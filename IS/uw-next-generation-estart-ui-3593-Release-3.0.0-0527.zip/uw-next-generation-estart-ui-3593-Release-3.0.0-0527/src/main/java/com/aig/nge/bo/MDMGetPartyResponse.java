package com.aig.nge.bo;

import java.util.List;

import com.aig.nge.utilities.NGECommonUtil;
import com.fasterxml.jackson.annotation.JsonProperty;

public class MDMGetPartyResponse {
	
	@JsonProperty("DunsNo")
	private String dunsNo="";
	@JsonProperty("PartyId")
	private String partyId="";
	@JsonProperty("PartyName")
	private String partyName="";
	@JsonProperty("MailingAddress")
	private String mailingAddress="";
	@JsonProperty("PhoneNumber")
	private String phoneNumber="";
	@JsonProperty("CEO")
	private String ceo="";
	@JsonProperty("LineOfBusiness")
	private String lineOfBusiness="";
	@JsonProperty("StartYear")
	private String startYear="";
	@JsonProperty("SalesAmount")
	private String salesAmount="";
	@JsonProperty("NumberOfEmployeesLocation")
	private String numberOfEmployeesLocation="";
	@JsonProperty("NumberOfEmployeesTotal")
	private String numberOfEmployeesTotal="";
	@JsonProperty("TradeName")
	private String tradeName="";
	
	
	@JsonProperty("DunsActiveIndicator")
	private String dunsActiveIndicator="";
	
	@JsonProperty("TreePositionCode")
	private String treePositionCode="";
	@JsonProperty("ParentDunsNo")
	private String parentDunsNo="";
	@JsonProperty("ParentDunsPartyName")
	private String ParentDunsPartyName="";	
	@JsonProperty("ParentDunsPartyId")
	private String parentDunsPartyId="";
	@JsonProperty("TopHQDunsNo")
	private String topHQDunsNo="";
	@JsonProperty("TopHQPartyID")
	private String topHQPartyID="";
	@JsonProperty("AccountUniverseType")
	private String accountUniverseType="";
	@JsonProperty("MultinationalIndicator")
	private String multinationalIndicator="";
	@JsonProperty("PrimarySIC")
	private String primarySIC="";
	@JsonProperty("Status")
	private String status="";
	@JsonProperty("CreditAlertInd")
	private String creditAlertInd="";
	
	//23-06-2021 MDM 2021 - change CreditAlertLiteral to CreditAlertAbbr
	//@JsonProperty("CreditAlertLiteral")
	//private String creditAlertLiteral="";
	@JsonProperty("CreditAlertAbbr")
	private String creditAlertAbbr="";

	@JsonProperty("Addresses")
	private List<Addresses> addresses;
	@JsonProperty("MarketSegmentInfo")
	private List<MarketSegmentInfo> marketSegmentInfo;
	
	@JsonProperty("TaxIdentifiers")
	private List<TaxIdentifiers> taxIdentifiers;
	@JsonProperty("sicInfo")
	private List<SicInfo> sicInfo;
	
	
	
	public String getDunsNo() {
		return dunsNo;
	}
	public void setDunsNo(String dunsNo) {
		dunsNo=NGECommonUtil.setDefaultStringValue(dunsNo);
		this.dunsNo = dunsNo;
	}
	public String getPartyId() {
		return partyId;
	}
	public void setPartyId(String partyId) {
		partyId=NGECommonUtil.setDefaultStringValue(partyId);
		this.partyId = partyId;
	}
	public String getPartyName() {
		return partyName;
	}
	public void setPartyName(String partyName) {
		partyName=NGECommonUtil.setDefaultStringValue(partyName);
		this.partyName = partyName;
	}
	public String getMailingAddress() {
		return mailingAddress;
	}
	public void setMailingAddress(String mailingAddress) {
		mailingAddress=NGECommonUtil.setDefaultStringValue(mailingAddress);
		this.mailingAddress = mailingAddress;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		phoneNumber=NGECommonUtil.setDefaultStringValue(phoneNumber);
		this.phoneNumber = phoneNumber;
	}
	public String getCeo() {
		return ceo;
	}
	public void setCeo(String ceo) {
		ceo=NGECommonUtil.setDefaultStringValue(ceo);
		this.ceo = ceo;
	}
	public String getLineOfBusiness() {
		return lineOfBusiness;
	}
	public void setLineOfBusiness(String lineOfBusiness) {
		lineOfBusiness=NGECommonUtil.setDefaultStringValue(lineOfBusiness);
		this.lineOfBusiness = lineOfBusiness;
	}
	public String getStartYear() {
		return startYear;
	}
	public void setStartYear(String startYear) {
		startYear=NGECommonUtil.setDefaultStringValue(startYear);
		this.startYear = startYear;
	}
	public String getSalesAmount() {
		return salesAmount;
	}
	public void setSalesAmount(String salesAmount) {
		salesAmount=NGECommonUtil.setDefaultStringValue(salesAmount);
		this.salesAmount = salesAmount;
	}
	public String getNumberOfEmployeesLocation() {
		return numberOfEmployeesLocation;
	}
	public void setNumberOfEmployeesLocation(String numberOfEmployeesLocation) {
		numberOfEmployeesLocation=NGECommonUtil.setDefaultStringValue(numberOfEmployeesLocation);
		this.numberOfEmployeesLocation = numberOfEmployeesLocation;
	}
	public String getNumberOfEmployeesTotal() {
		return numberOfEmployeesTotal;
	}
	public void setNumberOfEmployeesTotal(String numberOfEmployeesTotal) {
		numberOfEmployeesTotal=NGECommonUtil.setDefaultStringValue(numberOfEmployeesTotal);
		this.numberOfEmployeesTotal = numberOfEmployeesTotal;
	}
	
	public String getParentDunsNo() {
		return parentDunsNo;
	}
	public void setParentDunsNo(String parentDunsNo) {
		parentDunsNo=NGECommonUtil.setDefaultStringValue(parentDunsNo);
		this.parentDunsNo = parentDunsNo;
	}
	
	public String getTopHQDunsNo() {
		return topHQDunsNo;
	}
	public void setTopHQDunsNo(String topHQDunsNo) {
		NGECommonUtil.setDefaultStringValue(topHQDunsNo);
		this.topHQDunsNo = topHQDunsNo;
	}
	public String getTopHQPartyID() {
		return topHQPartyID;
	}
	public void setTopHQPartyID(String topHQPartyID) {
		topHQPartyID=NGECommonUtil.setDefaultStringValue(topHQPartyID);
		this.topHQPartyID = topHQPartyID;
	}
	public String getAccountUniverseType() {
		return accountUniverseType;
	}
	public void setAccountUniverseType(String accountUniverseType) {
		accountUniverseType=NGECommonUtil.setDefaultStringValue(accountUniverseType);
		this.accountUniverseType = accountUniverseType;
	}
	public String getMultinationalIndicator() {
		return multinationalIndicator;
	}
	public void setMultinationalIndicator(String multinationalIndicator) {
		multinationalIndicator=NGECommonUtil.setDefaultStringValue(multinationalIndicator);
		this.multinationalIndicator = multinationalIndicator;
	}
	public String getPrimarySIC() {
		return primarySIC;
	}
	public void setPrimarySIC(String primarySIC) {
		primarySIC=NGECommonUtil.setDefaultStringValue(primarySIC);
		this.primarySIC = primarySIC;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		status=NGECommonUtil.setDefaultStringValue(status);
		this.status = status;
	}
	public String getCreditAlertInd() {
		return creditAlertInd;
	}
	public void setCreditAlertInd(String creditAlertInd) {
		creditAlertInd=NGECommonUtil.setDefaultStringValue(creditAlertInd);
		this.creditAlertInd = creditAlertInd;
	}
	/* 23-06-2021 MDM 2021 - change CreditAlertLiteral to CreditAlertAbbr
	 public String getCreditAlertLiteral() {
		return creditAlertLiteral;
	}
	public void setCreditAlertLiteral(String creditAlertLiteral) {
		creditAlertLiteral=NGECommonUtil.setDefaultStringValue(creditAlertLiteral);
		this.creditAlertLiteral = creditAlertLiteral;
	}*/
	public List<Addresses> getAddresses() {
		return addresses;
	}
	public void setAddresses(List<Addresses> addresses) {
		this.addresses = addresses;
	}
	public List<MarketSegmentInfo> getMarketSegmentInfo() {
		return marketSegmentInfo;
	}
	public void setMarketSegmentInfo(List<MarketSegmentInfo> marketSegmentInfo) {
		this.marketSegmentInfo = marketSegmentInfo;
	}
	public List<TaxIdentifiers> getTaxIdentifiers() {
		return taxIdentifiers;
	}
	public void setTaxIdentifiers(List<TaxIdentifiers> taxIdentifiers) {
		this.taxIdentifiers = taxIdentifiers;
	}
	public String getParentDunsPartyId() {
		return parentDunsPartyId;
	}
	public void setParentDunsPartyId(String parentDunsPartyId) {
		parentDunsPartyId=NGECommonUtil.setDefaultStringValue(parentDunsPartyId);
		this.parentDunsPartyId = parentDunsPartyId;
	}
	public String getTradeName() {
		return tradeName;
	}
	public void setTradeName(String tradeName) {
		tradeName=NGECommonUtil.setDefaultStringValue(tradeName);
		this.tradeName = tradeName;
	}
	public String getTreePositionCode() {
		return treePositionCode;
	}
	public void setTreePositionCode(String treePositionCode) {
		treePositionCode=NGECommonUtil.setDefaultStringValue(treePositionCode);
		this.treePositionCode = treePositionCode;
	}
	public String getDunsActiveIndicator() {
		return dunsActiveIndicator;
	}
	public void setDunsActiveIndicator(String dunsActiveIndicator) {
		dunsActiveIndicator=NGECommonUtil.setDefaultStringValue(dunsActiveIndicator);
		this.dunsActiveIndicator = dunsActiveIndicator;
	}
	public List<SicInfo> getSicInfo() {
		return sicInfo;
	}
	public void setSicInfo(List<SicInfo> sicInfo) {
		this.sicInfo = sicInfo;
	}
	
	//23-06-2021 MDM 2021 - change CreditAlertLiteral to CreditAlertAbbr
	public String getCreditAlertAbbr() {
		return creditAlertAbbr;
	}
	public void setCreditAlertAbbr(String creditAlertAbbr) {
		creditAlertAbbr = NGECommonUtil.setDefaultStringValue(creditAlertAbbr);
		this.creditAlertAbbr = creditAlertAbbr;
	}
	public String getParentDunsPartyName() {
		return ParentDunsPartyName;
	}
	public void setParentDunsPartyName(String parentDunsPartyName) {
		ParentDunsPartyName = parentDunsPartyName;
	}
	
	
}
