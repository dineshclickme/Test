package com.aig.nge.bo;

import java.util.List;

public class UnderWriterDiarySearchResRows {
	private List<UnderWriterDiarySearchResBO> rows;

	public List<UnderWriterDiarySearchResBO> getRows() {
		return rows;
	}

	public void setRows(List<UnderWriterDiarySearchResBO> rows) {
		this.rows = rows;
	}
	
}
