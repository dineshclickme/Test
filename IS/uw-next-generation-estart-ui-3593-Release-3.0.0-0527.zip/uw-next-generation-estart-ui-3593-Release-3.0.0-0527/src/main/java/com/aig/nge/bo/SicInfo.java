package com.aig.nge.bo;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class SicInfo {
	
	@JsonProperty("SecondarySICCode")
	private String secondarySICCode="";
	@JsonProperty("SecondarySICDescription")
	private String secondarySICDescription="";
	@JsonProperty("SecondarySICSeqNo")
	private String secondarySICSeqNo="";
	public String getSecondarySICCode() {
		return secondarySICCode;
	}
	public void setSecondarySICCode(String secondarySICCode) {
		this.secondarySICCode = secondarySICCode;
	}
	public String getSecondarySICDescription() {
		return secondarySICDescription;
	}
	public void setSecondarySICDescription(String secondarySICDescription) {
		this.secondarySICDescription = secondarySICDescription;
	}
	public String getSecondarySICSeqNo() {
		return secondarySICSeqNo;
	}
	public void setSecondarySICSeqNo(String secondarySICSeqNo) {
		this.secondarySICSeqNo = secondarySICSeqNo;
	}
	
	
	
	
}
