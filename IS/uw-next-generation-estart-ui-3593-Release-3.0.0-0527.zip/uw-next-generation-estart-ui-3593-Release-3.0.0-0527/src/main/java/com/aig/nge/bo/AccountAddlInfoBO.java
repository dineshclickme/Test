package com.aig.nge.bo;

import java.util.List;

public class AccountAddlInfoBO {
    protected String creditAlertInd;
    protected String tradeName;
    protected String streetAddress;
    protected String mailingAddress;
    protected String cityName;
    protected String stateCode;
    protected String countyCode;
    protected String countryCode;
    protected String countryAbbr;
    protected String countryName;
    protected String postalCode;
    protected String phoneNumber;
    protected String faxNumber;
    protected String emailAddress;
    protected String webAddress;
    protected String marketSegmentCode;
    protected String marketSegmentName;
    protected String aiuMarketSegmentCode;
    protected String aiuMarketSegmentName;
    protected String fein;
    protected String riskManager;
    protected String dba;
    protected String ceo;
    protected String lineOfBusiness;
    protected String salesAmount;
    protected String numberOfEmployeesLocation;
    protected String numberOfEmployeesTotal;
    protected String primarySIC;
    protected List<SecondarySICBO> secondarySIC;
    protected String startYear;
    protected String multinationalIndicator;
    protected String creditAlertLiteral;
    protected String nationalID;
    protected String nationalIDDesc;
    protected String nationalIDValue;
    protected String netWorth;
    protected String creditScore;
    protected String currentAssests;
    protected String currentLiabilities;
    protected List<String> feins;
	/**
	 * @return the creditAlertInd
	 */
	public String getCreditAlertInd() {
		return creditAlertInd;
	}
	/**
	 * @param creditAlertInd the creditAlertInd to set
	 */
	public void setCreditAlertInd(String creditAlertInd) {
		this.creditAlertInd = creditAlertInd;
	}
	/**
	 * @return the tradeName
	 */
	public String getTradeName() {
		return tradeName;
	}
	/**
	 * @param tradeName the tradeName to set
	 */
	public void setTradeName(String tradeName) {
		this.tradeName = tradeName;
	}
	/**
	 * @return the streetAddress
	 */
	public String getStreetAddress() {
		return streetAddress;
	}
	/**
	 * @param streetAddress the streetAddress to set
	 */
	public void setStreetAddress(String streetAddress) {
		this.streetAddress = streetAddress;
	}
	/**
	 * @return the mailingAddress
	 */
	public String getMailingAddress() {
		return mailingAddress;
	}
	/**
	 * @param mailingAddress the mailingAddress to set
	 */
	public void setMailingAddress(String mailingAddress) {
		this.mailingAddress = mailingAddress;
	}
	/**
	 * @return the cityName
	 */
	public String getCityName() {
		return cityName;
	}
	/**
	 * @param cityName the cityName to set
	 */
	public void setCityName(String cityName) {
		this.cityName = cityName;
	}
	/**
	 * @return the stateCode
	 */
	public String getStateCode() {
		return stateCode;
	}
	/**
	 * @param stateCode the stateCode to set
	 */
	public void setStateCode(String stateCode) {
		this.stateCode = stateCode;
	}
	/**
	 * @return the countyCode
	 */
	public String getCountyCode() {
		return countyCode;
	}
	/**
	 * @param countyCode the countyCode to set
	 */
	public void setCountyCode(String countyCode) {
		this.countyCode = countyCode;
	}
	/**
	 * @return the countryCode
	 */
	public String getCountryCode() {
		return countryCode;
	}
	/**
	 * @param countryCode the countryCode to set
	 */
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}
	/**
	 * @return the countryAbbr
	 */
	public String getCountryAbbr() {
		return countryAbbr;
	}
	/**
	 * @param countryAbbr the countryAbbr to set
	 */
	public void setCountryAbbr(String countryAbbr) {
		this.countryAbbr = countryAbbr;
	}
	/**
	 * @return the countryName
	 */
	public String getCountryName() {
		return countryName;
	}
	/**
	 * @param countryName the countryName to set
	 */
	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}
	/**
	 * @return the postalCode
	 */
	public String getPostalCode() {
		return postalCode;
	}
	/**
	 * @param postalCode the postalCode to set
	 */
	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}
	/**
	 * @return the phoneNumber
	 */
	public String getPhoneNumber() {
		return phoneNumber;
	}
	/**
	 * @param phoneNumber the phoneNumber to set
	 */
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	/**
	 * @return the faxNumber
	 */
	public String getFaxNumber() {
		return faxNumber;
	}
	/**
	 * @param faxNumber the faxNumber to set
	 */
	public void setFaxNumber(String faxNumber) {
		this.faxNumber = faxNumber;
	}
	/**
	 * @return the emailAddress
	 */
	public String getEmailAddress() {
		return emailAddress;
	}
	/**
	 * @param emailAddress the emailAddress to set
	 */
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}
	/**
	 * @return the webAddress
	 */
	public String getWebAddress() {
		return webAddress;
	}
	/**
	 * @param webAddress the webAddress to set
	 */
	public void setWebAddress(String webAddress) {
		this.webAddress = webAddress;
	}
	/**
	 * @return the marketSegmentCode
	 */
	public String getMarketSegmentCode() {
		return marketSegmentCode;
	}
	/**
	 * @param marketSegmentCode the marketSegmentCode to set
	 */
	public void setMarketSegmentCode(String marketSegmentCode) {
		this.marketSegmentCode = marketSegmentCode;
	}
	/**
	 * @return the marketSegmentName
	 */
	public String getMarketSegmentName() {
		return marketSegmentName;
	}
	/**
	 * @param marketSegmentName the marketSegmentName to set
	 */
	public void setMarketSegmentName(String marketSegmentName) {
		this.marketSegmentName = marketSegmentName;
	}
	/**
	 * @return the aiuMarketSegmentCode
	 */
	public String getAiuMarketSegmentCode() {
		return aiuMarketSegmentCode;
	}
	/**
	 * @param aiuMarketSegmentCode the aiuMarketSegmentCode to set
	 */
	public void setAiuMarketSegmentCode(String aiuMarketSegmentCode) {
		this.aiuMarketSegmentCode = aiuMarketSegmentCode;
	}
	/**
	 * @return the aiuMarketSegmentName
	 */
	public String getAiuMarketSegmentName() {
		return aiuMarketSegmentName;
	}
	/**
	 * @param aiuMarketSegmentName the aiuMarketSegmentName to set
	 */
	public void setAiuMarketSegmentName(String aiuMarketSegmentName) {
		this.aiuMarketSegmentName = aiuMarketSegmentName;
	}
	/**
	 * @return the fein
	 */
	public String getFein() {
		return fein;
	}
	/**
	 * @param fein the fein to set
	 */
	public void setFein(String fein) {
		this.fein = fein;
	}
	/**
	 * @return the riskManager
	 */
	public String getRiskManager() {
		return riskManager;
	}
	/**
	 * @param riskManager the riskManager to set
	 */
	public void setRiskManager(String riskManager) {
		this.riskManager = riskManager;
	}
	/**
	 * @return the dba
	 */
	public String getDba() {
		return dba;
	}
	/**
	 * @param dba the dba to set
	 */
	public void setDba(String dba) {
		this.dba = dba;
	}
	/**
	 * @return the ceo
	 */
	public String getCeo() {
		return ceo;
	}
	/**
	 * @param ceo the ceo to set
	 */
	public void setCeo(String ceo) {
		this.ceo = ceo;
	}
	/**
	 * @return the lineOfBusiness
	 */
	public String getLineOfBusiness() {
		return lineOfBusiness;
	}
	/**
	 * @param lineOfBusiness the lineOfBusiness to set
	 */
	public void setLineOfBusiness(String lineOfBusiness) {
		this.lineOfBusiness = lineOfBusiness;
	}
	/**
	 * @return the salesAmount
	 */
	public String getSalesAmount() {
		return salesAmount;
	}
	/**
	 * @param salesAmount the salesAmount to set
	 */
	public void setSalesAmount(String salesAmount) {
		this.salesAmount = salesAmount;
	}
	/**
	 * @return the numberOfEmployeesLocation
	 */
	public String getNumberOfEmployeesLocation() {
		return numberOfEmployeesLocation;
	}
	/**
	 * @param numberOfEmployeesLocation the numberOfEmployeesLocation to set
	 */
	public void setNumberOfEmployeesLocation(String numberOfEmployeesLocation) {
		this.numberOfEmployeesLocation = numberOfEmployeesLocation;
	}
	/**
	 * @return the numberOfEmployeesTotal
	 */
	public String getNumberOfEmployeesTotal() {
		return numberOfEmployeesTotal;
	}
	/**
	 * @param numberOfEmployeesTotal the numberOfEmployeesTotal to set
	 */
	public void setNumberOfEmployeesTotal(String numberOfEmployeesTotal) {
		this.numberOfEmployeesTotal = numberOfEmployeesTotal;
	}
	/**
	 * @return the primarySIC
	 */
	public String getPrimarySIC() {
		return primarySIC;
	}
	/**
	 * @param primarySIC the primarySIC to set
	 */
	public void setPrimarySIC(String primarySIC) {
		this.primarySIC = primarySIC;
	}
	/**
	 * @return the secondarySIC
	 */
	public List<SecondarySICBO> getSecondarySIC() {
		return secondarySIC;
	}
	/**
	 * @param secondarySIC the secondarySIC to set
	 */
	public void setSecondarySIC(List<SecondarySICBO> secondarySIC) {
		this.secondarySIC = secondarySIC;
	}
	/**
	 * @return the startYear
	 */
	public String getStartYear() {
		return startYear;
	}
	/**
	 * @param startYear the startYear to set
	 */
	public void setStartYear(String startYear) {
		this.startYear = startYear;
	}
	/**
	 * @return the multinationalIndicator
	 */
	public String getMultinationalIndicator() {
		return multinationalIndicator;
	}
	/**
	 * @param multinationalIndicator the multinationalIndicator to set
	 */
	public void setMultinationalIndicator(String multinationalIndicator) {
		this.multinationalIndicator = multinationalIndicator;
	}
	/**
	 * @return the creditAlertLiteral
	 */
	public String getCreditAlertLiteral() {
		return creditAlertLiteral;
	}
	/**
	 * @param creditAlertLiteral the creditAlertLiteral to set
	 */
	public void setCreditAlertLiteral(String creditAlertLiteral) {
		this.creditAlertLiteral = creditAlertLiteral;
	}
	/**
	 * @return the nationalID
	 */
	public String getNationalID() {
		return nationalID;
	}
	/**
	 * @param nationalID the nationalID to set
	 */
	public void setNationalID(String nationalID) {
		this.nationalID = nationalID;
	}
	/**
	 * @return the nationalIDDesc
	 */
	public String getNationalIDDesc() {
		return nationalIDDesc;
	}
	/**
	 * @param nationalIDDesc the nationalIDDesc to set
	 */
	public void setNationalIDDesc(String nationalIDDesc) {
		this.nationalIDDesc = nationalIDDesc;
	}
	/**
	 * @return the nationalIDValue
	 */
	public String getNationalIDValue() {
		return nationalIDValue;
	}
	/**
	 * @param nationalIDValue the nationalIDValue to set
	 */
	public void setNationalIDValue(String nationalIDValue) {
		this.nationalIDValue = nationalIDValue;
	}
	/**
	 * @return the netWorth
	 */
	public String getNetWorth() {
		return netWorth;
	}
	/**
	 * @param netWorth the netWorth to set
	 */
	public void setNetWorth(String netWorth) {
		this.netWorth = netWorth;
	}
	/**
	 * @return the creditScore
	 */
	public String getCreditScore() {
		return creditScore;
	}
	/**
	 * @param creditScore the creditScore to set
	 */
	public void setCreditScore(String creditScore) {
		this.creditScore = creditScore;
	}
	/**
	 * @return the currentAssests
	 */
	public String getCurrentAssests() {
		return currentAssests;
	}
	/**
	 * @param currentAssests the currentAssests to set
	 */
	public void setCurrentAssests(String currentAssests) {
		this.currentAssests = currentAssests;
	}
	/**
	 * @return the currentLiabilities
	 */
	public String getCurrentLiabilities() {
		return currentLiabilities;
	}
	/**
	 * @param currentLiabilities the currentLiabilities to set
	 */
	public void setCurrentLiabilities(String currentLiabilities) {
		this.currentLiabilities = currentLiabilities;
	}
	/**
	 * @return the feins
	 */
	public List<String> getFeins() {
		return feins;
	}
	/**
	 * @param feins the feins to set
	 */
	public void setFeins(List<String> feins) {
		this.feins = feins;
	}
}
