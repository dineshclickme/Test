package com.aig.nge.bo;

public class BlockComponentProductBO {

	private String blockNo;
	private String transactionId;
	private String transactionVersionNo;
	private String segmentCd;
	private String subSegmentCd;
	private String segmentNm;
	private String subSegmentNm;
	private String marketableProductCd;
	private String marketableProductName;
	private String componentProductCd;
	private String componentProductName;
	private String reasonCd;
	private String reasonDs;
	private String blockStatus;
	private String blockStatusDs;
	private String blockingExpirationDt;
	private LimitBO limit;
	private UnderwriterBO underwriterDet;
	private AlternateContactDetailsBO alternateContactDet;
	private String componentProductSegmentCd;
	private String componentProductSubSegmentCd;
	private String componentProductSegmentNm;
	private String componentProductSubSegmentNm;
	private String submissionNo;
	private String accountName;
	//US145616 SCUP view/release block Changes 2020 started
	private String masterLineOfBusinessCd;
	private String masterLineOfBusinessNm;
	private String coverageLineCd;
	private String coverageLineNm;
	
	
	public String getMasterLineOfBusinessCd() {
		return masterLineOfBusinessCd;
	}

	public void setMasterLineOfBusinessCd(String masterLineOfBusinessCd) {
		this.masterLineOfBusinessCd = masterLineOfBusinessCd;
	}

	public String getMasterLineOfBusinessNm() {
		return masterLineOfBusinessNm;
	}

	public void setMasterLineOfBusinessNm(String masterLineOfBusinessNm) {
		this.masterLineOfBusinessNm = masterLineOfBusinessNm;
	}

	public String getCoverageLineCd() {
		return coverageLineCd;
	}

	public void setCoverageLineCd(String coverageLineCd) {
		this.coverageLineCd = coverageLineCd;
	}

	public String getCoverageLineNm() {
		return coverageLineNm;
	}

	public void setCoverageLineNm(String coverageLineNm) {
		this.coverageLineNm = coverageLineNm;
	}
	//US145616 SCUP view/release block Changes 2020 ended
	public String getBlockNo() {
		return blockNo;
	}

	public void setBlockNo(String blockNo) {
		this.blockNo = blockNo;
	}

	public String getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}

	public String getTransactionVersionNo() {
		return transactionVersionNo;
	}

	public void setTransactionVersionNo(String transactionVersionNo) {
		this.transactionVersionNo = transactionVersionNo;
	}

	public String getSegmentCd() {
		return segmentCd;
	}

	public void setSegmentCd(String segmentCd) {
		this.segmentCd = segmentCd;
	}

	public String getSubSegmentCd() {
		return subSegmentCd;
	}

	public void setSubSegmentCd(String subSegmentCd) {
		this.subSegmentCd = subSegmentCd;
	}

	public String getSegmentNm() {
		return segmentNm;
	}

	public void setSegmentNm(String segmentNm) {
		this.segmentNm = segmentNm;
	}

	public String getSubSegmentNm() {
		return subSegmentNm;
	}

	public void setSubSegmentNm(String subSegmentNm) {
		this.subSegmentNm = subSegmentNm;
	}

	public String getMarketableProductCd() {
		return marketableProductCd;
	}

	public void setMarketableProductCd(String marketableProductCd) {
		this.marketableProductCd = marketableProductCd;
	}

	public String getMarketableProductName() {
		return marketableProductName;
	}

	public void setMarketableProductName(String marketableProductName) {
		this.marketableProductName = marketableProductName;
	}

	public String getComponentProductCd() {
		return componentProductCd;
	}

	public void setComponentProductCd(String componentProductCd) {
		this.componentProductCd = componentProductCd;
	}

	public String getComponentProductName() {
		return componentProductName;
	}

	public void setComponentProductName(String componentProductName) {
		this.componentProductName = componentProductName;
	}

	public String getReasonCd() {
		return reasonCd;
	}

	public void setReasonCd(String reasonCd) {
		this.reasonCd = reasonCd;
	}

	public String getReasonDs() {
		return reasonDs;
	}

	public void setReasonDs(String reasonDs) {
		this.reasonDs = reasonDs;
	}

	public String getBlockStatus() {
		return blockStatus;
	}

	public void setBlockStatus(String blockStatus) {
		this.blockStatus = blockStatus;
	}

	public String getBlockStatusDs() {
		return blockStatusDs;
	}

	public void setBlockStatusDs(String blockStatusDs) {
		this.blockStatusDs = blockStatusDs;
	}

	public String getBlockingExpirationDt() {
		return blockingExpirationDt;
	}

	public void setBlockingExpirationDt(String blockingExpirationDt) {
		this.blockingExpirationDt = blockingExpirationDt;
	}

	public LimitBO getLimit() {
		return limit;
	}

	public void setLimit(LimitBO limit) {
		this.limit = limit;
	}

	public UnderwriterBO getUnderwriterDet() {
		return underwriterDet;
	}

	public void setUnderwriterDet(UnderwriterBO underwriterDet) {
		this.underwriterDet = underwriterDet;
	}

	public AlternateContactDetailsBO getAlternateContactDet() {
		return alternateContactDet;
	}

	public void setAlternateContactDet(
			AlternateContactDetailsBO alternateContactDet) {
		this.alternateContactDet = alternateContactDet;
	}

	public String getComponentProductSegmentCd() {
		return componentProductSegmentCd;
	}

	public void setComponentProductSegmentCd(String componentProductSegmentCd) {
		this.componentProductSegmentCd = componentProductSegmentCd;
	}

	public String getComponentProductSubSegmentCd() {
		return componentProductSubSegmentCd;
	}

	public void setComponentProductSubSegmentCd(
			String componentProductSubSegmentCd) {
		this.componentProductSubSegmentCd = componentProductSubSegmentCd;
	}

	public String getComponentProductSegmentNm() {
		return componentProductSegmentNm;
	}

	public void setComponentProductSegmentNm(String componentProductSegmentNm) {
		this.componentProductSegmentNm = componentProductSegmentNm;
	}

	public String getComponentProductSubSegmentNm() {
		return componentProductSubSegmentNm;
	}

	public void setComponentProductSubSegmentNm(
			String componentProductSubSegmentNm) {
		this.componentProductSubSegmentNm = componentProductSubSegmentNm;
	}

	public String getSubmissionNo() {
		return submissionNo;
	}

	public void setSubmissionNo(String submissionNo) {
		this.submissionNo = submissionNo;
	}

	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

}
