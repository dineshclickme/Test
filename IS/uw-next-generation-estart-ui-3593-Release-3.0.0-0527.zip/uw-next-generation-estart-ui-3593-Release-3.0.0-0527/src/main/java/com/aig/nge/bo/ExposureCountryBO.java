package com.aig.nge.bo;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

public class ExposureCountryBO {
	
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String transactionId;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String versionId;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String productTabKey;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String componentTabKey;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private List<String> countryList;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String exposureType;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String exposureValue;
	
	public String getExposureValue() {
		return exposureValue;
	}
	public void setExposureValue(String exposureValue) {
		this.exposureValue = exposureValue;
	}
	private String dataKey;
	
	
	public String getDataKey() {
		return dataKey;
	}
	public void setDataKey(String dataKey) {
		this.dataKey = dataKey;
	}
	public String getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	public String getVersionId() {
		return versionId;
	}
	public void setVersionId(String versionId) {
		this.versionId = versionId;
	}
	public String getProductTabKey() {
		return productTabKey;
	}
	public void setProductTabKey(String productTabKey) {
		this.productTabKey = productTabKey;
	}
	public String getComponentTabKey() {
		return componentTabKey;
	}
	public void setComponentTabKey(String componentTabKey) {
		this.componentTabKey = componentTabKey;
	}
	public List<String> getCountryList() {
		return countryList;
	}
	public void setCountryList(List<String> countryList) {
		this.countryList = countryList;
	}
	public String getExposureType() {
		return exposureType;
	}
	public void setExposureType(String exposureType) {
		this.exposureType = exposureType;
	}
		
}
