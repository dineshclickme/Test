package com.aig.nge.bo;

import java.util.List;

public class AgencyInfoBO {
	private List<LicenseTypeBO> agencyLicense;
	private String producerCd;
	private String producerNm;
	private String producerStatusCd;
	private String producerTradeNm;
	/**
	 * @return the producerTradeNm
	 */
	public String getProducerTradeNm() {
		return producerTradeNm;
	}
	/**
	 * @param producerTradeNm the producerTradeNm to set
	 */
	public void setProducerTradeNm(String producerTradeNm) {
		this.producerTradeNm = producerTradeNm;
	}
	/**
	 * @return the agencyLicense
	 */
	public List<LicenseTypeBO> getAgencyLicense() {
		return agencyLicense;
	}
	/**
	 * @param agencyLicense the agencyLicense to set
	 */
	public void setAgencyLicense(List<LicenseTypeBO> agencyLicense) {
		this.agencyLicense = agencyLicense;
	}
	/**
	 * @return the producerCd
	 */
	public String getProducerCd() {
		return producerCd;
	}
	/**
	 * @param producerCd the producerCd to set
	 */
	public void setProducerCd(String producerCd) {
		this.producerCd = producerCd;
	}
	/**
	 * @return the producerNm
	 */
	public String getProducerNm() {
		return producerNm;
	}
	/**
	 * @param producerNm the producerNm to set
	 */
	public void setProducerNm(String producerNm) {
		this.producerNm = producerNm;
	}
	/**
	 * @return the producerStatusCd
	 */
	public String getProducerStatusCd() {
		return producerStatusCd;
	}
	/**
	 * @param producerStatusCd the producerStatusCd to set
	 */
	public void setProducerStatusCd(String producerStatusCd) {
		this.producerStatusCd = producerStatusCd;
	}

}
