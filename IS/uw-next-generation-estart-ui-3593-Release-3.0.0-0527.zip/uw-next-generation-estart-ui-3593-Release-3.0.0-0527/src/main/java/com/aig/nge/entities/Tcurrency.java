package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Date;
import java.util.Set;


/**
 * The persistent class for the TCURRENCY database table.
 * 
 */
@Entity
public class Tcurrency implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="CURRENCY_ID")
	private short currencyId;

	@Column(name="AIG_CURRENCY_CD")
	private String aigCurrencyCd;

	@Column(name="CREATE_TS")
	private Timestamp createTs;

	@Column(name="CREATE_USER_ID")
	private String createUserId;

	@Column(name="CURRENCY_CD")
	private String currencyCd;

	@Column(name="CURRENCY_NM")
	private String currencyNm;

    @Temporal( TemporalType.DATE)
	@Column(name="EFFECTIVE_DT")
	private Date effectiveDt;

    @Temporal( TemporalType.DATE)
	@Column(name="EXPIRATION_DT")
	private Date expirationDt;

	@Column(name="UPDATE_TS")
	private Timestamp updateTs;

	@Column(name="UPDATE_USER_ID")
	private String updateUserId;

	//bi-directional many-to-one association to Tcurrency
	@ManyToOne
	@JoinColumn(name="ROLL_OVER_CURRENCY_ID")
	private Tcurrency tcurrency;

	//bi-directional many-to-one association to Tcurrency
	@OneToMany(mappedBy="tcurrency")
	private Set<Tcurrency> tcurrencies;

	//bi-directional many-to-one association to TlegacyWipQuoteCurrency
	@OneToMany(mappedBy="tcurrency", cascade={CascadeType.ALL})
	private Set<TlegacyWipQuoteCurrency> tlegacyWipQuoteCurrencies;

	//bi-directional many-to-one association to Tpolicy
	@OneToMany(mappedBy="tcurrency", cascade={CascadeType.ALL})
	private Set<Tpolicy> tpolicies;

	//bi-directional many-to-one association to TtransactionComponentLimit
	@OneToMany(mappedBy="tcurrency", cascade={CascadeType.ALL})
	private Set<TtransactionComponentLimit> ttransactionComponentLimits;

	//bi-directional many-to-one association to TuserPrefernce
	@OneToMany(mappedBy="tcurrency", cascade={CascadeType.ALL})
	private Set<TuserPrefernce> tuserPrefernces;

    public Tcurrency() {
    }

	public short getCurrencyId() {
		return this.currencyId;
	}

	public void setCurrencyId(short currencyId) {
		this.currencyId = currencyId;
	}

	public String getAigCurrencyCd() {
		return this.aigCurrencyCd;
	}

	public void setAigCurrencyCd(String aigCurrencyCd) {
		this.aigCurrencyCd = aigCurrencyCd;
	}

	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public String getCurrencyCd() {
		return this.currencyCd;
	}

	public void setCurrencyCd(String currencyCd) {
		this.currencyCd = currencyCd;
	}

	public String getCurrencyNm() {
		return this.currencyNm;
	}

	public void setCurrencyNm(String currencyNm) {
		this.currencyNm = currencyNm;
	}

	public Date getEffectiveDt() {
		return this.effectiveDt;
	}

	public void setEffectiveDt(Date effectiveDt) {
		this.effectiveDt = effectiveDt;
	}

	public Date getExpirationDt() {
		return this.expirationDt;
	}

	public void setExpirationDt(Date expirationDt) {
		this.expirationDt = expirationDt;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public Tcurrency getTcurrency() {
		return this.tcurrency;
	}

	public void setTcurrency(Tcurrency tcurrency) {
		this.tcurrency = tcurrency;
	}
	
	public Set<Tcurrency> getTcurrencies() {
		return this.tcurrencies;
	}

	public void setTcurrencies(Set<Tcurrency> tcurrencies) {
		this.tcurrencies = tcurrencies;
	}
	
	public Set<TlegacyWipQuoteCurrency> getTlegacyWipQuoteCurrencies() {
		return this.tlegacyWipQuoteCurrencies;
	}

	public void setTlegacyWipQuoteCurrencies(Set<TlegacyWipQuoteCurrency> tlegacyWipQuoteCurrencies) {
		this.tlegacyWipQuoteCurrencies = tlegacyWipQuoteCurrencies;
	}
	
	public Set<Tpolicy> getTpolicies() {
		return this.tpolicies;
	}

	public void setTpolicies(Set<Tpolicy> tpolicies) {
		this.tpolicies = tpolicies;
	}
	
	public Set<TtransactionComponentLimit> getTtransactionComponentLimits() {
		return this.ttransactionComponentLimits;
	}

	public void setTtransactionComponentLimits(Set<TtransactionComponentLimit> ttransactionComponentLimits) {
		this.ttransactionComponentLimits = ttransactionComponentLimits;
	}
	
	public Set<TuserPrefernce> getTuserPrefernces() {
		return this.tuserPrefernces;
	}

	public void setTuserPrefernces(Set<TuserPrefernce> tuserPrefernces) {
		this.tuserPrefernces = tuserPrefernces;
	}
	
}