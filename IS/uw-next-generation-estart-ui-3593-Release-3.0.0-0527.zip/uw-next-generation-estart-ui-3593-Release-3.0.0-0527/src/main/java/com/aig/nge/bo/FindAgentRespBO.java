/**
 * 
 */
package com.aig.nge.bo;

import java.util.List;

/**
 * @author Bennym
 *
 */
public class FindAgentRespBO {
	private List<AgentDetailTypeBO> rows;
	private ErrorDetailBO errorDetail;

	/**
	 * @return the errorDetail
	 */
	public ErrorDetailBO getErrorDetail() {
		return errorDetail;
	}

	/**
	 * @param errorDetail the errorDetail to set
	 */
	public void setErrorDetail(ErrorDetailBO errorDetail) {
		this.errorDetail = errorDetail;
	}

	public List<AgentDetailTypeBO> getRows() {
		return rows;
	}

	public void setRows(List<AgentDetailTypeBO> rows) {
		this.rows = rows;
	}
	
	
}
