package com.aig.nge.dao;

import java.math.BigDecimal;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.aig.nge.bo.ProductBO;
import com.aig.nge.entities.TattributeReference;
import com.aig.nge.entities.Tevent;
import com.aig.nge.entities.Ttable;
import com.aig.nge.entities.TtransactionComponentLimit;
import com.aig.nge.repository.TTransactionComponentAtrbtRepository;
import com.aig.nge.repository.TTransactionComponentLimitRepository;
import com.aig.nge.repository.TeventRepository;
import com.aig.nge.repository.TtableRepository;
import com.aig.nge.repository.TtowerEventRepository;

@Repository
public class AttributesDAO extends BaseDAO {
	
	@Autowired
	private TtableRepository ttableRepository;
	
	@Autowired
	private TeventRepository teventRepository;
	
	@Autowired
	private TtowerEventRepository ttowerEventRepository;
	@Autowired
	private TTransactionComponentAtrbtRepository ttransactionComponentAtrbtRepository;
	@Autowired
	private TTransactionComponentLimitRepository ttransactionComponentLimitRepository;
	
	
	public List<TattributeReference> getAttrReference(String referenceGroupId,String deletedInd){
		
		return ttableRepository.getAttrReference(referenceGroupId,deletedInd);
	}
	
	public Set<Ttable> getTablesDAO(){
		Set<Ttable> tables = new HashSet<Ttable>();
		tables = ttableRepository.getTables();
		return tables;
	}
	
	public Ttable getEventTableDAO(String eventTableName){
		Ttable eventTable = ttableRepository.getEventTable(eventTableName);
		return eventTable;
	}

	public Set<Tevent> getEventsDAO() {
		Set<Tevent> events = new HashSet<Tevent>();
		events = teventRepository.getEvents();
		return events;
	}

	public Set<Object[]> getTowerEventsDAO() {
		Set<Object[]> towerEvents = new HashSet<Object[]>();
		towerEvents = ttowerEventRepository.getTowerEvents();
		return towerEvents;
	}
	
	public List<TtransactionComponentLimit> getTransactionComponentIdDAO(ProductBO productBO){
		
		
		if(productBO.getMarketableProductCd()==null || productBO.getMarketableProductCd().length()==0){
			return ttransactionComponentLimitRepository.findByComponentProduct(productBO.getTransactionId(),
					Short.valueOf(productBO.getTransactionVersionNo()),
					productBO.getSegmentCd(), 
					productBO.getSubSegmentCd(),
					productBO.getComponentProductCd(),
					new BigDecimal(productBO.getAttachmentPointAmt()));
		}
		return ttransactionComponentLimitRepository.findByMarketableComponent(productBO.getTransactionId(),
				Short.valueOf(productBO.getTransactionVersionNo()),
				productBO.getSegmentCd(), 
				productBO.getSubSegmentCd(),
				productBO.getMarketableProductCd(),
				productBO.getComponentProductCd(),
				new BigDecimal(productBO.getAttachmentPointAmt()));
		
	}
	public List<String> getRecurringIndDAO(String attributeId ,String transactionComponentId){
		
		return ttransactionComponentAtrbtRepository.getAttributeValues(attributeId, transactionComponentId);
	}
}
