package com.aig.nge.bo;

import java.util.List;

public class GetsubmissionrespBO {

	/**
	 * @return the submissionNo
	 */
	public String getSubmissionNo() {
		return submissionNo;
	}
	/**
	 * @param submissionNo the submissionNo to set
	 */
	public void setSubmissionNo(String submissionNo) {
		this.submissionNo = submissionNo;
	}
	/**
	 * @return the createTs
	 */
	public String getCreateTs() {
		return createTs;
	}
	/**
	 * @param createTs the createTs to set
	 */
	public void setCreateTs(String createTs) {
		this.createTs = createTs;
	}
	/**
	 * @return the accoutdet
	 */
	public AccountBO getAccoutdet() {
		return accoutdet;
	}
	/**
	 * @param accoutdet the accoutdet to set
	 */
	public void setAccoutdet(AccountBO accoutdet) {
		this.accoutdet = accoutdet;
	}
	/**
	 * @return the producerdet
	 */
	public ProducerBO getProducerdet() {
		return producerdet;
	}
	/**
	 * @param producerdet the producerdet to set
	 */
	public void setProducerdet(ProducerBO producerdet) {
		this.producerdet = producerdet;
	}
	/**
	 * @return the transactiondet
	 */
	public List<TransactionBO> getTransactiondet() {
		return transactiondet;
	}
	/**
	 * @param transactiondet the transactiondet to set
	 */
	public void setTransactiondet(List<TransactionBO> transactiondet) {
		this.transactiondet = transactiondet;
	}
	private String submissionNo;
	private String createTs;
	private AccountBO accoutdet;
	private ProducerBO producerdet;
	private List<TransactionBO> transactiondet;
}
