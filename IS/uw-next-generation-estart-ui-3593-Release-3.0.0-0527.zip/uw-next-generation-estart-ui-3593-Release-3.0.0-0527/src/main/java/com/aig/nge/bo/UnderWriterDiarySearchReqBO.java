package com.aig.nge.bo;

import com.fasterxml.jackson.annotation.JsonInclude;

public class UnderWriterDiarySearchReqBO {
	
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String transactionType;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String autoCloseDays;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String lifeCycleStatus;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String transactionTypeId;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String autoCloseDaysId;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String lifeCycleStatusId;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String fromDate;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String toDate;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String accountName;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String accountnumberHidden;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String submissionNo;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String underwriterId;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String underwriterName;
	
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	public String getAutoCloseDays() {
		return autoCloseDays;
	}
	public void setAutoCloseDays(String autoCloseDays) {
		this.autoCloseDays = autoCloseDays;
	}
	public String getLifeCycleStatus() {
		return lifeCycleStatus;
	}
	public void setLifeCycleStatus(String lifeCycleStatus) {
		this.lifeCycleStatus = lifeCycleStatus;
	}
	public String getFromDate() {
		return fromDate;
	}
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}
	public String getToDate() {
		return toDate;
	}
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}
	public String getAccountName() {
		return accountName;
	}
	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}
	public String getSubmissionNo() {
		return submissionNo;
	}
	public void setSubmissionNo(String submissionNo) {
		this.submissionNo = submissionNo;
	}
	public String getUnderwriterId() {
		return underwriterId;
	}
	public void setUnderwriterId(String underwriterId) {
		this.underwriterId = underwriterId;
	}
	public String getUnderwriterName() {
		return underwriterName;
	}
	public void setUnderwriterName(String underwriterName) {
		this.underwriterName = underwriterName;
	}
	public String getTransactionTypeId() {
		return transactionTypeId;
	}
	public void setTransactionTypeId(String transactionTypeId) {
		this.transactionTypeId = transactionTypeId;
	}
	public String getAutoCloseDaysId() {
		return autoCloseDaysId;
	}
	public void setAutoCloseDaysId(String autoCloseDaysId) {
		this.autoCloseDaysId = autoCloseDaysId;
	}
	public String getLifeCycleStatusId() {
		return lifeCycleStatusId;
	}
	public void setLifeCycleStatusId(String lifeCycleStatusId) {
		this.lifeCycleStatusId = lifeCycleStatusId;
	}
	public String getAccountnumberHidden() {
		return accountnumberHidden;
	}
	public void setAccountnumberHidden(String accountnumberHidden) {
		this.accountnumberHidden = accountnumberHidden;
	}
	
}
