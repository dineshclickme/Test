package com.aig.nge.bo;

public class BranchBO {
	
	private String typeName;
	private String countryCd;
	private String countryName;
	private String branchCd;
	private String branchName;	
	private String branchTypeCd;
	
	public String getTypeName() {
		return typeName;
	}
	public void setTypeName(String typeName) {
		this.typeName = typeName;
	}
	public String getCountryCd() {
		return countryCd;
	}
	public void setCountryCd(String countryCd) {
		this.countryCd = countryCd;
	}
	public String getCountryName() {
		return countryName;
	}
	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}
	public String getBranchCd() {
		return branchCd;
	}
	public void setBranchCd(String branchCd) {
		this.branchCd = branchCd;
	}
	public String getBranchName() {
		return branchName;
	}
	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}
	/**
	 * @return the branchTypeCd
	 */
	public String getBranchTypeCd() {
		return branchTypeCd;
	}
	/**
	 * @param branchTypeCd the branchTypeCd to set
	 */
	public void setBranchTypeCd(String branchTypeCd) {
		this.branchTypeCd = branchTypeCd;
	}
	
	

}
