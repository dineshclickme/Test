package com.aig.nge.bo;

import java.util.List;
import java.util.Map;

public class BusinessTypeBO {
	
	private String screen;
	private List<Map<String,String>> data;
	
	public String getScreen() {
		return screen;
	}
	public void setScreen(String screen) {
		this.screen = screen;
	}
	public List<Map<String, String>> getData() {
		return data;
	}
	public void setData(List<Map<String, String>> data) {
		this.data = data;
	}

}
