package com.aig.nge.bo;

import java.util.List;

public class AgencyLicenseInfoBO {
	private List<AgencyInfoBO> agencyInfo;
	private String totalRecCount;
	/**
	 * @return the agencyInfo
	 */
	public List<AgencyInfoBO> getAgencyInfo() {
		return agencyInfo;
	}
	/**
	 * @param agencyInfo the agencyInfo to set
	 */
	public void setAgencyInfo(List<AgencyInfoBO> agencyInfo) {
		this.agencyInfo = agencyInfo;
	}
	/**
	 * @return the totalRecCount
	 */
	public String getTotalRecCount() {
		return totalRecCount;
	}
	/**
	 * @param totalRecCount the totalRecCount to set
	 */
	public void setTotalRecCount(String totalRecCount) {
		this.totalRecCount = totalRecCount;
	}
	
}
