package com.aig.nge.bo;


public class GetAccountResponseBO {
	private GetAccountResultsBO getAccountResults;
    private MessErrBO messages;
    private MessErrBO errors;
    private String masterConditionCode;
	/**
	 * @return the getAccountResults
	 */
	public GetAccountResultsBO getGetAccountResults() {
		return getAccountResults;
	}
	/**
	 * @param getAccountResults the getAccountResults to set
	 */
	public void setGetAccountResults(GetAccountResultsBO getAccountResults) {
		this.getAccountResults = getAccountResults;
	}
	/**
	 * @return the messages
	 */
	public MessErrBO getMessages() {
		return messages;
	}
	/**
	 * @param messages the messages to set
	 */
	public void setMessages(MessErrBO messages) {
		this.messages = messages;
	}
	/**
	 * @return the errors
	 */
	public MessErrBO getErrors() {
		return errors;
	}
	/**
	 * @param errors the errors to set
	 */
	public void setErrors(MessErrBO errors) {
		this.errors = errors;
	}
	/**
	 * @return the masterConditionCode
	 */
	public String getMasterConditionCode() {
		return masterConditionCode;
	}
	/**
	 * @param masterConditionCode the masterConditionCode to set
	 */
	public void setMasterConditionCode(String masterConditionCode) {
		this.masterConditionCode = masterConditionCode;
	}
}
