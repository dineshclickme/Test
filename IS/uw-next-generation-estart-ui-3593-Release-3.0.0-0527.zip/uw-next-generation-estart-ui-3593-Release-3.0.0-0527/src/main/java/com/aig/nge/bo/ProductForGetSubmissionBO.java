package com.aig.nge.bo;

public class ProductForGetSubmissionBO {
	
	private String dataKey;
	private String transaction;
	private String version;
	private String productId;
	private String productTower;
	private String mktProduct;
	private String bundleUnderwriter;
	private String lifeCycleStatus;
	private String productTowerHidden;
	private String mktProductHidden;
	private String lifeCycleStatusHidden;
	private String reservationStatusHidden;
	private String productName;
	private String segmentCdHidden;
	private String subSegmentCdHidden;
	private String bundleUnderwriterPartyNo;
	private String productTowerName;
	private String creditedCountryPLHidden;
	
	private String componentSegmentCdHidden;
	private String componentSubSegmentCdHidden;
	private String componentProductTowerName;
	private String componentProductTower;
	private String componentProductTowerHidden;
	
	 /* 2020 SCUP Changes UI Changes */
    private String masterLineOfCd;
    private String masterLineOfNm;
    private String coverageLineCd;
    private String coverageLineNm;
	
	public String getMasterLineOfCd() {
		return masterLineOfCd;
	}
	public void setMasterLineOfCd(String masterLineOfCd) {
		this.masterLineOfCd = masterLineOfCd;
	}
	public String getMasterLineOfNm() {
		return masterLineOfNm;
	}
	public void setMasterLineOfNm(String masterLineOfNm) {
		this.masterLineOfNm = masterLineOfNm;
	}
	public String getCoverageLineCd() {
		return coverageLineCd;
	}
	public void setCoverageLineCd(String coverageLineCd) {
		this.coverageLineCd = coverageLineCd;
	}
	public String getCoverageLineNm() {
		return coverageLineNm;
	}
	public void setCoverageLineNm(String coverageLineNm) {
		this.coverageLineNm = coverageLineNm;
	}	
	 /* 2020 SCUP Changes UI Changes */
	
	public String getCreditedCountryPLHidden() {
		return creditedCountryPLHidden;
	}
	public void setCreditedCountryPLHidden(String creditedCountryPLHidden) {
		this.creditedCountryPLHidden = creditedCountryPLHidden;
	}
	public String getProductTowerName() {
		return productTowerName;
	}
	public void setProductTowerName(String productTowerName) {
		this.productTowerName = productTowerName;
	}
	public String getBundleUnderwriterPartyNo() {
		return bundleUnderwriterPartyNo;
	}
	public void setBundleUnderwriterPartyNo(String bundleUnderwriterPartyNo) {
		this.bundleUnderwriterPartyNo = bundleUnderwriterPartyNo;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getDataKey() {
		return dataKey;
	}
	public void setDataKey(String dataKey) {
		this.dataKey = dataKey;
	}
	public String getTransaction() {
		return transaction;
	}
	public void setTransaction(String transaction) {
		this.transaction = transaction;
	}
	public String getVersion() {
		return version;
	}
	public void setVersion(String version) {
		this.version = version;
	}
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getProductTower() {
		return productTower;
	}
	public void setProductTower(String productTower) {
		this.productTower = productTower;
	}
	public String getMktProduct() {
		return mktProduct;
	}
	public void setMktProduct(String mktProduct) {
		this.mktProduct = mktProduct;
	}
	public String getBundleUnderwriter() {
		return bundleUnderwriter;
	}
	public void setBundleUnderwriter(String bundleUnderwriter) {
		this.bundleUnderwriter = bundleUnderwriter;
	}
	public String getLifeCycleStatus() {
		return lifeCycleStatus;
	}
	public void setLifeCycleStatus(String lifeCycleStatus) {
		this.lifeCycleStatus = lifeCycleStatus;
	}
	/**
	 * @return the productTowerHidden
	 */
	public String getProductTowerHidden() {
		return productTowerHidden;
	}
	/**
	 * @param productTowerHidden the productTowerHidden to set
	 */
	public void setProductTowerHidden(String productTowerHidden) {
		this.productTowerHidden = productTowerHidden;
	}
	/**
	 * @return the mktProductHidden
	 */
	public String getMktProductHidden() {
		return mktProductHidden;
	}
	/**
	 * @param mktProductHidden the mktProductHidden to set
	 */
	public void setMktProductHidden(String mktProductHidden) {
		this.mktProductHidden = mktProductHidden;
	}
	public String getLifeCycleStatusHidden() {
		return lifeCycleStatusHidden;
	}
	public void setLifeCycleStatusHidden(String lifeCycleStatusHidden) {
		this.lifeCycleStatusHidden = lifeCycleStatusHidden;
	}
	public String getReservationStatusHidden() {
		return reservationStatusHidden;
	}
	public void setReservationStatusHidden(String reservationStatusHidden) {
		this.reservationStatusHidden = reservationStatusHidden;
	}
	public String getSegmentCdHidden() {
		return segmentCdHidden;
	}
	public void setSegmentCdHidden(String segmentCdHidden) {
		this.segmentCdHidden = segmentCdHidden;
	}
	public String getSubSegmentCdHidden() {
		return subSegmentCdHidden;
	}
	public void setSubSegmentCdHidden(String subSegmentCdHidden) {
		this.subSegmentCdHidden = subSegmentCdHidden;
	}
	public String getComponentSegmentCdHidden() {
		return componentSegmentCdHidden;
	}
	public void setComponentSegmentCdHidden(String componentSegmentCdHidden) {
		this.componentSegmentCdHidden = componentSegmentCdHidden;
	}

	public String getComponentProductTowerName() {
		return componentProductTowerName;
	}
	public void setComponentProductTowerName(String componentProductTowerName) {
		this.componentProductTowerName = componentProductTowerName;
	}
	
	public String getComponentSubSegmentCdHidden() {
		return componentSubSegmentCdHidden;
	}
	public void setComponentSubSegmentCdHidden(String componentSubSegmentCdHidden) {
		this.componentSubSegmentCdHidden = componentSubSegmentCdHidden;
	}
	public String getComponentProductTower() {
		return componentProductTower;
	}
	public void setComponentProductTower(String componentProductTower) {
		this.componentProductTower = componentProductTower;
	}
	public String getComponentProductTowerHidden() {
		return componentProductTowerHidden;
	}
	public void setComponentProductTowerHidden(String componentProductTowerHidden) {
		this.componentProductTowerHidden = componentProductTowerHidden;
	}

}
