package com.aig.nge.bo;

import java.util.List;

public class TransactionVersionRsBO {

	   private String transactionVersionNo;	    	    
	   private List<ReserveProductsRsBO> reserveProductRs;
	   private AddProductRsBO addProductResponse;
	   /**
	 * @return the transactionVersionNo
	 */
	public String getTransactionVersionNo() {
		return transactionVersionNo;
	}
	/**
	 * @param transactionVersionNo the transactionVersionNo to set
	 */
	public void setTransactionVersionNo(String transactionVersionNo) {
		this.transactionVersionNo = transactionVersionNo;
	}
	
	/**
	 * @return the reserveProductRs
	 */
	public List<ReserveProductsRsBO> getReserveProductRs() {
		return reserveProductRs;
	}
	/**
	 * @param reserveProductRs the reserveProductRs to set
	 */
	public void setReserveProductRs(List<ReserveProductsRsBO> reserveProductRs) {
		this.reserveProductRs = reserveProductRs;
	}
	/**
	 * @return the addProductResponse
	 */
	public AddProductRsBO getAddProductResponse() {
		return addProductResponse;
	}
	/**
	 * @param addProductResponse the addProductResponse to set
	 */
	public void setAddProductResponse(AddProductRsBO addProductResponse) {
		this.addProductResponse = addProductResponse;
	}	
}
