package com.aig.nge.bo;

import java.io.Serializable;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class AttributeRefereceBOForUpdate implements Serializable{
	private static final long serialVersionUID = 1L;
	private String label;
	private String attrName;
	/*PI3 - Aug release - Add Low goverance attribute in user prefernce starts */
	private String attrId;
	private String name;
	private String type;
	private String defaultDisplayMode;
	private String applicableDisplayModes;
	private String defaultValue;
	private AdditionalAttributeReferenceDataBO dataPopulation;
	private List<EventReferenceDataBO> events;
	private boolean required;
	private String orderSequence;
	private WidgetOptions widgetOptions;
	private String initialState;
	private boolean optional;
	/*PI3 - Aug release - Add Low goverance attribute in user prefernce starts */
	Map<String,String> prefAttrIdName;
	
	public boolean isOptional() {
		return optional;
	}
	public void setOptional(boolean optional) {
		this.optional = optional;
	}
	public String getInitialState() {
		return initialState;
	}
	public void setInitialState(String initialState) {
		this.initialState = initialState;
	}
	public WidgetOptions getWidgetOptions() {
		return widgetOptions;
	}
	public void setWidgetOptions(WidgetOptions widgetOptions) {
		this.widgetOptions = widgetOptions;
	}
	public static Comparator<AttributeRefereceBOForUpdate> attributeRefereceBOForUpdateCompartor 
	= new Comparator<AttributeRefereceBOForUpdate>() {

		public int compare(AttributeRefereceBOForUpdate proTower1, AttributeRefereceBOForUpdate proTower2) {
			//ascending order
			return Integer.valueOf(proTower1.orderSequence)-Integer.valueOf(proTower2.orderSequence);
		}

	};
	
	public String getOrderSequence() {
		return orderSequence;
	}
	public void setOrderSequence(String orderSequence) {
		this.orderSequence = orderSequence;
	}
	public String getAttrName() {
		return attrName;
	}
	public void setAttrName(String attrName) {
		this.attrName = attrName;
	}
	public String getLabel() {
		return label;
	}
	public void setLabel(String label) {
		this.label = label;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getDefaultValue() {
		return defaultValue;
	}
	public void setDefaultValue(String defaultValue) {
		this.defaultValue = defaultValue;
	}
	public AdditionalAttributeReferenceDataBO getDataPopulation() {
		return dataPopulation;
	}
	public void setDataPopulation(AdditionalAttributeReferenceDataBO dataPopulation) {
		this.dataPopulation = dataPopulation;
	}
	public boolean isRequired() {
		return required;
	}
	public void setRequired(boolean required) {
		this.required = required;
	}
	public String getDefaultDisplayMode() {
		return defaultDisplayMode;
	}
	public void setDefaultDisplayMode(String defaultDisplayMode) {
		this.defaultDisplayMode = defaultDisplayMode;
	}
	public String getApplicableDisplayModes() {
		return applicableDisplayModes;
	}
	public void setApplicableDisplayModes(String applicableDisplayModes) {
		this.applicableDisplayModes = applicableDisplayModes;
	}
	public List<EventReferenceDataBO> getEvents() {
		return events;
	}
	public void setEvents(List<EventReferenceDataBO> events) {
		this.events = events;
	}
	public Map<String, String> getPrefAttrIdName() {
		return prefAttrIdName;
	}
	public void setPrefAttrIdName(Map<String, String> prefAttrIdName) {
		this.prefAttrIdName = prefAttrIdName;
	}
	public String getAttrId() {
		return attrId;
	}
	public void setAttrId(String attrId) {
		this.attrId = attrId;
	}
	
	
}
