package com.aig.nge.bo;

public class ProducerContactSessionBO {

	private BrokerBO producerIndividual;

	public BrokerBO getProducerIndividual() {
		return producerIndividual;
	}

	public void setProducerIndividual(BrokerBO producerIndividual) {
		this.producerIndividual = producerIndividual;
	}

	
}
