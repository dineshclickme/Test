package com.aig.nge.bo;

import java.util.List;

public class UpdateProductsDetailRsBO {

	    /**
	 * @return the marketableProduct
	 */
	public List<MarketableProductDetailsRsBO> getMarketableProduct() {
		return marketableProduct;
	}
	/**
	 * @param marketableProduct the marketableProduct to set
	 */
	public void setMarketableProduct(
			List<MarketableProductDetailsRsBO> marketableProduct) {
		this.marketableProduct = marketableProduct;
	}
	/**
	 * @return the componentProduct
	 */
	public List<UpdateComponentProductResBO> getComponentProduct() {
		return componentProduct;
	}
	/**
	 * @param componentProduct the componentProduct to set
	 */
	public void setComponentProduct(
			List<UpdateComponentProductResBO> componentProduct) {
		this.componentProduct = componentProduct;
	}
		private List<MarketableProductDetailsRsBO> marketableProduct;
	    private List<UpdateComponentProductResBO> componentProduct;

}
