package com.aig.nge.bo;

public class ProducerEntitySearchRespBO {
	private String producerEntityNumber;
	private String producerEntityName;
	private String producerAddress;
	private String producerStreetAddress;
	private String producerFaxNo;
	private String producerNPN;
	private String producerTradeName;
	private String producerCountry;
	private String producerCountryCd;
	private String producerBranchId;
	private String producerCategory;
	private String producerRegion;
	private String producerStatus;
	private String producerCiy;
	private String producerPostalCode;
	private String producerStateAbbreviation;
	private String producerPhoneNumber;
	private String producerSourceCd;
	private String error;
	
	/**
	 * @return the producerEntityNumber
	 */
	public String getProducerEntityNumber() {
		return producerEntityNumber;
	}
	/**
	 * @param producerEntityNumber the producerEntityNumber to set
	 */
	public void setProducerEntityNumber(String producerEntityNumber) {
		this.producerEntityNumber = producerEntityNumber;
	}
	/**
	 * @return the producerEntityName
	 */
	public String getProducerEntityName() {
		return producerEntityName;
	}
	/**
	 * @param producerEntityName the producerEntityName to set
	 */
	public void setProducerEntityName(String producerEntityName) {
		this.producerEntityName = producerEntityName;
	}
	/**
	 * @return the producerAddress
	 */
	public String getProducerAddress() {
		return producerAddress;
	}
	/**
	 * @param producerAddress the producerAddress to set
	 */
	public void setProducerAddress(String producerAddress) {
		this.producerAddress = producerAddress;
	}
	public String getProducerStreetAddress() {
		return producerStreetAddress;
	}
	public void setProducerStreetAddress(String producerStreetAddress) {
		this.producerStreetAddress = producerStreetAddress;
	}
	/**
	 * @return the producerNPN
	 */
	public String getProducerNPN() {
		return producerNPN;
	}
	/**
	 * @param producerNPN the producerNPN to set
	 */
	public void setProducerNPN(String producerNPN) {
		this.producerNPN = producerNPN;
	}
	/**
	 * @return the producerTradeName
	 */
	public String getProducerTradeName() {
		return producerTradeName;
	}
	/**
	 * @param producerTradeName the producerTradeName to set
	 */
	public void setProducerTradeName(String producerTradeName) {
		this.producerTradeName = producerTradeName;
	}
	/**
	 * @return the producerCountry
	 */
	public String getProducerCountry() {
		return producerCountry;
	}
	/**
	 * @param producerCountry the producerCountry to set
	 */
	public void setProducerCountry(String producerCountry) {
		this.producerCountry = producerCountry;
	}
	/**
	 * @return the producerCategory
	 */
	public String getProducerCategory() {
		return producerCategory;
	}
	/**
	 * @param producerCategory the producerCategory to set
	 */
	public void setProducerCategory(String producerCategory) {
		this.producerCategory = producerCategory;
	}
	/**
	 * @return the producerRegion
	 */
	public String getProducerRegion() {
		return producerRegion;
	}
	/**
	 * @param producerRegion the producerRegion to set
	 */
	public void setProducerRegion(String producerRegion) {
		this.producerRegion = producerRegion;
	}
	/**
	 * @return the producerStatus
	 */
	public String getProducerStatus() {
		return producerStatus;
	}
	/**
	 * @param producerStatus the producerStatus to set
	 */
	public void setProducerStatus(String producerStatus) {
		this.producerStatus = producerStatus;
	}
	public String getProducerCountryCd() {
		return producerCountryCd;
	}
	public void setProducerCountryCd(String producerCountryCd) {
		this.producerCountryCd = producerCountryCd;
	}
	public String getProducerBranchId() {
		return producerBranchId;
	}
	public void setProducerBranchId(String producerBranchId) {
		this.producerBranchId = producerBranchId;
	}
	/**
	 * @return the producerCiy
	 */
	public String getProducerCiy() {
		return producerCiy;
	}
	/**
	 * @param producerCiy the producerCiy to set
	 */
	public void setProducerCiy(String producerCiy) {
		this.producerCiy = producerCiy;
	}
	/**
	 * @return the producerPostalCode
	 */
	public String getProducerPostalCode() {
		return producerPostalCode;
	}
	/**
	 * @param producerPostalCode the producerPostalCode to set
	 */
	public void setProducerPostalCode(String producerPostalCode) {
		this.producerPostalCode = producerPostalCode;
	}
	/**
	 * @return the producerStateAbbreviation
	 */
	public String getProducerStateAbbreviation() {
		return producerStateAbbreviation;
	}
	/**
	 * @param producerStateAbbreviation the producerStateAbbreviation to set
	 */
	public void setProducerStateAbbreviation(String producerStateAbbreviation) {
		this.producerStateAbbreviation = producerStateAbbreviation;
	}
	/**
	 * @return the producerPhoneNumber
	 */
	public String getProducerPhoneNumber() {
		return producerPhoneNumber;
	}
	/**
	 * @param producerPhoneNumber the producerPhoneNumber to set
	 */
	public void setProducerPhoneNumber(String producerPhoneNumber) {
		this.producerPhoneNumber = producerPhoneNumber;
	}
	/**
	 * @return the producerFaxNo
	 */
	public String getProducerFaxNo() {
		return producerFaxNo;
	}
	/**
	 * @param producerFaxNo the producerFaxNo to set
	 */
	public void setProducerFaxNo(String producerFaxNo) {
		this.producerFaxNo = producerFaxNo;
	}
	/**
	 * @return the producerSourceCd
	 */
	public String getProducerSourceCd() {
		return producerSourceCd;
	}
	/**
	 * @param producerSourceCd the producerSourceCd to set
	 */
	public void setProducerSourceCd(String producerSourceCd) {
		this.producerSourceCd = producerSourceCd;
	}
	/**
	 * @return the error
	 */
	public String getError() {
		return error;
	}
	/**
	 * @param error the error to set
	 */
	public void setError(String error) {
		this.error = error;
	}
}
