package com.aig.nge.bo;

import java.util.List;
import java.util.Map;

public class ExposureGroupBO {
	private String group;
	private String groupcode;
	private List<Map<String,String>> data;
	public String getGroup() {
		return group;
	}
	public void setGroup(String group) {
		this.group = group;
	}
	public String getGroupcode() {
		return groupcode;
	}
	public void setGroupcode(String groupcode) {
		this.groupcode = groupcode;
	}
	public List<Map<String, String>> getData() {
		return data;
	}
	public void setData(List<Map<String, String>> data) {
		this.data = data;
	}
}
