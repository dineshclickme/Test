package com.aig.nge.controller;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.net.MalformedURLException;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.*;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.aig.generalins.configserverclient.ConfigServerProperties;
import com.aig.nge.utilities.*;
import com.fasterxml.jackson.databind.annotation.JsonAppend;
import com.us.chartisinsurance.producervalidationservicev3.ChartisInsuranceUSExceptionMsg;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
//import org.springframework.security.saml.SAMLCredential;
import org.opensaml.saml2.core.Attribute;
import org.opensaml.xml.util.XMLHelper;
//import org.springframework.security.saml.util.SAMLUtil;
import org.springframework.security.saml.SAMLCredential;
import org.springframework.security.web.csrf.CsrfToken;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import CASLExtComplexDataType.UserActionType;
import CASLExtComplexDataType.UserAppEntitlementCountryLOBType;
import CASLExtComplexDataType.UserDataCategoryType;
import CASLExtComplexDataType.UserRoleType;
import CASLExtUserEntitlement.EntitlementsByCountryLOBRespType;

import com.aig.casl.services.access.ServiceAccess;
import com.aig.casl.services.access.ServiceAccessException;
import com.aig.nge.accountservice.AccountServiceExceptionMsg;
import com.aig.nge.bo.*;
import com.aig.nge.handler.ManageProductsServiceHandler;
import com.aig.nge.handler.ManageTransactionServiceHandler;
import com.aig.nge.helper.AddAdditionalAttributesHelper;
import com.aig.nge.helper.AddTransactionHelper;
import com.aig.nge.helper.AlertServiceHelper;
import com.aig.nge.helper.PolicySearchHelper;
import com.aig.nge.helper.UnderwriterSearchHelper;
import com.aig.nge.helper.UserPrefHelper;
import com.aig.nge.service.AccountService;
import com.aig.nge.service.DataCacheObject;
import com.aig.nge.service.NGPLSService;
import com.aig.nge.service.ProducerService;
import com.aig.nge.service.SubmissionDataService;
import com.aig.nge.service.SubmissionManagementService;
import com.aig.nge.service.TransactionManagementService;
import com.aig.nge.utilities.AIGCIExceptionMsg;
import com.aig.nge.utilities.NGECommonUtil;
import com.aig.nge.utilities.NGEConstants;
import com.aig.nge.utilities.NGEConstants.ExpCntryType;
import com.aig.nge.utilities.NGEConstants.LifeCycleStatusID;
import com.aig.nge.utilities.NGEConstants.LifeCycleUpdateAction;
import com.aig.nge.utilities.NGEConstants.ReferenceGroup;
import com.aig.nge.utilities.NGEConstants.ServiceURL;
import com.aig.nge.utilities.NGEConstants.TableId;
import com.aig.nge.utilities.NGEDateUtil;
import com.aig.nge.utilities.NGEErrorCodes;
import com.aig.nge.utilities.NGEProperties;
import com.aig.nge.utilities.SequenceNumberGeneration;
import com.aig.nge.utilities.ServiceUtility;
import com.aig.nge.utilities.XSSValidator;
import com.aig.ngeservicecomplextypesv1.SubmissionRs;
import com.aig.submissiondataservicev2.Submissions;
import com.aig.submissiondataservicev2.binding.CreateSubmissionAIGCIExceptionTypeMsg;
import com.aig.submissiondataservicev2.binding.CreateTransactionAIGCIExceptionTypeMsg;
import com.aig.submissiondataservicev2.binding.CreateTransactionVersionAIGCIExceptionTypeMsg;
import com.aig.submissiondataservicev2.binding.GetBlockedInfoAIGCIExceptionTypeMsg;
import com.aig.submissiondataservicev2.binding.GetBlockingInfoAIGCIExceptionTypeMsg;
import com.aig.submissiondataservicev2.binding.GetSubmissionAIGCIExceptionTypeMsg;
import com.aig.submissiondataservicev2.binding.GetUnderwriterDiaryAIGCIExceptionTypeMsg;
import com.aig.submissiondataservicev2.binding.SearchSubmissionsAIGCIExceptionTypeMsg;
import com.aig.submissionmanagementservicev2.binding.BulkTransferAIGCIExceptionTypeMsg;
import com.aig.submissionmanagementservicev2.binding.CopyTransactionAIGCIExceptionTypeMsg;
import com.aig.submissionmanagementservicev2.binding.ManageProductsAIGCIExceptionTypeMsg;
import com.aig.submissionmanagementservicev2.binding.RenewTransactionAIGCIExceptionTypeMsg;
import com.aig.submissionmanagementservicev2.binding.ReserveProductAIGCIExceptionTypeMsg;
import com.aig.submissionmanagementservicev2.binding.UpdateTransactionAIGCIExceptionTypeMsg;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectReader;
import com.fasterxml.jackson.databind.ObjectWriter;
//import com.ibm.ws.security.core.AccessException;
import com.us.chartisinsurance.producervalidationservicev3.ChartisInsuranceUSExceptionMsg;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.view.RedirectView;
import org.springframework.web.util.UriComponentsBuilder;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;
import java.util.Arrays;
import org.springframework.web.client.RestTemplate;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
//import com.aig.accountservicev1.AIGCIExceptionMsg;

@Controller
public class MainController {
    //TCS CE Team Changes Starts Here
    private static final Logger logger = LogManager.getLogger(MainController.class);
    //TCS CE Team Changes Ends Here
    //private static final long serialVersionUID = 1L;
    private static ServiceAccess caslServiceAccess = null;
    private static String regionVariable = null;
    private static HashMap securityByPassRegions = new HashMap();
    private static HashMap csrfByPassRegions = new HashMap();
    //private static String siteMinderUserIdHeader = null;
    private static String caslServiceURL = null;
    private RestTemplate restTemplate;

    MainController() {
    }
    //TCS CE Team Changes Starts Here
    @RequestMapping(value = "/login", method = RequestMethod.GET)
    //TCS CE Team Changes Ends Here
    public String applicationlaunch(HttpServletRequest request,
                                    HttpServletResponse response) throws ServletException,
            ServiceAccessException, Exception {

        logger.info("in context servlet call");
        HttpSession session = null;
        logger.info("Entering into the MainController by Get Type");
        String defaultpage = "";
        String requestUserID = "";
        try {
            session = request.getSession(false);
            if (null != session) {
                logger.info("Nullify any session available existing");
                session.setMaxInactiveInterval(0);
                session.invalidate();
            }
            session = request.getSession(true);
            session.setMaxInactiveInterval(Integer.parseInt(NGEConstants.MAX_SESSION_ACTIVE_TIME));
            logger.info("Session set for " + NGEConstants.MAX_SESSION_ACTIVE_TIME + " seconds");
            /* 2020 - Okta migration changes -Start */

            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        if(null != authentication){

        	SAMLCredential credential = (SAMLCredential) authentication.getCredentials();
        	if(null != credential)
        	{
	        	requestUserID = credential.getNameID().getValue();
	        	//requestUserID="";
	        	logger.info("Okta Authentication completed");
	        	logger.info("Okta provided UserId="+ credential.getNameID().getValue());
	        	logger.info("Okta provided Principal value="+ authentication.getPrincipal().toString());

	        	if(null != credential.getAttributes())
			     {
			        for(int i=0; i<credential.getAttributes().size(); i++)
			        {
			        	String[] attributeValues = credential.getAttributeAsStringArray(credential.getAttributes().get(i).getName());
			        	for(String attribute : attributeValues ){
			        		logger.info("Okta provided Attributes->"+ 	attribute);
			        	}

			        }
			      }
            }
        }

		/*Enumeration<String> headerNames = request.getHeaderNames();

		while (headerNames.hasMoreElements()) {
			 String headerName = headerNames.nextElement();
			 logger.info("headerName="+headerName);
			 Enumeration<String> headers = request.getHeaders(headerName);
			 while (headers.hasMoreElements()) {
				 String headerValue = headers.nextElement();
				 logger.info("headerValue="+headerValue);
				 if (headerName.equalsIgnoreCase("SMUSER")){
					 requestUserID = headerValue;
					 logger.info("Okta provided userid "+ requestUserID);
				 }
			 }

		}*/

            /* 2020 - Okta migration changes -ends */

            if (requestUserID.equals("")) {
                logger.info("Setting User ID Manually if context root failed to get the User ID Starts");
//                requestUserID = "1456546";
//                requestUserID = "1439097";
                requestUserID = "9000237";

                logger.info("Setting User ID Manually if context root failed to get the User ID Ends");
                logger.info("Manually setted User ID : " + requestUserID);
            }
            CASLAuthorizeBO userData = CASLauthorize(request, requestUserID);
            String sessionusername = "";
            sessionusername = userData.getLastName() + ", " + userData.getFirstName();
            sessionusername = toDisplayCase(sessionusername);
            userData.setUserName(sessionusername);

		/*  2020 - JAR upgrade issue fixed
		 * if(System.getProperty(NGEConstants.REGION).equalsIgnoreCase("desktop")
				||System.getProperty(NGEConstants.REGION).equalsIgnoreCase("INTEG")){
			userData.setIscaslfailure("NO");
		}*/
            if (!(userData.getIscaslfailure().equalsIgnoreCase("YES"))) {
                response.setHeader("_csrf", "12345"); // initial Token
                response.setHeader("_csrf_header", "CSRF_Token");
                session.setAttribute("sescsrftoken", "12345");
                session.setAttribute("sessionTokenHeader", "CSRF_Token");
                session.setAttribute("SME_User", sessionusername);
                session.setAttribute("caslUserName", sessionusername);


                ObjectWriter ow = new ObjectMapper().writer()
                        .withDefaultPrettyPrinter();
                ObjectReader objectReader = new ObjectMapper().reader(UserPrefBO.class);

                try {
                    UserPrefHelper userPrefHelper = new UserPrefHelper();
                    UserPrefBO userprefBO = userPrefHelper.getUserPreferenceData(requestUserID);
                    UserPrefBO dbUserprefBO = new UserPrefBO();
                    dbUserprefBO = (UserPrefBO) objectReader.readValue(XSSValidator.stripXSS(ow.writeValueAsString(userprefBO)));
                    session.setAttribute(NGEConstants.SESSION_USER_PREF_DETAIL, userprefBO);
                    session.setAttribute(NGEConstants.DB_SESSION_USER_PREF_DETAIL, dbUserprefBO);
                    session.setAttribute(NGEConstants.SESSION_USER_PREFERENCE_DETAIL, XSSValidator.stripXSS(ow.writeValueAsString(userprefBO)));


                    UnderwriterSearchReqBO underwriterSearchReqBO = new UnderwriterSearchReqBO();
                    underwriterSearchReqBO.setPartyNo(requestUserID);
                    underwriterSearchReqBO.setIncludeSuspend(NGEConstants.YES);
				/*List<UnderwriterSearchResBO> underwritersList = new ArrayList<UnderwriterSearchResBO>();
				underwritersList=underwriterSearchHelper.searchUnderwriterHelper(underwriterSearchReqBO);
				headerjson="";
				if(underwritersList!=null && underwritersList.size()>0){
					headerjson = ow.writeValueAsString(underwritersList.get(0));
				}
				session.setAttribute(NGEConstants.SESSION_LOGIN_UW_DETAIL,headerjson);*/
                    session.setAttribute(NGEConstants.SESSION_LOGIN_UW_DETAIL, null);

                    String headerjson = "";
                    headerjson = ow.writeValueAsString(userData);
                    session.setAttribute("caslUserAcessDetails", XSSValidator.stripXSS(headerjson));
                    session.setAttribute("caslUserAcessDetailsBO", userData);
                    session.setAttribute(NGEConstants.SESSION_CASL_USERID, XSSValidator.stripXSS(requestUserID));
                    String languageData = "en-US";
                    session.setAttribute("USER_LANG", XSSValidator.stripXSS(languageData));

                    session.setAttribute("caslUserRole", XSSValidator.stripXSS(userData.getUserRole()));

                    String currentDate = new SimpleDateFormat("yyyyMMdd").format(new Date());
                    session.setAttribute("currentDate", XSSValidator.stripXSS(currentDate));
                    String fileContextPath = "";
                    //TCS CE Team Changes Starts Here
                    ConfigProvider configProvider = new ConfigProvider();
                    Properties properties = configProvider.getProperties();
                    if ((NGEConstants.REGION).equalsIgnoreCase("desktop")) {
                        fileContextPath = "/ngestart";
                    }
                    //TCS CE Team Changes Ends Here
                    session.setAttribute("fileContextPath", XSSValidator.stripXSS(fileContextPath));
                } catch (JsonProcessingException e) {
                    logger.info("NGEUIException", e);
                }
                //logger.info("The Session object is : " + session);


                defaultpage = NGEConstants.APPLICATION_CONTEXT_URL;
            } else {
                defaultpage = NGEConstants.NON_AUTHORIZE_APPLICATION_CONTEXT_URL;
            }
        } catch (IllegalStateException e) {
            logger.info("In Session Nullify Exception");
        }

        return defaultpage;
    }

    /**
     * @throws ServletException
     * @throws ServiceAccessException
     */
    @RequestMapping(value = "/caslAuthorize", method = RequestMethod.GET)
    public String start(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, ServiceAccessException, Exception {
        logger.info("inside casl Authorization");
        RedirectView redirectView = new RedirectView();
        NGEProperties ngeProperties = new NGEProperties();
        HttpSession session = null;
        try {

           caslServiceURL = ngeProperties.readMessageFromFile(
                    NGEConstants.CASL_SERVICE_URL,
                    NGEConstants.CONFIG_FILE_NAME, true);
           /* caslServiceURL = "https://caslsvc-qa.aig.net:15021/CASLServicesWeb/services/CASLExtConsumingServicesPort";*/

            logger.info("CASL interface URL is : " + caslServiceURL);
            caslServiceAccess = new ServiceAccess(caslServiceURL);

            String byPassRegions = ngeProperties.readMessageFromFile(
                    NGEConstants.SECURITY_BYPASS_REGIONS,
                    NGEConstants.CONFIG_FILE_NAME, true);
            regionVariable = ngeProperties.readMessageFromFile(
                    NGEConstants.REGION_VARIABLE,
                    NGEConstants.CONFIG_FILE_NAME, true);
            String siteminder = ngeProperties.readMessageFromFile(
                    NGEConstants.REGION_VARIABLE,
                    NGEConstants.CONFIG_FILE_NAME, true);

            if (securityByPassRegions.size() == 0 && byPassRegions != null
                    && !byPassRegions.equals("")) {
                synchronized (securityByPassRegions) {
                    StringTokenizer strTok = new StringTokenizer(byPassRegions,
                            ",");
                    while (strTok.hasMoreTokens()) {
                        String myRegion = strTok.nextToken();
                        securityByPassRegions.put(myRegion, myRegion);

                    }
                }
            }
			/*if (!securityByPassRegions.containsKey((regionVariable))) {
				siteMinderUserIdHeader = siteminder;
				if (siteMinderUserIdHeader == null) {
					String errorStr = "userid.header parameter is missing in the envrionment!!!\nuserid.header is defaulted to smuser !!!";
					logger.error("Error Message ::" + errorStr);
					siteMinderUserIdHeader = "smuser";
				}
			}*/

        } catch (Exception ex) {
            logger.error("Exception in getting environmental variables"
                    + ex.toString());
        }

        logger.info("Enterting into the Action Controller by Get Type");
        session = request.getSession(true);
        response.setHeader("_csrf", "12345"); // initial Token
        response.setHeader("_csrf_header", "CSRF_Token");
        session.setAttribute("sescsrftoken", "12345");
        session.setAttribute("sessionTokenHeader", "CSRF_Token");
        session.setAttribute("SME_User", "SME_USER_ID");
        redirectView.setUrl("http://localhost:8080/NGeStart/jsp/index.jsp");
        // //Needs to set the home URL dynamically respective to the region
        return NGEConstants.APPLICATION_CONTEXT_URL;
    }

    /**
     * @param request
     * @param response
     * @throws ServletException
     * @throws ServiceAccessException
     */
    @RequestMapping(value = "/test", method = RequestMethod.GET)
    public String applicationlaunch1(HttpServletRequest request,
                                     HttpServletResponse response) throws ServletException,
            ServiceAccessException, Exception {
        AddTransactionHelper addTransaction = new AddTransactionHelper();
        addTransaction.getBranchMappingHelper();
        return null;
    }

    @SuppressWarnings("unchecked")
    @RequestMapping(value = "/createsubmission", headers = "Accept=application/json", method = RequestMethod.POST)
    public @ResponseBody
    JSONHeaderBO createSubmission(@RequestBody SubmissionBO submission,
                                  HttpServletRequest request, HttpServletResponse response) throws IOException {
        JSONHeaderBO jsonheader = new JSONHeaderBO();
        ProducerService producerObject = new ProducerService();
        HttpSession session = null;
        session = request.getSession(false);
        if (session == null || (session.getAttribute(NGEConstants.SESSION_CASL_USERID) == null)) {
            //logger.info("Invalid Session : "+session);
            response.sendRedirect("jsp/logout.jsp");
            return jsonheader;
        }
		/*else{
			logger.info("session : "+session);
		}*/
        try {

            if (null != session.getAttribute(NGEConstants.TRANSACTION_ADDRESS)) {
                session.removeAttribute(NGEConstants.TRANSACTION_ADDRESS);
            }
            if (null != session.getAttribute(NGEConstants.SESSION_TRANSACTION_ADDRESS_DETAIL)) {
                session.removeAttribute(NGEConstants.SESSION_TRANSACTION_ADDRESS_DETAIL);
            }
            if (null != session.getAttribute(NGEConstants.TRANSACTION_ADDITIONAL_ACC_INSURED_LIST)) {
                session.removeAttribute(NGEConstants.TRANSACTION_ADDITIONAL_ACC_INSURED_LIST);
            }
            if (null != session.getAttribute(NGEConstants.TRANSACTION_ADDITIONAL_ACC_PRODUCER_LIST)) {
                session.removeAttribute(NGEConstants.TRANSACTION_ADDITIONAL_ACC_PRODUCER_LIST);
            }
            if (null != session.getAttribute(NGEConstants.TRANSACTION_PRODUCER_CONTACT_DETAIL)) {
                session.removeAttribute(NGEConstants.TRANSACTION_PRODUCER_CONTACT_DETAIL);
            }
            if (null != session.getAttribute(NGEConstants.SESSION_TRANSACTION_PRODUCER_CONTACT_DETAIL)) {
                session.removeAttribute(NGEConstants.SESSION_TRANSACTION_PRODUCER_CONTACT_DETAIL);
            }
            if (null != session.getAttribute(NGEConstants.SESSION_TRANSACTION_ADDITIONAL_PRODUCER_DETAIL)) {
                session.removeAttribute(NGEConstants.SESSION_TRANSACTION_ADDITIONAL_PRODUCER_DETAIL);
            }
            if (null != session.getAttribute(NGEConstants.PRODUCT_POLICY_DETAIL)) {
                session.removeAttribute(NGEConstants.PRODUCT_POLICY_DETAIL);
            }
            if (null != session.getAttribute(NGEConstants.SESSION_POLICY_DETAIL)) {
                session.removeAttribute(NGEConstants.SESSION_POLICY_DETAIL);
            }
            if (null != session.getAttribute(NGEConstants.PRODUCT_ASSET_DETAIL)) {
                session.removeAttribute(NGEConstants.PRODUCT_ASSET_DETAIL);
            }
            if (null != session.getAttribute(NGEConstants.SESSION_TRANSACTION_ASSET_DETAIL)) {
                session.removeAttribute(NGEConstants.SESSION_TRANSACTION_ASSET_DETAIL);
            }

            if (null != session.getAttribute(NGEConstants.EXPOSURE_COUNTRY_DATA)) {
                session.removeAttribute(NGEConstants.EXPOSURE_COUNTRY_DATA);
            }
            if (null != session.getAttribute(NGEConstants.EXPOSURE_COUNTRY_DETAIL)) {
                session.removeAttribute(NGEConstants.EXPOSURE_COUNTRY_DETAIL);
            }

            if (null != session.getAttribute(NGEConstants.SESSION_TRANSACTION_ADDITIONAL_INSURED_DETAIL)) {
                session.removeAttribute(NGEConstants.SESSION_TRANSACTION_ADDITIONAL_INSURED_DETAIL);
            }
            if (null != session.getAttribute(NGEConstants.SESSION_ADDITIONAL_INSURED_PRODUCT_LEVEL_DETAIL)) {
                session.removeAttribute(NGEConstants.SESSION_ADDITIONAL_INSURED_PRODUCT_LEVEL_DETAIL);
            }
            if (null != session.getAttribute(NGEConstants.TRANSACTION_ADDITIONAL_ACC_INSURED_LIST)) {
                session.removeAttribute(NGEConstants.TRANSACTION_ADDITIONAL_ACC_INSURED_LIST);
            }
            if (null != session.getAttribute(NGEConstants.ADDITIONAL_INSURED_LIST_PRODUCT_LEVEL)) {
                session.removeAttribute(NGEConstants.ADDITIONAL_INSURED_LIST_PRODUCT_LEVEL);
            }

            boolean tokenerror = false;
            boolean paramerror = false;
            // tokenerror = tokenVerification(request); //Commented to test in
            // local
            // paramerror = paramVerification(request); //Commented to test in
            // local
            tokenerror = false;
            paramerror = false;
            if (!tokenerror && !paramerror) {
                ExceptionBO exceptionBO = null;
                SequenceNumberGeneration generateObj = new SequenceNumberGeneration();
                HashMap<String, String> sequenceNames = new HashMap<>();
                HashMap<String, Object> sequenceValueMap = new HashMap<String, Object>();
                sequenceNames.put("CREATE_SUBMISSION", "INT");
                sequenceValueMap = generateObj
                        .getNextSequenceNumber(sequenceNames);
                int sequenceNo = Integer.parseInt(sequenceValueMap.get(
                        "CREATE_SUBMISSION").toString());
                CreateSubmissionBO responseObj = new CreateSubmissionBO();
                Submission resp = new Submission();
                String accountNo = null;
                String accountNme = null;
                String producerNo = null;
                String producerName = null;
                String producerCountryCd = null;
                String producerBranchNo = null;
                String creditedCountryCd = null;
                String creditedBranchCd = null;
                String sourceCd = null;
                //MDM Party ID adding in Create Submission Request -  2021 MDM Changes - Start
                String mdmPartyId = null;
                //MDM Party ID adding in Create Submission Request - 2021 MDM Changes - End
                DataCacheObject cacheObject = new DataCacheObject();
                Map<String, String> countryCodeMap = new HashMap<>();
                Map<String, String> branchCodeMap = new HashMap<>();
                if (submission == null)
                    logger.info("createSubmission : " + sequenceNo
                            + " Error : " + "Request Object is Empty");
                else {
                    accountNo = submission.getAccountName().getFooter();
                    if (null != accountNo) {
                        accountNo = accountNo.trim();
                    }
                    accountNme = submission.getAccountName().getValue();
                    producerNo = submission.getInitiatingProducerNo().getFooter();
                    producerName = submission.getInitiatingProducerNo().getValue();
                    //MDM Party ID adding in Create Submission Request - 2021 MDM Changes - Start
                    mdmPartyId = submission.getMdmpartyIdHidden();
                    //MDM Party ID adding in Create Submission Request - 2021 MDM Changes - End
                    //medium low issue fixes-2020 starts
//					if(submission.getProducerCountryCd() != null && submission.getProducerCountryCd().trim() != ""
//							&& submission.getProducerBranchId() != null && submission.getProducerBranchId().trim() != ""
//							&& submission.getSourceCd() != null && submission.getSourceCd().trim() != ""){
                    if (submission.getProducerCountryCd() != null && !submission.getProducerCountryCd().trim().equals("")
                            && submission.getProducerBranchId() != null && !submission.getProducerBranchId().trim().equals("")
                            && submission.getSourceCd() != null && !submission.getSourceCd().trim().equals("")) {
                        //medium low issue fixes-2020 ends
                        producerCountryCd = submission.getProducerCountryCd();
                        producerBranchNo = submission.getProducerBranchId();
                        sourceCd = submission.getSourceCd();
                    } else {
                        producerObject.setCaslServiceId((String) session.getAttribute(NGEConstants.SESSION_CASL_USERID));
                        ProducerEntitySearchRespBO producerDetail = producerObject.validateProducer(producerNo);
                        producerCountryCd = producerDetail.getProducerCountryCd();
                        producerBranchNo = producerDetail.getProducerBranchId();
                        sourceCd = producerDetail.getProducerSourceCd();
                    }
                    countryCodeMap = (Map<String, String>) cacheObject.getDynacacheObj("COUNRTY_CD_BY_ALTERNATE");
                    branchCodeMap = (Map<String, String>) cacheObject.getDynacacheObj("BRANCH_ID_TO_CD");
                    creditedCountryCd = countryCodeMap.get(producerCountryCd);
                    creditedBranchCd = branchCodeMap.get(sourceCd + "~" + producerBranchNo);
                }
                SubmissionDataService serviceObj = new SubmissionDataService();
                serviceObj.setCaslServiceId((String) session.getAttribute(NGEConstants.SESSION_CASL_USERID));
				/*long accountNum = Long.parseLong(accNo);
				String accountNm = accNo;
				String producerNum = producerNo;
				String producerNm = producerName;
				long submissionNo = 0;*/
                String i18SuccessMessage = null;
                try {
                    //long accountNum = Long.parseLong(accountNo);
                    String accountNum = accountNo;
                    String accountNm = accountNme;
                    String producerNum = producerNo;
                    String producerNm = producerName;
                    String creditedCountryCode = creditedCountryCd;
                    String creditedBranchCode = creditedBranchCd;
                    long submissionNo = 0;
                    //MDM Party ID adding in Create Submission Request - 2021 MDM Changes - Start
					/*submissionNo = serviceObj.createSubmission(accountNum,
					producerNum);*/
                    String mdmpartyId = mdmPartyId;
                    submissionNo = serviceObj.createSubmission(accountNum,
                            producerNum, mdmpartyId);
                    //MDM Party ID adding in Create Submission Request - 2021 MDM Changes - End
                    SubmissionBO submissions = new SubmissionBO();
                    TransactionProducerBO transactions = new TransactionProducerBO();
                    ValueFooterBO accountName = new ValueFooterBO();
                    accountName.setFooter(accountNum);
                    accountName.setValue(accountNm);
                    /* 2021 MDM Changes - Starts */
                    accountName.setFooterAdtn(mdmpartyId);
                    /* 2021 MDM Changes - Ends */
                    submissions.setAccountName(accountName);
                    ValueFooterBO initiatingProducerNo = new ValueFooterBO();
                    initiatingProducerNo.setFooter(producerNum);
                    initiatingProducerNo.setValue(producerNm);
                    submissions.setAccountNumberHidden(accountNum);
                    submissions.setInitiatingProducerNo(initiatingProducerNo);
                    //MDM Party ID adding in Create Submission Request - 2021 MDM Changes - Start
                    submissions.setMdmpartyIdHidden(mdmpartyId);
                    //MDM Party ID adding in Create Submission Request - 2021 MDM Changes - End
                    submissions.setSubmissionNo(Long.toString(submissionNo));
                    if (submission != null)
                        submissions.setCountryName(submission.getCountryName());
                    //ProducerDetail producerDetail=producerObject.validateProducer(producerNum);
                    ProducerEntitySearchRespBO producerDetail = producerObject.validateProducer(producerNum);
                    if (producerDetail != null && producerDetail.getProducerSourceCd() != null) {
                        submissions.setSourceCd(producerDetail.getProducerSourceCd());
                    }
                    submissions.setSourceCd(sourceCd);
                    ValueFooterBO producerEntity = new ValueFooterBO();
                    producerEntity.setFooter(producerNum);
                    producerEntity.setValue(producerNm);
                    transactions.setProducerEntity(producerEntity);
                    transactions.setProducernumberHidden(producerNum);
                    transactions.setCreditedBranchHidden("9999");
                    transactions.setCreditedBranch(creditedCountryCode);
                    transactions.setCreditedCountryBranch(creditedBranchCode);
                    resp.setSubmission(submissions);
                    resp.setTransaction(transactions);
                    i18SuccessMessage = seti18ErroMessage(NGEConstants.SUBMISSION_SUCCESSFUL);
                } catch (MalformedURLException e) {
                    exceptionBO = new ExceptionBO();
                    exceptionBO.setErrorFrom(NGEConstants.CREATE_SUBMISSION_SERVICE);
                    logger.info("NGEUIException", e);
                    exceptionBO
                            .setErrorMessage(seti18ErroMessage(NGEConstants.MALFORMED_URL));
                    exceptionBO.setErrorCode(NGEConstants.FAILURE_CODE);
                    exceptionBO.setErrorType(NGEConstants.FATAL);
                } catch (CreateSubmissionAIGCIExceptionTypeMsg e) {
                    exceptionBO = new ExceptionBO();
                    exceptionBO.setErrorFrom(NGEConstants.CREATE_SUBMISSION_SERVICE);
                    exceptionBO.setErrorMessage(seti18ErroMessage(e
                            .getFaultInfo().getErrorCode()));
                    exceptionBO.setErrorCode(NGEConstants.FAILURE_CODE);
                    exceptionBO.setErrorType(e.getFaultInfo().getErrorType());
                    logger.info("NGEUIException", e);
                } catch (NumberFormatException e) {
                    exceptionBO = new ExceptionBO();
                    exceptionBO.setErrorFrom(NGEConstants.CREATE_SUBMISSION_SERVICE);
                    exceptionBO.setErrorMessage(seti18ErroMessage(NGEConstants.INVALID_ACCOUNT_NUMBER_FORMAT));
                    exceptionBO.setErrorCode(NGEConstants.FAILURE_CODE);
                    exceptionBO.setErrorType(NGEConstants.FATAL);
                    logger.info("NGEUIException", e);
                } catch (Exception e) {
                    exceptionBO = new ExceptionBO();
                    exceptionBO.setErrorFrom(NGEConstants.CREATE_SUBMISSION_SERVICE);
                    exceptionBO
                            .setErrorMessage(seti18ErroMessage(NGEConstants.ERROR_INVOKING_SERVICE));
                    exceptionBO.setErrorCode(NGEConstants.FAILURE_CODE);
                    exceptionBO.setErrorType(NGEConstants.FATAL);
                    logger.info("NGEUIException", e);
                }
                if (null == exceptionBO) {
                    jsonheader = setJsonHeader(sequenceNo,
                            NGEConstants.SUCCESS_CODE, NGEConstants.SUCCESS,
                            i18SuccessMessage, resp);
                } else {
                    jsonheader = setJsonHeader(sequenceNo,
                            exceptionBO.getErrorType(), NGEConstants.FAILURE,
                            exceptionBO.getErrorMessage(), resp);
                }
                String headerjson = "";
                ObjectWriter ow = new ObjectMapper().writer()
                        .withDefaultPrettyPrinter();
                try {
                    headerjson = ow.writeValueAsString(jsonheader);
                } catch (JsonProcessingException e) {
                    // TODO Auto-generated catch block
                    logger.info("NGEUIException", e);
                }
                responseObj.setSubmission(resp.getSubmission());

                session.setAttribute(NGEConstants.CREATE_SUBMISSION_RESPONSE, XSSValidator.stripXSS(headerjson));
                if (null != resp.getSubmission()
                        && null != resp.getSubmission().getSubmissionNo()) {
                    //System.out.println("sub"+resp.getSubmission().getSubmissionNo());
                    session.setAttribute(NGEConstants.SUBMISSION_NO, XSSValidator.stripXSS(resp.getSubmission().getSubmissionNo()));
                }
            } else {
                // TODO Needs to add the failure URL for CSRF Validation
            }
        } catch (Exception e) {
            logger.info("NGEUIException", e);
        }
        return jsonheader;
    }

    @RequestMapping(value = "/searchsubmission", headers = "Accept=application/json", method = RequestMethod.POST)
    public @ResponseBody
    JSONHeaderBO searchSubmission(@RequestBody SearchSubBO searchSubBO, HttpServletRequest request, HttpServletResponse response) throws IOException {
        IConfigProvider configProvider = new ConfigProvider();
        Properties properties = configProvider.getProperties("");
        JSONHeaderBO jsonHeaderBO = new JSONHeaderBO();
        HttpSession session = null;
        session = request.getSession(false);
        if (session == null || (session.getAttribute(NGEConstants.SESSION_CASL_USERID) == null)) {
            response.sendRedirect("jsp/logout.jsp");
            return jsonHeaderBO;
        }
		/*else{
			logger.info("session : "+session);
		}*/
        ExceptionBO exceptionBO = null;

        SequenceNumberGeneration generateObj = new SequenceNumberGeneration();
        HashMap<String, String> sequenceNames = new HashMap<>();
        HashMap<String, Object> sequenceValueMap = new HashMap<String, Object>();
        sequenceNames.put("SEARCH_SUBMISSION", "INT");
        sequenceValueMap = generateObj.getNextSequenceNumber(sequenceNames);
        int sequenceNo = Integer.parseInt(sequenceValueMap.get(
                "SEARCH_SUBMISSION").toString());
        SearchSubmissionRows subRows = new SearchSubmissionRows();
        String i18SuccessMessage = null;
        List<SubmissionRsSearchSubmissionsBO> submissionsearschlist = new ArrayList<SubmissionRsSearchSubmissionsBO>();
        List<Submissions> submissionList = null;
        UserPrefBO dbUserprefBO = (UserPrefBO) session.getAttribute(NGEConstants.DB_SESSION_USER_PREF_DETAIL);
        if (null != searchSubBO && null != searchSubBO.getSearchValue()
                && searchSubBO.getSearchValue().length() > 0
                && !searchSubBO.getSearchValue().equals("")) {
            SubmissionDataService serviceObj = new SubmissionDataService();
            try {
                serviceObj.setCaslServiceId((String) session.getAttribute(NGEConstants.SESSION_CASL_USERID));
                submissionList = serviceObj
                        .searchSubmission(searchSubBO.getSearchby(),
                                searchSubBO.getSearchValue());
                if (submissionList != null) {
                    for (Submissions submission : submissionList) {
                        SubmissionRsSearchSubmissionsBO submissionRsSearchSubmissionsBO = new SubmissionRsSearchSubmissionsBO();
                        submissionRsSearchSubmissionsBO.setAccountNm(submission.getSubmission().getAccountNm());
                        submissionRsSearchSubmissionsBO.setAccountNo(String.valueOf(submission.getSubmission().getAccountNo()));
                        /* 2021 MDM Changes - Starts */
                        submissionRsSearchSubmissionsBO.setMdmPartyId(submission.getSubmission().getMDMPartyId());
                        /* 2021 MDM Changes - Ends */
                        if (dbUserprefBO != null && dbUserprefBO.getDateFormat() != null && dbUserprefBO.getDateFormat().length() > 0) {
                            String dateFormat = "";
                            if (dbUserprefBO.getDateFormat().equals("mm/dd/yy")) {
                                dateFormat = "MM/dd/yyyy";
                            } else if (dbUserprefBO.getDateFormat().equals("dd/mm/yy")) {
                                dateFormat = "dd/MM/yyyy";
                            } else if (dbUserprefBO.getDateFormat().equals("yy/mm/dd")) {
                                dateFormat = "yyyy/MM/dd";
                            }
                            submissionRsSearchSubmissionsBO.setCreationTs(NGEDateUtil.convertDateToString_ByFormat(NGEDateUtil.convertStringtoDate_MMddyyyy(submission.getSubmission().getCreationTs()), dateFormat));
                        } else {
                            submissionRsSearchSubmissionsBO.setCreationTs(NGEDateUtil.convertDateToString_MMddyyyy(NGEDateUtil.convertStringtoDate_MMddyyyy(submission.getSubmission().getCreationTs())));
                        }
                        submissionRsSearchSubmissionsBO.setProducerNm(submission.getSubmission().getProducerNm());
                        submissionRsSearchSubmissionsBO.setSubmissionNo(String.valueOf(submission.getSubmission().getSubmissionNo()));
                        submissionsearschlist.add(submissionRsSearchSubmissionsBO);
                    }
                }
                NGEProperties ngeProperties = new NGEProperties();
                subRows.setSubmissionSearchByAccMaxResult(ngeProperties.readMessageFromFile(NGEConstants.SUB_SEARCH_BY_ACC_MAX_RESULT, NGEConstants.MESSAGE_FILE_NAME, true));

                subRows.setRows(submissionsearschlist);
                i18SuccessMessage = seti18ErroMessage(NGEConstants.SUBMISSION_SEARCH_SUCCESSFUL);
            } catch (SearchSubmissionsAIGCIExceptionTypeMsg e) {
                if (!e.getFaultInfo().getErrorCode().equalsIgnoreCase("ERR00032") && !e.getFaultInfo().getErrorCode().equalsIgnoreCase("ERR70003")
                        && !e.getFaultInfo().getErrorCode().equalsIgnoreCase("ERR00042") && !e.getFaultInfo().getErrorCode().equalsIgnoreCase("ERR00007")
                        && !e.getFaultInfo().getErrorCode().equalsIgnoreCase("ERR00001") && !e.getFaultInfo().getErrorCode().equalsIgnoreCase("ERR70004")
                        && !e.getFaultInfo().getErrorCode().equalsIgnoreCase("ERR90212")) { //MDM Changes to handle invalid MDM ID
                    exceptionBO = new ExceptionBO();
                    exceptionBO.setErrorFrom(NGEConstants.SEARCH_SUBMISSION_SERVICE);
                    exceptionBO.setErrorMessage(seti18ErroMessage(e.getFaultInfo()
                            .getErrorCode()));
                    exceptionBO.setErrorCode(NGEConstants.FAILURE_CODE);
                    exceptionBO.setErrorType(e.getFaultInfo().getErrorType());
                    subRows.setRows(submissionsearschlist);
                    logger.info("NGEUIException", e);
                } else {
                    subRows.setRows(submissionsearschlist);
                }
            } catch (MalformedURLException e) {
                exceptionBO = new ExceptionBO();
                exceptionBO.setErrorFrom(NGEConstants.SEARCH_SUBMISSION_SERVICE);
                logger.info("NGEUIException", e);
                exceptionBO
                        .setErrorMessage(seti18ErroMessage(NGEConstants.MALFORMED_URL));
                exceptionBO.setErrorCode(NGEConstants.FAILURE_CODE);
                exceptionBO.setErrorType(NGEConstants.FATAL);
            } catch (NumberFormatException e) {
                exceptionBO = new ExceptionBO();
                exceptionBO.setErrorFrom(NGEConstants.SEARCH_SUBMISSION_SERVICE);
                logger.info("NGEUIException", e);
                if (searchSubBO.getSearchby().equalsIgnoreCase("SN")) {
                    exceptionBO
                            .setErrorMessage(seti18ErroMessage(NGEConstants.INVALID_SUBMISSION_NUMBER_FORMAT));
                } else if (searchSubBO.getSearchby().equalsIgnoreCase("AN")) {
                    exceptionBO
                            .setErrorMessage(seti18ErroMessage(NGEConstants.INVALID_ACCOUNT_NUMBER_FORMAT));
                } else if (searchSubBO.getSearchby().equalsIgnoreCase("TN")) {
                    exceptionBO
                            .setErrorMessage(seti18ErroMessage(NGEConstants.INVALID_TRANSACTION_NUMBER_FORMAT));
                }
                exceptionBO.setErrorCode(NGEConstants.FAILURE_CODE);
                exceptionBO.setErrorType(NGEConstants.FATAL);
            } catch (Exception e) {
                exceptionBO = new ExceptionBO();
                exceptionBO.setErrorFrom(NGEConstants.SEARCH_SUBMISSION_SERVICE);
                // exceptionBO.setErrorMessage(e.getMessage());
                exceptionBO
                        .setErrorMessage(seti18ErroMessage(NGEConstants.ERROR_INVOKING_SERVICE));
                exceptionBO.setErrorCode(NGEConstants.FAILURE_CODE);
                exceptionBO.setErrorType(NGEConstants.FATAL);
                logger.info("NGEUIException", e);
            }
            if (null == exceptionBO) {
                jsonHeaderBO = setJsonHeader(sequenceNo,
                        NGEConstants.SUCCESS_CODE, NGEConstants.SUCCESS,
                        i18SuccessMessage, subRows);
            } else {
                jsonHeaderBO = setJsonHeader(sequenceNo,
                        exceptionBO.getErrorType(), NGEConstants.FAILURE,
                        exceptionBO.getErrorMessage(), subRows);
            }

        } else {
            logger.info("No Value is entered in JSP");
        }
        return jsonHeaderBO;
    }

    @RequestMapping(value = "/getsubmission", headers = "Accept=application/json", method = RequestMethod.POST)
    public @ResponseBody
    JSONHeaderBO getSubmission(@RequestBody GetSubmissionBO submissionBO, HttpServletRequest request, HttpServletResponse response) throws IOException {
        JSONHeaderBO jsonHeaderBO = new JSONHeaderBO();
        HttpSession session = null;
        session = request.getSession(false);
        if (session == null || (session.getAttribute(NGEConstants.SESSION_CASL_USERID) == null)) {
            //logger.info("Invalid Session : "+session);
            response.sendRedirect("jsp/logout.jsp");
            return jsonHeaderBO;
        }
		/*else{
			logger.info("session : "+session);
		}*/
        SubmissionDataService serviceObj = new SubmissionDataService();
        serviceObj.setCaslServiceId((String) session.getAttribute(NGEConstants.SESSION_CASL_USERID));
        ExceptionBO exceptionBO = null;
        Submission resp = null;
        List<AdditionalProducerBO> additionalProducerSessionList = null;
        SequenceNumberGeneration generateObj = new SequenceNumberGeneration();
        HashMap<String, String> sequenceNames = new HashMap<>();
        HashMap<String, Object> sequenceValueMap = new HashMap<String, Object>();
        sequenceNames.put("GET_SUBMISSION", "INT");
        sequenceValueMap = generateObj.getNextSequenceNumber(sequenceNames);
        int sequenceNo = Integer.parseInt(sequenceValueMap
                .get("GET_SUBMISSION").toString());
        SubmissionRespUIBO submissionsList = new SubmissionRespUIBO();
        GetsubmissionrespBO respBO = new GetsubmissionrespBO();
        String json1 = "";
        String respJson = "";
        String assetJSON = "";
        String i18Message = "";
        ObjectWriter ow = new ObjectMapper().writer()
                .withDefaultPrettyPrinter();
        SubmissionRs reponsesubmissionDet = new SubmissionRs();

        try {

            reponsesubmissionDet = serviceObj.getSubmission(
                    submissionBO);

            i18Message = seti18ErroMessage(NGEConstants.GET_SUBMISSION_SEARCH_SUCCESSFUL);
            respBO = serviceObj.setSubmissionResponseInBO(reponsesubmissionDet);
            //additionalProducerSessionList = GetSubmissionHandler.setAdditionalProducers(respBO);
            //additionalProducerSessionBO.setRows(additionalProducerSessionList);
            submissionsList = serviceObj.setSubmissionResponseInBOUI(reponsesubmissionDet, respBO, submissionBO);
            resp = serviceObj.setSubmissionRespForNewTrans(respBO);
			/*try {
				json1 = ow.writeValueAsString(submissionsList);
				logger.info("the json is  : " + json1);
			} catch (JsonProcessingException e) {
				// TODO Auto-generated catch block
				logger.info("NGEUIException",e);
			}*/


        } catch (MalformedURLException e) {
            exceptionBO = new ExceptionBO();
            exceptionBO.setErrorFrom(NGEConstants.GET_SUBMISSION_SERVICE);
            logger.info("NGEUIException", e);
            exceptionBO
                    .setErrorMessage(seti18ErroMessage(NGEConstants.MALFORMED_URL));
            exceptionBO.setErrorCode(NGEConstants.FAILURE_CODE);
            exceptionBO.setErrorType(NGEConstants.FATAL);
        } catch (GetSubmissionAIGCIExceptionTypeMsg e) {
            exceptionBO = new ExceptionBO();
            exceptionBO.setErrorFrom(NGEConstants.GET_SUBMISSION_SERVICE);
            exceptionBO.setErrorMessage(seti18ErroMessage(e.getFaultInfo()
                    .getErrorCode()));
            exceptionBO.setErrorCode(NGEConstants.FAILURE_CODE);
            exceptionBO.setErrorType(e.getFaultInfo().getErrorType());
            logger.info("NGEUIException", e);
        } catch (Exception e) {
            exceptionBO = new ExceptionBO();
            exceptionBO.setErrorFrom(NGEConstants.GET_SUBMISSION_SERVICE);
            exceptionBO
                    .setErrorMessage(seti18ErroMessage(NGEConstants.ERROR_INVOKING_SERVICE));
            exceptionBO.setErrorCode(NGEConstants.FAILURE_CODE);
            exceptionBO.setErrorType(NGEConstants.FATAL);
            logger.info("NGEUIException", e);
        }
//		List<PolicyDetailsJSONBO> policyDetails = submissionsList.getPolicyDetails();
//		if (policyDetails != null) {
//			for (int i = 0; i < policyDetails.size(); i++) {
//				List<PolicyDetailBO> policyBo = policyDetails.get(i).getData();
//				for (int j = 0; j < policyBo.size(); j++) {
//					if (null == policyBo.get(j).getPremiumWithCurrency()) {
//						if (null != policyBo.get(j).getCurrency()
//								&& null != policyBo.get(j).getPremium())
//							policyBo.get(j).setPremiumWithCurrency(
//									policyBo.get(j).getPremium() + " "
//											+ policyBo.get(j).getCurrency());
//					}
//					if(null == policyBo.get(j).getCurrencyHidden() ){
//						if(null != policyBo.get(j).getCurrency())
//							policyBo.get(j).setCurrencyHidden(policyBo.get(j).getCurrency());
//					}
//				}
//			}
//		}
        List<AssetDetailsJSONBO> assetList = submissionsList.getAssetDetails();
        if (exceptionBO == null) {
            jsonHeaderBO = setJsonHeader(sequenceNo, NGEConstants.SUCCESS_CODE,
                    NGEConstants.SUCCESS, i18Message, submissionsList);
        } else {
            jsonHeaderBO = setJsonHeader(sequenceNo,
                    exceptionBO.getErrorType(), NGEConstants.FAILURE,
                    exceptionBO.getErrorMessage(), submissionsList);
        }
        try {
            json1 = ow.writeValueAsString(jsonHeaderBO);
//			policyJSON = ow.writeValueAsString(policyDetails);
            assetJSON = ow.writeValueAsString(assetList);
            respJson = ow.writeValueAsString(resp);
            //addProdJSON = ow.writeValueAsString(additionalProducerSessionBO);
        } catch (JsonProcessingException e) {
            // TODO Auto-generated catch block
            logger.info("NGEUIException", e);
        }

        session.setAttribute(NGEConstants.UPDATE_ACC_MAIL_ADDRESS, null);
        session.setAttribute(NGEConstants.UPDATE_PROD_IND_CONTACT, null);
        logger.info("******************Setting the Get Submission Response in Session Starts********************************");
        logger.info("The Data Base Object stored in session is : " + respBO);
        session.setAttribute(NGEConstants.SUBMISSION_RESPONSE, XSSValidator.stripXSS(json1));
        session.setAttribute(NGEConstants.DB_SET_OBJECT, respBO);
        logger.info("The Data Base Object stored in session is : " + session.getAttribute(NGEConstants.DB_SET_OBJECT));
        session.setAttribute("SUBMISSION_HEADER_JSON", XSSValidator.stripXSS(respJson));
        session.setAttribute(NGEConstants.TRANSACTION_ADDITIONAL_ACC_PRODUCER_LIST, additionalProducerSessionList);
        session.setAttribute(NGEConstants.SESSION_TRANSACTION_ASSET_DETAIL_UPDATE, XSSValidator.stripXSS(assetJSON));
        session.setAttribute(NGEConstants.PRODUCT_ASSET_DETAIL_UPDATE, assetList);
        if (submissionBO.getFromPage() != null && submissionBO.getFromPage().equalsIgnoreCase(NGEConstants.BLOCK_SEARCH)) {
            session.setAttribute(NGEConstants.FROM_PAGE, submissionBO.getFromPage());
        } else {
            session.setAttribute(NGEConstants.FROM_PAGE, null);
        }
        logger.info("******************Setting the Get Submission Response in Session Ends********************************");
        return jsonHeaderBO;
    }

    @SuppressWarnings("unchecked")
    @RequestMapping(value = "/createtransaction", headers = "Accept=application/json", method = RequestMethod.POST)
    public @ResponseBody
    JSONHeaderBO createTransaction(
            @RequestBody CreateTransactionReqBO transactionBO, HttpServletRequest request, HttpServletResponse response) throws IOException {
        JSONHeaderBO jsonHeaderBO = new JSONHeaderBO();
        HttpSession session = null;
        session = request.getSession(false);
        if (session == null || (session.getAttribute(NGEConstants.SESSION_CASL_USERID) == null)) {
            //logger.info("Invalid Session : "+session);
            response.sendRedirect("jsp/logout.jsp");
            return jsonHeaderBO;
        }
	/*	else{
			logger.info("session : "+session);
		}*/

        String branchCd = null;
        SubmissionDataService serviceObj = new SubmissionDataService();
        serviceObj.setCaslServiceId((String) session.getAttribute(NGEConstants.SESSION_CASL_USERID));
        Map<String, String> prodNameMapMktPdct = new HashMap<String, String>();
        Map<String, String> prodNameMapCmptPdct = new HashMap<String, String>();
        Map<String, String> prodNameMapSubPdct = new HashMap<String, String>();
        transactionBO.getTransaction().setProducts(
                ServiceUtility.setCreateTransProducts(transactionBO));
        if (null != transactionBO.getTransaction().getCreditedBranchStr()) {
            CreditedBranchBO creditedBranch = new CreditedBranchBO();
            creditedBranch.setCountryCode(transactionBO
                    .getTransaction()
                    .getCreditedBranchStr()
                    .substring(
                            0,
                            transactionBO.getTransaction()
                                    .getCreditedBranchStr().indexOf("-")));
            creditedBranch.setBranchCode(transactionBO
                    .getTransaction()
                    .getCreditedBranchStr()
                    .substring(
                            transactionBO.getTransaction()
                                    .getCreditedBranchStr().indexOf("-") + 1));
            transactionBO.getTransaction().setCreditedBranch(creditedBranch);
        }
        Map<String, Map<String, AssetBO>> assetProductMap = null;
        Map<String, AssetBO> assetMap = null;
        List<AssetBO> assetList = null;
        CreateSubmissionRespBO transactionResp = null;

        ExceptionBO exceptionBO = null;
        SequenceNumberGeneration generateObj = new SequenceNumberGeneration();
        HashMap<String, String> sequenceNames = new HashMap<>();
        HashMap<String, Object> sequenceValueMap = new HashMap<String, Object>();
        sequenceNames.put("CREATE_TRANSACTION", "INT");
        sequenceValueMap = generateObj.getNextSequenceNumber(sequenceNames);
        int sequenceNo = Integer.parseInt(sequenceValueMap.get(
                "CREATE_TRANSACTION").toString());
        ObjectWriter ow = new ObjectMapper().writer()
                .withDefaultPrettyPrinter();

        try {
            ow.writeValueAsString(transactionBO);

            //session = request.getSession(true);
            transactionBO
                    .getTransaction()
                    .setAdditionalInsureds(
                            (List<AdditionalInsuredBO>) session
                                    .getAttribute(NGEConstants.TRANSACTION_ADDITIONAL_ACC_INSURED_LIST));
            transactionBO
                    .getTransaction()
                    .setAdditionalProducers(
                            (List<AdditionalProducerBO>) session
                                    .getAttribute(NGEConstants.TRANSACTION_ADDITIONAL_ACC_PRODUCER_LIST));
            transactionBO
                    .getTransaction()
                    .setBroker(
                            (BrokerBO) session
                                    .getAttribute(NGEConstants.TRANSACTION_PRODUCER_CONTACT_DETAIL));
            transactionBO
                    .getTransaction()
                    .setMailingAddress(
                            (AddressDetailsBO) session
                                    .getAttribute(NGEConstants.TRANSACTION_ADDRESS));
            if (null != session
                    .getAttribute(NGEConstants.TRANSACTION_ATTR_INFO_DETAIL)) {
                //session = request.getSession(true);
                Map<String, AttributesInfoBO> attrInfoMap = (Map<String, AttributesInfoBO>) session
                        .getAttribute(NGEConstants.TRANSACTION_ATTR_INFO_DETAIL);
                Set<String> attrSet = attrInfoMap.keySet();
                for (AttributesInfoBO aInfo : transactionBO
                        .getTransaction().getAttributes()) {
                    if (attrSet.contains(aInfo.getAttributeNm())) {
                        aInfo.setAttributeAction(attrInfoMap.get(
                                        aInfo.getAttributeAction())
                                .getAttributeAction());
                    }
                }
            }
            for (ComponentProductBO compProd : transactionBO
                    .getTransaction().getProducts().getComponentProduct()) {

                if (null != compProd.getDspMmcp() && compProd.getDspMmcp().length() > 0) {
                    String dSPMMCP = compProd.getDspMmcp();
                    String[] dspMMCP = dSPMMCP.split("-");
                    List<BranchBO> branchList = compProd.getBranch();
                    for (BranchBO branchBo : branchList) {
                        String branchTypeCd = branchBo.getBranchTypeCd();
                        if (branchTypeCd.equalsIgnoreCase("Working Branch")) {
                            branchCd = branchBo.getCountryCd();
                        }
                    }
                    if (branchCd != null && (branchCd.equalsIgnoreCase("0") || branchCd.equalsIgnoreCase("USA"))) {
                        compProd.setDivisionNo(dspMMCP[0]);
                        compProd.setSectionCd(dspMMCP[1]);
                        compProd.setProfitUnitCd(dspMMCP[2]);
                    } else {
                        compProd.setMajorClassCd(dspMMCP[0]);
                        compProd.setMajorLineCd(dspMMCP[1]);
                        compProd.setMinorLineCd(dspMMCP[2]);
                    }
                }


                if (null != session.getAttribute(NGEConstants.ADDITIONAL_INSURED_LIST_PRODUCT_LEVEL)) {
                    List<AdditionalInsuredBO> additionalInsuredListProductLevel = (List<AdditionalInsuredBO>) session.getAttribute(NGEConstants.ADDITIONAL_INSURED_LIST_PRODUCT_LEVEL);
                    List<AdditionalInsuredBO> additionalInsuredListOfProduct = new ArrayList<AdditionalInsuredBO>();
                    String processingInd = null;
                    for (AdditionalInsuredBO sessionAdditionalInsured : additionalInsuredListProductLevel) {
                        if (sessionAdditionalInsured.getProductTabKey().equalsIgnoreCase(compProd.getProductTabkey()) && sessionAdditionalInsured.getComponentProductTabKey().equalsIgnoreCase(compProd.getComponentProductTabKey()) && sessionAdditionalInsured.getAccountNo() != null) {
                            additionalInsuredListOfProduct.add(sessionAdditionalInsured);
                            processingInd = sessionAdditionalInsured.getProcessingInd();
                        } else if (sessionAdditionalInsured.getProductTabKey().equalsIgnoreCase(compProd.getProductTabkey()) && sessionAdditionalInsured.getComponentProductTabKey().equalsIgnoreCase(compProd.getComponentProductTabKey())) {
                            processingInd = sessionAdditionalInsured.getProcessingInd();
                        }
                    }
                    compProd.setAdditionalInsured(additionalInsuredListOfProduct);
                    AdditionalInsuredsBO additionalInsureds = new AdditionalInsuredsBO();
                    additionalInsureds.setAdditionalInsuredRq(additionalInsuredListOfProduct);
                    additionalInsureds.setProcessingInd(processingInd);
                    compProd.setAdditionalInsureds(additionalInsureds);
                }

                if (null != session.getAttribute(NGEConstants.EXPOSURE_COUNTRY_DETAIL)) {
                    Map<String, ExposureCountryBO> exposureMap = (Map<String, ExposureCountryBO>) session.getAttribute(NGEConstants.EXPOSURE_COUNTRY_DETAIL);
                    compProd.setExposureCountry(exposureMap.get(compProd.getProductTabkey() + "~" + compProd.getComponentProductTabKey()));
                }

                if (null != session.getAttribute(NGEConstants.PRODUCT_POLICY_DETAIL)) {
                    List<PolicyDetailBO> policyList = (List<PolicyDetailBO>) session.getAttribute(NGEConstants.PRODUCT_POLICY_DETAIL);
                    ow.writeValueAsString(policyList);
                    List<PolicyDetailBO> policyListOfProduct = new ArrayList<PolicyDetailBO>();
                    for (PolicyDetailBO sessionPolicy : policyList) {
                        if (sessionPolicy.getProductTabKey().equalsIgnoreCase(compProd.getProductTabkey()) && sessionPolicy.getComponentProductTabKey().equalsIgnoreCase(compProd.getComponentProductTabKey())) {
                            policyListOfProduct.add(sessionPolicy);
                        }
                    }
                    compProd.setPolicyDetail(policyListOfProduct);
                }

                if (null != session.getAttribute(NGEConstants.PRODUCT_ASSET_DETAIL)) {
                    assetProductMap = (Map<String, Map<String, AssetBO>>) session
                            .getAttribute(NGEConstants.PRODUCT_ASSET_DETAIL);

                    if (null != assetProductMap) {
                        assetMap = assetProductMap
                                .get(compProd.getProductTabkey()
                                        + "~"
                                        + compProd
                                        .getComponentProductTabKey());

                        if (null != assetMap) {
                            assetList = new ArrayList<AssetBO>(assetMap.values());
                            compProd.setAsset(assetList);
                        }

                    }
                }
                if (null != session.getAttribute(NGEConstants.SESSION_ASSOCIATE_PRODUCT_LIST_DATA)) {
                    Map<String, List<ProductBO>> expiringProductMap = (Map<String, List<ProductBO>>) session.getAttribute(NGEConstants.SESSION_ASSOCIATE_PRODUCT_LIST_DATA);
                    if (expiringProductMap != null && expiringProductMap.size() > 0) {
                        List<ProductBO> expiringProductList = expiringProductMap.get(compProd.getProductTabkey() + "~" + compProd.getComponentProductTabKey());
                        if (expiringProductList != null && expiringProductList.size() > 0) {
                            compProd.setExpiringProduct(expiringProductList);
                        }
                    }
                }

                if (null != session
                        .getAttribute(NGEConstants.PRODUCT_ATTR_INFO_DETAIL
                                + compProd.getCompProductId())) {
                    Map<String, AttributesInfoBO> attrInfoMap = (Map<String, AttributesInfoBO>) session
                            .getAttribute(NGEConstants.PRODUCT_ATTR_INFO_DETAIL
                                    + compProd.getCompProductId());
                    Set<String> attrSet = attrInfoMap.keySet();
                    for (AttributesInfoBO aInfo : compProd
                            .getAttributesInfo()) {
                        if (attrSet.contains(aInfo.getAttributeNm())) {
                            aInfo.setAttributeAction(attrInfoMap.get(
                                            aInfo.getAttributeAction())
                                    .getAttributeAction());
                        }
                    }
                }
            }
            for (MarketableProductDetailsBO marketProd : transactionBO
                    .getTransaction().getProducts().getMarketableProduct()) {
                if (null != session
                        .getAttribute(NGEConstants.PRODUCT_ATTR_INFO_DETAIL
                                + marketProd.getMarketableProductCd())) {
                    Map<String, AttributesInfoBO> attrInfoMap = (Map<String, AttributesInfoBO>) session
                            .getAttribute(NGEConstants.PRODUCT_ATTR_INFO_DETAIL
                                    + marketProd.getMarketProdId());
                    Set<String> attrSet = attrInfoMap.keySet();
                    for (AttributesInfoBO aInfo : marketProd
                            .getAttributesInfo()) {
                        if (attrSet.contains(aInfo.getAttributeNm())) {
                            aInfo.setAttributeAction(attrInfoMap.get(
                                            aInfo.getAttributeAction())
                                    .getAttributeAction());
                        }
                    }
                }
            }

            transactionResp = serviceObj.createTransaction(transactionBO);
        } catch (MalformedURLException e) {
            exceptionBO = new ExceptionBO();
            exceptionBO.setErrorFrom(NGEConstants.CREATE_TRANSACTION_SERVICE);
            exceptionBO.setErrorMessage(e.getMessage());
            exceptionBO.setErrorType(NGEConstants.FATAL);
        } catch (CreateTransactionAIGCIExceptionTypeMsg e) {
            logger.info("Inside Service Exception");
            //System.out.println("The Error Message is : " + e.getFaultInfo().getErrorMessage());
            exceptionBO = new ExceptionBO();
            exceptionBO.setErrorFrom(NGEConstants.CREATE_TRANSACTION_SERVICE);
            exceptionBO.setErrorMessage(seti18ErroMessage(e.getFaultInfo()
                    .getErrorCode()));
            exceptionBO.setErrorCode(NGEConstants.FAILURE_CODE);
            exceptionBO.setErrorType(e.getFaultInfo().getErrorType());
            logger.info("The Error Message is : " + e.getFaultInfo().getErrorMessage());
            logger.info("NGEUIException", e);
        } catch (NumberFormatException e) {
            exceptionBO = new ExceptionBO();
            exceptionBO.setErrorFrom(NGEConstants.CREATE_TRANSACTION_SERVICE);
            logger.info("NGEUIException", e);
            exceptionBO
                    .setErrorMessage(seti18ErroMessage(NGEConstants.INVALID_TRANSACTION_REQUEST));
            exceptionBO.setErrorCode(NGEConstants.FAILURE_CODE);
            exceptionBO.setErrorType(NGEConstants.FATAL);
        } catch (Exception e) {
            logger.info("Inside General Exception");
            exceptionBO = new ExceptionBO();
            exceptionBO.setErrorFrom(NGEConstants.CREATE_TRANSACTION_SERVICE);
            exceptionBO
                    .setErrorMessage(seti18ErroMessage(NGEConstants.ERROR_INVOKING_SERVICE));
            exceptionBO.setErrorType(NGEConstants.FATAL);
        }
        StringBuffer message = new StringBuffer();
        if (null != transactionResp && null != transactionResp.getTransaction() && null != transactionResp.getTransaction().getTransactionVersionNo()
                && null != transactionResp.getTransaction().getTransactionVersionNo().getAddProductResponse()
                && null != transactionResp.getTransaction().getTransactionVersionNo().getAddProductResponse().getProductsRs()) {
            DataCacheObject cacheObject = new DataCacheObject();
            prodNameMapMktPdct = (Map<String, String>) cacheObject.getDynacacheObj("PRODUCT_NAME_BY_CODE_MKT_PDCT");
            prodNameMapCmptPdct = (Map<String, String>) cacheObject.getDynacacheObj("PRODUCT_NAME_BY_CODE_CMPNT_PDCT");
            prodNameMapSubPdct = (Map<String, String>) cacheObject.getDynacacheObj("PRODUCT_NAME_BY_CODE_SUB_PDCT");
            List<MessageDetailsBO> serviceMessages = new ArrayList<MessageDetailsBO>();
            if (null != transactionResp.getTransaction().getTransactionVersionNo().getAddProductResponse().getProductsRs().getMarketableProduct()
                    && !transactionResp.getTransaction().getTransactionVersionNo().getAddProductResponse().getProductsRs().getMarketableProduct().isEmpty()) {
                for (MarketableProductDetailsRsBO marketProd : transactionResp.getTransaction().getTransactionVersionNo().getAddProductResponse().getProductsRs().getMarketableProduct()) {
                    if (null != marketProd.getMessage()) {
                        if (!marketProd.getMessage().getMessageCode().equalsIgnoreCase("000")) {
                            message.append(seti18ErroMessage(marketProd.getMessage().getMessageCode()));
                            message.append("~~");
                            MessageDetailsBO bo = new MessageDetailsBO();
                            bo.setProductName(prodNameMapMktPdct.get(marketProd.getMarketableProductCd()));
                            bo.setMesssage(seti18ErroMessage(marketProd.getMessage().getMessageCode()));
                            bo.setErrorCode(marketProd.getMessage().getMessageCode());
                            serviceMessages.add(bo);
                        } else {
                            MessageDetailsBO bo = new MessageDetailsBO();
                            bo.setProductName(prodNameMapMktPdct.get(marketProd.getMarketableProductCd()));
                            bo.setMesssage(NGEConstants.MARKET_PRODUCT_ADD_SUCCESS);
                            bo.setErrorCode(marketProd.getMessage().getMessageCode());
                            serviceMessages.add(bo);
                        }
                    }
                }
            }
            if (null != transactionResp.getTransaction().getTransactionVersionNo().getAddProductResponse().getProductsRs().getComponentProduct()
                    && !transactionResp.getTransaction().getTransactionVersionNo().getAddProductResponse().getProductsRs().getComponentProduct().isEmpty()) {
                for (ComponentProductResBO compProd : transactionResp.getTransaction().getTransactionVersionNo().getAddProductResponse().getProductsRs().getComponentProduct()) {
                    if (null != compProd.getMessage()) {
                        if (!compProd.getMessage().getMessageCode().equalsIgnoreCase("000")) {
                            message.append(seti18ErroMessage(compProd.getMessage().getMessageCode()));
                            message.append("~~");
                            MessageDetailsBO bo = new MessageDetailsBO();
                            bo.setAttachmentPoint(compProd.getAttachmentPointAmt());
                            if (compProd.getMarketableProductCd() != null) {
                                bo.setProductName(prodNameMapCmptPdct.get(compProd.getComponentProductCd()));
                            } else {
                                bo.setProductName(prodNameMapSubPdct.get(compProd.getComponentProductCd()));
                            }
                            bo.setMesssage(seti18ErroMessage(compProd.getMessage().getMessageCode()));
                            bo.setErrorCode(compProd.getMessage().getMessageCode());
                            serviceMessages.add(bo);
                        } else {
                            MessageDetailsBO bo = new MessageDetailsBO();
                            if (null != compProd.getMarketableProductCd()) {
                                bo.setProductName(prodNameMapCmptPdct.get(compProd.getComponentProductCd()));
                            } else {
                                bo.setProductName(prodNameMapSubPdct.get(compProd.getComponentProductCd()));
                            }
                            bo.setAttachmentPoint(compProd.getAttachmentPointAmt());
                            if (null == compProd.getMarketableProductCd()) {
                                bo.setMesssage(NGEConstants.TECH_SUB_PRODUCT_ADD_SUCCESS);
                            } else {
                                bo.setMesssage(NGEConstants.COMP_PRODUCT_ADD_SUCCESS);
                            }
                            bo.setErrorCode(compProd.getMessage().getMessageCode());
                            serviceMessages.add(bo);
                        }
                    }
                }
            }
            if (null != transactionResp.getTransaction().getTransactionVersionNo().getReserveProductRs() && !transactionResp.getTransaction().getTransactionVersionNo().getReserveProductRs().isEmpty()) {
                for (ReserveProductsRsBO product : transactionResp.getTransaction().getTransactionVersionNo().getReserveProductRs()) {
                    if (null != product.getMessage()) {
                        if (!product.getMessage().getMessageCode().equalsIgnoreCase("SUCCESS")
                                && !product.getMessage().getMessageCode().equalsIgnoreCase("000")) {
                            message.append(seti18ErroMessage(product.getMessage().getMessageCode()));
                            message.append("~~");
                            MessageDetailsBO bo = new MessageDetailsBO();
                            if (null != product.getAttachmentPointAmt()) {
                                bo.setAttachmentPoint(product.getAttachmentPointAmt());
                                if (product.getMarketableProductCd() != null) {
                                    bo.setProductName(prodNameMapCmptPdct.get(product.getComponentProductCd()));
                                } else {
                                    bo.setProductName(prodNameMapSubPdct.get(product.getComponentProductCd()));
                                }
                            } else {
                                bo.setProductName(prodNameMapMktPdct.get(product.getMarketableProductCd()));
                            }
                            bo.setMesssage(seti18ErroMessage(product.getMessage().getMessageCode()));
                            bo.setErrorCode(product.getMessage().getMessageCode());
                            serviceMessages.add(bo);
                        } else {
                            MessageDetailsBO bo = new MessageDetailsBO();
                            if (null != product.getAttachmentPointAmt()) {
                                bo.setAttachmentPoint(product.getAttachmentPointAmt());
                                bo.setMesssage(NGEConstants.PRODUCT_RESERVE_SUCCESS);

                                if (product.getMarketableProductCd() != null) {
                                    bo.setProductName(prodNameMapCmptPdct.get(product.getComponentProductCd()));
                                } else {
                                    bo.setProductName(prodNameMapSubPdct.get(product.getComponentProductCd()));
                                }
                            } else {
                                bo.setMesssage(NGEConstants.PRODUCT_RESERVE_SUCCESS);
                                bo.setProductName(prodNameMapMktPdct.get(product.getMarketableProductCd()));
                            }
                            bo.setErrorCode(product.getMessage().getMessageCode());
                            serviceMessages.add(bo);
                        }
                    }
                }
            }
            transactionResp.setServiceMessages(serviceMessages);
        }
        if (null == exceptionBO) {
            jsonHeaderBO = setJsonHeader(sequenceNo, NGEConstants.SUCCESS_CODE,
                    NGEConstants.SUCCESS,
                    message.toString(),
                    transactionResp);
        } else {
            jsonHeaderBO = setJsonHeader(sequenceNo,
                    exceptionBO.getErrorCode(), exceptionBO.getErrorType(),
                    exceptionBO.getErrorMessage(), transactionResp);
        }
        return jsonHeaderBO;
    }

    @RequestMapping(value = "/createtransactionversion", headers = "Accept=application/json", method = RequestMethod.POST)
    public @ResponseBody
    JSONHeaderBO createTransactionVersion(
            @RequestBody CreateTransactionVersionReqBO transactionBO, HttpServletRequest request, HttpServletResponse response) throws IOException {
        HttpSession session = null;
        session = request.getSession(false);
        JSONHeaderBO jsonHeaderBO = new JSONHeaderBO();
        if (session == null || (session.getAttribute(NGEConstants.SESSION_CASL_USERID) == null)) {
            //logger.info("Invalid Session : "+session);
            response.sendRedirect("jsp/logout.jsp");
            return jsonHeaderBO;
        }
		/*else{
			logger.info("session : "+session);
		}*/

        SubmissionDataService serviceObj = new SubmissionDataService();
        serviceObj.setCaslServiceId((String) session.getAttribute(NGEConstants.SESSION_CASL_USERID));
        CreateTransactionVersionResBO transactionResp = null;
        ExceptionBO exceptionBO = null;

        SequenceNumberGeneration generateObj = new SequenceNumberGeneration();
        HashMap<String, String> sequenceNames = new HashMap<>();
        HashMap<String, Object> sequenceValueMap = new HashMap<String, Object>();
        sequenceNames.put("CREATE_TRANSACTION_VERSION", "INT");
        sequenceValueMap = generateObj.getNextSequenceNumber(sequenceNames);
        int sequenceNo = Integer.parseInt(sequenceValueMap.get(
                "CREATE_TRANSACTION_VERSION").toString());
        try {

            transactionResp = serviceObj
                    .createTransactionVersion(transactionBO);
			/*submissionsList = serviceObj.getSubmission(
					transactionBO.getSubmissionNo(), null, null, null);*/

        } catch (MalformedURLException e) {
            exceptionBO = new ExceptionBO();
            exceptionBO.setErrorFrom(NGEConstants.CREATE_TRANSACTION_VERSION_SERVICE);
            exceptionBO.setErrorMessage(e.getMessage());
            exceptionBO.setErrorType(NGEConstants.FATAL);
        } catch (CreateTransactionVersionAIGCIExceptionTypeMsg e) {
            logger.info("Inside Service Exception");
            exceptionBO = new ExceptionBO();
            exceptionBO.setErrorFrom(NGEConstants.CREATE_TRANSACTION_VERSION_SERVICE);
            exceptionBO.setErrorMessage(seti18ErroMessage(e.getFaultInfo()
                    .getErrorCode()));
            exceptionBO.setErrorCode(NGEConstants.FAILURE_CODE);
            exceptionBO.setErrorType(e.getFaultInfo().getErrorType());
            logger.info("NGEUIException", e);
        } catch (NumberFormatException e) {
            exceptionBO = new ExceptionBO();
            exceptionBO.setErrorFrom(NGEConstants.CREATE_TRANSACTION_VERSION_SERVICE);
            logger.info("NGEUIException", e);
            exceptionBO
                    .setErrorMessage(seti18ErroMessage(NGEConstants.INVALID_TRANSACTION_REQUEST));
            exceptionBO.setErrorCode(NGEConstants.FAILURE_CODE);
            exceptionBO.setErrorType(NGEConstants.FATAL);
        } catch (Exception e) {
            logger.info("Inside General Exception");
            exceptionBO = new ExceptionBO();
            exceptionBO.setErrorFrom(NGEConstants.CREATE_TRANSACTION_VERSION_SERVICE);
            exceptionBO
                    .setErrorMessage(seti18ErroMessage(NGEConstants.ERROR_INVOKING_SERVICE));
            exceptionBO.setErrorType(NGEConstants.FATAL);
        }
        if (null == exceptionBO) {
            jsonHeaderBO = setJsonHeader(sequenceNo, NGEConstants.SUCCESS_CODE,
                    NGEConstants.SUCCESS,
                    NGEConstants.CREATE_TRANSACTION_VERSION_SUCCESSFUL,
                    transactionResp);
        } else {
            jsonHeaderBO = setJsonHeader(sequenceNo,
                    exceptionBO.getErrorCode(), exceptionBO.getErrorType(),
                    exceptionBO.getErrorMessage(), transactionResp);
        }
        return jsonHeaderBO;
    }

    @RequestMapping(value = "/getviewreleaseblock", headers = "Accept=application/json", method = RequestMethod.POST)
    public @ResponseBody
    JSONHeaderBO getviewreleaseblock(
            @RequestBody GetViewBlockReqBO getViewBlockReqBO, HttpServletRequest request, HttpServletResponse response) throws IOException {
        JSONHeaderBO jsonHeaderBO = new JSONHeaderBO();
        HttpSession session = null;
        session = request.getSession(false);
        if (session == null || (session.getAttribute(NGEConstants.SESSION_CASL_USERID) == null)) {
            //logger.info("Invalid Session : "+session);
            response.sendRedirect("jsp/logout.jsp");
            return jsonHeaderBO;
        }
	/*	else{
			logger.info("session : "+session);
		}*/
        CASLAuthorizeBO authorize = (CASLAuthorizeBO) session.getAttribute("caslUserAcessDetailsBO");
        SubmissionDataService serviceObj = new SubmissionDataService();
        serviceObj.setCaslServiceId((String) session.getAttribute(NGEConstants.SESSION_CASL_USERID));
        GetBlockedProductsResBO productsResBO = null;
        ViewblockBO viewblockResBo = new ViewblockBO();
        SessionBlockDetailsBO saveblockcomponentdetails = new SessionBlockDetailsBO();
        ExceptionBO exceptionBO = null;

        JSONHeaderBO jsonHeaderBO1 = new JSONHeaderBO();
        SequenceNumberGeneration generateObj = new SequenceNumberGeneration();
        HashMap<String, String> sequenceNames = new HashMap<>();
        HashMap<String, Object> sequenceValueMap = new HashMap<String, Object>();
        sequenceNames.put("VIEW_RELEASE_BLOCK_INFO", "INT");
        sequenceValueMap = generateObj.getNextSequenceNumber(sequenceNames);
        int sequenceNo = Integer.parseInt(sequenceValueMap.get("VIEW_RELEASE_BLOCK_INFO")
                .toString());
        String i18SuccessMessage = null;
/*		List<BlockedInfoRow> blockedRows = new ArrayList<BlockedInfoRow>();
		List<BlockedInfoRow> releasedRows = new ArrayList<BlockedInfoRow>();
		GetBlockedInfoRows blockedInfoRows = new GetBlockedInfoRows();
		GetBlockedInfoRows releasedInfoRows = new GetBlockedInfoRows();*/
        GetBlockingInfoResBO blockingInfoResBO = new GetBlockingInfoResBO();


        GetBlockedProductsRqBO getBloProductsRqBO = getViewBlockReqBO.getGetBlockedProductsRqBO();
        GetBlockingInfoReqBO blockingInfoReqBO = getViewBlockReqBO.getGetBlockingInfoReqBO();
        try {
            if (null != getBloProductsRqBO.getBlockingComponentProduct()) {
                logger.info("Inside Component Block Starts");
                viewblockResBo = ServiceUtility.setviewblockinfo(getBloProductsRqBO);
                saveblockcomponentdetails.setViewblockdetails(viewblockResBo);
                logger.info("Inside Component Block Ends");
            }
            getBloProductsRqBO.setEmailiconalertBlock(authorize.getEmailiconalertBlock());
            getBloProductsRqBO.setEmailiconproductBlock(authorize.getEmailiconproductBlock());
            productsResBO = serviceObj.getBlockedProducts(getBloProductsRqBO);
            if (productsResBO != null) {
                productsResBO.setEmailiconalertBlock(authorize.getEmailiconalertBlock());
                productsResBO.setEmailiconproductBlock(authorize.getEmailiconproductBlock());
            }
            ServiceUtility.getBlockedInfoRows(productsResBO);

            i18SuccessMessage = seti18ErroMessage(NGEConstants.BLOCKED_INFO_SUCCESSFUL);

        } catch (MalformedURLException e) {
            logger.info("Inside Malformed URL");
            exceptionBO = new ExceptionBO();
            exceptionBO.setErrorFrom(NGEConstants.GET_BLOCKED_INFO_SERVICE);
            exceptionBO.setErrorMessage(e.getMessage());
            exceptionBO.setErrorType(NGEConstants.FATAL);
            logger.info("NGEUIException", e);
        } catch (GetBlockedInfoAIGCIExceptionTypeMsg e) {
            logger.info("Inside Service URL");
            if (!e.getFaultInfo().getErrorCode().equalsIgnoreCase(NGEErrorCodes.NO_BLOCKS_AVAILABLE)) {
                exceptionBO = new ExceptionBO();
                exceptionBO.setErrorFrom(NGEConstants.GET_BLOCKED_INFO_SERVICE);
                exceptionBO.setErrorMessage(seti18ErroMessage(e.getFaultInfo()
                        .getErrorCode()));
                exceptionBO.setErrorCode(NGEConstants.FAILURE_CODE);
                exceptionBO.setErrorType(e.getFaultInfo().getErrorType());
            }
            logger.info("NGEUIException", e);
        } catch (NumberFormatException e) {
            exceptionBO = new ExceptionBO();
            exceptionBO.setErrorFrom(NGEConstants.GET_BLOCKED_INFO_SERVICE);
            logger.info("NGEUIException", e);
            exceptionBO
                    .setErrorMessage(seti18ErroMessage(NGEConstants.INVALID_BLOCK_NUMBER_FORMAT));
            exceptionBO.setErrorCode(NGEConstants.FAILURE_CODE);
            exceptionBO.setErrorType(NGEConstants.FATAL);
            logger.info("NGEUIException", e);
        } catch (Exception e) {
            exceptionBO = new ExceptionBO();
            exceptionBO.setErrorFrom(NGEConstants.GET_BLOCKED_INFO_SERVICE);
            exceptionBO
                    .setErrorMessage(seti18ErroMessage(NGEConstants.ERROR_INVOKING_SERVICE));
            exceptionBO.setErrorType(NGEConstants.FATAL);
            logger.info("NGEUIException", e);
        }

        try {
            if (blockingInfoReqBO != null) {
                blockingInfoReqBO.setEmailiconalertBlock(authorize.getEmailiconalertBlock());
                blockingInfoReqBO.setEmailiconproductBlock(authorize.getEmailiconproductBlock());
            }
            blockingInfoResBO = serviceObj.getBlockingInfo(blockingInfoReqBO);
            if (blockingInfoResBO != null) {
                blockingInfoResBO.setEmailiconalertBlock(authorize.getEmailiconalertBlock());
                blockingInfoResBO.setEmailiconproductBlock(authorize.getEmailiconproductBlock());
            }
            ServiceUtility.getBlockingInfoRows(blockingInfoResBO);
        } catch (MalformedURLException e) {
            logger.info("Inside Malformed URL");
            exceptionBO = new ExceptionBO();
            exceptionBO.setErrorFrom(NGEConstants.GET_BLOCKED_INFO_SERVICE);
            exceptionBO.setErrorMessage(e.getMessage());
            exceptionBO.setErrorType(NGEConstants.FATAL);
            logger.info("NGEUIException", e);
        } catch (GetBlockingInfoAIGCIExceptionTypeMsg e) {
            logger.info("Inside Service URL");
            if (!e.getFaultInfo().getErrorCode().equalsIgnoreCase(NGEErrorCodes.NO_BLOCK_EXISTS)) {
                exceptionBO = new ExceptionBO();
                exceptionBO.setErrorFrom(NGEConstants.GET_BLOCKED_INFO_SERVICE);
                exceptionBO.setErrorMessage(seti18ErroMessage(e.getFaultInfo()
                        .getErrorCode()));
                exceptionBO.setErrorCode(NGEConstants.FAILURE_CODE);
                exceptionBO.setErrorType(e.getFaultInfo().getErrorType());
            }
            logger.info("NGEUIException", e);

        } catch (NumberFormatException e) {
            exceptionBO = new ExceptionBO();
            exceptionBO.setErrorFrom(NGEConstants.GET_BLOCKED_INFO_SERVICE);
            logger.info("NGEUIException", e);
            exceptionBO
                    .setErrorMessage(seti18ErroMessage(NGEConstants.INVALID_BLOCK_NUMBER_FORMAT));
            exceptionBO.setErrorCode(NGEConstants.FAILURE_CODE);
            exceptionBO.setErrorType(NGEConstants.FATAL);
            logger.info("NGEUIException", e);
        } catch (Exception e) {
            exceptionBO = new ExceptionBO();
            exceptionBO.setErrorFrom(NGEConstants.GET_BLOCKED_INFO_SERVICE);
            exceptionBO
                    .setErrorMessage(seti18ErroMessage(NGEConstants.ERROR_INVOKING_SERVICE));
            exceptionBO.setErrorType(NGEConstants.FATAL);
            logger.info("NGEUIException", e);
        }
        ObjectWriter ow = new ObjectMapper().writer()
                .withDefaultPrettyPrinter();
        String json1 = "";
        String json2 = "";
        String viewblockJson = "";
        String getViewBlockReqBOJson = "";

        if (exceptionBO == null) {
            jsonHeaderBO = setJsonHeader(sequenceNo, NGEConstants.SUCCESS_CODE,
                    NGEConstants.SUCCESS, i18SuccessMessage, productsResBO);

            jsonHeaderBO1 = setJsonHeader(sequenceNo, NGEConstants.SUCCESS_CODE,
                    NGEConstants.SUCCESS,
                    NGEConstants.BLOCKING_INFO_SUCCESSFUL, blockingInfoResBO);
        } else {
            jsonHeaderBO = setJsonHeader(sequenceNo,
                    exceptionBO.getErrorType(), NGEConstants.FAILURE,
                    exceptionBO.getErrorMessage(), productsResBO);
        }
        try {
            json1 = ow.writeValueAsString(jsonHeaderBO);
            if (null != getBloProductsRqBO.getBlockingComponentProduct()) {
                viewblockJson = ow.writeValueAsString(saveblockcomponentdetails);
            }
            json2 = ow.writeValueAsString(jsonHeaderBO1);
            getViewBlockReqBOJson = ow.writeValueAsString(getViewBlockReqBO);

        } catch (JsonProcessingException e) {
            // TODO Auto-generated catch block
            logger.info("NGEUIException", e);
        }

        logger.info("****************************Setting Session Object for Blocked Info Details Starts********************");

        session.setAttribute(NGEConstants.SESSION_VIEW_RELEASE_BLOCK_REQUEST, XSSValidator.stripXSSPattern(getViewBlockReqBOJson));

        session.setAttribute(NGEConstants.SESSION_VIEW_BLOCKED_COMPONENTS_DETAILS, XSSValidator.stripXSSPattern(json1));
        //session = request.getSession(true);
        if (null != viewblockResBo) {
            logger.info("****************************Setting Session Object for View Blocked Info Details Starts********************");
            session.setAttribute(NGEConstants.SESSION_VIEW_COMPONENTS_DETAILS, XSSValidator.stripXSSPattern(viewblockJson));
            logger.info("****************************Setting Session Object for View Blocked Info Details Info Ends********************");
        }

        logger.info("****************************Setting Session Object for Blocking Info Details Starts********************");
        session.setAttribute(NGEConstants.SESSION_VIEW_BLOCKING_COMPONENTS_DETAILS, XSSValidator.stripXSSPattern(json2));
        logger.info("****************************Setting Session Object for Blocked Info Details Ends********************");
        return jsonHeaderBO;
    }

    @RequestMapping(value = "/getblockedinfo", headers = "Accept=application/json", method = RequestMethod.POST)
    public @ResponseBody
    JSONHeaderBO getBlockedInfo(
            @RequestBody GetBlockedProductsRqBO getBloProductsRqBO, HttpServletRequest request, HttpServletResponse response) throws IOException {
        HttpSession session = null;
        session = request.getSession(false);
        JSONHeaderBO jsonHeaderBO = new JSONHeaderBO();
        if (session == null || (session.getAttribute(NGEConstants.SESSION_CASL_USERID) == null)) {
            //logger.info("Invalid Session : "+session);
            response.sendRedirect("jsp/logout.jsp");
            return jsonHeaderBO;
        }
		/*else{
			logger.info("session : "+session);
		}*/
        CASLAuthorizeBO authorize = (CASLAuthorizeBO) session.getAttribute("caslUserAcessDetailsBO");
        SubmissionDataService serviceObj = new SubmissionDataService();
        serviceObj.setCaslServiceId((String) session.getAttribute(NGEConstants.SESSION_CASL_USERID));
        GetBlockedInfoBlockStatus blockedInfo = new GetBlockedInfoBlockStatus();
        GetBlockedProductsResBO productsResBO = null;
        ViewblockBO viewblockResBo = null;
        SessionBlockDetailsBO saveblockcomponentdetails = new SessionBlockDetailsBO();
        ExceptionBO exceptionBO = null;

        SequenceNumberGeneration generateObj = new SequenceNumberGeneration();
        HashMap<String, String> sequenceNames = new HashMap<>();
        HashMap<String, Object> sequenceValueMap = new HashMap<String, Object>();
        sequenceNames.put("BLOCKED_INFO", "INT");
        sequenceValueMap = generateObj.getNextSequenceNumber(sequenceNames);
        int sequenceNo = Integer.parseInt(sequenceValueMap.get("BLOCKED_INFO")
                .toString());
        String i18SuccessMessage = null;
        List<BlockedInfoRow> blockedRows = new ArrayList<BlockedInfoRow>();
        List<BlockedInfoRow> releasedRows = new ArrayList<BlockedInfoRow>();
        GetBlockedInfoRows blockedInfoRows = new GetBlockedInfoRows();
        GetBlockedInfoRows releasedInfoRows = new GetBlockedInfoRows();

        try {
            //productsResBO = serviceObj.getBlockedProducts(blockedProductsRqBO);
            if (getBloProductsRqBO != null) {
                getBloProductsRqBO.setEmailiconalertBlock(authorize.getEmailiconalertBlock());
                getBloProductsRqBO.setEmailiconproductBlock(authorize.getEmailiconproductBlock());
            }
            productsResBO = serviceObj.getBlockedProducts(getBloProductsRqBO);
            if (productsResBO != null) {
                productsResBO.setEmailiconalertBlock(authorize.getEmailiconalertBlock());
                productsResBO.setEmailiconproductBlock(authorize.getEmailiconproductBlock());
            }
            ServiceUtility.getBlockedInfoRows(productsResBO);
            if (productsResBO != null) {
                blockedInfo.setBlocked(productsResBO.getBlocked());
                blockedInfo.setReleased(productsResBO.getReleased());
                blockedInfo.setBlockingAlertList(productsResBO.getBlockingAlertList());
                blockedInfo.setReleasedAlertList(productsResBO.getReleasedAlertList());
                blockedInfo.setAdvancedBlockSearchMaxResult(productsResBO.getAdvancedBlockSearchMaxResult());
            }
            i18SuccessMessage = seti18ErroMessage(NGEConstants.BLOCKED_INFO_SUCCESSFUL);
            if (getBloProductsRqBO != null && null != getBloProductsRqBO.getBlockingComponentProduct()) {
                logger.info("Inside Component Block Starts");

                viewblockResBo = ServiceUtility.setviewblockinfo(getBloProductsRqBO);

                saveblockcomponentdetails.setViewblockdetails(viewblockResBo);
                logger.info("Inside Component Block Ends");
            }
        } catch (MalformedURLException e) {
            logger.info("Inside Malformed URL");
            exceptionBO = new ExceptionBO();
            exceptionBO.setErrorFrom(NGEConstants.GET_BLOCKED_INFO_SERVICE);
            exceptionBO.setErrorMessage(e.getMessage());
            exceptionBO.setErrorType(NGEConstants.FATAL);
            logger.info("NGEUIException", e);
        } catch (GetBlockedInfoAIGCIExceptionTypeMsg e) {
            logger.info("Inside Service URL");
            exceptionBO = new ExceptionBO();
            exceptionBO.setErrorFrom(NGEConstants.GET_BLOCKED_INFO_SERVICE);
            exceptionBO.setErrorMessage(seti18ErroMessage(e.getFaultInfo()
                    .getErrorCode()));
            exceptionBO.setErrorCode(NGEConstants.FAILURE_CODE);
            exceptionBO.setErrorType(e.getFaultInfo().getErrorType());
            blockedInfoRows.setRows(blockedRows);
            releasedInfoRows.setRows(releasedRows);
            blockedInfo.setBlocked(blockedInfoRows);
            blockedInfo.setReleased(releasedInfoRows);
            logger.info("NGEUIException", e);
        } catch (NumberFormatException e) {
            exceptionBO = new ExceptionBO();
            exceptionBO.setErrorFrom(NGEConstants.GET_BLOCKED_INFO_SERVICE);
            exceptionBO
                    .setErrorMessage(seti18ErroMessage(NGEConstants.INVALID_BLOCK_NUMBER_FORMAT));
            exceptionBO.setErrorCode(NGEConstants.FAILURE_CODE);
            exceptionBO.setErrorType(NGEConstants.FATAL);
            logger.info("NGEUIException", e);
        } catch (Exception e) {
            exceptionBO = new ExceptionBO();
            exceptionBO.setErrorFrom(NGEConstants.GET_BLOCKED_INFO_SERVICE);
            exceptionBO
                    .setErrorMessage(seti18ErroMessage(NGEConstants.ERROR_INVOKING_SERVICE));
            exceptionBO.setErrorType(NGEConstants.FATAL);
            logger.info("NGEUIException", e);
        }
        ObjectWriter ow = new ObjectMapper().writer()
                .withDefaultPrettyPrinter();
        String json1 = "";
        String viewblockJson = "";
        String blockRequestJson = "";

        if (exceptionBO == null) {
            jsonHeaderBO = setJsonHeader(sequenceNo, NGEConstants.SUCCESS_CODE,
                    NGEConstants.SUCCESS, i18SuccessMessage, blockedInfo);
        } else {
            jsonHeaderBO = setJsonHeader(sequenceNo,
                    exceptionBO.getErrorType(), NGEConstants.FAILURE,
                    exceptionBO.getErrorMessage(), blockedInfo);
        }
        try {
            json1 = ow.writeValueAsString(jsonHeaderBO);
            if (getBloProductsRqBO != null) {
                blockRequestJson = ow.writeValueAsString(getBloProductsRqBO);
            }
            if (getBloProductsRqBO != null && null != getBloProductsRqBO.getBlockingComponentProduct()) {
                viewblockJson = ow.writeValueAsString(saveblockcomponentdetails);
            }
        } catch (JsonProcessingException e) {
            // TODO Auto-generated catch block
            logger.info("NGEUIException", e);
        }
        session = request.getSession(false);
        if (null != session) {
            logger.info("****************************Setting Session Object for Blocked Info Details Starts********************");
            session.setAttribute(NGEConstants.SESSION_VIEW_BLOCKED_COMPONENTS_DETAILS, XSSValidator.stripXSSPattern(json1));
            if (getBloProductsRqBO != null && getBloProductsRqBO.getCallType() != null && getBloProductsRqBO.getCallType().equalsIgnoreCase(NGEConstants.INITIAL_BLOCK_SEARCH)) {
                session.setAttribute(NGEConstants.SESSION_BLOCK_DETAILS_INPUT, XSSValidator.stripXSSPattern(blockRequestJson));
            } else {
                session.setAttribute(NGEConstants.SESSION_BLOCK_DETAILS_INPUT, null);
            }

            //session = request.getSession(true);
            if (null != viewblockResBo) {
                logger.info("****************************Setting Session Object for View Blocked Info Details Starts********************");
                session.setAttribute(NGEConstants.SESSION_VIEW_COMPONENTS_DETAILS, XSSValidator.stripXSSPattern(viewblockJson));
                logger.info("****************************Setting Session Object for View Blocked Info Details Info Ends********************");
            }
            logger.info("****************************Setting Session Object for Blocked Info Details Ends********************");
        }
        return jsonHeaderBO;
    }

    @RequestMapping(value = "/getblockinginfo", headers = "Accept=application/json", method = RequestMethod.POST)
    public @ResponseBody
    JSONHeaderBO getBlockingInfo(
            @RequestBody GetBlockingInfoReqBO blockingInfoReqBO, HttpServletRequest request, HttpServletResponse response) throws IOException {
        HttpSession session = null;
        session = request.getSession(false);
        JSONHeaderBO jsonHeaderBO = new JSONHeaderBO();

        if (session == null || (session.getAttribute(NGEConstants.SESSION_CASL_USERID) == null)) {
            //logger.info("Invalid Session : "+session);
            response.sendRedirect("jsp/logout.jsp");
            return jsonHeaderBO;
        }
		/*else{
			logger.info("session : "+session);
		}*/
        SubmissionDataService serviceObj = new SubmissionDataService();
        serviceObj.setCaslServiceId((String) session.getAttribute(NGEConstants.SESSION_CASL_USERID));
        //GetBlockingInfoResBO blockingInfoResBO = null;
        ExceptionBO exceptionBO = null;
        SequenceNumberGeneration generateObj = new SequenceNumberGeneration();
        HashMap<String, String> sequenceNames = new HashMap<>();
        HashMap<String, Object> sequenceValueMap = new HashMap<String, Object>();
        sequenceNames.put("BLOCKING_INFO", "INT");
        sequenceValueMap = generateObj.getNextSequenceNumber(sequenceNames);
        GetBlockedInfoBlockStatus blockingInfo = new GetBlockedInfoBlockStatus();

        int sequenceNo = Integer.parseInt(sequenceValueMap.get("BLOCKING_INFO")
                .toString());
        try {
            //blockingInfoResBO = serviceObj.getBlockingInfo(blockingInfoReqBO);
            serviceObj.getBlockingInfo(blockingInfoReqBO);
            //blockingInfo = ServiceUtility.getBlockingInfoRows(blockingInfoResBO);
        } catch (MalformedURLException e) {
            exceptionBO = new ExceptionBO();
            exceptionBO.setErrorFrom(NGEConstants.GET_BLOCKING_INFO_SERVICE);
            exceptionBO.setErrorMessage(e.getMessage());
        } catch (GetBlockingInfoAIGCIExceptionTypeMsg e) {
            exceptionBO = new ExceptionBO();
            exceptionBO.setErrorFrom(NGEConstants.GET_BLOCKING_INFO_SERVICE);
            exceptionBO.setErrorMessage(e.getFaultInfo().getErrorMessage());
            exceptionBO.setErrorCode(e.getFaultInfo().getErrorCode());
            exceptionBO.setErrorType(e.getFaultInfo().getErrorType());
        } catch (Exception e) {
            exceptionBO = new ExceptionBO();
            exceptionBO.setErrorFrom(NGEConstants.GET_BLOCKING_INFO_SERVICE);
            exceptionBO
                    .setErrorMessage(seti18ErroMessage(NGEConstants.ERROR_INVOKING_SERVICE));
        }
        if (null == exceptionBO) {
            jsonHeaderBO = setJsonHeader(sequenceNo, NGEConstants.SUCCESS_CODE,
                    NGEConstants.SUCCESS,
                    NGEConstants.BLOCKING_INFO_SUCCESSFUL, blockingInfo);
        } else {
            jsonHeaderBO = setJsonHeader(sequenceNo,
                    exceptionBO.getErrorCode(), exceptionBO.getErrorType(),
                    exceptionBO.getErrorMessage(), blockingInfo);
        }
        String json1 = null;
        ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
        try {
            json1 = ow.writeValueAsString(jsonHeaderBO);
        } catch (JsonProcessingException e) {
            logger.info("NGEUIException", e);
        }

        logger.info("****************************Setting Session Object for Blocking Info Details Starts********************");
        session.setAttribute(NGEConstants.SESSION_VIEW_BLOCKING_COMPONENTS_DETAILS, XSSValidator.stripXSSPattern(json1));
        return jsonHeaderBO;
    }

    @RequestMapping(value = "/copyTransaction", headers = "Accept=application/json", method = RequestMethod.POST)
    public @ResponseBody
    JSONHeaderBO CopyTransaction(
            @RequestBody CopyTransactionBO copyTransactionBO, HttpServletRequest request, HttpServletResponse response) throws IOException {

        //binder.setAllowedFields("transactionId","transactionVersionNo","submissionNo");
        HttpSession session = null;
        session = request.getSession(false);
        JSONHeaderBO jsonHeaderBO = new JSONHeaderBO();

        if (session == null || (session.getAttribute(NGEConstants.SESSION_CASL_USERID) == null)) {
            //logger.info("Invalid Session : "+session);
            response.sendRedirect("jsp/logout.jsp");
            return jsonHeaderBO;
        }
		/*else{
			logger.info("session : "+session);
		}*/
        SubmissionManagementService serviceObj = new SubmissionManagementService();
        serviceObj.setCaslServiceId((String) session.getAttribute(NGEConstants.SESSION_CASL_USERID));
        SubmissionDataService serviceObj1 = new SubmissionDataService();
        serviceObj1.setCaslServiceId((String) session.getAttribute(NGEConstants.SESSION_CASL_USERID));
        CopyTransactionBO copyTransactionResBO = null;
        //CopyTransactionBO copyTransactionReqBO = new CopyTransactionBO();
        ExceptionBO exceptionBO = null;
        SequenceNumberGeneration generateObj = new SequenceNumberGeneration();
        HashMap<String, String> sequenceNames = new HashMap<>();
        HashMap<String, Object> sequenceValueMap = new HashMap<String, Object>();
        sequenceNames.put("COPY_TRANSACTION", "INT");
        sequenceValueMap = generateObj.getNextSequenceNumber(sequenceNames);
        int sequenceNo = Integer.parseInt(sequenceValueMap.get(
                "COPY_TRANSACTION").toString());
        //SubmissionRespUIBO submissionsList = new SubmissionRespUIBO();
        try {
            copyTransactionResBO = serviceObj
                    .copyTransaction(copyTransactionBO);
			/*submissionsList = serviceObj1.getSubmission(
					copyTransactionBO.getSubmissionNo(), null, null, null);*/

        } catch (MalformedURLException e) {
            exceptionBO = new ExceptionBO();
            exceptionBO.setErrorFrom(NGEConstants.COPY_TRANSACTION_SERVICE);
            exceptionBO.setErrorMessage(e.getMessage());
            exceptionBO.setErrorType(NGEConstants.FATAL);
        } catch (CopyTransactionAIGCIExceptionTypeMsg e) {
            logger.info("Inside Service Exception");
            exceptionBO = new ExceptionBO();
            exceptionBO.setErrorFrom(NGEConstants.COPY_TRANSACTION_SERVICE);
            exceptionBO.setErrorMessage(seti18ErroMessage(e.getFaultInfo()
                    .getErrorCode()));
            exceptionBO.setErrorCode(NGEConstants.FAILURE_CODE);
            exceptionBO.setErrorType(e.getFaultInfo().getErrorType());
            logger.info("NGEUIException", e);
        } catch (NumberFormatException e) {
            exceptionBO = new ExceptionBO();
            exceptionBO.setErrorFrom(NGEConstants.COPY_TRANSACTION_SERVICE);
            logger.info("NGEUIException", e);
            exceptionBO
                    .setErrorMessage(seti18ErroMessage(NGEConstants.INVALID_BLOCK_NUMBER_FORMAT));
            exceptionBO.setErrorCode(NGEConstants.FAILURE_CODE);
            exceptionBO.setErrorType(NGEConstants.FATAL);
        } catch (Exception e) {
            logger.info("Inside General Exception");
            exceptionBO = new ExceptionBO();
            exceptionBO.setErrorFrom(NGEConstants.COPY_TRANSACTION_SERVICE);
            exceptionBO
                    .setErrorMessage(seti18ErroMessage(NGEConstants.ERROR_INVOKING_SERVICE));
            exceptionBO.setErrorType(NGEConstants.FATAL);
        }
        if (null == exceptionBO) {
            jsonHeaderBO = setJsonHeader(sequenceNo, NGEConstants.SUCCESS_CODE,
                    NGEConstants.SUCCESS,
                    NGEConstants.COPY_TRANSACTION_SUCCESSFUL,
                    copyTransactionResBO);
        } else {
            jsonHeaderBO = setJsonHeader(sequenceNo,
                    exceptionBO.getErrorCode(), exceptionBO.getErrorType(),
                    exceptionBO.getErrorMessage(), copyTransactionResBO);
        }
        return jsonHeaderBO;
    }

    @RequestMapping(value = "/renewTransaction", headers = "Accept=application/json", method = RequestMethod.POST)
    public @ResponseBody
    JSONHeaderBO renewTransaction(
            @RequestBody ProductBO renewTransactionReq, HttpServletRequest request, HttpServletResponse response) throws IOException {
        HttpSession session = null;
        session = request.getSession(false);
        JSONHeaderBO jsonHeaderBO = new JSONHeaderBO();

        if (session == null || (session.getAttribute(NGEConstants.SESSION_CASL_USERID) == null)) {
            //logger.info("Invalid Session : "+session);
            response.sendRedirect("jsp/logout.jsp");
            return jsonHeaderBO;
        }
		/*else{
			logger.info("session : "+session);
		}*/
        SubmissionManagementService serviceObj = new SubmissionManagementService();
        serviceObj.setCaslServiceId((String) session.getAttribute(NGEConstants.SESSION_CASL_USERID));
        RenewTransactionBO renewTransactionRes = new RenewTransactionBO();
        ExceptionBO exceptionBO = null;
        SequenceNumberGeneration generateObj = new SequenceNumberGeneration();
        HashMap<String, String> sequenceNames = new HashMap<>();
        HashMap<String, Object> sequenceValueMap = new HashMap<String, Object>();
        sequenceNames.put("RENEW_TRANSACTION", "INT");
        sequenceValueMap = generateObj.getNextSequenceNumber(sequenceNames);
        int sequenceNo = Integer.parseInt(sequenceValueMap.get(
                "RENEW_TRANSACTION").toString());
        try {
            renewTransactionRes = serviceObj
                    .RenewTrasaction(renewTransactionReq);
        } catch (MalformedURLException e) {
            exceptionBO = new ExceptionBO();
            exceptionBO.setErrorFrom(NGEConstants.RENEW_TRANSACTION_SERVICE);
            exceptionBO.setErrorMessage(e.getMessage());
            exceptionBO.setErrorType(NGEConstants.FATAL);
        } catch (RenewTransactionAIGCIExceptionTypeMsg e) {
            logger.info("Inside Service Exception");
            exceptionBO = new ExceptionBO();
            exceptionBO.setErrorFrom(NGEConstants.RENEW_TRANSACTION_SERVICE);
            exceptionBO.setErrorMessage(seti18ErroMessage(e.getFaultInfo()
                    .getErrorCode()));
            exceptionBO.setErrorCode(NGEConstants.FAILURE_CODE);
            exceptionBO.setErrorType(e.getFaultInfo().getErrorType());
            logger.info("NGEUIException", e);
        } catch (NumberFormatException e) {
            exceptionBO = new ExceptionBO();
            exceptionBO.setErrorFrom(NGEConstants.RENEW_TRANSACTION_SERVICE);
            logger.info("NGEUIException", e);
            exceptionBO
                    .setErrorMessage(seti18ErroMessage(NGEConstants.ERROR_PROCESSING_REQUEST));
            exceptionBO.setErrorCode(NGEConstants.FAILURE_CODE);
            exceptionBO.setErrorType(NGEConstants.FATAL);
        } catch (Exception e) {
            logger.info("Inside General Exception");
            exceptionBO = new ExceptionBO();
            exceptionBO.setErrorFrom(NGEConstants.RENEW_TRANSACTION_SERVICE);
            exceptionBO
                    .setErrorMessage(seti18ErroMessage(NGEConstants.ERROR_INVOKING_SERVICE));
            exceptionBO.setErrorType(NGEConstants.FATAL);
        }
        if (null == exceptionBO) {
            jsonHeaderBO = setJsonHeader(sequenceNo, NGEConstants.SUCCESS_CODE,
                    NGEConstants.SUCCESS,
                    NGEConstants.RENEW_TRANSACTION_SUCCESSFUL,
                    renewTransactionRes);
        } else {
            jsonHeaderBO = setJsonHeader(sequenceNo,
                    exceptionBO.getErrorCode(), exceptionBO.getErrorType(),
                    exceptionBO.getErrorMessage(), renewTransactionRes);
        }
        return jsonHeaderBO;
    }

    @RequestMapping(value = "/releaseAlertBlock", headers = "Accept=application/json", method = RequestMethod.POST)
    public @ResponseBody
    JSONHeaderBO releaseAlertBlock(@RequestBody ReleaseAlertBlockReqBO releaseAlertBlockReqBO,
                                   HttpServletRequest request, HttpServletResponse response) throws IOException {
        HttpSession session = null;
        session = request.getSession(false);
        JSONHeaderBO jsonHeaderBO = new JSONHeaderBO();

        if (session == null || (session.getAttribute(NGEConstants.SESSION_CASL_USERID) == null)) {
            //logger.info("Invalid Session : "+session);
            response.sendRedirect("jsp/logout.jsp");
            return jsonHeaderBO;
        }
		/*else{
			logger.info("session : "+session);
		}*/
        ExceptionBO exceptionBO = null;
        HeaderStatusTypeBO headerStatusTypeBO = new HeaderStatusTypeBO();
        SequenceNumberGeneration generateObj = new SequenceNumberGeneration();
        HashMap<String, String> sequenceNames = new HashMap<>();
        HashMap<String, Object> sequenceValueMap = new HashMap<String, Object>();
        sequenceNames.put("RELEASE_ALERT_BLOCK", "INT");
        sequenceValueMap = generateObj.getNextSequenceNumber(sequenceNames);
        int sequenceNo = Integer.parseInt(sequenceValueMap.get("RELEASE_ALERT_BLOCK")
                .toString());
        SubmissionManagementService serviceObj = new SubmissionManagementService();
        serviceObj.setCaslServiceId((String) session.getAttribute(NGEConstants.SESSION_CASL_USERID));
        String i18SuccessMessage = null;
        try {
            headerStatusTypeBO = serviceObj.releaseAlertBlock(releaseAlertBlockReqBO);
            i18SuccessMessage = seti18ErroMessage(NGEConstants.RELEASE_ALERT_PRODUCT_BLOCK_SUCCESSFUL);
        } catch (MalformedURLException e) {
            exceptionBO = new ExceptionBO();
            exceptionBO.setErrorFrom(NGEConstants.RELEASE_BLOCK_SERVICE);
            logger.info("NGEUIException", e);
            exceptionBO
                    .setErrorMessage(seti18ErroMessage(NGEConstants.MALFORMED_URL));
            exceptionBO.setErrorCode(NGEConstants.FAILURE_CODE);
        } catch (ManageProductsAIGCIExceptionTypeMsg e) {
            exceptionBO = new ExceptionBO();
            exceptionBO.setErrorFrom(NGEConstants.ALERT_RELEASE_BLOCK_SERVICE);
            exceptionBO.setErrorMessage(seti18ErroMessage(e.getFaultInfo()
                    .getErrorCode()));
            exceptionBO.setErrorCode(NGEConstants.FAILURE_CODE);
            exceptionBO.setErrorType(e.getFaultInfo().getErrorType());
            logger.info("NGEUIException", e);
        } catch (com.aig.nge.utilities.AIGCIExceptionMsg e) {
            exceptionBO = new ExceptionBO();
            exceptionBO.setErrorFrom(NGEConstants.ALERT_RELEASE_BLOCK_SERVICE);
            exceptionBO
                    .setErrorMessage(NGEConstants.INTERNAL_APPLICATION_ERROR);
            exceptionBO.setErrorCode(NGEConstants.FAILURE_CODE);
            exceptionBO.setErrorType(NGEConstants.FATAL);
            logger.info("NGEUIException", e);
        }
        if (exceptionBO == null) {
            jsonHeaderBO = setJsonHeader(sequenceNo, NGEConstants.SUCCESS_CODE,
                    NGEConstants.SUCCESS, i18SuccessMessage, headerStatusTypeBO);
        } else {
            jsonHeaderBO = setJsonHeader(sequenceNo,
                    exceptionBO.getErrorType(), NGEConstants.FAILURE,
                    exceptionBO.getErrorMessage(), headerStatusTypeBO);
        }
        return jsonHeaderBO;
    }

    @RequestMapping(value = "/releaseBlock", headers = "Accept=application/json", method = RequestMethod.POST)
    public @ResponseBody
    JSONHeaderBO releaseBlock(@RequestBody BlockReleaseBO releaseBlockReqBO, HttpServletRequest request, HttpServletResponse response) throws IOException {
        HttpSession session = null;
        session = request.getSession(false);
        JSONHeaderBO jsonHeaderBO = new JSONHeaderBO();
        if (session == null || (session.getAttribute(NGEConstants.SESSION_CASL_USERID) == null)) {
            //logger.info("Invalid Session : "+session);
            response.sendRedirect("jsp/logout.jsp");
            return jsonHeaderBO;
        }
		/*else{
			logger.info("session : "+session);
		}*/
        ExceptionBO exceptionBO = null;
        HeaderStatusTypeBO headerStatusTypeBO = new HeaderStatusTypeBO();
        SequenceNumberGeneration generateObj = new SequenceNumberGeneration();
        HashMap<String, String> sequenceNames = new HashMap<>();
        HashMap<String, Object> sequenceValueMap = new HashMap<String, Object>();
        sequenceNames.put("RELEASE_BLOCK", "INT");
        sequenceValueMap = generateObj.getNextSequenceNumber(sequenceNames);
        int sequenceNo = Integer.parseInt(sequenceValueMap.get("RELEASE_BLOCK")
                .toString());
        SubmissionManagementService serviceObj = new SubmissionManagementService();
        serviceObj.setCaslServiceId((String) session.getAttribute(NGEConstants.SESSION_CASL_USERID));
        String i18SuccessMessage = null;
        try {
            headerStatusTypeBO = serviceObj.releaseBlock(releaseBlockReqBO);
            i18SuccessMessage = seti18ErroMessage(NGEConstants.RELEASE_PRODUCT_BLOCK_SUCCESSFUL);
        } catch (MalformedURLException e) {
            exceptionBO = new ExceptionBO();
            exceptionBO.setErrorFrom(NGEConstants.RELEASE_BLOCK_SERVICE);
            logger.info("NGEUIException", e);
            exceptionBO
                    .setErrorMessage(seti18ErroMessage(NGEConstants.MALFORMED_URL));
            exceptionBO.setErrorCode(NGEConstants.FAILURE_CODE);
        } catch (ManageProductsAIGCIExceptionTypeMsg e) {
            exceptionBO = new ExceptionBO();
            exceptionBO.setErrorFrom(NGEConstants.RELEASE_BLOCK_SERVICE);
            exceptionBO.setErrorMessage(seti18ErroMessage(e.getFaultInfo()
                    .getErrorCode()));
            exceptionBO.setErrorCode(NGEConstants.FAILURE_CODE);
            exceptionBO.setErrorType(e.getFaultInfo().getErrorType());
            logger.info("NGEUIException", e);
        } catch (com.aig.nge.utilities.AIGCIExceptionMsg e) {
            exceptionBO = new ExceptionBO();
            exceptionBO.setErrorFrom(NGEConstants.RELEASE_BLOCK_SERVICE);
            exceptionBO
                    .setErrorMessage(NGEConstants.INTERNAL_APPLICATION_ERROR);
            exceptionBO.setErrorCode(NGEConstants.FAILURE_CODE);
            exceptionBO.setErrorType(NGEConstants.FATAL);
            logger.info("NGEUIException", e);
        }
        if (exceptionBO == null) {
            jsonHeaderBO = setJsonHeader(sequenceNo, NGEConstants.SUCCESS_CODE,
                    NGEConstants.SUCCESS, i18SuccessMessage, headerStatusTypeBO);
        } else {
            jsonHeaderBO = setJsonHeader(sequenceNo,
                    exceptionBO.getErrorType(), NGEConstants.FAILURE,
                    exceptionBO.getErrorMessage(), headerStatusTypeBO);
        }
        return jsonHeaderBO;
    }


    @RequestMapping(value = "/reserveProduct", headers = "Accept=application/json", method = RequestMethod.POST)
    public @ResponseBody
    JSONHeaderBO reserveProducts(HttpServletRequest request, @RequestBody List<ProductBO> reserveProductReq, HttpServletResponse response) throws IOException {
        HttpSession session = null;
        session = request.getSession(false);
        JSONHeaderBO jsonHeaderBO = new JSONHeaderBO();

        if (session == null || (session.getAttribute(NGEConstants.SESSION_CASL_USERID) == null)) {
            //logger.info("Invalid Session : "+session);
            response.sendRedirect("jsp/logout.jsp");
            return jsonHeaderBO;
        }
		/*else{
			logger.info("session : "+session);
		}*/
        SubmissionManagementService serviceObj = new SubmissionManagementService();
        serviceObj.setCaslServiceId((String) session.getAttribute(NGEConstants.SESSION_CASL_USERID));
        List<ReserveProductsRsBO> reserveProductsResponse = new ArrayList<ReserveProductsRsBO>();
        ExceptionBO exceptionBO = null;
        SequenceNumberGeneration generateObj = new SequenceNumberGeneration();
        HashMap<String, String> sequenceNames = new HashMap<>();
        HashMap<String, Object> sequenceValueMap = new HashMap<String, Object>();
        sequenceNames.put("RESERVE_PRODUCT", "INT");
        sequenceValueMap = generateObj.getNextSequenceNumber(sequenceNames);
        int sequenceNo = Integer.parseInt(sequenceValueMap.get(
                "RESERVE_PRODUCT").toString());
		/*List<ProductBO> testRq = new ArrayList<ProductBO>();
		ProductBO testBo = new ProductBO();
		testBo.setTransactionId("1212");
		testBo.setProductTowerCd("6");
		testBo.setMarketableProductCd("BUM1");
		testBo.setComponentProductCd("PRDL");
		testBo.setCurrencyCd("USD");
		testRq.add(testBo);*/
        try {
            reserveProductsResponse = serviceObj.reserveProducts(reserveProductReq);
            //reserveProductsResponse = serviceObj.reserveProducts(testRq);
        } catch (ReserveProductAIGCIExceptionTypeMsg e) {
            exceptionBO = new ExceptionBO();
            exceptionBO.setErrorFrom(NGEConstants.RESERVE_PRODUCT_SERVICE);
            exceptionBO.setErrorMessage(seti18ErroMessage(e.getFaultInfo()
                    .getErrorCode()));
            exceptionBO.setErrorCode(NGEConstants.FAILURE_CODE);
            exceptionBO.setErrorType(e.getFaultInfo().getErrorType());
            logger.info("NGEUIException", e);
        } catch (MalformedURLException e) {
            exceptionBO = new ExceptionBO();
            exceptionBO.setErrorFrom(NGEConstants.RESERVE_PRODUCT_SERVICE);
            exceptionBO.setErrorMessage(e.getMessage());
            exceptionBO.setErrorType(NGEConstants.FATAL);
        } catch (NumberFormatException e) {
            exceptionBO = new ExceptionBO();
            exceptionBO.setErrorFrom(NGEConstants.RESERVE_PRODUCT_SERVICE);
            logger.info("NGEUIException", e);
            exceptionBO
                    .setErrorMessage(seti18ErroMessage(NGEConstants.ERROR_PROCESSING_REQUEST));
            exceptionBO.setErrorCode(NGEConstants.FAILURE_CODE);
            exceptionBO.setErrorType(NGEConstants.FATAL);
        } catch (Exception e) {
            exceptionBO = new ExceptionBO();
            exceptionBO.setErrorFrom(NGEConstants.GET_BLOCKED_INFO_SERVICE);
            exceptionBO
                    .setErrorMessage(seti18ErroMessage(NGEConstants.ERROR_INVOKING_SERVICE));
            exceptionBO.setErrorType(NGEConstants.FATAL);
        }
        if (null == exceptionBO) {

            if (session.getAttribute(NGEConstants.FROM_PAGE) != null && ((String) session.getAttribute(NGEConstants.FROM_PAGE)).equals("underwriterdiary")) {
                session.setAttribute(NGEConstants.UPDATE_EVENT_REFRESH_PAGE, XSSValidator.stripXSS("true"));
            }
            jsonHeaderBO = setJsonHeader(sequenceNo, NGEConstants.SUCCESS_CODE,
                    NGEConstants.SUCCESS,
                    NGEConstants.RESERVE_PRODUCT_SUCCESSFUL,
                    reserveProductsResponse);
        } else {
            jsonHeaderBO = setJsonHeader(sequenceNo,
                    exceptionBO.getErrorCode(), exceptionBO.getErrorType(),
                    exceptionBO.getErrorMessage(), reserveProductsResponse);
        }
        return jsonHeaderBO;
    }

    @RequestMapping(value = "/bulkTransfer", headers = "Accept=application/json", method = RequestMethod.POST)
    public @ResponseBody
    JSONHeaderBO bulkTransfer(@RequestBody BulkTransferRequestBO request, HttpServletRequest servRequest, HttpServletResponse response) throws IOException {

        HttpSession session = null;
        session = servRequest.getSession(false);
        JSONHeaderBO jsonHeaderBO = new JSONHeaderBO();

        if (session == null || (session.getAttribute(NGEConstants.SESSION_CASL_USERID) == null)) {
            //logger.info("Invalid Session : "+session);
            response.sendRedirect("jsp/logout.jsp");
            return jsonHeaderBO;
        }
		/*else{
			logger.info("session : "+session);
		}*/
        SubmissionManagementService serviceObj = new SubmissionManagementService();
        serviceObj.setCaslServiceId((String) session.getAttribute(NGEConstants.SESSION_CASL_USERID));
        ExceptionBO exceptionBO = null;
        NGEViewOfMessageBO bulkTransferResponse = new NGEViewOfMessageBO();
        SequenceNumberGeneration generateObj = new SequenceNumberGeneration();
        HashMap<String, String> sequenceNames = new HashMap<>();
        HashMap<String, Object> sequenceValueMap = new HashMap<String, Object>();
        sequenceNames.put("BULK_TRANSFER", "INT");
        sequenceValueMap = generateObj.getNextSequenceNumber(sequenceNames);
        int sequenceNo = Integer.parseInt(sequenceValueMap.get("BULK_TRANSFER").toString());
        String bulkTransferMessageCode = "";
        //String bulkTransferResponseCode = "";
        try {
            bulkTransferResponse = serviceObj.bulkTransferService(request);
            bulkTransferMessageCode = bulkTransferResponse.getMessageCode();
            if (null != bulkTransferResponse.getResponse()) {
                // bulkTransferResponseCode = bulkTransferResponse.getResponse().getResponseCode();
                if (bulkTransferMessageCode.equalsIgnoreCase(NGEConstants.SERVICE_ERROR_MESSAGE_CODE)) {
                    exceptionBO = new ExceptionBO();
                    exceptionBO.setErrorFrom(NGEConstants.BULK_TRANSFER_SERVICE);
                    exceptionBO.setErrorMessage(seti18ErroMessage(NGEConstants.ERROR_BULK_TRANSFER));
                    exceptionBO.setErrorCode(NGEConstants.FAILURE_CODE);
                    exceptionBO.setErrorType(NGEConstants.FATAL);
                }
            }

        } catch (BulkTransferAIGCIExceptionTypeMsg e) {
            exceptionBO = new ExceptionBO();
            exceptionBO.setErrorFrom(NGEConstants.BULK_TRANSFER_SERVICE);
            exceptionBO.setErrorMessage(seti18ErroMessage(e.getFaultInfo().getErrorCode()));
            exceptionBO.setErrorCode(NGEConstants.FAILURE_CODE);
            exceptionBO.setErrorType(e.getFaultInfo().getErrorType());
            logger.info("NGEUIException", e);
        } catch (MalformedURLException e) {
            exceptionBO = new ExceptionBO();
            exceptionBO.setErrorFrom(NGEConstants.BULK_TRANSFER_SERVICE);
            exceptionBO.setErrorMessage(e.getMessage());
            exceptionBO.setErrorType(NGEConstants.FATAL);
        } catch (Exception e) {
            exceptionBO = new ExceptionBO();
            exceptionBO.setErrorFrom(NGEConstants.BULK_TRANSFER_SERVICE);
            exceptionBO.setErrorMessage(seti18ErroMessage(NGEConstants.ERROR_INVOKING_SERVICE));
            exceptionBO.setErrorType(NGEConstants.FATAL);
        }
        if (null == exceptionBO) {
            jsonHeaderBO = setJsonHeader(sequenceNo, NGEConstants.SUCCESS_CODE, NGEConstants.SUCCESS, seti18ErroMessage(NGEConstants.BULK_TRANSFER_SUCCESSFUL), bulkTransferResponse);
        } else {
            jsonHeaderBO = setJsonHeader(sequenceNo, exceptionBO.getErrorCode(), exceptionBO.getErrorType(), exceptionBO.getErrorMessage(), bulkTransferResponse);
        }
        return jsonHeaderBO;
    }

    @RequestMapping(value = "/getaccount", headers = "Accept=application/json", method = RequestMethod.POST)
    public @ResponseBody
    JSONHeaderBO getAccount(@RequestBody GetAccountReqBO getAccountReqBO) {
        AccountService serviceObj = new AccountService();
        GetAccountRespBO getAccountRespBO = null;
        AccountInfoUIBO accountInfo = null;
        ExceptionBO exceptionBO = null;
        JSONHeaderBO jsonHeaderBO = new JSONHeaderBO();
        SequenceNumberGeneration generateObj = new SequenceNumberGeneration();
        HashMap<String, String> sequenceNames = new HashMap<>();
        HashMap<String, Object> sequenceValueMap = new HashMap<String, Object>();
        sequenceNames.put("GET_ACCOUNT", "INT");
        sequenceValueMap = generateObj.getNextSequenceNumber(sequenceNames);
        int sequenceNo = Integer.parseInt(sequenceValueMap.get("GET_ACCOUNT")
                .toString());
        try {
            getAccountRespBO = serviceObj.getAccount(getAccountReqBO);
            accountInfo = ManageProductsServiceHandler.setAccountInfo(getAccountRespBO);
        } catch (MalformedURLException e) {
            exceptionBO = new ExceptionBO();
            exceptionBO.setErrorFrom(NGEConstants.GET_ACCOUNT_SERVICE);
            exceptionBO.setErrorMessage(e.getMessage());
        } catch (AIGCIExceptionMsg e) {
            exceptionBO = new ExceptionBO();
            exceptionBO.setErrorFrom(NGEConstants.GET_ACCOUNT_SERVICE);
            exceptionBO.setErrorMessage(seti18ErroMessage(e.getFaultInfo()
                    .getErrorCode()));
            exceptionBO.setErrorCode(NGEConstants.FAILURE_CODE);
            exceptionBO.setErrorType(e.getFaultInfo().getErrorType());
        } catch (AccountServiceExceptionMsg e) {
            exceptionBO = new ExceptionBO();
            exceptionBO.setErrorFrom(NGEConstants.GET_ACCOUNT_SERVICE);
            exceptionBO.setErrorMessage(e.getFaultInfo().getErrorMessage());
            exceptionBO.setErrorCode(e.getFaultInfo().getErrorCode());
            exceptionBO.setErrorType(e.getFaultInfo().getErrorType());
        } catch (Exception e) {
            exceptionBO = new ExceptionBO();
            exceptionBO.setErrorFrom(NGEConstants.GET_ACCOUNT_SERVICE);
            exceptionBO.setErrorMessage(e.getMessage());
        }
        if (null != getAccountRespBO && null != getAccountRespBO.getResponse()
                && null != getAccountRespBO.getResponse().getErrors()
                && null != getAccountRespBO.getResponse().getErrors().getMessage()
                && null != getAccountRespBO.getResponse().getErrors().getMessage().get(0)) {
            exceptionBO = new ExceptionBO();
            exceptionBO.setErrorFrom(NGEConstants.GET_ACCOUNT_SERVICE);
            exceptionBO.setErrorMessage(getAccountRespBO.getResponse().getErrors().getMessage().get(0).getValue());
            exceptionBO.setErrorCode(getAccountRespBO.getResponse().getErrors().getMessage().get(0).getNumber());
            exceptionBO.setErrorType(getAccountRespBO.getResponse().getErrors().getMessage().get(0).getType());
        }

        if (null == exceptionBO) {
            jsonHeaderBO = setJsonHeader(sequenceNo, NGEConstants.SUCCESS_CODE,
                    NGEConstants.SUCCESS, NGEConstants.GET_ACCOUNT_SUCCESSFUL,
                    accountInfo);
        } else {
            jsonHeaderBO = setJsonHeader(sequenceNo,
                    exceptionBO.getErrorCode(), exceptionBO.getErrorType(),
                    exceptionBO.getErrorMessage(), accountInfo);
        }
        return jsonHeaderBO;
    }

    /* 2021 MDM Changes - Starts */
    @RequestMapping(value = "/getMDMPartyDetails", headers = "Accept=application/json", method = RequestMethod.POST)
    public @ResponseBody
	JSONHeaderBO getMDMPartyDetails(@RequestBody MDMGetPartyRequest mdmGetPartyRequest
				       ,HttpServletRequest request) { /* F56355 - Modify request parameter names for MDM services */ 
        MDMGetPartyResponse mdmGetPartyResponse = null;
        JSONHeaderBO jsonHeaderBO = new JSONHeaderBO();
        logger.info("getMDMPartyDetails : BEGIN");
        this.restTemplate = new RestTemplate();
        String reponseJSON = "";
        SequenceNumberGeneration generateObj = new SequenceNumberGeneration();
        HashMap<String, String> sequenceNames = new HashMap<>();
        HashMap<String, Object> sequenceValueMap = new HashMap<String, Object>();
        sequenceNames.put("GET_MDM_ACCOUNT", "INT");
        sequenceValueMap = generateObj.getNextSequenceNumber(sequenceNames);
        int sequenceNo = Integer.parseInt(sequenceValueMap.get("GET_MDM_ACCOUNT")
                .toString());

        try {

            NGEProperties ngeProperties = new NGEProperties();
				/* F56355 - Modify request parameter names for MDM services - starts */
				HttpSession session = null;
				session = request.getSession(false);
				if(session!=null && session.getAttribute(NGEConstants.SESSION_CASL_USERID)!=null){
					mdmGetPartyRequest.setOriginuser((String)session.getAttribute(NGEConstants.SESSION_CASL_USERID));
				}
				else
				{
					mdmGetPartyRequest.setOriginuser(NGEConstants.USER_ID);
				}
				mdmGetPartyRequest.setOriginatingsystem(NGEConstants.APPLICATION_ID);
				/* F56355 - Modify request parameter names for MDM services - ends */
            String mdmUrl = ngeProperties.readMessageFromFile(NGEConstants.MDM_GET_DETAILS_URI, NGEConstants.CONFIG_FILE_NAME, true);
            UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(mdmUrl);
            HttpHeaders requestHeader = setRequestHeader();

            ObjectMapper objectMapper = new ObjectMapper();

            String requestJSON = objectMapper.writeValueAsString(mdmGetPartyRequest);

            HttpEntity<String> requestEntity = new HttpEntity<>(requestJSON, requestHeader);

            long startTime = System.currentTimeMillis();

			    ResponseEntity<MDMGetPartyResponse> responseEntity = this.restTemplate.exchange(builder.toUriString(), 
                    HttpMethod.POST, requestEntity, MDMGetPartyResponse.class);
            HttpStatus httpStatus = responseEntity.getStatusCode();
            long elapsedTime = System.currentTimeMillis() - startTime;

            if (httpStatus.series() == HttpStatus.Series.SUCCESSFUL) {
                logger.debug("STATUS OK!!");
                mdmGetPartyResponse = responseEntity.getBody();
                reponseJSON = objectMapper.writeValueAsString(mdmGetPartyResponse);
                logger.info("getParty - MDM api url - " + mdmUrl + ", requestJSON: " + requestJSON + " ,reponseJSON: " + reponseJSON + " , api call completed in: " +
                        elapsedTime + " milliseconds");
            }

            jsonHeaderBO = setJsonHeader(sequenceNo, NGEConstants.SUCCESS_CODE,
                    NGEConstants.SUCCESS, NGEConstants.GET_ACCOUNT_SUCCESSFUL,
                    reponseJSON);

        } catch (Exception e) {

            logger.error("getMDMPartyDetails exception: " + e.getMessage());
            e.printStackTrace();
        }
        logger.info("getMDMPartyDetails :: END");
        return jsonHeaderBO;
    }
    /* 2021 MDM Changes - Ends */
/*
	@RequestMapping(value = "/findaccount", headers = "Accept=application/json", method = RequestMethod.GET)
	public @ResponseBody
	JSONHeaderBO findAccount(@RequestBody FindAccountReqBO findAccountReqBO) {
		AccountService serviceObj = new AccountService();
		FindAccountRespBO findAccountRespBO = null;
		JSONHeaderBO jsonHeaderBO = new JSONHeaderBO();
		ExceptionBO exceptionBO = null;
		SequenceNumberGeneration generateObj = new SequenceNumberGeneration();
		HashMap<String, String> sequenceNames = new HashMap<>();
		HashMap<String, Object> sequenceValueMap = new HashMap<String, Object>();
		sequenceNames.put("FIND_ACCOUNT", "INT");
		sequenceValueMap = generateObj.getNextSequenceNumber(sequenceNames);
		int sequenceNo = Integer.parseInt(sequenceValueMap.get("FIND_ACCOUNT")
				.toString());
		try {
			findAccountRespBO = serviceObj.findAccount(findAccountReqBO);
		} catch (MalformedURLException e) {
			exceptionBO = new ExceptionBO();
			exceptionBO.setErrorFrom(NGEConstants.FIND_ACCOUNT_SERVICE);
			exceptionBO.setErrorMessage(e.getMessage());
		} catch (ReserveProductAIGCIExceptionTypeMsg e) {
			exceptionBO = new ExceptionBO();
			exceptionBO.setErrorFrom(NGEConstants.FIND_ACCOUNT_SERVICE);
			exceptionBO.setErrorMessage(e.getFaultInfo().getErrorMessage());
			exceptionBO.setErrorCode(e.getFaultInfo().getErrorCode());
			exceptionBO.setErrorType(e.getFaultInfo().getErrorType());
		} catch (Exception e) {
			exceptionBO = new ExceptionBO();
			exceptionBO.setErrorFrom(NGEConstants.FIND_ACCOUNT_SERVICE);
			exceptionBO.setErrorMessage(e.getMessage());
		}
		if (null == exceptionBO) {
			jsonHeaderBO = setJsonHeader(sequenceNo, NGEConstants.SUCCESS_CODE,
					NGEConstants.SUCCESS, NGEConstants.FIND_ACCOUNT_SUCCESSFUL,
					findAccountRespBO);
		} else {
			jsonHeaderBO = setJsonHeader(sequenceNo,
					exceptionBO.getErrorCode(), exceptionBO.getErrorType(),
					exceptionBO.getErrorMessage(), findAccountRespBO);
		}
		return jsonHeaderBO;
	}
*/

    /**
     * @throws ServletException
     * @throws ServiceAccessException
     */
    public CASLAuthorizeBO CASLauthorize(javax.servlet.http.HttpServletRequest request, String smuserid)
            throws ServletException, ServiceAccessException {

        String userId = null;
        userId = smuserid;
        String usersEmailId = null;
        logger.info("Entering into the PerformTask method");
        StringBuilder desigBuffer = new StringBuilder();
        NGEProperties ngeProperties = new NGEProperties();
        String userName = null;
        CASLactionBO action = new CASLactionBO();
        List<CASLactionBO> actionlist = new ArrayList<CASLactionBO>();
        CASLAuthorizeBO authorize = new CASLAuthorizeBO();
        CASLuserapplicationdetailsBO userappDet = new CASLuserapplicationdetailsBO();
        List<CASLuserapplicationdetailsBO> userappDetlist = new ArrayList<CASLuserapplicationdetailsBO>();
        CASLUserdataBO userdata = new CASLUserdataBO();
        List<CASLUserdataBO> userdatalist = new ArrayList<CASLUserdataBO>();
        CASLuserroleBO userrole = new CASLuserroleBO();
        List<CASLuserroleBO> userrolelist = new ArrayList<CASLuserroleBO>();
/*		List<CASLuserapplicationdetailsBO> userAppDet = new ArrayList<CASLuserapplicationdetailsBO>();
		boolean ismanager = false;
		boolean isunderwriter = false;*/
        try {

            caslServiceURL = ngeProperties.readMessageFromFile(
                    NGEConstants.CASL_SERVICE_URL,
                    NGEConstants.CONFIG_FILE_NAME, true);
//            caslServiceURL = "https://caslsvc-qa.aig.net:15021/CASLServicesWeb/services/CASLExtConsumingServicesPort";
            logger.info("CASL interface URL is : " + caslServiceURL);
            caslServiceAccess = new ServiceAccess(caslServiceURL);
        } catch (Exception e) {
            logger.info("NGEUIException", e);
        }
        //if (!securityByPassRegions.containsKey(regionVariable)) {

        //HttpSession session = request.getSession(true);
        //HttpSession rsession = request.getSession(true);

			/*if (request.getParameter("iniUserid") != null) {
				userId = request.getParameter("iniUserid").trim();
				userId = userId.toLowerCase();
			}
		} else {
			userId = request.getHeader(siteMinderUserIdHeader);
			if (userId != null) {
				userId = userId.trim();
			}
			userId = userId.toLowerCase();
			logger.info("User ID from siteminder" + userId);
		}*/
        //userId = "9000238";
		/*HttpSession session = request.getSession();
		if (session == null) {
			session = request.getSession(true);
			logger.info("Session Failure");
		} else {
			if (session.getAttribute("USER_ID") != null && userId != null
					&& !userId.equals((String) session.getAttribute("USER_ID"))) {
				session.invalidate();
				session = request.getSession(true);
				logger.info("Session and User ID is having values");
			}
		}*/
		/*logger.info("session.getId() in Policy Action controller = "
				+ session.getId());
		logger.info("session.getCreationTime() in Policy Action controller = "
				+ session.getCreationTime());
		logger.info("session.getMaxInactiveInterval() in Policy Action controller = "
				+ session.getMaxInactiveInterval());
		logger.info("session.getLastAccessedTime() in Policy Action controller = "
				+ session.getLastAccessedTime());*/
        logger.info("User......Authorization");
        List<String> dataCatList = new ArrayList<String>();

		/*UserStatusRespType statusRespType = caslServiceAccess.getUserStatus(
				NGEConstants.CASL_USER_ID_ATTR_NM, userId);
		logger.info("nternal Users......Authorization statusRespType  : "
				+ statusRespType);
		if (statusRespType != null && statusRespType.getUserStatus() != null
				&& statusRespType.getEmployeeId() != null) {
			logger.info("User Status in CASL is :"
					+ statusRespType.getUserStatus()
					+ " and User Employee Id in CASL is :"
					+ statusRespType.getEmployeeId());
			logger.info("Internal Users......Authorization statusRespType "
					+ statusRespType);
			if (statusRespType.getUserStatus().equals(
					NGEConstants.ACTIVE_ST_STR)) {*/
        try {
            EntitlementsByCountryLOBRespType entitlementsRespType = caslServiceAccess.getUserEntitlementsByCountryLOB(NGEConstants.CASL_APPLICATION_NM,
                    userId);
            if (entitlementsRespType != null) {
                authorize.setIscaslfailure(NGEConstants.CASL_NO);
                logger.info("Internal Users......Authorization entitlementsRespType "
                        + entitlementsRespType);
                userName = entitlementsRespType.getUserInformation().getLastName() + "," + entitlementsRespType.getUserInformation().getFirstName();
                authorize.setFirstName(entitlementsRespType.getUserInformation().getFirstName());
                authorize.setLastName(entitlementsRespType.getUserInformation().getLastName());

                if (null != entitlementsRespType.getUserInformation()
                        .getEmailAddress()) {
                    usersEmailId = entitlementsRespType
                            .getUserInformation().getEmailAddress();
                    logger.info("getUser--EmailAddress--->" + usersEmailId);
                    authorize.setEmailID(usersEmailId);
                }
                UserAppEntitlementCountryLOBType[] userAppEntitlementType = entitlementsRespType
                        .getUserAppEntitlement();
                if (userAppEntitlementType != null) {
                    for (int k = 0; k < userAppEntitlementType.length; k++) {
                        if (userAppEntitlementType[k] != null
                                && userAppEntitlementType[k].getUserRole() != null) {
                            UserRoleType[] userRoleTypeArray = userAppEntitlementType[k]
                                    .getUserRole();
                            if (null != userAppEntitlementType[k].getLOBId()) {
                                userappDet.setLob(userAppEntitlementType[k].getLOBId());
                            }
                            if (null != userAppEntitlementType[k].getSubLineId()) {
                                userappDet.setSubline(userAppEntitlementType[k].getSubLineId());
                            }
                            if (null != userAppEntitlementType[k].getCountryCode()) {
                                userappDet.setCountry(userAppEntitlementType[k].getCountryCode());
                            }

                            logger.info("Internal Users......Authorization userAppEntitlementType "
                                    + userAppEntitlementType);
                            for (int i = 0; i < userRoleTypeArray.length; i++) {
									/*System.out
											.println("Internal Users......Authorization userRoleTypeArray "
													+ userRoleTypeArray[i]);*/
                                logger.info("Internal Users......Authorization userRoleTypeArray " + userRoleTypeArray[i]);
                                UserRoleType userRoleType = userRoleTypeArray[i];
                                if (userRoleType != null) {
                                    userrole.setRoleName(userRoleType.getRoleName());
                                    authorize.setUserRole(userRoleType.getRoleName());
                                    logger.info("Role Name :"
                                            + userRoleType.getRoleName());

                                    logger.info("Internal Users......Authorization Role Name " + userRoleType.getRoleName());
                                    UserDataCategoryType[] userDataCategoryTypeArray = userRoleType
                                            .getUserDataCategory();
                                    if (userDataCategoryTypeArray != null) {
                                        for (int j = 0; j < userDataCategoryTypeArray.length; j++) {
                                            UserDataCategoryType userDataCategoryType = userDataCategoryTypeArray[j];

                                            if (userDataCategoryType
                                                    .getDataCategoryName() != null) {
                                                userdata.setUserDataCategoryName(userDataCategoryType
                                                        .getDataCategoryName());
													/*System.out
															.println("Internal Users......Authorization userDataCategoryType "
																	+ userDataCategoryType
																			.getDataCategoryName());*/
                                                logger.info("Internal Users......Authorization userDataCategoryType " + userDataCategoryType.getDataCategoryName());
                                                dataCatList
                                                        .add(userDataCategoryType
                                                                .getDataCategoryName()
                                                                .trim());
                                            }
                                            logger.info("Data Category Name From CASL:"
                                                    + userDataCategoryType
                                                    .getDataCategoryName());
                                            UserActionType[] useractionTypeArray = userDataCategoryType.getAction();
                                            if (useractionTypeArray != null) {
                                                ArrayList<String> actionList = new ArrayList<String>();
                                                for (int m = 0; m < useractionTypeArray.length; m++) {
                                                    UserActionType useraction = useractionTypeArray[m];
                                                    if (null != useraction.getActionName()) {
                                                        action.setActionName(useraction.getActionName());
                                                        actionList.add(useraction.getActionName());
                                                        //authorize.getActionList().set(m, useraction.getActionName());
                                                        //logger.info("Total no of actions for the user : " + authorize.getActionList().size());
                                                        logger.info("User Action : " + authorize.getActionList());
                                                        //authorize.setUserAction(useraction.getActionName());
                                                    }
                                                    actionlist.add(action);
                                                }
                                                authorize.setActionList(actionList);
                                                logger.info("Total no of actions for the user : " + authorize.getActionList().size());

                                            }
                                            userdata.setAction(actionlist);
                                            userdatalist.add(userdata);
                                        }
                                    }
                                } else {
                                    logger.info("UserRoleType is NULL");
                                }
                                userrole.setUserDataCategory(userdatalist);
                                userrolelist.add(userrole);
                            }
                        }
                        userappDet.setUserRole(userrolelist);
                        userappDetlist.add(userappDet);
                    }
                } else {
                    userName = "error";
                    authorize.setIscaslfailure("YES");
                    logger.info("UserAppEntitlementType is NULL");
                }
                authorize.setUserApplicationDetails(userappDetlist);
            } else {
                userName = "error";
                authorize.setIscaslfailure("YES");
                logger.info("UserEntitlementsRespType is NULL");
            }
        } catch (Exception e) {
            userName = "error";
            authorize.setIscaslfailure("YES");
            logger.info("UserEntitlementsRespType is NULL");
        }
        //}
		/*} else {
			logger.info("UserStatusRespType is NULL");
		}*/
        for (String dataCat : dataCatList) {
            if (desigBuffer.length() > 0) {
                desigBuffer.append(",");
            }
            desigBuffer.append(dataCat.trim());
        }
        // IF NODESIGNATION THEN redirecting the error page
        if (desigBuffer.length() == 0) {
			/*System.out
					.println("There is no Designations for Internal Users.....");*/
            logger.info("There is no Designations for Internal Users.....");
            List errorList = new ArrayList();
            request.setAttribute("errorList", errorList);
            // Needs to add the error page redirection code;
        }
        if (dataCatList.size() > 0) {
            // Needs to add the code for settingu up the user authorization in
            // screen accessing level;
        }
        logger.info("After Authorization...............................");
        logger.info("After Authorization............................... " + userName);
        if ((null != authorize.getUserRole() && authorize.getUserRole().equalsIgnoreCase(NGEConstants.CASL_NGE_MANAGER_ROLE)) || (null != authorize.getUserRole() && authorize.getUserRole().equalsIgnoreCase("NGE _MANAGER"))) {
            logger.info("Setting the Access Screens for Manager Role Starts");
            authorize.setUserRole("Manager");
            authorize = setUserprimaryactionforManager(authorize);
            authorize = setUserAccessLevelforManager(authorize);
            logger.info("Setting the Access Screens for Manager Role Ends");
        } else if (null != authorize.getUserRole() && authorize.getUserRole().equalsIgnoreCase(NGEConstants.CASL_NGE_ADMIN_ROLE)) {
            logger.info("Setting the Access Screens for Admin Role Starts");
            authorize.setUserRole("Admin");
            logger.info("Admins have access for all screens by default");
            logger.info("Setting the Access Screens for Admin Role Ends");
        } else if (null != authorize.getUserRole() && authorize.getUserRole().equalsIgnoreCase(NGEConstants.CASL_NGE_ALERT_RELEASER_ESCALATION_ROLE)) {
            logger.info("Setting the Access Screens for Alert Releaser Role Starts");
            authorize.setUserRole("Alert Releaser");
            authorize = setUserprimaryactionforAlertReleaserEscalation(authorize);
            authorize = setUserAccessLevelforAlertReleaseEscalation(authorize);
            logger.info("Setting the Access Screens for Alert Releaser Role Ends");
        } else if (null != authorize.getUserRole() && authorize.getUserRole().equalsIgnoreCase(NGEConstants.CASL_NGE_ALERT_RELEASER_ROLE)) {
            authorize.setUserRole("Alert Releaser");
            authorize = setUserprimaryactionforAlertReleaser(authorize);
            authorize = setUserAccessLevelforAlertReleaser(authorize);
        } else if (null != authorize.getUserRole() && authorize.getUserRole().equalsIgnoreCase(NGEConstants.CASL_NGE_SERVICE_CENTER_ASST_ROLE)) {
            authorize = setUserprimaryactionforCenterAssitant(authorize);
            authorize.setUserRole("Service Center Assistant");
            authorize = setUserAccessLevelforCenterAssitant(authorize);
        } else if (null != authorize.getUserRole() && authorize.getUserRole().equalsIgnoreCase(NGEConstants.CASL_NGE_UNDERWRITER_ROLE)) {
            authorize.setUserRole("Underwriter");
            authorize = setUserprimaryactionforUnderwriter(authorize);
            authorize = setUserAccessLevelforUnderwriter(authorize);
        }
        return authorize;
    }

    public CASLAuthorizeBO setUserAccessLevelforManager(CASLAuthorizeBO authorize) {
        if (null != authorize.getUserAction() && authorize.getUserAction().equalsIgnoreCase(NGEConstants.CASL_NGE_ALL_MANAGER_FUNCTIONS_ACTION)) {
            authorize.setReleasebuttonalertBlock(NGEConstants.CASL_NO);
            authorize.setReleasebuttonblocksearchalertBlock(NGEConstants.CASL_NO);
        } else if (null != authorize.getUserAction() && authorize.getUserAction().equalsIgnoreCase(NGEConstants.CASL_NGE_ALL_RELEASE_PRODUCT_BLOCK_ACTION)) {
            authorize.setAccoutnSearch(NGEConstants.CASL_NO);
            authorize.setProducerSearch(NGEConstants.CASL_NO);
            authorize.setCreateSubmission(NGEConstants.CASL_NO);
            authorize.setBulkTransfer(NGEConstants.CASL_NO);
            authorize.setDiary(NGEConstants.CASL_NO);
            authorize.setCreateTransaction(NGEConstants.CASL_NO);
            authorize.setAddProduct(NGEConstants.CASL_NO);
            authorize.setPrintView(NGEConstants.CASL_NO);
            authorize.setCreatenewVersion(NGEConstants.CASL_NO);
            authorize.setTransfersingleProduct(NGEConstants.CASL_NO);
            authorize.setEditTransaction(NGEConstants.CASL_NO);
            authorize.setCopyTransaction(NGEConstants.CASL_NO);
            authorize.setEditProducts(NGEConstants.CASL_NO);
            authorize.setRenewProducts(NGEConstants.CASL_NO);
            authorize.setBindTransaction(NGEConstants.CASL_NO);
            authorize.setUnbindTransaction(NGEConstants.CASL_NO);
            authorize.setUpdateTransaction(NGEConstants.CASL_NO);
            authorize.setUpdateProducts(NGEConstants.CASL_NO);
            authorize.setReopenProducts(NGEConstants.CASL_NO);
            authorize.setReleasebuttonalertBlock(NGEConstants.CASL_NO);
            authorize.setEmailiconalertBlock(NGEConstants.CASL_NO);
            authorize.setEmailiconproductBlock(NGEConstants.CASL_NO);
            authorize.setAddshellAccount(NGEConstants.CASL_NO);
        }
        return authorize;
    }


    public CASLAuthorizeBO setUserAccessLevelforCenterAssitant(CASLAuthorizeBO authorize) {
        if (null != authorize.getUserAction() && authorize.getUserAction().equalsIgnoreCase(NGEConstants.CASL_NGE_ALL_SC_ASST_FUNCTIONS_ACTION_NGE_SERVICE_CENTER_ASST)) {
            authorize.setBlockDetails(NGEConstants.CASL_NO);
            authorize.setBulkTransfer(NGEConstants.CASL_NO);
            authorize.setReleasebuttonalertBlock(NGEConstants.CASL_NO);
            authorize.setReleasebuttonproductBlock(NGEConstants.CASL_NO);
            authorize.setBlockSearch(NGEConstants.CASL_NO);
            authorize.setReleasebuttonblocksearchalertBlock(NGEConstants.CASL_NO);
            authorize.setReleasebuttonblocksearchproductBlock(NGEConstants.CASL_NO);
        } else if (null != authorize.getUserAction() && authorize.getUserAction().equalsIgnoreCase(NGEConstants.CASL_NGE_VIEW_SUBMISSION_ACTION_NGE_SERVICE_CENTER_ASST)) {
            //US190305 Changes 2020//
            //authorize.setAccoutnSearch(NGEConstants.CASL_NO);
            //authorize.setProducerSearch(NGEConstants.CASL_NO);
            //authorize.setBlockDetails(NGEConstants.CASL_NO);
            authorize.setCreateSubmission(NGEConstants.CASL_NO);
            authorize.setBulkTransfer(NGEConstants.CASL_NO);
            //authorize.setDiary(NGEConstants.CASL_NO);
            authorize.setCreateTransaction(NGEConstants.CASL_NO);
            authorize.setAddProduct(NGEConstants.CASL_NO);
            authorize.setCreatenewVersion(NGEConstants.CASL_NO);
            authorize.setTransfersingleProduct(NGEConstants.CASL_NO);
            authorize.setEditTransaction(NGEConstants.CASL_NO);
            authorize.setCopyTransaction(NGEConstants.CASL_NO);
            authorize.setEditProducts(NGEConstants.CASL_NO);
            authorize.setRenewProducts(NGEConstants.CASL_NO);
            authorize.setBindTransaction(NGEConstants.CASL_NO);
            authorize.setUnbindTransaction(NGEConstants.CASL_NO);
            authorize.setUpdateTransaction(NGEConstants.CASL_NO);
            authorize.setUpdateProducts(NGEConstants.CASL_NO);
            authorize.setReopenProducts(NGEConstants.CASL_NO);
            authorize.setReleasebuttonalertBlock(NGEConstants.CASL_NO);
            authorize.setReleasebuttonproductBlock(NGEConstants.CASL_NO);
            authorize.setAddshellAccount(NGEConstants.CASL_NO);
            authorize.setBlockSearch(NGEConstants.CASL_NO);
            authorize.setReleasebuttonblocksearchalertBlock(NGEConstants.CASL_NO);
            authorize.setReleasebuttonblocksearchproductBlock(NGEConstants.CASL_NO);

        } else if (null != authorize.getUserAction() && authorize.getUserAction().equalsIgnoreCase(NGEConstants.CASL_NGE_Create_Updt_Submn_ACTION_NGE_SERVICE_CENTER_ASST)) {
            authorize.setBlockDetails(NGEConstants.CASL_NO);
            authorize.setBulkTransfer(NGEConstants.CASL_NO);
            authorize.setReleasebuttonalertBlock(NGEConstants.CASL_NO);
            authorize.setReleasebuttonproductBlock(NGEConstants.CASL_NO);
            authorize.setBlockSearch(NGEConstants.CASL_NO);
            authorize.setReleasebuttonblocksearchalertBlock(NGEConstants.CASL_NO);
            authorize.setReleasebuttonblocksearchproductBlock(NGEConstants.CASL_NO);
        }
        return authorize;
    }

    public CASLAuthorizeBO setUserAccessLevelforUnderwriter(CASLAuthorizeBO authorize) {
        if (null != authorize.getUserAction() && authorize.getUserAction().equalsIgnoreCase(NGEConstants.CASL_NGE_ALL_UNDERWRITER_FUNCTIONS_ACTION_CASL_NGE_UNDERWRITER_ROLE)) {
            authorize.setReleasebuttonalertBlock(NGEConstants.CASL_NO);
            authorize.setReleasebuttonblocksearchalertBlock(NGEConstants.CASL_NO);
        } else if (null != authorize.getUserAction() && authorize.getUserAction().equalsIgnoreCase(NGEConstants.CASL_NGE_VIEW_SUBMISSION_ACTION_CASL_NGE_UNDERWRITER_ROLE)) {
            authorize.setAccoutnSearch(NGEConstants.CASL_NO);
            authorize.setProducerSearch(NGEConstants.CASL_NO);
            authorize.setBlockDetails(NGEConstants.CASL_NO);
            authorize.setCreateSubmission(NGEConstants.CASL_NO);
            authorize.setBulkTransfer(NGEConstants.CASL_NO);
            authorize.setDiary(NGEConstants.CASL_NO);
            authorize.setCreateTransaction(NGEConstants.CASL_NO);
            authorize.setAddProduct(NGEConstants.CASL_NO);
            authorize.setCreatenewVersion(NGEConstants.CASL_NO);
            authorize.setTransfersingleProduct(NGEConstants.CASL_NO);
            authorize.setEditTransaction(NGEConstants.CASL_NO);
            authorize.setCopyTransaction(NGEConstants.CASL_NO);
            authorize.setEditProducts(NGEConstants.CASL_NO);
            authorize.setRenewProducts(NGEConstants.CASL_NO);
            authorize.setBindTransaction(NGEConstants.CASL_NO);
            authorize.setUnbindTransaction(NGEConstants.CASL_NO);
            authorize.setUpdateTransaction(NGEConstants.CASL_NO);
            authorize.setUpdateProducts(NGEConstants.CASL_NO);
            authorize.setReopenProducts(NGEConstants.CASL_NO);
            authorize.setReleasebuttonalertBlock(NGEConstants.CASL_NO);
            authorize.setReleasebuttonproductBlock(NGEConstants.CASL_NO);
            authorize.setAddshellAccount(NGEConstants.CASL_NO);
            authorize.setBlockSearch(NGEConstants.CASL_NO);
            authorize.setReleasebuttonblocksearchalertBlock(NGEConstants.CASL_NO);
            authorize.setReleasebuttonblocksearchproductBlock(NGEConstants.CASL_NO);

        } else if (null != authorize.getUserAction() && authorize.getUserAction().equalsIgnoreCase(NGEConstants.CASL_NGE_ADD_UPDATE_SUBMISSION_ACTION_CASL_NGE_UNDERWRITER_ROLE)) {
            authorize.setBulkTransfer(NGEConstants.CASL_NO);
            authorize.setReleasebuttonalertBlock(NGEConstants.CASL_NO);
            authorize.setReleasebuttonblocksearchalertBlock(NGEConstants.CASL_NO);
        } else if (null != authorize.getUserAction() && authorize.getUserAction().equalsIgnoreCase(NGEConstants.CASL_NGE_TRANSFER_UNDERWRITER_PORTFOLIO_ACTION_CASL_NGE_UNDERWRITER_ROLE)) {
            authorize.setSubmissionSearch(NGEConstants.CASL_NO);
            authorize.setAccoutnSearch(NGEConstants.CASL_NO);
            authorize.setProducerSearch(NGEConstants.CASL_NO);
            authorize.setBlockDetails(NGEConstants.CASL_NO);
            authorize.setCreateSubmission(NGEConstants.CASL_NO);
            authorize.setViewmanageSubmission(NGEConstants.CASL_NO);
            authorize.setDiary(NGEConstants.CASL_NO);
            authorize.setGlobalsubmissionSearch(NGEConstants.CASL_NO);
            authorize.setCreateTransaction(NGEConstants.CASL_NO);
            authorize.setAddProduct(NGEConstants.CASL_NO);
            authorize.setPrintView(NGEConstants.CASL_NO);
            authorize.setDefaultView(NGEConstants.CASL_NO);
            authorize.setCreatenewVersion(NGEConstants.CASL_NO);
            authorize.setTransfersingleProduct(NGEConstants.CASL_NO);
            authorize.setViewreleaseblock(NGEConstants.CASL_NO);
            authorize.setEditTransaction(NGEConstants.CASL_NO);
            authorize.setCopyTransaction(NGEConstants.CASL_NO);
            authorize.setEditProducts(NGEConstants.CASL_NO);
            authorize.setRenewProducts(NGEConstants.CASL_NO);
            authorize.setBindTransaction(NGEConstants.CASL_NO);
            authorize.setUnbindTransaction(NGEConstants.CASL_NO);
            authorize.setUpdateTransaction(NGEConstants.CASL_NO);
            authorize.setUpdateProducts(NGEConstants.CASL_NO);
            authorize.setReopenProducts(NGEConstants.CASL_NO);
            authorize.setReleasebuttonalertBlock(NGEConstants.CASL_NO);
            authorize.setReleasebuttonproductBlock(NGEConstants.CASL_NO);
            authorize.setEmailiconalertBlock(NGEConstants.CASL_NO);
            authorize.setEmailiconproductBlock(NGEConstants.CASL_NO);
            authorize.setAddshellAccount(NGEConstants.CASL_NO);
            authorize.setBlockSearch(NGEConstants.CASL_NO);
            authorize.setReleasebuttonblocksearchalertBlock(NGEConstants.CASL_NO);
            authorize.setReleasebuttonblocksearchproductBlock(NGEConstants.CASL_NO);
        }
        return authorize;
    }

    public CASLAuthorizeBO setUserAccessLevelforAlertReleaseEscalation(CASLAuthorizeBO authorize) {
        if (null != authorize.getUserAction() && authorize.getUserAction().equalsIgnoreCase(NGEConstants.CASL_NGE_RELEASE_ALERT_BLOCK_ACTION_ALERT_RELEASER_ESCALATION)) {
            authorize.setAccoutnSearch(NGEConstants.CASL_NO);
            authorize.setProducerSearch(NGEConstants.CASL_NO);
            authorize.setCreateSubmission(NGEConstants.CASL_NO);
            authorize.setBulkTransfer(NGEConstants.CASL_NO);
            authorize.setDiary(NGEConstants.CASL_NO);
            authorize.setCreateTransaction(NGEConstants.CASL_NO);
            authorize.setAddProduct(NGEConstants.CASL_NO);
            authorize.setPrintView(NGEConstants.CASL_NO);
            authorize.setCreatenewVersion(NGEConstants.CASL_NO);
            authorize.setTransfersingleProduct(NGEConstants.CASL_NO);
            authorize.setEditTransaction(NGEConstants.CASL_NO);
            authorize.setCopyTransaction(NGEConstants.CASL_NO);
            authorize.setEditProducts(NGEConstants.CASL_NO);
            authorize.setRenewProducts(NGEConstants.CASL_NO);
            authorize.setBindTransaction(NGEConstants.CASL_NO);
            authorize.setUnbindTransaction(NGEConstants.CASL_NO);
            authorize.setUpdateTransaction(NGEConstants.CASL_NO);
            authorize.setUpdateProducts(NGEConstants.CASL_NO);
            authorize.setReopenProducts(NGEConstants.CASL_NO);
            authorize.setReleasebuttonproductBlock(NGEConstants.CASL_NO);
            authorize.setEmailiconalertBlock(NGEConstants.CASL_NO);
            authorize.setEmailiconproductBlock(NGEConstants.CASL_NO);
            authorize.setAddshellAccount(NGEConstants.CASL_NO);
            authorize.setReleasebuttonblocksearchproductBlock(NGEConstants.CASL_NO);
        }
        return authorize;
    }


    public CASLAuthorizeBO setUserAccessLevelforAlertReleaser(CASLAuthorizeBO authorize) {
        if (null != authorize.getUserAction() && authorize.getUserAction().equalsIgnoreCase(NGEConstants.CASL_NGE_RELEASE_ALERT_BLOCK_ACTION_ALERT_RELEASER)) {
            authorize.setAccoutnSearch(NGEConstants.CASL_NO);
            authorize.setProducerSearch(NGEConstants.CASL_NO);
            authorize.setCreateSubmission(NGEConstants.CASL_NO);
            authorize.setBulkTransfer(NGEConstants.CASL_NO);
            authorize.setDiary(NGEConstants.CASL_NO);
            authorize.setCreateTransaction(NGEConstants.CASL_NO);
            authorize.setAddProduct(NGEConstants.CASL_NO);
            authorize.setPrintView(NGEConstants.CASL_NO);
            authorize.setCreatenewVersion(NGEConstants.CASL_NO);
            authorize.setTransfersingleProduct(NGEConstants.CASL_NO);
            authorize.setEditTransaction(NGEConstants.CASL_NO);
            authorize.setCopyTransaction(NGEConstants.CASL_NO);
            authorize.setEditProducts(NGEConstants.CASL_NO);
            authorize.setRenewProducts(NGEConstants.CASL_NO);
            authorize.setBindTransaction(NGEConstants.CASL_NO);
            authorize.setUnbindTransaction(NGEConstants.CASL_NO);
            authorize.setUpdateTransaction(NGEConstants.CASL_NO);
            authorize.setUpdateProducts(NGEConstants.CASL_NO);
            authorize.setReopenProducts(NGEConstants.CASL_NO);
            authorize.setReleasebuttonproductBlock(NGEConstants.CASL_NO);
            authorize.setEmailiconalertBlock(NGEConstants.CASL_NO);
            authorize.setEmailiconproductBlock(NGEConstants.CASL_NO);
            authorize.setAddshellAccount(NGEConstants.CASL_NO);
            authorize.setReleasebuttonblocksearchproductBlock(NGEConstants.CASL_NO);
        }
        return authorize;
    }

    @RequestMapping(value = "/addshellaccount", headers = "Accept=application/json", method = RequestMethod.POST)
    public @ResponseBody
    JSONHeaderBO addShellAccount(
            @RequestBody AddShellAccountReqDataTypeBO request, HttpServletRequest sesRequest, HttpServletResponse response) throws IOException {

        /**PI3 - Aug Maintenance Release  - Use employee id to create shell account in NGE - Starts*/
        JSONHeaderBO jsonHeaderBO = new JSONHeaderBO();
        HttpSession session = null;
        session = sesRequest.getSession(false);

        if (session == null || (session.getAttribute(NGEConstants.SESSION_CASL_USERID) == null)) {
            response.sendRedirect("jsp/logout.jsp");
            return jsonHeaderBO;
        }

        /**PI3 - Aug Maintenance Release  - Use employee id to create shell account in NGE - Ends*/

        AccountService serviceObj = new AccountService();
        AddShellAccountRespBO addShellAccountRespBO = null;
        AddShellAccountReqBO addShellAccountReqBO = null;
        ExceptionBO exceptionBO = null;
        DataCacheObject cacheObject = new DataCacheObject();

        /**PI3 - Aug Maintenance Release  - Use employee id to create shell account in NGE - Starts*/
        serviceObj.setCaslServiceId((String) session.getAttribute(NGEConstants.SESSION_CASL_USERID));
        /**PI3 - Aug Maintenance Release  - Use employee id to create shell account in NGE - Ends*/

        try {
            //changes for alternate country code mapping starts
            String strCurrentCountryCd = request.getCountryCode();
            if (strCurrentCountryCd != null && strCurrentCountryCd.trim().length() != 0) {
                if (cacheObject.getDynacacheObj("ALTERNATE_COUNTRY_CODE") != null) {
                    @SuppressWarnings("unchecked")
                    Map<String, String> mapAlternateCountryCode = (Map<String, String>) cacheObject.getDynacacheObj("ALTERNATE_COUNTRY_CODE");
                    //Map<String,String> mapAlternateCountryCode= new AddTransactionHelper().getAlternateCountryHelper();
                    request.setCountryCode(mapAlternateCountryCode.get(strCurrentCountryCd));
                }

            }
            //changes for alternate country code mapping ends

            addShellAccountReqBO = new AddShellAccountReqBO();
            addShellAccountReqBO.setRequest(request);
            addShellAccountRespBO = serviceObj
                    .addShellAccount(addShellAccountReqBO);
        } catch (MalformedURLException e) {
            exceptionBO = new ExceptionBO();
            exceptionBO.setErrorFrom(NGEConstants.ADD_SHELL_ACCOUNT_SERVICE);
            exceptionBO.setErrorMessage(e.getMessage());
        } catch (AIGCIExceptionMsg e) {
            exceptionBO = new ExceptionBO();
            exceptionBO.setErrorFrom(NGEConstants.ADD_SHELL_ACCOUNT_SERVICE);
            exceptionBO.setErrorMessage(e.getFaultInfo().getErrorMessage());
            exceptionBO.setErrorCode(e.getFaultInfo().getErrorCode());
            exceptionBO.setErrorType(e.getFaultInfo().getErrorType());
        } catch (AccountServiceExceptionMsg e) {
            exceptionBO = new ExceptionBO();
            exceptionBO.setErrorFrom(NGEConstants.ADD_SHELL_ACCOUNT_SERVICE);
            exceptionBO.setErrorMessage(e.getFaultInfo().getErrorMessage());
            exceptionBO.setErrorCode(e.getFaultInfo().getErrorCode());
            exceptionBO.setErrorType(e.getFaultInfo().getErrorType());
        } catch (Exception e) {
            exceptionBO = new ExceptionBO();
            exceptionBO.setErrorFrom(NGEConstants.ADD_SHELL_ACCOUNT_SERVICE);
            exceptionBO.setErrorMessage(e.getMessage());
        }
        String failureMessage = "";
        if (null != addShellAccountRespBO && null != addShellAccountRespBO.getResponse()
                && null != addShellAccountRespBO.getResponse().getErrors()
                && null != addShellAccountRespBO.getResponse().getErrors().getMessage()
                && null != addShellAccountRespBO.getResponse().getErrors().getMessage().get(0)) {
            exceptionBO = new ExceptionBO();
            exceptionBO.setErrorFrom(NGEConstants.ADD_SHELL_ACCOUNT_SERVICE);
            exceptionBO.setErrorMessage(addShellAccountRespBO.getResponse().getErrors().getMessage().get(0).getValue());
            failureMessage = addShellAccountRespBO.getResponse().getErrors().getMessage().get(0).getValue();
            exceptionBO.setErrorCode(addShellAccountRespBO.getResponse().getErrors().getMessage().get(0).getNumber());
            exceptionBO.setErrorType(addShellAccountRespBO.getResponse().getErrors().getMessage().get(0).getType());
        }
        JSONHeaderBO jsonHeader = null;
        if (null == exceptionBO) {
            jsonHeader = setJsonHeader(0, NGEConstants.SUCCESS_CODE,
                    NGEConstants.SUCCESS, NGEConstants.SUBMISSION_SUCCESSFUL,
                    addShellAccountRespBO);
        } else {

            if (failureMessage != null) {
                failureMessage = failureMessage.replace(NGEConstants.ERROR_MESSAGE_TO_BE_TRIMMED, "");
            }
            jsonHeader = setJsonHeader(0, NGEConstants.FAILURE_CODE,
                    NGEConstants.FAILURE, NGEConstants.ADD_SHELL_FAILURE + " Reason: " + failureMessage,
                    addShellAccountRespBO);
        }
        return jsonHeader;
    }

    @RequestMapping(value = "/findlicense", headers = "Accept=application/json", method = RequestMethod.POST)
    public @ResponseBody
    JSONHeaderBO findLicense(@RequestBody FindLicenseReqBO licenseReqBO) {
        NGPLSService serviceObj = new NGPLSService();
        AccountService accServiceObj = new AccountService();
        GetAccountRespBO getAccountRespBO = null;
        AccountInfoUIBO accountInfo = null;
        FindLicenseRespBO licenseRespBO = null;
        ExceptionBO exceptionBO = null;
        JSONHeaderBO jsonHeaderBO = null;
        GetAccountReqBO accReqBO = new GetAccountReqBO();
        GetAccountRequestDataBO request = new GetAccountRequestDataBO();
        request.setSearchNumber(licenseReqBO.getAccountNo());
        accReqBO.setRequest(request);
        try {
            getAccountRespBO = accServiceObj.getAccount(accReqBO);
            accountInfo = ManageProductsServiceHandler.setAccountInfo(getAccountRespBO);
        } catch (MalformedURLException e) {
            exceptionBO = new ExceptionBO();
            exceptionBO.setErrorFrom(NGEConstants.GET_ACCOUNT_SERVICE);
            exceptionBO.setErrorMessage(e.getMessage());
        } catch (AIGCIExceptionMsg e) {
            exceptionBO = new ExceptionBO();
            exceptionBO.setErrorFrom(NGEConstants.GET_ACCOUNT_SERVICE);
            exceptionBO.setErrorMessage(seti18ErroMessage(e.getFaultInfo()
                    .getErrorCode()));
            exceptionBO.setErrorCode(NGEConstants.FAILURE_CODE);
            exceptionBO.setErrorType(e.getFaultInfo().getErrorType());
        } catch (AccountServiceExceptionMsg e) {
            exceptionBO = new ExceptionBO();
            exceptionBO.setErrorFrom(NGEConstants.GET_ACCOUNT_SERVICE);
            exceptionBO.setErrorMessage(e.getFaultInfo().getErrorMessage());
            exceptionBO.setErrorCode(e.getFaultInfo().getErrorCode());
            exceptionBO.setErrorType(e.getFaultInfo().getErrorType());
        } catch (Exception e) {
            exceptionBO = new ExceptionBO();
            exceptionBO.setErrorFrom(NGEConstants.GET_ACCOUNT_SERVICE);
            exceptionBO.setErrorMessage(e.getMessage());
        }

        if (accountInfo != null) {
            licenseReqBO.setLicenseStateCd(accountInfo.getContactdetailsaccount().getState());
        }
        SequenceNumberGeneration generateObj = new SequenceNumberGeneration();
        HashMap<String, String> sequenceNames = new HashMap<>();
        HashMap<String, Object> sequenceValueMap = new HashMap<String, Object>();
        sequenceNames.put("FIND_LICENSE", "INT");
        sequenceValueMap = generateObj.getNextSequenceNumber(sequenceNames);
        int sequenceNo = Integer.parseInt(sequenceValueMap.get(
                "FIND_LICENSE").toString());
        LicenseDetailInfoUIBO licenseDetail = null;
        try {
            licenseReqBO.setSourceCd(NGEConstants.USA);
            licenseRespBO = serviceObj.findLicense(licenseReqBO);
            licenseDetail = ManageProductsServiceHandler.getLicenseList(licenseRespBO);
		} 
		/* March 20, 2022 - App Modernization Fix - Fetching the consumer side local WSDL & then hit the end point to consume the services. - Starts*/
		/*
		 * catch (MalformedURLException e) { exceptionBO = new ExceptionBO();
		 * exceptionBO.setErrorFrom(NGEConstants.FIND_LICENSE);
		 * exceptionBO.setErrorMessage(e.getMessage());
		 * exceptionBO.setErrorType(NGEConstants.FATAL); }
		 */
		/* March 20, 2022 - App Modernization Fix - Fetching the consumer side local WSDL & then hit the end point to consume the services. - Ends*/
		catch (AIGCIExceptionMsg e) {
            exceptionBO = new ExceptionBO();
            exceptionBO.setErrorFrom(NGEConstants.FIND_LICENSE);
            exceptionBO.setErrorMessage(seti18ErroMessage(e.getFaultInfo()
                    .getErrorCode()));
            exceptionBO.setErrorCode(NGEConstants.FAILURE_CODE);
            exceptionBO.setErrorType(e.getFaultInfo().getErrorType());
        } catch (ChartisInsuranceUSExceptionMsg e) {
            logger.info("Inside Service Exception");
            exceptionBO = new ExceptionBO();
            exceptionBO.setErrorFrom(NGEConstants.FIND_LICENSE);
            exceptionBO.setErrorMessage(seti18ErroMessage(e.getFaultInfo()
                    .getErrorCode()));
            exceptionBO.setErrorCode(NGEConstants.FAILURE_CODE);
            exceptionBO.setErrorType(NGEConstants.FATAL);
        } catch (Exception e) {
            exceptionBO = new ExceptionBO();
            exceptionBO.setErrorFrom(NGEConstants.FIND_LICENSE);
            exceptionBO
                    .setErrorMessage(seti18ErroMessage(NGEConstants.ERROR_INVOKING_SERVICE));
            exceptionBO.setErrorType(NGEConstants.FATAL);
        }
		/*if(null!=licenseRespBO && null!=licenseRespBO.getErrorDetail()){
			logger.info("Inside Service Exception");
			exceptionBO = new ExceptionBO();
			exceptionBO.setErrorFrom(NGEConstants.FIND_AGENT);
			exceptionBO.setErrorMessage(seti18ErroMessage(licenseRespBO.getErrorDetail().getErrorDesc()));
			exceptionBO.setErrorCode(licenseRespBO.getErrorDetail().getErrorCd());
			exceptionBO.setErrorType(NGEConstants.FATAL);
		}*/
        if (exceptionBO != null) {
            jsonHeaderBO = setJsonHeader(sequenceNo,
                    exceptionBO.getErrorCode(), exceptionBO.getErrorType(),
                    exceptionBO.getErrorMessage(), null);
        } else {
            jsonHeaderBO = setJsonHeader(sequenceNo, NGEConstants.SUCCESS_CODE,
                    NGEConstants.SUCCESS, NGEConstants.PRODUCT_UPDATED,
                    licenseDetail);
        }
        return jsonHeaderBO;
    }

    public JSONHeaderBO setJsonHeader(int id, String code, String type,
                                      String description, Object object) {
        JSONHeaderBO jsonHeaderBO = new JSONHeaderBO();
        jsonHeaderBO.setId(String.valueOf(id));
        jsonHeaderBO.setCode(code);
        jsonHeaderBO.setType(type);
        jsonHeaderBO.setDescription(description);
        jsonHeaderBO.setData(object);
        return jsonHeaderBO;

    }

    @RequestMapping(value = "/setaccmailingaddress", headers = "Accept=application/json", method = RequestMethod.POST)
    public @ResponseBody
    JSONHeaderBO setAccMailingAddress(HttpServletRequest request,
                                      @RequestBody AddressDetailsBO addressDet, HttpServletResponse response) throws IOException {
        HttpSession session = null;
        JSONHeaderBO bo = new JSONHeaderBO();
        session = request.getSession(false);
        if (session == null || (session.getAttribute(NGEConstants.SESSION_CASL_USERID) == null)) {
            //logger.info("Invalid Session : "+session);
            response.sendRedirect("jsp/logout.jsp");
            return bo;
        }
		/*else{
			logger.info("session : "+session);
		}*/
        String headerjson = "";
        ObjectWriter ow = new ObjectMapper().writer()
                .withDefaultPrettyPrinter();
		/*AddressDetailsSessionBO sessionbroker = new AddressDetailsSessionBO();
		sessionbroker.setAccountmailingaddress(addressDet);*/
        try {
            headerjson = ow.writeValueAsString(addressDet);
        } catch (JsonProcessingException e) {
            // TODO Auto-generated catch block
            logger.info("NGEUIException", e);
        }

        logger.info("***********************Setting ADDRESS Detail in Session Starts**********************");
        //session = request.getSession(true);
        session.setAttribute(
                NGEConstants.TRANSACTION_ADDRESS, addressDet);
        session.setAttribute(NGEConstants.UPDATE_ACC_MAIL_ADDRESS,
                XSSValidator.stripXSS(headerjson));
        session.setAttribute(NGEConstants.SESSION_TRANSACTION_ADDRESS_DETAIL, XSSValidator.stripXSS(headerjson));

        bo.setData(addressDet);
        logger.info("***********************Setting ADDRESS Detail in Session Ends**********************");
        return bo;
    }

    @RequestMapping(value = "/setproducercontact", headers = "Accept=application/json", method = RequestMethod.POST)
    public @ResponseBody
    JSONHeaderBO setProducerContact(HttpServletRequest request,
                                    @RequestBody BrokerBO brokerBO, HttpServletResponse response) throws IOException {
        HttpSession session = null;
        JSONHeaderBO bo = new JSONHeaderBO();
        session = request.getSession(false);
        if (session == null || (session.getAttribute(NGEConstants.SESSION_CASL_USERID) == null)) {
            //logger.info("Invalid Session : "+session);
            response.sendRedirect("jsp/logout.jsp");
            return bo;
        }
		/*else{
			logger.info("session : "+session);
		}*/
        String headerjson = "";
        ObjectWriter ow = new ObjectMapper().writer()
                .withDefaultPrettyPrinter();
        ProducerContactSessionBO sessionbroker = new ProducerContactSessionBO();
        sessionbroker.setProducerIndividual(brokerBO);
        try {
            headerjson = ow.writeValueAsString(sessionbroker);
        } catch (JsonProcessingException e) {
            // TODO Auto-generated catch block
            logger.info("NGEUIException", e);
        }

        logger.info("***********************Setting Broker Detail in Session Starts**********************");
        //session = request.getSession(true);
        session.setAttribute(
                NGEConstants.TRANSACTION_PRODUCER_CONTACT_DETAIL, brokerBO);
        session.setAttribute(NGEConstants.SESSION_TRANSACTION_PRODUCER_CONTACT_DETAIL, XSSValidator.stripXSS(headerjson));
        logger.info("***********************Setting Broker Detail in Session Ends**********************");
        return bo;
    }


    @RequestMapping(value = "/setadditionalproducer", headers = "Accept=application/json", method = RequestMethod.POST)
    public @ResponseBody
    JSONHeaderBO setAdditionalProducer(HttpServletRequest request,
                                       @RequestBody List<AdditionalProducerBO> additionalProducers, HttpServletResponse response) throws IOException {
        HttpSession session = null;
        JSONHeaderBO bo = new JSONHeaderBO();
        session = request.getSession(false);
        if (session == null || (session.getAttribute(NGEConstants.SESSION_CASL_USERID) == null)) {
            //logger.info("Invalid Session : "+session);
            response.sendRedirect("jsp/logout.jsp");
            return bo;
        }
	/*	else{
			logger.info("session : "+session);
		}*/
        String headerjson = "";
        ObjectWriter ow = new ObjectMapper().writer()
                .withDefaultPrettyPrinter();
		/*AdditionalProducerSessionBO additionalProducerSession = new AdditionalProducerSessionBO();
		additionalProducerSession.setAdditionalProducerBOList(additionalProducer);*/
        List<AdditionalProducerBO> additionalProducerSessionList = new ArrayList<AdditionalProducerBO>();
        if (additionalProducers != null) {
            for (AdditionalProducerBO additionalProducer : additionalProducers) {
                additionalProducerSessionList.add(additionalProducer);
            }
        }
        AdditionalProducerSessionBO additionalProducerSessionBO = new AdditionalProducerSessionBO();
        additionalProducerSessionBO.setRows(additionalProducerSessionList);
        try {
            headerjson = ow.writeValueAsString(additionalProducerSessionBO);
        } catch (JsonProcessingException e) {
            // TODO Auto-generated catch block
            logger.info("NGEUIException", e);
        }

        logger.info("***********************Setting Additional Producer in Session Starts**********************");
        //session = request.getSession(true);
        session.setAttribute(NGEConstants.SESSION_TRANSACTION_ADDITIONAL_PRODUCER_DETAIL, XSSValidator.stripXSS(headerjson));
        session.setAttribute(NGEConstants.TRANSACTION_ADDITIONAL_ACC_PRODUCER_LIST, additionalProducerSessionList);
        logger.info("***********************Setting Additional Producer in Session Ends**********************");
        return bo;
    }

    @RequestMapping(value = "/deleteproducer", headers = "Accept=application/json", method = RequestMethod.POST)
    public @ResponseBody
    JSONHeaderBO deleteProducer(HttpServletRequest request,
                                @RequestBody AdditionalProducerBO additionalProducerBO, HttpServletResponse response) throws IOException {

        HttpSession session = null;
        JSONHeaderBO bo = new JSONHeaderBO();
        session = request.getSession(false);
        if (session == null || (session.getAttribute(NGEConstants.SESSION_CASL_USERID) == null)) {
            response.sendRedirect("jsp/logout.jsp");
            return bo;
        }
        String headerjson = "";
        ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
        List<AdditionalProducerBO> producerList = new ArrayList<AdditionalProducerBO>();
        if (session.getAttribute("TRANSACTION_ADDITIONAL_ACC_PRODUCER_LIST") != null) {
            producerList = (List<AdditionalProducerBO>) session.getAttribute(NGEConstants.TRANSACTION_ADDITIONAL_ACC_PRODUCER_LIST);
            if (producerList != null && producerList.size() > 0) {

                for (Iterator<AdditionalProducerBO> producerDetailIter = producerList.iterator(); producerDetailIter.hasNext(); ) {
                    AdditionalProducerBO producer = producerDetailIter.next();
                    if (producer.getProducerEntityNumber().equals(additionalProducerBO.getProducerEntityNumber())) {
                        producerDetailIter.remove();
                    }
                }
            }
        }
        AdditionalProducerSessionBO additionalProducerSessionBO = new AdditionalProducerSessionBO();
        additionalProducerSessionBO.setRows(producerList);
        try {
            headerjson = ow.writeValueAsString(additionalProducerSessionBO);
        } catch (JsonProcessingException e) {
            // TODO Auto-generated catch block
            logger.info("NGEUIException", e);
        }

        logger.info("***********************Setting Additional Producer in Session Starts**********************");
        session.setAttribute(NGEConstants.SESSION_TRANSACTION_ADDITIONAL_PRODUCER_DETAIL, XSSValidator.stripXSS(headerjson));
        session.setAttribute(NGEConstants.TRANSACTION_ADDITIONAL_ACC_PRODUCER_LIST, producerList);
        logger.info("***********************Setting Additional Producer in Session Ends**********************");
        return bo;
    }

    @RequestMapping(value = "/setAdditionalInsured", headers = "Accept=application/json", method = RequestMethod.POST)
    public @ResponseBody
    JSONHeaderBO setAdditionalInsured(HttpServletRequest request,
                                      @RequestBody List<AdditionalInsuredBO> additionalInsureds, HttpServletResponse response) throws IOException {
        HttpSession session = null;
        String additionalInsuredListJSON = "";
        JSONHeaderBO bo = new JSONHeaderBO();
        session = request.getSession(false);

        if (session == null || (session.getAttribute(NGEConstants.SESSION_CASL_USERID) == null)) {
            //logger.info("Invalid Session : "+session);
            response.sendRedirect("jsp/logout.jsp");
            return bo;
        }
		/*else{
			logger.info("session : "+session);
		}*/
        ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
        List<AdditionalInsuredBO> additionalInsuredSessionList = new ArrayList<AdditionalInsuredBO>();
        List<AdditionalInsuredBO> toBeDeletedList = new ArrayList<AdditionalInsuredBO>();
        String transactionId = null;
        String versionId = null;
        int size = additionalInsureds.size();
        logger.info(size);
        if (additionalInsureds.size() > 0) {
            transactionId = additionalInsureds.get(0).getTransactionId();
            versionId = additionalInsureds.get(0).getVersionId();
        }
        session = request.getSession(false);
        if (session.getAttribute(NGEConstants.TRANSACTION_ADDITIONAL_ACC_INSURED_LIST) != null) {
            additionalInsuredSessionList = (List<AdditionalInsuredBO>) session.getAttribute(NGEConstants.TRANSACTION_ADDITIONAL_ACC_INSURED_LIST);
            if (additionalInsuredSessionList != null && additionalInsuredSessionList.size() > 0) {
                for (AdditionalInsuredBO toBeDeletedSession : additionalInsuredSessionList) {
                    if (toBeDeletedSession.getTransactionId().equalsIgnoreCase(transactionId) && toBeDeletedSession.getVersionId().equalsIgnoreCase(versionId))
                        toBeDeletedList.add(toBeDeletedSession);
                }
            }
            if (toBeDeletedList.size() > 0) {
                for (AdditionalInsuredBO toBeDeletedSession : toBeDeletedList) {
                    if (additionalInsuredSessionList != null) {
                        additionalInsuredSessionList.remove(toBeDeletedSession);
                    }
                }
            }
            for (AdditionalInsuredBO additionalInsured : additionalInsureds) {
                if (additionalInsuredSessionList != null) {
                    additionalInsuredSessionList.add(additionalInsured);
                }
            }
        } else if (additionalInsureds.size() > 0) {
            for (AdditionalInsuredBO additionalInsured : additionalInsureds) {
                //medium low issue fixes-2020 starts
                //if(additionalInsured.getAccountNo() != null && additionalInsured.getAccountNo() != "")
                if (additionalInsured.getAccountNo() != null && !additionalInsured.getAccountNo().equals(""))
                    //medium low issue fixes-2020 ends
                    additionalInsuredSessionList.add(additionalInsured);
            }
        }
        AdditionalInsuredSessionBO additionalInsuredSessionBO = new AdditionalInsuredSessionBO();
        additionalInsuredSessionBO.setRows(additionalInsuredSessionList);
        try {
            additionalInsuredListJSON = ow.writeValueAsString(additionalInsuredSessionBO);
        } catch (JsonProcessingException e) {
            // TODO Auto-generated catch block
            logger.info("NGEUIException", e);
        }

        logger.info("***********************Setting Additional Insured in Session Starts**********************");
        session.setAttribute(NGEConstants.SESSION_TRANSACTION_ADDITIONAL_INSURED_DETAIL, XSSValidator.stripXSS(additionalInsuredListJSON));

        session.setAttribute(NGEConstants.TRANSACTION_ADDITIONAL_ACC_INSURED_LIST, additionalInsuredSessionList);
        logger.info("***********************Setting Additional Insured in Session Ends**********************");
        return bo;
    }

    @SuppressWarnings("unchecked")
    @RequestMapping(value = "/setAdditionalInsuredProductLevel", headers = "Accept=application/json", method = RequestMethod.POST)
    public @ResponseBody
    JSONHeaderBO setAdditionalInsuredProductLevel(HttpServletRequest request,
                                                  @RequestBody List<AdditionalInsuredBO> additionalInsureds, HttpServletResponse response) throws IOException {
        HttpSession session = null;
        String additionalInsuredListJSON = "";
        JSONHeaderBO bo = new JSONHeaderBO();
        session = request.getSession(false);
        if (session == null || (session.getAttribute(NGEConstants.SESSION_CASL_USERID) == null)) {
            //logger.info("Invalid Session : "+session);
            response.sendRedirect("jsp/logout.jsp");
            return bo;
        }
		/*else{
			logger.info("session : "+session);
		}*/
        ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
        List<AdditionalInsuredBO> additionalInsuredSessionList = new ArrayList<AdditionalInsuredBO>();
        //List<AdditionalInsuredBO> additionalInsuredFromExistingSession = new ArrayList<AdditionalInsuredBO>();
        String productId = null;
        String componentId = null;
        String transactionId = null;
        String versionId = null;
        List<AdditionalInsuredBO> toBeDeletedAdditionalInsuredList = new ArrayList<AdditionalInsuredBO>();
        if (additionalInsureds != null) {
            productId = additionalInsureds.get(0).getProductTabKey();
            componentId = additionalInsureds.get(0).getComponentProductTabKey();
            transactionId = additionalInsureds.get(0).getTransactionId();
            versionId = additionalInsureds.get(0).getVersionId();
        }

        if (session.getAttribute(NGEConstants.ADDITIONAL_INSURED_LIST_PRODUCT_LEVEL) != null) {
            additionalInsuredSessionList = (List<AdditionalInsuredBO>) session.getAttribute(NGEConstants.ADDITIONAL_INSURED_LIST_PRODUCT_LEVEL);
            if (additionalInsureds != null && additionalInsureds.size() > 0) {
                for (AdditionalInsuredBO additionalInsuredSession : additionalInsuredSessionList) {
                    if (additionalInsuredSession.getProductTabKey().equalsIgnoreCase(productId) && additionalInsuredSession.getComponentProductTabKey().equalsIgnoreCase(componentId) && additionalInsuredSession.getTransactionId().equalsIgnoreCase(transactionId) && additionalInsuredSession.getVersionId().equalsIgnoreCase(versionId)) {
                        toBeDeletedAdditionalInsuredList.add(additionalInsuredSession);
                    }
                }
                if (toBeDeletedAdditionalInsuredList.size() > 0) {
                    for (AdditionalInsuredBO toBeDeletedAdditionalInsured : toBeDeletedAdditionalInsuredList) {
                        additionalInsuredSessionList.remove(toBeDeletedAdditionalInsured);
                    }
                }
                for (AdditionalInsuredBO additionalInsured : additionalInsureds) {
                    additionalInsuredSessionList.add(additionalInsured);
                }
            }
        } else {
            if (additionalInsureds != null && additionalInsureds.size() > 0) {
                for (AdditionalInsuredBO additionalInsured : additionalInsureds) {
                    additionalInsuredSessionList.add(additionalInsured);
                }
            }
        }
        AdditionalInsuredSessionBO additionalInsuredSessionBO = new AdditionalInsuredSessionBO();
        additionalInsuredSessionBO.setRows(additionalInsuredSessionList);
        try {
            additionalInsuredListJSON = ow.writeValueAsString(additionalInsuredSessionBO);
        } catch (JsonProcessingException e) {
            // TODO Auto-generated catch block
            logger.info("NGEUIException", e);
        }
        session = request.getSession(false);
        if (null != session) {
            logger.info("***********************Setting Additional Insured product level in Session Starts**********************");
            session.setAttribute(NGEConstants.SESSION_ADDITIONAL_INSURED_PRODUCT_LEVEL_DETAIL, XSSValidator.stripXSS(additionalInsuredListJSON));
            session.setAttribute(NGEConstants.ADDITIONAL_INSURED_LIST_PRODUCT_LEVEL, additionalInsuredSessionList);
            logger.info("***********************Setting Additional Insured product level in Session Ends**********************");
        }
        return bo;
    }


    @RequestMapping(value = "/setAssociateProduct", headers = "Accept=application/json", method = RequestMethod.POST)
    public @ResponseBody
    JSONHeaderBO setAssociateProduct(
            @RequestBody ExpiringPoductBO expiringProductBO, HttpServletRequest request, HttpServletResponse response) throws IOException {
        HttpSession session = null;
        JSONHeaderBO bo = new JSONHeaderBO();
        session = request.getSession(false);
        if (session == null || (session.getAttribute(NGEConstants.SESSION_CASL_USERID) == null)) {
            //logger.info("Invalid Session : "+session);
            response.sendRedirect("jsp/logout.jsp");
            return bo;
        }
		/*else{
			logger.info("session : "+session);
		}*/
        String headerjson = "";
        ObjectWriter ow = new ObjectMapper().writer()
                .withDefaultPrettyPrinter();

        Map<String, List<ProductBO>> associateProductBOList = (Map<String, List<ProductBO>>) session.getAttribute(NGEConstants.SESSION_ASSOCIATE_PRODUCT_LIST_DATA);
        if (associateProductBOList != null && associateProductBOList.size() > 0) {
            if (expiringProductBO.getExpiringProductBO() != null) {
                associateProductBOList.put(expiringProductBO.getId(), expiringProductBO.getExpiringProductBO());
            } else {
                associateProductBOList.remove(expiringProductBO.getId());
            }

        } else {
            associateProductBOList = new HashMap<String, List<ProductBO>>();
            if (expiringProductBO.getExpiringProductBO() != null) {
                associateProductBOList.put(expiringProductBO.getId(), expiringProductBO.getExpiringProductBO());
            }

        }
        try {
            headerjson = ow.writeValueAsString(associateProductBOList);
        } catch (JsonProcessingException e) {
            logger.info("NGEUIException", e);
        }
        session.setAttribute(NGEConstants.SESSION_ASSOCIATE_PRODUCT_LIST, XSSValidator.stripXSS(headerjson));
        session.setAttribute(NGEConstants.SESSION_ASSOCIATE_PRODUCT_LIST_DATA, associateProductBOList);
        return bo;
    }


    /**
     * @param response
     * @throws IOException
     */
    @RequestMapping(value = "/findagent", headers = "Accept=application/json", method = RequestMethod.POST)
    public @ResponseBody
    JSONHeaderBO findAgent(@RequestBody FindAgentReqBO agentReqBO, HttpServletResponse response) throws IOException {
        NGPLSService serviceObj = new NGPLSService();
        FindAgentRespBO agentRespBO = null;
        ExceptionBO exceptionBO = null;
        JSONHeaderBO jsonHeaderBO = null;
        SequenceNumberGeneration generateObj = new SequenceNumberGeneration();
        HashMap<String, String> sequenceNames = new HashMap<>();
        HashMap<String, Object> sequenceValueMap = new HashMap<String, Object>();
        sequenceNames.put(NGEConstants.FIND_AGENT, "INT");
        sequenceValueMap = generateObj.getNextSequenceNumber(sequenceNames);
        int sequenceNo = Integer.parseInt(sequenceValueMap.get(
                NGEConstants.FIND_AGENT).toString());
        try {
            agentReqBO.setSourceCd(NGEConstants.USA);
            agentRespBO = serviceObj.findAgent(agentReqBO);
		} 
		/* March 20, 2022 - App Modernization Fix - Fetching the consumer side local WSDL & then hit the end point to consume the services. - Starts*/
		/*
		 * catch (MalformedURLException e) { exceptionBO = new ExceptionBO();
		 * exceptionBO.setErrorFrom(NGEConstants.FIND_AGENT);
		 * exceptionBO.setErrorMessage(e.getMessage());
		 * exceptionBO.setErrorType(NGEConstants.FATAL); }
		 */
		/* March 20, 2022 - App Modernization Fix - Fetching the consumer side local WSDL & then hit the end point to consume the services. - Ends*/
		catch (AIGCIExceptionMsg e) {			
            exceptionBO = new ExceptionBO();
            exceptionBO.setErrorFrom(NGEConstants.FIND_AGENT);
            exceptionBO.setErrorMessage(seti18ErroMessage(e.getFaultInfo()
                    .getErrorCode()));
            exceptionBO.setErrorCode(NGEConstants.FAILURE_CODE);
            exceptionBO.setErrorType(e.getFaultInfo().getErrorType());
        } catch (ChartisInsuranceUSExceptionMsg e) {
            logger.info("Inside Service Exception");
            exceptionBO = new ExceptionBO();
            exceptionBO.setErrorFrom(NGEConstants.FIND_AGENT);
            exceptionBO.setErrorMessage(seti18ErroMessage(e.getFaultInfo()
                    .getErrorCode()));
            exceptionBO.setErrorCode(NGEConstants.FIND_AGENT);
            exceptionBO.setErrorType(NGEConstants.SERVICE_EXCEPTION);
        } catch (Exception e) {
            exceptionBO = new ExceptionBO();
            exceptionBO.setErrorFrom(NGEConstants.LINK_LICENSE);
            exceptionBO
                    .setErrorMessage(seti18ErroMessage(NGEConstants.ERROR_INVOKING_SERVICE));
            exceptionBO.setErrorType(NGEConstants.FATAL);
        }
        if (agentRespBO != null && null != agentRespBO.getErrorDetail()) {
            logger.info("Inside Service Exception");
            exceptionBO = new ExceptionBO();
            exceptionBO.setErrorFrom(NGEConstants.FIND_AGENT);
            exceptionBO.setErrorMessage(NGEConstants.NGPLS_SERVICE_ERROR);
            exceptionBO.setErrorCode(agentRespBO.getErrorDetail().getErrorCd());
            exceptionBO.setErrorType(NGEConstants.FATAL);
        }
        if (exceptionBO != null) {
            jsonHeaderBO = setJsonHeader(sequenceNo,
                    exceptionBO.getErrorCode(), exceptionBO.getErrorType(),
                    exceptionBO.getErrorMessage(), null);
        } else {
            jsonHeaderBO = setJsonHeader(sequenceNo, NGEConstants.SUCCESS_CODE,
                    NGEConstants.SUCCESS, NGEConstants.PRODUCT_UPDATED,
                    agentRespBO);
        }
        return jsonHeaderBO;
    }

/*	private String getSourceCode(String countryName) {
		DataCacheObject cacheObject = new DataCacheObject();
		 Map<String, String> countryMap = (Map<String, String>) cacheObject
				.getDynacacheObj("COUNTRY_ID_MAP");
		return countryMap.get(countryName);
	}*/

    @SuppressWarnings("unchecked")
    @RequestMapping(value = "/getexposuregroup", headers = "Accept=application/json")
    public @ResponseBody
    List<ExposureGroupBO> getexposuregroup(HttpServletResponse response) {
        setCacheHeader(response);
        Map<String, String> dataMap = new HashMap<String, String>();
        List<Map<String, String>> dataList = new ArrayList<Map<String, String>>();
        DataCacheObject cacheObject = new DataCacheObject();


        List<ExposureGroupBO> expoGroupBOList = new ArrayList<ExposureGroupBO>();
        ExposureGroupBO exposureGroupBO = new ExposureGroupBO();


        exposureGroupBO.setGroup("Worldwide");
        exposureGroupBO.setGroupcode("");
        dataMap = (Map<String, String>) cacheObject.getDynacacheObj("EXPOSURE_WORLDWIDE_DATA");
        //dataMap.put("worldwide", "Worldwide");
        dataList = new ArrayList<Map<String, String>>();
        dataList.add(dataMap);
        exposureGroupBO.setData(dataList);
        expoGroupBOList.add(exposureGroupBO);
        exposureGroupBO = new ExposureGroupBO();

        exposureGroupBO.setGroup("Country");
        exposureGroupBO.setGroupcode("");
        dataMap = new HashMap<String, String>();
        dataMap.put(ExpCntryType.COUNTRY_EXP_CNTRY_TYPE, "Country");
        dataList = new ArrayList<Map<String, String>>();
        dataList.add(dataMap);
        exposureGroupBO.setData(dataList);
        expoGroupBOList.add(exposureGroupBO);

        exposureGroupBO = new ExposureGroupBO();
        exposureGroupBO.setGroup("Region");
        exposureGroupBO.setGroupcode("reg");
        dataMap = (Map<String, String>) cacheObject.getDynacacheObj("EXPOSURE_REGION_DATA");
        dataList = new ArrayList<Map<String, String>>();
        dataList.add(dataMap);
        exposureGroupBO.setData(dataList);
        expoGroupBOList.add(exposureGroupBO);

        exposureGroupBO = new ExposureGroupBO();
        exposureGroupBO.setGroup("Sub Region");
        exposureGroupBO.setGroupcode("subreg");
        dataMap = (Map<String, String>) cacheObject.getDynacacheObj("EXPOSURE_SUB_REGION_DATA");
        dataList = new ArrayList<Map<String, String>>();
        dataList.add(dataMap);
        exposureGroupBO.setData(dataList);
        expoGroupBOList.add(exposureGroupBO);


        exposureGroupBO = new ExposureGroupBO();
        exposureGroupBO.setGroup("Geo Clusters");
        exposureGroupBO.setGroupcode("geoclus");
        dataMap = (Map<String, String>) cacheObject.getDynacacheObj("EXPOSURE_GEO_CLUSTER_DATA");
        dataList = new ArrayList<Map<String, String>>();
        dataList.add(dataMap);
        exposureGroupBO.setData(dataList);
        expoGroupBOList.add(exposureGroupBO);

        return expoGroupBOList;
    }

    @SuppressWarnings("unchecked")
    @RequestMapping(value = "/getexposureworldwide", headers = "Accept=application/json")
    public @ResponseBody
    List<ExposureTypeWorldWideBO> getexposureworldwide(HttpServletResponse response) {
            setCacheHeader(response);
        Map<String, String> dataMap = new HashMap<String, String>();
        DataCacheObject cacheObject = new DataCacheObject();

		List<ExposureTypeWorldWideBO> expoWorldWideList=new ArrayList<ExposureTypeWorldWideBO>();
        ExposureTypeWorldWideBO expoWorldWide = new ExposureTypeWorldWideBO();

        dataMap = (Map<String, String>) cacheObject.getDynacacheObj("EXPOSURE_WORLDWIDE_DATA");
        Set<String> worldWideSet = dataMap.keySet();
        for (String worldwideData : worldWideSet) {
            expoWorldWide.setId(worldwideData);
            expoWorldWide.setText(dataMap.get(worldwideData));
        }
        Map<String, String> stateMap = new HashMap<String, String>();
        stateMap.put("opened", "true");
        expoWorldWide.setState(stateMap);

        dataMap = (Map<String, String>) cacheObject.getDynacacheObj("EXPOSURE_COUNTRY_DATA");
        List<ExposureTypeChildrenBO> children = new ArrayList<ExposureTypeChildrenBO>();
        ExposureTypeChildrenBO exposureTypeChildrenBO = new ExposureTypeChildrenBO();
        for (String keyData : dataMap.keySet()) {
			/*Map<String, String> dataMap1 = new HashMap<String, String>();
			dataMap1.put(keyData, dataMap.get(keyData));*/
            exposureTypeChildrenBO = new ExposureTypeChildrenBO();
            exposureTypeChildrenBO.setId(keyData);
            exposureTypeChildrenBO.setText(dataMap.get(keyData));

            children.add(exposureTypeChildrenBO);
        }
        Collections.sort(children, ExposureTypeChildrenBO.exposureTypeChildrenBOCompartor);
        expoWorldWide.setChildren(children);
        expoWorldWideList.add(expoWorldWide);
        return expoWorldWideList;
    }

    @SuppressWarnings("unchecked")
    @RequestMapping(value = "/getexposurebycountry", headers = "Accept=application/json")
    public @ResponseBody
    List<ExposureTypeChildrenBO> getexposurebycountry(HttpServletResponse response) {
        setCacheHeader(response);
        List<ExposureTypeChildrenBO> dataList = new ArrayList<ExposureTypeChildrenBO>();
        ExposureTypeChildrenBO exposureTypeChildrenBO = new ExposureTypeChildrenBO();
        Map<String, String> dataMap = new HashMap<String, String>();
        DataCacheObject cacheObject = new DataCacheObject();

        dataMap = (Map<String, String>) cacheObject.getDynacacheObj("EXPOSURE_COUNTRY_DATA");
        for (String keyData : dataMap.keySet()) {
			/*Map<String, String> dataMap1 = new HashMap<String, String>();
			dataMap1.put(keyData, dataMap.get(keyData));*/
            exposureTypeChildrenBO = new ExposureTypeChildrenBO();
            exposureTypeChildrenBO.setId(keyData);
            exposureTypeChildrenBO.setText(dataMap.get(keyData));

            dataList.add(exposureTypeChildrenBO);
        }
        Collections.sort(dataList, ExposureTypeChildrenBO.exposureTypeChildrenBOCompartor);
        return dataList;
    }


    @SuppressWarnings("unchecked")
    @RequestMapping(value = "/getexposurebyregion", headers = "Accept=application/json")
    public @ResponseBody
    List<ExposureTypeRegionBO> getexposurebyregion(HttpServletResponse response) {
        setCacheHeader(response);
        Map<String, String> worldWideMap = new HashMap<String, String>();
        Map<String, String> regionMap = new HashMap<String, String>();
        Map<String, String> geoClusterDataMap = new HashMap<String, String>();
        Map<String, String> countryMap = new HashMap<String, String>();
        Map<String, String> subRegionDataMap = new HashMap<String, String>();
        DataCacheObject cacheObject = new DataCacheObject();

        List<ExposureTypeRegionBO> expoRegionList = new ArrayList<ExposureTypeRegionBO>();
        ExposureTypeRegionBO expoRegionBO = new ExposureTypeRegionBO();

        expoRegionBO.setText("Worldwide");
        expoRegionBO.setId("worldwide");
        worldWideMap = (Map<String, String>) cacheObject.getDynacacheObj("EXPOSURE_WORLDWIDE_DATA");
        Set<String> worldWideSet = worldWideMap.keySet();
        for (String worldwideData : worldWideSet) {
            expoRegionBO.setId(worldwideData);
            expoRegionBO.setText(worldWideMap.get(worldwideData));
        }
        Map<String, String> stateMap = new HashMap<String, String>();
        stateMap.put("opened", "true");
        stateMap.put("disabled", "true");

        expoRegionBO.setState(stateMap);
        List<ExposureTypeRegionDataBO> regionChildren = new ArrayList<ExposureTypeRegionDataBO>();
        ExposureTypeRegionDataBO regionData = new ExposureTypeRegionDataBO();
        regionMap = (Map<String, String>) cacheObject.getDynacacheObj("EXPOSURE_REGION_DATA");
        for (String regionId : regionMap.keySet()) {
            regionData = new ExposureTypeRegionDataBO();
            regionData.setId(regionId);
            regionData.setText(regionMap.get(regionId) + " (Region)");

            List<ExposureTypeSubRegionDataBO> subRegionChildern = new ArrayList<ExposureTypeSubRegionDataBO>();
            ExposureTypeSubRegionDataBO subRegion = new ExposureTypeSubRegionDataBO();
            subRegionDataMap = (Map<String, String>) cacheObject.getDynacacheObj("EXPOSURE_SUB_REGION_DATA");
            for (String subRegionId : subRegionDataMap.keySet()) {
                if (subRegionId.split("-")[0].equals(regionId)) {
                    subRegion = new ExposureTypeSubRegionDataBO();
                    subRegion.setId(regionId + "-" + subRegionId.split("-")[1]);
                    subRegion.setText(subRegionDataMap.get(subRegionId) + " (Sub Region)");

                    List<ExposureTypeWorldWideBO> geoClusterChildren = new ArrayList<ExposureTypeWorldWideBO>();
                    ExposureTypeWorldWideBO geoCluster = new ExposureTypeWorldWideBO();

                    geoClusterDataMap = (Map<String, String>) cacheObject.getDynacacheObj("EXPOSURE_GEO_CLUSTER_DATA");
                    for (String geoClusterKey : geoClusterDataMap.keySet()) {

                        if (geoClusterKey.split("-")[0].equals(regionId) &&
                                geoClusterKey.split("-")[1].equals(subRegionId.split("-")[1])) {
                            geoCluster = new ExposureTypeWorldWideBO();
                            geoCluster.setId(regionId + "-" + subRegionId.split("-")[1] + "-" + geoClusterKey.split("-")[2]);
                            geoCluster.setText(geoClusterDataMap.get(geoClusterKey) + " (Geo Cluster)");
                            List<ExposureTypeChildrenBO> countryChildren = new ArrayList<ExposureTypeChildrenBO>();
                            ExposureTypeChildrenBO exposureTypeChildrenBO = new ExposureTypeChildrenBO();

                            //Map<String,String> county=new HashMap<String,String>();

                            countryMap = (Map<String, String>) cacheObject.getDynacacheObj("EXPOSURE_COUNTRY_DATA");
                            for (String countryKey : countryMap.keySet()) {
                                if (countryKey.split("-")[0].equals(regionId) &&
                                        countryKey.split("-")[1].equals(subRegionId.split("-")[1]) &&
                                        countryKey.split("-")[2].equals(geoClusterKey.split("-")[2])) {
									/*county=new HashMap<String,String>();
									county.put(countryKey.split("-")[3], countryMap.get(countryKey));*/
                                    exposureTypeChildrenBO = new ExposureTypeChildrenBO();
                                    exposureTypeChildrenBO.setId(countryKey.split("-")[3]);
                                    exposureTypeChildrenBO.setText(countryMap.get(countryKey));
                                    countryChildren.add(exposureTypeChildrenBO);

                                }
                            }
                            Collections.sort(countryChildren, ExposureTypeChildrenBO.exposureTypeChildrenBOCompartor);
                            geoCluster.setChildren(countryChildren);
                            geoClusterChildren.add(geoCluster);
                        }

                    }
                    Collections.sort(geoClusterChildren, ExposureTypeWorldWideBO.expoWorldWideCompartor);
                    subRegion.setChildren(geoClusterChildren);
                    subRegionChildern.add(subRegion);
                }
            }
            Collections.sort(subRegionChildern, ExposureTypeSubRegionDataBO.expoSubRegCompartor);
            regionData.setChildren(subRegionChildern);
            regionChildren.add(regionData);
        }
        Collections.sort(regionChildren, ExposureTypeRegionDataBO.expoRegionCompartor);
        expoRegionBO.setChildren(regionChildren);
        expoRegionList.add(expoRegionBO);
        return expoRegionList;
    }

    @SuppressWarnings("unchecked")
    @RequestMapping(value = "/countryBranch", headers = "Accept=application/json")
    public @ResponseBody
    List<Map<String, String>> getBranch(HttpServletResponse response) {
        setCacheHeader(response);
        List<Map<String, String>> list = new ArrayList<Map<String, String>>();
        DataCacheObject cacheObject = new DataCacheObject();
        list = (List<Map<String, String>>) cacheObject
                .getDynacacheObj("BRANCH_BY_COUNTRY");
        return list;
    }

    @SuppressWarnings("unchecked")
    @RequestMapping(value = "/creditedCountry", headers = "Accept=application/json")
    public @ResponseBody
    List<Map<String, String>> getCreditedCountry(@RequestParam(value = "creditedBranchHidden", required = false) String countryCd,
                                                 @RequestParam(value = "workingBranchHidden", required = false) String workingBranchHidden, HttpServletResponse response) {
        setCacheHeader(response);
        List<Map<String, String>> dynaList = new ArrayList<Map<String, String>>();
        List<Map<String, String>> list = new ArrayList<Map<String, String>>();
        Map<String, String> inactiveList = new HashMap<String, String>();
        DataCacheObject cacheObject = new DataCacheObject();
        dynaList = (List<Map<String, String>>) cacheObject
                .getDynacacheObj("COUNTRY_WITH_BRANCH");
        list.addAll(dynaList);
        inactiveList = (Map<String, String>) cacheObject
                .getDynacacheObj("INACTIVE_COUNTRY_WITH_BRANCH");

        if (countryCd == null) {
            countryCd = workingBranchHidden;
        }
        if ((countryCd != null && !countryCd.equalsIgnoreCase("9999") && inactiveList != null && inactiveList.containsKey(countryCd))) {
            Map<String, String> countryCdMap = new HashMap<String, String>();
            countryCdMap.put(countryCd, inactiveList.get(countryCd));
            list.add(1, countryCdMap);
        }
        return list;
    }

    /**
     * @throws AIGCIExceptionMsg
     * @throws JsonProcessingException
     */
    @SuppressWarnings("unchecked")
    @RequestMapping(value = "/creditedCountryBranch", headers = "Accept=application/json")
    public @ResponseBody
    List<Map<String, String>> getBranch(@RequestParam(value = "creditedBranch", required = false) String countryCd, @RequestParam(value = "workingBranch", required = false) String workingCountryCd
            , @RequestParam(value = "creditedBranchCdHidden", required = false) String creditedBranchCdHidden,
                                        @RequestParam(value = "workingCountryBranchHidden", required = false) String workingCountryBranchHidden
            , HttpServletResponse response) throws AIGCIExceptionMsg, JsonProcessingException {
        setCacheHeader(response);
        List<Map<String, String>> list = new ArrayList<Map<String, String>>();
        List<Map<String, String>> dynaList = new ArrayList<Map<String, String>>();
        DataCacheObject cacheObject = new DataCacheObject();
		/*AddTransactionHelper addTransaction = new AddTransactionHelper();
		addTransaction.groupBranchByCountry();*/
        if (countryCd != null || workingCountryCd != null) {

            Map<String, List<Map<String, String>>> map = new HashMap<String, List<Map<String, String>>>();

            Map<String, List<Map<String, String>>> dynaMap = (Map<String, List<Map<String, String>>>) cacheObject
                    .getDynacacheObj("BRANCH_BY_COUNTRY_CD");

            map.putAll(dynaMap);
            Map<String, String> inactiveMap = (Map<String, String>) cacheObject
                    .getDynacacheObj("INACTIVE_BRANCH_BY_COUNTRY_CD");


            if (countryCd == null)
                countryCd = workingCountryCd;

            dynaList = map.get(countryCd);
            if (dynaList != null) {
                list.addAll(dynaList);
            }
            if (creditedBranchCdHidden == null) {
                creditedBranchCdHidden = workingCountryBranchHidden;
            }

            if (creditedBranchCdHidden != null && !creditedBranchCdHidden.equalsIgnoreCase("9999") && inactiveMap != null &&
                    inactiveMap.containsKey(countryCd + "-" + creditedBranchCdHidden)) {
                Map<String, String> branchMap = new HashMap<String, String>();
                if (list.size() == 0) {
                    branchMap.put("00", "--Select--");
                    list.add(branchMap);
                }

                branchMap = new HashMap<String, String>();
                branchMap.put(creditedBranchCdHidden, inactiveMap.get(countryCd + "-" + creditedBranchCdHidden));
                list.add(1, branchMap);
            }
        } else
            list = null;
        return list;
    }

    @SuppressWarnings("unchecked")
    @RequestMapping(value = "/productBlockReleaseReasons", headers = "Accept=application/json")
    public @ResponseBody
    List<Map<String, String>> getReleaseReasons(HttpServletResponse response) {
        setCacheHeader(response);
        Map<String, List<Map<String, String>>> allReasons = null;
        DataCacheObject cacheObject = new DataCacheObject();
        allReasons = (Map<String, List<Map<String, String>>>) cacheObject
                .getDynacacheObj("REASONS");
        List<Map<String, String>> releaseReasons = allReasons
                .get("PRODUCT BLOCK RELEASE");
        return releaseReasons;
    }

    @SuppressWarnings("unchecked")
    @RequestMapping(value = "/countries", headers = "Accept=application/json")
    public @ResponseBody
    List<Map<String, String>> getCountries(HttpServletResponse response) {
        setCacheHeader(response);
        List<Map<String, String>> countries = new ArrayList<Map<String, String>>();
        DataCacheObject cacheObject = new DataCacheObject();
        countries = (List<Map<String, String>>) cacheObject
                .getDynacacheObj("COUNTRY_LIST");
        logger.info("CountryList" + countries.size());
        return countries;
    }


    @SuppressWarnings("unchecked")
    @RequestMapping(value = "/exposurecountries", headers = "Accept=application/json")
    public @ResponseBody
    List<Map<String, String>> getExposureCountries(HttpServletResponse response) {
        setCacheHeader(response);
        List<Map<String, String>> exposureCountries = new ArrayList<Map<String, String>>();
        DataCacheObject cacheObject = new DataCacheObject();
        exposureCountries = (List<Map<String, String>>) cacheObject
                .getDynacacheObj("EXPOSURE_COUNTRY_LIST");
        return exposureCountries;
    }

    @SuppressWarnings("unchecked")
    @RequestMapping(value = "/currencies", headers = "Accept=application/json")
    public @ResponseBody
    List<Map<String, String>> getCurrencies(@RequestParam("currencyHidden") String currencyCd, HttpServletResponse response) {
		/*long cacheAge=2000000;
		long expiry = new Date().getTime() + cacheAge*1000;
		response.addDateHeader("Expires", expiry);
		response.addDateHeader("Last-Modified",new Date().getTime());
		response.setHeader("Cache-Control", "max-age="+cacheAge);*/
        setCacheHeader(response);
        DataCacheObject cacheObject = new DataCacheObject();
        List<Map<String, String>> dynaList = new ArrayList<Map<String, String>>();
        Map<String, String> inactiveCurrencies = (Map<String, String>) cacheObject.getDynacacheObj("INACTIVE_CURRENCIES");
        dynaList = (List<Map<String, String>>) cacheObject
                .getDynacacheObj("CURRENCY_CODES");

        List<Map<String, String>> list = new ArrayList<Map<String, String>>();
        list.addAll(dynaList);
        if (currencyCd != null && !currencyCd.equalsIgnoreCase("9999") && inactiveCurrencies != null && inactiveCurrencies.containsKey(currencyCd)) {

            Map<String, String> additionalCurrency = new HashMap<String, String>();
            String currencyName = inactiveCurrencies.get(currencyCd) + " - " + currencyCd;
            additionalCurrency.put(currencyCd, currencyName);
            list.add(1, additionalCurrency);
        }
        return list;
    }

    /**
     * @throws AIGCIExceptionMsg
     */
    @RequestMapping(value = "/productTowers", headers = "Accept=application/json")
    public @ResponseBody
    List<ProductTowerBO> getProductTowers(@RequestParam(value = "productTowerHidden", required = false) String productTowerHidden, HttpServletResponse response) throws JsonProcessingException, IOException, AIGCIExceptionMsg {
        setCacheHeader(response);
        ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
        ObjectReader objectReader = new ObjectMapper().reader(ProductReferenceDataBO.class);
        Object object = new Object();
        DataCacheObject cacheObject = new DataCacheObject();
        ProductReferenceDataBO productReferenceDataBO = new ProductReferenceDataBO();
        List<ProductTowerBO> productsMapList = new ArrayList<ProductTowerBO>();
        object = cacheObject.getDynacacheObj("PRODUCT_TOWERS");
        Map<String, String> inactiveProductTower = (Map<String, String>) cacheObject.getDynacacheObj("INACTIVE_PRODUCT_TOWERS");

        productReferenceDataBO = (ProductReferenceDataBO) objectReader.readValue(ow.writeValueAsString(object));

        productsMapList = productReferenceDataBO.getData();

        if (inactiveProductTower != null && inactiveProductTower.size() > 0 && productTowerHidden != null
                && !productTowerHidden.equals(NGEConstants.OPTIONAL_FIELED_DELETE_VALUE) && inactiveProductTower.containsKey(productTowerHidden)) {
            ProductTowerBO productTowerBO = new ProductTowerBO();
            productTowerBO.setGroupcode("ttt");
            productTowerBO.setGroup(inactiveProductTower.get(productTowerHidden).split("-")[0]);
            List<Map<String, String>> dataList = new ArrayList<Map<String, String>>();
            Map<String, String> dataMap = new HashMap<String, String>();
            dataMap.put(productTowerHidden, inactiveProductTower.get(productTowerHidden).split("-")[1]);
            dataList.add(dataMap);
            productTowerBO.setData(dataList);
            productsMapList.add(1, productTowerBO);
        }
        return productsMapList;
    }

    @SuppressWarnings("unchecked")
    @RequestMapping(value = "/policyTypes", headers = "Accept=application/json")
    public @ResponseBody
    List<PolicyTypesReferenceDataBO> getPolicyTypes(HttpServletResponse response) throws JsonProcessingException, IOException {
        setCacheHeader(response);
        /* 2020 - JAR upgrade issue fixed -Start */
        ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
        ObjectReader objectReader = new ObjectMapper().reader(PolicyTypesRefDataListBO.class);
        Object object = new Object();
        PolicyTypesRefDataListBO policyTypesRefDataListBO = new PolicyTypesRefDataListBO();
        DataCacheObject cacheObject = new DataCacheObject();
        List<Map<String, String>> list = new ArrayList<Map<String, String>>();
        object = cacheObject
                .getDynacacheObj("POLICY_TYPES");

        policyTypesRefDataListBO = (PolicyTypesRefDataListBO) objectReader.readValue(ow.writeValueAsString(object));
        /* 2020 - JAR upgrade issue fixed -End */
        return policyTypesRefDataListBO.getPolicyTypesRefDataBO();
    }

    @SuppressWarnings("unchecked")
    @RequestMapping(value = "/issuingCompanies", headers = "Accept=application/json")
    public @ResponseBody
    List<Map<String, String>> getIssuingCompanies(@RequestParam(value = "issuingCompanyCdHidden", required = false) String issuingCompanyCdHidden
            , HttpServletResponse response) {
        setCacheHeader(response);
        DataCacheObject cacheObject = new DataCacheObject();
        List<Map<String, String>> issuingCompaniesList = new ArrayList<Map<String, String>>();
        List<Map<String, String>> dynaCacheissuingCompaniesList = new ArrayList<Map<String, String>>();
        List<Map<String, String>> inactiveIssuingCompaniesList = new ArrayList<Map<String, String>>();
        dynaCacheissuingCompaniesList = (List<Map<String, String>>) cacheObject
                .getDynacacheObj("ISSUING_COMPANIES");

        inactiveIssuingCompaniesList = (List<Map<String, String>>) cacheObject
                .getDynacacheObj("INACTIVE_ISSUING_COMPANIES");

        issuingCompaniesList.addAll(dynaCacheissuingCompaniesList);

        if (issuingCompanyCdHidden != null && !issuingCompanyCdHidden.equalsIgnoreCase("9999") && inactiveIssuingCompaniesList != null
                && inactiveIssuingCompaniesList.size() > 0) {
            for (Map<String, String> issCompanyData : inactiveIssuingCompaniesList) {
                if (issCompanyData.containsKey(issuingCompanyCdHidden)) {
                    issuingCompaniesList.add(issCompanyData);
                }
            }
        }
        return issuingCompaniesList;
    }

    /**
     * @throws JsonProcessingException
     */
    @SuppressWarnings("unchecked")
    @RequestMapping(value = "/products", headers = "Accept=application/json")
    public @ResponseBody
    List<MarketableAndSubProductReferenceDataBO> getProducts(@RequestParam("productTower") String productTower, @RequestParam("creditedCountryPLHidden") String creditedCountryPLHidden
            , HttpServletResponse response) throws JsonProcessingException {
        setCacheHeader(response);
        List<MarketableAndSubProductReferenceDataBO> productDataList = new ArrayList<MarketableAndSubProductReferenceDataBO>();
        ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
        ObjectReader objectReader = new ObjectMapper().reader(MarketableAndSubProductReferenceDataBO.class);
        Object object = new Object();
        Object dynaObject = new Object();
        try {
            MarketableAndSubProductReferenceDataBO productData = new MarketableAndSubProductReferenceDataBO();
            MarketableAndSubProductReferenceDataBO subProductData = new MarketableAndSubProductReferenceDataBO();
            MarketableAndSubProductReferenceDataBO dynaProductData = new MarketableAndSubProductReferenceDataBO();
            DataCacheObject cacheObject = new DataCacheObject();
            Map<String, Object> productsMap = new HashMap<String, Object>();
            if (creditedCountryPLHidden.equalsIgnoreCase(NGEConstants.Location.UNITED_STATES) || creditedCountryPLHidden.equalsIgnoreCase(NGEConstants.Location.CANADA)) {
                productsMap = (Map<String, Object>) cacheObject
                        .getDynacacheObj("PRODUCTS_BY_PRODUCTOWER_FOR_US/CANADA");
            } else {
                productsMap = (Map<String, Object>) cacheObject
                        .getDynacacheObj("PRODUCTS_BY_PRODUCTOWER_FOR_NON_US/CANADA");
            }

            dynaObject = productsMap.get(productTower + "~" + creditedCountryPLHidden);
            dynaProductData = (MarketableAndSubProductReferenceDataBO) objectReader.readValue(ow.writeValueAsString(dynaObject));
            object = productsMap.get(productTower);
            subProductData = (MarketableAndSubProductReferenceDataBO) objectReader.readValue(ow.writeValueAsString(object));
            if (dynaProductData != null && dynaProductData.getData() != null) {
                List<MarketableAndSubProductBO> data = new ArrayList<MarketableAndSubProductBO>();
                data.addAll(dynaProductData.getData());
                productData.setData(data);
                productData.setCreditedCountryPLHidden(dynaProductData.getCreditedCountryPLHidden());
                productData.setProductTower(dynaProductData.getProductTower());
            }

            if (productData.getData() != null) {
                if (subProductData != null && subProductData.getData() != null && subProductData.getData().size() > 0) {
                    productData.getData().addAll(subProductData.getData());
                }
            } else {
                List<MarketableAndSubProductBO> marketableAndSubProductBOList = new ArrayList<MarketableAndSubProductBO>();
                productData = new MarketableAndSubProductReferenceDataBO();
                Map<String, String> emptyMapPT = new HashMap<String, String>();
                emptyMapPT.put(" ", "--Select--");
                List<Map<String, String>> emptyList = new ArrayList<Map<String, String>>();
                emptyList.add(emptyMapPT);
                MarketableAndSubProductBO subProductBOForNull = new MarketableAndSubProductBO();
                subProductBOForNull.setData(emptyList);
                marketableAndSubProductBOList.add(subProductBOForNull);

                productData.setData(marketableAndSubProductBOList);
                if (subProductData != null && subProductData.getData() != null && subProductData.getData().size() > 0) {
                    productData.getData().addAll(subProductData.getData());
                }
                productData.setProductTower(productTower);
            }

            productData.setCreditedCountryPLHidden(creditedCountryPLHidden);
            productDataList.add(productData);

        } catch (Exception e) {
            logger.info("NGEUIException", e);
        }


        return productDataList;
    }

    /**
     * @throws AIGCIExceptionMsg
     */
    @SuppressWarnings("unchecked")
    @RequestMapping(value = "/divisions", headers = "Accept=application/json")
    public @ResponseBody
    List<DivisionsReferenceDataBO> getDivisions(@RequestParam("productTowerwrHidden") String productTower, @RequestParam("creditedCountryId") String creditedCountry, @RequestParam("divisionHidden") String divisionHidden,
                                                @RequestParam("mktProductwrHidden") String mktPdctCd, @RequestParam("componentProductwrHidden") String cmptPdctCd, HttpServletResponse response) throws IOException, AIGCIExceptionMsg {
        setCacheHeader(response);
        DataCacheObject cacheObject = new DataCacheObject();
        Map<String, Object> divisionsMap = new HashMap<String, Object>();

        Map<String, String> inactiveDivisionsMap = new HashMap<String, String>();
        List<DivisionsReferenceDataBO> divisonDataList = new ArrayList<DivisionsReferenceDataBO>();
        ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
        ObjectReader objectReader = new ObjectMapper().reader(DivisionsReferenceDataBO.class);
        Object object = new Object();
        DivisionsReferenceDataBO dynaDivisonData = new DivisionsReferenceDataBO();
	/*	AddProductHelper ap = new AddProductHelper();
		ap.getDivisionsByProductTowerHelper();*/
        if ((creditedCountry.equalsIgnoreCase(NGEConstants.Location.UNITED_STATES) || creditedCountry.equalsIgnoreCase(NGEConstants.Location.CANADA)) || !divisionHidden.equalsIgnoreCase("9999")) {
            DivisionsReferenceDataBO divisonData = new DivisionsReferenceDataBO();
            if (cmptPdctCd != null && cmptPdctCd.equalsIgnoreCase("00")) {
                divisionsMap = (Map<String, Object>) cacheObject
                        .getDynacacheObj("DIVISIONS_BY_SUB_PRDUCT");
                inactiveDivisionsMap = (Map<String, String>) cacheObject
                        .getDynacacheObj("INACTIVE_DIVISIONS_BY_SUB_PRDUCT");
                object = divisionsMap.get(productTower + "-" + mktPdctCd);
            } else if (cmptPdctCd != null && !cmptPdctCd.equalsIgnoreCase("00")) {
                divisionsMap = (Map<String, Object>) cacheObject
                        .getDynacacheObj("DIVISIONS_BY_CMPNT_PRDUCT");
                inactiveDivisionsMap = (Map<String, String>) cacheObject
                        .getDynacacheObj("INACTIVE_DIVISIONS_BY_CMPNT_PRDUCT");
                object = divisionsMap.get(productTower + "-" + mktPdctCd + "-" + cmptPdctCd);
            }
            dynaDivisonData = (DivisionsReferenceDataBO) objectReader.readValue(ow.writeValueAsString(object));
            if (dynaDivisonData != null && dynaDivisonData.getData() != null) {
                List<Map<String, String>> data = new ArrayList<Map<String, String>>();
                data.addAll(dynaDivisonData.getData());
                divisonData.setData(data);
                divisonData.setAllowDataEntry(dynaDivisonData.isAllowDataEntry());
                divisonData.setProductTowerwrHidden(dynaDivisonData.getProductTowerwrHidden());
            } else {
                List<Map<String, String>> data = new ArrayList<Map<String, String>>();
                Map<String, String> divisionDataMap = new HashMap<String, String>();
                divisionDataMap.put("", "--Select--");

                data.add(divisionDataMap);
                divisonData.setData(data);
                divisonData.setAllowDataEntry(true);
                divisonData.setProductTowerwrHidden(productTower);
            }

            //divisonData = divisionsMap.get(productTower);

            if (divisionHidden != null && !divisionHidden.equalsIgnoreCase("9999") && inactiveDivisionsMap != null && inactiveDivisionsMap.containsKey(productTower + "-" + divisionHidden)) {
                String inactiveDivisonData = null;
                if (cmptPdctCd != null && cmptPdctCd.equalsIgnoreCase("00")) {
                    inactiveDivisonData = inactiveDivisionsMap.get(productTower + "-" + mktPdctCd + "-" + divisionHidden);
                } else if (cmptPdctCd != null && !cmptPdctCd.equalsIgnoreCase("00")) {
                    inactiveDivisonData = inactiveDivisionsMap.get(productTower + "-" + mktPdctCd + "-" + cmptPdctCd + "-" + divisionHidden);
                }
                if (divisonData.getData() == null) {
                    divisonData = new DivisionsReferenceDataBO();
                    List<Map<String, String>> data = new ArrayList<Map<String, String>>();
                    divisonData.setData(data);
                }
                Map<String, String> divisionDataMap = new HashMap<String, String>();
                if (divisonData.getData().size() == 0) {
                    divisionDataMap.put("", "--Select--");
                    divisonData.getData().add(0, divisionDataMap);
                    divisionDataMap = new HashMap<String, String>();
                }
                divisionDataMap.put(divisionHidden, inactiveDivisonData);
                divisonData.setAllowDataEntry(true);
                divisonData.setProductTowerwrHidden(productTower);
                divisonData.getData().add(1, divisionDataMap);
            }
            divisonDataList.add(divisonData);
        } else {
            divisonDataList = null;
        }
        return divisonDataList;
    }

    /**
     * @throws IOException
     */
    @SuppressWarnings("unchecked")
    @RequestMapping(value = "/divisionsByProductTower", headers = "Accept=application/json")
    public @ResponseBody
    List<DivisionsReferenceDataBO> getDivisions(@RequestParam("productTowerwrHidden") String productTower, @RequestParam("creditedCountryId") String creditedCountry, @RequestParam("divisionHidden") String divisionHidden
            , HttpServletResponse response) throws IOException {
        setCacheHeader(response);
        DataCacheObject cacheObject = new DataCacheObject();
        Map<String, Object> divisionsMap = new HashMap<String, Object>();
        Map<String, String> inactiveDivisionsMap = new HashMap<String, String>();
        List<DivisionsReferenceDataBO> divisonDataList = new ArrayList<DivisionsReferenceDataBO>();

        DivisionsReferenceDataBO dynaDivisonData = new DivisionsReferenceDataBO();
        if ((creditedCountry.equalsIgnoreCase(NGEConstants.Location.UNITED_STATES) || creditedCountry.equalsIgnoreCase(NGEConstants.Location.CANADA)) || !divisionHidden.equalsIgnoreCase("9999")) {
            DivisionsReferenceDataBO divisonData = new DivisionsReferenceDataBO();
            divisionsMap = (Map<String, Object>) cacheObject
                    .getDynacacheObj("DIVISIONS_BY_PRODUCTOWER");

            inactiveDivisionsMap = (Map<String, String>) cacheObject
                    .getDynacacheObj("INACTIVE_DIVISIONS_BY_PRODUCTOWER");

            dynaDivisonData = (DivisionsReferenceDataBO) divisionsMap.get(productTower);
            if (dynaDivisonData != null && dynaDivisonData.getData() != null) {
                List<Map<String, String>> data = new ArrayList<Map<String, String>>();
                data.addAll(dynaDivisonData.getData());
                divisonData.setData(data);
                divisonData.setAllowDataEntry(dynaDivisonData.isAllowDataEntry());
                divisonData.setProductTowerwrHidden(dynaDivisonData.getProductTowerwrHidden());
            } else {
                List<Map<String, String>> data = new ArrayList<Map<String, String>>();
                Map<String, String> divisionDataMap = new HashMap<String, String>();
                divisionDataMap.put("", "--Select--");

                data.add(divisionDataMap);
                divisonData.setData(data);
                divisonData.setAllowDataEntry(true);
                divisonData.setProductTowerwrHidden(productTower);
            }

            //divisonData = divisionsMap.get(productTower);

            if (divisionHidden != null && !divisionHidden.equalsIgnoreCase("9999") && inactiveDivisionsMap != null && inactiveDivisionsMap.containsKey(productTower + "-" + divisionHidden)) {

                String inactiveDivisonData = inactiveDivisionsMap.get(productTower + "-" + divisionHidden);
                if (divisonData.getData() == null) {
                    divisonData = new DivisionsReferenceDataBO();
                    List<Map<String, String>> data = new ArrayList<Map<String, String>>();
                    divisonData.setData(data);
                }
                Map<String, String> divisionDataMap = new HashMap<String, String>();
                if (divisonData.getData().size() == 0) {
                    divisionDataMap.put("", "--Select--");
                    divisonData.getData().add(0, divisionDataMap);
                    divisionDataMap = new HashMap<String, String>();
                }
                divisionDataMap.put(divisionHidden, inactiveDivisonData);
                divisonData.setAllowDataEntry(true);
                divisonData.setProductTowerwrHidden(productTower);
                divisonData.getData().add(1, divisionDataMap);
            }
            divisonDataList.add(divisonData);

        } else {
            divisonDataList = null;
        }
        return divisonDataList;
    }


    @SuppressWarnings("unchecked")
    @RequestMapping(value = "/autoCloseTimePeriod", headers = "Accept=application/json")
    public @ResponseBody
    List<AutoCloseTimePeriod> autoCloseTimePeriod(@RequestParam("transName") String transName, HttpServletResponse response) {
        setCacheHeader(response);
        List<AutoCloseTimePeriod> autoCloseList = new ArrayList<AutoCloseTimePeriod>();
        AutoCloseTimePeriod autoCloseTimePeriod = new AutoCloseTimePeriod();
        List<Map<String, String>> autoCloseTimePeriodMapList = new ArrayList<Map<String, String>>();
        Map<String, String> autoCloseTimePeriodMap = new HashMap<String, String>();
        DataCacheObject cacheObject = new DataCacheObject();
        Map<String, String> list = (Map<String, String>) cacheObject
                .getDynacacheObj("PROPERTY_URLS");
        String diaryFilter = "";
        if (null != list && list.size() > 0) {
            diaryFilter = list.get(NGEConstants.DIARY_FILTER);

            String[] diaryFilterArray = diaryFilter.split(",");
            int i = 0;
            for (String diaryFilterData : diaryFilterArray) {
                autoCloseTimePeriodMap.put(String.valueOf(i), diaryFilterData);
                i++;
            }
        }

        autoCloseTimePeriodMapList.add(autoCloseTimePeriodMap);

        autoCloseTimePeriod.setData(autoCloseTimePeriodMapList);
        if (transName.equalsIgnoreCase(NGEConstants.ACTIVE_ID) || transName.equalsIgnoreCase(NGEConstants.RENEWAL_ID))
            autoCloseList.add(autoCloseTimePeriod);
        return autoCloseList;
    }

    @SuppressWarnings("unchecked")
    @RequestMapping(value = "/uwLifeCycleStatusFilter", headers = "Accept=application/json")
    public @ResponseBody
    List<UWLifeCycleStatusFilter> uwLifeCycleStatusFilter(@RequestParam("transName") String transName, HttpServletResponse response) {
        setCacheHeader(response);
        DataCacheObject cacheObject = new DataCacheObject();
        Map<String, String> lifeCycleStatusMapById = (Map<String, String>) cacheObject.getDynacacheObj("LIFECYCLE_STATUS_MAP_BY_ID");
        List<UWLifeCycleStatusFilter> uwLifeCycleStatusList = new ArrayList<UWLifeCycleStatusFilter>();
        UWLifeCycleStatusFilter uwLifeCycleStatus = new UWLifeCycleStatusFilter();
        List<Map<String, String>> uwLifeCycleStatusMapList = new ArrayList<Map<String, String>>();
        Map<String, String> uwLifeCycleStatusMap = new HashMap<String, String>();
        uwLifeCycleStatusMap.put("0", "All");
        uwLifeCycleStatusMap.put("1", lifeCycleStatusMapById.get("1"));
        uwLifeCycleStatusMap.put("2", lifeCycleStatusMapById.get("2"));
        uwLifeCycleStatusMapList.add(uwLifeCycleStatusMap);

        uwLifeCycleStatus.setData(uwLifeCycleStatusMapList);
        if (transName.equalsIgnoreCase(NGEConstants.ACTIVE_ID) || transName.equalsIgnoreCase(NGEConstants.RENEWAL_ID))
            uwLifeCycleStatusList.add(uwLifeCycleStatus);
        return uwLifeCycleStatusList;
    }

    @SuppressWarnings("unchecked")
    @RequestMapping(value = "/getDateFormat", headers = "Accept=application/json")
    public @ResponseBody
    List<Map<String, String>> getDateFormat(HttpServletResponse response) {
        setCacheHeader(response);
        DataCacheObject cacheObject = new DataCacheObject();
        Map<String, String> dateFormatMap = (Map<String, String>) cacheObject.getDynacacheObj("DATE_FORMAT_MAP");
        List<Map<String, String>> dateFormatBOMapList = new ArrayList<Map<String, String>>();
        dateFormatBOMapList.add(dateFormatMap);
        return dateFormatBOMapList;
    }

    /**
     * @param request
     */
    @RequestMapping(value = "/alertService", headers = "Accept=application/json")
    public @ResponseBody
    List<AlertServiceModel> getAlertsForSubmission(@RequestBody GetSubmissionBO submissionBO, HttpServletRequest request) {

        AlertServiceHelper alertHelper = new AlertServiceHelper();
        List<AlertServiceModel> alertList = null;
        alertList = alertHelper.submissionAlertsHelper(submissionBO);
        return alertList;
    }

    @SuppressWarnings("unchecked")
    @RequestMapping(value = "/dspCodes", headers = "Accept=application/json")
    public @ResponseBody
    List<DspReferenceDataBO> getDspCodes(@RequestParam("division") String division, @RequestParam("mktProductwrHidden") String productId, @RequestParam("componentProductwrHidden") String componentId,
                                         @RequestParam("dspHidden") String dspHidden, @RequestParam("productTowerwrHidden") String productTowerwrHidden, HttpServletResponse response) {
        setCacheHeader(response);
        DataCacheObject cacheObject = new DataCacheObject();
        List<String> dspList = new ArrayList<String>();
        List<String> dynadspList = new ArrayList<String>();
        List<Map<String, String>> responseList = new ArrayList<Map<String, String>>();
        DspReferenceDataBO dspReferenceDataBO = new DspReferenceDataBO();
        List<DspReferenceDataBO> dspReferenceDataBOList = new ArrayList<DspReferenceDataBO>();
        String key = null;
        Map<String, String> dspMap = null;
        if (componentId != null && componentId != "" && !componentId.equalsIgnoreCase("00")) {
            key = componentId + "~" + division + "~" + productTowerwrHidden;
        } else {
            key = productId + "~" + division + "~" + productTowerwrHidden;
        }
        Map<String, List<String>> dspCodesMap = new HashMap<String, List<String>>();
        //2019 Q1 release- Display DSP & MMCP in NGE
        Map<String, String> dspNmMap = new HashMap<String, String>();

        dspCodesMap = (Map<String, List<String>>) cacheObject.getDynacacheObj("DSP_CODES");
        //2019 Q1 release- Display DSP & MMCP in NGE
        dspNmMap = (Map<String, String>) cacheObject.getDynacacheObj("DSP_NM");

        if (dspCodesMap.containsKey(key)) {
            dynadspList = dspCodesMap.get(key);
            dspList.addAll(dynadspList);
        }
        if (dspHidden != null) {
            if (!dspHidden.equalsIgnoreCase("9999")) {
                if (dspList.size() == 0) {
                    dspList.add(dspHidden);
                } else if (!dspList.contains(dspHidden)) {
                    dspList.add(0, dspHidden);
                }
            }
        }

        if (dspList.size() > 0) {
            Map<String, String> selectDspMap = new HashMap<String, String>();
            selectDspMap.put("9999-9999-9999", "--Select--");
            responseList.add(selectDspMap);
            for (String dsp : dspList) {
                dspMap = new HashMap<String, String>();
                //2019 Q1 release- Display DSP & MMCP in NGE
                dspMap.put(dsp, dsp + " - " + dspNmMap.get(dsp));
                responseList.add(dspMap);
            }
        } else {
            Map<String, String> emptyDspMap = new HashMap<String, String>();
            emptyDspMap.put("9999-9999-9999", "--Select--");
            responseList.add(emptyDspMap);
        }
        dspReferenceDataBO.setDivision(division);
        dspReferenceDataBO.setMktProduct(productId);
        if (componentId != null && !componentId.equalsIgnoreCase("00")) {
            dspReferenceDataBO.setAddComponent(componentId);
        }
        dspReferenceDataBO.setData(responseList);
        dspReferenceDataBOList.add(dspReferenceDataBO);
        return dspReferenceDataBOList;
    }

    @SuppressWarnings("unchecked")
    @RequestMapping(value = "/mmcpCodes", headers = "Accept=application/json")
    public @ResponseBody
    List<MmcpReferenceDataBO> getMmcpCodes(@RequestParam("mktProductwrHidden") String mktProduct, @RequestParam("componentProductwrHidden") String componentId
            , @RequestParam("productTowerwrHidden") String productTowerwrHidden, @RequestParam("mmcpHidden") String mmcpHidden, HttpServletResponse response) {
        setCacheHeader(response);
        DataCacheObject cacheObject = new DataCacheObject();
        List<String> mmcpList = new ArrayList<String>();
        List<String> dynammcpList = new ArrayList<String>();

        Map<String, List<String>> mmcpCodesMap = new HashMap<String, List<String>>();
        Map<String, String> mmcpMap = null;
        List<Map<String, String>> responseList = new ArrayList<Map<String, String>>();
        MmcpReferenceDataBO mmcpReferenceDataBO = new MmcpReferenceDataBO();
        List<MmcpReferenceDataBO> mmcpReferenceDataBOList = new ArrayList<MmcpReferenceDataBO>();
        //2019 Q1 release- Display DSP & MMCP in NGE
        Map<String, String> mmcpNmMap = new HashMap<String, String>();
        mmcpNmMap = (Map<String, String>) cacheObject.getDynacacheObj("MMCP_NM");
        mmcpCodesMap = (Map<String, List<String>>) cacheObject.getDynacacheObj("MMCP_CODES");
        String key = null;
        if (componentId != null && componentId != "" && !componentId.equalsIgnoreCase("00")) {
            key = componentId + "~" + productTowerwrHidden;
        } else {
            key = mktProduct + "~" + productTowerwrHidden;
        }
        if (mmcpCodesMap.containsKey(key)) {
            dynammcpList = mmcpCodesMap.get(key);
            mmcpList.addAll(dynammcpList);
        }
        if (mmcpHidden != null && !mmcpHidden.equalsIgnoreCase("9999")) {
            if (mmcpList.size() == 0) {
                mmcpList.add(mmcpHidden);
            } else if (!mmcpList.contains(mmcpHidden)) {
                mmcpList.add(0, mmcpHidden);
            }
        }
        if (mmcpList.size() > 0) {
            Map<String, String> selectMmcpMap = new HashMap<String, String>();
            selectMmcpMap.put("9999-9999-9999", "--Select--");
            responseList.add(selectMmcpMap);
            for (String mmcp : mmcpList) {
                mmcpMap = new HashMap<String, String>();
                mmcpMap.put(mmcp, mmcp + " - " + mmcpNmMap.get(mmcp));
                responseList.add(mmcpMap);
            }
        } else {
            Map<String, String> emptyMmcpMap = new HashMap<String, String>();
            emptyMmcpMap.put("9999-9999-9999", "--Select--");
            responseList.add(emptyMmcpMap);
        }
        mmcpReferenceDataBO.setMktProduct(mktProduct);
        if (componentId != null && !componentId.equalsIgnoreCase("00")) {
            mmcpReferenceDataBO.setAddComponent(componentId);
        }
        mmcpReferenceDataBO.setData(responseList);
        mmcpReferenceDataBOList.add(mmcpReferenceDataBO);
        return mmcpReferenceDataBOList;
    }


    @SuppressWarnings("unchecked")
    @RequestMapping(value = "/lifeCycleStatus", headers = "Accept=application/json")
    public @ResponseBody
    Set<Map<String, String>> getLifeCycleStatus(@RequestParam("lifeCycleStatusHidden") String lifeCycleStatus, @RequestParam("reservationStatusHidden") String reservationStatus
            , HttpServletResponse response) {
        setCacheHeader(response);
        DataCacheObject cacheObject = new DataCacheObject();
        String lifeCycleReservationStatusKey = lifeCycleStatus + "~" + reservationStatus;
        Map<String, String> statusConditionMap = new HashMap<String, String>();
        Map<String, List<String>> statusTransitionMap = new HashMap<String, List<String>>();
        List<String> lifeCycleStatusList = new ArrayList<String>();
        Map<String, String> lifeCycleStatusMapById = new HashMap<String, String>();
        Set<Map<String, String>> responseList = new LinkedHashSet<Map<String, String>>();
        String statusCondition = null;
        statusConditionMap = (Map<String, String>) cacheObject.getDynacacheObj("STATUS_CONDITION");
        statusTransitionMap = (Map<String, List<String>>) cacheObject.getDynacacheObj("STATUS_TRANSITION");
        lifeCycleStatusMapById = (Map<String, String>) cacheObject.getDynacacheObj("LIFECYCLE_STATUS_MAP_BY_ID");
        statusCondition = statusConditionMap.get(lifeCycleReservationStatusKey);
        lifeCycleStatusList = statusTransitionMap.get(statusCondition);
        Map<String, String> inputLifeCycleStatusMap = new HashMap<String, String>();
        inputLifeCycleStatusMap.put(lifeCycleStatus, lifeCycleStatusMapById.get(lifeCycleStatus));
        responseList.add(inputLifeCycleStatusMap);
        if (lifeCycleStatusList.size() > 0) {
            for (String lifeCycleStatusId : lifeCycleStatusList) {
                String lifeCycleStatusName = lifeCycleStatusMapById.get(lifeCycleStatusId);
                Map<String, String> responseMap = new HashMap<String, String>();
                responseMap.put(lifeCycleStatusId, lifeCycleStatusName);
                responseList.add(responseMap);
            }
        }
        return responseList;
    }

    @SuppressWarnings("unchecked")
    @RequestMapping(value = "/reasonsForUpdate", headers = "Accept=application/json")
    public @ResponseBody
    Set<Map<String, String>> reasonsForUpdate(@RequestParam("reasonLifeCycleStatus") String lifeCycleStatus, @RequestParam("reasonReservationStatus") String reservationStatus, @RequestParam("reasonProductTower") String productTower, @RequestParam("reasonLifeCycleStatusNew") String changedLifeCycleStatus
            , HttpServletResponse response) {
        setCacheHeader(response);
        DataCacheObject cacheObject = new DataCacheObject();
        String lifeCycleReservationStatusKey = lifeCycleStatus + "~" + reservationStatus;
        Map<String, String> statusConditionMap = new HashMap<String, String>();
        Map<String, String> reasonTypeMap = new HashMap<String, String>();
        Map<String, List<String>> reasonsMap = new HashMap<String, List<String>>();
        Map<String, List<String>> reasonsByProductTower = new HashMap<String, List<String>>();
        Map<String, String> reasonNameByReasonIdMap = new HashMap<String, String>();
        String statusCondition = null;
        String reasonTypeKey = null;
        String reasonTypeId = null;
        List<String> finalReasonIds = null;
        Set<Map<String, String>> finalReasonNames = new LinkedHashSet<Map<String, String>>();
        Map<String, String> finalReasonNamesMap = new HashMap<String, String>();
        finalReasonNamesMap.put("-1", "--Select--");
        finalReasonNames.add(finalReasonNamesMap);

        List<String> reasonsForReasonType = new ArrayList<String>();
        List<String> reasonForProductTower = new ArrayList<String>();

        statusConditionMap = (Map<String, String>) cacheObject.getDynacacheObj("STATUS_CONDITION");
        reasonTypeMap = (Map<String, String>) cacheObject.getDynacacheObj("STATUS_TRANSITION_REASON_TYPE");
        reasonsMap = (Map<String, List<String>>) cacheObject.getDynacacheObj("REASON_TYPE_REASONS_MAP");
        reasonNameByReasonIdMap = (Map<String, String>) cacheObject.getDynacacheObj("REASON_ID_REASON_DESC_MAP");
        statusCondition = statusConditionMap.get(lifeCycleReservationStatusKey);
        reasonTypeKey = statusCondition + "~" + changedLifeCycleStatus;
        if (reasonTypeMap.containsKey(reasonTypeKey)) {
            reasonTypeId = reasonTypeMap.get(reasonTypeKey);
            reasonsForReasonType = reasonsMap.get(reasonTypeId);
        }
        if (changedLifeCycleStatus.equals("-1")) {
            reasonTypeKey = statusCondition + "~1";
            if (reasonTypeMap.containsKey(reasonTypeKey)) {
                reasonTypeId = reasonTypeMap.get(reasonTypeKey);
                reasonsForReasonType.addAll(reasonsMap.get(reasonTypeId));
            }
            reasonTypeKey = statusCondition + "~2";
            if (reasonTypeMap.containsKey(reasonTypeKey)) {
                reasonTypeId = reasonTypeMap.get(reasonTypeKey);
                reasonsForReasonType.addAll(reasonsMap.get(reasonTypeId));
            }
        }
        reasonsByProductTower = (Map<String, List<String>>) cacheObject.getDynacacheObj("REASON_ID_BY_PRODUCT_TOWER");
        reasonForProductTower = reasonsByProductTower.get(productTower);
        if (reasonsForReasonType.size() > 0) {
            finalReasonIds = new ArrayList<String>(reasonsForReasonType);
            finalReasonIds.retainAll(reasonForProductTower);
        }
        if (finalReasonIds != null) {
            if (finalReasonIds.size() > 0) {
                for (String reasonId : finalReasonIds) {
                    finalReasonNamesMap = new HashMap<String, String>();
                    String reasonName = reasonNameByReasonIdMap.get(reasonId);
                    finalReasonNamesMap.put(reasonId, reasonName);
                    finalReasonNames.add(finalReasonNamesMap);
                }
            }
        }
        return finalReasonNames;
    }

    /**
     * @param request
     */
    @SuppressWarnings("unchecked")
    @RequestMapping(value = "/productTowerAssetType", headers = "Accept=application/json")
	public @ResponseBody Boolean getProductTowerAssetType(@RequestParam ("productTowerId") String productTowerId, HttpServletRequest request,HttpServletResponse response){
        setCacheHeader(response);
        Boolean areAttributePresent = false;
        DataCacheObject cacheObject = new DataCacheObject();
//		Object attributeBO = null;
//		List<Object> attributesList = new ArrayList<Object>();
//		AdditionalAttributeReferenceBOForUpdate additionalAttributeReferenceBOForUpdate = new AdditionalAttributeReferenceBOForUpdate();

        try {
            Map<String, Map<String, Map<String, AttributeRefereceBOForUpdate>>> productTowerAssetTypeAttr = new HashMap<String, Map<String, Map<String, AttributeRefereceBOForUpdate>>>();
            Map<String, Map<String, AttributeRefereceBOForUpdate>> assetTypeAttr = new HashMap<String, Map<String, AttributeRefereceBOForUpdate>>();

            if (cacheObject.getDynacacheObj("PRODUCT_TOWER_ASSSET_TYPE_ATTRIBUTES") != null) {

                productTowerAssetTypeAttr = (Map<String, Map<String, Map<String, AttributeRefereceBOForUpdate>>>) cacheObject.getDynacacheObj("PRODUCT_TOWER_ASSSET_TYPE_ATTRIBUTES");
            }

            assetTypeAttr = productTowerAssetTypeAttr.get(productTowerId);
            if (assetTypeAttr.size() != 0) {
                areAttributePresent = true;
            }
        } catch (Exception e) {
            // TODO Auto-generated catch block
            logger.info("NGEUIException", e);
        }
        return areAttributePresent;
    }

    @SuppressWarnings("unchecked")
    @RequestMapping(value = "/insertBrickMetaData", headers = "Accept=application/json")
	public @ResponseBody void insertBrickMetaData(){
        UnderwriterSearchHelper underwriterSearchHelper = new UnderwriterSearchHelper();
        underwriterSearchHelper.insertBrickMetaData();
    }

    @SuppressWarnings("unchecked")
    @RequestMapping(value = "/getBrickMetaData", headers = "Accept=application/json")
	public @ResponseBody BrickMetaDataBO getBrickMetaData(HttpServletResponse response){
		/*long cacheAge=2000000;
		long expiry = new Date().getTime() + cacheAge*1000;
		//response.addDateHeader("Expires", expiry);
		//response.addDateHeader("Last-Modified",new Date().getTime());
		response.setHeader("Cache-Control", "private");*/
        //logger.info("res header "+response.getHeader("Cache-Control"));

        //long cacheAge=43200;
        //long expiry = new Date().getTime() + cacheAge*1000;
        //response.addDateHeader("Expires", expiry);
        //response.addDateHeader("Last-Modified",new Date().getTime());
        //response.setHeader("Cache-Control", "max-age="+cacheAge);
        setCacheHeader(response);


        BrickMetaDataBO brickMetaDataBO = new BrickMetaDataBO();
        DataCacheObject cacheObject = new DataCacheObject();
        String brickMetaData = null;
        ConfigProvider configProvider = new ConfigProvider();
        Properties properties = configProvider.getProperties();
//        String regionName = System.getProperty(NGEConstants.REGION);
        String regionName = (NGEConstants.REGION);
        if (!regionName.equalsIgnoreCase("desktop") && !regionName.equalsIgnoreCase("integ")) {
            if (cacheObject.getDynacacheObj("BRICK_META_DATA") != null) {
                brickMetaData = (String) cacheObject.getDynacacheObj("BRICK_META_DATA");
            }
        } else {
            try {
                URL resource = Thread.currentThread().getContextClassLoader().getResource(
                        "/ngestart/resources/json/ngeobject.json");
                String line = null;
                StringBuffer sb = new StringBuffer("");
                BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(new File(resource.toURI()))));
                while ((line = br.readLine()) != null) {
                    sb.append(line);
                }
                br.close();
                brickMetaData = sb.toString();
            } catch (Exception e) {
                logger.info("NGEUIException", e);
            }

        }
//		return brickMetaData;
        brickMetaDataBO.setBrickMetaDataValue(brickMetaData);
        return brickMetaDataBO;
    }


    @SuppressWarnings("unchecked")
    @RequestMapping(value = "/getTransactionDynamicAttribute", headers = "Accept=application/json")
	public @ResponseBody AttributeDataBOForUpdate getTransactionDynamicAttribute(HttpServletResponse response){
        setCacheHeader(response);
        DataCacheObject cacheObject = new DataCacheObject();
        AttributeDataBOForUpdate attributeDataBOForUpdate = new AttributeDataBOForUpdate();

        try {
            Map<String, Map<String, List<AttributeRefereceBOForUpdate>>> dynamicTableMap = new HashMap<String, Map<String, List<AttributeRefereceBOForUpdate>>>();
            Map<String, List<AttributeRefereceBOForUpdate>> dynamicProductTowerAttrMap = new HashMap<String, List<AttributeRefereceBOForUpdate>>();
            List<AttributeRefereceBOForUpdate> dynamicAttrList = new ArrayList<AttributeRefereceBOForUpdate>();
            if (cacheObject.getDynacacheObj("DYNAMIC_ATTR") != null) {

                dynamicTableMap = (Map<String, Map<String, List<AttributeRefereceBOForUpdate>>>) cacheObject.getDynacacheObj("DYNAMIC_ATTR");
            }
            if (dynamicTableMap != null) {
                dynamicProductTowerAttrMap = dynamicTableMap.get(TableId.TTRANSACTION_ATTRIBUTE_TABLE_ID);
                if (dynamicProductTowerAttrMap != null) {
                    dynamicAttrList = dynamicProductTowerAttrMap.get("0");
                    if (dynamicAttrList != null && dynamicAttrList.size() > 0) {
                        attributeDataBOForUpdate.setData(dynamicAttrList);
                    }
                }
            }
        } catch (Exception e) {
            // TODO Auto-generated catch block
            logger.info("NGEUIException", e);
        }
        return attributeDataBOForUpdate;
    }

    @SuppressWarnings("unchecked")
    @RequestMapping(value = "/getPolicyDynamicAttribute", headers = "Accept=application/json")
	public @ResponseBody AttributeDataBOForUpdate getPolicyDynamicAttribute(@RequestParam ("productTowerId") String productTowerId,HttpServletResponse response){
        setCacheHeader(response);
        DataCacheObject cacheObject = new DataCacheObject();
        AttributeDataBOForUpdate attributeDataBOForUpdate = new AttributeDataBOForUpdate();

        try {
            Map<String, Map<String, List<AttributeRefereceBOForUpdate>>> dynamicTableMap = new HashMap<String, Map<String, List<AttributeRefereceBOForUpdate>>>();
            Map<String, List<AttributeRefereceBOForUpdate>> dynamicProductTowerAttrMap = new HashMap<String, List<AttributeRefereceBOForUpdate>>();
            List<AttributeRefereceBOForUpdate> dynamicAttrList = new ArrayList<AttributeRefereceBOForUpdate>();
            if (cacheObject.getDynacacheObj("DYNAMIC_ATTR") != null) {

                dynamicTableMap = (Map<String, Map<String, List<AttributeRefereceBOForUpdate>>>) cacheObject.getDynacacheObj("DYNAMIC_ATTR");
            }
            if (dynamicTableMap != null) {
                dynamicProductTowerAttrMap = dynamicTableMap.get(TableId.TPOLICY_ATTRIBUTE);
                if (dynamicProductTowerAttrMap != null) {
                    dynamicAttrList = dynamicProductTowerAttrMap.get(productTowerId);
                    if (dynamicAttrList != null && dynamicAttrList.size() > 0) {
                        attributeDataBOForUpdate.setData(dynamicAttrList);
                    }
                }
            }
        } catch (Exception e) {
            // TODO Auto-generated catch block
            logger.info("NGEUIException", e);
        }
        return attributeDataBOForUpdate;
    }

    @SuppressWarnings("unchecked")
    @RequestMapping(value = "/getProductDynamicAttribute", headers = "Accept=application/json")
	public @ResponseBody AttributeDataBOForUpdate getProductDynamicAttribute(
            @RequestParam("productTowerwrHidden") String productTowerId,
            @RequestParam("prefAttrData") String prefAttrData,
            @RequestParam("prefProdTowerData") String prefProdTowerData, HttpServletResponse response
    ) {
        setCacheHeader(response);
        AttributeDataBOForUpdate attributeDataBOForUpdate = new AttributeDataBOForUpdate();

        DataCacheObject cacheObject = new DataCacheObject();


        try {
            Map<String, Map<String, List<AttributeRefereceBOForUpdate>>> dynamicTableMap = new HashMap<String, Map<String, List<AttributeRefereceBOForUpdate>>>();
            Map<String, List<AttributeRefereceBOForUpdate>> dynamicProductTowerAttrMap = new HashMap<String, List<AttributeRefereceBOForUpdate>>();
            List<AttributeRefereceBOForUpdate> dynamicAttrList = new ArrayList<AttributeRefereceBOForUpdate>();
            if (cacheObject.getDynacacheObj("DYNAMIC_ATTR") != null) {

                dynamicTableMap = (Map<String, Map<String, List<AttributeRefereceBOForUpdate>>>) cacheObject.getDynacacheObj("DYNAMIC_ATTR");
            }

            if (dynamicTableMap != null) {
                dynamicProductTowerAttrMap = dynamicTableMap.get(TableId.TTRANSACTION_COMPONENT_ATRBT);
                if (dynamicProductTowerAttrMap != null) {
                    ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
                    ObjectReader objectReader = new ObjectMapper().reader(AttributeRefereceBOForUpdate.class);
                    Object object = new Object();

                    dynamicAttrList = dynamicProductTowerAttrMap.get(productTowerId);
                    if (dynamicAttrList != null && dynamicAttrList.size() > 0) {

                        for (int i = 0; i < dynamicAttrList.size(); i++) {
                            object = dynamicAttrList.get(i);
                            AttributeRefereceBOForUpdate attrRefBOForUpdate = (AttributeRefereceBOForUpdate) objectReader.readValue(ow.writeValueAsString(object));

                            if (prefAttrData != null && prefProdTowerData != null && productTowerId.equals(prefProdTowerData)) {
                                String[] prefAttrArray = prefAttrData.split(",");
                                List<String> prefAttrList = new ArrayList<String>();
                                for (int j = 0; j < prefAttrArray.length; j++) {
                                    prefAttrList.add(prefAttrArray[j]);
                                }
                                if (prefAttrList != null && prefAttrList.contains(attrRefBOForUpdate.getAttrId())) {
                                    attrRefBOForUpdate.setInitialState("on");
                                }
                            }

                            attributeDataBOForUpdate.getData().add(attrRefBOForUpdate);

                        }

                    }
                }
            }
        } catch (Exception e) {
            // TODO Auto-generated catch block
            logger.info("NGEUIException", e);
        }
        return attributeDataBOForUpdate;
    }

    /*PI3 - Aug release - Add Low goverance attribute in user prefernce starts*/
    @SuppressWarnings("unchecked")
    @RequestMapping(value = "/getProductLowGovDynamicAttribute", headers = "Accept=application/json")
	public @ResponseBody List<Map<String, String>> getProductLowGovDynamicAttribute(
            @RequestParam("productTower") String productTowerId,
            HttpServletResponse response
    ) {
        setCacheHeader(response);
        DataCacheObject cacheObject = new DataCacheObject();
        List<Map<String, String>> prefAttrList = new ArrayList<Map<String, String>>();
        try {
            Map<String, Map<String, List<AttributeRefereceBOForUpdate>>> dynamicTableMap = new HashMap<String, Map<String, List<AttributeRefereceBOForUpdate>>>();
            Map<String, List<AttributeRefereceBOForUpdate>> dynamicProductTowerAttrMap = new HashMap<String, List<AttributeRefereceBOForUpdate>>();
            List<AttributeRefereceBOForUpdate> dynamicAttrList = new ArrayList<AttributeRefereceBOForUpdate>();

            if (cacheObject.getDynacacheObj("DYNAMIC_ATTR") != null) {

                dynamicTableMap = (Map<String, Map<String, List<AttributeRefereceBOForUpdate>>>) cacheObject.getDynacacheObj("DYNAMIC_ATTR");
            }
            if (dynamicTableMap != null) {
                dynamicProductTowerAttrMap = dynamicTableMap.get(TableId.TTRANSACTION_COMPONENT_ATRBT);
                if (dynamicProductTowerAttrMap != null) {

                    ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
                    ObjectReader objectReader = new ObjectMapper().reader(AttributeRefereceBOForUpdate.class);
                    Object object = new Object();
                    dynamicAttrList = dynamicProductTowerAttrMap.get(productTowerId);
                    if (dynamicAttrList != null && dynamicAttrList.size() > 0) {
                        for (int i = 0; i < dynamicAttrList.size(); i++) {
                            object = dynamicAttrList.get(i);
                            AttributeRefereceBOForUpdate attrRefBOForUpdate = (AttributeRefereceBOForUpdate) objectReader.readValue(ow.writeValueAsString(object));
                            prefAttrList.add(attrRefBOForUpdate.getPrefAttrIdName());
                        }
                    }
                }
            }
        } catch (Exception e) {
            // TODO Auto-generated catch block
            logger.info("NGEUIException", e);
        }
        return prefAttrList;
    }

    @SuppressWarnings("unchecked")
    @RequestMapping(value = "/productTowerAssetTypeAttr", headers = "Accept=application/json")
	public @ResponseBody AttributeDataBOForUpdate getProductTowerAssetTypeAttr(@RequestParam ("assetId") String assetTypeId,@RequestParam ("productTowerId") String productTowerId,HttpServletResponse response){
        setCacheHeader(response);
        DataCacheObject cacheObject = new DataCacheObject();
        ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
        ObjectReader objectReader = new ObjectMapper().reader(AttributeRefereceBOForUpdate.class);

        List<AttributeRefereceBOForUpdate> attributesList = new ArrayList<AttributeRefereceBOForUpdate>();
        AttributeDataBOForUpdate attributeDataBOForUpdate = new AttributeDataBOForUpdate();
        AddAdditionalAttributesHelper attributeHelper = new AddAdditionalAttributesHelper();

        try {
            Map<String, Map<String, Map<String, Object>>> productTowerAssetTypeAttr = new HashMap<String, Map<String, Map<String, Object>>>();
            Map<String, Map<String, Object>> assetTypeAttr = new HashMap<String, Map<String, Object>>();


            productTowerAssetTypeAttr = (Map<String, Map<String, Map<String, Object>>>) cacheObject.getDynacacheObj("PRODUCT_TOWER_ASSSET_TYPE_ATTRIBUTES");

            assetTypeAttr = productTowerAssetTypeAttr.get(productTowerId);
            Map<String, Object> assetTypeAttrMap = assetTypeAttr.get(assetTypeId);
            if (assetTypeAttrMap != null && assetTypeAttrMap.size() > 0) {
                Set<String> attrNameList = assetTypeAttrMap.keySet();
                for (String attrName : attrNameList) {

                    if (assetTypeAttrMap.get(attrName) != null) {

                        Object object = assetTypeAttrMap.get(attrName);
                        AttributeRefereceBOForUpdate attributeRefereceBOForUpdate = (AttributeRefereceBOForUpdate) objectReader.readValue(ow.writeValueAsString(object));

                        attributesList.add(attributeRefereceBOForUpdate);
                    }
                }
            }
            Collections.sort(attributesList, AttributeRefereceBOForUpdate.attributeRefereceBOForUpdateCompartor);
            attributeHelper.addHiddenList(attributesList, assetTypeId);
            attributeDataBOForUpdate.setData(attributesList);
        } catch (Exception e) {
            // TODO Auto-generated catch block
            logger.info("NGEUIException", e);
        }
        return attributeDataBOForUpdate;
    }
    /*PI3 - Aug release - Add Low goverance attribute in user prefernce end*/

    /**
     * @param productTowerId
     */
    @SuppressWarnings("unchecked")
    @RequestMapping(value = "/assetTypeAttr", headers = "Accept=application/json")
	public @ResponseBody AdditionalAttributeReferenceBOForUpdate getAssetTypeAttr(@RequestParam ("assetId") String assetTypeId,@RequestParam ("productTowerId") String productTowerId,HttpServletResponse response){
        setCacheHeader(response);
        DataCacheObject cacheObject = new DataCacheObject();
        Object attributeBO = null;
        List<Object> attributesList = new ArrayList<Object>();
        AdditionalAttributeReferenceBOForUpdate additionalAttributeReferenceBOForUpdate = new AdditionalAttributeReferenceBOForUpdate();
        //AddAdditionalAttributesHandler t=new AddAdditionalAttributesHandler();

        try {
            Map<String, Map<String, AttributeRefereceBOForUpdate>> assetTypeAttr = null;
            // Map<String, Map<String, String>> productTowerAttr=null;
            if (cacheObject.getDynacacheObj("ASSSET_TYPE_ATTRIBUTES") != null) {

                assetTypeAttr = (Map<String, Map<String, AttributeRefereceBOForUpdate>>) cacheObject.getDynacacheObj("ASSSET_TYPE_ATTRIBUTES");
            }
			/*if(cacheObject.getDynacacheObj("PRODUCT_TOWER_ATTRIBUTES") != null){
				productTowerAttr=(Map<String, Map<String, String>>) cacheObject.getDynacacheObj("PRODUCT_TOWER_ATTRIBUTES");
			}
	if(cacheObject.getDynacacheObj("PRODUCT_TOWER_ATTRIBUTES_MANDATORY") != null){
				productTowerAttrMandatory=(Map<String, String>) cacheObject.getDynacacheObj("PRODUCT_TOWER_ATTRIBUTES_MANDATORY");
			}
			Map<String, String> attrMapMandatory=productTowerAttr.get(productTowerId);*/
            //AddAdditionalAttributesHandler.getAssetTypeAttrHandler();
            Map<String, AttributeRefereceBOForUpdate> assetTypeAttrMap = null;
            Set<String> attrNameList = null;
            if (assetTypeAttr != null) {
                assetTypeAttrMap = assetTypeAttr.get(assetTypeId);
                attrNameList = assetTypeAttrMap.keySet();
            }
            if (attrNameList != null) {
                for (String attrName : attrNameList) {

                    if (assetTypeAttrMap != null && assetTypeAttrMap.get(attrName) != null) {

                        //List<AttributeRefereceBOForUpdate> attrRefValueList=(List<AttributeRefereceBOForUpdate>) assetTypeAttrMap.values();

                        //AttributeRefereceBOForUpdate attributeRefereceBO=null;
						/* boolean required=false;
						 if(attrMapMandatory !=null && attrMapMandatory.get(attrName)!=null && attrMapMandatory.get(attrName).equals("Y")){
							 required=true;
						 }*/
                        //assetTypeAttrMap.get(attrName).setRequired(required);
                        attributeBO = assetTypeAttrMap.get(attrName);
                        // attributeRefereceBO.s
                        //attributeRefereceBO=(AttributeRefereceBOForUpdate) attributeBO;
						/* Class<? extends AttributeRefereceBOForUpdate> attributeRefBOCast=assetTypeAttrMap.get(attrName).getClass();

						 attributeRefereceBO=attributeRefBOCast.cast(attributeBO);*/


                        //attributeRefereceBO.setRequired(required);

                        //attributeBO=attributeRefereceBO;
                        attributesList.add(attributeBO);
                    }
                }
            }


            additionalAttributeReferenceBOForUpdate.setData(attributesList);
        } catch (Exception e) {
            // TODO Auto-generated catch block
            logger.info("NGEUIException", e);
        }
        return additionalAttributeReferenceBOForUpdate;
    }

    @SuppressWarnings("unchecked")
    @RequestMapping(value = "/additionalAttributesForUpdate", headers = "Accept=application/json")
	public @ResponseBody AdditionalAttributeReferenceBOForUpdate getAdditionalAttributesForUpdate(@RequestParam ("reasonProductTower") String productTower, @RequestParam ("reasonLifeCycleStatusNew") String toLifeCycleStatus, @RequestParam ("reasonLifeCycleStatus") String fromLifeCycleStatus,HttpServletResponse response){
        setCacheHeader(response);
        DataCacheObject cacheObject = new DataCacheObject();
        Object attributeBO = null;
        List<Object> attributesList = new ArrayList<Object>();
        String statusIdKey = fromLifeCycleStatus + "~" + toLifeCycleStatus;
        Map<String, String> eventIds = (Map<String, String>) cacheObject.getDynacacheObj("EVENT_ID");
        Map<String, List<String>> eventProductTowerAttributes = (Map<String, List<String>>) cacheObject.getDynacacheObj("EVENT_PRODUCT_TOWER_ATTRIBUTE_MAP");
        Map<String, Object> eventAttributes = (Map<String, Object>) cacheObject.getDynacacheObj("EVENT_ATTRIBUTES");
        AdditionalAttributeReferenceBOForUpdate additionalAttributeReferenceBOForUpdate = new AdditionalAttributeReferenceBOForUpdate();

        String eventId = eventIds.get(statusIdKey);
        String eventProductTowerKey = eventId + "~" + productTower;
        List<String> attributeIds = eventProductTowerAttributes.get(eventProductTowerKey);
        if (attributeIds != null) {
            for (String attributeId : attributeIds) {
                attributeBO = new AttributeRefereceBOForUpdate();
                attributeBO = eventAttributes.get(attributeId);
                attributesList.add(attributeBO);
            }
        }
        additionalAttributeReferenceBOForUpdate.setData(attributesList);
        return additionalAttributeReferenceBOForUpdate;
    }

    @SuppressWarnings("unchecked")
    @RequestMapping(value = "/statesByCountry", headers = "Accept=application/json")
    public @ResponseBody
    List<StateCountryReferenceDataBO> getStatesByCountry(@RequestParam("countryselection") String countryselection, HttpServletResponse response)
            throws JsonProcessingException, IOException {
        setCacheHeader(response);
        ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
        ObjectReader objectReader = new ObjectMapper().reader(StateCountryReferenceDataBO.class);
        Object object = new Object();
        List<StateCountryReferenceDataBO> statesList = new ArrayList<StateCountryReferenceDataBO>();
        StateCountryReferenceDataBO stateCountry = new StateCountryReferenceDataBO();
        Map<String, Object> statesMap = new HashMap<String, Object>();
        DataCacheObject cacheObject = new DataCacheObject();
        statesMap = (Map<String, Object>) cacheObject
                .getDynacacheObj("STATES_BY_COUNTRY");

        object = statesMap.get(countryselection);

        stateCountry = (StateCountryReferenceDataBO) objectReader.readValue(ow.writeValueAsString(object));

        if (stateCountry == null) {
            stateCountry = new StateCountryReferenceDataBO();
        }
        statesList.add(stateCountry);
        return statesList;
    }

    /* 2021 MDM Changes - Starts */
    @SuppressWarnings("unchecked")
    @RequestMapping(value = "/statesByCountryAccountSearch", headers = "Accept=application/json")
    public @ResponseBody
    List<StateCountryReferenceDataBO> getStatesByCountryForAccountSearch(@RequestParam("countryselection") String countryselection,
                                                                         @RequestParam(value = "FEIN", required = false) String FEIN, @RequestParam(value = "NCI", required = false) String NCI,
                                                                         HttpServletResponse response)
            throws JsonProcessingException, IOException {
        setCacheHeader(response);
        ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
        ObjectReader objectReader = new ObjectMapper().reader(StateCountryReferenceDataBO.class);
        Object object = new Object();
        List<StateCountryReferenceDataBO> statesList = new ArrayList<StateCountryReferenceDataBO>();
        StateCountryReferenceDataBO stateCountry = new StateCountryReferenceDataBO();
        Map<String, Object> statesMap = new HashMap<String, Object>();
        DataCacheObject cacheObject = new DataCacheObject();
        if ((FEIN == null || ("").equals(FEIN)) && (NCI == null || ("").equals(NCI))) {
            statesMap = (Map<String, Object>) cacheObject
                    .getDynacacheObj("STATES_BY_COUNTRY");

            object = statesMap.get(countryselection);

            stateCountry = (StateCountryReferenceDataBO) objectReader.readValue(ow.writeValueAsString(object));
        } else {
            stateCountry = null;
        }


        if (stateCountry == null) {
            stateCountry = new StateCountryReferenceDataBO();
        }
        statesList.add(stateCountry);
        return statesList;
    }
    /* 2021 MDM Changes - Ends */

    @SuppressWarnings("unchecked")
    @RequestMapping(value = "/leadFollowIndicator", headers = "Accept=application/json")
    public @ResponseBody
    List<Map<String, String>> getLeadFollowIndicator(@RequestParam("aigsharepercentage") String aigPercentageValue, HttpServletResponse response) {
        setCacheHeader(response);
		/*Map<String,String> leadFollowIndMap=new HashMap<String,String>();
		List<Map<String,String>> leadFollowMapList=new ArrayList<Map<String,String>>();
		*/
        DataCacheObject cacheObject = new DataCacheObject();
        Map<String, List<Map<String, String>>> attrRefMap = new HashMap<String, List<Map<String, String>>>();
        List<Map<String, String>> attrRefValue = new ArrayList<Map<String, String>>();
        Map<String, String> refMap = new HashMap<String, String>();


        if (!aigPercentageValue.equals("100") && !aigPercentageValue.isEmpty()) {
//		leadFollowIndMap.put("--Select--", "--Select--");
//		leadFollowMapList.add(leadFollowIndMap);
//
//		leadFollowIndMap=new HashMap<String,String>();
//		leadFollowIndMap.put("Lead", "Lead");
//		leadFollowMapList.add(leadFollowIndMap);
//
//		leadFollowIndMap=new HashMap<String,String>();
//		leadFollowIndMap.put("Follow", "Follow");
//		leadFollowMapList.add(leadFollowIndMap);

            attrRefMap = (Map<String, List<Map<String, String>>>) cacheObject.getDynacacheObj("ATTRIBUTES_REFERENCES");

            if (attrRefMap != null) {
                attrRefValue = attrRefMap.get(ReferenceGroup.LEAD_FOLLOW);
            }
            return attrRefValue;
        }
        refMap.put(null, null);
        attrRefValue.add(null);
        attrRefValue = null;
        return attrRefValue;
    }

    @SuppressWarnings("unchecked")
    @RequestMapping(value = "/statesOfUS", headers = "Accept=application/json")
    public @ResponseBody
    List<Map<String, String>> getUSStates(HttpServletResponse response) {
        setCacheHeader(response);
        List<Map<String, String>> usStatesList = new ArrayList<Map<String, String>>();
        DataCacheObject cacheObject = new DataCacheObject();
        usStatesList = (List<Map<String, String>>) cacheObject
                .getDynacacheObj("US_STATES");
        return usStatesList;
    }

    @SuppressWarnings("unchecked")
    @RequestMapping(value = "/componentsByMarketableProduct", headers = "Accept=application/json")
    public @ResponseBody
    List<ComponentsDataReferenceBO> getcomponentsByMarketableProduct(@RequestParam(value = "mktProductCmpwrHidden", required = false) String mktProductCmpwrHidden,
                                                                     @RequestParam(value = "productTowerwrHidden", required = false) String productTowerwrHidden,
                                                                     @RequestParam(value = "creditedCountrywrHidden", required = false) String creditedCountry, HttpServletResponse response) throws JsonProcessingException, IOException {
        setCacheHeader(response);
        ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
        ObjectReader objectReader = new ObjectMapper().reader(ComponentsDataReferenceBO.class);
        Object object = new Object();
        //Object object2=new Object();
        Map<String, Object> components = new HashMap<String, Object>();
        DataCacheObject cacheObject = new DataCacheObject();
        if (creditedCountry.equalsIgnoreCase(NGEConstants.Location.UNITED_STATES) || creditedCountry.equalsIgnoreCase(NGEConstants.Location.CANADA)) {
            components = (Map<String, Object>) cacheObject
                    .getDynacacheObj("COMPONENTS_BY_MARKETABLEPRODUCT_FOR_US/CANADA");
        } else {
            components = (Map<String, Object>) cacheObject
                    .getDynacacheObj("COMPONENTS_BY_MARKETABLEPRODUCT_FOR_NON_US/CANADA");
        }
        List<ComponentsDataReferenceBO> componentList = new ArrayList<ComponentsDataReferenceBO>();
        ComponentsDataReferenceBO componentsDataReferenceBO = new ComponentsDataReferenceBO();
        //ComponentsDataReferenceBO componentsDataReferenceBO2=new ComponentsDataReferenceBO();
		/*if(creditedCountry.equalsIgnoreCase(NGEConstants.Location.UNITED_STATES) || creditedCountry.equalsIgnoreCase(NGEConstants.Location.CANADA)){
			object1=components.get(mktProductCmpwrHidden+"-"+productTowerwrHidden+"-"+"Y"+"-"+"N");
			object2=components.get(mktProductCmpwrHidden+"-"+productTowerwrHidden+"-"+"Y"+"-"+"Y");
		}else{
			object1=components.get(mktProductCmpwrHidden+"-"+productTowerwrHidden+"-"+"N"+"-"+"Y");
			object2=components.get(mktProductCmpwrHidden+"-"+productTowerwrHidden+"-"+"Y"+"-"+"Y");
		}*/
        object = components.get(mktProductCmpwrHidden + "-" + productTowerwrHidden);
        componentsDataReferenceBO = (ComponentsDataReferenceBO) objectReader.readValue(ow.writeValueAsString(object));
        //componentsDataReferenceBO2=(ComponentsDataReferenceBO) objectReader.readValue(ow.writeValueAsString(object2));

        componentList.add(componentsDataReferenceBO);
        //componentList.add(componentsDataReferenceBO2);

        return componentList;
    }

    @SuppressWarnings("unchecked")
    @RequestMapping(value = "/assetTypes", headers = "Accept=application/json")
    public @ResponseBody
    List<Map<String, String>> getAssetTypes(HttpServletResponse response) {
        setCacheHeader(response);
        DataCacheObject cacheObject = new DataCacheObject();
        List<Map<String, String>> assetTypes = new ArrayList<Map<String, String>>();
        assetTypes = (List<Map<String, String>>) cacheObject.getDynacacheObj("ASSET_TYPES");
        return assetTypes;
    }

    @SuppressWarnings("unchecked")
    @RequestMapping(value = "/getLimitType", headers = "Accept=application/json")
    public @ResponseBody
    List<Map<String, String>> getLimitType(HttpServletResponse response) {
        setCacheHeader(response);
        DataCacheObject cacheObject = new DataCacheObject();

        Map<String, List<Map<String, String>>> attrRefMap = new HashMap<String, List<Map<String, String>>>();
        List<Map<String, String>> attrRefValue = new ArrayList<Map<String, String>>();
        attrRefMap = (Map<String, List<Map<String, String>>>) cacheObject.getDynacacheObj("ATTRIBUTES_REFERENCES");

		/*AddAdditionalAttributesHelper addAdditionalAttributes=new AddAdditionalAttributesHelper();
		attrRefMap=addAdditionalAttributes.getAttrReference();*/
        if (attrRefMap != null) {
            attrRefValue = attrRefMap.get(ReferenceGroup.LIMIT_TYPE_REFERENCEGROUP);
			/*System.out.println("attrRefValue"+attrRefValue);
			/*System.out.println("Before"+attrRefValue.get(0));
			attrRefTempMap.putAll(attrRefValue.get(0));
			attrRefReverseMap = attrRefTempMap.descendingMap();
			System.out.println("After1"+attrRefReverseMap);
			attrRefValueList.add(attrRefReverseMap);
			System.out.println("attrRefValueList"+attrRefValueList);*/
        }
        /*return attrRefValue;*/
        return attrRefValue;

    }

    @SuppressWarnings("unchecked")
    @RequestMapping(value = "/getPriorCarrior", headers = "Accept=application/json")
    public @ResponseBody
    List<Map<String, String>> getPriorCarrior(@RequestParam(value = "priorcarrierhidden", required = false) String priorCarriorHidden,
                                              HttpServletResponse response) {
        setCacheHeader(response);
        DataCacheObject cacheObject = new DataCacheObject();
        Map<String, List<Map<String, String>>> attrRefMap = new HashMap<String, List<Map<String, String>>>();
        List<Map<String, String>> attrRefValue = new ArrayList<Map<String, String>>();
        List<Map<String, String>> dynaCacheattrRefValue = new ArrayList<Map<String, String>>();
        List<Map<String, String>> inactiveAttrRefValue = new ArrayList<Map<String, String>>();
        attrRefMap = (Map<String, List<Map<String, String>>>) cacheObject.getDynacacheObj("ATTRIBUTES_REFERENCES");


        dynaCacheattrRefValue = attrRefMap.get(ReferenceGroup.PRIOR_CARRIOR);

        attrRefValue.addAll(dynaCacheattrRefValue);
        inactiveAttrRefValue = attrRefMap.get(ReferenceGroup.PRIOR_CARRIOR + "~" + NGEConstants.DELETED_IN_INDICATOR_Y);
        if (priorCarriorHidden != null && !priorCarriorHidden.equalsIgnoreCase("9999") && inactiveAttrRefValue != null && inactiveAttrRefValue.size() > 0) {
            for (Map<String, String> attrData : inactiveAttrRefValue) {
                if (attrData.containsKey(priorCarriorHidden)) {
                    attrRefValue.add(1, attrData);
                }
            }


        }

		/*AddAdditionalAttributesHelper addAdditionalAttributes = new AddAdditionalAttributesHelper();
		addAdditionalAttributes.getAttrReference();*/

        return attrRefValue;
    }

    @SuppressWarnings("unchecked")
    @RequestMapping(value = "/getRecurringAndNonRecurring", headers = "Accept=application/json")
    public @ResponseBody
    List<Map<String, String>> getRecurringAndNonRecurring(HttpServletResponse response) {
        setCacheHeader(response);
        DataCacheObject cacheObject = new DataCacheObject();
        Map<String, List<Map<String, String>>> attrRefMap = new HashMap<String, List<Map<String, String>>>();
        List<Map<String, String>> attrRefValue = new ArrayList<Map<String, String>>();
        attrRefMap = (Map<String, List<Map<String, String>>>) cacheObject.getDynacacheObj("ATTRIBUTES_REFERENCES");
		/*AddAdditionalAttributesHelper addAdditionalAttributes = new AddAdditionalAttributesHelper();
		attrRefMap =addAdditionalAttributes.getAttrReference();*/
        if (attrRefMap != null) {
            attrRefValue = attrRefMap.get(ReferenceGroup.RECURRING_NON_RECURRING);
        }
        return attrRefValue;
    }

    @SuppressWarnings("unchecked")
    @RequestMapping(value = "/getYesOrNoIndicator", headers = "Accept=application/json")
    public @ResponseBody
    List<Map<String, String>> getYesOrNoIndicator(HttpServletResponse response) {
        setCacheHeader(response);
        DataCacheObject cacheObject = new DataCacheObject();
        Map<String, List<Map<String, String>>> attrRefMap = new HashMap<String, List<Map<String, String>>>();
        List<Map<String, String>> attrRefValue = new ArrayList<Map<String, String>>();
        attrRefMap = (Map<String, List<Map<String, String>>>) cacheObject.getDynacacheObj("ATTRIBUTES_REFERENCES");
        if (attrRefMap != null) {
            attrRefValue = attrRefMap.get(ReferenceGroup.YES_OR_NO);
        }
        return attrRefValue;
    }

    @RequestMapping(value = "/transactionAttributes", headers = "Accept=application/json")
	public @ResponseBody Object getTransactionAttributes(HttpServletResponse response){
        setCacheHeader(response);
        DataCacheObject cacheObject = new DataCacheObject();
        Map<String, Object> additionalAttributes = new HashMap<String, Object>();
        additionalAttributes = (Map<String, Object>) cacheObject.getDynacacheObj("ADDITIONAL_ATTRIBUTES");
        Object transactionAttributes = additionalAttributes.get(NGEConstants.TABLE_TRANSACTION_ATTRIBUTE);
        return transactionAttributes;
    }

    @RequestMapping(value = "/transactionProductAttributes", headers = "Accept=application/json")
	public @ResponseBody Object getTransactionProductAttributes(HttpServletResponse response){
        setCacheHeader(response);
        DataCacheObject cacheObject = new DataCacheObject();
        Map<String, Object> additionalAttributes = new HashMap<String, Object>();
        additionalAttributes = (Map<String, Object>) cacheObject.getDynacacheObj("ADDITIONAL_ATTRIBUTES");
        Object transactionProductAttributes = additionalAttributes.get(NGEConstants.TABLE_TTRANSACTION_PRODUCT_ATTRIBUTE);
        return transactionProductAttributes;
    }

    @SuppressWarnings("unchecked")
    @RequestMapping(value = "/componentStatusAttributes", headers = "Accept=application/json")
	public @ResponseBody Object getComponentStatusAttributes(HttpServletResponse response){
        setCacheHeader(response);
        DataCacheObject cacheObject = new DataCacheObject();
        Map<String, Object> additionalAttributes = new HashMap<String, Object>();
        additionalAttributes = (Map<String, Object>) cacheObject.getDynacacheObj("ADDITIONAL_ATTRIBUTES");
        Object componentStatusAttributes = additionalAttributes.get(NGEConstants.TABLE_COMPONENT_STATUS_ATTRIBUTE);
        return componentStatusAttributes;
    }

    @RequestMapping(value = "/towerEventAttributes", headers = "Accept=application/json")
	public @ResponseBody Object getTowerEventAttributes(HttpServletResponse response){
        setCacheHeader(response);
        DataCacheObject cacheObject = new DataCacheObject();
        Map<String, Object> additionalAttributes = new HashMap<String, Object>();
        additionalAttributes = (Map<String, Object>) cacheObject.getDynacacheObj("ADDITIONAL_ATTRIBUTES");
        Object towerEventAttributes = additionalAttributes.get(NGEConstants.TABLE_TOWER_EVENT);
        return towerEventAttributes;
    }

    @RequestMapping(value = "/policyAttributes", headers = "Accept=application/json")
	public @ResponseBody Object getPolicyAttributes(HttpServletResponse response){
        setCacheHeader(response);
        DataCacheObject cacheObject = new DataCacheObject();
        Map<String, Object> additionalAttributes = new HashMap<String, Object>();
        additionalAttributes = (Map<String, Object>) cacheObject.getDynacacheObj("ADDITIONAL_ATTRIBUTES");
        Object policyAttributes = additionalAttributes.get(NGEConstants.TABLE_POLICY_ATTRIBUTE);
        return policyAttributes;
    }

    @RequestMapping(value = "/assetAttributes", headers = "Accept=application/json")
	public @ResponseBody Object getAssetAttributes(HttpServletResponse response){
        setCacheHeader(response);
        DataCacheObject cacheObject = new DataCacheObject();
        Map<String, Object> additionalAttributes = new HashMap<String, Object>();
        additionalAttributes = (Map<String, Object>) cacheObject.getDynacacheObj("ADDITIONAL_ATTRIBUTES");
        Object assetAttributes = additionalAttributes.get(NGEConstants.TABLE_ASSET_ATTRIBUTE);
        return assetAttributes;
    }

    @RequestMapping(value = "/transactionComponentAttributes", headers = "Accept=application/json")
	public @ResponseBody Object getTransactionComponentAttributes(HttpServletResponse response){
        setCacheHeader(response);
        DataCacheObject cacheObject = new DataCacheObject();
        Map<String, Object> additionalAttributes = new HashMap<String, Object>();
        additionalAttributes = (Map<String, Object>) cacheObject.getDynacacheObj("ADDITIONAL_ATTRIBUTES");
        Object transactionComponentAttributes = additionalAttributes.get(NGEConstants.TABLE_TRANSACTION_COMPONENT_ATRBT);
        return transactionComponentAttributes;
    }

    @RequestMapping(value = "/productTowerAttributes", headers = "Accept=application/json")
	public @ResponseBody Object getProductTowerAttributes(HttpServletResponse response){
        setCacheHeader(response);
        DataCacheObject cacheObject = new DataCacheObject();
        Map<String, Object> additionalAttributes = new HashMap<String, Object>();
        additionalAttributes = (Map<String, Object>) cacheObject.getDynacacheObj("ADDITIONAL_ATTRIBUTES");
        Object productTowerAttributes = additionalAttributes.get(NGEConstants.TABLE_PRODUCT_TOWER_ATTRIBUTE);
        return productTowerAttributes;
    }

    @RequestMapping(value = "/businessTypes", headers = "Accept= application/json")
	public @ResponseBody List<BusinessTypeBO> getBusinessTypes(HttpServletResponse response){
        setCacheHeader(response);
        DataCacheObject cacheObject = new DataCacheObject();
        List<BusinessTypeBO> businessTypes = new ArrayList<BusinessTypeBO>();
        businessTypes = (List<BusinessTypeBO>) cacheObject.getDynacacheObj("BUSINESS_TYPES");
        return businessTypes;
    }

    @RequestMapping(value = "/searchUnderwriter", headers = "Accept=application/json", method = RequestMethod.POST)
    public @ResponseBody
    JSONHeaderBO searchUnderwriter(
            @RequestBody UnderwriterSearchReqBO underwriterSearchReqBO) throws AIGCIExceptionMsg {
        UnderwriterSearchGridBO searchBO = new UnderwriterSearchGridBO();
        UnderwriterSearchHelper underwriterSearchHelper = new UnderwriterSearchHelper();
        List<UnderwriterSearchResBO> underwritersList = underwriterSearchHelper
                .searchUnderwriterHelper(underwriterSearchReqBO);
        SequenceNumberGeneration generateObj = new SequenceNumberGeneration();
        HashMap<String, String> sequenceNames = new HashMap<>();
        HashMap<String, Object> sequenceValueMap = new HashMap<String, Object>();
        sequenceNames.put("SEARCH_UNDERWRITER", "INT");
        sequenceValueMap = generateObj.getNextSequenceNumber(sequenceNames);
        int sequenceNo = Integer.parseInt(sequenceValueMap.get(
                "SEARCH_UNDERWRITER").toString());
        NGEProperties ngeProperties = new NGEProperties();
        String count = ngeProperties.readMessageFromFile(NGEConstants.UNDERWRITER_SEARCH_MAX_COUNT, NGEConstants.MESSAGE_FILE_NAME, true);
        searchBO.setPage("1");
        searchBO.setRecords(count);
        searchBO.setRows(underwritersList);
        String i18Message = "";
        if (underwritersList.size() > 0) {
            i18Message = seti18ErroMessage(NGEConstants.UNDERWRITER_SEARCH_SUCCESSFUL);
            searchBO.setTotal(Integer.toString(underwritersList.size()));
        } else {
            i18Message = seti18ErroMessage(NGEConstants.UNDERWRITER_SEARCH_FAILURE);
        }
        JSONHeaderBO jsonHeader = null;
        logger.info("The total Underwriter is : " + underwritersList.size());
        if (underwritersList.size() > 0) {
            jsonHeader = setJsonHeader(sequenceNo, NGEConstants.SUCCESS_CODE,
                    NGEConstants.SUCCESS, i18Message, searchBO);
        } else {
            jsonHeader = setJsonHeader(sequenceNo, NGEConstants.ERROR,
                    NGEConstants.FAILURE, i18Message, searchBO);
        }
        return jsonHeader;
    }

    @RequestMapping(value = "/searchPolicy", headers = "Accept=application/json", method = RequestMethod.POST)
    public @ResponseBody
    JSONHeaderBO searchPolicy(@RequestBody PolicySearchReqBO policySearchReqBO) throws AIGCIExceptionMsg {
        PolicySearchHelper searchHelper = new PolicySearchHelper();
        List<PolicySearchRespBo> policies = searchHelper
                .searchPolicyHelper(policySearchReqBO);
        PolicySearchGridBO gridBO = new PolicySearchGridBO();
        gridBO.setRecords("6");
        gridBO.setPage("1");
        String i18Message = "";
        if (policies.size() > 0) {
            i18Message = seti18ErroMessage(NGEConstants.POLICY_SEARCH_SUCCESSFUL);
            gridBO.setTotal(Integer.toString(policies.size()));
        } else {
            i18Message = seti18ErroMessage(NGEConstants.POLICY_SEARCH_FAILURE);
        }
        gridBO.setRows(policies);
        JSONHeaderBO jsonHeader = null;
        if (policies.size() > 0) {
            jsonHeader = setJsonHeader(0, NGEConstants.SUCCESS_CODE,
                    NGEConstants.SUCCESS, i18Message, gridBO);
        } else {
            jsonHeader = setJsonHeader(0, NGEConstants.ERROR,
                    NGEConstants.FAILURE, i18Message, gridBO);
        }
        return jsonHeader;
    }

    public boolean tokenVerification(HttpServletRequest request) {
        logger.info("Entered in to Token Authorization Entering");
        HttpSession session = null;
        session = request.getSession(false);
        String reqToken = (String) session.getAttribute("sescsrftoken");
        CsrfToken expectedtoken = (CsrfToken) request.getAttribute("_csrf");
        logger.info("session token : " + reqToken);
        boolean error = false;
        ConfigProvider configProvider = new ConfigProvider();
        Properties properties = configProvider.getProperties();
        String securityFilter_CSRF = properties.getProperty("securityfilter_csrf");
//        String securityFilter_CSRF = System.getProperty("securityfilter_csrf");
        securityFilter_CSRF = securityFilter_CSRF != null ? securityFilter_CSRF
                .trim() : null;
        boolean isSecurityFilterCSRFOn = (securityFilter_CSRF == null
                || "".equalsIgnoreCase(securityFilter_CSRF) || "ON"
                .equalsIgnoreCase(securityFilter_CSRF));
        logger.info("CSRF Check Required? " + isSecurityFilterCSRFOn);
        isSecurityFilterCSRFOn = false;
        if (isSecurityFilterCSRFOn) {
            String sesToken = expectedtoken.getToken();
            logger.info(" CSRF Check - sesToken = " + sesToken + " reqToken = "
                    + reqToken);
            if (!getByPassRegions() && sesToken != null && reqToken != null
                    && reqToken.equalsIgnoreCase(sesToken)) {
                logger.info(" Token Validated and continuing the work flow ");
            } else {
                logger.info(" Token InValid contextToken = " + sesToken
                        + " requestToken = " + reqToken);
                error = true;
            }
        }
        logger.info("Entered in to Token Authorization Exit");
        return error;
    }

    @SuppressWarnings("unchecked")
    private boolean getByPassRegions() {
        NGEProperties ngeProperties = new NGEProperties();
        String CSRFbyPassRegions;
        boolean available = false;
        try {
            CSRFbyPassRegions = ngeProperties.readMessageFromFile(
                    NGEConstants.CSRF_BYPASS_REGIONS,
                    NGEConstants.CONFIG_FILE_NAME, true);
            regionVariable = ngeProperties.readMessageFromFile(
                    NGEConstants.REGION_VARIABLE,
                    NGEConstants.CONFIG_FILE_NAME, true);
            if (csrfByPassRegions.size() == 0 && CSRFbyPassRegions != null
                    && !CSRFbyPassRegions.equals("")) {
                synchronized (csrfByPassRegions) {
                    StringTokenizer strTok = new StringTokenizer(
                            CSRFbyPassRegions, ",");
                    while (strTok.hasMoreTokens()) {
                        String myRegion = strTok.nextToken();
                        csrfByPassRegions.put(myRegion, myRegion);
                        available = true;
                    }
                }
            }
            if (!csrfByPassRegions.containsKey((regionVariable))) {

            }
        } catch (Exception e) {
            // TODO Auto-generated catch block
            logger.info("NGEUIException", e);
        }
        return available;
    }

    public boolean paramVerification(HttpServletRequest hRequest) {
        boolean isHazardousCharsPresent = false;
        Pattern scriptTagPattern = null;
        Pattern iframePattern = null;
        Pattern xsrfPattern = null;
        Pattern badCharPattern = null;
        try {
            scriptTagPattern = Pattern.compile(".*<[^>]*script[^>]*>.*",
                    Pattern.CASE_INSENSITIVE);
            iframePattern = Pattern.compile(".*<.*iframe.*>.*",
                    Pattern.CASE_INSENSITIVE);
            xsrfPattern = Pattern.compile("WF_XSRF.", Pattern.CASE_INSENSITIVE);
            /*
             * [1] | (pipe sign) [2] & (ampersand sign) // EXCEPTION: This
             * character is not considered at this time (\\&) [3] ; (semicolon
             * sign) [4] $ (dollar sign) [5] % (percent sign) [6] @ (at sign)
             * [7] ' (single apostrophe) [8] " (quotation mark) [9] \'
             * (backslash-escaped apostrophe) [10] \" (backslash-escaped
             * quotation mark) [11] <> (triangular parenthesis) [12] ()
             * (parenthesis) [13] + (plus sign) [14] CR (Carriage return, ASCII
             * 0x0d) [15] LF (Line feed, ASCII 0x0a) [16] , (comma sign) [17] \
             * (backslash)
             */
            badCharPattern = Pattern
                    .compile("[\\|;$%@'\"\\'\\\"<>\\(\\)\\+\\n\\r,\\\\]");
        } catch (PatternSyntaxException e) {
            logger.info("NGEUIException", e);
        }
//        String securityFilter_XSS = System.getProperty("securityfilter_xss");
          ConfigProvider configProvider = new ConfigProvider();
          Properties properties = configProvider.getProperties();
          String securityFilter_XSS = properties.getProperty("securityfilter_xss");
        if (securityFilter_XSS != null)
            securityFilter_XSS = securityFilter_XSS.trim();
        boolean isSecurityFilterXSSOn = (securityFilter_XSS == null
                || "".equalsIgnoreCase(securityFilter_XSS) || "ON"
                .equalsIgnoreCase(securityFilter_XSS));
        isSecurityFilterXSSOn = false;
        if (isSecurityFilterXSSOn) {
            boolean isGetRequest = ("GET"
                    .equalsIgnoreCase(hRequest.getMethod()));
            String securityFilter_iframe = properties.getProperty("securityfilter_iframe");
            if (securityFilter_iframe != null)
                securityFilter_iframe = securityFilter_iframe.trim();
            boolean isSecurityFilterIFrameOn = (securityFilter_iframe == null
                    || "".equalsIgnoreCase(securityFilter_iframe) || "ON"
                    .equalsIgnoreCase(securityFilter_iframe));
            Enumeration<String> paramEnum = hRequest.getParameterNames();
            while (paramEnum.hasMoreElements()) {
                String paramName = paramEnum.nextElement();
                String[] paramValues = hRequest.getParameterValues(paramName);
                if (paramValues != null && paramValues.length > 0) {
                    for (int i = 0; !isHazardousCharsPresent
                            && i < paramValues.length; i++) {
                        // value = ESAPI.encoder().canonicalize(paramValues[i]);
                        // // Needs to check the ESAPI encoding for handling the
                        // SCRIPT pattern issue
                        if (scriptTagPattern != null) {
                            isHazardousCharsPresent = scriptTagPattern.matcher(
                                    paramValues[i]).find();
                        }
                        // Check for IFRAME pattern
                        if (iframePattern != null && !isHazardousCharsPresent
                                && isSecurityFilterIFrameOn) {
                            isHazardousCharsPresent = iframePattern.matcher(
                                    paramValues[i]).find();
                        }
                        // Check for XSRF pattern
                        if (xsrfPattern != null && !isHazardousCharsPresent) {
                            isHazardousCharsPresent = xsrfPattern.matcher(
                                    paramValues[i]).find();
                        }
                        // Check for bad characters pattern
                        if (badCharPattern != null && !isHazardousCharsPresent && isGetRequest) {
                            isHazardousCharsPresent = badCharPattern.matcher(
                                    paramValues[i]).find();
                        }
                    }
                }
            }
        }
        return isHazardousCharsPresent;
    }

    // TODO Producer service method to be added.

    /**
     * @param response
     * @throws IOException
     */
    @RequestMapping(value = "/searchProducerEntity", headers = "Accept=application/json", method = RequestMethod.POST)
    public @ResponseBody
    JSONHeaderBO searchProducerEntity(
            @RequestBody ProducerEntitySearchReqBO prodEntSearchReqBO, HttpServletRequest request, HttpServletResponse response) throws IOException {
        JSONHeaderBO jsonHeader = null;
        ExceptionBO exceptionBO = null;
        HttpSession session = null;
        JSONHeaderBO jsonHeaderBO = new JSONHeaderBO();
        session = request.getSession(false);
        if (session == null || (session.getAttribute(NGEConstants.SESSION_CASL_USERID) == null)) {
            //eStart 2.8 December Release - Source code scan fix:Log forging - session variable logging removed
            //response.sendRedirect("jsp/logout.jsp");
            return jsonHeaderBO;
        }
		/*else{
			logger.info("session : "+session);
		}*/
        ProducerService serviceObj = new ProducerService();
        serviceObj.setCaslServiceId((String) session.getAttribute(NGEConstants.SESSION_CASL_USERID));
        ProdEntSearchRespBO searchRespBO = new ProdEntSearchRespBO();
        //List<ProducerEntitySearchRespBO> rows = new ArrayList<ProducerEntitySearchRespBO>();

        try {
            searchRespBO = serviceObj.searchProducer(prodEntSearchReqBO);
        }/*catch(NullPointerException e){
				exceptionBO = new ExceptionBO();
				exceptionBO.setErrorFrom(NGEConstants.SEARCH_PRODUCER_SERVICE);
				logger.info("NGEUIException",e);
				exceptionBO.setErrorMessage(seti18ErroMessage(NGEConstants.INVALID_PRODUCER_NUMBER));
				exceptionBO.setErrorCode(NGEConstants.FAILURE_CODE);
				exceptionBO.setErrorType(NGEConstants.PRODUCER_ERROR);
				searchRespBO.setRows(rows);
		}*/ catch (SocketTimeoutException e) {
            exceptionBO = new ExceptionBO();
            exceptionBO.setErrorFrom(NGEConstants.SEARCH_PRODUCER_SERVICE);
            // exceptionBO.setErrorMessage(e.getMessage());
            exceptionBO
                    .setErrorMessage(seti18ErroMessage(NGEConstants.ERROR_INVOKING_PRODUCER_SERVICE));
            exceptionBO.setErrorCode(NGEConstants.FAILURE_CODE);
            exceptionBO.setErrorType(NGEConstants.FATAL);
            logger.info("NGEUIException", e);
        } catch (Exception e) {
            exceptionBO = new ExceptionBO();
            exceptionBO.setErrorFrom(NGEConstants.SEARCH_PRODUCER_SERVICE);
            // exceptionBO.setErrorMessage(e.getMessage());
            exceptionBO
                    .setErrorMessage(seti18ErroMessage(NGEConstants.ERROR_INVOKING_PRODUCER_SERVICE));
            exceptionBO.setErrorCode(NGEConstants.FAILURE_CODE);
            exceptionBO.setErrorType(NGEConstants.FATAL);
            logger.info("NGEUIException", e);
        }
        if (null != searchRespBO && null != searchRespBO.getError() && !(searchRespBO.getError().equalsIgnoreCase(NGEConstants.PRODUCER_SERVICE_DATA_NOT_FOUND_ERROR_CODE))) {
            logger.info("Setting the Error Response for the producer search");
            exceptionBO = new ExceptionBO();
            exceptionBO.setErrorFrom(NGEConstants.SEARCH_PRODUCER_SERVICE);
            // exceptionBO.setErrorMessage(e.getMessage());
            exceptionBO
                    .setErrorMessage(seti18ErroMessage(searchRespBO.getError()));
            exceptionBO.setErrorCode(NGEConstants.FAILURE_CODE);
            exceptionBO.setErrorType(NGEConstants.FATAL);
        }
        if (null == exceptionBO) {
            logger.info("inside successful message");
            jsonHeader = setJsonHeader(0, NGEConstants.SUCCESS_CODE,
                    NGEConstants.SUCCESS,
                    NGEConstants.SUBMISSION_SUCCESSFUL, searchRespBO);
        } else {
            logger.info("inside Service Failure code");
			/*jsonHeader = setJsonHeader(0, NGEConstants.FAILURE_CODE,
					NGEConstants.FAILURE,
					NGEConstants.SUBMISSION_SUCCESSFUL, searchRespBO);*/
            jsonHeader = setJsonHeader(0, exceptionBO.getErrorType(), NGEConstants.FAILURE,
                    exceptionBO.getErrorMessage(), searchRespBO);
        }
        return jsonHeader;
    }

    @RequestMapping(value = "/getProducerSession", headers = "Accept=application/json", method = RequestMethod.POST)
	public @ResponseBody JSONHeaderBO getProducerSession(@RequestBody SubmissionStartDetailsSessionBO submissionStartDetailsSessionBO,
                                    HttpServletRequest request, HttpServletResponse response) throws IOException {
        HttpSession session = null;
        String jsonBO = null;
        JSONHeaderBO jsonHeaderBO = new JSONHeaderBO();

        session = request.getSession(false);
        if (session == null || (session.getAttribute(NGEConstants.SESSION_CASL_USERID) == null)) {
            //logger.info("Invalid Session : "+session);
            response.sendRedirect("jsp/logout.jsp");
            return jsonHeaderBO;
        }
		/*else{
			logger.info("session : "+session);
		}*/
        ObjectMapper mapper = new ObjectMapper();
        StartSubmissionSessionBO submisssionSession = new StartSubmissionSessionBO();
        submisssionSession.setStartsubmission(submissionStartDetailsSessionBO);
        try {
            jsonBO = mapper.writeValueAsString(submisssionSession);
        } catch (JsonProcessingException e) {
            logger.info("NGEUIException", e);
        }

        //session = request.getSession(true);
        logger.info("************************Session Storage for Setting Initiating Producer Number Starts*******************");
        session.setAttribute(NGEConstants.START_SUBMISSION, XSSValidator.stripXSS(jsonBO));
        logger.info("************************Session Storage for Setting Initiating Producer Number Ends*******************");
        return new JSONHeaderBO();
    }

    @RequestMapping(value = "/validateProducerEntity", headers = "Accept=application/json", method = RequestMethod.POST)
	public @ResponseBody JSONHeaderBO getProdDetailsFromValidate(@RequestBody ProducerEntitySearchReqBO prodEntSearchReqBO,
                                            HttpServletRequest request, HttpServletResponse response) throws IOException {
        JSONHeaderBO jsonHeaderBO = new JSONHeaderBO();
        JSONHeaderBO jsonHeader = null;
        ExceptionBO exceptionBO = null;
        HttpSession session = null;
        session = request.getSession(false);
        if (session == null || (session.getAttribute(NGEConstants.SESSION_CASL_USERID) == null)) {
            //logger.info("Invalid Session : "+session);
            response.sendRedirect("jsp/logout.jsp");
            return jsonHeaderBO;
        }
		/*else{
			logger.info("session : "+session);
		}*/
        ProdEntSearchRespBO searchRespBO = new ProdEntSearchRespBO();
        ProducerEntitySearchRespBO entitySearchRespBO = null;
        ProducerService serviceObj = new ProducerService();
        serviceObj.setCaslServiceId((String) session.getAttribute(NGEConstants.SESSION_CASL_USERID));
        try {
            entitySearchRespBO = serviceObj.validateProducer(prodEntSearchReqBO.getProdEntityNumber());
            searchRespBO = serviceObj.setValidateProducerResponseInBO(entitySearchRespBO);
        } catch (Exception e) {
            exceptionBO = new ExceptionBO();
            exceptionBO.setErrorFrom(NGEConstants.SEARCH_PRODUCER_SERVICE);
            // exceptionBO.setErrorMessage(e.getMessage());
            exceptionBO
                    .setErrorMessage(seti18ErroMessage(NGEConstants.ERROR_INVOKING_PRODUCER_SERVICE));
            exceptionBO.setErrorCode(NGEConstants.FAILURE_CODE);
            exceptionBO.setErrorType(NGEConstants.FATAL);
            logger.info("NGEUIException", e);
        }
        if (null != entitySearchRespBO && null != entitySearchRespBO.getError() && !(entitySearchRespBO.getError().equalsIgnoreCase(NGEConstants.PRODUCER_SERVICE_DATA_NOT_FOUND_ERROR_CODE))) {
            logger.info("Setting the Error Response for the producer search");
            exceptionBO = new ExceptionBO();
            exceptionBO.setErrorFrom(NGEConstants.SEARCH_PRODUCER_SERVICE);
            // exceptionBO.setErrorMessage(e.getMessage());
            exceptionBO
                    .setErrorMessage(seti18ErroMessage(searchRespBO.getError()));
            exceptionBO.setErrorCode(NGEConstants.FAILURE_CODE);
            exceptionBO.setErrorType(NGEConstants.FATAL);
        }
        if (null == exceptionBO) {
            logger.info("inside successful message");
            jsonHeader = setJsonHeader(0, NGEConstants.SUCCESS_CODE,
                    NGEConstants.SUCCESS,
                    NGEConstants.SUBMISSION_SUCCESSFUL, searchRespBO);
        } else {
            logger.info("inside Service Failure code");
			/*jsonHeader = setJsonHeader(0, NGEConstants.FAILURE_CODE,
					NGEConstants.FAILURE,
					NGEConstants.SUBMISSION_SUCCESSFUL, searchRespBO);*/
            jsonHeader = setJsonHeader(0, exceptionBO.getErrorType(), NGEConstants.FAILURE,
                    exceptionBO.getErrorMessage(), searchRespBO);
        }

        return jsonHeader;
    }

    public String seti18ErroMessage(String ErrorMessage) {
        String i18ErrorMessge = "";
        NGEProperties ngeProperties = new NGEProperties();
        try {
            i18ErrorMessge = ngeProperties.readMessageFromFile(ErrorMessage,
                    NGEConstants.MESSAGE_FILE_NAME, true);

        } catch (Exception e) {
            // TODO Auto-generated catch block
            logger.error("Error in reading message property" + e.getMessage());
            logger.info("NGEUIException", e);
        }
        if (null == i18ErrorMessge || i18ErrorMessge.equalsIgnoreCase("")) {
            logger.info("Setting the Error in Default Mode Starts");
            i18ErrorMessge = NGEConstants.COMMON_ERROR_MESSAGE;
            logger.info("Setting the Error in Default Mode Ends");
        }
        return i18ErrorMessge;

    }

    @RequestMapping(value = "/updateProductStatusSessionData", headers = "Accept=application/json", method = RequestMethod.POST)
    public @ResponseBody
    JSONHeaderBO updateProductStatusSessionData(HttpServletRequest request,
			@RequestBody ProductStatusBO productStatusBO,HttpServletResponse response) throws IOException
	{
        HttpSession session = null;
        JSONHeaderBO jsonHeaderBO = new JSONHeaderBO();
        session = request.getSession(false);
        if (session == null || (session.getAttribute(NGEConstants.SESSION_CASL_USERID) == null)) {
            //logger.info("Invalid Session : "+session);
            response.sendRedirect("jsp/logout.jsp");
            return jsonHeaderBO;
        }
		/*else{
			logger.info("session : "+session);
		}*/
        ExceptionBO exceptionBO = null;
        SequenceNumberGeneration generateObj = new SequenceNumberGeneration();
        HashMap<String, String> sequenceNames = new HashMap<>();
        HashMap<String, Object> sequenceValueMap = new HashMap<String, Object>();
        sequenceNames.put("UPDATE_PRODUCT_STATUS_SESSION", "INT");
        sequenceValueMap = generateObj.getNextSequenceNumber(sequenceNames);
        int sequenceNo = Integer.parseInt(sequenceValueMap.get(
                "UPDATE_PRODUCT_STATUS_SESSION").toString());

        try {

            if (productStatusBO.getLifeCycleStausUpdateAction().equals(LifeCycleUpdateAction.CHANGE) ||
                    productStatusBO.getLifeCycleStausUpdateAction().equals(LifeCycleUpdateAction.NEGATIVE)) {
                SetProductStatusReqBO setProductStatusReq = (SetProductStatusReqBO) session.getAttribute(NGEConstants.SESSION_UPDATE_PRODUCT_STATUS);
                if (setProductStatusReq == null) {
                    setProductStatusReq = new SetProductStatusReqBO();
                }
                TransactionRqBO transactionRq = new TransactionRqBO();
                transactionRq.setTransactionId(productStatusBO.getTransactionId());
                transactionRq.setTransactionVersionNo(productStatusBO.getTransactionVersionNo());

                setProductStatusReq.setTransactionRq(transactionRq);

                setProductStatusReq.setWorking(setProductStatus(setProductStatusReq.getWorking(), productStatusBO, LifeCycleStatusID.WORKING, session));
                setProductStatusReq.setQuoteProducts(setProductStatus(setProductStatusReq.getQuoteProducts(), productStatusBO, LifeCycleStatusID.QUOTED, session));
                setProductStatusReq.setBindProducts(setProductStatus(setProductStatusReq.getBindProducts(), productStatusBO, LifeCycleStatusID.BOUND, session));
                setProductStatusReq.setCancel(setProductStatus(setProductStatusReq.getCancel(), productStatusBO, LifeCycleStatusID.CANCELLED, session));
                setProductStatusReq.setLost(setProductStatus(setProductStatusReq.getLost(), productStatusBO, LifeCycleStatusID.LOST, session));
                setProductStatusReq.setDecline(setProductStatus(setProductStatusReq.getDecline(), productStatusBO, LifeCycleStatusID.DECLINED, session));
                setProductStatusReq.set_void(setProductStatus(setProductStatusReq.get_void(), productStatusBO, LifeCycleStatusID.VOID, session));

                session.setAttribute(NGEConstants.SESSION_UPDATE_PRODUCT_STATUS, setProductStatusReq);
            } else if (productStatusBO.getLifeCycleStausUpdateAction().equals(LifeCycleUpdateAction.REOPEN)) {
                ReopenProductsReqBO reopenProductsReq = (ReopenProductsReqBO) session.getAttribute(NGEConstants.SESSION_REOPEN_PRODUCT);
                if (reopenProductsReq == null) {
                    reopenProductsReq = new ReopenProductsReqBO();
                }
                reopenProductsReq.setTransactionId(productStatusBO.getTransactionId());
                reopenProductsReq.setTransactionVersionNo(productStatusBO.getTransactionVersionNo());

                reopenProductsReq.setProduct(setProductStatus(reopenProductsReq.getProduct(), productStatusBO, productStatusBO.getLifeCycleStatus(), session));

                session.setAttribute(NGEConstants.SESSION_REOPEN_PRODUCT, reopenProductsReq);
            } else if (productStatusBO.getLifeCycleStausUpdateAction().equals(LifeCycleUpdateAction.UNBIND)) {
                UnBindProductReqBO unBindProductsRq = (UnBindProductReqBO) session.getAttribute(NGEConstants.SESSION_UNBIND_PRODUCT_STATUS);
                if (unBindProductsRq == null) {
                    unBindProductsRq = new UnBindProductReqBO();
                }
                unBindProductsRq.setTransactionId(productStatusBO.getTransactionId());
                unBindProductsRq.setTransactionVersionNo(productStatusBO.getTransactionVersionNo());

                unBindProductsRq.setUnbindProducts(setProductStatus(unBindProductsRq.getUnbindProducts(), productStatusBO, productStatusBO.getLifeCycleStatus(), session));

                session.setAttribute(NGEConstants.SESSION_UNBIND_PRODUCT_STATUS, unBindProductsRq);


            } else {
                exceptionBO = new ExceptionBO();
                exceptionBO.setErrorFrom(NGEConstants.UPDATE_PRODUCT_STATUS_SESSION);
                exceptionBO
                        .setErrorMessage(seti18ErroMessage(NGEConstants.ERROR_PROCESSING_REQUEST));
                exceptionBO.setErrorType(NGEConstants.FATAL);
            }
        } catch (Exception e) {
            exceptionBO = new ExceptionBO();
            exceptionBO.setErrorFrom(NGEConstants.UPDATE_PRODUCT_STATUS_SESSION);
            exceptionBO
                    .setErrorMessage(seti18ErroMessage(NGEConstants.ERROR_PROCESSING_REQUEST));
            exceptionBO.setErrorType(NGEConstants.FATAL);
            logger.info("NGEUIException", e);
        }
        if (null == exceptionBO) {
            jsonHeaderBO = setJsonHeader(sequenceNo, NGEConstants.SUCCESS_CODE,
                    NGEConstants.SUCCESS,
                    NGEConstants.SUCCESS,
                    null);
        } else {
            jsonHeaderBO = setJsonHeader(sequenceNo,
                    exceptionBO.getErrorCode(), exceptionBO.getErrorType(),
                    exceptionBO.getErrorMessage(), null);
        }
        return jsonHeaderBO;
    }

    private List<ProductStatusBO> setProductStatus(List<ProductStatusBO> productStatusBOList, ProductStatusBO productStatusBO, String lifeCycleStatus, HttpSession session) {

        if (productStatusBOList == null && lifeCycleStatus.equals(productStatusBO.getLifeCycleStatus())) {
            productStatusBOList = new ArrayList<ProductStatusBO>();
        }
        List<PolicyDetailBO> removePolicyList = new ArrayList<PolicyDetailBO>();
        if (productStatusBOList != null) {
            for (Iterator<ProductStatusBO> productStatusIter = productStatusBOList.iterator(); productStatusIter.hasNext(); ) {
                ProductStatusBO productStatus = productStatusIter.next();
                if (productStatusBO.getTabId().equals(productStatus.getTabId())) {
                    if (productStatus.getPolicyDetail() != null) {
                        removePolicyList.addAll(productStatus.getPolicyDetail());
                        if (!lifeCycleStatus.equals(productStatusBO.getLifeCycleStatus())) {
                            if (session.getAttribute("PRODUCT_POLICY_DETAIL") != null) {
                                List<PolicyDetailBO> policyList = (List<PolicyDetailBO>) session.getAttribute(NGEConstants.PRODUCT_POLICY_DETAIL);


                                for (PolicyDetailBO removePolicyBO : removePolicyList) {
                                    PolicyDetailBO toBeDeletedPolicy = null;
                                    for (PolicyDetailBO policyDetail : policyList) {
                                        String productTabKey = removePolicyBO.getProductTabKey();
                                        String compProdTabKey = removePolicyBO.getComponentProductTabKey();
                                        if (compProdTabKey.length() == 0) {
                                            compProdTabKey = "component";
                                        } else {
                                            compProdTabKey = compProdTabKey.substring(2);
                                        }
                                        if ( /*policyDetail.getTransactionId().equals(removePolicyBO.getTransactionId()) &&
												policyDetail.getVersionId().equals(removePolicyBO.getVersionId()) &&*/
                                                (policyDetail.getProductTabKey().equals(productTabKey)) &&
                                                        (policyDetail.getComponentProductTabKey().equals(compProdTabKey))
                                                        && (policyDetail.getPolicySequenceId().equals(removePolicyBO.getPolicySequenceId()))) {
                                            toBeDeletedPolicy = policyDetail;
                                            break;
                                        }
                                    }
                                    if (toBeDeletedPolicy != null)
                                        policyList.remove(toBeDeletedPolicy);
                                }
                                String headerjson = "";
                                ObjectWriter ow = new ObjectMapper().writer()
                                        .withDefaultPrettyPrinter();
                                session.setAttribute(NGEConstants.PRODUCT_POLICY_DETAIL, policyList);
                                PolicySessionBO policySessionBO = new PolicySessionBO();
                                policySessionBO.setPolicyDetailBO(policyList);

                                try {
                                    headerjson = ow.writeValueAsString(policySessionBO);
                                } catch (JsonProcessingException e) {
                                    logger.info("NGEUIException", e);
                                }
                                session.setAttribute(NGEConstants.SESSION_POLICY_DETAIL, XSSValidator.stripXSS(headerjson));
                            }

                        }
                    }
                    productStatusIter.remove();

                    break;
                }
            }
        }
        if (lifeCycleStatus.equals(productStatusBO.getLifeCycleStatus()) && !productStatusBO.isDeleteFromSession()) {
            if (productStatusBO.getPolicyDetailBO() != null && productStatusBO.getPolicyDetailBO().getPolicySequenceId() != null) {

                boolean editPolicy = true;
                for (Iterator<PolicyDetailBO> removePolicyListIter = removePolicyList.iterator(); removePolicyListIter.hasNext(); ) {
                    PolicyDetailBO policyDetailBO = removePolicyListIter.next();
                    //for(PolicyDetailBO policyDetailBO:removePolicyList){
                    String productTabKey = productStatusBO.getProductTabkey();
                    String compProdTabKey = productStatusBO.getComponentProductTabKey();
                    if (compProdTabKey.length() == 0) {
                        compProdTabKey = "component";
                    } else {
                        compProdTabKey = compProdTabKey.substring(2);
                    }
                    if (policyDetailBO.getProductTabKey().equals(productTabKey)
                            && policyDetailBO.getComponentProductTabKey().equals(compProdTabKey)
                            && policyDetailBO.getPolicySequenceId().equals(productStatusBO.getPolicyDetailBO().getPolicySequenceId())) {
                        editPolicy = false;
                        removePolicyListIter.remove();
                        break;
                    }
                }
                if (editPolicy) {
                    removePolicyList.add(productStatusBO.getPolicyDetailBO());
                } else {
                    //removePolicyList.remove(editPolicy);
                    if (productStatusBO.getPolicyDetailBO().getPolicyActionInd() != null)
                        removePolicyList.add(productStatusBO.getPolicyDetailBO());
                }
                productStatusBO.setPolicyDetail(removePolicyList);
            }
            if (productStatusBOList != null) {
                productStatusBOList.add(productStatusBO);
            }
            return productStatusBOList;
        }
        return productStatusBOList;
    }

    @RequestMapping(value = "/getDeclineReasonFromSession", headers = "Accept=application/json", method = RequestMethod.POST)
    public @ResponseBody
    JSONHeaderBO getDeclineReasonFromSession(HttpServletRequest request, @RequestBody ProductStatusBO productStatusBO, HttpServletResponse response) throws IOException {
        HttpSession session = null;
        JSONHeaderBO jsonHeaderBO = new JSONHeaderBO();
        session = request.getSession(false);
        if (session == null || (session.getAttribute(NGEConstants.SESSION_CASL_USERID) == null)) {
            //logger.info("Invalid Session : "+session);
            response.sendRedirect("jsp/logout.jsp");
            return jsonHeaderBO;
        }
		/*else{
			logger.info("session : "+session);
		}*/
        ExceptionBO exceptionBO = null;
        SequenceNumberGeneration generateObj = new SequenceNumberGeneration();
        HashMap<String, String> sequenceNames = new HashMap<>();
        HashMap<String, Object> sequenceValueMap = new HashMap<String, Object>();
        sequenceNames.put("GET_DECLINE_REASON_FROM_SESSION", "INT");
        sequenceValueMap = generateObj.getNextSequenceNumber(sequenceNames);
        int sequenceNo = Integer.parseInt(sequenceValueMap.get(
                "GET_DECLINE_REASON_FROM_SESSION").toString());

        try {

            if (productStatusBO.getLifeCycleStausUpdateAction().equals(LifeCycleUpdateAction.CHANGE) || productStatusBO.getLifeCycleStausUpdateAction().equals(LifeCycleUpdateAction.NEGATIVE)) {
                SetProductStatusReqBO setProductStatusReq = (SetProductStatusReqBO) session.getAttribute(NGEConstants.SESSION_UPDATE_PRODUCT_STATUS);
                if (setProductStatusReq != null) {
                    productStatusBO = getProductStatus(setProductStatusReq.getCancel(), productStatusBO, LifeCycleStatusID.CANCELLED);
                    productStatusBO = getProductStatus(setProductStatusReq.getLost(), productStatusBO, LifeCycleStatusID.LOST);
                    productStatusBO = getProductStatus(setProductStatusReq.getDecline(), productStatusBO, LifeCycleStatusID.DECLINED);
                    productStatusBO = getProductStatus(setProductStatusReq.get_void(), productStatusBO, LifeCycleStatusID.VOID);
                }
            } else if (productStatusBO.getLifeCycleStausUpdateAction().equals(LifeCycleUpdateAction.REOPEN)) {
                ReopenProductsReqBO reopenProductsReq = (ReopenProductsReqBO) session.getAttribute(NGEConstants.SESSION_REOPEN_PRODUCT);
                if (reopenProductsReq != null) {
                    productStatusBO = getProductStatus(reopenProductsReq.getProduct(), productStatusBO, productStatusBO.getLifeCycleStatus());
                }
            } else if (productStatusBO.getLifeCycleStausUpdateAction().equals(LifeCycleUpdateAction.UNBIND)) {
                UnBindProductReqBO unBindProductReq = (UnBindProductReqBO) session.getAttribute(NGEConstants.SESSION_UNBIND_PRODUCT_STATUS);
                if (unBindProductReq != null) {
                    productStatusBO = getProductStatus(unBindProductReq.getUnbindProducts(), productStatusBO, productStatusBO.getLifeCycleStatus());
                }

            }
            if (productStatusBO.getReasonCd() == null) {
                exceptionBO = new ExceptionBO();
                exceptionBO.setErrorFrom(NGEConstants.GET_DECLINE_REASON_SESSION);
                exceptionBO
                        .setErrorMessage(seti18ErroMessage(NGEConstants.ERROR_PROCESSING_REQUEST));
                exceptionBO.setErrorType(NGEConstants.FATAL);
            }
        } catch (Exception e) {
            exceptionBO = new ExceptionBO();
            exceptionBO.setErrorFrom(NGEConstants.GET_DECLINE_REASON_SESSION);
            exceptionBO
                    .setErrorMessage(seti18ErroMessage(NGEConstants.ERROR_PROCESSING_REQUEST));
            exceptionBO.setErrorType(NGEConstants.FATAL);
            logger.info("NGEUIException", e);
        }
        if (null == exceptionBO) {
            jsonHeaderBO = setJsonHeader(sequenceNo, NGEConstants.SUCCESS_CODE,
                    NGEConstants.SUCCESS,
                    NGEConstants.SUCCESS,
                    productStatusBO);
        } else {
            jsonHeaderBO = setJsonHeader(sequenceNo,
                    exceptionBO.getErrorCode(), exceptionBO.getErrorType(),
                    exceptionBO.getErrorMessage(), null);
        }
        return jsonHeaderBO;
    }

    private ProductStatusBO getProductStatus(List<ProductStatusBO> productStatusBOList, ProductStatusBO productStatusBO, String lifeCycleStatus) {
        if (productStatusBOList != null && lifeCycleStatus.equals(productStatusBO.getLifeCycleStatus()) && productStatusBO.getReasonCd() == null) {
            for (ProductStatusBO productStatus : productStatusBOList) {
                if (productStatusBO.getTabId().equals(productStatus.getTabId())) {
                    return productStatus;
                }
            }
        }
        return productStatusBO;
    }

    /**
     * @throws UpdateTransactionAIGCIExceptionTypeMsg
     */
    @RequestMapping(value = "/updateAccountMailingAddress", headers = "Accept=application/json", method = RequestMethod.POST)
    public @ResponseBody
    JSONHeaderBO updateAccountMailingAddressSession(HttpServletRequest request,
                                                    @RequestBody AddressDetailsBO updateAccountMailingAddress, HttpServletResponse response) throws IOException,
            UpdateTransactionAIGCIExceptionTypeMsg {
        HttpSession session = null;
        String json = null;
        session = request.getSession(false);
        JSONHeaderBO jsonHeaderBO = new JSONHeaderBO();

        if (session == null || (session.getAttribute(NGEConstants.SESSION_CASL_USERID) == null)) {
            //logger.info("Invalid Session : "+session);
            response.sendRedirect("jsp/logout.jsp");
            return jsonHeaderBO;
        }
		/*else{
			logger.info("session : "+session);
		}*/

        ObjectWriter ow = new ObjectMapper().writer()
                .withDefaultPrettyPrinter();
        try {
            json = ow.writeValueAsString(updateAccountMailingAddress);
        } catch (JsonProcessingException e) {
            // TODO Auto-generated catch block
            logger.info("NGEUIException", e);
        }
        //System.out.println("inrto the method");

        session.setAttribute(NGEConstants.TRANSACTION_ADDRESS,
                updateAccountMailingAddress);
        session.setAttribute(NGEConstants.UPDATE_ACC_MAIL_ADDRESS,
                XSSValidator.stripXSS(json));
        session.setAttribute(NGEConstants.SESSION_TRANSACTION_ADDRESS_DETAIL,
                XSSValidator.stripXSS(json));
        return new JSONHeaderBO();
    }

    /**
     * @throws UpdateTransactionAIGCIExceptionTypeMsg
     */
    @RequestMapping(value = "/updateProducerIndividualContactDetails", headers = "Accept=application/json", method = RequestMethod.POST)
    public @ResponseBody
    JSONHeaderBO updateAlternateContactDetails(HttpServletRequest request,
                                               @RequestBody BrokerBO brokerBO, HttpServletResponse response) throws IOException, UpdateTransactionAIGCIExceptionTypeMsg {
        HttpSession session = null;
        session = request.getSession(false);
        JSONHeaderBO jsonHeaderBO = new JSONHeaderBO();

        if (session == null || (session.getAttribute(NGEConstants.SESSION_CASL_USERID) == null)) {
            //logger.info("Invalid Session : "+session);
            response.sendRedirect("jsp/logout.jsp");
            return jsonHeaderBO;
        }
		/*else{
			logger.info("session : "+session);
		}*/
        String json = null;
        ObjectWriter ow = new ObjectMapper().writer()
                .withDefaultPrettyPrinter();
        try {
            json = ow.writeValueAsString(brokerBO);
        } catch (JsonProcessingException e) {
            // TODO Auto-generated catch block
            logger.info("NGEUIException", e);
        }

        session.setAttribute(NGEConstants.TRANSACTION_PRODUCER_CONTACT_DETAIL,
                brokerBO);
        session.setAttribute(NGEConstants.UPDATE_PROD_IND_CONTACT,
                XSSValidator.stripXSS(json));
        session.setAttribute(NGEConstants.SESSION_TRANSACTION_PRODUCER_CONTACT_DETAIL, XSSValidator.stripXSS(json));

        return new JSONHeaderBO();
    }

    @RequestMapping(value = "/resetDBUserPreference", headers = "Accept=application/json", method = RequestMethod.GET)
    public @ResponseBody
    void resetDBUserPreference(HttpServletRequest request, HttpServletResponse response) throws IOException {
        HttpSession session = null;
        session = request.getSession(false);
        if (session == null || (session.getAttribute(NGEConstants.SESSION_CASL_USERID) == null)) {
            //logger.info("Invalid Session : "+session);
            response.sendRedirect("jsp/logout.jsp");
            return;
        }
		/*else{
			logger.info("session : "+session);
		}*/
        //String headerjson = "";
        ObjectWriter ow = new ObjectMapper().writer()
                .withDefaultPrettyPrinter();
        ObjectReader objectReader = new ObjectMapper().reader(UserPrefBO.class);
        UserPrefBO dbUserprefBO = (UserPrefBO) session.getAttribute(NGEConstants.DB_SESSION_USER_PREF_DETAIL);
        //headerjson = ow.writeValueAsString(dbUserprefBO);
        UserPrefBO userprefBO = (UserPrefBO) objectReader.readValue(XSSValidator.stripXSS(ow.writeValueAsString(dbUserprefBO)));
        session.setAttribute(NGEConstants.SESSION_USER_PREF_DETAIL, userprefBO);
        session.setAttribute(NGEConstants.SESSION_USER_PREFERENCE_DETAIL, XSSValidator.stripXSS(ow.writeValueAsString(dbUserprefBO)));

    }

    /**
     * @throws CreateTransactionAIGCIExceptionTypeMsg
     */
    @RequestMapping(value = "/saveUserPreference", headers = "Accept=application/json", method = RequestMethod.POST)
    public @ResponseBody
    JSONHeaderBO saveUserPreference(HttpServletRequest request,
                                    @RequestBody UserPrefBO userprefBO, HttpServletResponse response) throws IOException, CreateTransactionAIGCIExceptionTypeMsg {
        HttpSession session = null;
        JSONHeaderBO jsonHeaderBO = new JSONHeaderBO();
        session = request.getSession(false);
        if (session == null || (session.getAttribute(NGEConstants.SESSION_CASL_USERID) == null)) {
            //logger.info("Invalid Session : "+session);
            response.sendRedirect("jsp/logout.jsp");
            return jsonHeaderBO;
        }
		/*else{
			logger.info("session : "+session);
		}*/
        SequenceNumberGeneration generateObj = new SequenceNumberGeneration();
        HashMap<String, String> sequenceNames = new HashMap<>();
        HashMap<String, Object> sequenceValueMap = new HashMap<String, Object>();
        sequenceNames.put("SAVE_USER_PREFERENCE", "INT");
        sequenceValueMap = generateObj.getNextSequenceNumber(sequenceNames);
        int sequenceNo = Integer.parseInt(sequenceValueMap.get(
                "SAVE_USER_PREFERENCE").toString());

        //String headerjson = "";
        ObjectWriter ow = new ObjectMapper().writer()
                .withDefaultPrettyPrinter();
        ObjectReader objectReader = new ObjectMapper().reader(UserPrefBO.class);
        String responseCode = NGEConstants.RESPONSE_FAILURE;
        try {
            UserPrefBO dbUserprefBO = (UserPrefBO) session.getAttribute(NGEConstants.DB_SESSION_USER_PREF_DETAIL);

            UserPrefHelper userPrefHelper = new UserPrefHelper();
            responseCode = userPrefHelper.validateAndSaveUserPref(dbUserprefBO, userprefBO);
            if (responseCode.equalsIgnoreCase(NGEConstants.USER_PREF_UPDATE_SUCCESS)) {
                dbUserprefBO = (UserPrefBO) objectReader.readValue(XSSValidator.stripXSS(ow.writeValueAsString(userprefBO)));
                session.setAttribute(NGEConstants.SESSION_USER_PREF_DETAIL, userprefBO);
                session.setAttribute(NGEConstants.SESSION_USER_PREFERENCE_DETAIL, XSSValidator.stripXSS(ow.writeValueAsString(userprefBO)));
                session.setAttribute(NGEConstants.DB_SESSION_USER_PREF_DETAIL, dbUserprefBO);
            }


        } catch (Exception e) {
            logger.info("NGEUIException", e);
            responseCode = NGEConstants.RESPONSE_FAILURE;
        }
        if (!responseCode.equalsIgnoreCase(NGEConstants.RESPONSE_FAILURE)) {
            jsonHeaderBO = setJsonHeader(sequenceNo, NGEConstants.SUCCESS_CODE,
                    NGEConstants.SUCCESS,
                    responseCode,
                    responseCode);
        } else {
            jsonHeaderBO = setJsonHeader(sequenceNo, NGEConstants.FAILURE_CODE,
                    NGEConstants.FAILURE,
                    seti18ErroMessage(NGEConstants.ERROR_INVOKING_SERVICE),
                    responseCode);
        }
        return jsonHeaderBO;
    }

    /**
     * @throws CreateTransactionAIGCIExceptionTypeMsg
     */
    @SuppressWarnings("unchecked")
    @RequestMapping(value = "/saveUserPrefSession", headers = "Accept=application/json", method = RequestMethod.POST)
    public @ResponseBody
    JSONHeaderBO saveUserPrefSession(HttpServletRequest request,
                                     @RequestBody UserPrefBO userPrefBO, HttpServletResponse response) throws IOException, CreateTransactionAIGCIExceptionTypeMsg {
        HttpSession session = null;
        JSONHeaderBO bo = new JSONHeaderBO();
        session = request.getSession(false);
        if (session == null || (session.getAttribute(NGEConstants.SESSION_CASL_USERID) == null)) {
            //logger.info("Invalid Session : "+session);
            response.sendRedirect("jsp/logout.jsp");
            return bo;
        }
		/*else{
			logger.info("session : "+session);
		}*/
        String headerjson = "";
        ObjectWriter ow = new ObjectMapper().writer()
                .withDefaultPrettyPrinter();

        UserPrefBO userprefBOforUI = null;
        userprefBOforUI = (UserPrefBO) session
                .getAttribute(NGEConstants.SESSION_USER_PREF_DETAIL);
        if (userprefBOforUI != null && userPrefBO.getProducerEntityData() != null) {
            userprefBOforUI.setProducerEntityData(userPrefBO.getProducerEntityData());
            userPrefBO = userprefBOforUI;
        }
        // Q2 May 2018 - Maintenance release - Preferred underwriter List Changes starts

        if (userprefBOforUI != null && userPrefBO.getPreferredUnderWriter() != null) {
            userprefBOforUI.setPreferredUnderWriter(userPrefBO.getPreferredUnderWriter());
            userPrefBO = userprefBOforUI;
        }
        // Q2 May 2018 - Maintenance release - Preferred underwriter List Changes ends
        try {
            headerjson = ow.writeValueAsString(userPrefBO);
        } catch (JsonProcessingException e) {
            logger.info("NGEUIException", e);
            return bo;
        }
        session.setAttribute(NGEConstants.SESSION_USER_PREF_DETAIL, userPrefBO);
        session.setAttribute(NGEConstants.SESSION_USER_PREFERENCE_DETAIL, XSSValidator.stripXSS(headerjson));

        return bo;
    }

    /**
     * @throws CreateTransactionAIGCIExceptionTypeMsg
     */
    @SuppressWarnings("unchecked")
    @RequestMapping(value = "/saveProductAssets", headers = "Accept=application/json", method = RequestMethod.POST)
    public @ResponseBody
    JSONHeaderBO createProductAssets(HttpServletRequest request,
                                     @RequestBody AssetBO assetBO, HttpServletResponse response) throws IOException, CreateTransactionAIGCIExceptionTypeMsg {
        HttpSession session = null;
        JSONHeaderBO bo = new JSONHeaderBO();
        session = request.getSession(false);
        if (session == null || (session.getAttribute(NGEConstants.SESSION_CASL_USERID) == null)) {
            //logger.info("Invalid Session : "+session);
            response.sendRedirect("jsp/logout.jsp");
            return bo;
        }
		/*else{
			logger.info("session : "+session);
		}*/
        String headerjson = "";
        ObjectWriter ow = new ObjectMapper().writer()
                .withDefaultPrettyPrinter();
        AssetSessionBO assetSessionBO = new AssetSessionBO();
        logger.info("inside save product assets");
//		assetSessionBO.setAssetBo(assetBO);

        //HashMap<String, List<AssetBO>> assetMap = new HashMap<String, List<AssetBO>>() ;
        Map<String, Map<String, AssetBO>> existingProdAssetMap = null;
        Map<String, AssetBO> assetMap = null;

        existingProdAssetMap = (HashMap<String, Map<String, AssetBO>>) session
                .getAttribute(NGEConstants.PRODUCT_ASSET_DETAIL);
        if (existingProdAssetMap != null && existingProdAssetMap.size() > 0) {

            assetMap = existingProdAssetMap.get(assetBO.getProductTabKey()
                    + "~" + assetBO.getComponentProductTabKey());

            if (assetMap != null && assetMap.size() > 0) {
                assetMap.put(assetBO.getAssetValue(), assetBO);
            } else {
                assetMap = new HashMap<String, AssetBO>();
                assetMap.put(assetBO.getAssetValue(), assetBO);
            }

            existingProdAssetMap.put(assetBO.getProductTabKey()
                    + "~" + assetBO.getComponentProductTabKey(), assetMap);
        } else {
            existingProdAssetMap = new HashMap<String, Map<String, AssetBO>>();
            assetMap = new HashMap<String, AssetBO>();

            assetMap.put(assetBO.getAssetValue(), assetBO);
            existingProdAssetMap.put(assetBO.getProductTabKey()
                    + "~" + assetBO.getComponentProductTabKey(), assetMap);
        }
        session.setAttribute(NGEConstants.PRODUCT_ASSET_DETAIL, existingProdAssetMap);

        List<AssetBO> assetList = new ArrayList<AssetBO>();
        if (existingProdAssetMap.size() > 0) {
            for (String key : existingProdAssetMap.keySet()) {
                List<AssetBO> asset = new ArrayList<AssetBO>(existingProdAssetMap.get(key).values());
                assetList.addAll(asset);
            }
        }

        assetSessionBO.setAssetBo(assetList);


        try {
            headerjson = ow.writeValueAsString(assetSessionBO);
        } catch (JsonProcessingException e) {
            // TODO Auto-generated catch block
            logger.info("NGEUIException", e);
        }
        session.setAttribute(NGEConstants.SESSION_TRANSACTION_ASSET_DETAIL, XSSValidator.stripXSS(headerjson));
        return bo;
    }

    /**
     * @throws CreateTransactionAIGCIExceptionTypeMsg
     */
    @SuppressWarnings("unchecked")
    @RequestMapping(value = "/saveExposureCountry", headers = "Accept=application/json", method = RequestMethod.POST)
    public @ResponseBody
    JSONHeaderBO saveExposureCountry(HttpServletRequest request,
                                     @RequestBody ExposureCountryBO exposureCountry, HttpServletResponse response) throws IOException, CreateTransactionAIGCIExceptionTypeMsg {
        HttpSession session = null;
        JSONHeaderBO bo = new JSONHeaderBO();
        session = request.getSession(false);
        if (session == null || (session.getAttribute(NGEConstants.SESSION_CASL_USERID) == null)) {
            //logger.info("Invalid Session : "+session);
            response.sendRedirect("jsp/logout.jsp");
            return bo;
        }
		/*else{
			logger.info("session : "+session);
		}*/
        String headerjson = "";
        ObjectWriter ow = new ObjectMapper().writer()
                .withDefaultPrettyPrinter();
        Map<String, ExposureCountryBO> exposureCountryMap = new HashMap<String, ExposureCountryBO>();
        logger.info("inside save saveExposureCountry");

        exposureCountryMap = (Map<String, ExposureCountryBO>) session
                .getAttribute(NGEConstants.EXPOSURE_COUNTRY_DETAIL);
        if (exposureCountryMap == null) {
            exposureCountryMap = new HashMap<String, ExposureCountryBO>();
        }
        exposureCountryMap.put(exposureCountry.getProductTabKey() + "~" + exposureCountry.getComponentTabKey(), exposureCountry);
        try {
            headerjson = ow.writeValueAsString(exposureCountryMap);
        } catch (JsonProcessingException e) {
            logger.info("NGEUIException", e);
        }
        session.setAttribute(NGEConstants.EXPOSURE_COUNTRY_DETAIL, exposureCountryMap);
        session.setAttribute(NGEConstants.EXPOSURE_COUNTRY_DATA, XSSValidator.stripXSS(headerjson));
        return bo;
    }

    /**
     * @throws CreateTransactionAIGCIExceptionTypeMsg
     */
    @SuppressWarnings("unchecked")
    @RequestMapping(value = "/editProductAssets", headers = "Accept=application/json", method = RequestMethod.POST)
    public @ResponseBody
    JSONHeaderBO editProductAssets(HttpServletRequest request,
                                   @RequestBody AssetBO assetBO, HttpServletResponse response) throws IOException, CreateTransactionAIGCIExceptionTypeMsg {
        logger.info("inside edit product assets");
        HttpSession session = null;
        JSONHeaderBO bo = new JSONHeaderBO();
        session = request.getSession(false);
        if (session == null || (session.getAttribute(NGEConstants.SESSION_CASL_USERID) == null)) {
            //logger.info("Invalid Session : "+session);
            response.sendRedirect("jsp/logout.jsp");
            return bo;
        }
		/*else{
			logger.info("session : "+session);
		}*/
        String headerjson = "";
        ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
        AssetSessionBO assetSessionBO = new AssetSessionBO();
        AssetBO toBeDeletedAsset = new AssetBO();
        List<AssetBO> assetList = new ArrayList<AssetBO>();
//		assetSessionBO.setAssetBo(assetBO);

/*		HashMap<String, List<AssetBO>> assetMap = new HashMap<String, List<AssetBO>>() ;

		HashMap<String, List<AssetBO>> existingAssetMap =null;
		List<AssetBO> existingAssetList = new ArrayList<AssetBO>();*/
        if (session.getAttribute(NGEConstants.PRODUCT_ASSET_DETAIL) != null) {
            assetList = (List<AssetBO>) session.getAttribute(NGEConstants.PRODUCT_ASSET_DETAIL);
            for (AssetBO assetBOSession : assetList) {
                if (assetBOSession.getProductTabKey().equalsIgnoreCase(assetBO.getProductTabKey()) && assetBOSession.getComponentProductTabKey().equalsIgnoreCase(assetBO.getComponentProductTabKey()) && assetBOSession.getAssetType().equalsIgnoreCase(assetBO.getAssetType())) {
                    toBeDeletedAsset = assetBOSession;
                }
            }
            assetList.remove(toBeDeletedAsset);
            assetList.add(assetBO);
        }
        session.setAttribute(NGEConstants.PRODUCT_ASSET_DETAIL, assetList);
        assetSessionBO.setAssetBo(assetList);
        try {
            headerjson = ow.writeValueAsString(assetSessionBO);
        } catch (JsonProcessingException e) {
            logger.info("NGEUIException", e);
        }
        session.setAttribute(NGEConstants.SESSION_TRANSACTION_ASSET_DETAIL, XSSValidator.stripXSS(headerjson));
        return bo;
    }

    /**
     * @throws CreateTransactionAIGCIExceptionTypeMsg
     */
    @SuppressWarnings("unchecked")
    @RequestMapping(value = "/deleteProductAssets", headers = "Accept=application/json", method = RequestMethod.POST)
    public @ResponseBody
    JSONHeaderBO deleteProductAssets(HttpServletRequest request,
                                     @RequestBody AssetBO assetBO, HttpServletResponse response) throws IOException, CreateTransactionAIGCIExceptionTypeMsg {

        HttpSession session = null;
        JSONHeaderBO bo = new JSONHeaderBO();
        session = request.getSession(false);
        if (session == null || (session.getAttribute(NGEConstants.SESSION_CASL_USERID) == null)) {
            //logger.info("Invalid Session : "+session);
            response.sendRedirect("jsp/logout.jsp");
            return bo;
        }
		/*else{
			logger.info("session : "+session);
		}*/
        String headerjson = "";
        ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
        AssetSessionBO assetSessionBO = new AssetSessionBO();
//		assetSessionBO.setAssetBo(assetBO);
        //HashMap<String, List<AssetBO>> assetMap = new HashMap<String, List<AssetBO>>() ;
        Map<String, Map<String, AssetBO>> existingProdAssetMap = null;
        Map<String, AssetBO> assetMap = null;

        existingProdAssetMap = (HashMap<String, Map<String, AssetBO>>) session
                .getAttribute(NGEConstants.PRODUCT_ASSET_DETAIL);
        if (existingProdAssetMap != null && existingProdAssetMap.size() > 0) {

            assetMap = existingProdAssetMap.get(assetBO.getProductTabKey()
                    + "~" + assetBO.getComponentProductTabKey());

            if (assetMap != null && assetMap.size() > 0) {
                assetMap.remove(assetBO.getAssetValue());
            }

            existingProdAssetMap.put(assetBO.getProductTabKey()
                    + "~" + assetBO.getComponentProductTabKey(), assetMap);
        }
        session.setAttribute(NGEConstants.PRODUCT_ASSET_DETAIL, existingProdAssetMap);

        List<AssetBO> assetList = new ArrayList<AssetBO>();
        if (existingProdAssetMap != null && existingProdAssetMap.size() > 0) {
            for (String key : existingProdAssetMap.keySet()) {
                List<AssetBO> asset = new ArrayList<AssetBO>(existingProdAssetMap.get(key).values());
                assetList.addAll(asset);
            }
        }

        assetSessionBO.setAssetBo(assetList);
        try {
            headerjson = ow.writeValueAsString(assetSessionBO);
        } catch (JsonProcessingException e) {
            logger.info("NGEUIException", e);
        }
        session.setAttribute(NGEConstants.SESSION_TRANSACTION_ASSET_DETAIL, XSSValidator.stripXSS(headerjson));
        return bo;
    }

    /**
     * @throws CreateTransactionAIGCIExceptionTypeMsg
     */
    @RequestMapping(value = "/saveProductPolicies", headers = "Accept=application/json", method = RequestMethod.POST)
    public @ResponseBody
    JSONHeaderBO createProductPolicies(HttpServletRequest request,
                                       @RequestBody PolicyDetailBO policyDetailBO, HttpServletResponse response) throws IOException, CreateTransactionAIGCIExceptionTypeMsg {
        HttpSession session = null;
        JSONHeaderBO bo = new JSONHeaderBO();
        session = request.getSession(false);
        if (session == null || (session.getAttribute(NGEConstants.SESSION_CASL_USERID) == null)) {
            //logger.info("Invalid Session : "+session);
            response.sendRedirect("jsp/logout.jsp");
            return bo;
        }
		/*else{
			logger.info("session : "+session);
		}*/
        String headerjson = "";
        ObjectWriter ow = new ObjectMapper().writer()
                .withDefaultPrettyPrinter();
        PolicySessionBO policySessionBO = new PolicySessionBO();
        List<PolicyDetailBO> policyList = new ArrayList<PolicyDetailBO>();
        policyDetailBO.setPremium(NGECommonUtil.stripTrailingZeros(new BigDecimal(NGECommonUtil.trimCommas(policyDetailBO.getPremium()))));
        policyDetailBO.setPremiumWithCurrency(policyDetailBO.getPremium() + " " + policyDetailBO.getCurrency());
        if (session.getAttribute(NGEConstants.PRODUCT_POLICY_DETAIL) != null) {
            policyList = (List<PolicyDetailBO>) session.getAttribute(NGEConstants.PRODUCT_POLICY_DETAIL);
            policyList.add(policyDetailBO);
        } else {
            policyList.add(policyDetailBO);
        }
        session.setAttribute(NGEConstants.PRODUCT_POLICY_DETAIL, policyList);
        policySessionBO.setPolicyDetailBO(policyList);
        try {
            headerjson = ow.writeValueAsString(policySessionBO);
        } catch (JsonProcessingException e) {
            logger.info("NGEUIException", e);
        }
        session.setAttribute(NGEConstants.SESSION_POLICY_DETAIL, XSSValidator.stripXSS(headerjson));
        return bo;
    }

    @SuppressWarnings("unchecked")
    @RequestMapping(value = "/editProductPolicies", headers = "Accept=application/json", method = RequestMethod.POST)
    public @ResponseBody
    JSONHeaderBO editProductPolicies(HttpServletRequest request,
                                     @RequestBody PolicyDetailBO policyDetailBO, HttpServletResponse response) throws IOException {
        HttpSession session = null;
        JSONHeaderBO bo = new JSONHeaderBO();
        session = request.getSession(false);
        if (session == null || (session.getAttribute(NGEConstants.SESSION_CASL_USERID) == null)) {
            //logger.info("Invalid Session : "+session);
            response.sendRedirect("jsp/logout.jsp");
            return bo;
        }
		/*else{
			logger.info("session : "+session);
		}*/
        String headerjson = "";
        String sessionPremium = null;
        String sessionCurrency = null;
        String sessionPremiumWithCurrency = null;
        String[] buffer = new String[2];
        ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
        PolicySessionBO policySessionBO = new PolicySessionBO();
        PolicyDetailBO toBeDeletedPolicy = new PolicyDetailBO();
        List<PolicyDetailBO> policyList = new ArrayList<PolicyDetailBO>();
        if (session.getAttribute("PRODUCT_POLICY_DETAIL") != null) {
            policyDetailBO.setPremium(NGECommonUtil.stripTrailingZeros(new BigDecimal(NGECommonUtil.trimCommas(policyDetailBO.getPremium()))));
            policyList = (List<PolicyDetailBO>) session.getAttribute(NGEConstants.PRODUCT_POLICY_DETAIL);
            for (PolicyDetailBO policyDetail : policyList) {
                if ((policyDetail.getProductTabKey().equals(policyDetailBO.getProductTabKey())) && (policyDetail.getComponentProductTabKey().equals(policyDetailBO.getComponentProductTabKey()))
                        && (policyDetail.getPolicySequenceId().equals(policyDetailBO.getPolicySequenceId()))) {
                    toBeDeletedPolicy = policyDetail;
                }
            }
            buffer = toBeDeletedPolicy.getPremiumWithCurrency().split(" ");
            sessionPremiumWithCurrency = toBeDeletedPolicy.getPremiumWithCurrency();
            policyList.remove(toBeDeletedPolicy);
            sessionPremium = buffer[0];
            sessionCurrency = buffer[1];
            if (!(policyDetailBO.getPremium().equals(sessionPremium))) {
                policyDetailBO.setPremiumWithCurrency(policyDetailBO.getPremium() + " " + policyDetailBO.getCurrency());
            } else if (!(policyDetailBO.getCurrency().equals(sessionCurrency))) {
                policyDetailBO.setPremiumWithCurrency(policyDetailBO.getPremium() + " " + policyDetailBO.getCurrency());
            } else {
                policyDetailBO.setPremiumWithCurrency(sessionPremiumWithCurrency);
            }
            policyList.add(policyDetailBO);
        }
        session.setAttribute(NGEConstants.PRODUCT_POLICY_DETAIL, policyList);
        policySessionBO.setPolicyDetailBO(policyList);
        try {
            headerjson = ow.writeValueAsString(policySessionBO);
        } catch (JsonProcessingException e) {
            // TODO Auto-generated catch block
            logger.info("NGEUIException", e);
        }
        session.setAttribute(NGEConstants.SESSION_POLICY_DETAIL, XSSValidator.stripXSS(headerjson));
        return bo;
    }


    @SuppressWarnings("unchecked")
    @RequestMapping(value = "/deleteProductPolicies", headers = "Accept=application/json", method = RequestMethod.POST)
    public @ResponseBody
    JSONHeaderBO deleteProductPolicies(HttpServletRequest request,
                                       @RequestBody PolicyDetailBO policyDetailBO, HttpServletResponse response) throws IOException {
        HttpSession session = null;
        JSONHeaderBO bo = new JSONHeaderBO();
        session = request.getSession(false);
        if (session == null || (session.getAttribute(NGEConstants.SESSION_CASL_USERID) == null)) {
            //logger.info("Invalid Session : "+session);
            response.sendRedirect("jsp/logout.jsp");
            return bo;
        }
		/*else{
			logger.info("session : "+session);
		}*/
        String headerjson = "";
        ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
        PolicySessionBO policySessionBO = new PolicySessionBO();
        List<PolicyDetailBO> policyList = new ArrayList<PolicyDetailBO>();
        if (session.getAttribute("PRODUCT_POLICY_DETAIL") != null) {
            policyList = (List<PolicyDetailBO>) session.getAttribute(NGEConstants.PRODUCT_POLICY_DETAIL);
            if (policyList != null && policyList.size() > 0) {

                for (Iterator<PolicyDetailBO> policyDetailIter = policyList.iterator(); policyDetailIter.hasNext(); ) {
                    PolicyDetailBO policyDetail = policyDetailIter.next();
                    //for(PolicyDetailBO policyDetail : policyList ){
                    if ((policyDetail.getProductTabKey().equals(policyDetailBO.getProductTabKey())) && (policyDetail.getComponentProductTabKey().equals(policyDetailBO.getComponentProductTabKey()))
                    ) {

                        if (policyDetailBO.getPolicySequenceId() == null || policyDetailBO.getPolicySequenceId().length() == 0 || (policyDetail.getPolicySequenceId().equals(policyDetailBO.getPolicySequenceId()))) {
                            policyDetailIter.remove();
                            //policyList.remove(toBeDeletedPolicy);
                        }
                    }
                }

            }
        }
        session.setAttribute(NGEConstants.PRODUCT_POLICY_DETAIL, policyList);
        policySessionBO.setPolicyDetailBO(policyList);

        try {
            headerjson = ow.writeValueAsString(policySessionBO);
        } catch (JsonProcessingException e) {
            logger.info("NGEUIException", e);
        }
        session.setAttribute(NGEConstants.SESSION_POLICY_DETAIL, XSSValidator.stripXSS(headerjson));
        return bo;
    }


    @RequestMapping(value = "/clearcreateTransactionsession", method = RequestMethod.POST)
    public @ResponseBody
    void clearTransactionSession(HttpServletRequest request, HttpServletResponse response) throws IOException {
        logger.info("inside clearcreateTransactionsession");
        HttpSession session = null;
        session = request.getSession(false);
        if (session == null || (session.getAttribute(NGEConstants.SESSION_CASL_USERID) == null)) {
            //logger.info("Invalid Session : "+session);
            response.sendRedirect("jsp/logout.jsp");
            return;
        }
		/*else{
			logger.info("session : "+session);
		}*/
        if (null != session.getAttribute(NGEConstants.CREATE_SUBMISSION_RESPONSE)) {
            session.removeAttribute(NGEConstants.CREATE_SUBMISSION_RESPONSE);
        }
        if (null != session.getAttribute(NGEConstants.SUBMISSION_NO)) {
            session.removeAttribute(NGEConstants.SUBMISSION_NO);
        }
        if (null != session.getAttribute(NGEConstants.TRANSACTION_ADDRESS)) {
            session.removeAttribute(NGEConstants.TRANSACTION_ADDRESS);
        }
        if (null != session.getAttribute(NGEConstants.SESSION_TRANSACTION_ADDRESS_DETAIL)) {
            session.removeAttribute(NGEConstants.SESSION_TRANSACTION_ADDRESS_DETAIL);
        }
        if (null != session.getAttribute(NGEConstants.TRANSACTION_ADDITIONAL_ACC_INSURED_LIST)) {
            session.removeAttribute(NGEConstants.TRANSACTION_ADDITIONAL_ACC_INSURED_LIST);
        }
        if (null != session.getAttribute(NGEConstants.TRANSACTION_ADDITIONAL_ACC_PRODUCER_LIST)) {
            session.removeAttribute(NGEConstants.TRANSACTION_ADDITIONAL_ACC_PRODUCER_LIST);
        }
        if (null != session.getAttribute(NGEConstants.SESSION_TRANSACTION_ADDITIONAL_PRODUCER_DETAIL)) {
            session.removeAttribute(NGEConstants.SESSION_TRANSACTION_ADDITIONAL_PRODUCER_DETAIL);
        }
        if (null != session.getAttribute(NGEConstants.TRANSACTION_PRODUCER_CONTACT_DETAIL)) {
            session.removeAttribute(NGEConstants.TRANSACTION_PRODUCER_CONTACT_DETAIL);
        }
        if (null != session.getAttribute(NGEConstants.PRODUCT_POLICY_DETAIL)) {
            session.removeAttribute(NGEConstants.PRODUCT_POLICY_DETAIL);
        }
        if (null != session.getAttribute(NGEConstants.TRANSACTION_ADDITIONAL_PRODUCT_INSURED_LIST)) {
            session.removeAttribute(NGEConstants.TRANSACTION_ADDITIONAL_PRODUCT_INSURED_LIST);
        }
        if (null != session.getAttribute(NGEConstants.PRODUCT_ASSET_DETAIL)) {
            session.removeAttribute(NGEConstants.PRODUCT_ASSET_DETAIL);
        }
        if (null != session.getAttribute(NGEConstants.PRODUCT_ATTR_INFO_DETAIL)) {
            session.removeAttribute(NGEConstants.PRODUCT_ATTR_INFO_DETAIL);
        }
        if (null != session.getAttribute(NGEConstants.TRANSACTION_ATTR_INFO_DETAIL)) {
            session.removeAttribute(NGEConstants.TRANSACTION_ATTR_INFO_DETAIL);
        }
        if (null != session.getAttribute(NGEConstants.PRODUCT_ATTR_INFO_DETAIL)) {
            session.removeAttribute(NGEConstants.PRODUCT_ATTR_INFO_DETAIL);
        }
        if (null != session.getAttribute(NGEConstants.SESSION_TRANSACTION_ADDITIONAL_INSURED_DETAIL)) {
            session.removeAttribute(NGEConstants.SESSION_TRANSACTION_ADDITIONAL_INSURED_DETAIL);
        }
        if (null != session.getAttribute(NGEConstants.TRANSACTION_ADDITIONAL_ACC_INSURED_LIST)) {
            session.removeAttribute(NGEConstants.TRANSACTION_ADDITIONAL_ACC_INSURED_LIST);
        }
        if (null != session.getAttribute(NGEConstants.SESSION_ADDITIONAL_INSURED_PRODUCT_LEVEL_DETAIL)) {
            session.removeAttribute(NGEConstants.SESSION_ADDITIONAL_INSURED_PRODUCT_LEVEL_DETAIL);
        }
        if (null != session.getAttribute(NGEConstants.ADDITIONAL_INSURED_LIST_PRODUCT_LEVEL)) {
            session.removeAttribute(NGEConstants.ADDITIONAL_INSURED_LIST_PRODUCT_LEVEL);
        }

    }

    @RequestMapping(value = "/clearUpdateTransactionsession", method = RequestMethod.POST)
    public @ResponseBody
    void clearUpdateTransactionSession(HttpServletRequest request, HttpServletResponse response) throws IOException {
        HttpSession session = null;
        session = request.getSession(false);

        if (session == null || (session.getAttribute(NGEConstants.SESSION_CASL_USERID) == null)) {
            //logger.info("Invalid Session : "+session);
            response.sendRedirect("jsp/logout.jsp");
            return;
        }
		/*else{
			logger.info("session : "+session);
		}*/
        if (null != session.getAttribute("AdditionalInsured")) {
            session.removeAttribute("AdditionalInsured");
        }
        if (null != session.getAttribute("AdditionalProducer")) {
            session.removeAttribute("AdditionalProducer");
        }
        if (null != session.getAttribute(NGEConstants.UPDATE_ACC_MAIL_ADDRESS)) {
            session.removeAttribute(NGEConstants.UPDATE_ACC_MAIL_ADDRESS);
        }
        if (null != session.getAttribute(NGEConstants.UPDATE_PROD_IND_CONTACT)) {
            session.removeAttribute(NGEConstants.UPDATE_PROD_IND_CONTACT);
        }
        if (null != session.getAttribute("Assets")) {
            session.removeAttribute("Assets");
        }
        if (null != session.getAttribute(NGEConstants.PRODUCT_ASSET_DETAIL)) {
            session.removeAttribute(NGEConstants.PRODUCT_ASSET_DETAIL);
        }
        if (null != session.getAttribute("Policies")) {
            session.removeAttribute("Policies");
        }
        if (null != session.getAttribute(NGEConstants.DELETE_ASSET_LIST)) {
            session.removeAttribute(NGEConstants.DELETE_ASSET_LIST);
        }
        if (null != session.getAttribute(NGEConstants.DELETE_POLICY_LIST)) {
            session.removeAttribute(NGEConstants.DELETE_POLICY_LIST);
        }
        if (null != session.getAttribute(NGEConstants.SESSION_UPDATE_PRODUCT_STATUS)) {
            session.removeAttribute(NGEConstants.SESSION_UPDATE_PRODUCT_STATUS);
        }
        if (null != session.getAttribute(NGEConstants.SESSION_REOPEN_PRODUCT)) {
            session.removeAttribute(NGEConstants.SESSION_REOPEN_PRODUCT);
        }
        if (null != session.getAttribute(NGEConstants.SESSION_UNBIND_PRODUCT_STATUS)) {
            session.removeAttribute(NGEConstants.SESSION_UNBIND_PRODUCT_STATUS);
        }
    }

    @RequestMapping(value = "/clearBlockSearchInputSession", headers = "Accept=application/json", method = RequestMethod.GET)
    public @ResponseBody
    void clearBlockSearchInputSession(HttpServletRequest request, HttpServletResponse response) throws IOException {
        HttpSession session = null;
        session = request.getSession(false);
        if (session == null || (session.getAttribute(NGEConstants.SESSION_CASL_USERID) == null)) {
            response.sendRedirect("jsp/logout.jsp");
            return;
        }
        if (null != session.getAttribute(NGEConstants.SESSION_BLOCK_DETAILS_INPUT)) {
            session.removeAttribute(NGEConstants.SESSION_BLOCK_DETAILS_INPUT);
        }
    }

    @RequestMapping(value = "/clearLifeCycleStatusUpdateSession", headers = "Accept=application/json", method = RequestMethod.GET)
    public @ResponseBody
    void clearLifeCycleStatusUpdateSession(HttpServletRequest request, HttpServletResponse response) throws IOException {
        HttpSession session = null;
        session = request.getSession(false);
        if (session == null || (session.getAttribute(NGEConstants.SESSION_CASL_USERID) == null)) {
            //logger.info("Invalid Session : "+session);
            response.sendRedirect("jsp/logout.jsp");
            return;
        }
		/*else{
			logger.info("session : "+session);
		}*/

        if (null != session.getAttribute(NGEConstants.SESSION_UPDATE_PRODUCT_STATUS)) {
            session.removeAttribute(NGEConstants.SESSION_UPDATE_PRODUCT_STATUS);
        }
        if (null != session.getAttribute(NGEConstants.SESSION_REOPEN_PRODUCT)) {
            session.removeAttribute(NGEConstants.SESSION_REOPEN_PRODUCT);
        }
        if (null != session.getAttribute(NGEConstants.SESSION_UNBIND_PRODUCT_STATUS)) {
            session.removeAttribute(NGEConstants.SESSION_UNBIND_PRODUCT_STATUS);
        }
        if (null != session.getAttribute(NGEConstants.PRODUCT_POLICY_DETAIL)) {
            session.removeAttribute(NGEConstants.PRODUCT_POLICY_DETAIL);
        }
        if (null != session.getAttribute(NGEConstants.SESSION_POLICY_DETAIL)) {
            session.removeAttribute(NGEConstants.SESSION_POLICY_DETAIL);
        }
        if (null != session.getAttribute(NGEConstants.SESSION_TRANSACTION_ADDRESS_DETAIL)) {
            session.removeAttribute(NGEConstants.SESSION_TRANSACTION_ADDRESS_DETAIL);
        }
        if (null != session.getAttribute(NGEConstants.SESSION_TRANSACTION_ADDITIONAL_PRODUCER_DETAIL)) {
            session.removeAttribute(NGEConstants.SESSION_TRANSACTION_ADDITIONAL_PRODUCER_DETAIL);
        }
        if (null != session.getAttribute(NGEConstants.TRANSACTION_ADDITIONAL_ACC_PRODUCER_LIST)) {
            session.removeAttribute(NGEConstants.TRANSACTION_ADDITIONAL_ACC_PRODUCER_LIST);
        }
        if (null != session.getAttribute(NGEConstants.SESSION_TRANSACTION_PRODUCER_CONTACT_DETAIL)) {
            session.removeAttribute(NGEConstants.SESSION_TRANSACTION_PRODUCER_CONTACT_DETAIL);
        }
        if (null != session.getAttribute(NGEConstants.SESSION_TRANSACTION_ASSET_DETAIL)) {
            session.removeAttribute(NGEConstants.SESSION_TRANSACTION_ASSET_DETAIL);
        }
        if (null != session.getAttribute(NGEConstants.EXPOSURE_COUNTRY_DATA)) {
            session.removeAttribute(NGEConstants.EXPOSURE_COUNTRY_DATA);
        }
        if (null != session.getAttribute(NGEConstants.EXPOSURE_COUNTRY_DETAIL)) {
            session.removeAttribute(NGEConstants.EXPOSURE_COUNTRY_DETAIL);
        }
        if (null != session.getAttribute(NGEConstants.PRODUCT_ASSET_DETAIL)) {
            session.removeAttribute(NGEConstants.PRODUCT_ASSET_DETAIL);
        }
        if (null != session.getAttribute(NGEConstants.SESSION_ASSOCIATE_PRODUCT_LIST_DATA)) {
            session.removeAttribute(NGEConstants.SESSION_ASSOCIATE_PRODUCT_LIST_DATA);
        }
        if (null != session.getAttribute(NGEConstants.SESSION_ASSOCIATE_PRODUCT_LIST)) {
            session.removeAttribute(NGEConstants.SESSION_ASSOCIATE_PRODUCT_LIST);
        }
        if (null != session.getAttribute(NGEConstants.SESSION_TRANSACTION_ADDITIONAL_INSURED_DETAIL)) {
            session.removeAttribute(NGEConstants.SESSION_TRANSACTION_ADDITIONAL_INSURED_DETAIL);
        }
        if (null != session.getAttribute(NGEConstants.TRANSACTION_ADDITIONAL_ACC_INSURED_LIST)) {
            session.removeAttribute(NGEConstants.TRANSACTION_ADDITIONAL_ACC_INSURED_LIST);
        }

        if (null != session.getAttribute(NGEConstants.SESSION_ADDITIONAL_INSURED_PRODUCT_LEVEL_DETAIL)) {
            session.removeAttribute(NGEConstants.SESSION_ADDITIONAL_INSURED_PRODUCT_LEVEL_DETAIL);
        }
        if (null != session.getAttribute(NGEConstants.ADDITIONAL_INSURED_LIST_PRODUCT_LEVEL)) {
            session.removeAttribute(NGEConstants.ADDITIONAL_INSURED_LIST_PRODUCT_LEVEL);
        }


        if (null != session.getAttribute(NGEConstants.TRANSACTION_ADDRESS)) {
            session.removeAttribute(NGEConstants.TRANSACTION_ADDRESS);
        }

        if (null != session.getAttribute(NGEConstants.SESSION_TRANSACTION_ADDRESS_DETAIL)) {
            session.removeAttribute(NGEConstants.SESSION_TRANSACTION_ADDRESS_DETAIL);
        }
        if (null != session.getAttribute(NGEConstants.UPDATE_ACC_MAIL_ADDRESS)) {
            session.removeAttribute(NGEConstants.UPDATE_ACC_MAIL_ADDRESS);
        }
    }


    @RequestMapping(value = "/logout", headers = "Accept=application/json", method = RequestMethod.POST)
    public String logout(HttpServletRequest request) {
        HttpSession session = null;
        session = request.getSession(false);
        if (null != session) {
            session.setMaxInactiveInterval(0);
            session.invalidate();
        }
        return "login";
    }

    @SuppressWarnings({"null", "unchecked"})
    @RequestMapping(value = "/updateTransaction", headers = "Accept=application/json", method = RequestMethod.POST)
    public @ResponseBody
    JSONHeaderBO updateTransaction(HttpServletRequest request,
                                   @RequestBody UpdateTransactionRequestBO updateTransactionRequest, HttpServletResponse response) throws IOException {

        HttpSession session = null;
        session = request.getSession(false);
        JSONHeaderBO jsonHeaderBO = new JSONHeaderBO();
        if (session == null || (session.getAttribute(NGEConstants.SESSION_CASL_USERID) == null)) {
            //logger.info("Invalid Session : "+session);
            response.sendRedirect("jsp/logout.jsp");
            return jsonHeaderBO;
        }
		/*else{
			logger.info("session : "+session);
		}*/
        TransactionManagementService serviceObj = new TransactionManagementService();
        serviceObj.setCaslServiceId((String) session.getAttribute(NGEConstants.SESSION_CASL_USERID));
        ExceptionBO exceptionBO = null;
        GetsubmissionrespBO dbSetTransactionDetails = null;
        ObjectWriter ow = new ObjectMapper().writer()
                .withDefaultPrettyPrinter();

        boolean sessionFlag = true;
        StringBuffer message = null;
        UpdateTransactionRespBO updateTransactionResp = null;
        Map<String, String> prodNameMapMktPdct = new HashMap<String, String>();
        Map<String, String> prodNameMapCmptPdct = new HashMap<String, String>();
        Map<String, String> prodNameMapSubPdct = new HashMap<String, String>();
        List<MessageDetailsBO> serviceMessages = new ArrayList<MessageDetailsBO>();
        int sequenceNo = 0;
        try {
            //logger.info("session : "+session);
            logger.info("session object : " + session.getAttribute(NGEConstants.DB_SET_OBJECT));
            if (null != session.getAttribute(NGEConstants.DB_SET_OBJECT)) {
                dbSetTransactionDetails = (GetsubmissionrespBO) session.getAttribute(NGEConstants.DB_SET_OBJECT);
            }/*else{
				SubmissionDataService subServiceObj = new SubmissionDataService();
				subServiceObj.setCaslServiceId((String)session.getAttribute(NGEConstants.SESSION_CASL_USERID));
				SubmissionRs reponsesubmissionDet = subServiceObj.getSubmission(updateTransactionRequest.getSubmissionNo(),null,null,null);
				dbSetTransactionDetails = subServiceObj.setSubmissionResponseInBO(reponsesubmissionDet);
			}*/
            logger.info(XSSValidator.stripXSS(ow.writeValueAsString(dbSetTransactionDetails)));
        } /*catch (MalformedURLException e) {
			exceptionBO = new ExceptionBO();
			exceptionBO.setErrorFrom(NGEConstants.GET_SUBMISSION_SERVICE);
			logger.info("NGEUIException",e);
			exceptionBO
					.setErrorMessage(seti18ErroMessage(NGEConstants.MALFORMED_URL));
			exceptionBO.setErrorCode(NGEConstants.FAILURE_CODE);
			exceptionBO.setErrorType(NGEConstants.FATAL);
		} catch (GetSubmissionAIGCIExceptionTypeMsg e) {
			exceptionBO = new ExceptionBO();
			exceptionBO.setErrorFrom(NGEConstants.GET_SUBMISSION_SERVICE);
			exceptionBO.setErrorMessage(seti18ErroMessage(e.getFaultInfo()
					.getErrorCode()));
			exceptionBO.setErrorCode(NGEConstants.FAILURE_CODE);
			exceptionBO.setErrorType(e.getFaultInfo().getErrorType());
			logger.info("NGEUIException",e);
		}*/ catch (IllegalStateException ise) {
            logger.info(ise);
            sessionFlag = false;
            exceptionBO = new ExceptionBO();
            exceptionBO.setErrorFrom("UpdateTransactionService");
            exceptionBO.setErrorMessage(NGEConstants.SESSION_EXPIRED);
        } catch (Exception e) {
            exceptionBO = new ExceptionBO();
            exceptionBO.setErrorFrom(NGEConstants.GET_SUBMISSION_SERVICE);
            exceptionBO
                    .setErrorMessage(seti18ErroMessage(NGEConstants.ERROR_INVOKING_SERVICE));
            exceptionBO.setErrorCode(NGEConstants.FAILURE_CODE);
            exceptionBO.setErrorType(NGEConstants.FATAL);
            logger.info("NGEUIException", e);
        }
        if (sessionFlag) {
            logger.info("The Data Base Object from session is : " + dbSetTransactionDetails);
            if (dbSetTransactionDetails != null) {
                logger.info("The Data Base Object from session is : " + dbSetTransactionDetails.getTransactiondet());
            }
            SubmissionManagementService reserveSerObj = new SubmissionManagementService();
            reserveSerObj.setCaslServiceId((String) session.getAttribute(NGEConstants.SESSION_CASL_USERID));
            List<ReserveProductsRsBO> reserveProductsResponse = null;


            Map<String, Map<String, AssetBO>> assetProductMap = null;
            Map<String, AssetBO> assetMap = null;
            List<AssetBO> assetList = null;
            List<PolicyDetailBO> policyDetailList = null;

            if (null != updateTransactionRequest) {
                if (null != session.getAttribute(NGEConstants.TRANSACTION_ADDRESS)) {
                    updateTransactionRequest.getUpdateTransactionDetails().setMailingAddress((AddressDetailsBO) session.getAttribute(NGEConstants.TRANSACTION_ADDRESS));
                }
                if (null != session.getAttribute(NGEConstants.TRANSACTION_PRODUCER_CONTACT_DETAIL)) {
                    updateTransactionRequest.getUpdateTransactionDetails().setBroker((BrokerBO) session.getAttribute(NGEConstants.TRANSACTION_PRODUCER_CONTACT_DETAIL));
                }
                if (null != session.getAttribute(NGEConstants.SESSION_UPDATE_PRODUCT_STATUS)) {
                    updateTransactionRequest.setSetProductStatusReq((SetProductStatusReqBO) session.getAttribute(NGEConstants.SESSION_UPDATE_PRODUCT_STATUS));
                }
                if (null != session.getAttribute(NGEConstants.SESSION_REOPEN_PRODUCT)) {
                    updateTransactionRequest.setReopenProductsReq((ReopenProductsReqBO) session.getAttribute(NGEConstants.SESSION_REOPEN_PRODUCT));
                }
                if (null != session.getAttribute(NGEConstants.SESSION_UNBIND_PRODUCT_STATUS)) {
                    updateTransactionRequest.setUnBindProductsRq((UnBindProductReqBO) session.getAttribute(NGEConstants.SESSION_UNBIND_PRODUCT_STATUS));
                }
                List<TransactionVersionBO> transactionVersionList = updateTransactionRequest.getUpdateTransactionDetails().getTransactionVersionRq();

                for (TransactionVersionBO transactionVersion : transactionVersionList) {
                    if (null != session.getAttribute(NGEConstants.TRANSACTION_ADDITIONAL_ACC_PRODUCER_LIST)) {
                        transactionVersion.setAdditionalProducerDet((List<AdditionalProducerBO>) session.getAttribute(NGEConstants.TRANSACTION_ADDITIONAL_ACC_PRODUCER_LIST));
                    }
                    //Added for Additional Insured Update scenario starts
                    if (null != session.getAttribute(NGEConstants.TRANSACTION_ADDITIONAL_ACC_INSURED_LIST)) {
                        transactionVersion.setAdditionalInsuredDet((List<AdditionalInsuredBO>) session.getAttribute(NGEConstants.TRANSACTION_ADDITIONAL_ACC_INSURED_LIST));
                    }

                    //Added for Additional Insured Update scenario ends
                    List<ComponentProductBO> updateComponentProductList = transactionVersion.getProductDet().getComponentProduct();
                    policyDetailList = (List<PolicyDetailBO>) session.getAttribute(NGEConstants.PRODUCT_POLICY_DETAIL);
                    for (ComponentProductBO updateComponentProductBO : updateComponentProductList) {
                        if (null != session.getAttribute(NGEConstants.ADDITIONAL_INSURED_LIST_PRODUCT_LEVEL)) {
                            List<AdditionalInsuredBO> additionalInsuredListProductLevel = (List<AdditionalInsuredBO>) session.getAttribute(NGEConstants.ADDITIONAL_INSURED_LIST_PRODUCT_LEVEL);
                            List<AdditionalInsuredBO> additionalInsuredListOfProduct = new ArrayList<AdditionalInsuredBO>();
                            String processingInd = null;
                            for (AdditionalInsuredBO sessionAdditionalInsured : additionalInsuredListProductLevel) {
                                if (sessionAdditionalInsured.getProductTabKey().equalsIgnoreCase(updateComponentProductBO.getProductTabkey()) && sessionAdditionalInsured.getComponentProductTabKey().equalsIgnoreCase(updateComponentProductBO.getComponentProductTabKey()) && sessionAdditionalInsured.getAccountNo() != null) {
                                    additionalInsuredListOfProduct.add(sessionAdditionalInsured);
                                    processingInd = sessionAdditionalInsured.getProcessingInd();
                                } else if (sessionAdditionalInsured.getProductTabKey().equalsIgnoreCase(updateComponentProductBO.getProductTabkey()) && sessionAdditionalInsured.getComponentProductTabKey().equalsIgnoreCase(updateComponentProductBO.getComponentProductTabKey())) {
                                    processingInd = sessionAdditionalInsured.getProcessingInd();
                                }
                            }
                            updateComponentProductBO.setAdditionalInsured(additionalInsuredListOfProduct);
                            AdditionalInsuredsBO additionalInsureds = new AdditionalInsuredsBO();
                            additionalInsureds.setAdditionalInsuredRq(additionalInsuredListOfProduct);
                            additionalInsureds.setProcessingInd(processingInd);
                            updateComponentProductBO.setAdditionalInsureds(additionalInsureds);
                        }

                        if (null != session.getAttribute(NGEConstants.PRODUCT_ASSET_DETAIL)) {

                            assetProductMap = (Map<String, Map<String, AssetBO>>) session
                                    .getAttribute(NGEConstants.PRODUCT_ASSET_DETAIL);

                            if (null != assetProductMap) {
                                assetMap = assetProductMap
                                        .get(updateComponentProductBO.getProductTabkey()
                                                + "~"
                                                + updateComponentProductBO
                                                .getComponentProductTabKey());

                                if (null != assetMap) {
                                    assetList = new ArrayList<AssetBO>(assetMap.values());
                                    List<AssetBO> assetListOfProduct = new ArrayList<AssetBO>();
                                    for (AssetBO sessionAsset : assetList) {
                                        if (sessionAsset.getProductTabKey().equalsIgnoreCase(updateComponentProductBO.getProductTabkey()) && sessionAsset.getComponentProductTabKey().equalsIgnoreCase(updateComponentProductBO.getComponentProductTabKey())) {
                                            assetListOfProduct.add(sessionAsset);
                                        }
                                    }
                                    updateComponentProductBO.setAsset(assetListOfProduct);
                                }

                            }

                        }


                        if (null != policyDetailList && !policyDetailList.isEmpty()) {
                            ManageTransactionServiceHandler.setPolicyDetails(updateTransactionRequest.getTransactionId(), transactionVersion.getTransactionVersionNo(), updateComponentProductBO, policyDetailList);
                        }
                        if (null != session.getAttribute(NGEConstants.EXPOSURE_COUNTRY_DETAIL)) {
                            Map<String, ExposureCountryBO> exposureMap = (Map<String, ExposureCountryBO>) session.getAttribute(NGEConstants.EXPOSURE_COUNTRY_DETAIL);
                            updateComponentProductBO.setExposureCountry(exposureMap.get(updateComponentProductBO.getProductTabkey() + "~" + updateComponentProductBO.getComponentProductTabKey()));
                        }
                        if (null != session.getAttribute(NGEConstants.SESSION_ASSOCIATE_PRODUCT_LIST_DATA)) {
                            Map<String, List<ProductBO>> expiringProductMap = (Map<String, List<ProductBO>>) session.getAttribute(NGEConstants.SESSION_ASSOCIATE_PRODUCT_LIST_DATA);
                            if (expiringProductMap != null && expiringProductMap.size() > 0) {
                                List<ProductBO> expiringProductList = expiringProductMap.get(updateComponentProductBO.getProductTabkey() + "~" + updateComponentProductBO.getComponentProductTabKey());
                                if (expiringProductList != null && expiringProductList.size() > 0) {
                                    updateComponentProductBO.setExpiringProduct(expiringProductList);
                                }
                            }
                        }
                        if (null != updateComponentProductBO.getDspMmcp() && !updateComponentProductBO.getDspMmcp().trim().isEmpty()) {
                            String dSPMMCP = updateComponentProductBO.getDspMmcp();
                            String[] dspMMCP = dSPMMCP.split("-");
                            String creditedCountryBranchCd = updateTransactionRequest.getUpdateTransactionDetails().getCreditedBranchStr().split("-")[0];
                            updateComponentProductBO.setCreditedCountryBranchCd(creditedCountryBranchCd);
                            if (creditedCountryBranchCd.equalsIgnoreCase("0") || creditedCountryBranchCd.equalsIgnoreCase("USA") || creditedCountryBranchCd.equalsIgnoreCase("1") || creditedCountryBranchCd.equalsIgnoreCase("CAN")) {
                                if (dspMMCP[0].equalsIgnoreCase("9999")) {
                                    updateComponentProductBO.setDivisionNo(updateComponentProductBO.getDivisionNo());
                                } else {
                                    updateComponentProductBO.setDivisionNo(dspMMCP[0]);
                                }
                                updateComponentProductBO.setSectionCd(dspMMCP[1]);
                                updateComponentProductBO.setProfitUnitCd(dspMMCP[2]);
                            } else {
                                updateComponentProductBO.setMajorLineCd(dspMMCP[0]);
                                updateComponentProductBO.setMinorLineCd(dspMMCP[1]);
                                updateComponentProductBO.setClassPerilCd(dspMMCP[2]);
                            }
                        }
                    }
                }
            }
            SequenceNumberGeneration generateObj = new SequenceNumberGeneration();
            HashMap<String, String> sequenceNames = new HashMap<>();
            HashMap<String, Object> sequenceValueMap = new HashMap<String, Object>();
            sequenceNames.put("UPDATE_TRANSACTION", "INT");
            sequenceValueMap = generateObj.getNextSequenceNumber(sequenceNames);
            sequenceNo = Integer.parseInt(sequenceValueMap.get(
                    "UPDATE_TRANSACTION").toString());
            try {
                updateTransactionRequest = ManageTransactionServiceHandler
                        .updateTransactionDetails(updateTransactionRequest,
                                dbSetTransactionDetails);
                updateTransactionResp = serviceObj
                        .updateTransaction(updateTransactionRequest);
                if (null != updateTransactionRequest.getReserveProductReq() && !updateTransactionRequest.getReserveProductReq().isEmpty()) {
                    List<ProductBO> reserveProds = ManageTransactionServiceHandler.getReserveList(updateTransactionRequest.getReserveProductReq(), updateTransactionResp);
                    if (null != reserveProds && !reserveProds.isEmpty()) {
                        reserveProductsResponse = reserveSerObj.reserveProducts(updateTransactionRequest.getReserveProductReq());
                    }
                }
            } catch (MalformedURLException e) {
                logger.info("NGEUIException", e);
                exceptionBO = new ExceptionBO();
                exceptionBO.setErrorFrom("UpdateTransactionService");
                exceptionBO.setErrorMessage(e.getMessage());
            } catch (UpdateTransactionAIGCIExceptionTypeMsg e) {
                logger.info("The error emssage is : " + e.getFaultInfo().getErrorMessage());
                logger.info("NGEUIException", e);
                exceptionBO = new ExceptionBO();
                exceptionBO.setErrorFrom("UpdateTransactionService");
                exceptionBO.setErrorMessage(seti18ErroMessage(e
                        .getFaultInfo().getErrorCode()));
                exceptionBO.setErrorCode(e.getFaultInfo().getErrorCode());
                exceptionBO.setErrorType(e.getFaultInfo().getErrorType());
            } catch (ManageProductsAIGCIExceptionTypeMsg e) {
                logger.info("NGEUIException", e);
                exceptionBO = new ExceptionBO();
                exceptionBO.setErrorFrom("UpdateTransactionService");
                exceptionBO.setErrorMessage(seti18ErroMessage(e
                        .getFaultInfo().getErrorCode()));
                exceptionBO.setErrorCode(e.getFaultInfo().getErrorCode());
                exceptionBO.setErrorType(e.getFaultInfo().getErrorType());
            } catch (ReserveProductAIGCIExceptionTypeMsg e) {
                exceptionBO = new ExceptionBO();
                exceptionBO.setErrorFrom(NGEConstants.RESERVE_PRODUCT_SERVICE);
                exceptionBO.setErrorMessage(seti18ErroMessage(e.getFaultInfo()
                        .getErrorCode()));
                exceptionBO.setErrorCode(NGEConstants.FAILURE_CODE);
                exceptionBO.setErrorType(e.getFaultInfo().getErrorType());
                logger.info("NGEUIException", e);
            } catch (Exception e) {
                logger.info("NGEUIException", e);
                logger.info("NGEUIException", e);
                exceptionBO = new ExceptionBO();
                exceptionBO.setErrorFrom("UpdateTransactionService");
                exceptionBO.setErrorMessage(seti18ErroMessage(NGEConstants.ERROR_INVOKING_SERVICE));
            }
            message = new StringBuffer();
            DataCacheObject cacheObject = new DataCacheObject();
            prodNameMapMktPdct = (Map<String, String>) cacheObject.getDynacacheObj("PRODUCT_NAME_BY_CODE_MKT_PDCT");
            prodNameMapCmptPdct = (Map<String, String>) cacheObject.getDynacacheObj("PRODUCT_NAME_BY_CODE_CMPNT_PDCT");
            prodNameMapSubPdct = (Map<String, String>) cacheObject.getDynacacheObj("PRODUCT_NAME_BY_CODE_SUB_PDCT");

            if (null != updateTransactionResp) {

                if (null != updateTransactionResp.getAddProducts() && !updateTransactionResp.getAddProducts().isEmpty()) {
                    for (ProductBO product : updateTransactionResp.getAddProducts()) {
                        if (null != product.getMessage()) {
                            if (!product.getMessage().getMessageCode().equalsIgnoreCase("SUCCESS")
                                    && !product.getMessage().getMessageCode().equalsIgnoreCase("000")) {
                                message.append(seti18ErroMessage(product.getMessage().getMessageCode()));
                                message.append("~~");
                                MessageDetailsBO bo = new MessageDetailsBO();
                                if (null != product.getAttachmentPointAmt()) {
                                    bo.setAttachmentPoint(product.getAttachmentPointAmt());
                                    if (product.getMarketableProductCd() != null) {
                                        bo.setProductName(prodNameMapCmptPdct.get(product.getComponentProductCd()));
                                    } else {
                                        bo.setProductName(prodNameMapSubPdct.get(product.getComponentProductCd()));
                                    }
                                } else {
                                    bo.setProductName(prodNameMapMktPdct.get(product.getMarketableProductCd()));
                                }
                                bo.setMesssage(seti18ErroMessage(product.getMessage().getMessageCode()));
                                bo.setErrorCode(product.getMessage().getMessageCode());
                                serviceMessages.add(bo);
                            } else {
                                MessageDetailsBO bo = new MessageDetailsBO();
                                if (null != product.getAttachmentPointAmt()) {
                                    bo.setAttachmentPoint(product.getAttachmentPointAmt());
                                    if (null == product.getMarketableProductCd()) {
                                        bo.setMesssage(NGEConstants.TECH_SUB_PRODUCT_ADD_SUCCESS);
                                    } else {
                                        bo.setMesssage(NGEConstants.COMP_PRODUCT_ADD_SUCCESS);
                                    }
                                    if (product.getMarketableProductCd() != null) {
                                        bo.setProductName(prodNameMapCmptPdct.get(product.getComponentProductCd()));
                                    } else {
                                        bo.setProductName(prodNameMapSubPdct.get(product.getComponentProductCd()));
                                    }
                                } else {
                                    bo.setMesssage(NGEConstants.MARKET_PRODUCT_ADD_SUCCESS);
                                    bo.setProductName(prodNameMapMktPdct.get(product.getMarketableProductCd()));
                                }
                                bo.setErrorCode(product.getMessage().getMessageCode());
                                serviceMessages.add(bo);
                            }
                        }
                    }
                }
                if (null != updateTransactionResp.getUpdateProducts() && !updateTransactionResp.getUpdateProducts().isEmpty()) {
                    for (ProductBO product : updateTransactionResp.getUpdateProducts()) {
                        if (null != product.getMessage()) {
                            if (!product.getMessage().getMessageCode().equalsIgnoreCase("SUCCESS")
                                    && !product.getMessage().getMessageCode().equalsIgnoreCase("000")) {
                                message.append(seti18ErroMessage(product.getMessage().getMessageCode()));
                                message.append("~~");
                                MessageDetailsBO bo = new MessageDetailsBO();
                                if (null != product.getAttachmentPointAmt()) {
                                    bo.setAttachmentPoint(product.getAttachmentPointAmt());
                                    if (product.getMarketableProductCd() != null) {
                                        bo.setProductName(prodNameMapCmptPdct.get(product.getComponentProductCd()));
                                    } else {
                                        bo.setProductName(prodNameMapSubPdct.get(product.getComponentProductCd()));
                                    }
                                } else {
                                    bo.setProductName(prodNameMapMktPdct.get(product.getMarketableProductCd()));
                                }
                                bo.setMesssage(seti18ErroMessage(product.getMessage().getMessageCode()));
                                bo.setErrorCode(product.getMessage().getMessageCode());
                                serviceMessages.add(bo);
                            } else {
                                MessageDetailsBO bo = new MessageDetailsBO();
                                if (null != product.getAttachmentPointAmt()) {
                                    bo.setAttachmentPoint(product.getAttachmentPointAmt());
                                    //bo.setMesssage(NGEConstants.COMP_PRODUCT_UPDATE_SUCCESS);
                                    if (null == product.getMarketableProductCd()) {
                                        bo.setMesssage(NGEConstants.TECH_SUB_PRODUCT_UPDATE_SUCCESS);
                                    } else {
                                        bo.setMesssage(NGEConstants.COMP_PRODUCT_UPDATE_SUCCESS);
                                    }
                                    if (product.getMarketableProductCd() != null) {
                                        bo.setProductName(prodNameMapCmptPdct.get(product.getComponentProductCd()));
                                    } else {
                                        bo.setProductName(prodNameMapSubPdct.get(product.getComponentProductCd()));
                                    }
                                } else {
                                    bo.setMesssage(NGEConstants.MARKET_PRODUCT_UPDATE_SUCCESS);
                                    bo.setProductName(prodNameMapMktPdct.get(product.getMarketableProductCd()));
                                }
                                bo.setErrorCode(product.getMessage().getMessageCode());
                                serviceMessages.add(bo);
                            }
                        }
                    }
                }
                if (null != updateTransactionResp.getRemoveProducts() && !updateTransactionResp.getRemoveProducts().isEmpty()) {
                    for (ProductBO product : updateTransactionResp.getRemoveProducts()) {
                        if (null != product.getMessage()) {
                            if (!product.getMessage().getMessageCode().equalsIgnoreCase("SUCCESS")
                                    && !product.getMessage().getMessageCode().equalsIgnoreCase("000")) {
                                message.append(seti18ErroMessage(product.getMessage().getMessageCode()));
                                message.append("~~");
                                MessageDetailsBO bo = new MessageDetailsBO();
                                if (null != product.getAttachmentPointAmt()) {
                                    bo.setAttachmentPoint(product.getAttachmentPointAmt());
                                    if (product.getMarketableProductCd() != null) {
                                        bo.setProductName(prodNameMapCmptPdct.get(product.getComponentProductCd()));
                                    } else {
                                        bo.setProductName(prodNameMapSubPdct.get(product.getComponentProductCd()));
                                    }
                                } else {
                                    bo.setProductName(prodNameMapMktPdct.get(product.getMarketableProductCd()));
                                }
                                bo.setMesssage(seti18ErroMessage(product.getMessage().getMessageCode()));
                                bo.setErrorCode(product.getMessage().getMessageCode());
                                serviceMessages.add(bo);
                            } else {
                                MessageDetailsBO bo = new MessageDetailsBO();
                                if (null != product.getAttachmentPointAmt()) {
                                    bo.setAttachmentPoint(product.getAttachmentPointAmt());
                                    //bo.setMesssage(NGEConstants.COMP_PRODUCT_REMOVE_SUCCESS);
                                    if (null == product.getMarketableProductCd()) {
                                        bo.setMesssage(NGEConstants.TECH_SUB_PRODUCT_REMOVE_SUCCESS);
                                    } else {
                                        bo.setMesssage(NGEConstants.COMP_PRODUCT_REMOVE_SUCCESS);
                                    }
                                    if (product.getMarketableProductCd() != null) {
                                        bo.setProductName(prodNameMapCmptPdct.get(product.getComponentProductCd()));
                                    } else {
                                        bo.setProductName(prodNameMapSubPdct.get(product.getComponentProductCd()));
                                    }
                                } else {
                                    bo.setMesssage(NGEConstants.MARKET_PRODUCT_REMOVE_SUCCESS);
                                    bo.setProductName(prodNameMapMktPdct.get(product.getMarketableProductCd()));
                                }
                                bo.setErrorCode(product.getMessage().getMessageCode());
                                serviceMessages.add(bo);
                            }
                        }
                    }
                }
                if (null != reserveProductsResponse && !reserveProductsResponse.isEmpty()) {
                    for (ReserveProductsRsBO product : reserveProductsResponse) {
                        if (null != product.getMessage()) {
                            if (!product.getMessage().getMessageCode().equalsIgnoreCase("SUCCESS")
                                    && !product.getMessage().getMessageCode().equalsIgnoreCase("000")) {
                                message.append(seti18ErroMessage(product.getMessage().getMessageCode()));
                                message.append("~~");
                                MessageDetailsBO bo = new MessageDetailsBO();
                                if (null != product.getAttachmentPointAmt()) {
                                    bo.setAttachmentPoint(product.getAttachmentPointAmt());
                                    if (product.getMarketableProductCd() != null) {
                                        bo.setProductName(prodNameMapCmptPdct.get(product.getComponentProductCd()));
                                    } else {
                                        bo.setProductName(prodNameMapSubPdct.get(product.getComponentProductCd()));
                                    }
                                } else {
                                    bo.setProductName(prodNameMapMktPdct.get(product.getMarketableProductCd()));
                                }
                                bo.setMesssage(seti18ErroMessage(product.getMessage().getMessageCode()));
                                bo.setErrorCode(product.getMessage().getMessageCode());
                                serviceMessages.add(bo);
                            } else {
                                MessageDetailsBO bo = new MessageDetailsBO();
                                if (null != product.getAttachmentPointAmt()) {
                                    bo.setAttachmentPoint(product.getAttachmentPointAmt());
                                    bo.setMesssage(NGEConstants.PRODUCT_RESERVE_SUCCESS);
                                    if (product.getMarketableProductCd() != null) {
                                        bo.setProductName(prodNameMapCmptPdct.get(product.getComponentProductCd()));
                                    } else {
                                        bo.setProductName(prodNameMapSubPdct.get(product.getComponentProductCd()));
                                    }
                                } else {
                                    bo.setMesssage(NGEConstants.PRODUCT_RESERVE_SUCCESS);
                                    bo.setProductName(prodNameMapMktPdct.get(product.getMarketableProductCd()));
                                }
                                bo.setErrorCode(product.getMessage().getMessageCode());
                                serviceMessages.add(bo);
                            }
                        }
                    }
                }
                createErrorMessage(updateTransactionResp.getUpdateProductStatus(), message, serviceMessages, NGEConstants.PRODUCT_STATUS_UPDATE_SUCCESS, prodNameMapCmptPdct, prodNameMapSubPdct);
                createErrorMessage(updateTransactionResp.getReopenProduct(), message, serviceMessages, NGEConstants.PRODUCT_STATUS_REOPEN_SUCCESS, prodNameMapCmptPdct, prodNameMapSubPdct);
                createErrorMessage(updateTransactionResp.getUnbindProduct(), message, serviceMessages, NGEConstants.PRODUCT_STATUS_UNBIND_SUCCESS, prodNameMapCmptPdct, prodNameMapSubPdct);
                updateTransactionResp.setServiceMessages(serviceMessages);
                if (exceptionBO != null) {
                    List<String> exceptionMessage = new ArrayList<String>();
                    exceptionMessage.add(exceptionBO.getErrorCode());
                    updateTransactionResp.setExceptionMessage(exceptionMessage);
                }
                if (null != session.getAttribute(NGEConstants.SESSION_TRANSACTION_ADDITIONAL_INSURED_DETAIL)) {
                    session.removeAttribute(NGEConstants.SESSION_TRANSACTION_ADDITIONAL_INSURED_DETAIL);
                }
                if (null != session.getAttribute(NGEConstants.TRANSACTION_ADDITIONAL_ACC_INSURED_LIST)) {
                    session.removeAttribute(NGEConstants.TRANSACTION_ADDITIONAL_ACC_INSURED_LIST);
                }
            }
        }
        if (exceptionBO != null
                && (serviceMessages.size() == 0)
        ) {
            jsonHeaderBO = setJsonHeader(sequenceNo,
                    exceptionBO.getErrorCode(), exceptionBO.getErrorType(),
                    exceptionBO.getErrorMessage(), null);
        } else if (message != null) {
            jsonHeaderBO = setJsonHeader(sequenceNo, NGEConstants.SUCCESS_CODE,
                    NGEConstants.SUCCESS, message.toString(),
                    updateTransactionResp);
        }
        return jsonHeaderBO;
    }

    private void createErrorMessage(List<ProductBO> productBOList, StringBuffer message, List<MessageDetailsBO> serviceMessages, String successMessage, Map<String, String> cmpntProdNameMap, Map<String, String> subProdNameMap) {
        if (null != productBOList && !productBOList.isEmpty()) {
            for (ProductBO product : productBOList) {
                if (null != product.getMessage()) {
                    if (!product.getMessage().getMessageCode().equalsIgnoreCase("SUCCESS")
                            && !product.getMessage().getMessageCode().equalsIgnoreCase("000")) {
                        message.append(seti18ErroMessage(product.getMessage().getMessageCode()));
                        message.append("~~");
                        MessageDetailsBO bo = new MessageDetailsBO();
                        if (product.getMarketableProductCd() != null) {
                            bo.setProductName(cmpntProdNameMap.get(product.getComponentProductCd()));
                        } else {
                            bo.setProductName(subProdNameMap.get(product.getComponentProductCd()));
                        }
                        bo.setAttachmentPoint(product.getAttachmentPointAmt());
                        bo.setMesssage(seti18ErroMessage(product.getMessage().getMessageCode()));
                        bo.setErrorCode(product.getMessage().getMessageCode());
                        serviceMessages.add(bo);
                    } else {
                        MessageDetailsBO bo = new MessageDetailsBO();
                        if (product.getMarketableProductCd() != null) {
                            bo.setProductName(cmpntProdNameMap.get(product.getComponentProductCd()));
                        } else {
                            bo.setProductName(subProdNameMap.get(product.getComponentProductCd()));
                        }
                        bo.setAttachmentPoint(product.getAttachmentPointAmt());
                        logger.info("Success Message : " + successMessage);
                        bo.setMesssage(successMessage);
                        bo.setErrorCode(product.getMessage().getMessageCode());
                        serviceMessages.add(bo);
                    }
                }
            }
        }
    }

    @RequestMapping(value = "/accountdetails", headers = "Accept=application/json", method = RequestMethod.POST)
    public @ResponseBody
    JSONHeaderBO accountdetails(HttpServletRequest request,
                                @RequestBody SubmissionStartDetailsSessionBO accountBO, HttpServletResponse response) throws IOException {

        HttpSession session = null;
        JSONHeaderBO bo = new JSONHeaderBO();
        session = request.getSession(false);
        if (session == null || (session.getAttribute(NGEConstants.SESSION_CASL_USERID) == null)) {
            //logger.info("Invalid Session : "+session);
            response.sendRedirect("jsp/logout.jsp");
            return bo;
        }
		/*else{
			logger.info("session : "+session);
		}*/
        logger.info("inside save account details");
        String jsonBO = null;
        ObjectMapper mapper = new ObjectMapper();
        StartSubmissionSessionBO submisssionSession = new StartSubmissionSessionBO();
        submisssionSession.setStartsubmission(accountBO);
        try {
            jsonBO = mapper.writeValueAsString(submisssionSession);
        } catch (JsonProcessingException e) {
            logger.info("NGEUIException", e);
        }
        //session = request.getSession(true);
        logger.info("************************Session Storage for Setting Account Name Starts*******************");
        session.setAttribute(NGEConstants.START_SUBMISSION, XSSValidator.stripXSS(jsonBO));
        logger.info("************************Session Storage for Setting Account Name Ends*******************");
        return new JSONHeaderBO();
    }


    @SuppressWarnings("unchecked")
    @RequestMapping(value = "/updateSingleProduct", headers = "Accept=application/json", method = RequestMethod.POST)
    public @ResponseBody
    JSONHeaderBO updateSingleProduct(HttpServletRequest request,
                                     @RequestBody UpdateTransactionRequestBO updateTransactionRequest, HttpServletResponse response) throws IOException {

        HttpSession session = null;
        session = request.getSession(false);
        JSONHeaderBO jsonHeaderBO = new JSONHeaderBO();

        if (session == null || (session.getAttribute(NGEConstants.SESSION_CASL_USERID) == null)) {
            //logger.info("Invalid Session : "+session);
            response.sendRedirect("jsp/logout.jsp");
            return jsonHeaderBO;
        }
		/*else{
			logger.info("session : "+session);
		}*/
        TransactionManagementService serviceObj = new TransactionManagementService();
        serviceObj.setCaslServiceId((String) session.getAttribute(NGEConstants.SESSION_CASL_USERID));
        SubmissionManagementService reserveSerObj = new SubmissionManagementService();
        reserveSerObj.setCaslServiceId((String) session.getAttribute(NGEConstants.SESSION_CASL_USERID));
        ExceptionBO exceptionBO = null;
        GetsubmissionrespBO dbSetTransactionDetails = null;
        boolean sessionFlag = true;
        UpdateTransactionRespBO updateTransactionResp = null;
        Map<String, String> prodNameMapMktPdct = new HashMap<String, String>();
        Map<String, String> prodNameMapCmptPdct = new HashMap<String, String>();
        Map<String, String> prodNameMapSubPdct = new HashMap<String, String>();
        List<ReserveProductsRsBO> reserveProductsResponse = null;

        List<PolicyDetailBO> policyDetailList = null;
        SequenceNumberGeneration generateObj = new SequenceNumberGeneration();
        HashMap<String, String> sequenceNames = new HashMap<>();
        HashMap<String, Object> sequenceValueMap = new HashMap<String, Object>();
        sequenceNames.put("UPDATE_TRANSACTION", "INT");
        sequenceValueMap = generateObj.getNextSequenceNumber(sequenceNames);
        List<MessageDetailsBO> serviceMessages = new ArrayList<MessageDetailsBO>();
        int sequenceNo = Integer.parseInt(sequenceValueMap.get(
                "UPDATE_TRANSACTION").toString());
        StringBuffer message = new StringBuffer();
        try {

            logger.info("session object : " + session.getAttribute(NGEConstants.DB_SET_OBJECT));
            if (null != session.getAttribute(NGEConstants.DB_SET_OBJECT)) {
                dbSetTransactionDetails = (GetsubmissionrespBO) session.getAttribute(NGEConstants.DB_SET_OBJECT);
            }/*else{
				SubmissionDataService subServiceObj = new SubmissionDataService();
				subServiceObj.setCaslServiceId((String)session.getAttribute(NGEConstants.SESSION_CASL_USERID));
				SubmissionRs reponsesubmissionDet = subServiceObj.getSubmission(updateTransactionRequest.getSubmissionNo(),null,null,null);
				dbSetTransactionDetails = subServiceObj.setSubmissionResponseInBO(reponsesubmissionDet);
			}*/
        } /*catch (MalformedURLException e) {
			exceptionBO = new ExceptionBO();
			exceptionBO.setErrorFrom(NGEConstants.GET_SUBMISSION_SERVICE);
			logger.info("NGEUIException",e);
			exceptionBO
					.setErrorMessage(seti18ErroMessage(NGEConstants.MALFORMED_URL));
			exceptionBO.setErrorCode(NGEConstants.FAILURE_CODE);
			exceptionBO.setErrorType(NGEConstants.FATAL);
		} catch (GetSubmissionAIGCIExceptionTypeMsg e) {
			exceptionBO = new ExceptionBO();
			exceptionBO.setErrorFrom(NGEConstants.GET_SUBMISSION_SERVICE);
			exceptionBO.setErrorMessage(seti18ErroMessage(e.getFaultInfo()
					.getErrorCode()));
			exceptionBO.setErrorCode(NGEConstants.FAILURE_CODE);
			exceptionBO.setErrorType(e.getFaultInfo().getErrorType());
			logger.info("NGEUIException",e);
		}*/ catch (IllegalStateException ise) {
            //islogger.info("NGEUIException",e);
            sessionFlag = false;
            exceptionBO = new ExceptionBO();
            exceptionBO.setErrorFrom("UpdateTransactionService");
            exceptionBO.setErrorMessage(NGEConstants.SESSION_EXPIRED);
        } catch (Exception e) {
            exceptionBO = new ExceptionBO();
            exceptionBO.setErrorFrom(NGEConstants.GET_SUBMISSION_SERVICE);
            exceptionBO
                    .setErrorMessage(seti18ErroMessage(NGEConstants.ERROR_INVOKING_SERVICE));
            exceptionBO.setErrorCode(NGEConstants.FAILURE_CODE);
            exceptionBO.setErrorType(NGEConstants.FATAL);
            logger.info("NGEUIException", e);
        }
        if (sessionFlag) {
            logger.info("The Data Base Object from session is : " + dbSetTransactionDetails);
            if (dbSetTransactionDetails != null) {
                logger.info("The Data Base Object from session is : " + dbSetTransactionDetails.getTransactiondet());
            }
            if (null != updateTransactionRequest) {
                if (null != session.getAttribute(NGEConstants.SESSION_UPDATE_PRODUCT_STATUS)) {
                    updateTransactionRequest.setSetProductStatusReq((SetProductStatusReqBO) session.getAttribute(NGEConstants.SESSION_UPDATE_PRODUCT_STATUS));
                }
                if (null != session.getAttribute(NGEConstants.SESSION_REOPEN_PRODUCT)) {
                    updateTransactionRequest.setReopenProductsReq((ReopenProductsReqBO) session.getAttribute(NGEConstants.SESSION_REOPEN_PRODUCT));
                }
                if (null != session.getAttribute(NGEConstants.SESSION_UNBIND_PRODUCT_STATUS)) {
                    updateTransactionRequest.setUnBindProductsRq((UnBindProductReqBO) session.getAttribute(NGEConstants.SESSION_UNBIND_PRODUCT_STATUS));
                }
                List<TransactionVersionBO> transactionVersionList = updateTransactionRequest.getUpdateTransactionDetails().getTransactionVersionRq();

                for (TransactionVersionBO transactionVersion : transactionVersionList) {
                    List<ComponentProductBO> updateComponentProductList = transactionVersion.getProductDet().getComponentProduct();

                    for (ComponentProductBO updateComponentProductBO : updateComponentProductList) {

					/*		additionalInsuredMap = (HashMap<String, AdditionalInsuredsBO>) session
									.getAttribute("AdditionalInsured");
							if(null!=additionalInsuredMap){
								additionalInsuredsBO = additionalInsuredMap
										.get(productsBO.getProductTabKey()
												+ "~"
												+ updateComponentProductBO
														.getComponentProductTabKey());
							}
							*/

                        if (null != session.getAttribute(NGEConstants.ADDITIONAL_INSURED_LIST_PRODUCT_LEVEL)) {
                            List<AdditionalInsuredBO> additionalInsuredListProductLevel = (List<AdditionalInsuredBO>) session.getAttribute(NGEConstants.ADDITIONAL_INSURED_LIST_PRODUCT_LEVEL);
                            List<AdditionalInsuredBO> additionalInsuredListOfProduct = new ArrayList<AdditionalInsuredBO>();
                            String processingInd = null;
                            for (AdditionalInsuredBO sessionAdditionalInsured : additionalInsuredListProductLevel) {
                                if (sessionAdditionalInsured.getProductTabKey().equalsIgnoreCase(updateComponentProductBO.getProductTabkey()) && sessionAdditionalInsured.getComponentProductTabKey().equalsIgnoreCase(updateComponentProductBO.getComponentProductTabKey()) && sessionAdditionalInsured.getAccountNo() != null) {
                                    additionalInsuredListOfProduct.add(sessionAdditionalInsured);
                                    processingInd = sessionAdditionalInsured.getProcessingInd();
                                } else if (sessionAdditionalInsured.getProductTabKey().equalsIgnoreCase(updateComponentProductBO.getProductTabkey()) && sessionAdditionalInsured.getComponentProductTabKey().equalsIgnoreCase(updateComponentProductBO.getComponentProductTabKey())) {
                                    processingInd = sessionAdditionalInsured.getProcessingInd();
                                }
                            }
                            updateComponentProductBO.setAdditionalInsured(additionalInsuredListOfProduct);
                            AdditionalInsuredsBO additionalInsureds = new AdditionalInsuredsBO();
                            additionalInsureds.setAdditionalInsuredRq(additionalInsuredListOfProduct);
                            additionalInsureds.setProcessingInd(processingInd);
                            updateComponentProductBO.setAdditionalInsureds(additionalInsureds);
                        }

                        if (null != session.getAttribute(NGEConstants.PRODUCT_ASSET_DETAIL)) {

                            Map<String, Map<String, AssetBO>> assetProductMap = (Map<String, Map<String, AssetBO>>) session
                                    .getAttribute(NGEConstants.PRODUCT_ASSET_DETAIL);

                            if (null != assetProductMap) {
                                Map<String, AssetBO> assetMap = assetProductMap
                                        .get(updateComponentProductBO.getProductTabkey()
                                                + "~"
                                                + updateComponentProductBO
                                                .getComponentProductTabKey());

                                if (null != assetMap) {
                                    List<AssetBO> assetList = new ArrayList<AssetBO>(assetMap.values());
                                    List<AssetBO> assetListOfProduct = new ArrayList<AssetBO>();
                                    for (AssetBO sessionAsset : assetList) {
                                        if (sessionAsset.getProductTabKey().equalsIgnoreCase(updateComponentProductBO.getProductTabkey()) && sessionAsset.getComponentProductTabKey().equalsIgnoreCase(updateComponentProductBO.getComponentProductTabKey())) {
                                            assetListOfProduct.add(sessionAsset);
                                        }
                                    }
                                    updateComponentProductBO.setAsset(assetListOfProduct);
                                }

                            }

                        }
                        if (null != session.getAttribute(NGEConstants.SESSION_ASSOCIATE_PRODUCT_LIST_DATA)) {
                            Map<String, List<ProductBO>> expiringProductMap = (Map<String, List<ProductBO>>) session.getAttribute(NGEConstants.SESSION_ASSOCIATE_PRODUCT_LIST_DATA);
                            if (expiringProductMap != null && expiringProductMap.size() > 0) {
                                List<ProductBO> expiringProductList = expiringProductMap.get(updateComponentProductBO.getProductTabkey() + "~" + updateComponentProductBO.getComponentProductTabKey());
                                if (expiringProductList != null && expiringProductList.size() > 0) {
                                    updateComponentProductBO.setExpiringProduct(expiringProductList);
                                }
                            }
                        }
                        policyDetailList = (List<PolicyDetailBO>) session
                                .getAttribute(NGEConstants.PRODUCT_POLICY_DETAIL);
                        if (null != policyDetailList && !policyDetailList.isEmpty()) {
                            ManageTransactionServiceHandler.setPolicyDetails(updateTransactionRequest.getTransactionId(), transactionVersion.getTransactionVersionNo(), updateComponentProductBO, policyDetailList);
                        }
                        if (null != session.getAttribute(NGEConstants.EXPOSURE_COUNTRY_DETAIL)) {
                            Map<String, ExposureCountryBO> exposureMap = (Map<String, ExposureCountryBO>) session.getAttribute(NGEConstants.EXPOSURE_COUNTRY_DETAIL);
                            updateComponentProductBO.setExposureCountry(exposureMap.get(updateComponentProductBO.getProductTabkey() + "~" + updateComponentProductBO.getComponentProductTabKey()));
                        }
                        if (null != updateComponentProductBO.getDspMmcp() && !updateComponentProductBO.getDspMmcp().trim().isEmpty()) {
                            String dSPMMCP = updateComponentProductBO.getDspMmcp();
                            String[] dspMMCP = dSPMMCP.split("-");
                            String creditedCountryBranchCd = updateTransactionRequest.getUpdateTransactionDetails().getCreditedBranchHiddenStr().split("-")[0];
                            updateComponentProductBO.setCreditedCountryBranchCd(creditedCountryBranchCd);

								/*List<BranchBO> branchList=updateComponentProductBO.getBranch();
								for(BranchBO branchBo:branchList){
								String branchTypeCd=	branchBo.getBranchTypeCd();
								if(branchTypeCd.equalsIgnoreCase("Working Branch")){
									branchCd=branchBo.getCountryCd();
									}
								}*/
                            if (creditedCountryBranchCd.equalsIgnoreCase("0") || creditedCountryBranchCd.equalsIgnoreCase("USA") || creditedCountryBranchCd.equalsIgnoreCase("1") || creditedCountryBranchCd.equalsIgnoreCase("CAN")) {
                                if (dspMMCP[0].equalsIgnoreCase("9999")) {
                                    updateComponentProductBO.setDivisionNo(updateComponentProductBO.getDivisionNo());
                                    //updateComponentProductBO.setDivisionNo(dspMMCP[0]);
                                } else {
                                    //updateComponentProductBO.setDivisionNo(updateComponentProductBO.getDivisionNo());
                                    updateComponentProductBO.setDivisionNo(dspMMCP[0]);
                                }
                                //updateComponentProductBO.setDivisionNo(dspMMCP[0]);
                                updateComponentProductBO.setSectionCd(dspMMCP[1]);
                                updateComponentProductBO.setProfitUnitCd(dspMMCP[2]);
                            } else {
                                updateComponentProductBO.setMajorLineCd(dspMMCP[0]);
                                updateComponentProductBO.setMinorLineCd(dspMMCP[1]);
                                updateComponentProductBO.setClassPerilCd(dspMMCP[2]);
                            }
                        }
                    }
                }
            }

            try {
                updateTransactionRequest = ManageTransactionServiceHandler
                        .updateSingleProductDetails(updateTransactionRequest,
                                dbSetTransactionDetails);
                updateTransactionResp = serviceObj
                        .manageProducts(updateTransactionRequest);
                if (null != updateTransactionRequest.getReserveProductReq() && !updateTransactionRequest.getReserveProductReq().isEmpty()) {
                    List<ProductBO> reserveProds = ManageTransactionServiceHandler.getReserveList(updateTransactionRequest.getReserveProductReq(), updateTransactionResp);
                    if (null != reserveProds && !reserveProds.isEmpty()) {
                        reserveProductsResponse = reserveSerObj.reserveProducts(updateTransactionRequest.getReserveProductReq());
                    }
                }
            } catch (MalformedURLException e) {
                logger.info("NGEUIException", e);
                exceptionBO = new ExceptionBO();
                exceptionBO.setErrorFrom("UpdateTransactionService");
                exceptionBO.setErrorMessage(e.getMessage());
            } catch (ManageProductsAIGCIExceptionTypeMsg e) {
                logger.info("NGEUIException", e);
                //System.out.println(e.getFaultInfo().getErrorMessage());
                exceptionBO = new ExceptionBO();
                exceptionBO.setErrorFrom("UpdateTransactionService");
                exceptionBO.setErrorMessage(seti18ErroMessage(e.getFaultInfo().getErrorCode()));
                exceptionBO.setErrorCode(e.getFaultInfo().getErrorCode());
                exceptionBO.setErrorType(e.getFaultInfo().getErrorType());
            } catch (ReserveProductAIGCIExceptionTypeMsg e) {
                exceptionBO = new ExceptionBO();
                exceptionBO.setErrorFrom(NGEConstants.RESERVE_PRODUCT_SERVICE);
                exceptionBO.setErrorMessage(seti18ErroMessage(e.getFaultInfo()
                        .getErrorCode()));
                exceptionBO.setErrorCode(NGEConstants.FAILURE_CODE);
                exceptionBO.setErrorType(e.getFaultInfo().getErrorType());
                logger.info("NGEUIException", e);
            } catch (Exception e) {
                logger.info("NGEUIException", e);
                exceptionBO = new ExceptionBO();
                exceptionBO.setErrorFrom("UpdateTransactionService");
                exceptionBO.setErrorMessage(e.getMessage());
            }
            if (null != updateTransactionResp) {
                DataCacheObject cacheObject = new DataCacheObject();
                prodNameMapMktPdct = (Map<String, String>) cacheObject.getDynacacheObj("PRODUCT_NAME_BY_CODE_MKT_PDCT");
                prodNameMapCmptPdct = (Map<String, String>) cacheObject.getDynacacheObj("PRODUCT_NAME_BY_CODE_CMPNT_PDCT");
                prodNameMapSubPdct = (Map<String, String>) cacheObject.getDynacacheObj("PRODUCT_NAME_BY_CODE_SUB_PDCT");
                if (null != updateTransactionResp.getAddProducts() && !updateTransactionResp.getAddProducts().isEmpty()) {
                    for (ProductBO product : updateTransactionResp.getAddProducts()) {
                        if (null != product.getMessage()) {
                            if (!product.getMessage().getMessageCode().equalsIgnoreCase("SUCCESS")
                                    && !product.getMessage().getMessageCode().equalsIgnoreCase("000")) {
                                message.append(seti18ErroMessage(product.getMessage().getMessageCode()));
                                message.append("~~");
                                MessageDetailsBO bo = new MessageDetailsBO();
                                if (null != product.getAttachmentPointAmt()) {
                                    bo.setAttachmentPoint(product.getAttachmentPointAmt());
                                    if (product.getMarketableProductCd() != null) {
                                        bo.setProductName(prodNameMapCmptPdct.get(product.getComponentProductCd()));
                                    } else {
                                        bo.setProductName(prodNameMapSubPdct.get(product.getComponentProductCd()));
                                    }
                                } else {
                                    bo.setProductName(prodNameMapMktPdct.get(product.getMarketableProductCd()));
                                }
                                bo.setMesssage(seti18ErroMessage(product.getMessage().getMessageCode()));
                                bo.setErrorCode(product.getMessage().getMessageCode());
                                serviceMessages.add(bo);
                            } else {
                                MessageDetailsBO bo = new MessageDetailsBO();
                                if (null != product.getAttachmentPointAmt()) {
                                    bo.setAttachmentPoint(product.getAttachmentPointAmt());
                                    //bo.setMesssage(NGEConstants.COMP_PRODUCT_ADD_SUCCESS);
                                    if (null == product.getMarketableProductCd()) {
                                        bo.setMesssage(NGEConstants.TECH_SUB_PRODUCT_ADD_SUCCESS);
                                    } else {
                                        bo.setMesssage(NGEConstants.COMP_PRODUCT_ADD_SUCCESS);
                                    }
                                    if (product.getMarketableProductCd() != null) {
                                        bo.setProductName(prodNameMapCmptPdct.get(product.getComponentProductCd()));
                                    } else {
                                        bo.setProductName(prodNameMapSubPdct.get(product.getComponentProductCd()));
                                    }
                                } else {
                                    bo.setMesssage(NGEConstants.MARKET_PRODUCT_ADD_SUCCESS);
                                    bo.setProductName(prodNameMapMktPdct.get(product.getMarketableProductCd()));
                                }
                                bo.setErrorCode(product.getMessage().getMessageCode());
                                serviceMessages.add(bo);
                            }
                        }
                    }
                }
                if (null != updateTransactionResp.getUpdateProducts() && !updateTransactionResp.getUpdateProducts().isEmpty()) {
                    for (ProductBO product : updateTransactionResp.getUpdateProducts()) {
                        if (null != product.getMessage()) {
                            if (!product.getMessage().getMessageCode().equalsIgnoreCase("SUCCESS")
                                    && !product.getMessage().getMessageCode().equalsIgnoreCase("000")) {
                                message.append(seti18ErroMessage(product.getMessage().getMessageCode()));
                                message.append("~~");
                                MessageDetailsBO bo = new MessageDetailsBO();
                                if (null != product.getAttachmentPointAmt()) {
                                    bo.setAttachmentPoint(product.getAttachmentPointAmt());
                                    if (product.getMarketableProductCd() != null) {
                                        bo.setProductName(prodNameMapCmptPdct.get(product.getComponentProductCd()));
                                    } else {
                                        bo.setProductName(prodNameMapSubPdct.get(product.getComponentProductCd()));
                                    }
                                } else {
                                    bo.setProductName(prodNameMapMktPdct.get(product.getMarketableProductCd()));
                                }
                                bo.setMesssage(seti18ErroMessage(product.getMessage().getMessageCode()));
                                bo.setErrorCode(product.getMessage().getMessageCode());
                                serviceMessages.add(bo);
                            } else {
                                MessageDetailsBO bo = new MessageDetailsBO();
                                if (null != product.getAttachmentPointAmt()) {
                                    bo.setAttachmentPoint(product.getAttachmentPointAmt());
                                    //bo.setMesssage(NGEConstants.COMP_PRODUCT_UPDATE_SUCCESS);
                                    if (null == product.getMarketableProductCd()) {
                                        bo.setMesssage(NGEConstants.TECH_SUB_PRODUCT_UPDATE_SUCCESS);
                                    } else {
                                        bo.setMesssage(NGEConstants.COMP_PRODUCT_UPDATE_SUCCESS);
                                    }
                                    if (product.getMarketableProductCd() != null) {
                                        bo.setProductName(prodNameMapCmptPdct.get(product.getComponentProductCd()));
                                    } else {
                                        bo.setProductName(prodNameMapSubPdct.get(product.getComponentProductCd()));
                                    }
                                } else {
                                    bo.setMesssage(NGEConstants.MARKET_PRODUCT_UPDATE_SUCCESS);
                                    bo.setProductName(prodNameMapMktPdct.get(product.getMarketableProductCd()));
                                }
                                bo.setErrorCode(product.getMessage().getMessageCode());
                                serviceMessages.add(bo);
                            }
                        }
                    }
                }
                if (null != updateTransactionResp.getRemoveProducts() && !updateTransactionResp.getRemoveProducts().isEmpty()) {
                    for (ProductBO product : updateTransactionResp.getRemoveProducts()) {
                        if (null != product.getMessage()) {
                            if (!product.getMessage().getMessageCode().equalsIgnoreCase("SUCCESS")
                                    && !product.getMessage().getMessageCode().equalsIgnoreCase("000")) {
                                message.append(seti18ErroMessage(product.getMessage().getMessageCode()));
                                message.append("~~");
                                MessageDetailsBO bo = new MessageDetailsBO();
                                if (null != product.getAttachmentPointAmt()) {
                                    bo.setAttachmentPoint(product.getAttachmentPointAmt());
                                    if (product.getMarketableProductCd() != null) {
                                        bo.setProductName(prodNameMapCmptPdct.get(product.getComponentProductCd()));
                                    } else {
                                        bo.setProductName(prodNameMapSubPdct.get(product.getComponentProductCd()));
                                    }
                                } else {
                                    bo.setProductName(prodNameMapMktPdct.get(product.getMarketableProductCd()));
                                }
                                bo.setMesssage(seti18ErroMessage(product.getMessage().getMessageCode()));
                                bo.setErrorCode(product.getMessage().getMessageCode());
                                serviceMessages.add(bo);
                            } else {
                                MessageDetailsBO bo = new MessageDetailsBO();
                                if (null != product.getAttachmentPointAmt()) {
                                    bo.setAttachmentPoint(product.getAttachmentPointAmt());
                                    //bo.setMesssage(NGEConstants.COMP_PRODUCT_REMOVE_SUCCESS);
                                    if (null == product.getMarketableProductCd()) {
                                        bo.setMesssage(NGEConstants.TECH_SUB_PRODUCT_REMOVE_SUCCESS);
                                    } else {
                                        bo.setMesssage(NGEConstants.COMP_PRODUCT_REMOVE_SUCCESS);
                                    }
                                    if (product.getMarketableProductCd() != null) {
                                        bo.setProductName(prodNameMapCmptPdct.get(product.getComponentProductCd()));
                                    } else {
                                        bo.setProductName(prodNameMapSubPdct.get(product.getComponentProductCd()));
                                    }
                                } else {
                                    bo.setMesssage(NGEConstants.MARKET_PRODUCT_REMOVE_SUCCESS);
                                    bo.setProductName(prodNameMapMktPdct.get(product.getMarketableProductCd()));
                                }
                                bo.setErrorCode(product.getMessage().getMessageCode());
                                serviceMessages.add(bo);
                            }
                        }
                    }
                }
                if (null != reserveProductsResponse && !reserveProductsResponse.isEmpty()) {
                    for (ReserveProductsRsBO product : reserveProductsResponse) {
                        if (null != product.getMessage()) {
                            if (!product.getMessage().getMessageCode().equalsIgnoreCase("SUCCESS")
                                    && !product.getMessage().getMessageCode().equalsIgnoreCase("000")) {
                                message.append(seti18ErroMessage(product.getMessage().getMessageCode()));
                                message.append("~~");
                                MessageDetailsBO bo = new MessageDetailsBO();
                                if (null != product.getAttachmentPointAmt()) {
                                    bo.setAttachmentPoint(product.getAttachmentPointAmt());
                                    if (product.getMarketableProductCd() != null) {
                                        bo.setProductName(prodNameMapCmptPdct.get(product.getComponentProductCd()));
                                    } else {
                                        bo.setProductName(prodNameMapSubPdct.get(product.getComponentProductCd()));
                                    }
                                } else {
                                    bo.setProductName(prodNameMapMktPdct.get(product.getMarketableProductCd()));
                                }
                                bo.setMesssage(seti18ErroMessage(product.getMessage().getMessageCode()));
                                bo.setErrorCode(product.getMessage().getMessageCode());
                                serviceMessages.add(bo);
                            } else {
                                MessageDetailsBO bo = new MessageDetailsBO();
                                if (null != product.getAttachmentPointAmt()) {
                                    bo.setAttachmentPoint(product.getAttachmentPointAmt());
                                    bo.setMesssage(NGEConstants.PRODUCT_RESERVE_SUCCESS);
                                    if (product.getMarketableProductCd() != null) {
                                        bo.setProductName(prodNameMapCmptPdct.get(product.getComponentProductCd()));
                                    } else {
                                        bo.setProductName(prodNameMapSubPdct.get(product.getComponentProductCd()));
                                    }
                                } else {
                                    bo.setMesssage(NGEConstants.PRODUCT_RESERVE_SUCCESS);
                                    bo.setProductName(prodNameMapMktPdct.get(product.getMarketableProductCd()));
                                }
                                bo.setErrorCode(product.getMessage().getMessageCode());
                                serviceMessages.add(bo);
                            }
                        }
                    }
                }
                createErrorMessage(updateTransactionResp.getUpdateProductStatus(), message, serviceMessages, NGEConstants.PRODUCT_STATUS_UPDATE_SUCCESS, prodNameMapCmptPdct, prodNameMapSubPdct);
                createErrorMessage(updateTransactionResp.getReopenProduct(), message, serviceMessages, NGEConstants.PRODUCT_STATUS_REOPEN_SUCCESS, prodNameMapCmptPdct, prodNameMapSubPdct);
                createErrorMessage(updateTransactionResp.getUnbindProduct(), message, serviceMessages, NGEConstants.PRODUCT_STATUS_UNBIND_SUCCESS, prodNameMapCmptPdct, prodNameMapSubPdct);

                updateTransactionResp.setServiceMessages(serviceMessages);
                if (exceptionBO != null) {
                    List<String> exceptionMessage = new ArrayList<String>();
                    exceptionMessage.add(exceptionBO.getErrorCode());
                    updateTransactionResp.setExceptionMessage(exceptionMessage);
                }
            }
        }
        if (exceptionBO != null
                && (serviceMessages.size() == 0)
        ) {
            jsonHeaderBO = setJsonHeader(sequenceNo,
                    exceptionBO.getErrorCode(), exceptionBO.getErrorType(),
                    exceptionBO.getErrorMessage(), null);
        } else {
            if (updateTransactionResp != null && updateTransactionRequest != null) {
                updateTransactionResp.setTransactionId(updateTransactionRequest.getTransactionId());
            }
            jsonHeaderBO = setJsonHeader(sequenceNo, NGEConstants.SUCCESS_CODE,
                    NGEConstants.SUCCESS, message.toString(),
                    updateTransactionResp);
        }
        return jsonHeaderBO;

    }

    /* Benny End */
    @RequestMapping(value = "/searchUnderWriterDiary", headers = "Accept=application/json", method = RequestMethod.POST)
    public @ResponseBody
    JSONHeaderBO searchUnderWriterDiary(@RequestBody UnderWriterDiarySearchReqBO underWriterDiarySearchReq,
                                        HttpServletRequest request, HttpServletResponse response) throws IOException {
        HttpSession session = null;
        session = request.getSession(false);

        JSONHeaderBO jsonheader = new JSONHeaderBO();
        if (session == null || (session.getAttribute(NGEConstants.SESSION_CASL_USERID) == null)) {
            //logger.info("Invalid Session : "+session);
            response.sendRedirect("jsp/logout.jsp");
            return jsonheader;
        }
		/*else{
			logger.info("session : "+session);
		}*/

        ExceptionBO exceptionBO = null;
        int sequenceNo = 0;
        UnderWriterDiarySearchResRows diaryRows = new UnderWriterDiarySearchResRows();
        String i18SuccessMessage = null;
        String underWriterDiarySearchReqSession = null;
        try {
            SequenceNumberGeneration generateObj = new SequenceNumberGeneration();
            HashMap<String, String> sequenceNames = new HashMap<>();
            HashMap<String, Object> sequenceValueMap = new HashMap<String, Object>();
            sequenceNames.put("SEARCH_UNDERWRITER_DIARY", "INT");
            sequenceValueMap = generateObj.getNextSequenceNumber(sequenceNames);
            sequenceNo = Integer.parseInt(sequenceValueMap.get(
                    "SEARCH_UNDERWRITER_DIARY").toString());

            List<UnderWriterDiarySearchResBO> underWriterDiaryList = new ArrayList<UnderWriterDiarySearchResBO>();

            SubmissionDataService dataService = new SubmissionDataService();
            dataService.setCaslServiceId((String) session.getAttribute(NGEConstants.SESSION_CASL_USERID));

            underWriterDiaryList.addAll(dataService.getUnderwriterDiary(underWriterDiarySearchReq));

            ObjectWriter ow = new ObjectMapper().writer()
                    .withDefaultPrettyPrinter();
            underWriterDiarySearchReqSession = ow.writeValueAsString(underWriterDiarySearchReq);
            Collections.sort(underWriterDiaryList, UnderWriterDiarySearchResBO.underWriterDiarySearchResComparator);
            int rowId = 1;
            for (UnderWriterDiarySearchResBO underWriterDiarySearchResBO : underWriterDiaryList) {
                underWriterDiarySearchResBO.setUnderwriterRowId(rowId);
                rowId++;
            }
            diaryRows.setRows(underWriterDiaryList);
            i18SuccessMessage = seti18ErroMessage(NGEConstants.UNDERWRITERDIARY_SEARCH_SUCCESSFUL);

        } catch (GetUnderwriterDiaryAIGCIExceptionTypeMsg e) {
            exceptionBO = new ExceptionBO();
            exceptionBO.setErrorFrom(NGEConstants.UNDERDIARY_SEARCH_SERVICE);
            exceptionBO
                    .setErrorMessage(seti18ErroMessage(e.getFaultInfo().getErrorCode()));
            exceptionBO.setErrorCode(NGEConstants.FAILURE_CODE);
            exceptionBO.setErrorType(NGEConstants.FATAL);
            logger.info("NGEUIException", e);
        } catch (JsonProcessingException e) {
            exceptionBO = new ExceptionBO();
            exceptionBO.setErrorFrom(NGEConstants.UNDERDIARY_SEARCH_SERVICE);
            exceptionBO
                    .setErrorMessage(seti18ErroMessage(NGEConstants.ERROR_INVOKING_SERVICE));
            exceptionBO.setErrorCode(NGEConstants.FAILURE_CODE);
            exceptionBO.setErrorType(NGEConstants.FATAL);
            logger.info("NGEUIException", e);
        } catch (Exception e) {
            exceptionBO = new ExceptionBO();
            exceptionBO.setErrorFrom(NGEConstants.UNDERDIARY_SEARCH_SERVICE);
            exceptionBO
                    .setErrorMessage(seti18ErroMessage(NGEConstants.ERROR_INVOKING_SERVICE));
            exceptionBO.setErrorCode(NGEConstants.FAILURE_CODE);
            exceptionBO.setErrorType(NGEConstants.FATAL);
            logger.info("NGEUIException", e);
        }
        if (null == exceptionBO) {

            session.setAttribute(NGEConstants.UNDERWRITER_DIARY_REQUEST, XSSValidator.stripXSS(underWriterDiarySearchReqSession));
            session.setAttribute(NGEConstants.FROM_PAGE, XSSValidator.stripXSS("underwriterdiary"));
            jsonheader = setJsonHeader(sequenceNo,
                    NGEConstants.SUCCESS_CODE, NGEConstants.SUCCESS,
                    i18SuccessMessage, diaryRows);
        } else {
            jsonheader = setJsonHeader(sequenceNo,
                    exceptionBO.getErrorType(), NGEConstants.FAILURE,
                    exceptionBO.getErrorMessage(), null);
        }
        return jsonheader;
    }

    @RequestMapping(value = "/extendAutoCloseDays", headers = "Accept=application/json", method = RequestMethod.POST)
    public @ResponseBody
    JSONHeaderBO extendAutoCloseDays(HttpServletRequest request, @RequestBody ExtendAutoCloseDaysReqBO extendAutoCloseDaysReq, HttpServletResponse response) throws IOException {
        HttpSession session = null;
        session = request.getSession(false);
        JSONHeaderBO jsonHeaderBO = new JSONHeaderBO();
        if (session == null || (session.getAttribute(NGEConstants.SESSION_CASL_USERID) == null)) {
            //logger.info("Invalid Session : "+session);
            response.sendRedirect("jsp/logout.jsp");
            return jsonHeaderBO;
        }
		/*else{
			logger.info("session : "+session);
		}*/
        SubmissionManagementService serviceObj = new SubmissionManagementService();
        serviceObj.setCaslServiceId((String) session.getAttribute(NGEConstants.SESSION_CASL_USERID));
        ExtendAutoCloseDaysRespBO extendAutoCloseDaysResp = new ExtendAutoCloseDaysRespBO();
        ExceptionBO exceptionBO = null;
        SequenceNumberGeneration generateObj = new SequenceNumberGeneration();
        HashMap<String, String> sequenceNames = new HashMap<>();
        HashMap<String, Object> sequenceValueMap = new HashMap<String, Object>();
        sequenceNames.put("EXTEND_AUTO_CLOSE_DAYS", "INT");
        sequenceValueMap = generateObj.getNextSequenceNumber(sequenceNames);
        int sequenceNo = Integer.parseInt(sequenceValueMap.get(
                "EXTEND_AUTO_CLOSE_DAYS").toString());

        try {
            extendAutoCloseDaysResp = serviceObj.extendAutoCloseDays(extendAutoCloseDaysReq);
        } catch (ManageProductsAIGCIExceptionTypeMsg e) {
            exceptionBO = new ExceptionBO();
            exceptionBO.setErrorFrom(NGEConstants.EXTEND_AUTO_CLOSE_DAYS_SERVICE);
            exceptionBO.setErrorMessage(seti18ErroMessage(e.getFaultInfo()
                    .getErrorCode()));
            exceptionBO.setErrorCode(NGEConstants.FAILURE_CODE);
            exceptionBO.setErrorType(e.getFaultInfo().getErrorType());
            logger.info("NGEUIException", e);
        } catch (MalformedURLException e) {
            exceptionBO = new ExceptionBO();
            exceptionBO.setErrorFrom(NGEConstants.EXTEND_AUTO_CLOSE_DAYS_SERVICE);
            exceptionBO.setErrorMessage(e.getMessage());
            exceptionBO.setErrorType(NGEConstants.FATAL);
            logger.info("NGEUIException", e);
        } catch (NumberFormatException e) {
            exceptionBO = new ExceptionBO();
            exceptionBO.setErrorFrom(NGEConstants.EXTEND_AUTO_CLOSE_DAYS_SERVICE);
            logger.info("NGEUIException", e);
            exceptionBO
                    .setErrorMessage(seti18ErroMessage(NGEConstants.ERROR_PROCESSING_REQUEST));
            exceptionBO.setErrorCode(NGEConstants.FAILURE_CODE);
            exceptionBO.setErrorType(NGEConstants.FATAL);
            logger.info("NGEUIException", e);
        } catch (Exception e) {
            exceptionBO = new ExceptionBO();
            exceptionBO.setErrorFrom(NGEConstants.EXTEND_AUTO_CLOSE_DAYS_SERVICE);
            exceptionBO
                    .setErrorMessage(seti18ErroMessage(NGEConstants.ERROR_INVOKING_SERVICE));
            exceptionBO.setErrorType(NGEConstants.FATAL);
            logger.info("NGEUIException", e);
        }
        if (null == exceptionBO) {

            session.setAttribute(NGEConstants.UPDATE_EVENT_REFRESH_PAGE, XSSValidator.stripXSS("true"));
            jsonHeaderBO = setJsonHeader(sequenceNo, NGEConstants.SUCCESS_CODE,
                    NGEConstants.SUCCESS,
                    NGEConstants.EXTEND_AUTOCLOSE_SUCCESSFUL,
                    extendAutoCloseDaysResp);
        } else {
            jsonHeaderBO = setJsonHeader(sequenceNo,
                    exceptionBO.getErrorCode(), exceptionBO.getErrorType(),
                    exceptionBO.getErrorMessage(), null);
        }
        return jsonHeaderBO;
    }


    @RequestMapping(value = "/quoteProduct", headers = "Accept=application/json", method = RequestMethod.POST)
    public @ResponseBody
    JSONHeaderBO quoteProduct(HttpServletRequest request, @RequestBody QuoteProductReqBO quoteProductReq, HttpServletResponse response) throws IOException {
        HttpSession session = null;
        session = request.getSession(false);
        JSONHeaderBO jsonHeaderBO = new JSONHeaderBO();
        if (session == null || (session.getAttribute(NGEConstants.SESSION_CASL_USERID) == null)) {
            //logger.info("Invalid Session : "+session);
            response.sendRedirect("jsp/logout.jsp");
            return jsonHeaderBO;
        }
		/*else{
			logger.info("session : "+session);
		}*/
        SubmissionManagementService serviceObj = new SubmissionManagementService();
        serviceObj.setCaslServiceId((String) session.getAttribute(NGEConstants.SESSION_CASL_USERID));
        QuoteProductResBO quoteProductRes = new QuoteProductResBO();
        ExceptionBO exceptionBO = null;
        SequenceNumberGeneration generateObj = new SequenceNumberGeneration();
        HashMap<String, String> sequenceNames = new HashMap<>();
        HashMap<String, Object> sequenceValueMap = new HashMap<String, Object>();
        sequenceNames.put("QOUTE_PRODUCT", "INT");
        sequenceValueMap = generateObj.getNextSequenceNumber(sequenceNames);
        int sequenceNo = Integer.parseInt(sequenceValueMap.get(
                "QOUTE_PRODUCT").toString());

        try {
            quoteProductRes = serviceObj.quoteProduct(quoteProductReq);
        } catch (ManageProductsAIGCIExceptionTypeMsg e) {
            exceptionBO = new ExceptionBO();
            exceptionBO.setErrorFrom(NGEConstants.QUOTE_PRODUCT);
            exceptionBO.setErrorMessage(seti18ErroMessage(e.getFaultInfo()
                    .getErrorCode()));
            exceptionBO.setErrorCode(NGEConstants.FAILURE_CODE);
            exceptionBO.setErrorType(e.getFaultInfo().getErrorType());
            logger.info("NGEUIException", e);
        } catch (MalformedURLException e) {
            exceptionBO = new ExceptionBO();
            exceptionBO.setErrorFrom(NGEConstants.QUOTE_PRODUCT);
            exceptionBO.setErrorMessage(e.getMessage());
            exceptionBO.setErrorType(NGEConstants.FATAL);
            logger.info("NGEUIException", e);
        } catch (NumberFormatException e) {
            exceptionBO = new ExceptionBO();
            exceptionBO.setErrorFrom(NGEConstants.QUOTE_PRODUCT);
            logger.info("NGEUIException", e);
            exceptionBO
                    .setErrorMessage(seti18ErroMessage(NGEConstants.ERROR_PROCESSING_REQUEST));
            exceptionBO.setErrorCode(NGEConstants.FAILURE_CODE);
            exceptionBO.setErrorType(NGEConstants.FATAL);
            logger.info("NGEUIException", e);
        } catch (Exception e) {
            exceptionBO = new ExceptionBO();
            exceptionBO.setErrorFrom(NGEConstants.QUOTE_PRODUCT);
            exceptionBO
                    .setErrorMessage(seti18ErroMessage(NGEConstants.ERROR_INVOKING_SERVICE));
            exceptionBO.setErrorType(NGEConstants.FATAL);
            logger.info("NGEUIException", e);
        }
        if (null == exceptionBO) {

            session.setAttribute(NGEConstants.UPDATE_EVENT_REFRESH_PAGE, XSSValidator.stripXSS("true"));
            String responseCode = null;
            if (quoteProductRes != null && quoteProductRes.getMessageCode() != null &&
                    (quoteProductRes.getMessageCode().equalsIgnoreCase("000") ||
                            quoteProductRes.getMessageCode().equalsIgnoreCase("SUCCESS"))) {
                responseCode = NGEConstants.PRODUCT_STATUS_UPDATE_SUCCESS;
            } else if (quoteProductRes != null) {
                responseCode = quoteProductRes.getMessageCode();
            }
            if (responseCode != null && responseCode.equals(NGEConstants.PRODUCT_STATUS_UPDATE_SUCCESS)) {
                jsonHeaderBO = setJsonHeader(sequenceNo, NGEConstants.SUCCESS_CODE,
                        NGEConstants.SUCCESS,
                        NGEConstants.PRODUCT_STATUS_UPDATE_SUCCESS,
                        quoteProductRes);
            } else {
                jsonHeaderBO = setJsonHeader(sequenceNo, NGEConstants.FAILURE_CODE,
                        NGEConstants.FAILURE,
                        seti18ErroMessage(responseCode),
                        quoteProductRes);
            }

        } else {
            jsonHeaderBO = setJsonHeader(sequenceNo,
                    exceptionBO.getErrorCode(), exceptionBO.getErrorType(),
                    exceptionBO.getErrorMessage(), null);
        }
        return jsonHeaderBO;
    }

    @RequestMapping(value = "/updateProductStatus", headers = "Accept=application/json", method = RequestMethod.POST)
    public @ResponseBody
    JSONHeaderBO updateProductStatus(HttpServletRequest request, @RequestBody SetProductStatusReqBO setProductStatusReq, HttpServletResponse response) throws IOException {
        HttpSession session = null;
        session = request.getSession(false);
        JSONHeaderBO jsonHeaderBO = new JSONHeaderBO();
        if (session == null || (session.getAttribute(NGEConstants.SESSION_CASL_USERID) == null)) {
            //logger.info("Invalid Session : "+session);
            response.sendRedirect("jsp/logout.jsp");
            return jsonHeaderBO;
        }
		/*else{
			logger.info("session : "+session);
		}*/
        SubmissionManagementService serviceObj = new SubmissionManagementService();
        serviceObj.setCaslServiceId((String) session.getAttribute(NGEConstants.SESSION_CASL_USERID));
        SetProductStatusRespBO setProductStatusResp = new SetProductStatusRespBO();
        ExceptionBO exceptionBO = null;
        SequenceNumberGeneration generateObj = new SequenceNumberGeneration();
        HashMap<String, String> sequenceNames = new HashMap<>();
        HashMap<String, Object> sequenceValueMap = new HashMap<String, Object>();
        sequenceNames.put("UPDATE_PRODUCT_STATUS", "INT");
        sequenceValueMap = generateObj.getNextSequenceNumber(sequenceNames);
        int sequenceNo = Integer.parseInt(sequenceValueMap.get(
                "UPDATE_PRODUCT_STATUS").toString());

        try {

            List<PolicyDetailBO> policyDetailList = (List<PolicyDetailBO>) session.getAttribute(NGEConstants.PRODUCT_POLICY_DETAIL);
            setBindPolicyDetails(setProductStatusReq, policyDetailList);
            setProductStatusResp = serviceObj.updateProductStatus(setProductStatusReq);
        } catch (ManageProductsAIGCIExceptionTypeMsg e) {
            exceptionBO = new ExceptionBO();
            exceptionBO.setErrorFrom(NGEConstants.UPDATE_PRODUCT_STATUS);
            exceptionBO.setErrorMessage(seti18ErroMessage(e.getFaultInfo()
                    .getErrorCode()));
            exceptionBO.setErrorCode(NGEConstants.FAILURE_CODE);
            exceptionBO.setErrorType(e.getFaultInfo().getErrorType());
            logger.info("NGEUIException", e);
        } catch (MalformedURLException e) {
            exceptionBO = new ExceptionBO();
            exceptionBO.setErrorFrom(NGEConstants.UPDATE_PRODUCT_STATUS);
            exceptionBO.setErrorMessage(e.getMessage());
            exceptionBO.setErrorType(NGEConstants.FATAL);
            logger.info("NGEUIException", e);
        } catch (NumberFormatException e) {
            exceptionBO = new ExceptionBO();
            exceptionBO.setErrorFrom(NGEConstants.UPDATE_PRODUCT_STATUS);
            logger.info("NGEUIException", e);
            exceptionBO
                    .setErrorMessage(seti18ErroMessage(NGEConstants.ERROR_PROCESSING_REQUEST));
            exceptionBO.setErrorCode(NGEConstants.FAILURE_CODE);
            exceptionBO.setErrorType(NGEConstants.FATAL);
            logger.info("NGEUIException", e);
        } catch (Exception e) {
            exceptionBO = new ExceptionBO();
            exceptionBO.setErrorFrom(NGEConstants.UPDATE_PRODUCT_STATUS);
            exceptionBO
                    .setErrorMessage(seti18ErroMessage(NGEConstants.ERROR_INVOKING_SERVICE));
            exceptionBO.setErrorType(NGEConstants.FATAL);
            logger.info("NGEUIException", e);
        }
        if (null == exceptionBO) {
            session = request.getSession(false);
            session.setAttribute(NGEConstants.UPDATE_EVENT_REFRESH_PAGE, XSSValidator.stripXSS("true"));
            String responseCode = null;
            responseCode = validateStatusErrorMessage(setProductStatusResp.getCancelResponse(), responseCode);
            responseCode = validateStatusErrorMessage(setProductStatusResp.getDeclineResponse(), responseCode);
            responseCode = validateStatusErrorMessage(setProductStatusResp.getBindProductsResponse(), responseCode);
            responseCode = validateStatusErrorMessage(setProductStatusResp.getLostResponse(), responseCode);
            responseCode = validateStatusErrorMessage(setProductStatusResp.getQuoteProductsResponse(), responseCode);
            responseCode = validateStatusErrorMessage(setProductStatusResp.getVoidResponse(), responseCode);
            responseCode = validateStatusErrorMessage(setProductStatusResp.getWorkingResponse(), responseCode);
            if (responseCode != null && responseCode.equals(NGEConstants.PRODUCT_STATUS_UPDATE_SUCCESS)) {
                jsonHeaderBO = setJsonHeader(sequenceNo, NGEConstants.SUCCESS_CODE,
                        NGEConstants.SUCCESS,
                        NGEConstants.PRODUCT_STATUS_UPDATE_SUCCESS,
                        setProductStatusResp.getBindProductsResponse());
            } else {
                jsonHeaderBO = setJsonHeader(sequenceNo, NGEConstants.FAILURE_CODE,
                        NGEConstants.FAILURE,
                        seti18ErroMessage(responseCode),
                        setProductStatusResp);
            }
        } else {
            jsonHeaderBO = setJsonHeader(sequenceNo,
                    exceptionBO.getErrorCode(), exceptionBO.getErrorType(),
                    exceptionBO.getErrorMessage(), null);
        }
        return jsonHeaderBO;
    }

    void setBindPolicyDetails(SetProductStatusReqBO setProductStatusReq, List<PolicyDetailBO> policyDetailList) {
        if (setProductStatusReq.getBindProducts() != null && setProductStatusReq.getBindProducts().size() > 0) {
            if (policyDetailList != null && policyDetailList.size() > 0) {

                for (Iterator<PolicyDetailBO> policyDetailIter = policyDetailList.iterator(); policyDetailIter.hasNext(); ) {
                    PolicyDetailBO policyDetail = policyDetailIter.next();
                    if (policyDetail.getPolicytype().equalsIgnoreCase("PRIOR POLICY")) {
                        policyDetailIter.remove();
                    }
                }
                setProductStatusReq.getBindProducts().get(0).setPolicyDetail(policyDetailList);
            }
        }
    }

    String validateStatusErrorMessage(List<ProductRespTypeBO> prodResBO, String responseCode) {
        if (responseCode == null && prodResBO != null && prodResBO.size() > 0) {
            if (prodResBO.get(0).getMessage().getMessageCode().equalsIgnoreCase("000") ||
                    prodResBO.get(0).getMessage().getMessageCode().equalsIgnoreCase("SUCCESS")) {
                responseCode = NGEConstants.PRODUCT_STATUS_UPDATE_SUCCESS;
            } else {
                responseCode = prodResBO.get(0).getMessage().getMessageCode();
            }
        }
        return responseCode;
    }

    @RequestMapping(value = "/linkLicense", headers = "Accept=application/json", method = RequestMethod.POST)
    public @ResponseBody
    JSONHeaderBO linkLicense(@RequestBody LinkLicenseReqBO linkLicenseReqBo) {
        NGPLSService serviceObj = new NGPLSService();
        LinkLicenseRespBO licenseRespBO = null;
        ExceptionBO exceptionBO = null;
        JSONHeaderBO jsonHeaderBO = null;
        SequenceNumberGeneration generateObj = new SequenceNumberGeneration();
        HashMap<String, String> sequenceNames = new HashMap<>();
        HashMap<String, Object> sequenceValueMap = new HashMap<String, Object>();
        sequenceNames.put("LINK_LICENSCE", "INT");
        sequenceValueMap = generateObj.getNextSequenceNumber(sequenceNames);
        int sequenceNo = Integer.parseInt(sequenceValueMap.get(
                "LINK_LICENSCE").toString());
        try {
            linkLicenseReqBo.setUnderwritingSysCd(NGEConstants.NGPLS_UNDERWRITING_SYS_ID);
            linkLicenseReqBo.setDeleteInd(NGEConstants.NGPLS_DELETE_IND);
            linkLicenseReqBo.setRequestType(NGEConstants.NGPLS_REQ_TYPE);
            licenseRespBO = serviceObj.linkLicense(linkLicenseReqBo);
		} 
		/* March 20, 2022 - App Modernization Fix - Fetching the consumer side local WSDL & then hit the end point to consume the services. - Starts*/
		/*
			 * catch (MalformedURLException e) { exceptionBO = new ExceptionBO();
			 * exceptionBO.setErrorFrom(NGEConstants.LINK_LICENSE);
			 * exceptionBO.setErrorMessage(e.getMessage());
			 * exceptionBO.setErrorType(NGEConstants.FATAL); }
			 */ 
		/* March 20, 2022 - App Modernization Fix - Fetching the consumer side local WSDL & then hit the end point to consume the services. - Ends*/
		catch (AIGCIExceptionMsg e) {
            exceptionBO = new ExceptionBO();
            exceptionBO.setErrorFrom(NGEConstants.FIND_LICENSE);
            exceptionBO.setErrorMessage(seti18ErroMessage(e.getFaultInfo()
                    .getErrorCode()));
            exceptionBO.setErrorCode(NGEConstants.FAILURE_CODE);
            exceptionBO.setErrorType(e.getFaultInfo().getErrorType());
        } catch (ChartisInsuranceUSExceptionMsg e) {
            logger.info("Inside Service Exception");
            exceptionBO = new ExceptionBO();
            exceptionBO.setErrorFrom(NGEConstants.LINK_LICENSE);
            exceptionBO.setErrorMessage(seti18ErroMessage(e.getFaultInfo()
                    .getErrorCode()));
            exceptionBO.setErrorCode(NGEConstants.FAILURE_CODE);
            exceptionBO.setErrorType(NGEConstants.SERVICE_EXCEPTION);
        } catch (Exception e) {
            exceptionBO = new ExceptionBO();
            exceptionBO.setErrorFrom(NGEConstants.LINK_LICENSE);
            exceptionBO
                    .setErrorMessage(seti18ErroMessage(NGEConstants.ERROR_INVOKING_SERVICE));
            exceptionBO.setErrorType(NGEConstants.FATAL);
        }
		/*if(null!=licenseRespBO && null!=licenseRespBO.getErrorDetail()){
			logger.info("Inside Service Exception");
			exceptionBO = new ExceptionBO();
			exceptionBO.setErrorFrom(NGEConstants.FIND_AGENT);
			exceptionBO.setErrorMessage(seti18ErroMessage(licenseRespBO.getErrorDetail().getErrorDesc()));
			exceptionBO.setErrorCode(licenseRespBO.getErrorDetail().getErrorCd());
			exceptionBO.setErrorType(NGEConstants.FATAL);
		}*/
        if (exceptionBO != null) {
            jsonHeaderBO = setJsonHeader(sequenceNo,
                    exceptionBO.getErrorCode(), exceptionBO.getErrorType(),
                    exceptionBO.getErrorMessage(), null);
        } else {
            jsonHeaderBO = setJsonHeader(sequenceNo, NGEConstants.SUCCESS_CODE,
                    NGEConstants.SUCCESS, NGEConstants.PRODUCT_UPDATED,
                    licenseRespBO);
        }
        return jsonHeaderBO;
    }

    @RequestMapping(value = "/unbindProduct", headers = "Accept=application/json", method = RequestMethod.POST)
    public @ResponseBody
    JSONHeaderBO unbindProduct(@RequestBody UnBindProductReqBO unBindProductReq,
                               HttpServletRequest request, HttpServletResponse response) throws IOException {

        HttpSession session = null;
        session = request.getSession(false);
        JSONHeaderBO jsonHeaderBO = new JSONHeaderBO();
        if (session == null || (session.getAttribute(NGEConstants.SESSION_CASL_USERID) == null)) {
            //logger.info("Invalid Session : "+session);
            response.sendRedirect("jsp/logout.jsp");
            return jsonHeaderBO;
        }
		/*else{
			logger.info("session : "+session);
		}*/
        SubmissionManagementService serviceObj = new SubmissionManagementService();
        serviceObj.setCaslServiceId((String) session.getAttribute(NGEConstants.SESSION_CASL_USERID));
        UnBindProductRespBO unBindProductResp = new UnBindProductRespBO();
        ExceptionBO exceptionBO = null;
        SequenceNumberGeneration generateObj = new SequenceNumberGeneration();
        HashMap<String, String> sequenceNames = new HashMap<>();
        HashMap<String, Object> sequenceValueMap = new HashMap<String, Object>();
        sequenceNames.put("UNBIND_PRODUCT", "INT");
        sequenceValueMap = generateObj.getNextSequenceNumber(sequenceNames);
        int sequenceNo = Integer.parseInt(sequenceValueMap.get("UNBIND_PRODUCT").toString());

        try {
            unBindProductResp = serviceObj.unBindProduct(unBindProductReq);
        } catch (ManageProductsAIGCIExceptionTypeMsg e) {
            exceptionBO = new ExceptionBO();
            exceptionBO.setErrorFrom(NGEConstants.UNBIND_PRODUCT);
            exceptionBO.setErrorMessage(seti18ErroMessage(e.getFaultInfo()
                    .getErrorCode()));
            exceptionBO.setErrorCode(NGEConstants.FAILURE_CODE);
            exceptionBO.setErrorType(e.getFaultInfo().getErrorType());
            logger.info("NGEUIException", e);
        } catch (MalformedURLException e) {
            exceptionBO = new ExceptionBO();
            exceptionBO.setErrorFrom(NGEConstants.UNBIND_PRODUCT);
            exceptionBO.setErrorMessage(e.getMessage());
            exceptionBO.setErrorType(NGEConstants.FATAL);
            logger.info("NGEUIException", e);
        } catch (NumberFormatException e) {
            exceptionBO = new ExceptionBO();
            exceptionBO.setErrorFrom(NGEConstants.UNBIND_PRODUCT);
            logger.info("NGEUIException", e);
            exceptionBO
                    .setErrorMessage(seti18ErroMessage(NGEConstants.ERROR_PROCESSING_REQUEST));
            exceptionBO.setErrorCode(NGEConstants.FAILURE_CODE);
            exceptionBO.setErrorType(NGEConstants.FATAL);
            logger.info("NGEUIException", e);
        } catch (Exception e) {
            exceptionBO = new ExceptionBO();
            exceptionBO.setErrorFrom(NGEConstants.UPDATE_PRODUCT_STATUS);
            exceptionBO
                    .setErrorMessage(seti18ErroMessage(NGEConstants.ERROR_INVOKING_SERVICE));
            exceptionBO.setErrorType(NGEConstants.FATAL);
            logger.info("NGEUIException", e);
        }
        if (null == exceptionBO) {
            jsonHeaderBO = setJsonHeader(sequenceNo, NGEConstants.SUCCESS_CODE,
                    NGEConstants.SUCCESS,
                    NGEConstants.UPDATE_PRODUCT_STATUS_SUCCESSFUL,
                    unBindProductResp);
        } else {
            jsonHeaderBO = setJsonHeader(sequenceNo,
                    exceptionBO.getErrorCode(), exceptionBO.getErrorType(),
                    exceptionBO.getErrorMessage(), null);
        }
        return jsonHeaderBO;
    }

    @RequestMapping(value = "/unbindTransaction", headers = "Accept=application/json", method = RequestMethod.POST)
    public @ResponseBody
    JSONHeaderBO unbindTransaction(@RequestBody UnBindTransactionRequestBO unBindTransactionReq,
                                   HttpServletRequest request, HttpServletResponse response) throws IOException {

        HttpSession session = null;
        session = request.getSession(false);
        JSONHeaderBO jsonHeaderBO = new JSONHeaderBO();
        if (session == null || (session.getAttribute(NGEConstants.SESSION_CASL_USERID) == null)) {
            //logger.info("Invalid Session : "+session);
            response.sendRedirect("jsp/logout.jsp");
            return jsonHeaderBO;
        }
		/*else{
			logger.info("session : "+session);
		}*/
        SubmissionManagementService serviceObj = new SubmissionManagementService();
        serviceObj.setCaslServiceId((String) session.getAttribute(NGEConstants.SESSION_CASL_USERID));
        UnBindTransactionRespBO unBindTransactionResp = new UnBindTransactionRespBO();
        ExceptionBO exceptionBO = null;
        SequenceNumberGeneration generateObj = new SequenceNumberGeneration();
        HashMap<String, String> sequenceNames = new HashMap<>();
        HashMap<String, Object> sequenceValueMap = new HashMap<String, Object>();
        sequenceNames.put("UNBIND_TRANSACTION", "INT");
        sequenceValueMap = generateObj.getNextSequenceNumber(sequenceNames);
        int sequenceNo = Integer.parseInt(sequenceValueMap.get("UNBIND_TRANSACTION").toString());

        try {
            unBindTransactionResp = serviceObj.unBindTransaction(unBindTransactionReq);
        } catch (UpdateTransactionAIGCIExceptionTypeMsg e) {
            exceptionBO = new ExceptionBO();
            exceptionBO.setErrorFrom(NGEConstants.UNBIND_TRANSACTION);
            exceptionBO.setErrorMessage(seti18ErroMessage(e.getFaultInfo()
                    .getErrorCode()));
            exceptionBO.setErrorCode(NGEConstants.FAILURE_CODE);
            exceptionBO.setErrorType(e.getFaultInfo().getErrorType());
            logger.info("NGEUIException", e);
        } catch (MalformedURLException e) {
            exceptionBO = new ExceptionBO();
            exceptionBO.setErrorFrom(NGEConstants.UNBIND_TRANSACTION);
            exceptionBO.setErrorMessage(e.getMessage());
            exceptionBO.setErrorType(NGEConstants.FATAL);
            logger.info("NGEUIException", e);
        } catch (NumberFormatException e) {
            exceptionBO = new ExceptionBO();
            exceptionBO.setErrorFrom(NGEConstants.UNBIND_TRANSACTION);
            logger.info("NGEUIException", e);
            exceptionBO
                    .setErrorMessage(seti18ErroMessage(NGEConstants.ERROR_PROCESSING_REQUEST));
            exceptionBO.setErrorCode(NGEConstants.FAILURE_CODE);
            exceptionBO.setErrorType(NGEConstants.FATAL);
            logger.info("NGEUIException", e);
        } catch (Exception e) {
            exceptionBO = new ExceptionBO();
            exceptionBO.setErrorFrom(NGEConstants.UNBIND_TRANSACTION);
            exceptionBO
                    .setErrorMessage(seti18ErroMessage(NGEConstants.ERROR_INVOKING_SERVICE));
            exceptionBO.setErrorType(NGEConstants.FATAL);
            logger.info("NGEUIException", e);
        }
        if (null == exceptionBO) {
            jsonHeaderBO = setJsonHeader(sequenceNo, NGEConstants.SUCCESS_CODE,
                    NGEConstants.SUCCESS,
                    NGEConstants.UNBIND_TRANSACTION_STATUS_SUCCESSFUL,
                    unBindTransactionResp);
        } else {
            jsonHeaderBO = setJsonHeader(sequenceNo,
                    exceptionBO.getErrorCode(), exceptionBO.getErrorType(),
                    exceptionBO.getErrorMessage(), null);
        }
        return jsonHeaderBO;
    }


    @RequestMapping(value = "/reassignProduct", headers = "Accept=application/json", method = RequestMethod.POST)
    public @ResponseBody
    JSONHeaderBO reassignProduct(@RequestBody ReassignProdOwnerReqBO reassignProductReq,
                                 HttpServletRequest request, HttpServletResponse response) throws IOException {

        HttpSession session = null;
        session = request.getSession(false);
        JSONHeaderBO jsonHeaderBO = new JSONHeaderBO();
        if (session == null || (session.getAttribute(NGEConstants.SESSION_CASL_USERID) == null)) {
            //	logger.info("Invalid Session : "+session);
            response.sendRedirect("jsp/logout.jsp");
            return jsonHeaderBO;
        }
		/*else{
			logger.info("session : "+session);
		}*/
        SubmissionManagementService serviceObj = new SubmissionManagementService();
        serviceObj.setCaslServiceId((String) session.getAttribute(NGEConstants.SESSION_CASL_USERID));

        ReassignProductOwnerRespBO reassignProductResp = new ReassignProductOwnerRespBO();
        ExceptionBO exceptionBO = null;
        SequenceNumberGeneration generateObj = new SequenceNumberGeneration();
        HashMap<String, String> sequenceNames = new HashMap<>();
        HashMap<String, Object> sequenceValueMap = new HashMap<String, Object>();
        sequenceNames.put("REASSIGN_PRODUCT", "INT");
        sequenceValueMap = generateObj.getNextSequenceNumber(sequenceNames);
        int sequenceNo = Integer.parseInt(sequenceValueMap.get("REASSIGN_PRODUCT").toString());

        try {
            reassignProductResp = serviceObj.reassignProductOwner(reassignProductReq);
        } catch (ManageProductsAIGCIExceptionTypeMsg e) {
            exceptionBO = new ExceptionBO();
            exceptionBO.setErrorFrom(NGEConstants.REASSIGN_PRODUCT);
            exceptionBO.setErrorMessage(seti18ErroMessage(e.getFaultInfo()
                    .getErrorCode()));
            exceptionBO.setErrorCode(NGEConstants.FAILURE_CODE);
            exceptionBO.setErrorType(e.getFaultInfo().getErrorType());
            logger.info("NGEUIException", e);
        } catch (MalformedURLException e) {
            exceptionBO = new ExceptionBO();
            exceptionBO.setErrorFrom(NGEConstants.REASSIGN_PRODUCT);
            exceptionBO.setErrorMessage(e.getMessage());
            exceptionBO.setErrorType(NGEConstants.FATAL);
            logger.info("NGEUIException", e);
        } catch (NumberFormatException e) {
            exceptionBO = new ExceptionBO();
            exceptionBO.setErrorFrom(NGEConstants.REASSIGN_PRODUCT);
            logger.info("NGEUIException", e);
            exceptionBO
                    .setErrorMessage(seti18ErroMessage(NGEConstants.ERROR_PROCESSING_REQUEST));
            exceptionBO.setErrorCode(NGEConstants.FAILURE_CODE);
            exceptionBO.setErrorType(NGEConstants.FATAL);
            logger.info("NGEUIException", e);
        } catch (Exception e) {
            exceptionBO = new ExceptionBO();
            exceptionBO.setErrorFrom(NGEConstants.REASSIGN_PRODUCT_STATUS);
            exceptionBO
                    .setErrorMessage(seti18ErroMessage(NGEConstants.ERROR_INVOKING_SERVICE));
            exceptionBO.setErrorType(NGEConstants.FATAL);
            logger.info("NGEUIException", e);
        }
        if (null == exceptionBO) {
            jsonHeaderBO = setJsonHeader(sequenceNo, NGEConstants.SUCCESS_CODE,
                    NGEConstants.SUCCESS,
                    NGEConstants.REASSIGN_PRODUCT_STATUS_SUCCESSFUL,
                    reassignProductResp);
        } else {
            jsonHeaderBO = setJsonHeader(sequenceNo,
                    exceptionBO.getErrorCode(), exceptionBO.getErrorType(),
                    exceptionBO.getErrorMessage(), null);
        }
        return jsonHeaderBO;
    }

    @SuppressWarnings("unchecked")
    @RequestMapping(value = "/unBindTransactionReasons", headers = "Accept=application/json")
    public @ResponseBody
    List<Map<String, String>> getunBindTransactionReasons(HttpServletResponse response) {
        setCacheHeader(response);
        List<Map<String, String>> unBindTransactionReasons = new ArrayList<Map<String, String>>();
        DataCacheObject cacheObject = new DataCacheObject();
        Map<String, List<Map<String, String>>> reasonTypeMap = (Map<String, List<Map<String, String>>>) cacheObject
                .getDynacacheObj("REASON_TYPE_REASON_NAME_REASON_DESC_MAP");
        unBindTransactionReasons = reasonTypeMap.get("UNBIND");
        return unBindTransactionReasons;
    }

    public static String toDisplayCase(String s) {

        final String ACTIONABLE_DELIMITERS = " '-/,"; // these cause the character following
        // to be capitalized

        StringBuilder sb = new StringBuilder();
        boolean capNext = true;

        for (char c : s.toCharArray()) {
            c = (capNext)
                    ? Character.toUpperCase(c)
                    : Character.toLowerCase(c);
            sb.append(c);
            capNext = (ACTIONABLE_DELIMITERS.indexOf(c) >= 0); // explicit cast not needed
        }
        logger.info("User Name : " + sb.toString());
        return sb.toString();
    }

    /**
     * @param request
     */
    @RequestMapping(value = "/getTransactionProductAttribute", headers = "Accept=application/json", method = RequestMethod.POST)
    public @ResponseBody
    JSONHeaderBO getTransactionProductAttribute(HttpServletRequest request, @RequestBody ProductBO productBO) {
        ProductRespBO productRespBO = new ProductRespBO();
        JSONHeaderBO jsonHeaderBO = new JSONHeaderBO();
        ExceptionBO exceptionBO = null;
        SequenceNumberGeneration generateObj = new SequenceNumberGeneration();
        HashMap<String, String> sequenceNames = new HashMap<>();
        HashMap<String, Object> sequenceValueMap = new HashMap<String, Object>();
        sequenceNames.put("GET_TRAN_PROD_ATTR", "INT");
        sequenceValueMap = generateObj.getNextSequenceNumber(sequenceNames);
        int sequenceNo = Integer.parseInt(sequenceValueMap.get(
                "GET_TRAN_PROD_ATTR").toString());

        try {
            AddAdditionalAttributesHelper addAdditionalAttributesHelper = new AddAdditionalAttributesHelper();
            productRespBO = addAdditionalAttributesHelper.getRecurringAttribute(productBO);
        } catch (Exception e) {
            exceptionBO = new ExceptionBO();
            exceptionBO.setErrorFrom(NGEConstants.GET_TRANS_PROD_ATTR);
            exceptionBO
                    .setErrorMessage(seti18ErroMessage(NGEConstants.ERROR_INVOKING_SERVICE));
            exceptionBO.setErrorType(NGEConstants.FATAL);
            logger.info("NGEUIException", e);


        }
        if (null == exceptionBO) {
            jsonHeaderBO = setJsonHeader(sequenceNo, NGEConstants.SUCCESS_CODE,
                    NGEConstants.SUCCESS,
                    NGEConstants.GET_TRANS_PROD_ATTR,
                    productRespBO);
        } else {
            jsonHeaderBO = setJsonHeader(sequenceNo,
                    exceptionBO.getErrorCode(), exceptionBO.getErrorType(),
                    exceptionBO.getErrorMessage(), null);
        }
        return jsonHeaderBO;
    }

    @RequestMapping(value = "/bindTransaction", headers = "Accept=application/json", method = RequestMethod.POST)
    public @ResponseBody
    JSONHeaderBO bindTransaction(HttpServletRequest request, @RequestBody BindTransactionRequestBO bindTransactionRequestBO, HttpServletResponse response) throws IOException {
        HttpSession session = null;
        session = request.getSession(false);
        JSONHeaderBO jsonHeaderBO = new JSONHeaderBO();
        if (session == null || (session.getAttribute(NGEConstants.SESSION_CASL_USERID) == null)) {
            //logger.info("Invalid Session : "+session);
            response.sendRedirect("jsp/logout.jsp");
            return jsonHeaderBO;
        }
		/*else{
			logger.info("session : "+session);
		}*/
        SubmissionManagementService serviceObj = new SubmissionManagementService();
        serviceObj.setCaslServiceId((String) session.getAttribute(NGEConstants.SESSION_CASL_USERID));
        BindTransactionRespBO bindTransactionRespBO = new BindTransactionRespBO();
        ExceptionBO exceptionBO = null;
        SequenceNumberGeneration generateObj = new SequenceNumberGeneration();
        HashMap<String, String> sequenceNames = new HashMap<>();
        HashMap<String, Object> sequenceValueMap = new HashMap<String, Object>();
        sequenceNames.put("BIND_TRANSACTION", "INT");
        sequenceValueMap = generateObj.getNextSequenceNumber(sequenceNames);
        int sequenceNo = Integer.parseInt(sequenceValueMap.get(
                "BIND_TRANSACTION").toString());

        try {


            for (BindProductsRqBO bindProductsRqBO : bindTransactionRequestBO.getBindProducts()) {
                List<PolicyDetailBO> policyDetailList = (List<PolicyDetailBO>) session.getAttribute(NGEConstants.PRODUCT_POLICY_DETAIL);
                if (null != policyDetailList && !policyDetailList.isEmpty()) {
                    ManageTransactionServiceHandler.setBindTransactionPolicyDetails(bindTransactionRequestBO.getTransactionId(), bindTransactionRequestBO.getTransactionVersionNo(), bindProductsRqBO, policyDetailList);
                }
            }
            bindTransactionRespBO = serviceObj.bindTransaction(bindTransactionRequestBO);
        } catch (UpdateTransactionAIGCIExceptionTypeMsg e) {
            exceptionBO = new ExceptionBO();
            exceptionBO.setErrorFrom(NGEConstants.BIND_TRANSACTION_SERVICE);
            exceptionBO.setErrorMessage(seti18ErroMessage(e.getFaultInfo()
                    .getErrorCode()));
            exceptionBO.setErrorCode(NGEConstants.FAILURE_CODE);
            exceptionBO.setErrorType(e.getFaultInfo().getErrorType());
            logger.info("NGEUIException", e);
        } catch (MalformedURLException e) {
            exceptionBO = new ExceptionBO();
            exceptionBO.setErrorFrom(NGEConstants.BIND_TRANSACTION_SERVICE);
            exceptionBO.setErrorMessage(e.getMessage());
            exceptionBO.setErrorType(NGEConstants.FATAL);
        } catch (NumberFormatException e) {
            exceptionBO = new ExceptionBO();
            exceptionBO.setErrorFrom(NGEConstants.BIND_TRANSACTION_SERVICE);
            logger.info("NGEUIException", e);
            exceptionBO
                    .setErrorMessage(seti18ErroMessage(NGEConstants.ERROR_PROCESSING_REQUEST));
            exceptionBO.setErrorCode(NGEConstants.FAILURE_CODE);
            exceptionBO.setErrorType(NGEConstants.FATAL);
        } catch (Exception e) {
            exceptionBO = new ExceptionBO();
            exceptionBO.setErrorFrom(NGEConstants.BIND_TRANSACTION_SERVICE);
            exceptionBO
                    .setErrorMessage(seti18ErroMessage(NGEConstants.ERROR_INVOKING_SERVICE));
            exceptionBO.setErrorType(NGEConstants.FATAL);
        }
        if (null == exceptionBO) {

            jsonHeaderBO = setJsonHeader(sequenceNo, NGEConstants.SUCCESS_CODE,
                    NGEConstants.SUCCESS,
                    NGEConstants.TRANSACTION_BIND_SUCCESSFUL,
                    bindTransactionRespBO);
        } else {
            jsonHeaderBO = setJsonHeader(sequenceNo,
                    exceptionBO.getErrorCode(), exceptionBO.getErrorType(),
                    exceptionBO.getErrorMessage(), bindTransactionRespBO);
        }
        return jsonHeaderBO;
    }


    @RequestMapping(value = "/clearStartSubmission", headers = "Accept=application/json", method = RequestMethod.POST)
    public @ResponseBody
    JSONHeaderBO clearStartSubmissionSession(HttpServletRequest request) {
        logger.info("clear start submission session");
        HttpSession session = null;
        JSONHeaderBO jsonHeaderBO = new JSONHeaderBO();
        session = request.getSession(false);
        if (null != session) {
            if (null != session.getAttribute(NGEConstants.START_SUBMISSION)) {
                session.removeAttribute(NGEConstants.START_SUBMISSION);
            }
        }
        return jsonHeaderBO;
    }

    public CASLAuthorizeBO setUserprimaryactionforManager(CASLAuthorizeBO authorize) {
        ArrayList<String> useractionslist = new ArrayList<String>();
        if (null != authorize) {
            useractionslist = authorize.getActionList();
        }
        String useraction = "";
        if (null != useractionslist) {
            for (int i = 0; i < useractionslist.size(); ++i) {
                useraction = useractionslist.get(i);
			/*if ((useraction.equalsIgnoreCase(""))){
				authorize.setUserAction(useraction);
			}
			else*/
                if (useraction.equalsIgnoreCase(NGEConstants.CASL_NGE_ALL_MANAGER_FUNCTIONS_ACTION) && authorize != null) {
                    authorize.setUserAction(useraction);
                } else if (authorize != null && null == authorize.getUserAction() && useraction.equalsIgnoreCase(NGEConstants.CASL_NGE_ALL_RELEASE_PRODUCT_BLOCK_ACTION)) {
                    authorize.setUserAction(useraction);
                }
            }
        }
        return authorize;
    }

    public CASLAuthorizeBO setUserprimaryactionforUnderwriter(CASLAuthorizeBO authorize) {
        ArrayList<String> useractionslist = new ArrayList<String>();
        if (null != authorize) {
            useractionslist = authorize.getActionList();
        }
        String useraction = "";
        if (null != useractionslist) {
            for (int i = 0; i < useractionslist.size(); ++i) {
                useraction = useractionslist.get(i);
			/*if ((useraction.equalsIgnoreCase(""))){
				authorize.setUserAction(useraction);
			}
			else*/
                if (authorize != null && useraction.equalsIgnoreCase(NGEConstants.CASL_NGE_ALL_UNDERWRITER_FUNCTIONS_ACTION_CASL_NGE_UNDERWRITER_ROLE)) {
                    authorize.setUserAction(useraction);
                } else if ((authorize != null && (null == authorize.getUserAction() || authorize.getUserAction().equalsIgnoreCase(NGEConstants.CASL_NGE_VIEW_SUBMISSION_ACTION_CASL_NGE_UNDERWRITER_ROLE) || authorize.getUserAction().equalsIgnoreCase(NGEConstants.CASL_NGE_TRANSFER_UNDERWRITER_PORTFOLIO_ACTION_CASL_NGE_UNDERWRITER_ROLE)) && useraction.equalsIgnoreCase(NGEConstants.CASL_NGE_ADD_UPDATE_SUBMISSION_ACTION_CASL_NGE_UNDERWRITER_ROLE))) {
                    authorize.setUserAction(useraction);
                } else if ((authorize != null && (null == authorize.getUserAction() || authorize.getUserAction().equalsIgnoreCase(NGEConstants.CASL_NGE_TRANSFER_UNDERWRITER_PORTFOLIO_ACTION_CASL_NGE_UNDERWRITER_ROLE)) && useraction.equalsIgnoreCase(NGEConstants.CASL_NGE_VIEW_SUBMISSION_ACTION_CASL_NGE_UNDERWRITER_ROLE))) {
                    authorize.setUserAction(useraction);
                } else if (authorize != null && (null == authorize.getUserAction() && useraction.equalsIgnoreCase(NGEConstants.CASL_NGE_TRANSFER_UNDERWRITER_PORTFOLIO_ACTION_CASL_NGE_UNDERWRITER_ROLE))) {
                    authorize.setUserAction(useraction);
                }
            }
        }
        return authorize;
    }

    public CASLAuthorizeBO setUserprimaryactionforCenterAssitant(CASLAuthorizeBO authorize) {
        ArrayList<String> useractionslist = new ArrayList<String>();
        if (null != authorize) {
            useractionslist = authorize.getActionList();
        }
        String useraction = "";
        if (null != useractionslist) {
            for (int i = 0; i < useractionslist.size(); ++i) {
                useraction = useractionslist.get(i);
			/*if ((useraction.equalsIgnoreCase(""))){
				authorize.setUserAction(useraction);
			}
			else*/
                if (authorize != null && useraction.equalsIgnoreCase(NGEConstants.CASL_NGE_ALL_SC_ASST_FUNCTIONS_ACTION_NGE_SERVICE_CENTER_ASST)) {
                    authorize.setUserAction(useraction);
                } else if (authorize != null && (null == authorize.getUserAction() || authorize.getUserAction().equalsIgnoreCase(NGEConstants.CASL_NGE_VIEW_SUBMISSION_ACTION_NGE_SERVICE_CENTER_ASST)) && useraction.equalsIgnoreCase(NGEConstants.CASL_NGE_Create_Updt_Submn_ACTION_NGE_SERVICE_CENTER_ASST)) {
                    authorize.setUserAction(useraction);
                } else if (authorize != null && (null == authorize.getUserAction() && useraction.equalsIgnoreCase(NGEConstants.CASL_NGE_VIEW_SUBMISSION_ACTION_NGE_SERVICE_CENTER_ASST))) {
                    authorize.setUserAction(useraction);
                }
            }
        }
        return authorize;
    }

    public CASLAuthorizeBO setUserprimaryactionforAlertReleaser(CASLAuthorizeBO authorize) {
        ArrayList<String> useractionslist = new ArrayList<String>();
        if (null != authorize) {
            useractionslist = authorize.getActionList();
        }
        String useraction = "";
        if (null != useractionslist) {
            for (int i = 0; i < useractionslist.size(); ++i) {
                useraction = useractionslist.get(i);
			/*if ((useraction.equalsIgnoreCase(""))){
				authorize.setUserAction(useraction);
			}
			else*/
                if (authorize != null && useraction.equalsIgnoreCase(NGEConstants.CASL_NGE_RELEASE_ALERT_BLOCK_ACTION_ALERT_RELEASER)) {
                    authorize.setUserAction(useraction);
                }
            }
        }
        return authorize;
    }

    public CASLAuthorizeBO setUserprimaryactionforAlertReleaserEscalation(CASLAuthorizeBO authorize) {
        ArrayList<String> useractionslist = new ArrayList<String>();
        if (null != authorize) {
            useractionslist = authorize.getActionList();
        }
        String useraction = "";
        if (null != useractionslist) {
            for (int i = 0; i < useractionslist.size(); ++i) {
                useraction = useractionslist.get(i);
			/*if ((useraction.equalsIgnoreCase(""))){
				authorize.setUserAction(useraction);
			}
			else*/
                if (authorize != null && useraction.equalsIgnoreCase(NGEConstants.CASL_NGE_RELEASE_ALERT_BLOCK_ACTION_ALERT_RELEASER_ESCALATION)) {
                    authorize.setUserAction(useraction);
                }
            }
        }
        return authorize;
    }

    @RequestMapping(value = "/getScreenFieldMetaData", headers = "Accept=application/json")
	public @ResponseBody ScreenFieldMetaDataBO getScreenFieldMetaData(@RequestParam ("lan") String screenLanguage,HttpServletResponse response){
        setCacheHeader(response);
        DataCacheObject cacheObject = new DataCacheObject();
        String screenFieldMetaData = null;
        ScreenFieldMetaDataBO data = new ScreenFieldMetaDataBO();
        String screenFieldMetaDataLan = "SCREEN_FIELD_META_DATA";
        List<Map<String, String>> screenLanguagesMapList = null;
        Set<String> screenLanguageList = new HashSet<String>();
        try {
            /* Sep 2017 Maintenance Release 2.7 - Fix incorrect label issue in NGE UI - Starts */
            if (cacheObject.getDynacacheObj("SCREEN_LANGUAGES") != null) {
                screenLanguagesMapList = (List<Map<String, String>>) cacheObject.getDynacacheObj("SCREEN_LANGUAGES");
                if (screenLanguagesMapList != null && screenLanguagesMapList.size() > 0) {
                    for (Map<String, String> screenLanguagesMap : screenLanguagesMapList) {
                        screenLanguageList.addAll(screenLanguagesMap.keySet());
                    }
                    if (!screenLanguageList.contains(screenLanguage)) {
                        screenLanguage = "en-US";
                    }
                }
            }
            /* Sep 2017 Maintenance Release 2.7 - Fix incorrect label issue in NGE UI - End */
            screenFieldMetaDataLan = screenFieldMetaDataLan + screenLanguage;
            if (cacheObject.getDynacacheObj(screenFieldMetaDataLan) != null) {
                screenFieldMetaData = (String) cacheObject.getDynacacheObj(screenFieldMetaDataLan);
                data.setData(screenFieldMetaData);
            }

        } catch (Exception e) {
            e.printStackTrace();
            logger.info("NGEUIException", e);
            logger.error("Exception in getScreenFieldMetaData : " + e.getMessage());
        }
        return data;
    }

    @RequestMapping(value = "/setScreenLanguage", headers = "Accept=application/json")
	public @ResponseBody JSONHeaderBO setScreenLanguage(@RequestParam ("languageData") String  languageData,HttpServletRequest request
            , HttpServletResponse response) {
        setCacheHeader(response);
        HttpSession session = null;
        try {
            if (languageData == null || languageData.trim().length() == 0) {
                languageData = "en-US";
            }
            session = request.getSession(false);
            if (session != null) {
                session.setAttribute("USER_LANG", XSSValidator.stripXSS(languageData));
                //String fields=getScreenFieldMetaData(languageData);
            }
        } catch (Exception e) {
            logger.info("NGEUIException", e);
            logger.error("Exception in setScreenLanguage : " + e.getMessage());
        }
        return new JSONHeaderBO();
    }

    @SuppressWarnings("unchecked")
    @RequestMapping(value = "/getScreenLanguages", headers = "Accept=application/json")
	public @ResponseBody List<Map<String,String>> getScreenLanguages(HttpServletResponse response){
        setCacheHeader(response);
        DataCacheObject cacheObject = new DataCacheObject();
        List<Map<String, String>> screenLanguagesMapList = null;
        try {
            if (cacheObject.getDynacacheObj("SCREEN_LANGUAGES") != null) {
                screenLanguagesMapList = (List<Map<String, String>>) cacheObject.getDynacacheObj("SCREEN_LANGUAGES");
            }

        } catch (Exception e) {
            logger.info("NGEUIException", e);
            logger.error("Exception in getScreenLanguages : " + e.getMessage());
        }
        return screenLanguagesMapList;
    }
    public void setCacheHeader(HttpServletResponse response) {
        //long cacheAge=120;
        NGEProperties ngeProperties = new NGEProperties();
        try {
            String maxAge = ngeProperties.readMessageFromFile(NGEConstants.CACHE_MAX_AGE, NGEConstants.MESSAGE_FILE_NAME, true);
            response.setHeader("Cache-Control", "max-age=" + Long.valueOf(maxAge));
        } catch (Exception e) {
            logger.info("NGEUIException", e);
        }

    }

    /* Q1 2018 Maintenance Release - Add Shell Account Enhancement - Starts */
    @SuppressWarnings("unchecked")
    @RequestMapping(value = "/siccodeslist", headers = "Accept=application/json")
    public @ResponseBody
    List<Map<String, String>> getSicCodesList(HttpServletResponse response) {
        setCacheHeader(response);
        List<Map<String, String>> sicCodesList = new ArrayList<Map<String, String>>();
        DataCacheObject cacheObject = new DataCacheObject();
        sicCodesList = (List<Map<String, String>>) cacheObject
                .getDynacacheObj("SIC_CODES_LIST");
        return sicCodesList;
    }
    /* Q1 2018 Maintenance Release - Add Shell Account Enhancement - Ends */

    @SuppressWarnings("unchecked")
    @RequestMapping(value = NGEConstants.ServiceURL.GET_MAKE_MODEL_ASSET, headers = "Accept=application/json")
    public @ResponseBody
    Map<String, List<Map<String, String>>> getAssetAttribute(@RequestParam(value = "make", required = false) String makeAttributeId,
                                                             @RequestParam(value = "model", required = false) String modelAttributeId, @RequestParam(value = "assetTypeId", required = false) String attributeId, HttpServletResponse response) {
        setCacheHeader(response);
        DataCacheObject cacheObject = new DataCacheObject();
        AddAdditionalAttributesHelper attributeHelper = new AddAdditionalAttributesHelper();
        Map<String, List<Map<String, String>>> attributesMap = null;

        try {

            Map<String, List<Object>> assetAttributeMap = (Map<String, List<Object>>) cacheObject.getDynacacheObj("ASSET_ATTRIBUTE_MAPPING");
            if (attributeId != null && assetAttributeMap.get(attributeId) != null && assetAttributeMap.get(attributeId).size() == 4) {
                attributesMap = new HashMap<String, List<Map<String, String>>>();
                Map<String, List<String>> makeMapList = (Map<String, List<String>>) assetAttributeMap.get(attributeId).get(0);
                Map<String, List<String>> modelMapList = (Map<String, List<String>>) assetAttributeMap.get(attributeId).get(1);
                Map<String, Map<String, String>> makeRef = (Map<String, Map<String, String>>) assetAttributeMap.get(attributeId).get(2);
                Map<String, Map<String, String>> modelRef = (Map<String, Map<String, String>>) assetAttributeMap.get(attributeId).get(3);

                if (makeAttributeId == null && modelAttributeId == null) {

                    attributesMap.put(NGEConstants.AssetAttributes.MAKE.toLowerCase(), attributeHelper.mapToUIList(makeRef));
                    //	attributesMap.put(NGEConstants.AssetAttributes.MODEL.toLowerCase(), attributeHelper.mapToUIList(modelRef));
                } else if (modelAttributeId == null) {
                    attributesMap.put(NGEConstants.AssetAttributes.MODEL.toLowerCase(), attributeHelper.mapToUIList(modelRef));
                } else if (makeAttributeId.trim().length() == 0 && modelAttributeId.trim().length() == 0) {
                    if (makeRef.size() > 0 && modelRef.size() > 0) {

                        attributesMap.put(NGEConstants.AssetAttributes.MAKE.toLowerCase(), attributeHelper.mapToUIList(makeRef));
                        attributesMap.put(NGEConstants.AssetAttributes.MODEL.toLowerCase(), attributeHelper.mapToUIList(modelRef));
                    }
                } else if (makeAttributeId != null && makeAttributeId.trim().length() > 0) {
                    attributesMap.put(NGEConstants.AssetAttributes.MODEL.toLowerCase(), attributeHelper.getAttributeMapFromKey(makeAttributeId, makeMapList, modelRef));
                } else {
                    attributesMap.put(NGEConstants.AssetAttributes.MAKE.toLowerCase(), attributeHelper.getAttributeMapFromKey(modelAttributeId, modelMapList, makeRef));
                }
                //					 for(String attrName:attrNameList){
                //
                //						 if(assetTypeAttrMap.get(attrName)!=null){
                //
                //							 Object object=assetTypeAttrMap.get(attrName);
                //							 AttributeRefereceBOForUpdate attributeRefereceBOForUpdate=(AttributeRefereceBOForUpdate) objectReader.readValue(ow.writeValueAsString(object));
                //
                //							 attributesList.add(attributeRefereceBOForUpdate);
                //						 }
                //					 }
                // Collections.sort(attributesList,AttributeRefereceBOForUpdate.attributeRefereceBOForUpdateCompartor);
                return attributesMap;
            }
        } catch (Exception e) {
            // TODO Auto-generated catch block
            logger.info("NGEUIException", e);
        }
        return null;
    }

    /* MDM FindParty Changes Start*/
    /* 2021 MDM Changes - Starts */
    @RequestMapping(value = "/findMDMPartyDetails", headers = "Accept=application/json", method = RequestMethod.POST)
    public @ResponseBody
    JSONHeaderBO findMDMPartyDetails(@RequestBody MDMFindPartyReqBO mdmFindPartyRequest) throws AccountServiceExceptionMsg {
        MDMFindPartyResBO mdmFindPartyResponse = null;
        JSONHeaderBO jsonHeaderBO = new JSONHeaderBO();
        logger.info("findMDMPartyDetails : BEGIN");
        this.restTemplate = new RestTemplate();
        String reponseJSON = "";
        SequenceNumberGeneration generateObj = new SequenceNumberGeneration();
        HashMap<String, String> sequenceNames = new HashMap<>();
        HashMap<String, Object> sequenceValueMap = new HashMap<String, Object>();
        sequenceNames.put("FIND_MDM_ACCOUNT", "INT");
        sequenceValueMap = generateObj.getNextSequenceNumber(sequenceNames);
        int sequenceNo = Integer.parseInt(sequenceValueMap.get("FIND_MDM_ACCOUNT")
                .toString());
        String searchmode = "";
        String searchService = "";
        String mdmUrl = "";
        String requestJSON = "";
        String apiMethodLoggerName = "searchParty";
        try {
            NGEProperties ngeProperties = new NGEProperties();
				/* F56355 - Modify request parameter names for MDM services - starts */
				mdmFindPartyRequest.setOriginatingsystem(NGEConstants.APPLICATION_ID);
				/* F56355 - Modify request parameter names for MDM services - ends */
            searchmode = mdmFindPartyRequest.getSearchmode();

            String[] searchmodeArray = searchmode.split("-");

            mdmFindPartyRequest.setSearchmode(searchmodeArray[0]);
            if (searchmodeArray.length > 1) {
                searchService = searchmodeArray[1];
                if (searchmodeArray[1].equalsIgnoreCase(NGEConstants.SEARCH_SERVICE)) {
                    mdmUrl = ngeProperties.readMessageFromFile(NGEConstants.MDM_SEARCHPARTY_SERVICE_URL, NGEConstants.CONFIG_FILE_NAME, true);
                } else if (searchmodeArray[1].equalsIgnoreCase(NGEConstants.SUGGEST_SERVICE)) {
                    mdmUrl = ngeProperties.readMessageFromFile(NGEConstants.MDM_SUGGEST_SERVICE_URL, NGEConstants.CONFIG_FILE_NAME, true);
                    apiMethodLoggerName = "suggestParty";
                } else {
                    mdmUrl = ngeProperties.readMessageFromFile(NGEConstants.MDM_FINDPARTY_SERVICE_URL, NGEConstants.CONFIG_FILE_NAME, true);
                    apiMethodLoggerName = "findParty";
                }
            } else {
                mdmUrl = ngeProperties.readMessageFromFile(NGEConstants.MDM_FINDPARTY_SERVICE_URL, NGEConstants.CONFIG_FILE_NAME, true);
                apiMethodLoggerName = "findParty";
            }

            UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(mdmUrl);
            HttpHeaders requestHeader = setRequestHeader();

            ObjectMapper objectMapper = new ObjectMapper();

            requestJSON = objectMapper.writeValueAsString(mdmFindPartyRequest);

            HttpEntity<String> requestEntity = new HttpEntity<>(requestJSON, requestHeader);
            long startTime = System.currentTimeMillis();
			    ResponseEntity<MDMFindPartyResBO> responseEntity = this.restTemplate.exchange(builder.toUriString(), 
                    HttpMethod.POST, requestEntity, MDMFindPartyResBO.class);
            HttpStatus httpStatus = responseEntity.getStatusCode();

            long elapsedTime = System.currentTimeMillis() - startTime;
            if (httpStatus.series() == HttpStatus.Series.SUCCESSFUL) {
                logger.debug("STATUS OK!!");
                mdmFindPartyResponse = responseEntity.getBody();
                reponseJSON = objectMapper.writeValueAsString(mdmFindPartyResponse);

                if (mdmFindPartyResponse != null &&
                        mdmFindPartyResponse.getParties() != null &&
                        !mdmFindPartyResponse.getParties().isEmpty() &&  //If no parties, no call
                        searchService.equalsIgnoreCase(NGEConstants.SEARCH_SERVICE)) //Dont call for FUZZY
                {
                    List<String> accountNumberList = new ArrayList<String>();
                    for (Parties party : mdmFindPartyResponse.getParties()) {
                        accountNumberList.add(party.getAccountNumber());
                    }
                    SubmissionCountReqBO submissionCountReq = new SubmissionCountReqBO();
                    submissionCountReq.setGetSubmissionCountBy(NGEConstants.ACCOUNT);
                    submissionCountReq.setValues(accountNumberList);

                    Map<String, Integer> responseMap = getSubmissionCountByAccountNGE(submissionCountReq);
                    for (Parties party : mdmFindPartyResponse.getParties()) {
                        if (null != responseMap.get(party.getAccountNumber())) {
                            party.setSubmissionCount(responseMap.get(party.getAccountNumber()));
                        }
                    }
                    reponseJSON = objectMapper.writeValueAsString(mdmFindPartyResponse);
                }
            }
            logger.info(apiMethodLoggerName + " - MDM URL: " + mdmUrl + " ,requestJSON: " + requestJSON + " ,reponseJSON: " + reponseJSON + " , api call completed in: " +
                    elapsedTime + " milliseconds");
            jsonHeaderBO = setJsonHeader(sequenceNo, NGEConstants.SUCCESS_CODE,
                    NGEConstants.SUCCESS, NGEConstants.GET_ACCOUNT_SUCCESSFUL,
                    reponseJSON);

        } catch (Exception e) {
            logger.error(apiMethodLoggerName + " - MDM URL: " + mdmUrl + " ,requestJSON: " + requestJSON + " ,findMDMPartyDetails exception: " + e.getMessage());
            e.printStackTrace();
        }
        logger.info("findMDMPartyDetails :: END");
        return jsonHeaderBO;
    }
    /* 2021 MDM Changes - Ends */

    /* Submission Collection Changes Start*/
    public Map<String, Integer> getSubmissionCountByAccountNGE(SubmissionCountReqBO submissionCountReq) throws AccountServiceExceptionMsg {
        SubmissionCountResBO submissionCountRes = null;

        logger.info("getSubmissionCountByAccount : BEGIN");

        String reponseJSON = "";
        Map<String, Integer> responseMap = new HashMap<String, Integer>();

        try {
            NGEProperties ngeProperties = new NGEProperties();
            String submissionCountUrl = ngeProperties.readMessageFromFile(NGEConstants.NGE_SUBMISSION_COUNT_SERVICE_URL, NGEConstants.CONFIG_FILE_NAME, true);

            logger.debug("getSubmissionCountByAccount url: " + submissionCountUrl);
            UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(submissionCountUrl);
            HttpHeaders requestHeader = setRequestHeader();

            ObjectMapper objectMapper = new ObjectMapper();

            String requestJSON = objectMapper.writeValueAsString(submissionCountReq);
            logger.debug("requestJSON: " + requestJSON);

            HttpEntity<String> requestEntity = new HttpEntity<>(requestJSON, requestHeader);

			    ResponseEntity<SubmissionCountResBO> responseEntity = this.restTemplate.exchange(builder.toUriString(), 
                    HttpMethod.POST, requestEntity, SubmissionCountResBO.class);
            HttpStatus httpStatus = responseEntity.getStatusCode();

            if (httpStatus.series() == HttpStatus.Series.SUCCESSFUL) {
                logger.debug("STATUS OK!!");
                submissionCountRes = responseEntity.getBody();
                reponseJSON = objectMapper.writeValueAsString(submissionCountRes);
                //reponseJSON=objectMapper.writeValueAsString(responseEntity.getBody());
                logger.debug("requestJSON: " + requestJSON + " reponseJSON: " + reponseJSON);
                logger.debug("reponseJSON Direct: " + responseEntity.getBody());
                for (Response res : submissionCountRes.getResponse()) {
                    responseMap.put(res.getParty(), res.getSubmissionCount());
                }
            }

        } catch (Exception e) {

            logger.error("getSubmissionCountByAccount exception: " + e.getMessage());
            e.printStackTrace();
        }

        logger.info("getSubmissionCountByAccount :: END");
        return responseMap;
    }

    /* Submission Collection Changes Start*/
    @RequestMapping(value = "/getSubmissionCountByAccount", headers = "Accept=application/json", method = RequestMethod.POST)
    public @ResponseBody
    JSONHeaderBO getSubmissionCountByAccount(@RequestBody SubmissionCountReqBO submissionCountReq) throws AccountServiceExceptionMsg {
        SubmissionCountResBO submissionCountRes = null;
        JSONHeaderBO jsonHeaderBO = new JSONHeaderBO();
        logger.info("getSubmissionCountByAccount : BEGIN");
        this.restTemplate = new RestTemplate();
        String reponseJSON = "";
        SequenceNumberGeneration generateObj = new SequenceNumberGeneration();
        HashMap<String, String> sequenceNames = new HashMap<>();
        HashMap<String, Object> sequenceValueMap = new HashMap<String, Object>();
        sequenceNames.put("SUBMISSION_COUNT", "INT");
        sequenceValueMap = generateObj.getNextSequenceNumber(sequenceNames);
        int sequenceNo = Integer.parseInt(sequenceValueMap.get("SUBMISSION_COUNT")
                .toString());

        try {
            NGEProperties ngeProperties = new NGEProperties();
            String submissionCountUrl = ngeProperties.readMessageFromFile(NGEConstants.NGE_SUBMISSION_COUNT_SERVICE_URL, NGEConstants.CONFIG_FILE_NAME, true);

            logger.debug("getSubmissionCountByAccount url: " + submissionCountUrl);
            UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(submissionCountUrl);
            HttpHeaders requestHeader = setRequestHeader();

            ObjectMapper objectMapper = new ObjectMapper();

            String requestJSON = objectMapper.writeValueAsString(submissionCountReq);
            logger.debug("requestJSON: " + requestJSON);

            HttpEntity<String> requestEntity = new HttpEntity<>(requestJSON, requestHeader);

			    ResponseEntity<SubmissionCountResBO> responseEntity = this.restTemplate.exchange(builder.toUriString(), 
                    HttpMethod.POST, requestEntity, SubmissionCountResBO.class);
            HttpStatus httpStatus = responseEntity.getStatusCode();

            if (httpStatus.series() == HttpStatus.Series.SUCCESSFUL) {
                logger.debug("STATUS OK!!");
                submissionCountRes = responseEntity.getBody();
                reponseJSON = objectMapper.writeValueAsString(submissionCountRes);
                //reponseJSON=objectMapper.writeValueAsString(responseEntity.getBody());
                logger.debug("requestJSON: " + requestJSON + " reponseJSON: " + reponseJSON);
                logger.debug("reponseJSON Direct: " + responseEntity.getBody());
            }

            jsonHeaderBO = setJsonHeader(sequenceNo, NGEConstants.SUCCESS_CODE,
                    NGEConstants.SUCCESS, NGEConstants.GET_ACCOUNT_SUCCESSFUL,
                    reponseJSON);

        } catch (Exception e) {

            logger.error("getSubmissionCountByAccount exception: " + e.getMessage());
            e.printStackTrace();
        }
        logger.info("getSubmissionCountByAccount :: END");
        return jsonHeaderBO;
    }

    /* Submission Collection Changes Start*/
    @RequestMapping(value = "/getSubmissionCollection", headers = "Accept=application/json", method = RequestMethod.POST)
    public @ResponseBody
    JSONHeaderBO getSubmissionCollection(@RequestBody SubmissionCollectionReqBO submissionCollectionReqBO) throws AccountServiceExceptionMsg {
        SubmissionCollectiontResBO submissionCollectiontResBO = null;
        JSONHeaderBO jsonHeaderBO = new JSONHeaderBO();
        logger.info("getSubmissionCollection : BEGIN");
        this.restTemplate = new RestTemplate();
        String reponseJSON = "";
        SequenceNumberGeneration generateObj = new SequenceNumberGeneration();
        HashMap<String, String> sequenceNames = new HashMap<>();
        HashMap<String, Object> sequenceValueMap = new HashMap<String, Object>();
        sequenceNames.put("SUBMISSION_COLLECTION", "INT");
        sequenceValueMap = generateObj.getNextSequenceNumber(sequenceNames);
        int sequenceNo = Integer.parseInt(sequenceValueMap.get("SUBMISSION_COLLECTION")
                .toString());

        try {
            NGEProperties ngeProperties = new NGEProperties();
            String submissionCollectionUrl = ngeProperties.readMessageFromFile(NGEConstants.NGE_SUBMISSION_DETAILS_SERVICE_URL, NGEConstants.CONFIG_FILE_NAME, true);

            logger.debug("getSubmissionCollection url: " + submissionCollectionUrl);
            UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(submissionCollectionUrl);
            HttpHeaders requestHeader = setRequestHeader();

            ObjectMapper objectMapper = new ObjectMapper();

            String requestJSON = objectMapper.writeValueAsString(submissionCollectionReqBO);
            logger.debug("requestJSON: " + requestJSON);

            HttpEntity<String> requestEntity = new HttpEntity<>(requestJSON, requestHeader);

			    ResponseEntity<SubmissionCollectiontResBO> responseEntity = this.restTemplate.exchange(builder.toUriString(), 
                    HttpMethod.POST, requestEntity, SubmissionCollectiontResBO.class);
            HttpStatus httpStatus = responseEntity.getStatusCode();

            if (httpStatus.series() == HttpStatus.Series.SUCCESSFUL) {
                logger.debug("STATUS OK!!");
                submissionCollectiontResBO = responseEntity.getBody();
                reponseJSON = objectMapper.writeValueAsString(submissionCollectiontResBO);
                //reponseJSON=objectMapper.writeValueAsString(responseEntity.getBody());
                logger.debug("requestJSON: " + requestJSON + " reponseJSON: " + reponseJSON);
                logger.debug("reponseJSON Direct: " + responseEntity.getBody());
            }

            jsonHeaderBO = setJsonHeader(sequenceNo, NGEConstants.SUCCESS_CODE,
                    NGEConstants.SUCCESS, NGEConstants.GET_ACCOUNT_SUCCESSFUL,
                    reponseJSON);

        } catch (Exception e) {

            logger.error("getSubmissionCollectionByAccount exception: " + e.getMessage());
            e.printStackTrace();
        }
        logger.info("getSubmissionCollection :: END");
        return jsonHeaderBO;
    }

    /* 2021 MDM Changes - Starts */
    private HttpHeaders setRequestHeader() {
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        headers.setContentType(MediaType.APPLICATION_JSON);
        // MDM Adding Auth_Key Included in Header - Starts
        String authHeader = "";
        String authKey = "";
        try {
            NGEProperties ngeProperties = new NGEProperties();
            authHeader = ngeProperties.readMessageFromFile(NGEConstants.MDM_HEADER_AUTH, NGEConstants.CONFIG_FILE_NAME, true);
            authKey = ngeProperties.readMessageFromFile(NGEConstants.MDM_API_AUTH_TOKEN, NGEConstants.CONFIG_FILE_NAME, true);
            if ((null != authHeader && !authHeader.isEmpty()) && (null != authKey && !authKey.isEmpty())) {
                headers.set(authHeader, authKey);
            }
            logger.debug("authHeader: " + authHeader);
            logger.debug("authKey Token: " + authKey);
        } catch (Exception e) {
            logger.error("authKey exception: " + e.getMessage());
            e.printStackTrace();
        }
        // MDM Adding Auth_Key Included in Header - Ends
        return headers;
    }
    /* 2021 MDM Changes - Ends */
    /*July 2021 Q3 MDM Integration 2.27 -	Integrate MDM Services - Ends*/
}
