package com.aig.nge.bo;

import java.util.List;

//POJO bean to hold the ticker related fields
public class SubmissionTickerDataBO {
	
	List<SubmissionTickerInfo> tickerList;
	private String feedDs;
	public String getFeedDs() {
		return feedDs;
	}
	public void setFeedDs(String feedDs) {
		this.feedDs = feedDs;
	}
	
	public List<SubmissionTickerInfo> getTickerList() {
		return tickerList;
	}
	public void setTickerList(List<SubmissionTickerInfo> tickerList) {
		this.tickerList = tickerList;
	}
}
