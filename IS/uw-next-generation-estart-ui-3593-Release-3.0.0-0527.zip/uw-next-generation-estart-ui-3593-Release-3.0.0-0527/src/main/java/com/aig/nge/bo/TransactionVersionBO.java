package com.aig.nge.bo;

import java.util.List;

public class TransactionVersionBO {
	
	private String transactionVersionNo;
	private String lifecycleStatusCd;
	private String lifeCycleStatusNm;
	private String boundIn;
	private String lockIn;
	private List<AttributesInfoBO> attributesInfo;
	private List<AdditionalInsuredBO> additionalInsuredDet;
	private List<AdditionalProducerBO> additionalProducerDet;
	private ProductsBO productDet;
	private List<AttributesInfoUpdBO> attributesInfoUpdate;
	
	
	/**
	 * @return the attributesInfoUpdate
	 */
	public List<AttributesInfoUpdBO> getAttributesInfoUpdate() {
		return attributesInfoUpdate;
	}
	/**
	 * @param attributesInfoUpdate the attributesInfoUpdate to set
	 */
	public void setAttributesInfoUpdate(
			List<AttributesInfoUpdBO> attributesInfoUpdate) {
		this.attributesInfoUpdate = attributesInfoUpdate;
	}
	public String getTransactionVersionNo() {
		return transactionVersionNo;
	}
	public void setTransactionVersionNo(String transactionVersionNo) {
		this.transactionVersionNo = transactionVersionNo;
	}
	public String getLifecycleStatusCd() {
		return lifecycleStatusCd;
	}
	public void setLifecycleStatusCd(String lifecycleStatusCd) {
		this.lifecycleStatusCd = lifecycleStatusCd;
	}
	public String getLifeCycleStatusNm() {
		return lifeCycleStatusNm;
	}
	public void setLifeCycleStatusNm(String lifeCycleStatusNm) {
		this.lifeCycleStatusNm = lifeCycleStatusNm;
	}
	public String getBoundIn() {
		return boundIn;
	}
	public void setBoundIn(String boundIn) {
		this.boundIn = boundIn;
	}
	public List<AttributesInfoBO> getAttributesInfo() {
		return attributesInfo;
	}
	public void setAttributesInfo(List<AttributesInfoBO> attributesInfo) {
		this.attributesInfo = attributesInfo;
	}
	public List<AdditionalInsuredBO> getAdditionalInsuredDet() {
		return additionalInsuredDet;
	}
	public void setAdditionalInsuredDet(List<AdditionalInsuredBO> additionalInsuredDet) {
		this.additionalInsuredDet = additionalInsuredDet;
	}
	public List<AdditionalProducerBO> getAdditionalProducerDet() {
		return additionalProducerDet;
	}
	public void setAdditionalProducerDet(List<AdditionalProducerBO> additionalProducerDet) {
		this.additionalProducerDet = additionalProducerDet;
	}
	public ProductsBO getProductDet() {
		return productDet;
	}
	public void setProductDet(ProductsBO productDet) {
		this.productDet = productDet;
	}
	public String getLockIn() {
		return lockIn;
	}
	public void setLockIn(String lockIn) {
		this.lockIn = lockIn;
	}
	

}
