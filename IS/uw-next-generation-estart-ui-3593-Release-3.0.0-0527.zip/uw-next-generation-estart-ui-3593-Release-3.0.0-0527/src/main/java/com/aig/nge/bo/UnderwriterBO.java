package com.aig.nge.bo;

public class UnderwriterBO {
	
	private String underwriterId;
	private String firstName;
	private String middleName;
	private String lastName;
	private String emailAddressTx;
	private String contactNo;
	private String alternateContactNo;
	private String emailiconalertBlock;
	private String emailiconproductBlock;
	
	public String getUnderwriterId() {
		return underwriterId;
	}
	public void setUnderwriterId(String underwriterId) {
		this.underwriterId = underwriterId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getMiddleName() {
		return middleName;
	}
	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getEmailAddressTx() {
		return emailAddressTx;
	}
	public void setEmailAddressTx(String emailAddressTx) {
		this.emailAddressTx = emailAddressTx;
	}
	public String getContactNo() {
		return contactNo;
	}
	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}
	public String getAlternateContactNo() {
		return alternateContactNo;
	}
	public void setAlternateContactNo(String alternateContactNo) {
		this.alternateContactNo = alternateContactNo;
	}
	public String getEmailiconalertBlock() {
		return emailiconalertBlock;
	}
	public void setEmailiconalertBlock(String emailiconalertBlock) {
		this.emailiconalertBlock = emailiconalertBlock;
	}
	public String getEmailiconproductBlock() {
		return emailiconproductBlock;
	}
	public void setEmailiconproductBlock(String emailiconproductBlock) {
		this.emailiconproductBlock = emailiconproductBlock;
	}
	
	
	
	

}
