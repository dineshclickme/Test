package com.aig.nge.bo;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL) 
public class SubmissionCountReqBO {
	
	private String getSubmissionCountBy;
	private List<String> values;
	public String getGetSubmissionCountBy() {
		return getSubmissionCountBy;
	}
	public void setGetSubmissionCountBy(String getSubmissionCountBy) {
		this.getSubmissionCountBy = getSubmissionCountBy;
	}
	public List<String> getValues() {
		return values;
	}
	public void setValues(List<String> values) {
		this.values = values;
	}
		
}
