package com.aig.nge.aop;

import java.util.Arrays;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.jpa.JpaSystemException;
import org.springframework.stereotype.Component;

import com.aig.nge.utilities.NGEErrorCodes;
import com.aig.nge.utilities.NGEException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;


/**
 * @author Dineshkumar 
 * 09-Jan-2015 
 * This is AOP(Aspect Oriented Programming) class used
 * for logging the exception flows and method execution flows
 */
@Component
@Aspect
public class LoggingAspect {
	//TCS CE Team Changes Starts Here
	private static final Logger logger = LogManager.getLogger(LoggingAspect.class);
	//TCS CE Team Changes Ends Here
	
	@Autowired
	private NGEException ngeException;

	/**
	 * @param joinPoint
	 * @throws Throwable
	 * This method used for log the all methods execution under the com.aig package
	 * This AOP method is used for logging the different methods with different 
	 * data types so currently this method return type made as Object 
	 */
	@Around("execution(* com.aig..*(..))")
	public Object log(ProceedingJoinPoint joinPoint) throws Throwable {
		String packageName = joinPoint.getSignature().getDeclaringTypeName();
		String methodName = joinPoint.getSignature().getName();

		long start = System.currentTimeMillis();

		logger.info("Entering method [" + packageName + "." + methodName + "]");
		logger.info(" arguments : " + Arrays.toString(joinPoint.getArgs()));

		Object result = null;
		try {
			result  = joinPoint.proceed();
		} catch (JpaSystemException e) {
			logger.debug(e.getMessage());
			ngeException.throwException(NGEErrorCodes.JPA_EXCEPTION, NGEErrorCodes.ERROR_TYPE,
					e.getMessage(), null);
		}
		long elapsedTime = System.currentTimeMillis() - start;
		logger.info("Exiting method [" + packageName + "." + methodName
				+ "]; exec time (ms): " + elapsedTime);
		return result;

	}

	@AfterThrowing(pointcut = "execution(* com.aig..*(..))", throwing = "error")
	public void logAfterThrowing(JoinPoint joinPoint, Throwable error) {

		String packageName = joinPoint.getSignature().getDeclaringTypeName();
		String methodName = joinPoint.getSignature().getName();
		logger.error("Exception Occured [" + packageName + "." + methodName
				+ "]");
		logger.error("Exception : " + error);
		

	}

}