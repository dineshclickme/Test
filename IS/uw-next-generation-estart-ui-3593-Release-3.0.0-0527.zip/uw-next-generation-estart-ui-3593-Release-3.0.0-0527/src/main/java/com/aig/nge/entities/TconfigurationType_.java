package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SetAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-04-15T15:31:46.807+0530")
@StaticMetamodel(TconfigurationType.class)
public class TconfigurationType_ {
	public static volatile SingularAttribute<TconfigurationType, Short> configurationTypeId;
	public static volatile SingularAttribute<TconfigurationType, String> configurationTypeDs;
	public static volatile SingularAttribute<TconfigurationType, Timestamp> createTs;
	public static volatile SingularAttribute<TconfigurationType, String> createUserId;
	public static volatile SingularAttribute<TconfigurationType, Timestamp> updateTs;
	public static volatile SingularAttribute<TconfigurationType, String> updateUserId;
	public static volatile SetAttribute<TconfigurationType, TproductTowerConfiguration> tproductTowerConfigurations;
}
