package com.aig.nge.bo;


public class GetAccountRequestDataBO {
    private String searchNumber;
    private String brokerId;
    private String isFeinRequired;
    private String searchCountryCode;
    private SearchTypeBO seachType;
	/**
	 * @return the searchNumber
	 */
	public String getSearchNumber() {
		return searchNumber;
	}
	/**
	 * @param searchNumber the searchNumber to set
	 */
	public void setSearchNumber(String searchNumber) {
		this.searchNumber = searchNumber;
	}
	/**
	 * @return the brokerId
	 */
	public String getBrokerId() {
		return brokerId;
	}
	/**
	 * @param brokerId the brokerId to set
	 */
	public void setBrokerId(String brokerId) {
		this.brokerId = brokerId;
	}
	/**
	 * @return the isFeinRequired
	 */
	public String getIsFeinRequired() {
		return isFeinRequired;
	}
	/**
	 * @param isFeinRequired the isFeinRequired to set
	 */
	public void setIsFeinRequired(String isFeinRequired) {
		this.isFeinRequired = isFeinRequired;
	}
	/**
	 * @return the searchCountryCode
	 */
	public String getSearchCountryCode() {
		return searchCountryCode;
	}
	/**
	 * @param searchCountryCode the searchCountryCode to set
	 */
	public void setSearchCountryCode(String searchCountryCode) {
		this.searchCountryCode = searchCountryCode;
	}
	/**
	 * @return the seachType
	 */
	public SearchTypeBO getSeachType() {
		return seachType;
	}
	/**
	 * @param seachType the seachType to set
	 */
	public void setSeachType(SearchTypeBO seachType) {
		this.seachType = seachType;
	}
}
