package com.aig.nge.bo;

import java.util.List;

public class SubmissionRespUIBO {
	
	private SubmissionBO submission;
	private TransactionListBO transactionList;
	private List<TransactionForGetSubmissionBO> transaction;
	private List<ProductForGetSubmissionBO> product;
	private List<ComponentForGetSubmissionBO> component;
	private List<ComponentListForGetSubmissionBO> componentList;
	private List<AdditionalInsuredJSONBO> additionalInsured;
	private List<AdditionalInsuredJSONBO> additionalInsuredTransaction;
	private List<PolicyDetailsJSONBO> policyDetails;
	private List<AssetDetailsJSONBO> assetDetails;
	private List<AccountMailingAddressJSONBO> accountmailingaddress;
	private List<ProducerIndividualContactDetailsJSONBO> producerIndividual;
	private List<AdditionalProducersJSONBO> additionalProducer;
	private List<ExposureCountryBO> exposureCountryBO;
	List<ExpiringProductJSONBO> expiringProduct;
	public List<ExpiringProductJSONBO> getExpiringProduct() {
		return expiringProduct;
	}
	public void setExpiringProduct(List<ExpiringProductJSONBO> expiringProduct) {
		this.expiringProduct = expiringProduct;
	}
	public List<AdditionalProducersJSONBO> getAdditionalProducer() {
		return additionalProducer;
	}
	public void setAdditionalProducer(
			List<AdditionalProducersJSONBO> additionalProducer) {
		this.additionalProducer = additionalProducer;
	}
	public SubmissionBO getSubmission() {
		return submission;
	}
	public void setSubmission(SubmissionBO submission) {
		this.submission = submission;
	}
	public TransactionListBO getTransactionList() {
		return transactionList;
	}
	public void setTransactionList(TransactionListBO transactionList) {
		this.transactionList = transactionList;
	}
	public List<TransactionForGetSubmissionBO> getTransaction() {
		return transaction;
	}
	public void setTransaction(List<TransactionForGetSubmissionBO> transaction) {
		this.transaction = transaction;
	}
	public List<ProductForGetSubmissionBO> getProduct() {
		return product;
	}
	public void setProduct(List<ProductForGetSubmissionBO> product) {
		this.product = product;
	}
	public List<ComponentForGetSubmissionBO> getComponent() {
		return component;
	}
	public void setComponent(List<ComponentForGetSubmissionBO> component) {
		this.component = component;
	}
	public List<ComponentListForGetSubmissionBO> getComponentList() {
		return componentList;
	}
	public void setComponentList(List<ComponentListForGetSubmissionBO> componentList) {
		this.componentList = componentList;
	}
	/**
	 * @return the additionalInsured
	 */
	public List<AdditionalInsuredJSONBO> getAdditionalInsured() {
		return additionalInsured;
	}
	/**
	 * @param additionalInsured the additionalInsured to set
	 */
	public void setAdditionalInsured(List<AdditionalInsuredJSONBO> additionalInsured) {
		this.additionalInsured = additionalInsured;
	}
	/**
	 * @return the policyDetails
	 */
	public List<PolicyDetailsJSONBO> getPolicyDetails() {
		return policyDetails;
	}
	/**
	 * @param policyDetails the policyDetails to set
	 */
	public void setPolicyDetails(List<PolicyDetailsJSONBO> policyDetails) {
		this.policyDetails = policyDetails;
	}
	/**
	 * @return the assetDetails
	 */
	public List<AssetDetailsJSONBO> getAssetDetails() {
		return assetDetails;
	}
	/**
	 * @param assetDetails the assetDetails to set
	 */
	public void setAssetDetails(List<AssetDetailsJSONBO> assetDetails) {
		this.assetDetails = assetDetails;
	}
	public List<AccountMailingAddressJSONBO> getAccountmailingaddress() {
		return accountmailingaddress;
	}
	public void setAccountmailingaddress(
			List<AccountMailingAddressJSONBO> accountmailingaddress) {
		this.accountmailingaddress = accountmailingaddress;
	}
	public List<ProducerIndividualContactDetailsJSONBO> getProducerIndividual() {
		return producerIndividual;
	}
	public void setProducerIndividual(
			List<ProducerIndividualContactDetailsJSONBO> producerIndividual) {
		this.producerIndividual = producerIndividual;
	}
	public List<AdditionalInsuredJSONBO> getAdditionalInsuredTransaction() {
		return additionalInsuredTransaction;
	}
	public void setAdditionalInsuredTransaction(
			List<AdditionalInsuredJSONBO> additionalInsuredTransaction) {
		this.additionalInsuredTransaction = additionalInsuredTransaction;
	}
	public List<ExposureCountryBO> getExposureCountryBO() {
		return exposureCountryBO;
	}
	public void setExposureCountryBO(List<ExposureCountryBO> exposureCountryBO) {
		this.exposureCountryBO = exposureCountryBO;
	}

	

}
