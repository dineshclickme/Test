package com.aig.nge.bo;

import java.util.List;

public class ReserveProductsRsBO {

	private String transactionId;
    private String transactionVersionNo;
    private String segmentCd;
    private String subSegmentCd;
    private String marketableProductCd;
    private String componentProductCd;
    private String attachmentPointAmt;
    private String lifeCycleStatusCd;
    private String reservationStatus;
    private List<BlockComponentProductBO> productBlocks;
    private AlertBlockDetailsBO alertBlockDetails;
    protected NGEViewOfMessageBO message;
	/**
	 * @return the transactionId
	 */
	public String getTransactionId() {
		return transactionId;
	}
	/**
	 * @param transactionId the transactionId to set
	 */
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	/**
	 * @return the transactionVersionNo
	 */
	public String getTransactionVersionNo() {
		return transactionVersionNo;
	}
	/**
	 * @param transactionVersionNo the transactionVersionNo to set
	 */
	public void setTransactionVersionNo(String transactionVersionNo) {
		this.transactionVersionNo = transactionVersionNo;
	}
	/**
	 * @return the segmentCd
	 */
	public String getSegmentCd() {
		return segmentCd;
	}
	/**
	 * @param segmentCd the segmentCd to set
	 */
	public void setSegmentCd(String segmentCd) {
		this.segmentCd = segmentCd;
	}
	/**
	 * @return the subSegmentCd
	 */
	public String getSubSegmentCd() {
		return subSegmentCd;
	}
	/**
	 * @param subSegmentCd the subSegmentCd to set
	 */
	public void setSubSegmentCd(String subSegmentCd) {
		this.subSegmentCd = subSegmentCd;
	}
	/**
	 * @return the marketableProductCd
	 */
	public String getMarketableProductCd() {
		return marketableProductCd;
	}
	/**
	 * @param marketableProductCd the marketableProductCd to set
	 */
	public void setMarketableProductCd(String marketableProductCd) {
		this.marketableProductCd = marketableProductCd;
	}
	/**
	 * @return the componentProductCd
	 */
	public String getComponentProductCd() {
		return componentProductCd;
	}
	/**
	 * @param componentProductCd the componentProductCd to set
	 */
	public void setComponentProductCd(String componentProductCd) {
		this.componentProductCd = componentProductCd;
	}
	/**
	 * @return the attachmentPointAmt
	 */
	public String getAttachmentPointAmt() {
		return attachmentPointAmt;
	}
	/**
	 * @param attachmentPointAmt the attachmentPointAmt to set
	 */
	public void setAttachmentPointAmt(String attachmentPointAmt) {
		this.attachmentPointAmt = attachmentPointAmt;
	}
	/**
	 * @return the lifeCycleStatusCd
	 */
	public String getLifeCycleStatusCd() {
		return lifeCycleStatusCd;
	}
	/**
	 * @param lifeCycleStatusCd the lifeCycleStatusCd to set
	 */
	public void setLifeCycleStatusCd(String lifeCycleStatusCd) {
		this.lifeCycleStatusCd = lifeCycleStatusCd;
	}
	/**
	 * @return the reservationStatus
	 */
	public String getReservationStatus() {
		return reservationStatus;
	}
	/**
	 * @param reservationStatus the reservationStatus to set
	 */
	public void setReservationStatus(String reservationStatus) {
		this.reservationStatus = reservationStatus;
	}
	/**
	 * @return the productBlocks
	 */
	public List<BlockComponentProductBO> getProductBlocks() {
		return productBlocks;
	}
	/**
	 * @param productBlocks the productBlocks to set
	 */
	public void setProductBlocks(List<BlockComponentProductBO> productBlocks) {
		this.productBlocks = productBlocks;
	}
	/**
	 * @return the alertBlockDetails
	 */
	public AlertBlockDetailsBO getAlertBlockDetails() {
		return alertBlockDetails;
	}
	/**
	 * @param alertBlockDetails the alertBlockDetails to set
	 */
	public void setAlertBlockDetails(AlertBlockDetailsBO alertBlockDetails) {
		this.alertBlockDetails = alertBlockDetails;
	}
	public NGEViewOfMessageBO getMessage() {
		return message;
	}
	public void setMessage(NGEViewOfMessageBO message) {
		this.message = message;
	}
    
    
}
