package com.aig.nge.bo;


public class LicenseBO {
    private String licenseNo;
    private String licenseNm;
    private String typeCd;
    private String stateCd;
    private String stateNm;
    private String statusCd;
    private String statusNm;
    private String lineOfBusinessCd;
    private String lineOfBusinessNm;
	/**
	 * @return the licenseNo
	 */
	public String getLicenseNo() {
		return licenseNo;
	}
	/**
	 * @param licenseNo the licenseNo to set
	 */
	public void setLicenseNo(String licenseNo) {
		this.licenseNo = licenseNo;
	}
	/**
	 * @return the licenseNm
	 */
	public String getLicenseNm() {
		return licenseNm;
	}
	/**
	 * @param licenseNm the licenseNm to set
	 */
	public void setLicenseNm(String licenseNm) {
		this.licenseNm = licenseNm;
	}
	/**
	 * @return the typeCd
	 */
	public String getTypeCd() {
		return typeCd;
	}
	/**
	 * @param typeCd the typeCd to set
	 */
	public void setTypeCd(String typeCd) {
		this.typeCd = typeCd;
	}
	/**
	 * @return the stateCd
	 */
	public String getStateCd() {
		return stateCd;
	}
	/**
	 * @param stateCd the stateCd to set
	 */
	public void setStateCd(String stateCd) {
		this.stateCd = stateCd;
	}
	/**
	 * @return the stateNm
	 */
	public String getStateNm() {
		return stateNm;
	}
	/**
	 * @param stateNm the stateNm to set
	 */
	public void setStateNm(String stateNm) {
		this.stateNm = stateNm;
	}
	/**
	 * @return the statusCd
	 */
	public String getStatusCd() {
		return statusCd;
	}
	/**
	 * @param statusCd the statusCd to set
	 */
	public void setStatusCd(String statusCd) {
		this.statusCd = statusCd;
	}
	/**
	 * @return the statusNm
	 */
	public String getStatusNm() {
		return statusNm;
	}
	/**
	 * @param statusNm the statusNm to set
	 */
	public void setStatusNm(String statusNm) {
		this.statusNm = statusNm;
	}
	/**
	 * @return the lineOfBusinessCd
	 */
	public String getLineOfBusinessCd() {
		return lineOfBusinessCd;
	}
	/**
	 * @param lineOfBusinessCd the lineOfBusinessCd to set
	 */
	public void setLineOfBusinessCd(String lineOfBusinessCd) {
		this.lineOfBusinessCd = lineOfBusinessCd;
	}
	/**
	 * @return the lineOfBusinessNm
	 */
	public String getLineOfBusinessNm() {
		return lineOfBusinessNm;
	}
	/**
	 * @param lineOfBusinessNm the lineOfBusinessNm to set
	 */
	public void setLineOfBusinessNm(String lineOfBusinessNm) {
		this.lineOfBusinessNm = lineOfBusinessNm;
	}
    
}
