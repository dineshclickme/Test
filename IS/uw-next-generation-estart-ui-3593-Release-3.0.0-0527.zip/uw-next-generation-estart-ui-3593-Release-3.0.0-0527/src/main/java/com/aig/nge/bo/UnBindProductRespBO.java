package com.aig.nge.bo;

import java.util.List;

public class UnBindProductRespBO {

	    private String transactionId;
	    private String transactionVersionNo;
	    private List<ProductRespTypeBO> unbindProducts;
		/**
		 * @return the transactionId
		 */
		public String getTransactionId() {
			return transactionId;
		}
		/**
		 * @param transactionId the transactionId to set
		 */
		public void setTransactionId(String transactionId) {
			this.transactionId = transactionId;
		}
		/**
		 * @return the transactionVersionNo
		 */
		public String getTransactionVersionNo() {
			return transactionVersionNo;
		}
		/**
		 * @param transactionVersionNo the transactionVersionNo to set
		 */
		public void setTransactionVersionNo(String transactionVersionNo) {
			this.transactionVersionNo = transactionVersionNo;
		}
		/**
		 * @return the unbindProducts
		 */
		public List<ProductRespTypeBO> getUnbindProducts() {
			return unbindProducts;
		}
		/**
		 * @param unbindProducts the unbindProducts to set
		 */
		public void setUnbindProducts(List<ProductRespTypeBO> unbindProducts) {
			this.unbindProducts = unbindProducts;
		}
}
