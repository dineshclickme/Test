package com.aig.nge.dao;

import java.util.List;
import java.util.Set;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.aig.nge.entities.Tlocation;
import com.aig.nge.repository.TLocationByBranchRepository;
import com.aig.nge.utilities.NGEConstants;

@Repository
public class LocationByBranchDAO extends BaseDAO{

	@Autowired 
	private TLocationByBranchRepository tLocationByBranchRepository;
	
	public Set<Tlocation> getCountriesList(){
		Set<Tlocation> locationList =  tLocationByBranchRepository.findLocationByBranch(NGEConstants.LocationType.COUNTRY_LOCATION_TYPE);
		return  locationList;
	}
	public Set<Object[]> findBranchByCountry(){
		Set<Object[]> locationList =  tLocationByBranchRepository.findBranchByCountry(NGEConstants.LocationType.COUNTRY_LOCATION_TYPE);
		return  locationList;
	}
	
	public Set<Object[]> getAllCountriesData(){
		Set<Object[]> locationList =  tLocationByBranchRepository.getAllCountriesData(NGEConstants.LocationType.COUNTRY_LOCATION_TYPE);
		return  locationList;
	}
	public Set<Object[]> getExposureCountryData(){
		Set<Object[]> locationList =  tLocationByBranchRepository.getExposureCountryData(NGEConstants.LocationType.STATE);
		return  locationList;
	}
	
	public Tlocation findLocationByCountryCd( String locationCd, String locationTypeCd)
	{
		Tlocation locationData = tLocationByBranchRepository.findByCountryCd(locationCd, locationTypeCd);
	/*	if(locationData==null) 	{
			ngeException.throwException("ERR1000001", NGEErrorCodes.ERROR_TYPE, null, null);
		}*/
		return locationData;
	}
	
	public Set<Object[]> findStatesByCountryCd(String locationTypeCd)
	{
		Set<Object[]> locationData = tLocationByBranchRepository.findStatesByCountryCd( locationTypeCd);
	/*	if(locationData==null) 	{
			ngeException.throwException("ERR1000001", NGEErrorCodes.ERROR_TYPE, null, null);
		}*/
		return locationData;
	}
	
	public Set<Tlocation> getAllStates(){
		Set<Tlocation> statesList = tLocationByBranchRepository.getStates(NGEConstants.LocationType.STATE);
		return statesList;
	}
	
	public String getISOCountryCd(String aigCountryCd){
		String locCd=NGEConstants.EMPTY_STRING;
		Tlocation loc=tLocationByBranchRepository.getISOCountryCd(aigCountryCd,NGEConstants.LocationType.COUNTRY_AIG);
		if(null!=loc){
		locCd=loc.getLocationCd();
	    }
		return locCd;
	}
	
	//changes for alternate country code mapping starts
	public List<Object[]> getAlternateCountryCodeDAO(){
		List<Object[]> alternateCountryCode = tLocationByBranchRepository.getAlternateCountryCode();
		return alternateCountryCode;
	}
	//changes for alternate country code mapping ends
	
	public Set<Object[]> getBranchMappingDAO() {
		Set<Object[]> branchMapping = tLocationByBranchRepository.getBranchMapping();
		return branchMapping;
	}
}
