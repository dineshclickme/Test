package com.aig.nge.bo;


public class RowBO {
    protected String accountNumber;
    protected String accountBusinessName;
    protected String organization;
    protected String activeIndicator;
    protected String treePosition;
    protected String streetAddress;
    protected String cityName;
    protected String stateCode;
    protected String countryCode;
    protected String countryAbbr;
    protected String postalCode;
    protected String rowNo;
	/**
	 * @return the accountNumber
	 */
	public String getAccountNumber() {
		return accountNumber;
	}
	/**
	 * @param accountNumber the accountNumber to set
	 */
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	/**
	 * @return the accountBusinessName
	 */
	public String getAccountBusinessName() {
		return accountBusinessName;
	}
	/**
	 * @param accountBusinessName the accountBusinessName to set
	 */
	public void setAccountBusinessName(String accountBusinessName) {
		this.accountBusinessName = accountBusinessName;
	}
	/**
	 * @return the organization
	 */
	public String getOrganization() {
		return organization;
	}
	/**
	 * @param organization the organization to set
	 */
	public void setOrganization(String organization) {
		this.organization = organization;
	}
	/**
	 * @return the activeIndicator
	 */
	public String getActiveIndicator() {
		return activeIndicator;
	}
	/**
	 * @param activeIndicator the activeIndicator to set
	 */
	public void setActiveIndicator(String activeIndicator) {
		this.activeIndicator = activeIndicator;
	}
	/**
	 * @return the treePosition
	 */
	public String getTreePosition() {
		return treePosition;
	}
	/**
	 * @param treePosition the treePosition to set
	 */
	public void setTreePosition(String treePosition) {
		this.treePosition = treePosition;
	}
	/**
	 * @return the streetAddress
	 */
	public String getStreetAddress() {
		return streetAddress;
	}
	/**
	 * @param streetAddress the streetAddress to set
	 */
	public void setStreetAddress(String streetAddress) {
		this.streetAddress = streetAddress;
	}
	/**
	 * @return the cityName
	 */
	public String getCityName() {
		return cityName;
	}
	/**
	 * @param cityName the cityName to set
	 */
	public void setCityName(String cityName) {
		this.cityName = cityName;
	}
	/**
	 * @return the stateCode
	 */
	public String getStateCode() {
		return stateCode;
	}
	/**
	 * @param stateCode the stateCode to set
	 */
	public void setStateCode(String stateCode) {
		this.stateCode = stateCode;
	}
	/**
	 * @return the countryCode
	 */
	public String getCountryCode() {
		return countryCode;
	}
	/**
	 * @param countryCode the countryCode to set
	 */
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}
	/**
	 * @return the countryAbbr
	 */
	public String getCountryAbbr() {
		return countryAbbr;
	}
	/**
	 * @param countryAbbr the countryAbbr to set
	 */
	public void setCountryAbbr(String countryAbbr) {
		this.countryAbbr = countryAbbr;
	}
	/**
	 * @return the postalCode
	 */
	public String getPostalCode() {
		return postalCode;
	}
	/**
	 * @param postalCode the postalCode to set
	 */
	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}
	/**
	 * @return the rowNo
	 */
	public String getRowNo() {
		return rowNo;
	}
	/**
	 * @param rowNo the rowNo to set
	 */
	public void setRowNo(String rowNo) {
		this.rowNo = rowNo;
	}
}
