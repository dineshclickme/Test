package com.aig.nge.bo;

import com.fasterxml.jackson.annotation.JsonInclude;

public class QuoteProductReqBO {
	
	@JsonInclude(JsonInclude.Include.ALWAYS)
    private String segmentCd;
	@JsonInclude(JsonInclude.Include.ALWAYS)
    private String subSegmentCd;
	@JsonInclude(JsonInclude.Include.ALWAYS)
    private String marketableProductCd;
	@JsonInclude(JsonInclude.Include.ALWAYS)
    private String componentProductCd;
	@JsonInclude(JsonInclude.Include.ALWAYS)
    private String attachmentPointAmt;
	@JsonInclude(JsonInclude.Include.ALWAYS)
    private String quoteAttachmentPointAmt;
	@JsonInclude(JsonInclude.Include.ALWAYS)
    private String limitAmt;
	@JsonInclude(JsonInclude.Include.ALWAYS)
    private String productState;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String effDate;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String expDate;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String underwriterId;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String premiumAmount;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String currencyCode;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String technicalPremiumAmount;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String transId;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String transVersion;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String transactionComponentId;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String componentProductSegmentCd;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String componentProductSubSegmentCd;
	
	public String getTransactionComponentId() {
		return transactionComponentId;
	}
	public void setTransactionComponentId(String transactionComponentId) {
		this.transactionComponentId = transactionComponentId;
	}
	public String getSegmentCd() {
		return segmentCd;
	}
	public void setSegmentCd(String segmentCd) {
		this.segmentCd = segmentCd;
	}
	public String getSubSegmentCd() {
		return subSegmentCd;
	}
	public void setSubSegmentCd(String subSegmentCd) {
		this.subSegmentCd = subSegmentCd;
	}
	public String getMarketableProductCd() {
		return marketableProductCd;
	}
	public void setMarketableProductCd(String marketableProductCd) {
		this.marketableProductCd = marketableProductCd;
	}
	public String getComponentProductCd() {
		return componentProductCd;
	}
	public void setComponentProductCd(String componentProductCd) {
		this.componentProductCd = componentProductCd;
	}
	public String getAttachmentPointAmt() {
		return attachmentPointAmt;
	}
	public void setAttachmentPointAmt(String attachmentPointAmt) {
		this.attachmentPointAmt = attachmentPointAmt;
	}
	public String getLimitAmt() {
		return limitAmt;
	}
	public void setLimitAmt(String limitAmt) {
		this.limitAmt = limitAmt;
	}
	public String getProductState() {
		return productState;
	}
	public void setProductState(String productState) {
		this.productState = productState;
	}
	public String getEffDate() {
		return effDate;
	}
	public void setEffDate(String effDate) {
		this.effDate = effDate;
	}
	public String getExpDate() {
		return expDate;
	}
	public void setExpDate(String expDate) {
		this.expDate = expDate;
	}
	public String getUnderwriterId() {
		return underwriterId;
	}
	public void setUnderwriterId(String underwriterId) {
		this.underwriterId = underwriterId;
	}
	public String getPremiumAmount() {
		return premiumAmount;
	}
	public void setPremiumAmount(String premiumAmount) {
		this.premiumAmount = premiumAmount;
	}
	public String getTechnicalPremiumAmount() {
		return technicalPremiumAmount;
	}
	public void setTechnicalPremiumAmount(String technicalPremiumAmount) {
		this.technicalPremiumAmount = technicalPremiumAmount;
	}
	public String getTransId() {
		return transId;
	}
	public void setTransId(String transId) {
		this.transId = transId;
	}
	public String getTransVersion() {
		return transVersion;
	}
	public void setTransVersion(String transVersion) {
		this.transVersion = transVersion;
	}
	public String getQuoteAttachmentPointAmt() {
		return quoteAttachmentPointAmt;
	}
	public void setQuoteAttachmentPointAmt(String quoteAttachmentPointAmt) {
		this.quoteAttachmentPointAmt = quoteAttachmentPointAmt;
	}
	public String getCurrencyCode() {
		return currencyCode;
	}
	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}
	public String getComponentProductSegmentCd() {
		return componentProductSegmentCd;
	}
	public void setComponentProductSegmentCd(String componentProductSegmentCd) {
		this.componentProductSegmentCd = componentProductSegmentCd;
	}
	public String getComponentProductSubSegmentCd() {
		return componentProductSubSegmentCd;
	}
	public void setComponentProductSubSegmentCd(String componentProductSubSegmentCd) {
		this.componentProductSubSegmentCd = componentProductSubSegmentCd;
	}
}
