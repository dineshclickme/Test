package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-02-24T11:59:49.650+0530")
@StaticMetamodel(TcompnentStatusAttribute.class)
public class TcompnentStatusAttribute_ {
	public static volatile SingularAttribute<TcompnentStatusAttribute, TcompnentStatusAttributePK> id;
	public static volatile SingularAttribute<TcompnentStatusAttribute, String> attributeVal;
	public static volatile SingularAttribute<TcompnentStatusAttribute, Timestamp> createTs;
	public static volatile SingularAttribute<TcompnentStatusAttribute, String> createUserId;
	public static volatile SingularAttribute<TcompnentStatusAttribute, Timestamp> updateTs;
	public static volatile SingularAttribute<TcompnentStatusAttribute, String> updateUserId;
	public static volatile SingularAttribute<TcompnentStatusAttribute, Tattribute> tattribute;
	public static volatile SingularAttribute<TcompnentStatusAttribute, TtransactionComponentStatus> ttransactionComponentStatus;
}
