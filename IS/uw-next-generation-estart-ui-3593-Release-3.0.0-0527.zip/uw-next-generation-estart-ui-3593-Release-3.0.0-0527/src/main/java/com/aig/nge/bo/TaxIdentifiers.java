package com.aig.nge.bo;

import java.util.List;

import com.aig.nge.utilities.NGECommonUtil;
import com.fasterxml.jackson.annotation.JsonProperty;

public class TaxIdentifiers {
	
	@JsonProperty("IdentifierTypeCd")
	private String identifierTypeCd="";
	@JsonProperty("IdentifierValue")
	private String identifierValue="";
	@JsonProperty("IdentifierTypeCdDesc")
	private String identifierTypeCdDesc="";
		

	public String getIdentifierTypeCd() {
		return identifierTypeCd;
	}


	public void setIdentifierTypeCd(String identifierTypeCd) {
		identifierTypeCd=NGECommonUtil.setDefaultStringValue(identifierTypeCd);

		this.identifierTypeCd = identifierTypeCd;
	}


	public String getIdentifierValue() {
		return identifierValue;
	}


	public void setIdentifierValue(String identifierValue) {
		identifierValue=NGECommonUtil.setDefaultStringValue(identifierValue);

		this.identifierValue = identifierValue;
	}


	public String getIdentifierTypeCdDesc() {
		return identifierTypeCdDesc;
	}


	public void setIdentifierTypeCdDesc(String identifierTypeCdDesc) {
		identifierTypeCdDesc=NGECommonUtil.setDefaultStringValue(identifierTypeCdDesc);

		this.identifierTypeCdDesc = identifierTypeCdDesc;
	}
}
