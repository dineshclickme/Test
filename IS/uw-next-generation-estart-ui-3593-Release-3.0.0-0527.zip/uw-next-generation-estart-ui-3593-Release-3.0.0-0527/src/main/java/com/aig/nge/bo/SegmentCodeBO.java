package com.aig.nge.bo;

public class SegmentCodeBO {
	
	private String segmentCd;
	private String subSegmentCd;
	public String getSegmentCd() {
		return segmentCd;
	}
	public void setSegmentCd(String segmentCd) {
		this.segmentCd = segmentCd;
	}
	public String getSubSegmentCd() {
		return subSegmentCd;
	}
	public void setSubSegmentCd(String subSegmentCd) {
		this.subSegmentCd = subSegmentCd;
	}

}
