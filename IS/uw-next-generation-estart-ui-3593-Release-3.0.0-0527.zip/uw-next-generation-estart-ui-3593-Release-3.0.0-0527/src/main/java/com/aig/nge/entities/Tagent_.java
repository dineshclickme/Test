package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-02-19T16:13:02.773+0530")
@StaticMetamodel(Tagent.class)
public class Tagent_ {
	public static volatile SingularAttribute<Tagent, Integer> partyId;
	public static volatile SingularAttribute<Tagent, Timestamp> createTs;
	public static volatile SingularAttribute<Tagent, String> createUserId;
	public static volatile SingularAttribute<Tagent, String> firstNm;
	public static volatile SingularAttribute<Tagent, String> lastNm;
	public static volatile SingularAttribute<Tagent, String> middleNm;
	public static volatile SingularAttribute<Tagent, Timestamp> updateTs;
	public static volatile SingularAttribute<Tagent, String> updateUserId;
	public static volatile SingularAttribute<Tagent, Tparty> tparty;
}
