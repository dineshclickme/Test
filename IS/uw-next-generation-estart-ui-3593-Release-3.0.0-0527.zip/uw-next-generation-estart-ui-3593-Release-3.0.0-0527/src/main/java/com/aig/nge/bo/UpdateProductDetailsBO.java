package com.aig.nge.bo;

import java.util.List;

public class UpdateProductDetailsBO {
	private String productTabKey;
    private List<MarketableProductDetailsBO> marketableProduct;
    private List<UpdateComponentProductBO> componentProduct;
	/**
	 * @return the marketableProduct
	 */
	public List<MarketableProductDetailsBO> getMarketableProduct() {
		return marketableProduct;
	}
	/**
	 * @param marketableProduct the marketableProduct to set
	 */
	public void setMarketableProduct(
			List<MarketableProductDetailsBO> marketableProduct) {
		this.marketableProduct = marketableProduct;
	}
	/**
	 * @return the componentProduct
	 */
	public List<UpdateComponentProductBO> getComponentProduct() {
		return componentProduct;
	}
	/**
	 * @param componentProduct the componentProduct to set
	 */
	public void setComponentProduct(List<UpdateComponentProductBO> componentProduct) {
		this.componentProduct = componentProduct;
	}
	/**
	 * @return the productTabKey
	 */
	public String getProductTabKey() {
		return productTabKey;
	}
	/**
	 * @param productTabKey the productTabKey to set
	 */
	public void setProductTabKey(String productTabKey) {
		this.productTabKey = productTabKey;
	}
}
