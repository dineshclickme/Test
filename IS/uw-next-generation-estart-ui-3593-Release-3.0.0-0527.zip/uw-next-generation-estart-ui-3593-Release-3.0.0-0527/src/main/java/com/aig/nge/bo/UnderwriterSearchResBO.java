package com.aig.nge.bo;

public class UnderwriterSearchResBO {
	
	private String underwriterName;
	private String underwriterFirstName;
	private String jobTitle;
	private String contactNumber;
	private String emailAddress;
	private String locationAddress;
	private String partyNo;
	private String partyId;
	
	public String getPartyId() {
		return partyId;
	}
	public void setPartyId(String partyId) {
		this.partyId = partyId;
	}
	public String getPartyNo() {
		return partyNo;
	}
	public void setPartyNo(String partyNo) {
		this.partyNo = partyNo;
	}
	public String getUnderwriterName() {
		return underwriterName;
	}
	public void setUnderwriterName(String underwriterName) {
		this.underwriterName = underwriterName;
	}
	public String getUnderwriterFirstName() {
		return underwriterFirstName;
	}
	public void setUnderwriterFirstName(String underwriterFirstName) {
		this.underwriterFirstName = underwriterFirstName;
	}
	public String getJobTitle() {
		return jobTitle;
	}
	public void setJobTitle(String jobTitle) {
		this.jobTitle = jobTitle;
	}
	public String getContactNumber() {
		return contactNumber;
	}
	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}
	public String getEmailAddress() {
		return emailAddress;
	}
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}
	public String getLocationAddress() {
		return locationAddress;
	}
	public void setLocationAddress(String locationAddress) {
		this.locationAddress = locationAddress;
	}
	@Override
	public String toString() {
		return "UnderwriterSearchResBO [underwriterName=" + underwriterName
				+ ", jobTitle=" + jobTitle + ", contactNumber=" + contactNumber
				+ ", emailAddress=" + emailAddress + ", locationAddress="
				+ locationAddress +", partyNo=" + partyNo + "]";
	}
}
