package com.aig.nge.bo;


public class AddShellAccountBO {
    private AccountInfoBO accountInfo;
    private String documentType;
	/**
	 * @return the accountInfo
	 */
	public AccountInfoBO getAccountInfo() {
		return accountInfo;
	}
	/**
	 * @param accountInfo the accountInfo to set
	 */
	public void setAccountInfo(AccountInfoBO accountInfo) {
		this.accountInfo = accountInfo;
	}
	/**
	 * @return the documentType
	 */
	public String getDocumentType() {
		return documentType;
	}
	/**
	 * @param documentType the documentType to set
	 */
	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}
}
