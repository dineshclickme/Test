package com.aig.nge.bo;

import com.fasterxml.jackson.annotation.JsonInclude;

public class SubmissionStartDetailsSessionBO {
	
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String producerEntity;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String producerCd;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String accountName;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String accountCd;
	/* 2021 MDM Changes - Starts */
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String mdmpartyId;
	/* 2021 MDM Changes - Ends */
	
	public String getProducerEntity() {
		return producerEntity;
	}
	public void setProducerEntity(String producerEntity) {
		this.producerEntity = producerEntity;
	}
	public String getProducerCd() {
		return producerCd;
	}
	public void setProducerCd(String producerCd) {
		this.producerCd = producerCd;
	}
	public String getAccountName() {
		return accountName;
	}
	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}
	public String getAccountCd() {
		return accountCd;
	}
	public void setAccountCd(String accountCd) {
		this.accountCd = accountCd;
	}
	public String getMdmpartyId() {
		return mdmpartyId;
	}
	public void setMdmpartyId(String mdmpartyId) {
		this.mdmpartyId = mdmpartyId;
	}
}
