package com.aig.nge.bo;

import java.util.List;

 

public class AlertServiceModel {
	
	private String applID;
	private String userID;
	private String DunNo;
	/*MDM Changes - Starts*/
	private String mdmPartyId;
	/*MDM Changes - Ends*/

	private String submissionNO;
    private String acctNm;
    private String productNM;

	private int blockNo;
	private List<AlertServiceResponseBO> alertServiceRes;
	private String emisUrl;
	
	


	public String getAcctNm() {
		return acctNm;
	}
	public String getEmisUrl() {
		return emisUrl;
	}
	public void setEmisUrl(String emisUrl) {
		this.emisUrl = emisUrl;
	}
	public void setAcctNm(String acctNm) {
		this.acctNm = acctNm;
	}
	public String getProductNM() {
		return productNM;
	}
	public void setProductNM(String productNM) {
		this.productNM = productNM;
	}

	public List<AlertServiceResponseBO> getAlertServiceModel() {
		return alertServiceRes;
	}
	public void setAlertServiceModel(List<AlertServiceResponseBO> alertServiceModel) {
		this.alertServiceRes = alertServiceModel;
	}
	
	public int getBlockNo() {
		return blockNo;
	}
	public void setBlockNo(int blockNo) {
		this.blockNo = blockNo;
	}

	

	public String getApplID() {
		return applID;
	}
	public void setApplID(String applID) {
		this.applID = applID;
	}
	public String getUserID() {
		return userID;
	}
	public void setUserID(String userID) {
		this.userID = userID;
	}
	public String getDunNo() {
		return DunNo;
	}
	public void setDunNo(String dunNo) {
		DunNo = dunNo;
	}
	
	public String getSubmissionNO() {
		return submissionNO;
	}
	public void setSubmissionNO(String submissionNO) {
		this.submissionNO = submissionNO;
	}

	public List<AlertServiceResponseBO> getAlertServiceRes() {
		return alertServiceRes;
	}
	public void setAlertServiceRes(List<AlertServiceResponseBO> alertServiceRes) {
		this.alertServiceRes = alertServiceRes;
	}
	/*MDM Changes - Starts*/
	public String getMdmPartyId() {
		return mdmPartyId;
	}
	public void setMdmPartyId(String mdmPartyId) {
		this.mdmPartyId = mdmPartyId;
	}
	/*MDM Changes - Ends*/	

}
