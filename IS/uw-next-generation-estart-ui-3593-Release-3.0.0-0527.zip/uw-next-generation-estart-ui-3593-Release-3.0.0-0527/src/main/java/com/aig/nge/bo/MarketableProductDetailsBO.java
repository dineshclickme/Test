package com.aig.nge.bo;

import java.util.List;

public class MarketableProductDetailsBO {
	
	private String marketProdId;
	private String segmentCd;
	private String segmentName;
	private String subSegmentCd;
	private String subSegmentName;
	private String marketableProductCd;
	private String marketableProductName;
	private String underwriterId;
	private String prodTower;
	private String componentProductCd;
	private List<AttributesInfoBO> attributesInfo;
	private String action;
	private boolean isUpdateRequired;
	private List<AttributesInfoUpdBO> attributesInfoUpdate;
	
	/**
	 * @return the attributesInfoUpdate
	 */
	public List<AttributesInfoUpdBO> getAttributesInfoUpdate() {
		return attributesInfoUpdate;
	}
	/**
	 * @param attributesInfoUpdate the attributesInfoUpdate to set
	 */
	public void setAttributesInfoUpdate(
			List<AttributesInfoUpdBO> attributesInfoUpdate) {
		this.attributesInfoUpdate = attributesInfoUpdate;
	}
	/**
	 * @return the isUpdateRequired
	 */
	public boolean isUpdateRequired() {
		return isUpdateRequired;
	}
	/**
	 * @param isUpdateRequired the isUpdateRequired to set
	 */
	public void setUpdateRequired(boolean isUpdateRequired) {
		this.isUpdateRequired = isUpdateRequired;
	}
	/**
	 * @return the action
	 */
	public String getAction() {
		return action;
	}
	/**
	 * @param action the action to set
	 */
	public void setAction(String action) {
		this.action = action;
	}
	/**
	 * @return the marketProdId
	 */
	public String getMarketProdId() {
		return marketProdId;
	}
	/**
	 * @param marketProdId the marketProdId to set
	 */
	public void setMarketProdId(String marketProdId) {
		this.marketProdId = marketProdId;
	}
	public String getSegmentCd() {
		return segmentCd;
	}
	public void setSegmentCd(String segmentCd) {
		this.segmentCd = segmentCd;
	}
	public String getSegmentName() {
		return segmentName;
	}
	public void setSegmentName(String segmentName) {
		this.segmentName = segmentName;
	}
	public String getSubSegmentCd() {
		return subSegmentCd;
	}
	public void setSubSegmentCd(String subSegmentCd) {
		this.subSegmentCd = subSegmentCd;
	}
	public String getSubSegmentName() {
		return subSegmentName;
	}
	public void setSubSegmentName(String subSegmentName) {
		this.subSegmentName = subSegmentName;
	}
	public String getMarketableProductCd() {
		return marketableProductCd;
	}
	public void setMarketableProductCd(String marketableProductCd) {
		this.marketableProductCd = marketableProductCd;
	}
	public String getMarketableProductName() {
		return marketableProductName;
	}
	public void setMarketableProductName(String marketableProductName) {
		this.marketableProductName = marketableProductName;
	}
	public String getUnderwriterId() {
		return underwriterId;
	}
	public void setUnderwriterId(String underwriterId) {
		this.underwriterId = underwriterId;
	}
	public List<AttributesInfoBO> getAttributesInfo() {
		return attributesInfo;
	}
	public void setAttributesInfo(List<AttributesInfoBO> attributesInfo) {
		this.attributesInfo = attributesInfo;
	}
	
	public String getProdTower() {
		return prodTower;
	}
	public void setProdTower(String prodTower) {
		this.prodTower = prodTower;
	}
	public String getComponentProductCd() {
		return componentProductCd;
	}
	public void setComponentProductCd(String componentProductCd) {
		this.componentProductCd = componentProductCd;
	}

}
