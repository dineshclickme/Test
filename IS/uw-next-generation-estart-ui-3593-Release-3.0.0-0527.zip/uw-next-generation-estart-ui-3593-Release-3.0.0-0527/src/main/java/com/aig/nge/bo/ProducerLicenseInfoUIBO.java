package com.aig.nge.bo;

public class ProducerLicenseInfoUIBO {
	private String licensenumber;
	private String licensestate;
	private String licensename;
	private String licensetype;
	private String loatype;
	/**
	 * @return the licensenumber
	 */
	public String getLicensenumber() {
		return licensenumber;
	}
	/**
	 * @param licensenumber the licensenumber to set
	 */
	public void setLicensenumber(String licensenumber) {
		this.licensenumber = licensenumber;
	}
	/**
	 * @return the licensestate
	 */
	public String getLicensestate() {
		return licensestate;
	}
	/**
	 * @param licensestate the licensestate to set
	 */
	public void setLicensestate(String licensestate) {
		this.licensestate = licensestate;
	}
	/**
	 * @return the licensename
	 */
	public String getLicensename() {
		return licensename;
	}
	/**
	 * @param licensename the licensename to set
	 */
	public void setLicensename(String licensename) {
		this.licensename = licensename;
	}
	/**
	 * @return the licensetype
	 */
	public String getLicensetype() {
		return licensetype;
	}
	/**
	 * @param licensetype the licensetype to set
	 */
	public void setLicensetype(String licensetype) {
		this.licensetype = licensetype;
	}
	/**
	 * @return the loatype
	 */
	public String getLoatype() {
		return loatype;
	}
	/**
	 * @param loatype the loatype to set
	 */
	public void setLoatype(String loatype) {
		this.loatype = loatype;
	}
}
