package com.aig.nge.bo;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

public class ReleaseAlertBlockReqBO {
	
	@JsonInclude(JsonInclude.Include.ALWAYS)
    private BlockReleaseBO blockNo;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private List<ReleaseProductBO> blockedProduct;
    
	/**
	 * @return the blockNo
	 */
	public BlockReleaseBO getBlockNo() {
		return blockNo;
	}
	/**
	 * @param blockNo the blockNo to set
	 */
	public void setBlockNo(BlockReleaseBO blockNo) {
		this.blockNo = blockNo;
	}
	/**
	 * @return the blockedProduct
	 */
	public List<ReleaseProductBO> getBlockedProduct() {
		return blockedProduct;
	}
	/**
	 * @param blockedProduct the blockedProduct to set
	 */
	public void setBlockedProduct(List<ReleaseProductBO> blockedProduct) {
		this.blockedProduct = blockedProduct;
	}
	
}
