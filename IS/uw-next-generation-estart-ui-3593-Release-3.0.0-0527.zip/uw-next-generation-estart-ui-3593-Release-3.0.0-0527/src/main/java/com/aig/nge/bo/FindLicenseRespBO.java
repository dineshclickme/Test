/**
 * 
 */
package com.aig.nge.bo;

/**
 * @author Bennym
 *
 */
public class FindLicenseRespBO {
	
	private AgencyLicenseInfoBO agencyLicenseInfo;
	private AgentLicenseInfoBO agentLicenseInfo;
	private ErrorDetailBO errorDetail;
	private String status;
	/**
	 * @return the agencyLicenseInfo
	 */
	public AgencyLicenseInfoBO getAgencyLicenseInfo() {
		return agencyLicenseInfo;
	}
	/**
	 * @param agencyLicenseInfo the agencyLicenseInfo to set
	 */
	public void setAgencyLicenseInfo(AgencyLicenseInfoBO agencyLicenseInfo) {
		this.agencyLicenseInfo = agencyLicenseInfo;
	}
	/**
	 * @return the agentLicenseInfo
	 */
	public AgentLicenseInfoBO getAgentLicenseInfo() {
		return agentLicenseInfo;
	}
	/**
	 * @param agentLicenseInfo the agentLicenseInfo to set
	 */
	public void setAgentLicenseInfo(AgentLicenseInfoBO agentLicenseInfo) {
		this.agentLicenseInfo = agentLicenseInfo;
	}
	/**
	 * @return the errorDetail
	 */
	public ErrorDetailBO getErrorDetail() {
		return errorDetail;
	}
	/**
	 * @param errorDetail the errorDetail to set
	 */
	public void setErrorDetail(ErrorDetailBO errorDetail) {
		this.errorDetail = errorDetail;
	}
	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}
	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}
}
