package com.aig.nge.bo;

public class ViewblockBO {

	//private String accountName;
	private String submissionno;
	private String transactionVersionNumber;
	private String accntnamedandb;
	private String compProductName;
	private String attachmentpt;
	private String limitamt;
	//US145616 SCUP View/Block changes started
	private String masterLineofBusinessName;
	private String coverageLineName;
	/*MDM Change Starts*/
	private String accountNo;
	private String mdmPartyId;
	/*MDM Change Ends*/
	
	
	public String getMasterLineofBusinessName() {
		return masterLineofBusinessName;
	}
	public void setMasterLineofBusinessName(String masterLineofBusinessName) {
		this.masterLineofBusinessName = masterLineofBusinessName;
	}
	public String getCoverageLineName() {
		return coverageLineName;
	}
	public void setCoverageLineName(String coverageLineName) {
		this.coverageLineName = coverageLineName;
	}
	//US145616 SCUP view/block Changes ended
	
	/*public String getAccountName() {
		return accountName;
	}
	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}*/
	public String getSubmissionno() {
		return submissionno;
	}
	public void setSubmissionno(String submissionno) {
		this.submissionno = submissionno;
	}
	public String getTransactionVersionNumber() {
		return transactionVersionNumber;
	}
	public void setTransactionVersionNumber(String transactionVersionNumber) {
		this.transactionVersionNumber = transactionVersionNumber;
	}
	public String getAccntnamedandb() {
		return accntnamedandb;
	}
	public void setAccntnamedandb(String accntnamedandb) {
		this.accntnamedandb = accntnamedandb;
	}
	public String getCompProductName() {
		return compProductName;
	}
	public void setCompProductName(String compProductName) {
		this.compProductName = compProductName;
	}
	public String getAttachmentpt() {
		return attachmentpt;
	}
	public void setAttachmentpt(String attachmentpt) {
		this.attachmentpt = attachmentpt;
	}
	public String getLimitamt() {
		return limitamt;
	}
	public void setLimitamt(String limitamt) {
		this.limitamt = limitamt;
	}
	/*MDM Changes - Starts*/
	public String getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}
	public String getMdmPartyId() {
		return mdmPartyId;
	}
	public void setMdmPartyId(String mdmPartyId) {
		this.mdmPartyId = mdmPartyId;
	}
	/*MDM Changes - Ends*/	
	
	
}
