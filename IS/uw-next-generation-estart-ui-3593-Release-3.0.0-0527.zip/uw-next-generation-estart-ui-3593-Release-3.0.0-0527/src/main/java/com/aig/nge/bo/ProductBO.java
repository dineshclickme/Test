/**
 * 
 */
package com.aig.nge.bo;

import com.fasterxml.jackson.annotation.JsonInclude;


/**
 * @author Bennym
 *
 */
public class ProductBO {
	
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String transactionId;
	@JsonInclude(JsonInclude.Include.ALWAYS)
    private String transactionVersionNo;
	@JsonInclude(JsonInclude.Include.ALWAYS)
    private String segmentCd;
	@JsonInclude(JsonInclude.Include.ALWAYS)
    private String subSegmentCd;
	@JsonInclude(JsonInclude.Include.ALWAYS)
    private String productTowerCd;
	@JsonInclude(JsonInclude.Include.ALWAYS)
    private String marketableProductCd;
	@JsonInclude(JsonInclude.Include.ALWAYS)
    private String componentProductCd;
	@JsonInclude(JsonInclude.Include.ALWAYS)
    private String componentproductname;
	@JsonInclude(JsonInclude.Include.ALWAYS)
    private String attachmentPointAmt;
	@JsonInclude(JsonInclude.Include.ALWAYS)
    private String currencyCd;
	@JsonInclude(JsonInclude.Include.ALWAYS)
    private String submissionNo;
	@JsonInclude(JsonInclude.Include.ALWAYS)
    private String limitAmt;
	@JsonInclude(JsonInclude.Include.ALWAYS)
    private NGEViewOfMessageBO message;
	@JsonInclude(JsonInclude.Include.ALWAYS)
    private String accountName;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String accountNo;
	/*MDM Change Starts*/
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String mdmPartyId;
	/*MDM Change Ends*/
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String productTabKey;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String componentProductTabKey;
	@JsonInclude(JsonInclude.Include.ALWAYS)
    private String id;
	@JsonInclude(JsonInclude.Include.ALWAYS)
    private String actionInd;
	@JsonInclude(JsonInclude.Include.ALWAYS)
    private String sequenceNumber;
	@JsonInclude(JsonInclude.Include.ALWAYS)
    private String transactionComponentId;
	@JsonInclude(JsonInclude.Include.ALWAYS)
    private String componentProductTowerCd;
	@JsonInclude(JsonInclude.Include.ALWAYS)
    private String componentProductSegmentCd;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String componentProductSubSegmentCd;
	//US145616 SCUP view/release Changes 2020 started
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String masterLineOfBusinessNm;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String masterLineOfBusinessCd;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String coverageLineCd;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String coverageLineNm;
	

	public String getMasterLineOfBusinessNm() {
		return masterLineOfBusinessNm;
	}
	public void setMasterLineOfBusinessNm(String masterLineOfBusinessNm) {
		this.masterLineOfBusinessNm = masterLineOfBusinessNm;
	}
	public String getMasterLineOfBusinessCd() {
		return masterLineOfBusinessCd;
	}	
	public void setMasterLineOfBusinessCd(String masterLineOfBusinessCd) {
		this.masterLineOfBusinessCd = masterLineOfBusinessCd;
	}
	public String getCoverageLineCd() {
		return coverageLineCd;
	}
	public void setCoverageLineCd(String coverageLineCd) {
		this.coverageLineCd = coverageLineCd;
	}
	public String getCoverageLineNm() {
		return coverageLineNm;
	}
	public void setCoverageLineNm(String coverageLineNm) {
		this.coverageLineNm = coverageLineNm;
	}
	//US145616 SCUP view/release Changes 2020 ended
	public String getComponentProductTowerCd() {
		return componentProductTowerCd;
	}
	public void setComponentProductTowerCd(String componentProductTowerCd) {
		this.componentProductTowerCd = componentProductTowerCd;
	}
	public String getTransactionComponentId() {
		return transactionComponentId;
	}
	public void setTransactionComponentId(String transactionComponentId) {
		this.transactionComponentId = transactionComponentId;
	}
	public String getSequenceNumber() {
		return sequenceNumber;
	}
	public void setSequenceNumber(String sequenceNumber) {
		this.sequenceNumber = sequenceNumber;
	}
	public String getActionInd() {
		return actionInd;
	}
	public void setActionInd(String actionInd) {
		this.actionInd = actionInd;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	/**
	 * @return the transactionId
	 */
	 public String getComponentproductname() {
		return componentproductname;
	}
	public void setComponentproductname(String componentproductname) {
		this.componentproductname = componentproductname;
	}
	public String getTransactionId() {
		return transactionId;
	}
	public String getAccountName() {
		return accountName;
	}
	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}
	public String getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}
	/**
	 * @param transactionId the transactionId to set
	 */
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	/**
	 * @return the transactionVersionNo
	 */
	public String getTransactionVersionNo() {
		return transactionVersionNo;
	}
	/**
	 * @param transactionVersionNo the transactionVersionNo to set
	 */
	public void setTransactionVersionNo(String transactionVersionNo) {
		this.transactionVersionNo = transactionVersionNo;
	}
	/**
	 * @return the segmentCd
	 */
	public String getSegmentCd() {
		return segmentCd;
	}
	/**
	 * @param segmentCd the segmentCd to set
	 */
	public void setSegmentCd(String segmentCd) {
		this.segmentCd = segmentCd;
	}
	/**
	 * @return the subSegmentCd
	 */
	public String getSubSegmentCd() {
		return subSegmentCd;
	}
	/**
	 * @param subSegmentCd the subSegmentCd to set
	 */
	public void setSubSegmentCd(String subSegmentCd) {
		this.subSegmentCd = subSegmentCd;
	}
	/**
	 * @return the productTowerCd
	 */
	public String getProductTowerCd() {
		return productTowerCd;
	}
	/**
	 * @param productTowerCd the productTowerCd to set
	 */
	public void setProductTowerCd(String productTowerCd) {
		this.productTowerCd = productTowerCd;
	}
	/**
	 * @return the marketableProductCd
	 */
	public String getMarketableProductCd() {
		return marketableProductCd;
	}
	/**
	 * @param marketableProductCd the marketableProductCd to set
	 */
	public void setMarketableProductCd(String marketableProductCd) {
		this.marketableProductCd = marketableProductCd;
	}
	/**
	 * @return the componentProductCd
	 */
	public String getComponentProductCd() {
		return componentProductCd;
	}
	/**
	 * @param componentProductCd the componentProductCd to set
	 */
	public void setComponentProductCd(String componentProductCd) {
		this.componentProductCd = componentProductCd;
	}
	/**
	 * @return the attachmentPointAmt
	 */
	public String getAttachmentPointAmt() {
		return attachmentPointAmt;
	}
	/**
	 * @param attachmentPointAmt the attachmentPointAmt to set
	 */
	public void setAttachmentPointAmt(String attachmentPointAmt) {
		this.attachmentPointAmt = attachmentPointAmt;
	}
	public String getCurrencyCd() {
		return currencyCd;
	}
	public void setCurrencyCd(String currencyCd) {
		this.currencyCd = currencyCd;
	}
	public NGEViewOfMessageBO getMessage() {
		return message;
	}
	public void setMessage(NGEViewOfMessageBO message) {
		this.message = message;
	}
	public String getSubmissionNo() {
		return submissionNo;
	}
	public void setSubmissionNo(String submissionNo) {
		this.submissionNo = submissionNo;
	}
	public String getLimitAmt() {
		return limitAmt;
	}
	public void setLimitAmt(String limitAmt) {
		this.limitAmt = limitAmt;
	}
	public String getProductTabKey() {
		return productTabKey;
	}
	public void setProductTabKey(String productTabKey) {
		this.productTabKey = productTabKey;
	}
	public String getComponentProductTabKey() {
		return componentProductTabKey;
	}
	public void setComponentProductTabKey(String componentProductTabKey) {
		this.componentProductTabKey = componentProductTabKey;
	}
	public String getComponentProductSegmentCd() {
		return componentProductSegmentCd;
	}
	public void setComponentProductSegmentCd(String componentProductSegmentCd) {
		this.componentProductSegmentCd = componentProductSegmentCd;
	}
	public String getComponentProductSubSegmentCd() {
		return componentProductSubSegmentCd;
	}
	public void setComponentProductSubSegmentCd(String componentProductSubSegmentCd) {
		this.componentProductSubSegmentCd = componentProductSubSegmentCd;
	}
	/*MDM Changes - Starts*/
	public String getMdmPartyId() {
		return mdmPartyId;
	}
	public void setMdmPartyId(String mdmPartyId) {
		this.mdmPartyId = mdmPartyId;
	}
	/*MDM Changes - Ends*/
}
