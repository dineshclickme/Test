package com.aig.nge.bo;

public class AlternateContactDetailsBO {
	
	private String firstName;
	private String middleName;
	private String lastName;
	private String contactNo;
	private String emailAddress;
	private String emailiconalertBlock;
	private String emailiconproductBlock;
	
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getMiddleName() {
		return middleName;
	}
	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getContactNo() {
		return contactNo;
	}
	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}
	public String getEmailAddress() {
		return emailAddress;
	}
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}
	public String getEmailiconalertBlock() {
		return emailiconalertBlock;
	}
	public void setEmailiconalertBlock(String emailiconalertBlock) {
		this.emailiconalertBlock = emailiconalertBlock;
	}
	public String getEmailiconproductBlock() {
		return emailiconproductBlock;
	}
	public void setEmailiconproductBlock(String emailiconproductBlock) {
		this.emailiconproductBlock = emailiconproductBlock;
	}
	
	
	

}
