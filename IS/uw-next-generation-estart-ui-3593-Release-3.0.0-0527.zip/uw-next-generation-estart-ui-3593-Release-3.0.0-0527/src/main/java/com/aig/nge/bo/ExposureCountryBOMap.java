package com.aig.nge.bo;

import java.util.Map;

public class ExposureCountryBOMap {
	
	private Map<String,ExposureCountryBO> exposureCountryMap;

	public Map<String, ExposureCountryBO> getExposureCountryMap() {
		return exposureCountryMap;
	}

	public void setExposureCountryMap(
			Map<String, ExposureCountryBO> exposureCountryMap) {
		this.exposureCountryMap = exposureCountryMap;
	}
}
