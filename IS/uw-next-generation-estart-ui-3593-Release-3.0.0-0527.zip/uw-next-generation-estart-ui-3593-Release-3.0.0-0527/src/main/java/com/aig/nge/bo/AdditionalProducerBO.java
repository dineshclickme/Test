package com.aig.nge.bo;

import com.fasterxml.jackson.annotation.JsonInclude;

public class AdditionalProducerBO {

	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String producerEntityNumber;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String producerEntityName;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String attributeAction;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String producerAddress;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String producerNPN;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String producerTradeName;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String producerCountry;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String producerCategory;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String producerRegion;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String producerStatus;
	
	public String getProducerEntityNumber() {
		return producerEntityNumber;
	}
	public void setProducerEntityNumber(String producerEntityNumber) {
		this.producerEntityNumber = producerEntityNumber;
	}
	public String getProducerEntityName() {
		return producerEntityName;
	}
	public void setProducerEntityName(String producerEntityName) {
		this.producerEntityName = producerEntityName;
	}
	public String getAttributeAction() {
		return attributeAction;
	}
	public void setAttributeAction(String attributeAction) {
		this.attributeAction = attributeAction;
	}
	public String getProducerAddress() {
		return producerAddress;
	}
	public void setProducerAddress(String producerAddress) {
		this.producerAddress = producerAddress;
	}
	public String getProducerNPN() {
		return producerNPN;
	}
	public void setProducerNPN(String producerNPN) {
		this.producerNPN = producerNPN;
	}
	public String getProducerTradeName() {
		return producerTradeName;
	}
	public void setProducerTradeName(String producerTradeName) {
		this.producerTradeName = producerTradeName;
	}
	public String getProducerCountry() {
		return producerCountry;
	}
	public void setProducerCountry(String producerCountry) {
		this.producerCountry = producerCountry;
	}
	public String getProducerCategory() {
		return producerCategory;
	}
	public void setProducerCategory(String producerCategory) {
		this.producerCategory = producerCategory;
	}
	public String getProducerRegion() {
		return producerRegion;
	}
	public void setProducerRegion(String producerRegion) {
		this.producerRegion = producerRegion;
	}
	public String getProducerStatus() {
		return producerStatus;
	}
	public void setProducerStatus(String producerStatus) {
		this.producerStatus = producerStatus;
	}
	

}
