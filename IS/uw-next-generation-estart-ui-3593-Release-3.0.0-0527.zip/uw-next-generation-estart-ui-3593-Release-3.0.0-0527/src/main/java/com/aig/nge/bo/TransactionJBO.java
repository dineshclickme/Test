package com.aig.nge.bo;

public class TransactionJBO {

	private ValueFooterBO producerEntity;
	private ValueFooterBO producerIndividual;
	private String creditedBranch;
	private String underwriter;
	private String leadFollow;
	/**
	 * @return the producerEntity
	 */
	public ValueFooterBO getProducerEntity() {
		return producerEntity;
	}
	/**
	 * @param producerEntity the producerEntity to set
	 */
	public void setProducerEntity(ValueFooterBO producerEntity) {
		this.producerEntity = producerEntity;
	}
	/**
	 * @return the producerIndividual
	 */
	public ValueFooterBO getProducerIndividual() {
		return producerIndividual;
	}
	/**
	 * @param producerIndividual the producerIndividual to set
	 */
	public void setProducerIndividual(ValueFooterBO producerIndividual) {
		this.producerIndividual = producerIndividual;
	}
	/**
	 * @return the creditedBranch
	 */
	public String getCreditedBranch() {
		return creditedBranch;
	}
	/**
	 * @param creditedBranch the creditedBranch to set
	 */
	public void setCreditedBranch(String creditedBranch) {
		this.creditedBranch = creditedBranch;
	}
	/**
	 * @return the underwriter
	 */
	public String getUnderwriter() {
		return underwriter;
	}
	/**
	 * @param underwriter the underwriter to set
	 */
	public void setUnderwriter(String underwriter) {
		this.underwriter = underwriter;
	}
	/**
	 * @return the leadFollow
	 */
	public String getLeadFollow() {
		return leadFollow;
	}
	/**
	 * @param leadFollow the leadFollow to set
	 */
	public void setLeadFollow(String leadFollow) {
		this.leadFollow = leadFollow;
	}
}
