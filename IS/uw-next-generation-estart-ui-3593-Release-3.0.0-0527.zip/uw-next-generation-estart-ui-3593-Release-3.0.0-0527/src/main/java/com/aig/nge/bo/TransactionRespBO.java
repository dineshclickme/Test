package com.aig.nge.bo;


public class TransactionRespBO {

	private String transactionId;    
    private TransactionVersionRsBO transactionVersionNo;
	/**
	 * @return the transactionId
	 */
	public String getTransactionId() {
		return transactionId;
	}
	/**
	 * @param transactionId the transactionId to set
	 */
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	/**
	 * @return the transactionVersionNo
	 */
	public TransactionVersionRsBO getTransactionVersionNo() {
		return transactionVersionNo;
	}
	/**
	 * @param transactionVersionNo the transactionVersionNo to set
	 */
	public void setTransactionVersionNo(TransactionVersionRsBO transactionVersionNo) {
		this.transactionVersionNo = transactionVersionNo;
	}
    
    
}
