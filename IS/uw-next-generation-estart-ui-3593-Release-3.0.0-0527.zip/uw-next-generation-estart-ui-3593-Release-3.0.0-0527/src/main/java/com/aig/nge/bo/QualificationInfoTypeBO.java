package com.aig.nge.bo;


public class QualificationInfoTypeBO {

	private String licenseNo;
	private String qualificationNm;
	private String qualificationStatusCd;
	private String updateTimeStamp;	
	private String updateUserID;
	/**
	 * @return the licenseNo
	 */
	public String getLicenseNo() {
		return licenseNo;
	}
	/**
	 * @param licenseNo the licenseNo to set
	 */
	public void setLicenseNo(String licenseNo) {
		this.licenseNo = licenseNo;
	}
	/**
	 * @return the qualificationNm
	 */
	public String getQualificationNm() {
		return qualificationNm;
	}
	/**
	 * @param qualificationNm the qualificationNm to set
	 */
	public void setQualificationNm(String qualificationNm) {
		this.qualificationNm = qualificationNm;
	}
	/**
	 * @return the qualificationStatusCd
	 */
	public String getQualificationStatusCd() {
		return qualificationStatusCd;
	}
	/**
	 * @param qualificationStatusCd the qualificationStatusCd to set
	 */
	public void setQualificationStatusCd(String qualificationStatusCd) {
		this.qualificationStatusCd = qualificationStatusCd;
	}
	/**
	 * @return the updateTimeStamp
	 */
	public String getUpdateTimeStamp() {
		return updateTimeStamp;
	}
	/**
	 * @param updateTimeStamp the updateTimeStamp to set
	 */
	public void setUpdateTimeStamp(String updateTimeStamp) {
		this.updateTimeStamp = updateTimeStamp;
	}
	/**
	 * @return the updateUserID
	 */
	public String getUpdateUserID() {
		return updateUserID;
	}
	/**
	 * @param updateUserID the updateUserID to set
	 */
	public void setUpdateUserID(String updateUserID) {
		this.updateUserID = updateUserID;
	}	
}
