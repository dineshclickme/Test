package com.aig.nge.bo;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

public class UserPrefBO {
	
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String loginUserID;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String currency;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String productTower;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String workingBranch;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String workingCountryBranch;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String currencyHidden;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String workingBranchHidden;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String workingCountryBranchHidden;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String productTowerHidden;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String dateFormat;
	/*PI3 - Aug release - Add Low goverance attribute in user prefernce starts */
	private List<String> preferredAttribute;
	
	private List<UnderwriterSearchResBO1> preferredUnderWriter;
	
	public String getProductTowerHidden() {
		return productTowerHidden;
	}
	public void setProductTowerHidden(String productTowerHidden) {
		this.productTowerHidden = productTowerHidden;
	}
	private List<ProducerEntitySearchRespBO> producerEntityData;
	
	 // Q2 May 2018 - Maintenance release - Preferred underwriter List Changes starts
	
	public List<UnderwriterSearchResBO1> getPreferredUnderWriter() {
		return preferredUnderWriter;
	}
	public void setPreferredUnderWriter(
			List<UnderwriterSearchResBO1> preferredUnderWriter) {
		this.preferredUnderWriter = preferredUnderWriter;
	}
	
	 // Q2 May 2018 - Maintenance release - Preferred underwriter List Changes ends
	
	public List<ProducerEntitySearchRespBO> getProducerEntityData() {
		return producerEntityData;
	}
	public void setProducerEntityData(
			List<ProducerEntitySearchRespBO> producerEntityData) {
		this.producerEntityData = producerEntityData;
	}
	
	
	public String getCurrency() {
		return currency;
	}
	/**
	 * @param currency the currency to set
	 */
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	/**
	 * @return the productTower
	 */
	public String getProductTower() {
		return productTower;
	}
	/**
	 * @param productTower the productTower to set
	 */
	public void setProductTower(String productTower) {
		this.productTower = productTower;
	}
	/**
	 * @return the workingBranch
	 */
	public String getWorkingBranch() {
		return workingBranch;
	}
	/**
	 * @param workingBranch the workingBranch to set
	 */
	public void setWorkingBranch(String workingBranch) {
		this.workingBranch = workingBranch;
	}
	/**
	 * @return the workingCountryBranch
	 */
	public String getWorkingCountryBranch() {
		return workingCountryBranch;
	}
	/**
	 * @param workingCountryBranch the workingCountryBranch to set
	 */
	public void setWorkingCountryBranch(String workingCountryBranch) {
		this.workingCountryBranch = workingCountryBranch;
	}
	public String getLoginUserID() {
		return loginUserID;
	}
	public void setLoginUserID(String loginUserID) {
		this.loginUserID = loginUserID;
	}
	public String getCurrencyHidden() {
		return currencyHidden;
	}
	public void setCurrencyHidden(String currencyHidden) {
		this.currencyHidden = currencyHidden;
	}
	public String getWorkingBranchHidden() {
		return workingBranchHidden;
	}
	public void setWorkingBranchHidden(String workingBranchHidden) {
		this.workingBranchHidden = workingBranchHidden;
	}
	public String getWorkingCountryBranchHidden() {
		return workingCountryBranchHidden;
	}
	public void setWorkingCountryBranchHidden(String workingCountryBranchHidden) {
		this.workingCountryBranchHidden = workingCountryBranchHidden;
	}
	public String getDateFormat() {
		return dateFormat;
	}
	public void setDateFormat(String dateFormat) {
		this.dateFormat = dateFormat;
	}
	
	public List<String> getPreferredAttribute() {
		return preferredAttribute;
	}
	public void setPreferredAttribute(List<String> preferredAttribute) {
		this.preferredAttribute = preferredAttribute;
	}
		
}
