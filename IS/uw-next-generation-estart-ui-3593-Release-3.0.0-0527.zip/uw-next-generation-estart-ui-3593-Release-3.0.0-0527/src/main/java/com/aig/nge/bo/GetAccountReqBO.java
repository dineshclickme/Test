/**
 * 
 */
package com.aig.nge.bo;

import com.fasterxml.jackson.annotation.JsonInclude;


/**
 * @author Bennym
 *
 */
public class GetAccountReqBO {
	
	@JsonInclude(JsonInclude.Include.ALWAYS)
    private IdentityBO identity;
	@JsonInclude(JsonInclude.Include.ALWAYS)
    private GetAccountRequestDataBO request;
	
	/**
	 * @return the identity
	 */
	public IdentityBO getIdentity() {
		return identity;
	}
	/**
	 * @param identity the identity to set
	 */
	public void setIdentity(IdentityBO identity) {
		this.identity = identity;
	}
	/**
	 * @return the request
	 */
	public GetAccountRequestDataBO getRequest() {
		return request;
	}
	/**
	 * @param request the request to set
	 */
	public void setRequest(GetAccountRequestDataBO request) {
		this.request = request;
	}
    
}
