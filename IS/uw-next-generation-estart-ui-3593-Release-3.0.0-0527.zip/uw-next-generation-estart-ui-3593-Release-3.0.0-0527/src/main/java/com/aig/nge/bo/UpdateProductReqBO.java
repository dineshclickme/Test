package com.aig.nge.bo;


public class UpdateProductReqBO {
    /**
	 * @return the transactionId
	 */
	public String getTransactionId() {
		return transactionId;
	}
	/**
	 * @param transactionId the transactionId to set
	 */
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	/**
	 * @return the transactionVersionNo
	 */
	public String getTransactionVersionNo() {
		return transactionVersionNo;
	}
	/**
	 * @param transactionVersionNo the transactionVersionNo to set
	 */
	public void setTransactionVersionNo(String transactionVersionNo) {
		this.transactionVersionNo = transactionVersionNo;
	}
	/**
	 * @return the products
	 */
	public UpdateProductDetailsBO getProducts() {
		return products;
	}
	/**
	 * @param products the products to set
	 */
	public void setProducts(UpdateProductDetailsBO products) {
		this.products = products;
	}
	private String transactionId;
    private String transactionVersionNo;
    private UpdateProductDetailsBO products;
}
