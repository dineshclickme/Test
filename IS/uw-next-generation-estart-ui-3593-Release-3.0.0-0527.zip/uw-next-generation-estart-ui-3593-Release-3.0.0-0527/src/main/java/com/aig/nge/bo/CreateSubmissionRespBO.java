package com.aig.nge.bo;

import java.util.List;


public class CreateSubmissionRespBO {
	
	private String submissionNo;    
	private TransactionRespBO transaction;
	private List<MessageDetailsBO> serviceMessages;
	/**
	 * @return the serviceMessages
	 */
	public List<MessageDetailsBO> getServiceMessages() {
		return serviceMessages;
	}
	/**
	 * @param serviceMessages the serviceMessages to set
	 */
	public void setServiceMessages(List<MessageDetailsBO> serviceMessages) {
		this.serviceMessages = serviceMessages;
	}
	/**
	 * @return the submissionNo
	 */
	public String getSubmissionNo() {
		return submissionNo;
	}
	/**
	 * @param submissionNo the submissionNo to set
	 */
	public void setSubmissionNo(String submissionNo) {
		this.submissionNo = submissionNo;
	}
	/**
	 * @return the transaction
	 */
	public TransactionRespBO getTransaction() {
		return transaction;
	}
	/**
	 * @param transaction the transaction to set
	 */
	public void setTransaction(TransactionRespBO transaction) {
		this.transaction = transaction;
	}
    
}
