package com.aig.nge.bo;

public class AgentDetailTypeBO {
	private String agentId;
	private String producerindividualname;
	private String npn;
	private String locationaddress;
	private String status;
	
	public String getAgentId() {
		return agentId;
	}
	public void setAgentId(String agentId) {
		this.agentId = agentId;
	}
	public String getProducerindividualname() {
		return producerindividualname;
	}
	public void setProducerindividualname(String producerindividualname) {
		this.producerindividualname = producerindividualname;
	}
	public String getNpn() {
		return npn;
	}
	public void setNpn(String npn) {
		this.npn = npn;
	}
	public String getLocationaddress() {
		return locationaddress;
	}
	public void setLocationaddress(String locationaddress) {
		this.locationaddress = locationaddress;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	
}
