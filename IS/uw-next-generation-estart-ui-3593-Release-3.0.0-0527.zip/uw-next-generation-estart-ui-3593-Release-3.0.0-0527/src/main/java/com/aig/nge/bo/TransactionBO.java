package com.aig.nge.bo;

import java.util.List;

public class TransactionBO {
	
	private String transactionId;
	private transactionProducerDetailsBO  transactionProducer;
	private AddressDetailsBO addressDet;
	private AgentDtailsBO agentDet;
	private String underwriterId;
	private CreditedBranchBO creditBranch;
	private String marketSegmentCode;
	private String marketSegmentNm;
	private BrokerBO brokerDet;
	private List<TransactionVersionBO> transactionVersion;
	
	public String getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	public transactionProducerDetailsBO getTransactionProducer() {
		return transactionProducer;
	}
	public void setTransactionProducer(
			transactionProducerDetailsBO transactionProducer) {
		this.transactionProducer = transactionProducer;
	}
	public AddressDetailsBO getAddressDet() {
		return addressDet;
	}
	public void setAddressDet(AddressDetailsBO addressDet) {
		this.addressDet = addressDet;
	}
	public AgentDtailsBO getAgentDet() {
		return agentDet;
	}
	public void setAgentDet(AgentDtailsBO agentDet) {
		this.agentDet = agentDet;
	}
	public String getUnderwriterId() {
		return underwriterId;
	}
	public void setUnderwriterId(String underwriterId) {
		this.underwriterId = underwriterId;
	}
	public CreditedBranchBO getCreditBranch() {
		return creditBranch;
	}
	public void setCreditBranch(CreditedBranchBO creditBranch) {
		this.creditBranch = creditBranch;
	}
	public String getMarketSegmentCode() {
		return marketSegmentCode;
	}
	public void setMarketSegmentCode(String marketSegmentCode) {
		this.marketSegmentCode = marketSegmentCode;
	}
	public String getMarketSegmentNm() {
		return marketSegmentNm;
	}
	public void setMarketSegmentNm(String marketSegmentNm) {
		this.marketSegmentNm = marketSegmentNm;
	}
	public BrokerBO getBrokerDet() {
		return brokerDet;
	}
	public void setBrokerDet(BrokerBO brokerDet) {
		this.brokerDet = brokerDet;
	}
	public List<TransactionVersionBO> getTransactionVersion() {
		return transactionVersion;
	}
	public void setTransactionVersion(List<TransactionVersionBO> transactionVersion) {
		this.transactionVersion = transactionVersion;
	}
	
	
	

}
