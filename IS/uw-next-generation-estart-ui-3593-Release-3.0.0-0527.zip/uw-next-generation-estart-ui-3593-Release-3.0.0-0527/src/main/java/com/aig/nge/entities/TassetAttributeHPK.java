package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the TASSET_ATTRIBUTE_HS database table.
 * 
 */
@Embeddable
public class TassetAttributeHPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="ASSET_ID")
	private int assetId;

	@Column(name="ATTRIBUTE_ID")
	private short attributeId;

	@Column(name="ATTRIBUTE_SQN")
	private short attributeSqn;

    @Temporal( TemporalType.TIMESTAMP)
	@Column(name="CREATE_HISTORY_TS")
	private java.util.Date createHistoryTs;

    public TassetAttributeHPK() {
    }
	public int getAssetId() {
		return this.assetId;
	}
	public void setAssetId(int assetId) {
		this.assetId = assetId;
	}
	public short getAttributeId() {
		return this.attributeId;
	}
	public void setAttributeId(short attributeId) {
		this.attributeId = attributeId;
	}
	public short getAttributeSqn() {
		return this.attributeSqn;
	}
	public void setAttributeSqn(short attributeSqn) {
		this.attributeSqn = attributeSqn;
	}
	public java.util.Date getCreateHistoryTs() {
		return this.createHistoryTs;
	}
	public void setCreateHistoryTs(java.util.Date createHistoryTs) {
		this.createHistoryTs = createHistoryTs;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof TassetAttributeHPK)) {
			return false;
		}
		TassetAttributeHPK castOther = (TassetAttributeHPK)other;
		return 
			(this.assetId == castOther.assetId)
			&& (this.attributeId == castOther.attributeId)
			&& (this.attributeSqn == castOther.attributeSqn)
			&& this.createHistoryTs.equals(castOther.createHistoryTs);

    }
    
	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.assetId;
		hash = hash * prime + this.attributeId;
		hash = hash * prime + this.attributeSqn;
		hash = hash * prime + this.createHistoryTs.hashCode();
		
		return hash;
    }
}