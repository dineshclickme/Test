package com.aig.nge.bo;

import java.util.List;

public class MessErrBO {
    private List<MessErrInfoBO> message;
    private String count;
	/**
	 * @return the message
	 */
	public List<MessErrInfoBO> getMessage() {
		return message;
	}
	/**
	 * @param message the message to set
	 */
	public void setMessage(List<MessErrInfoBO> message) {
		this.message = message;
	}
	/**
	 * @return the count
	 */
	public String getCount() {
		return count;
	}
	/**
	 * @param count the count to set
	 */
	public void setCount(String count) {
		this.count = count;
	}
}
