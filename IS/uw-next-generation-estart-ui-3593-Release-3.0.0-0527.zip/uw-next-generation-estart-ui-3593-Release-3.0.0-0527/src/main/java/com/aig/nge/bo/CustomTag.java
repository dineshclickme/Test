package com.aig.nge.bo;

import java.io.Serializable;
public class CustomTag implements Serializable{
	private static final long serialVersionUID = 1L;
	private String searchby;
	public String getSearchby() {
		return searchby;
	}
	public void setSearchby(String searchby) {
		this.searchby = searchby;
	}
	private String submissionNo;
	private String accountNm;
	
	
	public String getSubmissionNo() {
		return submissionNo;
	}
	public void setSubmissionNo(String submissionNo) {
		this.submissionNo = submissionNo;
	}
	public String getAccountNm() {
		return accountNm;
	}
	public void setAccountNm(String accountNm) {
		this.accountNm = accountNm;
	}
	
	
	
	

	

	


}
