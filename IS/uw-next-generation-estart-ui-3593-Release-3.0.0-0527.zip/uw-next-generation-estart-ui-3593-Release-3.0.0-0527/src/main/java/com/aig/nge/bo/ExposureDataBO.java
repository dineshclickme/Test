package com.aig.nge.bo;

import java.util.Set;

public class ExposureDataBO {
	
	private String exposureView;
	private Set<String> exposureEdit;
	public String getExposureView() {
		return exposureView;
	}
	public void setExposureView(String exposureView) {
		this.exposureView = exposureView;
	}
	public Set<String> getExposureEdit() {
		return exposureEdit;
	}
	public void setExposureEdit(Set<String> exposureEdit) {
		this.exposureEdit = exposureEdit;
	}
		
	
}
