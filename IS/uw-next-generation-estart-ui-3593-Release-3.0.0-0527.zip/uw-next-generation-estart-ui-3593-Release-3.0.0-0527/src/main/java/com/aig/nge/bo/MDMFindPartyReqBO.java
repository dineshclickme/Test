package com.aig.nge.bo;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL) 
public class MDMFindPartyReqBO {
	/* F56355 - Modify request parameter names for MDM services - starts */
	private String originatingsystem;
	/* F56355 - Modify request parameter names for MDM services - ends */
	private String searchcriteria;
	private String searchtext;
	private String searchmode;
	private Integer pagesize;
	private Integer pagenumber;
	private String countrycode;
	private String statecode;
	private String cityname;
	private List<String> accountuniversetype;
	private List<String> treeposition;
	private String legacyindicator;
	private String activeindicator;
	/* F56355 - Modify request parameter names for MDM services - starts */
	public String getOriginatingsystem() {
		return originatingsystem;
	}
	public void setOriginatingsystem(String originatingsystem) {
		this.originatingsystem = originatingsystem;
	}
	/* F56355 - Modify request parameter names for MDM services - ends */
	public String getSearchcriteria() {
		return searchcriteria;
	}
	public void setSearchcriteria(String searchcriteria) {
		this.searchcriteria = searchcriteria;
	}
	public String getSearchtext() {
		return searchtext;
	}
	public void setSearchtext(String searchtext) {
		this.searchtext = searchtext;
	}
	public String getSearchmode() {
		return searchmode;
	}
	public void setSearchmode(String searchmode) {
		this.searchmode = searchmode;
	}
	
	public String getCountrycode() {
		return countrycode;
	}
	public void setCountrycode(String countrycode) {
		this.countrycode = countrycode;
	}
	public String getStatecode() {
		return statecode;
	}
	public void setStatecode(String statecode) {
		this.statecode = statecode;
	}
	
	
	public Integer getPagesize() {
		return pagesize;
	}
	public void setPagesize(Integer pagesize) {
		this.pagesize = pagesize;
	}
	
	public String getLegacyindicator() {
		return legacyindicator;
	}
	public void setLegacyindicator(String legacyindicator) {
		this.legacyindicator = legacyindicator;
	}
	public String getActiveindicator() {
		return activeindicator;
	}
	public void setActiveindicator(String activeindicator) {
		this.activeindicator = activeindicator;
	}
	public List<String> getAccountuniversetype() {
		return accountuniversetype;
	}
	public void setAccountuniversetype(List<String> accountuniversetype) {
		this.accountuniversetype = accountuniversetype;
	}
	public List<String> getTreeposition() {
		return treeposition;
	}
	public void setTreeposition(List<String> treeposition) {
		this.treeposition = treeposition;
	}
	public Integer getPagenumber() {
		return pagenumber;
	}
	public void setPagenumber(Integer pagenumber) {
		this.pagenumber = pagenumber;
	}
	public String getCityname() {
		return cityname;
	}
	public void setCityname(String cityname) {
		this.cityname = cityname;
	}
	
}
