package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the TATTRIBUTE_GROUP database table.
 * 
 */
@Embeddable
public class TattributeGroupPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="ATTRIBUTE_ID")
	private short attributeId;

	@Column(name="GROUP_ID")
	private short groupId;

    public TattributeGroupPK() {
    }
	public short getAttributeId() {
		return this.attributeId;
	}
	public void setAttributeId(short attributeId) {
		this.attributeId = attributeId;
	}
	public short getGroupId() {
		return this.groupId;
	}
	public void setGroupId(short groupId) {
		this.groupId = groupId;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof TattributeGroupPK)) {
			return false;
		}
		TattributeGroupPK castOther = (TattributeGroupPK)other;
		return 
			(this.attributeId == castOther.attributeId)
			&& (this.groupId == castOther.groupId);

    }
    
	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.attributeId;
		hash = hash * prime + this.groupId;
		
		return hash;
    }
}