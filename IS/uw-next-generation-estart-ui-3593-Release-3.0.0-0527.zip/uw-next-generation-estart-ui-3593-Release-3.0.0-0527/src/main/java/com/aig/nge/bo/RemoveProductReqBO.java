package com.aig.nge.bo;

import java.util.List;

public class RemoveProductReqBO {
	    /**
	 * @return the transactionId
	 */
	public String getTransactionId() {
		return transactionId;
	}
	/**
	 * @param transactionId the transactionId to set
	 */
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	/**
	 * @return the transactionVersionNo
	 */
	public String getTransactionVersionNo() {
		return transactionVersionNo;
	}
	/**
	 * @param transactionVersionNo the transactionVersionNo to set
	 */
	public void setTransactionVersionNo(String transactionVersionNo) {
		this.transactionVersionNo = transactionVersionNo;
	}
	/**
	 * @return the product
	 */
	public List<ProductBO> getProduct() {
		return product;
	}
	/**
	 * @param product the product to set
	 */
	public void setProduct(List<ProductBO> product) {
		this.product = product;
	}
		private String transactionId;
	    private String transactionVersionNo;
	    private List<ProductBO> product;
}
