package com.aig.nge.bo;

import java.util.Comparator;
import java.util.List;
import java.util.Map;

public class ExposureTypeWorldWideBO {
	private String id;
	private String text;
	private Map<String,String> state;
	private List<ExposureTypeChildrenBO> children; 
	public static Comparator<ExposureTypeWorldWideBO> expoWorldWideCompartor = new Comparator<ExposureTypeWorldWideBO>() {

		public int compare(ExposureTypeWorldWideBO child1, ExposureTypeWorldWideBO child2) {
			//ascending order
			return child1.getText().compareTo(child2.getText());
		}

	};
	
	public List<ExposureTypeChildrenBO> getChildren() {
		return children;
	}
	public void setChildren(List<ExposureTypeChildrenBO> children) {
		this.children = children;
	}
	public Map<String, String> getState() {
		return state;
	}
	public void setState(Map<String, String> state) {
		this.state = state;
	}
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}
	
}
