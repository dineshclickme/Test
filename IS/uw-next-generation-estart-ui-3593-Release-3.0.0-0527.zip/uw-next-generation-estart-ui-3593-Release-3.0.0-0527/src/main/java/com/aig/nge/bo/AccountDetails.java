package com.aig.nge.bo;

public class AccountDetails {

	private String accountName;
	private String dandbNumber;
	private String parentDandBNumber;
	private String accountType;
	private String accountStatus;
	private String location;
	private String fein;
	private String revisedDandBNumber;
	//MDM Changes - Starts
	private String mdmPartyId;
	private String parentMDMPartyId;
	private String revisedMDMPartyId;
	//MDM Changes - Ends
	/**
	 * @return the fein
	 */
	public String getFein() {
		return fein;
	}
	/**
	 * @param fein the fein to set
	 */
	public void setFein(String fein) {
		this.fein = fein;
	}
	/**
	 * @return the revisedDandBNumber
	 */
	public String getRevisedDandBNumber() {
		return revisedDandBNumber;
	}
	/**
	 * @param revisedDandBNumber the revisedDandBNumber to set
	 */
	public void setRevisedDandBNumber(String revisedDandBNumber) {
		this.revisedDandBNumber = revisedDandBNumber;
	}
	/**
	 * @return the accountName
	 */
	public String getAccountName() {
		return accountName;
	}
	/**
	 * @param accountName the accountName to set
	 */
	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}
	/**
	 * @return the dandbNumber
	 */
	public String getDandbNumber() {
		return dandbNumber;
	}
	/**
	 * @param dandbNumber the dandbNumber to set
	 */
	public void setDandbNumber(String dandbNumber) {
		this.dandbNumber = dandbNumber;
	}
	/**
	 * @return the parentDandBNumber
	 */
	public String getParentDandBNumber() {
		return parentDandBNumber;
	}
	/**
	 * @param parentDandBNumber the parentDandBNumber to set
	 */
	public void setParentDandBNumber(String parentDandBNumber) {
		this.parentDandBNumber = parentDandBNumber;
	}
	/**
	 * @return the accountType
	 */
	public String getAccountType() {
		return accountType;
	}
	/**
	 * @param accountType the accountType to set
	 */
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	/**
	 * @return the accountStatus
	 */
	public String getAccountStatus() {
		return accountStatus;
	}
	/**
	 * @param accountStatus the accountStatus to set
	 */
	public void setAccountStatus(String accountStatus) {
		this.accountStatus = accountStatus;
	}
	/**
	 * @return the location
	 */
	public String getLocation() {
		return location;
	}
	/**
	 * @param location the location to set
	 */
	public void setLocation(String location) {
		this.location = location;
	}
	//MDM Changes - Starts
	public String getMdmPartyId() {
		return mdmPartyId;
	}
	public void setMdmPartyId(String mdmPartyId) {
		this.mdmPartyId = mdmPartyId;
	}
	public String getParentMDMPartyId() {
		return parentMDMPartyId;
	}
	public void setParentMDMPartyId(String parentMDMPartyId) {
		this.parentMDMPartyId = parentMDMPartyId;
	}
	public String getRevisedMDMPartyId() {
		return revisedMDMPartyId;
	}
	public void setRevisedMDMPartyId(String revisedMDMPartyId) {
		this.revisedMDMPartyId = revisedMDMPartyId;
	}
	//MDM Changes - Ends
}
