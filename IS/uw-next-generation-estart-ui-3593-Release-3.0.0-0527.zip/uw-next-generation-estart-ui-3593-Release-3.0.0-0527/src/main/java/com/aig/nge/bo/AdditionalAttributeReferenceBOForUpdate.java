package com.aig.nge.bo;

import java.util.List;

public class AdditionalAttributeReferenceBOForUpdate {
	
	private List<Object> data;

	public List<Object> getData() {
		return data;
	}

	public void setData(List<Object> data) {
		this.data = data;
	}


}
