package com.aig.nge.bo;

import java.util.ArrayList;
import java.util.List;

public class CASLAuthorizeBO {
	private String firstName;
	private String lastName;
	private String userName;
	private String userCountry;
	private String userRole;
	private String userAction;
	private String emailID;
	private List<CASLuserapplicationdetailsBO> userApplicationDetails;
	private String home = "Yes";
	private String submissionSearch = "Yes";
	private String accoutnSearch = "Yes";
	private String producerSearch = "Yes";
	private String blockDetails = "Yes";
	private String createSubmission = "Yes";
	private String viewmanageSubmission = "Yes";
	private String bulkTransfer = "Yes";
	private String diary = "Yes";
	private String globalsubmissionSearch = "Yes";
	private String languageSelection = "Yes";
	private String help = "Yes";
	private String logout = "Yes";
	private String createTransaction = "Yes";
	private String addProduct = "Yes";
	private String defaultView = "Yes";
	private String printView = "Yes";
	private String createnewVersion = "Yes";
	private String transfersingleProduct = "Yes";
	private String viewreleaseblock = "Yes";
	private String editTransaction = "Yes";
	private String copyTransaction = "Yes";
	private String editProducts = "Yes";
	private String renewProducts = "Yes";
	private String bindTransaction = "Yes";
	private String unbindTransaction = "Yes";
	private String updateTransaction = "Yes";
	private String updateProducts = "Yes";
	private String reopenProducts = "Yes";
	private String releasebuttonproductBlock = "Yes";
	private String releasebuttonalertBlock = "Yes";
	private String emailiconproductBlock = "Yes";
	private String emailiconalertBlock = "Yes";
	private String addshellAccount = "Yes";
	private String blockSearch = "Yes";
	private String userPreference = "Yes";
	private String releasebuttonblocksearchproductBlock = "Yes";
	private String releasebuttonblocksearchalertBlock = "Yes";
	private String ismanager;
	private String isunderwriter;
	private String isassistant;
	private String iscaslfailure;
	private ArrayList<String> actionList = new ArrayList<String>();
	
	public String getIscaslfailure() {
		return iscaslfailure;
	}
	public ArrayList<String> getActionList() {
		return actionList;
	}
	public void setActionList(ArrayList<String> actionList) {
		this.actionList = actionList;
	}
	public void setIscaslfailure(String iscaslfailure) {
		this.iscaslfailure = iscaslfailure;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getUserCountry() {
		return userCountry;
	}
	public void setUserCountry(String userCountry) {
		this.userCountry = userCountry;
	}
	public String getEmailID() {
		return emailID;
	}
	public void setEmailID(String emailID) {
		this.emailID = emailID;
	}
	public List<CASLuserapplicationdetailsBO> getUserApplicationDetails() {
		return userApplicationDetails;
	}
	public void setUserApplicationDetails(
			List<CASLuserapplicationdetailsBO> userApplicationDetails) {
		this.userApplicationDetails = userApplicationDetails;
	}
	public String getHome() {
		return home;
	}
	public void setHome(String home) {
		this.home = home;
	}
	public String getSubmissionSearch() {
		return submissionSearch;
	}
	public void setSubmissionSearch(String submissionSearch) {
		this.submissionSearch = submissionSearch;
	}
	public String getAccoutnSearch() {
		return accoutnSearch;
	}
	public void setAccoutnSearch(String accoutnSearch) {
		this.accoutnSearch = accoutnSearch;
	}
	public String getProducerSearch() {
		return producerSearch;
	}
	public void setProducerSearch(String producerSearch) {
		this.producerSearch = producerSearch;
	}
	public String getBlockDetails() {
		return blockDetails;
	}
	public void setBlockDetails(String blockDetails) {
		this.blockDetails = blockDetails;
	}
	public String getCreateSubmission() {
		return createSubmission;
	}
	public void setCreateSubmission(String createSubmission) {
		this.createSubmission = createSubmission;
	}
	public String getViewmanageSubmission() {
		return viewmanageSubmission;
	}
	public void setViewmanageSubmission(String viewmanageSubmission) {
		this.viewmanageSubmission = viewmanageSubmission;
	}
	public String getBulkTransfer() {
		return bulkTransfer;
	}
	public void setBulkTransfer(String bulkTransfer) {
		this.bulkTransfer = bulkTransfer;
	}
	public String getDiary() {
		return diary;
	}
	public void setDiary(String diary) {
		this.diary = diary;
	}
	public String getGlobalsubmissionSearch() {
		return globalsubmissionSearch;
	}
	public void setGlobalsubmissionSearch(String globalsubmissionSearch) {
		this.globalsubmissionSearch = globalsubmissionSearch;
	}
	public String getLanguageSelection() {
		return languageSelection;
	}
	public void setLanguageSelection(String languageSelection) {
		this.languageSelection = languageSelection;
	}
	public String getHelp() {
		return help;
	}
	public void setHelp(String help) {
		this.help = help;
	}
	public String getLogout() {
		return logout;
	}
	public void setLogout(String logout) {
		this.logout = logout;
	}
	public String getCreateTransaction() {
		return createTransaction;
	}
	public void setCreateTransaction(String createTransaction) {
		this.createTransaction = createTransaction;
	}
	public String getAddProduct() {
		return addProduct;
	}
	public void setAddProduct(String addProduct) {
		this.addProduct = addProduct;
	}
	public String getDefaultView() {
		return defaultView;
	}
	public void setDefaultView(String defaultView) {
		this.defaultView = defaultView;
	}
	public String getPrintView() {
		return printView;
	}
	public void setPrintView(String printView) {
		this.printView = printView;
	}
	public String getCreatenewVersion() {
		return createnewVersion;
	}
	public void setCreatenewVersion(String createnewVersion) {
		this.createnewVersion = createnewVersion;
	}
	public String getTransfersingleProduct() {
		return transfersingleProduct;
	}
	public void setTransfersingleProduct(String transfersingleProduct) {
		this.transfersingleProduct = transfersingleProduct;
	}
	public String getViewreleaseblock() {
		return viewreleaseblock;
	}
	public void setViewreleaseblock(String viewreleaseblock) {
		this.viewreleaseblock = viewreleaseblock;
	}
	public String getEditTransaction() {
		return editTransaction;
	}
	public void setEditTransaction(String editTransaction) {
		this.editTransaction = editTransaction;
	}
	public String getCopyTransaction() {
		return copyTransaction;
	}
	public void setCopyTransaction(String copyTransaction) {
		this.copyTransaction = copyTransaction;
	}
	public String getEditProducts() {
		return editProducts;
	}
	public void setEditProducts(String editProducts) {
		this.editProducts = editProducts;
	}
	public String getRenewProducts() {
		return renewProducts;
	}
	public void setRenewProducts(String renewProducts) {
		this.renewProducts = renewProducts;
	}
	public String getBindTransaction() {
		return bindTransaction;
	}
	public void setBindTransaction(String bindTransaction) {
		this.bindTransaction = bindTransaction;
	}
	public String getUnbindTransaction() {
		return unbindTransaction;
	}
	public void setUnbindTransaction(String unbindTransaction) {
		this.unbindTransaction = unbindTransaction;
	}
	public String getUpdateTransaction() {
		return updateTransaction;
	}
	public void setUpdateTransaction(String updateTransaction) {
		this.updateTransaction = updateTransaction;
	}
	public String getUpdateProducts() {
		return updateProducts;
	}
	public void setUpdateProducts(String updateProducts) {
		this.updateProducts = updateProducts;
	}
	public String getReopenProducts() {
		return reopenProducts;
	}
	public void setReopenProducts(String reopenProducts) {
		this.reopenProducts = reopenProducts;
	}
	public String getReleasebuttonproductBlock() {
		return releasebuttonproductBlock;
	}
	public void setReleasebuttonproductBlock(String releasebuttonproductBlock) {
		this.releasebuttonproductBlock = releasebuttonproductBlock;
	}
	public String getReleasebuttonalertBlock() {
		return releasebuttonalertBlock;
	}
	public void setReleasebuttonalertBlock(String releasebuttonalertBlock) {
		this.releasebuttonalertBlock = releasebuttonalertBlock;
	}
	public String getEmailiconproductBlock() {
		return emailiconproductBlock;
	}
	public void setEmailiconproductBlock(String emailiconproductBlock) {
		this.emailiconproductBlock = emailiconproductBlock;
	}
	public String getEmailiconalertBlock() {
		return emailiconalertBlock;
	}
	public void setEmailiconalertBlock(String emailiconalertBlock) {
		this.emailiconalertBlock = emailiconalertBlock;
	}
	public String getAddshellAccount() {
		return addshellAccount;
	}
	public void setAddshellAccount(String addshellAccount) {
		this.addshellAccount = addshellAccount;
	}
	public String getBlockSearch() {
		return blockSearch;
	}
	public void setBlockSearch(String blockSearch) {
		this.blockSearch = blockSearch;
	}
	public String getReleasebuttonblocksearchproductBlock() {
		return releasebuttonblocksearchproductBlock;
	}
	public void setReleasebuttonblocksearchproductBlock(
			String releasebuttonblocksearchproductBlock) {
		this.releasebuttonblocksearchproductBlock = releasebuttonblocksearchproductBlock;
	}
	public String getReleasebuttonblocksearchalertBlock() {
		return releasebuttonblocksearchalertBlock;
	}
	public void setReleasebuttonblocksearchalertBlock(
			String releasebuttonblocksearchalertBlock) {
		this.releasebuttonblocksearchalertBlock = releasebuttonblocksearchalertBlock;
	}
	public String getIsmanager() {
		return ismanager;
	}
	public void setIsmanager(String ismanager) {
		this.ismanager = ismanager;
	}
	public String getIsunderwriter() {
		return isunderwriter;
	}
	public void setIsunderwriter(String isunderwriter) {
		this.isunderwriter = isunderwriter;
	}
	public String getIsassistant() {
		return isassistant;
	}
	public void setIsassistant(String isassistant) {
		this.isassistant = isassistant;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserRole() {
		return userRole;
	}
	public void setUserRole(String userRole) {
		this.userRole = userRole;
	}
	public String getUserAction() {
		return userAction;
	}
	public void setUserAction(String userAction) {
		this.userAction = userAction;
	}
	public String getUserPreference() {
		return userPreference;
	}
	public void setUserPreference(String userPreference) {
		this.userPreference = userPreference;
	}
	
}
