package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Set;


/**
 * The persistent class for the TEXTRACT database table.
 * 
 */
@Entity
public class Textract implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="EXTRACT_NM")
	private String extractNm;

	@Column(name="CREATE_TS")
	private Timestamp createTs;

	@Column(name="CREATE_USER_ID")
	private String createUserId;

	@Column(name="EXTRACT_DS")
	private String extractDs;

	@Column(name="UPDATE_TS")
	private Timestamp updateTs;

	@Column(name="UPDATE_USER_ID")
	private String updateUserId;

	//bi-directional many-to-one association to TextractAttribute
	@OneToMany(mappedBy="textract", cascade={CascadeType.ALL})
	private Set<TextractAttribute> textractAttributes;

    public Textract() {
    }

	public String getExtractNm() {
		return this.extractNm;
	}

	public void setExtractNm(String extractNm) {
		this.extractNm = extractNm;
	}

	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public String getExtractDs() {
		return this.extractDs;
	}

	public void setExtractDs(String extractDs) {
		this.extractDs = extractDs;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public Set<TextractAttribute> getTextractAttributes() {
		return this.textractAttributes;
	}

	public void setTextractAttributes(Set<TextractAttribute> textractAttributes) {
		this.textractAttributes = textractAttributes;
	}
	
}