package com.aig.nge.bo;

import java.io.Serializable;

public class WidgetOptions implements Serializable{
	private static final long serialVersionUID = 1L;
	private String maxlength;
	private Boolean header;
	private String height;
	private Integer selectedList;
	
	private String noneSelectedText;

	public String getMaxlength() {
		return maxlength;
	}

	public void setMaxlength(String maxlength) {
		this.maxlength = maxlength;
	}

	public String getHeight() {
		return height;
	}

	public void setHeight(String height) {
		this.height = height;
	}

	public String getNoneSelectedText() {
		return noneSelectedText;
	}

	public void setNoneSelectedText(String noneSelectedText) {
		this.noneSelectedText = noneSelectedText;
	}

	public Boolean getHeader() {
		return header;
	}

	public void setHeader(Boolean header) {
		this.header = header;
	}

	public Integer getSelectedList() {
		return selectedList;
	}

	public void setSelectedList(Integer selectedList) {
		this.selectedList = selectedList;
	}
}
