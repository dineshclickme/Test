package com.aig.nge.bo;

import java.io.Serializable;

public class EventReferenceDataBO implements Serializable{
	private static final long serialVersionUID = 1L;
	private String type;
	private String	handler;
	
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getHandler() {
		return handler;
	}
	public void setHandler(String handler) {
		this.handler = handler;
	}
}
