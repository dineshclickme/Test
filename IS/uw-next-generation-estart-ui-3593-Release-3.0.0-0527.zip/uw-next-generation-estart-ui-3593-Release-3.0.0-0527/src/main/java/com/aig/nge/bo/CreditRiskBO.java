package com.aig.nge.bo;


public class CreditRiskBO {
    private String creditRiskClass;
    private String creditRiskPercentile;
    private String creditRiskScore;
    private String changeDate;
    private String prevRiskClass;
	/**
	 * @return the creditRiskClass
	 */
	public String getCreditRiskClass() {
		return creditRiskClass;
	}
	/**
	 * @param creditRiskClass the creditRiskClass to set
	 */
	public void setCreditRiskClass(String creditRiskClass) {
		this.creditRiskClass = creditRiskClass;
	}
	/**
	 * @return the creditRiskPercentile
	 */
	public String getCreditRiskPercentile() {
		return creditRiskPercentile;
	}
	/**
	 * @param creditRiskPercentile the creditRiskPercentile to set
	 */
	public void setCreditRiskPercentile(String creditRiskPercentile) {
		this.creditRiskPercentile = creditRiskPercentile;
	}
	/**
	 * @return the creditRiskScore
	 */
	public String getCreditRiskScore() {
		return creditRiskScore;
	}
	/**
	 * @param creditRiskScore the creditRiskScore to set
	 */
	public void setCreditRiskScore(String creditRiskScore) {
		this.creditRiskScore = creditRiskScore;
	}
	/**
	 * @return the changeDate
	 */
	public String getChangeDate() {
		return changeDate;
	}
	/**
	 * @param changeDate the changeDate to set
	 */
	public void setChangeDate(String changeDate) {
		this.changeDate = changeDate;
	}
	/**
	 * @return the prevRiskClass
	 */
	public String getPrevRiskClass() {
		return prevRiskClass;
	}
	/**
	 * @param prevRiskClass the prevRiskClass to set
	 */
	public void setPrevRiskClass(String prevRiskClass) {
		this.prevRiskClass = prevRiskClass;
	}
}
