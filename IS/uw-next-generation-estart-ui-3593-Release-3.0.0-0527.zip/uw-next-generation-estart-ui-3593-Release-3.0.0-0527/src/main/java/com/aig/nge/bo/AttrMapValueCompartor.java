package com.aig.nge.bo;

import java.util.Comparator;
import java.util.Map;

public class AttrMapValueCompartor implements Comparator{

	 Map map;
	 
	    public AttrMapValueCompartor(Map base) {
	        this.map = base;
	    }
	 
	    public int compare(Object a, Object b) {
	    	AttributeRefereceBOForUpdate comparableA=(AttributeRefereceBOForUpdate)map.get(a);
	    	AttributeRefereceBOForUpdate comparableB=(AttributeRefereceBOForUpdate)map.get(b);
	    	
	        if (comparableA.isRequired() && !comparableB.isRequired()) {
	            return 1;
	        }
			return -1;
	    }
}
