package com.aig.nge.bo;


public class FienInfoBO {
    private String dunsNumber;
    private String dunsBusinessName;
    private String dunsStreetAddress;
    private String dunsState;
    private String dunsTreePosition;
    private String dunsCity;
    private String dunsCountry;
    private String identifierType;
	/**
	 * @return the dunsNumber
	 */
	public String getDunsNumber() {
		return dunsNumber;
	}
	/**
	 * @param dunsNumber the dunsNumber to set
	 */
	public void setDunsNumber(String dunsNumber) {
		this.dunsNumber = dunsNumber;
	}
	/**
	 * @return the dunsBusinessName
	 */
	public String getDunsBusinessName() {
		return dunsBusinessName;
	}
	/**
	 * @param dunsBusinessName the dunsBusinessName to set
	 */
	public void setDunsBusinessName(String dunsBusinessName) {
		this.dunsBusinessName = dunsBusinessName;
	}
	/**
	 * @return the dunsStreetAddress
	 */
	public String getDunsStreetAddress() {
		return dunsStreetAddress;
	}
	/**
	 * @param dunsStreetAddress the dunsStreetAddress to set
	 */
	public void setDunsStreetAddress(String dunsStreetAddress) {
		this.dunsStreetAddress = dunsStreetAddress;
	}
	/**
	 * @return the dunsState
	 */
	public String getDunsState() {
		return dunsState;
	}
	/**
	 * @param dunsState the dunsState to set
	 */
	public void setDunsState(String dunsState) {
		this.dunsState = dunsState;
	}
	/**
	 * @return the dunsTreePosition
	 */
	public String getDunsTreePosition() {
		return dunsTreePosition;
	}
	/**
	 * @param dunsTreePosition the dunsTreePosition to set
	 */
	public void setDunsTreePosition(String dunsTreePosition) {
		this.dunsTreePosition = dunsTreePosition;
	}
	/**
	 * @return the dunsCity
	 */
	public String getDunsCity() {
		return dunsCity;
	}
	/**
	 * @param dunsCity the dunsCity to set
	 */
	public void setDunsCity(String dunsCity) {
		this.dunsCity = dunsCity;
	}
	/**
	 * @return the dunsCountry
	 */
	public String getDunsCountry() {
		return dunsCountry;
	}
	/**
	 * @param dunsCountry the dunsCountry to set
	 */
	public void setDunsCountry(String dunsCountry) {
		this.dunsCountry = dunsCountry;
	}
	/**
	 * @return the identifierType
	 */
	public String getIdentifierType() {
		return identifierType;
	}
	/**
	 * @param identifierType the identifierType to set
	 */
	public void setIdentifierType(String identifierType) {
		this.identifierType = identifierType;
	}
}
