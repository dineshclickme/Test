package com.aig.nge.bo;

public class LinkLicenseRespBO {
	private String responseCd;
	private String responseDesc;
	private ErrorDetailBO errorDetail;
	/**
	 * @return the responseCd
	 */
	public String getResponseCd() {
		return responseCd;
	}
	/**
	 * @param responseCd the responseCd to set
	 */
	public void setResponseCd(String responseCd) {
		this.responseCd = responseCd;
	}
	/**
	 * @return the responseDesc
	 */
	public String getResponseDesc() {
		return responseDesc;
	}
	/**
	 * @param responseDesc the responseDesc to set
	 */
	public void setResponseDesc(String responseDesc) {
		this.responseDesc = responseDesc;
	}
	/**
	 * @return the errorDetail
	 */
	public ErrorDetailBO getErrorDetail() {
		return errorDetail;
	}
	/**
	 * @param errorDetail the errorDetail to set
	 */
	public void setErrorDetail(ErrorDetailBO errorDetail) {
		this.errorDetail = errorDetail;
	}
	
}
