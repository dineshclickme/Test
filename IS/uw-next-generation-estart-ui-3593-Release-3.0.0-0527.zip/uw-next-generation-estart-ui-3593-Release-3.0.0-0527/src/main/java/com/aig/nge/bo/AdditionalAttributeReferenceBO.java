package com.aig.nge.bo;

import java.util.List;

public class AdditionalAttributeReferenceBO {
	
	private List<AttributeReferenceBO> data;

	public List<AttributeReferenceBO> getData() {
		return data;
	}

	public void setData(List<AttributeReferenceBO> data) {
		this.data = data;
	}
	

}
