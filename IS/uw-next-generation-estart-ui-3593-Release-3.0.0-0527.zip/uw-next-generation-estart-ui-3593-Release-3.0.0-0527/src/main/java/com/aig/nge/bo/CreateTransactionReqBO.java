package com.aig.nge.bo;

import com.fasterxml.jackson.annotation.JsonInclude;


public class CreateTransactionReqBO {
	
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String submissionNo;   
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private CreateTransactionBO transaction;
	
    /**
	 * @return the submissionNo
	 */
	public String getSubmissionNo() {
		return submissionNo;
	}
	/**
	 * @param submissionNo the submissionNo to set
	 */
	public void setSubmissionNo(String submissionNo) {
		this.submissionNo = submissionNo;
	}
	/**
	 * @return the transaction
	 */
	public CreateTransactionBO getTransaction() {
		return transaction;
	}
	/**
	 * @param transaction the transaction to set
	 */
	public void setTransaction(CreateTransactionBO transaction) {
		this.transaction = transaction;
	}	
    
}
