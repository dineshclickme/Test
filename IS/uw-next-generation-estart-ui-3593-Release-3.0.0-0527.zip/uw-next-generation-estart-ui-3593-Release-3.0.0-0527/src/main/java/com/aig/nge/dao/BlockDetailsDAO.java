package com.aig.nge.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.aig.nge.entities.Ttransaction;
import com.aig.nge.repository.TtransactionRepository;

@Repository
public class BlockDetailsDAO extends BaseDAO{
	@Autowired
	private TtransactionRepository tTransactionRepository;
	
	public Ttransaction getSubmissionNoDAO(String transactionId){
		Ttransaction ttransaction = tTransactionRepository.getSubmissionNo(transactionId);
		return ttransaction;
	}
}

