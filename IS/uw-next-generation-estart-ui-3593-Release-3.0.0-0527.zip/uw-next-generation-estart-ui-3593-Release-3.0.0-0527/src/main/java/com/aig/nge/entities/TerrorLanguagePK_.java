package com.aig.nge.entities;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-08-04T13:12:21.168+0530")
@StaticMetamodel(TerrorLanguagePK.class)
public class TerrorLanguagePK_ {
	public static volatile SingularAttribute<TerrorLanguagePK, Short> errorId;
	public static volatile SingularAttribute<TerrorLanguagePK, Short> languageId;
}
