package com.aig.nge.bo;


public class AppointmentInfoTypeBO {

	private String appointmentEffDt;
	private String appointmentExpDt;
	private String appointmentStatusCd;
	private String issuingCompanyCd;
	private String lineOfBusinessNm;
	private String updateTimeStamp;
	private String updateUserID;
	/**
	 * @return the appointmentEffDt
	 */
	public String getAppointmentEffDt() {
		return appointmentEffDt;
	}
	/**
	 * @param appointmentEffDt the appointmentEffDt to set
	 */
	public void setAppointmentEffDt(String appointmentEffDt) {
		this.appointmentEffDt = appointmentEffDt;
	}
	/**
	 * @return the appointmentExpDt
	 */
	public String getAppointmentExpDt() {
		return appointmentExpDt;
	}
	/**
	 * @param appointmentExpDt the appointmentExpDt to set
	 */
	public void setAppointmentExpDt(String appointmentExpDt) {
		this.appointmentExpDt = appointmentExpDt;
	}
	/**
	 * @return the appointmentStatusCd
	 */
	public String getAppointmentStatusCd() {
		return appointmentStatusCd;
	}
	/**
	 * @param appointmentStatusCd the appointmentStatusCd to set
	 */
	public void setAppointmentStatusCd(String appointmentStatusCd) {
		this.appointmentStatusCd = appointmentStatusCd;
	}
	/**
	 * @return the issuingCompanyCd
	 */
	public String getIssuingCompanyCd() {
		return issuingCompanyCd;
	}
	/**
	 * @param issuingCompanyCd the issuingCompanyCd to set
	 */
	public void setIssuingCompanyCd(String issuingCompanyCd) {
		this.issuingCompanyCd = issuingCompanyCd;
	}
	/**
	 * @return the lineOfBusinessNm
	 */
	public String getLineOfBusinessNm() {
		return lineOfBusinessNm;
	}
	/**
	 * @param lineOfBusinessNm the lineOfBusinessNm to set
	 */
	public void setLineOfBusinessNm(String lineOfBusinessNm) {
		this.lineOfBusinessNm = lineOfBusinessNm;
	}
	/**
	 * @return the updateTimeStamp
	 */
	public String getUpdateTimeStamp() {
		return updateTimeStamp;
	}
	/**
	 * @param updateTimeStamp the updateTimeStamp to set
	 */
	public void setUpdateTimeStamp(String updateTimeStamp) {
		this.updateTimeStamp = updateTimeStamp;
	}
	/**
	 * @return the updateUserID
	 */
	public String getUpdateUserID() {
		return updateUserID;
	}
	/**
	 * @param updateUserID the updateUserID to set
	 */
	public void setUpdateUserID(String updateUserID) {
		this.updateUserID = updateUserID;
	}	
}
