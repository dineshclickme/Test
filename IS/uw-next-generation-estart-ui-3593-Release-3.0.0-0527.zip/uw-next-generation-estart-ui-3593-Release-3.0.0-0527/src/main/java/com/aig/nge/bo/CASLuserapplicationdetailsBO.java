package com.aig.nge.bo;

import java.util.List;

public class CASLuserapplicationdetailsBO {
	
	private String country;
	private String lob;
	private String subline;
	private List<CASLuserroleBO> userRole;
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getLob() {
		return lob;
	}
	public void setLob(String lob) {
		this.lob = lob;
	}
	public String getSubline() {
		return subline;
	}
	public void setSubline(String subline) {
		this.subline = subline;
	}
	public List<CASLuserroleBO> getUserRole() {
		return userRole;
	}
	public void setUserRole(List<CASLuserroleBO> userRole) {
		this.userRole = userRole;
	}
	
	

}
