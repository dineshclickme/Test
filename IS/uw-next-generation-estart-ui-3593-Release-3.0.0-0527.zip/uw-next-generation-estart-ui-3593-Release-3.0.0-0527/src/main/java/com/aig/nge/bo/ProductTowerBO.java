package com.aig.nge.bo;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

public class ProductTowerBO implements Serializable
{  

	private static final long serialVersionUID = 1L;
	private String group = "";
	private String groupcode = "";
	private List<Map<String,String>> data;  
	public List<Map<String, String>> getData() {    
		return data;
	}
	public void setData(List<Map<String, String>> data) {
		this.data = data;
	}
	public String getGroup() {
		return group;
	}
	public void setGroup(String group) {
		this.group = group;
	}
	public String getGroupcode() {
		return groupcode;
	}
	public void setGroupcode(String groupcode) {
		this.groupcode = groupcode;
	}	
}
