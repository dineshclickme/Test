package com.aig.nge.bo;

import java.util.List;

public class UpdateComponentProductBO {
	protected String segmentCd;
    protected String subSegmentCd;
    protected String marketableProductCd;
    protected String componentProductCd;
    protected String divisionNo;
    protected String sectionCd;
    protected String profitUnitCd;
    protected String majorLineCd;
    protected String minorLineCd;
    protected String classPerilCd;
    protected String majorClassCd;
    protected String productStateCd;
    protected String effectiveDt;
    protected String expirationDt;
    protected String underwriterId;
    protected List<AttributesInfoBO> attributes;
    protected List<BranchBO> branches;
    protected LimitBO limits;
    protected AdditionalInsuredsBO additionalInsureds;
    protected List<AssetBO> assets;
    protected List<PolicyDetailBO> policies;
    protected String componentProductKey;
    protected ExposureCountryBO exposureCountryBO;
    /**
	 * @return the segmentCd
	 */
	public String getSegmentCd() {
		return segmentCd;
	}
	/**
	 * @param segmentCd the segmentCd to set
	 */
	public void setSegmentCd(String segmentCd) {
		this.segmentCd = segmentCd;
	}
	/**
	 * @return the subSegmentCd
	 */
	public String getSubSegmentCd() {
		return subSegmentCd;
	}
	/**
	 * @param subSegmentCd the subSegmentCd to set
	 */
	public void setSubSegmentCd(String subSegmentCd) {
		this.subSegmentCd = subSegmentCd;
	}
	/**
	 * @return the marketableProductCd
	 */
	public String getMarketableProductCd() {
		return marketableProductCd;
	}
	/**
	 * @param marketableProductCd the marketableProductCd to set
	 */
	public void setMarketableProductCd(String marketableProductCd) {
		this.marketableProductCd = marketableProductCd;
	}
	/**
	 * @return the componentProductCd
	 */
	public String getComponentProductCd() {
		return componentProductCd;
	}
	/**
	 * @param componentProductCd the componentProductCd to set
	 */
	public void setComponentProductCd(String componentProductCd) {
		this.componentProductCd = componentProductCd;
	}
	/**
	 * @return the divisionNo
	 */
	public String getDivisionNo() {
		return divisionNo;
	}
	/**
	 * @param divisionNo the divisionNo to set
	 */
	public void setDivisionNo(String divisionNo) {
		this.divisionNo = divisionNo;
	}
	/**
	 * @return the sectionCd
	 */
	public String getSectionCd() {
		return sectionCd;
	}
	/**
	 * @param sectionCd the sectionCd to set
	 */
	public void setSectionCd(String sectionCd) {
		this.sectionCd = sectionCd;
	}
	/**
	 * @return the profitUnitCd
	 */
	public String getProfitUnitCd() {
		return profitUnitCd;
	}
	/**
	 * @param profitUnitCd the profitUnitCd to set
	 */
	public void setProfitUnitCd(String profitUnitCd) {
		this.profitUnitCd = profitUnitCd;
	}
	/**
	 * @return the majorLineCd
	 */
	public String getMajorLineCd() {
		return majorLineCd;
	}
	/**
	 * @param majorLineCd the majorLineCd to set
	 */
	public void setMajorLineCd(String majorLineCd) {
		this.majorLineCd = majorLineCd;
	}
	/**
	 * @return the minorLineCd
	 */
	public String getMinorLineCd() {
		return minorLineCd;
	}
	/**
	 * @param minorLineCd the minorLineCd to set
	 */
	public void setMinorLineCd(String minorLineCd) {
		this.minorLineCd = minorLineCd;
	}
	/**
	 * @return the classPerilCd
	 */
	public String getClassPerilCd() {
		return classPerilCd;
	}
	/**
	 * @param classPerilCd the classPerilCd to set
	 */
	public void setClassPerilCd(String classPerilCd) {
		this.classPerilCd = classPerilCd;
	}
	/**
	 * @return the majorClassCd
	 */
	public String getMajorClassCd() {
		return majorClassCd;
	}
	/**
	 * @param majorClassCd the majorClassCd to set
	 */
	public void setMajorClassCd(String majorClassCd) {
		this.majorClassCd = majorClassCd;
	}
	/**
	 * @return the productStateCd
	 */
	public String getProductStateCd() {
		return productStateCd;
	}
	/**
	 * @param productStateCd the productStateCd to set
	 */
	public void setProductStateCd(String productStateCd) {
		this.productStateCd = productStateCd;
	}
	/**
	 * @return the effectiveDt
	 */
	public String getEffectiveDt() {
		return effectiveDt;
	}
	/**
	 * @param effectiveDt the effectiveDt to set
	 */
	public void setEffectiveDt(String effectiveDt) {
		this.effectiveDt = effectiveDt;
	}
	/**
	 * @return the expirationDt
	 */
	public String getExpirationDt() {
		return expirationDt;
	}
	/**
	 * @param expirationDt the expirationDt to set
	 */
	public void setExpirationDt(String expirationDt) {
		this.expirationDt = expirationDt;
	}
	/**
	 * @return the underwriterId
	 */
	public String getUnderwriterId() {
		return underwriterId;
	}
	/**
	 * @param underwriterId the underwriterId to set
	 */
	public void setUnderwriterId(String underwriterId) {
		this.underwriterId = underwriterId;
	}
	/**
	 * @return the attributes
	 */
	public List<AttributesInfoBO> getAttributes() {
		return attributes;
	}
	/**
	 * @param attributes the attributes to set
	 */
	public void setAttributes(List<AttributesInfoBO> attributes) {
		this.attributes = attributes;
	}
	/**
	 * @return the branches
	 */
	public List<BranchBO> getBranches() {
		return branches;
	}
	/**
	 * @param branches the branches to set
	 */
	public void setBranches(List<BranchBO> branches) {
		this.branches = branches;
	}
	/**
	 * @return the limits
	 */
	public LimitBO getLimits() {
		return limits;
	}
	/**
	 * @param limits the limits to set
	 */
	public void setLimits(LimitBO limits) {
		this.limits = limits;
	}

	/**
	 * @return the additionalInsureds
	 */
	public AdditionalInsuredsBO getAdditionalInsureds() {
		return additionalInsureds;
	}
	/**
	 * @param additionalInsureds the additionalInsureds to set
	 */
	public void setAdditionalInsureds(AdditionalInsuredsBO additionalInsureds) {
		this.additionalInsureds = additionalInsureds;
	}
	/**
	 * @return the assets
	 */
	public List<AssetBO> getAssets() {
		return assets;
	}
	/**
	 * @param assets the assets to set
	 */
	public void setAssets(List<AssetBO> assets) {
		this.assets = assets;
	}
	/**
	 * @return the policies
	 */
	public List<PolicyDetailBO> getPolicies() {
		return policies;
	}
	/**
	 * @param policies the policies to set
	 */
	public void setPolicies(List<PolicyDetailBO> policies) {
		this.policies = policies;
	}
	/**
	 * @return the componentProductKey
	 */
	public String getComponentProductKey() {
		return componentProductKey;
	}
	/**
	 * @param componentProductKey the componentProductKey to set
	 */
	public void setComponentProductKey(String componentProductKey) {
		this.componentProductKey = componentProductKey;
	}
	
	public ExposureCountryBO getExposureCountryBO() {
		return exposureCountryBO;
	}
	public void setExposureCountryBO(ExposureCountryBO exposureCountryBO) {
		this.exposureCountryBO = exposureCountryBO;
	}
}
