package com.aig.nge.dao;

import java.util.Set;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.aig.nge.entities.TbrickMetadata;
import com.aig.nge.entities.TlegacySourceMapping;
import com.aig.nge.repository.TbrickMetadataRepository;
//import com.aig.nge.entities.TmarketSegment;
//import com.aig.nge.repository.TMarketSegmentRepository;
import com.aig.nge.repository.TlegacySourceMappingRepository;

/**
 * @author Ramakrishnas
 * This DAO class is used for accessing the transaction related repositories.
 */

@Repository
public class TransactionDAO extends BaseDAO{
	
	//@Autowired
	//private TMarketSegmentRepository tMarketSegmentRepository;
	
	@Autowired
	private TlegacySourceMappingRepository tLegacySourceMappingRepository;
	
	@Autowired
	private TbrickMetadataRepository tbrickMetadataRepository;
	/*
	public Set<TmarketSegment> getMarketSegmentsDAO(){
		Set<TmarketSegment> marketSegments;
		marketSegments = tMarketSegmentRepository.getMarketSegments();
		return marketSegments;
	}
*/
	public Set<TlegacySourceMapping> getSourceCdMappingDAO() {
		Set<TlegacySourceMapping> sourceCdSet;
		sourceCdSet = tLegacySourceMappingRepository.getSourceCds();
		return sourceCdSet;
	}
	public Set<TbrickMetadata> getBrickMetaData() {
		return tbrickMetadataRepository.getBrickMetaData();
	}
	
	
}
