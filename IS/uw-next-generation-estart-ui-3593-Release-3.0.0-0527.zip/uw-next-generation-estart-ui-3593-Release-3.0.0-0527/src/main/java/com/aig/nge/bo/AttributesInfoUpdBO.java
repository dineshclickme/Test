package com.aig.nge.bo;

import java.util.List;

public class AttributesInfoUpdBO {
	private String attributeNm;
	private AttributeValuesBO attributeValue;
	private String attributeVal;
	private String exstAttributeVal;
	private String attributeAction;
	private String mulitipleInd;
	private List<String> attributeValues; // added for get submission response
	/**
	 * @return the attributeNm
	 */
	public String getAttributeNm() {
		return attributeNm;
	}
	/**
	 * @param attributeNm the attributeNm to set
	 */
	public void setAttributeNm(String attributeNm) {
		this.attributeNm = attributeNm;
	}
	/**
	 * @return the attributeValue
	 */
	public AttributeValuesBO getAttributeValue() {
		return attributeValue;
	}
	/**
	 * @param attributeValue the attributeValue to set
	 */
	public void setAttributeValue(AttributeValuesBO attributeValue) {
		this.attributeValue = attributeValue;
	}
	/**
	 * @return the attributeVal
	 */
	public String getAttributeVal() {
		return attributeVal;
	}
	/**
	 * @param attributeVal the attributeVal to set
	 */
	public void setAttributeVal(String attributeVal) {
		this.attributeVal = attributeVal;
	}
	/**
	 * @return the exstAttributeVal
	 */
	public String getExstAttributeVal() {
		return exstAttributeVal;
	}
	/**
	 * @param exstAttributeVal the exstAttributeVal to set
	 */
	public void setExstAttributeVal(String exstAttributeVal) {
		this.exstAttributeVal = exstAttributeVal;
	}
	/**
	 * @return the attributeAction
	 */
	public String getAttributeAction() {
		return attributeAction;
	}
	/**
	 * @param attributeAction the attributeAction to set
	 */
	public void setAttributeAction(String attributeAction) {
		this.attributeAction = attributeAction;
	}
	/**
	 * @return the attributeValues
	 */
	public List<String> getAttributeValues() {
		return attributeValues;
	}
	/**
	 * @param attributeValues the attributeValues to set
	 */
	public void setAttributeValues(List<String> attributeValues) {
		this.attributeValues = attributeValues;
	}
	public String getMulitipleInd() {
		return mulitipleInd;
	}
	public void setMulitipleInd(String mulitipleInd) {
		this.mulitipleInd = mulitipleInd;
	}
}
