package com.aig.nge.bo;

import java.util.List;

public class AdditionalProducerSessionBO {
	private List<AdditionalProducerBO> rows;

	public List<AdditionalProducerBO> getRows() {
		return rows;
	}

	public void setRows(List<AdditionalProducerBO> rows) {
		this.rows = rows;
	}	
}
