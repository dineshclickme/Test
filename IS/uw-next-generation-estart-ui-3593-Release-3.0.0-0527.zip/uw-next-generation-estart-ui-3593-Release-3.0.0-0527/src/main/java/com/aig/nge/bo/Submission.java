package com.aig.nge.bo;

public class Submission {

	private SubmissionBO submission;
	private TransactionProducerBO transaction;

	public TransactionProducerBO getTransaction() {
		return transaction;
	}

	public void setTransaction(TransactionProducerBO transaction) {
		this.transaction = transaction;
	}

	/**
	 * @return the submission
	 */
	public SubmissionBO getSubmission() {
		return submission;
	}

	/**
	 * @param submission the submission to set
	 */
	public void setSubmission(SubmissionBO submission) {
		this.submission = submission;
	}
	
}
