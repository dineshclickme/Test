package com.aig.nge.bo;

import java.util.List;

public class LicenseDetailInfoUIBO {
	List<AgentLicenseInfoUIBO> agentInfo;
	List<ProducerLicenseInfoUIBO> producerInfo;
	/**
	 * @return the agentInfo
	 */
	public List<AgentLicenseInfoUIBO> getAgentInfo() {
		return agentInfo;
	}
	/**
	 * @param agentInfo the agentInfo to set
	 */
	public void setAgentInfo(List<AgentLicenseInfoUIBO> agentInfo) {
		this.agentInfo = agentInfo;
	}
	/**
	 * @return the producerInfo
	 */
	public List<ProducerLicenseInfoUIBO> getProducerInfo() {
		return producerInfo;
	}
	/**
	 * @param producerInfo the producerInfo to set
	 */
	public void setProducerInfo(List<ProducerLicenseInfoUIBO> producerInfo) {
		this.producerInfo = producerInfo;
	}
}
