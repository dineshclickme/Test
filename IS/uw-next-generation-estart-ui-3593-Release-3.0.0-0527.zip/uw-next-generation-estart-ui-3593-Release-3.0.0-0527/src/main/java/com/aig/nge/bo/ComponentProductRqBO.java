package com.aig.nge.bo;

public class ComponentProductRqBO {
    private String segmentCd;
    private String subSegmentCd;
    private String marketableProductCd;
    private String componentProductCd;
    private String transactionComponentId;
    private String attachmentPointAmt;
    private String underwriterId;
    
    private String productTowerCd;
    private String componentProductTowerCd;
    
	/**
	 * @return the segmentCd
	 */
	public String getSegmentCd() {
		return segmentCd;
	}
	/**
	 * @param segmentCd the segmentCd to set
	 */
	public void setSegmentCd(String segmentCd) {
		this.segmentCd = segmentCd;
	}
	/**
	 * @return the subSegmentCd
	 */
	public String getSubSegmentCd() {
		return subSegmentCd;
	}
	/**
	 * @param subSegmentCd the subSegmentCd to set
	 */
	public void setSubSegmentCd(String subSegmentCd) {
		this.subSegmentCd = subSegmentCd;
	}
	/**
	 * @return the marketableProductCd
	 */
	public String getMarketableProductCd() {
		return marketableProductCd;
	}
	/**
	 * @param marketableProductCd the marketableProductCd to set
	 */
	public void setMarketableProductCd(String marketableProductCd) {
		this.marketableProductCd = marketableProductCd;
	}
	/**
	 * @return the componentProductCd
	 */
	public String getComponentProductCd() {
		return componentProductCd;
	}
	/**
	 * @param componentProductCd the componentProductCd to set
	 */
	public void setComponentProductCd(String componentProductCd) {
		this.componentProductCd = componentProductCd;
	}
	/**
	 * @return the attachmentPointAmt
	 */
	public String getAttachmentPointAmt() {
		return attachmentPointAmt;
	}
	/**
	 * @param attachmentPointAmt the attachmentPointAmt to set
	 */
	public void setAttachmentPointAmt(String attachmentPointAmt) {
		this.attachmentPointAmt = attachmentPointAmt;
	}
	/**
	 * @return the underwriterId
	 */
	public String getUnderwriterId() {
		return underwriterId;
	}
	/**
	 * @param underwriterId the underwriterId to set
	 */
	public void setUnderwriterId(String underwriterId) {
		this.underwriterId = underwriterId;
	}
	public String getTransactionComponentId() {
		return transactionComponentId;
	}
	public void setTransactionComponentId(String transactionComponentId) {
		this.transactionComponentId = transactionComponentId;
	}
	public String getProductTowerCd() {
		return productTowerCd;
	}
	public void setProductTowerCd(String productTowerCd) {
		this.productTowerCd = productTowerCd;
	}
	public String getComponentProductTowerCd() {
		return componentProductTowerCd;
	}
	public void setComponentProductTowerCd(String componentProductTowerCd) {
		this.componentProductTowerCd = componentProductTowerCd;
	}
    
}
