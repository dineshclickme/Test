package com.aig.nge.bo;

import com.fasterxml.jackson.annotation.JsonInclude;

public class BrokerBO {

	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String firstName;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String lastName;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String phoneNo;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String emailAddress;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String commentTx;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String producerContactDetails;
	
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}
	public String getEmailAddress() {
		return emailAddress;
	}
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}
	public String getCommentTx() {
		return commentTx;
	}
	public void setCommentTx(String commentTx) {
		this.commentTx = commentTx;
	}
	public String getProducerContactDetails() {
		return producerContactDetails;
	}
	public void setProducerContactDetails(String producerContactDetails) {
		this.producerContactDetails = producerContactDetails;
	}
	
	
}
