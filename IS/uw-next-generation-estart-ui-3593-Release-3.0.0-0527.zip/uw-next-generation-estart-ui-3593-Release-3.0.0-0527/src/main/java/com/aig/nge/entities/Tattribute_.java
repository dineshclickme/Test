package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SetAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-02-19T16:13:02.926+0530")
@StaticMetamodel(Tattribute.class)
public class Tattribute_ {
	public static volatile SingularAttribute<Tattribute, Short> attributeId;
	public static volatile SingularAttribute<Tattribute, String> attributeNm;
	public static volatile SingularAttribute<Tattribute, Timestamp> createTs;
	public static volatile SingularAttribute<Tattribute, String> createUserId;
	public static volatile SingularAttribute<Tattribute, Short> dataLengthQt;
	public static volatile SingularAttribute<Tattribute, String> deletedIn;
	public static volatile SingularAttribute<Tattribute, Timestamp> updateTs;
	public static volatile SingularAttribute<Tattribute, String> updateUserId;
	public static volatile SetAttribute<Tattribute, TassetAttribute> tassetAttributes;
	public static volatile SingularAttribute<Tattribute, TdataType> tdataType;
	public static volatile SetAttribute<Tattribute, TattributeGroup> tattributeGroups;
	public static volatile SetAttribute<Tattribute, TcompnentStatusAttribute> tcompnentStatusAttributes;
	public static volatile SetAttribute<Tattribute, TextractAttribute> textractAttributes;
	public static volatile SetAttribute<Tattribute, TpolicyAttribute> tpolicyAttributes;
	public static volatile SetAttribute<Tattribute, TproductTowerAttribute> tproductTowerAttributes;
	public static volatile SetAttribute<Tattribute, TtableAttribute> ttableAttributes;
	public static volatile SetAttribute<Tattribute, TtowerEvent> ttowerEvents;
	public static volatile SetAttribute<Tattribute, TtransactionAttribute> ttransactionAttributes;
	public static volatile SetAttribute<Tattribute, TtransactionComponentAtrbt> ttransactionComponentAtrbts;
	public static volatile SetAttribute<Tattribute, TtransactionProductAttribute> ttransactionProductAttributes;
	public static volatile SetAttribute<Tattribute, TassetTypeAttribute> tassetTypeAttributes;
}
