package com.aig.nge.bo;

import java.util.List;

public class CreateTransactionBO {
	
    private AddressDetailsBO mailingAddress;
    
    private String producerCd;
    
    private String agentId;
    
    private String marketSegmentCd;
    
    private String underwriterId;
    
  

	private CreditedBranchBO creditedBranch;
    
    private String creditedBranchStr;
    
    private List<AttributesInfoBO> attributesInfo;
    private List<AttributesInfoBO> transactionAttributes;
    
    private List<AdditionalInsuredBO> additionalInsureds;
    
    private List<AdditionalProducerBO> additionalProducers;
    
    private BrokerBO broker;
    
    private ProductsBO products;
    
    private List<productsObj> productsInfo;

	/**
	 * @return the productsInfo
	 */
	public List<productsObj> getProductsInfo() {
		return productsInfo;
	}

	/**
	 * @param productsInfo the productsInfo to set
	 */
	public void setProductsInfo(List<productsObj> productsInfo) {
		this.productsInfo = productsInfo;
	}

	/**
	 * @return the mailingAddress
	 */
	public AddressDetailsBO getMailingAddress() {
		return mailingAddress;
	}

	/**
	 * @param mailingAddress the mailingAddress to set
	 */
	public void setMailingAddress(AddressDetailsBO mailingAddress) {
		this.mailingAddress = mailingAddress;
	}

	/**
	 * @return the producerCd
	 */
	public String getProducerCd() {
		return producerCd;
	}

	/**
	 * @param producerCd the producerCd to set
	 */
	public void setProducerCd(String producerCd) {
		this.producerCd = producerCd;
	}

	/**
	 * @return the agentId
	 */
	public String getAgentId() {
		return agentId;
	}

	/**
	 * @param agentId the agentId to set
	 */
	public void setAgentId(String agentId) {
		this.agentId = agentId;
	}

	/**
	 * @return the marketSegmentCd
	 */
	public String getMarketSegmentCd() {
		return marketSegmentCd;
	}

	/**
	 * @param marketSegmentCd the marketSegmentCd to set
	 */
	public void setMarketSegmentCd(String marketSegmentCd) {
		this.marketSegmentCd = marketSegmentCd;
	}

	/**
	 * @return the underwriterId
	 */
	public String getUnderwriterId() {
		return underwriterId;
	}

	/**
	 * @param underwriterId the underwriterId to set
	 */
	public void setUnderwriterId(String underwriterId) {
		this.underwriterId = underwriterId;
	}

	/**
	 * @return the creditedBranch
	 */
	public CreditedBranchBO getCreditedBranch() {
		return creditedBranch;
	}

	/**
	 * @param creditedBranch the creditedBranch to set
	 */
	public void setCreditedBranch(CreditedBranchBO creditedBranch) {
		this.creditedBranch = creditedBranch;
	}

	/**
	 * @return the attributes
	 */
	public List<AttributesInfoBO> getAttributes() {
		return attributesInfo;
	}

	/**
	 * @param attributes the attributes to set
	 */
	public void setAttributes(List<AttributesInfoBO> attributes) {
		this.attributesInfo = attributes;
	}

	/**
	 * @return the additionalInsureds
	 */
	public List<AdditionalInsuredBO> getAdditionalInsureds() {
		return additionalInsureds;
	}

	/**
	 * @param additionalInsureds the additionalInsureds to set
	 */
	public void setAdditionalInsureds(List<AdditionalInsuredBO> additionalInsureds) {
		this.additionalInsureds = additionalInsureds;
	}

	/**
	 * @return the additionalProducers
	 */
	public List<AdditionalProducerBO> getAdditionalProducers() {
		return additionalProducers;
	}

	/**
	 * @param additionalProducers the additionalProducers to set
	 */
	public void setAdditionalProducers(
			List<AdditionalProducerBO> additionalProducers) {
		this.additionalProducers = additionalProducers;
	}

	/**
	 * @return the broker
	 */
	public BrokerBO getBroker() {
		return broker;
	}

	/**
	 * @param broker the broker to set
	 */
	public void setBroker(BrokerBO broker) {
		this.broker = broker;
	}

	/**
	 * @return the products
	 */
	public ProductsBO getProducts() {
		return products;
	}

	/**
	 * @param products the products to set
	 */
	public void setProducts(ProductsBO products) {
		this.products = products;
	}

	/**
	 * @return the creditedBranchStr
	 */
	public String getCreditedBranchStr() {
		return creditedBranchStr;
	}

	/**
	 * @param creditedBranchStr the creditedBranchStr to set
	 */
	public void setCreditedBranchStr(String creditedBranchStr) {
		this.creditedBranchStr = creditedBranchStr;
	}

	public List<AttributesInfoBO> getTransactionAttributes() {
		return transactionAttributes;
	}

	public void setTransactionAttributes(
			List<AttributesInfoBO> transactionAttributes) {
		this.transactionAttributes = transactionAttributes;
	}

    
}
