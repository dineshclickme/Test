package com.aig.nge.bo;

public class UnderwriterSearchBO {
	
	private String autocloseDate;
	private String underwriterId;
	private String effectiveDt;
	private String expirationDt;
	private String lifecycleStatusCd;
	private String reservationStatus;
	private String submissionNo;
	private String creationTs;
	private String transactionId;
	private String marketableProductCd;
	private String marketableProductName;
	private String componentProductCd;
	private String componentProductNm;
	private String extCount;
	private String accountNm;
	private String cityNm;
	private String stateNm;
	
	public String getAutocloseDate() {
		return autocloseDate;
	}
	public void setAutocloseDate(String autocloseDate) {
		this.autocloseDate = autocloseDate;
	}
	public String getUnderwriterId() {
		return underwriterId;
	}
	public void setUnderwriterId(String underwriterId) {
		this.underwriterId = underwriterId;
	}
	public String getEffectiveDt() {
		return effectiveDt;
	}
	public void setEffectiveDt(String effectiveDt) {
		this.effectiveDt = effectiveDt;
	}
	public String getExpirationDt() {
		return expirationDt;
	}
	public void setExpirationDt(String expirationDt) {
		this.expirationDt = expirationDt;
	}
	public String getLifecycleStatusCd() {
		return lifecycleStatusCd;
	}
	public void setLifecycleStatusCd(String lifecycleStatusCd) {
		this.lifecycleStatusCd = lifecycleStatusCd;
	}
	public String getReservationStatus() {
		return reservationStatus;
	}
	public void setReservationStatus(String reservationStatus) {
		this.reservationStatus = reservationStatus;
	}
	public String getSubmissionNo() {
		return submissionNo;
	}
	public void setSubmissionNo(String submissionNo) {
		this.submissionNo = submissionNo;
	}
	public String getCreationTs() {
		return creationTs;
	}
	public void setCreationTs(String creationTs) {
		this.creationTs = creationTs;
	}
	public String getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	public String getMarketableProductCd() {
		return marketableProductCd;
	}
	public void setMarketableProductCd(String marketableProductCd) {
		this.marketableProductCd = marketableProductCd;
	}
	public String getMarketableProductName() {
		return marketableProductName;
	}
	public void setMarketableProductName(String marketableProductName) {
		this.marketableProductName = marketableProductName;
	}
	public String getComponentProductCd() {
		return componentProductCd;
	}
	public void setComponentProductCd(String componentProductCd) {
		this.componentProductCd = componentProductCd;
	}
	public String getComponentProductNm() {
		return componentProductNm;
	}
	public void setComponentProductNm(String componentProductNm) {
		this.componentProductNm = componentProductNm;
	}
	public String getExtCount() {
		return extCount;
	}
	public void setExtCount(String extCount) {
		this.extCount = extCount;
	}
	public String getAccountNm() {
		return accountNm;
	}
	public void setAccountNm(String accountNm) {
		this.accountNm = accountNm;
	}
	public String getCityNm() {
		return cityNm;
	}
	public void setCityNm(String cityNm) {
		this.cityNm = cityNm;
	}
	public String getStateNm() {
		return stateNm;
	}
	public void setStateNm(String stateNm) {
		this.stateNm = stateNm;
	}
	
	
	

}
