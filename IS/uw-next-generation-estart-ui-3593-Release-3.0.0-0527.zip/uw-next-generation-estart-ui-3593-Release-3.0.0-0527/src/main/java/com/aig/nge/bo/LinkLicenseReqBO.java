package com.aig.nge.bo;

import com.fasterxml.jackson.annotation.JsonInclude;

public class LinkLicenseReqBO {
	
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String underwritingSysCd;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String submissionNo;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String agentId;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String producerCd;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String requestType;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String deleteInd;
	
	/**
	 * @return the underwritingSysCd
	 */
	public String getUnderwritingSysCd() {
		return underwritingSysCd;
	}
	/**
	 * @param underwritingSysCd the underwritingSysCd to set
	 */
	public void setUnderwritingSysCd(String underwritingSysCd) {
		this.underwritingSysCd = underwritingSysCd;
	}
	/**
	 * @return the submissionNo
	 */
	public String getSubmissionNo() {
		return submissionNo;
	}
	/**
	 * @param submissionNo the submissionNo to set
	 */
	public void setSubmissionNo(String submissionNo) {
		this.submissionNo = submissionNo;
	}
	/**
	 * @return the agentId
	 */
	public String getAgentId() {
		return agentId;
	}
	/**
	 * @param agentId the agentId to set
	 */
	public void setAgentId(String agentId) {
		this.agentId = agentId;
	}
	/**
	 * @return the producerCd
	 */
	public String getProducerCd() {
		return producerCd;
	}
	/**
	 * @param producerCd the producerCd to set
	 */
	public void setProducerCd(String producerCd) {
		this.producerCd = producerCd;
	}
	/**
	 * @return the requestType
	 */
	public String getRequestType() {
		return requestType;
	}
	/**
	 * @param requestType the requestType to set
	 */
	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}
	/**
	 * @return the deleteInd
	 */
	public String getDeleteInd() {
		return deleteInd;
	}
	/**
	 * @param deleteInd the deleteInd to set
	 */
	public void setDeleteInd(String deleteInd) {
		this.deleteInd = deleteInd;
	}
	
}
