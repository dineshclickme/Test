package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-02-24T11:59:49.368+0530")
@StaticMetamodel(Tblock.class)
public class Tblock_ {
	public static volatile SingularAttribute<Tblock, Integer> blockNo;
	public static volatile SingularAttribute<Tblock, String> commentTx;
	public static volatile SingularAttribute<Tblock, Timestamp> createTs;
	public static volatile SingularAttribute<Tblock, String> createUserId;
	public static volatile SingularAttribute<Tblock, Short> systemId;
	public static volatile SingularAttribute<Tblock, Timestamp> updateTs;
	public static volatile SingularAttribute<Tblock, String> updateUserId;
	public static volatile SingularAttribute<Tblock, TalertBlock> talertBlock;
	public static volatile SingularAttribute<Tblock, TblockType> tblockType;
	public static volatile SingularAttribute<Tblock, Treason> treason;
	public static volatile SingularAttribute<Tblock, Tstatus> tstatus;
	public static volatile SingularAttribute<Tblock, TtransactionComponent> ttransactionComponent;
	public static volatile SingularAttribute<Tblock, TcomponentBlock> tcomponentBlock;
	public static volatile SingularAttribute<Tblock, Tparty> tparty;
	public static volatile SingularAttribute<Tblock, Trole> trole;
}
