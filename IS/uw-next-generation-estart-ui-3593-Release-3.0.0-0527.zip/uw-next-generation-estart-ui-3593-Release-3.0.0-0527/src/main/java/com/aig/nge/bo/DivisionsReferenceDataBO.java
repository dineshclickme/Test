package com.aig.nge.bo;

import java.io.Serializable;
import java.util.List;
import java.util.Map;
 
public class DivisionsReferenceDataBO implements Serializable{
	private static final long serialVersionUID = 1L;
	private String productTowerwrHidden;
	private boolean allowDataEntry;
	private List<Map<String,String>> data;

	public boolean isAllowDataEntry() {
		return allowDataEntry;
	}
	public void setAllowDataEntry(boolean allowDataEntry) {
		this.allowDataEntry = allowDataEntry;
	}
	public List<Map<String, String>> getData() {
		return data;
	}
	public void setData(List<Map<String, String>> data) {
		this.data = data;
	}
	public String getProductTowerwrHidden() {
		return productTowerwrHidden;
	}
	public void setProductTowerwrHidden(String productTowerwrHidden) {
		this.productTowerwrHidden = productTowerwrHidden;
	}
	
}
