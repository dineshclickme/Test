package com.aig.nge.bo;

import com.fasterxml.jackson.annotation.JsonInclude;

public class AddressDetailsBO {

	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String addressLine1;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String addressLine2;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String addressLine3;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String city;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String locationstate;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String stateNm;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String countryselection;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String countryNm;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String zipCode;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String countyNm;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String newAccountMailingAddress;
	
	public String getAddressLine1() {
		return addressLine1;
	}
	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}
	public String getAddressLine2() {
		return addressLine2;
	}
	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}
	public String getAddressLine3() {
		return addressLine3;
	}
	public void setAddressLine3(String addressLine3) {
		this.addressLine3 = addressLine3;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getLocationstate() {
		return locationstate;
	}
	public void setLocationstate(String locationstate) {
		this.locationstate = locationstate;
	}
	public String getStateNm() {
		return stateNm;
	}
	public void setStateNm(String stateNm) {
		this.stateNm = stateNm;
	}
	public String getCountryselection() {
		return countryselection;
	}
	public void setCountryselection(String countryselection) {
		this.countryselection = countryselection;
	}
	public String getCountryNm() {
		return countryNm;
	}
	public void setCountryNm(String countryNm) {
		this.countryNm = countryNm;
	}
	public String getZipCode() {
		return zipCode;
	}
	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}
	public String getCountyNm() {
		return countyNm;
	}
	public void setCountyNm(String countyNm) {
		this.countyNm = countyNm;
	}
	public String getNewAccountMailingAddress() {
		return newAccountMailingAddress;
	}
	public void setNewAccountMailingAddress(String newAccountMailingAddress) {
		this.newAccountMailingAddress = newAccountMailingAddress;
	}

	
	
}
