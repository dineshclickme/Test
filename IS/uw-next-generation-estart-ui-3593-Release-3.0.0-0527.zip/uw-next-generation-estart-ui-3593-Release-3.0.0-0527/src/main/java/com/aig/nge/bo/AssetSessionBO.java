package com.aig.nge.bo;

import java.util.List;

public class AssetSessionBO {

	public List<AssetBO> assetBo;

	public List<AssetBO> getAssetBo() {
		return assetBo;
	}

	public void setAssetBo(List<AssetBO> assetBo) {
		this.assetBo = assetBo;
	}
	
}
