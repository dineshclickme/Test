package com.aig.nge.bo;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

public class PolicyTypesRefDataListBO implements Serializable{
	/* 2020 - JAR upgrade issue fixed */
	private static final long serialVersionUID = 1L;

	private List<PolicyTypesReferenceDataBO> policyTypesRefDataBO;

	public List<PolicyTypesReferenceDataBO> getPolicyTypesRefDataBO() {
		return policyTypesRefDataBO;
	}

	public void setPolicyTypesRefDataBO(
			List<PolicyTypesReferenceDataBO> policyTypesRefDataBO) {
		this.policyTypesRefDataBO = policyTypesRefDataBO;
	}

	
}
