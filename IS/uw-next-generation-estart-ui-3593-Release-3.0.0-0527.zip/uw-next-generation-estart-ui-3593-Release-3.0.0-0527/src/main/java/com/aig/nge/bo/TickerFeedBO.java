package com.aig.nge.bo;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.LogManager;

//POJO bean to hold the ticker related fields
public class TickerFeedBO {
	//TCS CE Team Changes Starts Here
	private static final Logger logger = LogManager.getLogger(TickerFeedBO.class);
	//TCS CE Team Changes Ends Here
	
	private int feedId;
	private String feedDs;
	private double minPreAmt;
	private String segCD;
	public String getSegCD() {
		return segCD;
	}
	public void setSegCD(String segCD) {
		this.segCD = segCD;
	}
	public int getFeedId() {
		return feedId;
	}
	public void setFeedId(int feedId) {
		this.feedId = feedId;
	}
	public String getFeedDs() {
		return feedDs;
	}
	public void setFeedDs(String feedDs) {
		this.feedDs = feedDs;
	}
	public double getMinPreAmt() {
		return minPreAmt;
	}
	public void setMinPreAmt(double minPreAmt) {
		this.minPreAmt = minPreAmt;
	}
	public static Logger getLogger() {
		return logger;
	}
	
}
