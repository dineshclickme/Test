package com.aig.nge.bo;

import java.util.ArrayList;
import java.util.List;

public class AttributeDataBOForUpdate {
	
	private List<AttributeRefereceBOForUpdate> data;
	/*PI3 - Aug release - Add Low goverance attribute in user prefernce starts */
	public List<AttributeRefereceBOForUpdate> getData() {
		if(data==null){
			data=new ArrayList<AttributeRefereceBOForUpdate>();
		}
		return data;
	}

	public void setData(List<AttributeRefereceBOForUpdate> data) {
		this.data = data;
	}


}
