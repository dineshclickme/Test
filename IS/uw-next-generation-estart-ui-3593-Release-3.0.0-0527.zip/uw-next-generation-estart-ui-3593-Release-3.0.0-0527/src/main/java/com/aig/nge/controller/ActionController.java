package com.aig.nge.controller;

import com.aig.generalins.configserverclient.ConfigServerProperties;
import com.aig.nge.bo.*;
import com.aig.nge.handler.AlertServiceHandler;
import com.aig.nge.helper.DynaCacheScheduleTime;
import com.aig.nge.helper.ScheduleDynaCache;
import com.aig.nge.service.*;
import com.aig.nge.utilities.ConfigProvider;
import com.aig.nge.utilities.IConfigProvider;
import com.aig.nge.utilities.NGEConstants;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.core.LoggerContext;
import org.apache.logging.log4j.core.config.Configuration;
import org.apache.logging.log4j.core.config.ConfigurationSource;
import org.apache.logging.log4j.core.config.Configurator;
import org.apache.logging.log4j.core.config.properties.PropertiesConfigurationBuilder;
import org.apache.tomcat.dbcp.dbcp2.BasicDataSource;
import org.bouncycastle.jce.provider.BouncyCastleProvider;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.sql.DataSource;
import java.io.IOException;
import java.security.Security;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Properties;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;
import redis.clients.jedis.JedisPoolConfig;
import redis.clients.jedis.Protocol;

/*
  Servlet implementation class ActionController
*/
@WebServlet("/ActionController")
public class ActionController extends HttpServlet implements ServletContextListener {
    private static final long serialVersionUID = 1L;
    HttpSession session = null;
    //TCS CE Team Changes Starts Here
    private static final Logger logger = LogManager.getLogger(ActionController.class);
    ConfigProvider configProvider = new ConfigProvider();
    ConfigServerProperties configServerProperties = ConfigServerProperties.getInstance();
    /*
      @see HttpServlet#HttpServlet()
     */
    private Connection theConnection = null;


    public ActionController() {
        super();
    }
    @Override
    public void contextInitialized(ServletContextEvent servletContextEvent) {
        System.out.println("********** inside the contextInitialized function **************");
        System.setProperty("javax.xml.parsers.DocumentBuilderFactory", "com.sun.org.apache.xerces.internal.jaxp.DocumentBuilderFactoryImpl");

        /*------------------Logger Implementation Start's-----------------------*/
        Properties NgeLogProperties = configProvider.getProperties("NGELog.");
        setLogging(NgeLogProperties);
        /*------------------Logger Implementation End's-----------------------*/
        //Data Source Externalization//
        logger.info("***************** DataSource contextInitialized ******************");
        System.setProperty("APPLICATION_NAME", "uw-next-generation-estart-ui-3593");

//        Security.insertProviderAt(new BouncyCastleProvider(), 2);
        try {

            InitialContext ctx = new InitialContext();
            ctx.createSubcontext("JNDI").createSubcontext("nge");
            ctx.createSubcontext("jdbc");
            bind_NgeDynaCacheUI(configProvider,ctx);
            bindDb_DB2_ALERT(configProvider, ctx);
            bindDb_DB2_ADB(configProvider,ctx);
            bindDb_DB2_AAMS(configProvider,ctx);
            bindDb_NGE_MSSQL(configProvider,ctx);
            bindDb_NGeStartsvc(configProvider,ctx);
            DataCacheObject.initJedis();
            System.setProperty("log4j2.formatMsgNoLookups", "true");

            System.out.println("Loading..");
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Exception in LoadServlet init()	:" + e.getMessage());
        }

        System.out.println("****** DataSource Completed *******");
        logger.info("****** DataSource Completed *******");
    }

    private void bind_NgeDynaCacheUI(ConfigProvider configProvider, InitialContext ctx) {
        try {
            System.out.println("------------JNDI/nge/NgeDynaCacheUI--Bind--Start------------");
            Jedis jedis = new Jedis();
            ctx.bind("JNDI/nge/NgeDynaCacheUI",jedis);
            System.out.println("------------JNDI/nge/NgeDynaCacheUI--Bind--Complete------------");
        } catch (Exception e) {
            System.out.println("--------------NgeDynaCacheUI------------ " + e.getMessage());
        }
    }
    private static void setLogging(Properties NgeLogProperties) {
        // Configurator.initialize(NgeLogProperties);
        try {
            LoggerContext context = (LoggerContext) LogManager.getContext(false);
            Configuration config = new PropertiesConfigurationBuilder()
                    .setConfigurationSource(ConfigurationSource.NULL_SOURCE)
                    .setRootProperties(NgeLogProperties)
                    .setLoggerContext(context)
                    .build();
            context.setConfiguration(config);
            Configurator.initialize(config);
            //PropertyConfigurator.configure(NgeLogProperties);
            System.out.println("Logging Configuration set");
        }catch(Exception e){ System.out.println("Logging Configuration set" + e.getMessage());}
    }

    @Override
    public void contextDestroyed(ServletContextEvent servletContextEvent) {

    }
    //TCS CE Team Changes Ends Here
    public void init(ServletConfig config) throws ServletException {

        super.init(config);
        ngeUIInit();
    }

    //TCS CE Team Changes Starts Here
    private void bindDb_DB2_ALERT(ConfigProvider configProvider, InitialContext ctx) throws ClassNotFoundException, NamingException, SQLException {
        try {
            Properties properties = configProvider.getProperties("DB2_ALERT.");
            BasicDataSource dbcp = setDataSourceWithPooling(properties);
            //BasicDataSource dbcp = BasicDataSourceFactory.createDataSource(properties);
            ctx.bind("jdbc/DB2_ALERT", dbcp);
            try {
                DataSource ds = (DataSource) ctx.lookup("jdbc/DB2_ALERT");
                ds.getConnection();
                System.out.println("connection success for --DataSource---DB2_ALERT");
                if(theConnection != null)
                {
                    theConnection.close();
                }
            } catch (Exception e) {
                System.out.println("Exception for --DataSource---DB2_ALERT" + e.getMessage());
            }
        } catch (Exception e) {
            System.out.println("########################Exception in DB connection bindDb_DB2_ALERT - " + e.getMessage());
        }
    }

    private void bindDb_DB2_ADB(ConfigProvider configProvider, InitialContext ctx) throws ClassNotFoundException, NamingException, SQLException {
        try {
            Properties properties = configProvider.getProperties("DB2_ADB.");
            BasicDataSource dbcp = setDataSourceWithPooling(properties);
            //BasicDataSource dbcp = BasicDataSourceFactory.createDataSource(properties);
            ctx.bind("jdbc/DB2_ADB", dbcp);
            try {
                DataSource ds = (DataSource) ctx.lookup("jdbc/DB2_ADB");
                ds.getConnection();
                System.out.println("connection success for --DataSource---DB2_ADB");
                if(theConnection != null)
                {
                    theConnection.close();
                }
            } catch (Exception e) {
                System.out.println("Exception for --DataSource---DB2_ADB" + e.getMessage());
            }
        } catch (Exception e) {
            System.out.println("########################Exception in DB connection bindDb_DB2_ADB - " + e.getMessage());
        }
    }

    private void bindDb_DB2_AAMS(ConfigProvider configProvider, InitialContext ctx) throws ClassNotFoundException, NamingException, SQLException {
        try {
            Properties properties = configProvider.getProperties("DB2_AAMS.");
            BasicDataSource dbcp = setDataSourceWithPooling(properties);
            //BasicDataSource dbcp = BasicDataSourceFactory.createDataSource(properties);
            ctx.bind("jdbc/DB2_AAMS", dbcp);
            try {
                DataSource ds = (DataSource) ctx.lookup("jdbc/DB2_AAMS");
                ds.getConnection();
                System.out.println("connection success for --DataSource---DB2_AAMS");
                if(theConnection != null)
                {
                    theConnection.close();
                }
            } catch (Exception e) {
                System.out.println("Exception for --DataSource---DB2_AAMS" + e.getMessage());
            }
        } catch (Exception e) {
            System.out.println("########################Exception in DB connection bindDb_DB2_AAMS - " + e.getMessage());
        }
    }

    private void bindDb_NGE_MSSQL(ConfigProvider configProvider, InitialContext ctx) throws ClassNotFoundException, NamingException, SQLException {
        try {
            Properties properties = configProvider.getProperties("NGE_MSSQL.");
            BasicDataSource dbcp = setDataSourceWithPooling(properties);
            //BasicDataSource dbcp = BasicDataSourceFactory.createDataSource(properties);
            ctx.bind("jdbc/NGE_MSSQL", dbcp);
            try {
                DataSource ds = (DataSource) ctx.lookup("jdbc/NGE_MSSQL");
                ds.getConnection();
                System.out.println("connection success for --DataSource---NGE_MSSQL");
                if(theConnection != null)
                {
                    theConnection.close();
                }
            } catch (Exception e) {
                System.out.println("Exception for --DataSource---NGE_MSSQL" + e.getMessage());
            }
        } catch (Exception e) {
            System.out.println("########################Exception in DB connection bindDb_NGE_MSSQL - " + e.getMessage());
        }
    }

    private void bindDb_NGeStartsvc(ConfigProvider configProvider, InitialContext ctx) throws ClassNotFoundException, NamingException, SQLException {
        try {
            Properties properties = configProvider.getProperties("NGeStartsvc.");
            BasicDataSource dbcp = setDataSourceWithPooling(properties);
//            dbcp.setUsername("NGEUSRRW");
//            dbcp.setPassword("nge2mod");
            //BasicDataSource dbcp = BasicDataSourceFactory.createDataSource(properties);
            ctx.bind("jdbc/NGeStartsvc", dbcp);
            try {
                DataSource ds = (DataSource) ctx.lookup("jdbc/NGeStartsvc");
                ds.getConnection();
                System.out.println("connection success for --DataSource---NGeStartsvc");
                if(theConnection != null)
                {
                    theConnection.close();
                }
            } catch (Exception e) {
                System.out.println("Exception for --DataSource---NGeStartsvc---" + e.getMessage());
            }
        } catch (Exception e) {
            System.out.println("##################Exception in DB connection bindDb_NGeStartsvc##################### " + e.getMessage());
        }
    }



    private BasicDataSource setDataSourceWithPooling(Properties properties) {
        BasicDataSource dbcp = new BasicDataSource();
        dbcp.setDriverClassName(properties.getProperty("driverClassName"));

        dbcp.setUrl(properties.getProperty("url"));
        dbcp.setUsername(properties.getProperty("username"));
        dbcp.setPassword(properties.getProperty("password"));
        dbcp.setRemoveAbandonedOnBorrow(Boolean.parseBoolean(properties.getProperty("removeAbandonedOnBorrow")));
        dbcp.setDefaultAutoCommit(Boolean.parseBoolean(properties.getProperty("defaultAutoCommit")));
        dbcp.setInitialSize(Integer.parseInt(properties.getProperty("initialSize")));
        dbcp.setMaxTotal(Integer.parseInt(properties.getProperty("maxTotal")));
        dbcp.setMaxIdle(Integer.parseInt(properties.getProperty("maxIdle")));
        dbcp.setMaxWaitMillis(Integer.parseInt(properties.getProperty("maxWaitMillis")));
        dbcp.setMinIdle(Integer.parseInt(properties.getProperty("minIdle")));

        dbcp.setRemoveAbandonedTimeout(Integer.parseInt(properties.getProperty("removeAbandonedTimeout")));
        dbcp.setMinEvictableIdleTimeMillis(Integer.parseInt(properties.getProperty("minEvictableIdleTimeMillis")));
        dbcp.setTimeBetweenEvictionRunsMillis(Integer.parseInt(properties.getProperty("timeBetweenEvictionRunsMillis")));
        dbcp.setLogAbandoned(Boolean.parseBoolean(properties.getProperty("logAbandoned")));
        return dbcp;
    }
    //TCS CE Team Changes Ends Here

    public void intefaceSystemCall() {
        logger.debug("Calling Interface system in Server Startup");

        AccountService serviceObj = new AccountService();
        GetAccountReqBO getAccountReqBO = new GetAccountReqBO();
        GetAccountRequestDataBO request = new GetAccountRequestDataBO();
        request.setSearchNumber("000");
        getAccountReqBO.setRequest(request);
        try {
            serviceObj.getAccount(getAccountReqBO);
        } catch (Exception e) {
            logger.debug(e);
        }

        ProducerService producerServiceObject = new ProducerService();
        ProducerEntitySearchReqBO searchReq = new ProducerEntitySearchReqBO();
        searchReq.setProdEntityNumber("000");
        try {
            producerServiceObject.searchProducer(searchReq);
        } catch (Exception e) {
            logger.debug(e);
        }
        searchReq = new ProducerEntitySearchReqBO();
        searchReq.setProdEntityName("0");
        searchReq.setCountry("USA");
        try {
            producerServiceObject.searchProducer(searchReq);
        } catch (Exception e) {
            logger.debug(e);
        }
        try {
            producerServiceObject.validateProducer("000");
        } catch (Exception e) {
            logger.debug(e);
        }

        NGPLSService nGPLSService = new NGPLSService();
        FindAgentReqBO agentReqBO = new FindAgentReqBO();
        agentReqBO.setAgentNPN("0");
        agentReqBO.setAgentLastNm("aa");
        agentReqBO.setAgentFirstNm("aa");
        agentReqBO.setStateCd("a");
        agentReqBO.setAgentId("1");

        try {
            nGPLSService.findAgent(agentReqBO);
        } catch (Exception e) {
            logger.debug(e);
        }

        FindLicenseReqBO licenseReqBO = new FindLicenseReqBO();
        licenseReqBO.setAgentId("0");
        licenseReqBO.setProducerCd("0");
        licenseReqBO.setDivision("0");
        //licenseReqBO.setTransEffDt("");

        try {
            nGPLSService.findLicense(licenseReqBO);
        } catch (Exception e) {
            logger.debug(e);
        }

        LinkLicenseReqBO linkLicenseReqBo = new LinkLicenseReqBO();
        linkLicenseReqBo.setAgentId("0");
        linkLicenseReqBo.setProducerCd("0");
        linkLicenseReqBo.setRequestType("0");
        linkLicenseReqBo.setSubmissionNo("0");
        linkLicenseReqBo.setUnderwritingSysCd("0");


        try {
            nGPLSService.linkLicense(linkLicenseReqBo);
        } catch (Exception e) {
            logger.debug(e);
        }

        AlertServiceHandler alertService = new AlertServiceHandler();
        GetSubmissionBO submissionBO = new GetSubmissionBO();
        try {
            alertService.alertServiceHandler(submissionBO);
        } catch (Exception e) {
            logger.debug(e);
        }

        SubmissionDataService submissionDataserviceObj = new SubmissionDataService();
        try {
            submissionDataserviceObj.setCaslServiceId("1439097");
            submissionBO = new GetSubmissionBO();
            submissionBO.setSubmissionNo("1");
            submissionDataserviceObj.getSubmission(submissionBO);
        } catch (Exception e) {
            logger.debug(e);
        }

        SubmissionManagementService submissionManagementserviceObj = new SubmissionManagementService();
        try {
            submissionManagementserviceObj.setCaslServiceId("1439097");
            List<ProductBO> reserveProductReq = new ArrayList<ProductBO>();
            ProductBO reserveProduct = new ProductBO();
            reserveProduct.setAttachmentPointAmt("1");
            reserveProduct.setComponentProductCd("-1");
            //reserveProduct.setComponentProductTowerCd("1");
            reserveProduct.setTransactionId("1");
            reserveProduct.setTransactionVersionNo("1");
            reserveProductReq.add(reserveProduct);
            submissionManagementserviceObj.reserveProducts(reserveProductReq);
        } catch (Exception e) {
            logger.debug(e);
        }
    }

    public void ngeUIInit() {
        try {
            //TCS CE Team Changes Starts Here
            logger.debug("Calling ActionController in Server Startup");
            ConfigProvider configProvider = new ConfigProvider();
            Properties properties = configProvider.getProperties();
            if (!(NGEConstants.REGION).equalsIgnoreCase("desktop")) {
            //TCS CE Team Changes Ends Here
                DataCacheObject cacheObject = new DataCacheObject();
                cacheObject.clearDynacacheObj();
            }
            final ScheduleDynaCache dynaCache = new ScheduleDynaCache();

//            dynaCache.findJVMUsage();

            ArrayList<Callable<Void>> tasks = new ArrayList<Callable<Void>>();

            tasks.add(new Callable<Void>() {
                public Void call() throws Exception {
                    // if(!System.getProperty(NGEConstants.REGION).equalsIgnoreCase("desktop")){
                    dynaCache.createCacheObject();

                    //  }
                    return null;

                }
            });

            tasks.add(new Callable<Void>() {
                public Void call() throws Exception {
                    //TCS CE Team Changes Starts Here
                    if (!(NGEConstants.REGION).equalsIgnoreCase("desktop")) {
                    //TCS CE Team Changes Ends Here
                        TimeUnit.MILLISECONDS.sleep(6000);
                        intefaceSystemCall();
                    }
                    return null;
                }
            });
            ExecutorService executorService = Executors.newFixedThreadPool(2);
            executorService.invokeAll(tasks);
            DynaCacheScheduleTime dynaCacheScheduleTime = new DynaCacheScheduleTime();
            dynaCacheScheduleTime.getDynaCacheScheduleTime();

            //TCS CE Team Changes Starts Here
            if (!(NGEConstants.REGION).equalsIgnoreCase("desktop")) {
                try {
//                    dynaCache.refreshTickerFeed();
                    //TCS CE Team Changes Ends Here
                } catch (Exception e) {
                    logger.debug(e);
                }
            }
        } catch (Exception e) {
            logger.debug("NGEUIException" + e);
        }
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }else if(obj instanceof ActionController){
            return true;
        }
        return false;
    }

    /*
      @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //TCS CE Team Changes Starts Here
        if(request.getAttribute("CacheRefresh")!=null && request.getAttribute("CacheRefresh").equals("true"))
                ngeUIInit();
        //TCS CE Team Changes Ends Here
    }

    /*
      @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        ngeUIInit();
    }

}
