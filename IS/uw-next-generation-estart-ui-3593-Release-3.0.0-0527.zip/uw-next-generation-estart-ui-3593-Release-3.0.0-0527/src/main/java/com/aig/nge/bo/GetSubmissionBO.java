package com.aig.nge.bo;

import com.fasterxml.jackson.annotation.JsonInclude;

public class GetSubmissionBO {

	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String submissionNo;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String transactionId;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String transactionVersionNo;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String fromPage;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	protected Integer pageNumber;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	protected Long pageSize;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private FiltersBO[] filer;
	
	public Integer getPageNumber() {
		return pageNumber;
	}
	public void setPageNumber(Integer pageNumber) {
		this.pageNumber = pageNumber;
	}
	public String getSubmissionNo() {
		return submissionNo;
	}
	public void setSubmissionNo(String submissionNo) {
		this.submissionNo = submissionNo;
	}
	public String getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	public String getTransactionVersionNo() {
		return transactionVersionNo;
	}
	public void setTransactionVersionNo(String transactionVersionNo) {
		this.transactionVersionNo = transactionVersionNo;
	}
	public String getFromPage() {
		return fromPage;
	}
	public void setFromPage(String fromPage) {
		this.fromPage = fromPage;
	}
	public FiltersBO[] getFiler() {
		return filer;
	}
	public void setFiler(FiltersBO[] filer) {
		this.filer = filer;
	}
	public Long getPageSize() {
		return pageSize;
	}
	public void setPageSize(Long pageSize) {
		this.pageSize = pageSize;
	}
	
}
