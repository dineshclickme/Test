package com.aig.nge.bo;

import java.util.List;

public class GetSubmissionRespDataBO {
	
	private SubmissionBO submission;
	private TransactionJBO transaction;
	private List<ProductJBO> product;
	private List<ComponentJBO> component;
	private AddressDetailsJBO accountmailingaddress;
	private ProdIndividualJBO producerIndividual;
	private addtnlAssetJBO addeditassetdetails;
	/**
	 * @return the submission
	 */
	public SubmissionBO getSubmission() {
		return submission;
	}
	/**
	 * @param submission the submission to set
	 */
	public void setSubmission(SubmissionBO submission) {
		this.submission = submission;
	}
	/**
	 * @return the transaction
	 */
	public TransactionJBO getTransaction() {
		return transaction;
	}
	/**
	 * @param transaction the transaction to set
	 */
	public void setTransaction(TransactionJBO transaction) {
		this.transaction = transaction;
	}
	/**
	 * @return the product
	 */
	public List<ProductJBO> getProduct() {
		return product;
	}
	/**
	 * @param product the product to set
	 */
	public void setProduct(List<ProductJBO> product) {
		this.product = product;
	}
	/**
	 * @return the component
	 */
	public List<ComponentJBO> getComponent() {
		return component;
	}
	/**
	 * @param component the component to set
	 */
	public void setComponent(List<ComponentJBO> component) {
		this.component = component;
	}
	/**
	 * @return the accountmailingaddress
	 */
	public AddressDetailsJBO getAccountmailingaddress() {
		return accountmailingaddress;
	}
	/**
	 * @param accountmailingaddress the accountmailingaddress to set
	 */
	public void setAccountmailingaddress(AddressDetailsJBO accountmailingaddress) {
		this.accountmailingaddress = accountmailingaddress;
	}
	/**
	 * @return the producerIndividual
	 */
	public ProdIndividualJBO getProducerIndividual() {
		return producerIndividual;
	}
	/**
	 * @param producerIndividual the producerIndividual to set
	 */
	public void setProducerIndividual(ProdIndividualJBO producerIndividual) {
		this.producerIndividual = producerIndividual;
	}
	/**
	 * @return the addeditassetdetails
	 */
	public addtnlAssetJBO getAddeditassetdetails() {
		return addeditassetdetails;
	}
	/**
	 * @param addeditassetdetails the addeditassetdetails to set
	 */
	public void setAddeditassetdetails(addtnlAssetJBO addeditassetdetails) {
		this.addeditassetdetails = addeditassetdetails;
	}
}
