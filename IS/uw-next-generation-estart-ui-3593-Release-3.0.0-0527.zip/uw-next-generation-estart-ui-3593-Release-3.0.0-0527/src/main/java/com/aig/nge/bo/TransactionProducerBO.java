package com.aig.nge.bo;

public class TransactionProducerBO {

	private ValueFooterBO producerEntity;
	private String producernumberHidden;
	private String creditedBranchHidden;
	private String creditedBranch;
	private String creditedCountryBranch;

	public String getProducernumberHidden() {
		return producernumberHidden;
	}

	public void setProducernumberHidden(String producernumberHidden) {
		this.producernumberHidden = producernumberHidden;
	}

	public ValueFooterBO getProducerEntity() {
		return producerEntity;
	}

	public void setProducerEntity(ValueFooterBO producerEntity) {
		this.producerEntity = producerEntity;
	}

	public String getCreditedBranchHidden() {
		return creditedBranchHidden;
	}

	public void setCreditedBranchHidden(String creditedBranchHidden) {
		this.creditedBranchHidden = creditedBranchHidden;
	}

	/**
	 * @return the creditedBranch
	 */
	public String getCreditedBranch() {
		return creditedBranch;
	}

	/**
	 * @param creditedBranch the creditedBranch to set
	 */
	public void setCreditedBranch(String creditedBranch) {
		this.creditedBranch = creditedBranch;
	}

	/**
	 * @return the creditedCountryBranch
	 */
	public String getCreditedCountryBranch() {
		return creditedCountryBranch;
	}

	/**
	 * @param creditedCountryBranch the creditedCountryBranch to set
	 */
	public void setCreditedCountryBranch(String creditedCountryBranch) {
		this.creditedCountryBranch = creditedCountryBranch;
	}
	
	
}
