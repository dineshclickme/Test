package com.aig.nge.bo;

import java.util.List;

import com.aig.nge.utilities.NGECommonUtil;
import com.fasterxml.jackson.annotation.JsonProperty;

public class MarketSegmentInfo {
	
	@JsonProperty("MarketSegment")
	private String marketSegment="";
	
	@JsonProperty("MarketSegmentCode")
	private String marketSegmentCode="";
	@JsonProperty("MarketSubSegment")
	private String marketSubSegment="";
	@JsonProperty("MarketSubSegmentCode")
	private String marketSubSegmentCode="";
	
	@JsonProperty("LegacyMarketSegmentCode")
	private String legacyMarketSegmentCode="";
	@JsonProperty("LegacyMarketSegmentName")
	private String legacyMarketSegmentName="";
	@JsonProperty("LegacyAIUMarketSegmentCode")
	private String legacyAIUMarketSegmentCode="";
	@JsonProperty("LegacyAIUMarketSegmentName")
	private String legacyAIUMarketSegmentName="";
	public String getMarketSegment() {
		return marketSegment;
	}
	public void setMarketSegment(String marketSegment) {
		marketSegment=NGECommonUtil.setDefaultStringValue(marketSegment);
		this.marketSegment = marketSegment;
	}
	public String getMarketSubSegment() {
		return marketSubSegment;
	}
	public void setMarketSubSegment(String marketSubSegment) {
		marketSubSegment=NGECommonUtil.setDefaultStringValue(marketSubSegment);

		this.marketSubSegment = marketSubSegment;
	}
	public String getLegacyMarketSegmentCode() {
		return legacyMarketSegmentCode;
	}
	public void setLegacyMarketSegmentCode(String legacyMarketSegmentCode) {
		legacyMarketSegmentCode=NGECommonUtil.setDefaultStringValue(legacyMarketSegmentCode);

		this.legacyMarketSegmentCode = legacyMarketSegmentCode;
	}
	public String getLegacyMarketSegmentName() {
		return legacyMarketSegmentName;
	}
	public void setLegacyMarketSegmentName(String legacyMarketSegmentName) {
		legacyMarketSegmentName=NGECommonUtil.setDefaultStringValue(legacyMarketSegmentName);

		this.legacyMarketSegmentName = legacyMarketSegmentName;
	}
	public String getLegacyAIUMarketSegmentCode() {
		return legacyAIUMarketSegmentCode;
	}
	public void setLegacyAIUMarketSegmentCode(String legacyAIUMarketSegmentCode) {
		legacyAIUMarketSegmentCode=NGECommonUtil.setDefaultStringValue(legacyAIUMarketSegmentCode);

		this.legacyAIUMarketSegmentCode = legacyAIUMarketSegmentCode;
	}
	public String getLegacyAIUMarketSegmentName() {
		return legacyAIUMarketSegmentName;
	}
	public void setLegacyAIUMarketSegmentName(String legacyAIUMarketSegmentName) {
		legacyAIUMarketSegmentName=NGECommonUtil.setDefaultStringValue(legacyAIUMarketSegmentName);

		this.legacyAIUMarketSegmentName = legacyAIUMarketSegmentName;
	}
	public String getMarketSegmentCode() {
		return marketSegmentCode;
	}
	public void setMarketSegmentCode(String marketSegmentCode) {
		marketSegmentCode=NGECommonUtil.setDefaultStringValue(marketSegmentCode);

		this.marketSegmentCode = marketSegmentCode;
	}
	public String getMarketSubSegmentCode() {
		return marketSubSegmentCode;
	}
	public void setMarketSubSegmentCode(String marketSubSegmentCode) {
		marketSubSegmentCode=NGECommonUtil.setDefaultStringValue(marketSubSegmentCode);

		this.marketSubSegmentCode = marketSubSegmentCode;
	}

}
