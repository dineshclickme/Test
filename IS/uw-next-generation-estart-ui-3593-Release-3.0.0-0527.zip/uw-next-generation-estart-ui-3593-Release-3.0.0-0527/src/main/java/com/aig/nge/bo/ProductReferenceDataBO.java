package com.aig.nge.bo;

import java.io.Serializable;
import java.util.List;

public class ProductReferenceDataBO implements Serializable
{
	private static final long serialVersionUID = 1L;

	private List<ProductTowerBO> data;
	
	public List<ProductTowerBO> getData() {
		return data;
	}
	public void setData(List<ProductTowerBO> data) {
		this.data = data;
	}

}
