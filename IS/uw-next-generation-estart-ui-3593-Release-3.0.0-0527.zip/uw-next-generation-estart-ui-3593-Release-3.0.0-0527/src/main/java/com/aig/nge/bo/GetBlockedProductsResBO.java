package com.aig.nge.bo;

import java.util.List;

public class GetBlockedProductsResBO {

    private List<BlockComponentProductBO> blockedComponentProduct;
    private List<AlertBlockDetailsBO> alertBlockDetails;
    private ProductBO blockingComponentProduct;
    private LimitBO limit;
    private GetBlockedInfoRows blocked;
	private GetBlockedInfoRows released;
	private String emailiconalertBlock;
	private String emailiconproductBlock;
	private String advancedBlockSearchMaxResult;
	
 	private List<AlertBlockDetailsBO> blockingAlertList;
   	private List<AlertBlockDetailsBO> releasedAlertList;
   	
	/**
	 * @return the blockedComponentProduct
	 */
	public List<BlockComponentProductBO> getBlockedComponentProduct() {
		return blockedComponentProduct;
	}
	/**
	 * @param blockedComponentProduct the blockedComponentProduct to set
	 */
	public void setBlockedComponentProduct(
			List<BlockComponentProductBO> blockedComponentProduct) {
		this.blockedComponentProduct = blockedComponentProduct;
	}
	
	
	/**
	 * @return the blockingComponentProduct
	 */
	public ProductBO getBlockingComponentProduct() {
		return blockingComponentProduct;
	}
	/**
	 * @param blockingComponentProduct the blockingComponentProduct to set
	 */
	public void setBlockingComponentProduct(ProductBO blockingComponentProduct) {
		this.blockingComponentProduct = blockingComponentProduct;
	}
	/**
	 * @return the limit
	 */
	public LimitBO getLimit() {
		return limit;
	}
	/**
	 * @param limit the limit to set
	 */
	public void setLimit(LimitBO limit) {
		this.limit = limit;
	}
	public GetBlockedInfoRows getBlocked() {
		return blocked;
	}
	public void setBlocked(GetBlockedInfoRows blocked) {
		this.blocked = blocked;
	}
	public GetBlockedInfoRows getReleased() {
		return released;
	}
	public void setReleased(GetBlockedInfoRows released) {
		this.released = released;
	}
	public List<AlertBlockDetailsBO> getAlertBlockDetails() {
		return alertBlockDetails;
	}
	public void setAlertBlockDetails(List<AlertBlockDetailsBO> alertBlockDetails) {
		this.alertBlockDetails = alertBlockDetails;
	}
	public String getEmailiconalertBlock() {
		return emailiconalertBlock;
	}
	public void setEmailiconalertBlock(String emailiconalertBlock) {
		this.emailiconalertBlock = emailiconalertBlock;
	}
	public String getEmailiconproductBlock() {
		return emailiconproductBlock;
	}
	public void setEmailiconproductBlock(String emailiconproductBlock) {
		this.emailiconproductBlock = emailiconproductBlock;
	}
	public List<AlertBlockDetailsBO> getBlockingAlertList() {
		return blockingAlertList;
	}
	public void setBlockingAlertList(List<AlertBlockDetailsBO> blockingAlertList) {
		this.blockingAlertList = blockingAlertList;
	}
	public List<AlertBlockDetailsBO> getReleasedAlertList() {
		return releasedAlertList;
	}
	public void setReleasedAlertList(List<AlertBlockDetailsBO> releasedAlertList) {
		this.releasedAlertList = releasedAlertList;
	}
	public String getAdvancedBlockSearchMaxResult() {
		return advancedBlockSearchMaxResult;
	}
	public void setAdvancedBlockSearchMaxResult(String advancedBlockSearchMaxResult) {
		this.advancedBlockSearchMaxResult = advancedBlockSearchMaxResult;
	}
}
