package com.aig.nge.bo;


public class UpdateProductRespBO {
    private String transactionId;
    private String transactionVersionNo;
    private UpdateProductsDetailRsBO productsRs;
	/**
	 * @return the transactionId
	 */
	public String getTransactionId() {
		return transactionId;
	}
	/**
	 * @param transactionId the transactionId to set
	 */
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	/**
	 * @return the transactionVersionNo
	 */
	public String getTransactionVersionNo() {
		return transactionVersionNo;
	}
	/**
	 * @param transactionVersionNo the transactionVersionNo to set
	 */
	public void setTransactionVersionNo(String transactionVersionNo) {
		this.transactionVersionNo = transactionVersionNo;
	}
	/**
	 * @return the productsRs
	 */
	public UpdateProductsDetailRsBO getProductsRs() {
		return productsRs;
	}
	/**
	 * @param productsRs the productsRs to set
	 */
	public void setProductsRs(UpdateProductsDetailRsBO productsRs) {
		this.productsRs = productsRs;
	}
    
}
