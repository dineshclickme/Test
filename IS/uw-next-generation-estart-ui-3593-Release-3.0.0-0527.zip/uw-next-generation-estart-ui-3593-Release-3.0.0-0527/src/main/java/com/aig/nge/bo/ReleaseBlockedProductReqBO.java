package com.aig.nge.bo;

import java.util.List;

public class ReleaseBlockedProductReqBO {
	private BlockReleaseBO blockNo;
    private List<ReleaseProductBO> blockedProducts;
    private ProductBO blockingProduct;
	/**
	 * @return the blockNo
	 */
	public BlockReleaseBO getBlockNo() {
		return blockNo;
	}
	/**
	 * @param blockNo the blockNo to set
	 */
	public void setBlockNo(BlockReleaseBO blockNo) {
		this.blockNo = blockNo;
	}
	/**
	 * @return the blockedProducts
	 */
	public List<ReleaseProductBO> getBlockedProducts() {
		return blockedProducts;
	}
	/**
	 * @param blockedProducts the blockedProducts to set
	 */
	public void setBlockedProducts(List<ReleaseProductBO> blockedProducts) {
		this.blockedProducts = blockedProducts;
	}
	/**
	 * @return the blockingProduct
	 */
	public ProductBO getBlockingProduct() {
		return blockingProduct;
	}
	/**
	 * @param blockingProduct the blockingProduct to set
	 */
	public void setBlockingProduct(ProductBO blockingProduct) {
		this.blockingProduct = blockingProduct;
	}
}
