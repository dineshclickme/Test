package com.aig.nge.bo;

import java.util.List;

public class SearchSubmissionRows {

	private List<SubmissionRsSearchSubmissionsBO> rows;
	private String submissionSearchByAccMaxResult;

	public String getSubmissionSearchByAccMaxResult() {
		return submissionSearchByAccMaxResult;
	}

	public void setSubmissionSearchByAccMaxResult(
			String submissionSearchByAccMaxResult) {
		this.submissionSearchByAccMaxResult = submissionSearchByAccMaxResult;
	}

	/**
	 * @return the rows
	 */
	public List<SubmissionRsSearchSubmissionsBO> getRows() {
		return rows;
	}

	/**
	 * @param rows the rows to set
	 */
	public void setRows(List<SubmissionRsSearchSubmissionsBO> rows) {
		this.rows = rows;
	}
	
	
}
