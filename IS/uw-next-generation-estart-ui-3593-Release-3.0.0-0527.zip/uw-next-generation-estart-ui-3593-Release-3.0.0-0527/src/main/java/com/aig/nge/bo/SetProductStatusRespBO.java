package com.aig.nge.bo;

import java.util.List;

public class SetProductStatusRespBO {
    private List<ProductRespTypeBO> workingResponse;
    private List<ProductRespTypeBO> quoteProductsResponse;
    private List<ProductRespTypeBO> bindProductsResponse;
    private List<ProductRespTypeBO> declineResponse;
    private List<ProductRespTypeBO> lostResponse;
    private List<ProductRespTypeBO> cancelResponse;
    private List<ProductRespTypeBO> voidResponse;
	/**
	 * @return the workingResponse
	 */
	public List<ProductRespTypeBO> getWorkingResponse() {
		return workingResponse;
	}
	/**
	 * @param workingResponse the workingResponse to set
	 */
	public void setWorkingResponse(List<ProductRespTypeBO> workingResponse) {
		this.workingResponse = workingResponse;
	}
	/**
	 * @return the quoteProductsResponse
	 */
	public List<ProductRespTypeBO> getQuoteProductsResponse() {
		return quoteProductsResponse;
	}
	/**
	 * @param quoteProductsResponse the quoteProductsResponse to set
	 */
	public void setQuoteProductsResponse(
			List<ProductRespTypeBO> quoteProductsResponse) {
		this.quoteProductsResponse = quoteProductsResponse;
	}
	/**
	 * @return the bindProductsResponse
	 */
	public List<ProductRespTypeBO> getBindProductsResponse() {
		return bindProductsResponse;
	}
	/**
	 * @param bindProductsResponse the bindProductsResponse to set
	 */
	public void setBindProductsResponse(List<ProductRespTypeBO> bindProductsResponse) {
		this.bindProductsResponse = bindProductsResponse;
	}
	/**
	 * @return the declineResponse
	 */
	public List<ProductRespTypeBO> getDeclineResponse() {
		return declineResponse;
	}
	/**
	 * @param declineResponse the declineResponse to set
	 */
	public void setDeclineResponse(List<ProductRespTypeBO> declineResponse) {
		this.declineResponse = declineResponse;
	}
	/**
	 * @return the lostResponse
	 */
	public List<ProductRespTypeBO> getLostResponse() {
		return lostResponse;
	}
	/**
	 * @param lostResponse the lostResponse to set
	 */
	public void setLostResponse(List<ProductRespTypeBO> lostResponse) {
		this.lostResponse = lostResponse;
	}
	/**
	 * @return the cancelResponse
	 */
	public List<ProductRespTypeBO> getCancelResponse() {
		return cancelResponse;
	}
	/**
	 * @param cancelResponse the cancelResponse to set
	 */
	public void setCancelResponse(List<ProductRespTypeBO> cancelResponse) {
		this.cancelResponse = cancelResponse;
	}
	/**
	 * @return the voidResponse
	 */
	public List<ProductRespTypeBO> getVoidResponse() {
		return voidResponse;
	}
	/**
	 * @param voidResponse the voidResponse to set
	 */
	public void setVoidResponse(List<ProductRespTypeBO> voidResponse) {
		this.voidResponse = voidResponse;
	}
}
