package com.aig.nge.bo;

public class BlockAdvancedSearchBO {

	private Long submissionNo;
	private Long accountNo;
	private String underwriterId;
	private String submissionEnteredFromDate;
	private String submissionEnteredToDate;
	private String underWrtierName;
	private String accountName;
	public Long getSubmissionNo() {
		return submissionNo;
	}
	public void setSubmissionNo(Long submissionNo) {
		this.submissionNo = submissionNo;
	}
	public Long getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(Long accountNo) {
		this.accountNo = accountNo;
	}
	public String getUnderwriterId() {
		return underwriterId;
	}
	public void setUnderwriterId(String underwriterId) {
		this.underwriterId = underwriterId;
	}
	public String getSubmissionEnteredFromDate() {
		return submissionEnteredFromDate;
	}
	public void setSubmissionEnteredFromDate(String submissionEnteredFromDate) {
		this.submissionEnteredFromDate = submissionEnteredFromDate;
	}
	public String getSubmissionEnteredToDate() {
		return submissionEnteredToDate;
	}
	public void setSubmissionEnteredToDate(String submissionEnteredToDate) {
		this.submissionEnteredToDate = submissionEnteredToDate;
	}
	public String getUnderWrtierName() {
		return underWrtierName;
	}
	public void setUnderWrtierName(String underWrtierName) {
		this.underWrtierName = underWrtierName;
	}
	public String getAccountName() {
		return accountName;
	}
	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}
	
}
