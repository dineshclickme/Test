package com.aig.nge.bo;


public class AccountInfoBO {
    private AccountShortInfoBO accountShortInfo;
    private AccountAddlInfoBO accountAddlInfo;
	/**
	 * @return the accountShortInfo
	 */
	public AccountShortInfoBO getAccountShortInfo() {
		return accountShortInfo;
	}
	/**
	 * @param accountShortInfo the accountShortInfo to set
	 */
	public void setAccountShortInfo(AccountShortInfoBO accountShortInfo) {
		this.accountShortInfo = accountShortInfo;
	}
	/**
	 * @return the accountAddlInfo
	 */
	public AccountAddlInfoBO getAccountAddlInfo() {
		return accountAddlInfo;
	}
	/**
	 * @param accountAddlInfo the accountAddlInfo to set
	 */
	public void setAccountAddlInfo(AccountAddlInfoBO accountAddlInfo) {
		this.accountAddlInfo = accountAddlInfo;
	}
}
