/**
 * 
 */
package com.aig.nge.bo;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;


/**
 * @author Bennym
 *
 */
public class ExpiringPoductBO {

	@JsonInclude(JsonInclude.Include.ALWAYS)
	String id;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	List<ProductBO> expiringProductBO;

	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public List<ProductBO> getExpiringProductBO() {
		return expiringProductBO;
	}
	public void setExpiringProductBO(List<ProductBO> expiringProductBO) {
		this.expiringProductBO = expiringProductBO;
	}
}
