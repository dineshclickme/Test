package com.aig.nge.bo;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;

public class SearchSubBO {
	
	@JsonIgnore
    Long accountNo;
	@JsonIgnore
    String accountNm;
	@JsonIgnore
    String policyNo;
	@JsonInclude(JsonInclude.Include.ALWAYS)
    Long submissionNo;
	@JsonIgnore
    Long transactionId;
	@JsonIgnore
    String contractNo;
	@JsonInclude(JsonInclude.Include.ALWAYS)
    String searchby;
	@JsonInclude(JsonInclude.Include.ALWAYS)
    String searchValue;
    
    /**
	 * @return the searchValue
	 */
	public String getSearchValue() {
		return searchValue;
	}

	/**
	 * @param searchValue the searchValue to set
	 */
	public void setSearchValue(String searchValue) {
		this.searchValue = searchValue;
	}

	public String getSearchby() {
		return searchby;
	}

	public void setSearchby(String searchby) {
		this.searchby = searchby;
	}

	/**
	 * @return the accountNo
	 */
	public Long getAccountNo() {
		return accountNo;
	}

	/**
	 * @param accountNo the accountNo to set
	 */
	public void setAccountNo(Long accountNo) {
		this.accountNo = accountNo;
	}

	/**
	 * @return the accountNm
	 */
	public String getAccountNm() {
		return accountNm;
	}

	/**
	 * @param accountNm the accountNm to set
	 */
	public void setAccountNm(String accountNm) {
		this.accountNm = accountNm;
	}

	/**
	 * @return the policyNo
	 */
	public String getPolicyNo() {
		return policyNo;
	}

	/**
	 * @param policyNo the policyNo to set
	 */
	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	/**
	 * @return the submissionNo
	 */
	public Long getSubmissionNo() {
		return submissionNo;
	}

	/**
	 * @param submissionNo the submissionNo to set
	 */
	public void setSubmissionNo(Long submissionNo) {
		this.submissionNo = submissionNo;
	}

	/**
	 * @return the transactionId
	 */
	public Long getTransactionId() {
		return transactionId;
	}

	/**
	 * @param transactionId the transactionId to set
	 */
	public void setTransactionId(Long transactionId) {
		this.transactionId = transactionId;
	}

	/**
	 * @return the contractNo
	 */
	public String getContractNo() {
		return contractNo;
	}

	/**
	 * @param contractNo the contractNo to set
	 */
	public void setContractNo(String contractNo) {
		this.contractNo = contractNo;
	}

}
