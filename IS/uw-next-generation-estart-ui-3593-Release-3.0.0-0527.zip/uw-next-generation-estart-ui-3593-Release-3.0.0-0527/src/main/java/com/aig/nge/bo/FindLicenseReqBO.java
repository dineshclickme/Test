/**
 * 
 */
package com.aig.nge.bo;

import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * @author Bennym
 *
 */
public class FindLicenseReqBO {
	private String sourceCd;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String producerCd;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String agentId;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String licenseNo;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String licenseStateCd;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String surplusLineCd;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String surplusLineInd;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String licenseNm;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String totalRecCount;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String rowStart;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String rowEnd;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String assignCd;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String division;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String transEffDt;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String accountNo;
	
	public String getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}
	public String getDivision() {
		return division;
	}
	public void setDivision(String division) {
		this.division = division;
	}
	
	
	public String getTransEffDt() {
		return transEffDt;
	}
	public void setTransEffDt(String transEffDt) {
		this.transEffDt = transEffDt;
	}
	/**
	 * @return the assignCd
	 */
	public String getAssignCd() {
		return assignCd;
	}
	/**
	 * @param assignCd the assignCd to set
	 */
	public void setAssignCd(String assignCd) {
		this.assignCd = assignCd;
	}
	/**
	 * @return the sourceCd
	 */
	public String getSourceCd() {
		return sourceCd;
	}
	/**
	 * @param sourceCd the sourceCd to set
	 */
	public void setSourceCd(String sourceCd) {
		this.sourceCd = sourceCd;
	}
	/**
	 * @return the producerCd
	 */
	public String getProducerCd() {
		return producerCd;
	}
	/**
	 * @param producerCd the producerCd to set
	 */
	public void setProducerCd(String producerCd) {
		this.producerCd = producerCd;
	}
	/**
	 * @return the agentId
	 */
	public String getAgentId() {
		return agentId;
	}
	/**
	 * @param agentId the agentId to set
	 */
	public void setAgentId(String agentId) {
		this.agentId = agentId;
	}
	/**
	 * @return the licenseNo
	 */
	public String getLicenseNo() {
		return licenseNo;
	}
	/**
	 * @param licenseNo the licenseNo to set
	 */
	public void setLicenseNo(String licenseNo) {
		this.licenseNo = licenseNo;
	}
	/**
	 * @return the licenseStateCd
	 */
	public String getLicenseStateCd() {
		return licenseStateCd;
	}
	/**
	 * @param licenseStateCd the licenseStateCd to set
	 */
	public void setLicenseStateCd(String licenseStateCd) {
		this.licenseStateCd = licenseStateCd;
	}
	/**
	 * @return the surplusLineCd
	 */
	public String getSurplusLineCd() {
		return surplusLineCd;
	}
	/**
	 * @param surplusLineCd the surplusLineCd to set
	 */
	public void setSurplusLineCd(String surplusLineCd) {
		this.surplusLineCd = surplusLineCd;
	}
	/**
	 * @return the surplusLineInd
	 */
	public String getSurplusLineInd() {
		return surplusLineInd;
	}
	/**
	 * @param surplusLineInd the surplusLineInd to set
	 */
	public void setSurplusLineInd(String surplusLineInd) {
		this.surplusLineInd = surplusLineInd;
	}
	/**
	 * @return the licenseNm
	 */
	public String getLicenseNm() {
		return licenseNm;
	}
	/**
	 * @param licenseNm the licenseNm to set
	 */
	public void setLicenseNm(String licenseNm) {
		this.licenseNm = licenseNm;
	}
	/**
	 * @return the totalRecCount
	 */
	public String getTotalRecCount() {
		return totalRecCount;
	}
	/**
	 * @param totalRecCount the totalRecCount to set
	 */
	public void setTotalRecCount(String totalRecCount) {
		this.totalRecCount = totalRecCount;
	}
	/**
	 * @return the rowStart
	 */
	public String getRowStart() {
		return rowStart;
	}
	/**
	 * @param rowStart the rowStart to set
	 */
	public void setRowStart(String rowStart) {
		this.rowStart = rowStart;
	}
	/**
	 * @return the rowEnd
	 */
	public String getRowEnd() {
		return rowEnd;
	}
	/**
	 * @param rowEnd the rowEnd to set
	 */
	public void setRowEnd(String rowEnd) {
		this.rowEnd = rowEnd;
	}
		
}
