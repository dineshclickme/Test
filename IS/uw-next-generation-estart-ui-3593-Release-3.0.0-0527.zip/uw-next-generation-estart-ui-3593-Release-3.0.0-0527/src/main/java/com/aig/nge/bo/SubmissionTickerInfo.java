package com.aig.nge.bo;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.LogManager;

//POJO bean to hold the ticker related fields
public class SubmissionTickerInfo {
	//TCS CE Team Changes Starts Here
	private static final Logger logger = LogManager.getLogger(SubmissionTickerInfo.class);
	//TCS CE Team Changes Starts Here
	private long submissionNo;
	private String businessTypeCd;
	private String businessTypeDescription;
	private double limit;
	private double attachmentPointAmt;
	private double grossPremium;
	private String productCoverageTypeCd;
	private String productName;
	private String uwSubProductCd;
	private String uwSubProductNm;
	private String marketableProductCd;
	private String marketableProductNm;
	private String marketableProductComponentCd;
	private String marketableProductComponentNm;
	private String divName;
	private String workingBranchName;
	private String creditedBranchName;
	private int accountNo;
	private String accountName;
	private String producerName;
	private boolean marketableProductUWIn;
	private String underwriterId;
	private String underwriterFirstName;
	private String underwriterMiddleName;
	private String underwriterLastName;
	private String underwriterPhone1;
	private String underwriterEmail;
	private String underwriterCountry;
	private Date polEffDt;
	private String policyNo;
	private Date updateTimeStamp;
	private Date statusEnteredDate;
	private String creditedRegionName;
	private String creditedCountryName;
	private int policyId;
	private long transactionId;
	private short versionSqn;
	private long transactionComponentId;
	private int componentProductId;
	private int productDetailId;
	private String feedDs;
	private int tuwSubProductId;
	private String divisionNo;
	private String soruceCd;
	private String profitCenterCd;
	
	/* December 2017 Maintenance Release 2.8 - Correct division and business type in eStart Ticker for legacy submissions (1600) - Starts */
	private String legacyBusinessTypeCd;
	private String legacyBusinessTypeDescription;
	private String legacyIndicator;
	
	public String getLegacyBusinessTypeCd() {
		return legacyBusinessTypeCd;
	}
	public void setLegacyBusinessTypeCd(String legacyBusinessTypeCd) {
		this.legacyBusinessTypeCd = legacyBusinessTypeCd;
	}
	
	public String getLegacyBusinessTypeDescription() {
		return legacyBusinessTypeDescription;
	}
	public void setLegacyBusinessTypeDescription(
			String legacyBusinessTypeDescription) {
		this.legacyBusinessTypeDescription = legacyBusinessTypeDescription;
	}
	
	public String getLegacyIndicator() {
		return legacyIndicator;
	}
	public void setLegacyIndicator(String legacyIndicator) {
		this.legacyIndicator = legacyIndicator;
	}
	/* December 2017 Maintenance Release 2.8 - Correct division and business type in eStart Ticker for legacy submissions (1600) - Ends */	
	
	/* Q1 2018 Maintenance Release - NGE UI Ticker Issue - Starts */
	private String legacyWorkingBranchCode;
	private String legacyCreditedBranchCode;
		
	public String getLegacyWorkingBranchCode() {
		return legacyWorkingBranchCode;
	}
	public void setLegacyWorkingBranchCode(String legacyWorkingBranchCode) {
		this.legacyWorkingBranchCode = legacyWorkingBranchCode;
	}
	public String getLegacyCreditedBranchCode() {
		return legacyCreditedBranchCode;
	}
	public void setLegacyCreditedBranchCode(String legacyCreditedBranchCode) {
		this.legacyCreditedBranchCode = legacyCreditedBranchCode;
	}
	/* Q1 2018 Maintenance Release - NGE UI Ticker Issue - Ends */
	
	public String getFeedDs() {
		return feedDs;
	}
	public void setFeedDs(String feedDs) {
		this.feedDs = feedDs;
	}
	public String getUnderwriterCountry() {
		return underwriterCountry;
	}
	public void setUnderwriterCountry(String underwriterCountry) {
		this.underwriterCountry = underwriterCountry;
	}

	public String getCreditedRegionName() {
		return (null!=creditedRegionName) ? creditedRegionName.trim() : "";
	}

	public void setCreditedRegionName(String creditedRegionName) {
		this.creditedRegionName = creditedRegionName;
	}

	public String getCreditedCountryName() {
		return (null!=creditedCountryName) ? creditedCountryName.trim() : "";
	}

	public void setCreditedCountryName(String creditedCountryName) {
		this.creditedCountryName = creditedCountryName;
	}
	public String getUnderwriterFirstName() {
		return underwriterFirstName;
	}

	public void setUnderwriterFirstName(String underwriterFirstName) {
		this.underwriterFirstName = underwriterFirstName;
	}

	public String getUnderwriterLastName() {
		return underwriterLastName;
	}

	public void setUnderwriterLastName(String underwriterLastName) {
		this.underwriterLastName = underwriterLastName;
	}
	
	public SubmissionTickerInfo() {
		
	}
	
	public String getUnderwriterId() {
		return underwriterId;
	}

	public void setUnderwriterId(String underwriterId) {
		this.underwriterId = underwriterId;
	}

	public String getPolicyNo() {
		return this.policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public String getBusinessTypeCd() {
		return this.businessTypeCd;
	}

	public void setBusinessTypeCd(String businessTypeCd) {
		this.businessTypeCd = businessTypeCd;
	}
	
	public String getProductCoverageTypeCd() {
		return this.productCoverageTypeCd;
	}

	public void setProductCoverageTypeCd(String productCoverageTypeCd) {
		this.productCoverageTypeCd = productCoverageTypeCd;
	}

	public String getProductCoverageTypeDescription() {
		String productCoverageTypeDescription = "";
		if (this.productCoverageTypeCd != null) {
			if("P".equalsIgnoreCase(this.productCoverageTypeCd)) {
				productCoverageTypeDescription = "Primary";
			}
			else if("E".equalsIgnoreCase(this.productCoverageTypeCd)) {
				productCoverageTypeDescription = "Excess";
			}
			else {
				productCoverageTypeDescription = "";
			}
		}
		return productCoverageTypeDescription;
	}

	public Date getUpdateTimeStamp() {
		return updateTimeStamp;
	}

	public void setUpdateTimeStamp(Date updateTimeStamp) {
		this.updateTimeStamp = updateTimeStamp;
	}
	
	private static final SimpleDateFormat STATUS_ENTERED_DT = new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss z", Locale.US);
	public String getStatusEnteredDate4Display() {
		return STATUS_ENTERED_DT.format(getStatusEnteredDate());
	}

	public Date getStatusEnteredDate() {
		return statusEnteredDate;
	}

	public void setStatusEnteredDate(Date statusEnteredDate) {
		this.statusEnteredDate = statusEnteredDate;
	}

	private static final SimpleDateFormat DATE_ALONE = new SimpleDateFormat("MMM dd, yyyy");
	public String getPolEffDt4Display() {
		return DATE_ALONE.format(getPolEffDt());
	}
	
	public Date getPolEffDt() {
		return polEffDt;
	}

	public void setPolEffDt(Date polEffDt) {
		this.polEffDt = polEffDt;
	}
	private static final DecimalFormat absDollar = new DecimalFormat("$###,###,###,###,###.##");

	public String getLimit4Display() {
		
		return (1000<getLimit())? 
				absDollar.format((Math.round(getLimit()/1000.0))*1000):absDollar.format((long)getLimit());
	}
	public String getGrossPremium4Display() {
		return (0!=getGrossPremium())? 
				absDollar.format((Math.round(getGrossPremium()/1000.0))*1000):"0";
	}
	private String reFormatPhone (String word)
	{
		//Format the US phone numbers 
		if(null!=this.underwriterCountry && "UNITED STATES".equalsIgnoreCase(this.underwriterCountry)) {
			//extracting the numeric characters 
			String tempWord = word.replaceAll("[^0-9]", "");
			//format the phone number if it is 10 digit length
			return (tempWord != null && tempWord.length() == 10 && 
					!"0".equals(tempWord.substring(0, 1)) && !"1".equals(tempWord.substring(0, 1))) ?
					(String.format("(%s) %s-%s",
					tempWord.substring(0, 3),
					tempWord.substring(3, 6),
					tempWord.substring(6))) : word;
		}
		return word;
	 }

	public String getUWPhone14Display() {
		try {
			return (getUnderwriterPhone1() == null || "".equals(getUnderwriterPhone1().trim())) ?
				"" : reFormatPhone(getUnderwriterPhone1().trim());
		}catch(NumberFormatException nfe) {
			logger.error("NumberFormatException getUWPhone14Display:" + nfe.getMessage());
			return "";
		}
	}

	private static final SimpleDateFormat UPDATE_TS = new SimpleDateFormat("EEE dd MMM yyyy hh:mm a z",Locale.US);
	public String getUpdateTimeStamp4Display() {
		try {
			return UPDATE_TS .format(updateTimeStamp);
		} catch(Exception e) {
			logger.error("Exception getUpdateTimeStamp4Display:" + e.getMessage());
			return "";
		}
	}

	public String getShortAccountName() {
		String shortAccountName;
		if (accountName  != null) {
			shortAccountName = (accountName.length()>30?
				accountName.substring(0,30) + "...": accountName);
		}
		else {
			shortAccountName = "";
		}
		return shortAccountName;
	}

	public long getSubmissionNo() {
		return submissionNo;
	}
	public void setSubmissionNo(long submissionNo) {
		this.submissionNo = submissionNo;
	}
	public double getLimit() {
		return limit;
	}
	public void setLimit(double limit) {
		this.limit = limit;
	}
	public double getGrossPremium() {
		return grossPremium;
	}
	public void setGrossPremium(double grossPremium) {
		this.grossPremium = grossPremium;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getProductName() {
		return (null!=productName) ? productName.trim() : "";
	}
	public String getDivName() {
		return (null != divName) ? divName.trim() : "";
	}
	public void setDivName(String divName) {
		this.divName = divName;
	}
	public String getWorkingBranchName() {
		return (null != workingBranchName) ? workingBranchName.trim(): "";
	}
	public void setWorkingBranchName(String workingBranchName) {
		this.workingBranchName = workingBranchName;
	}
	public String getCreditedBranchName() {
		return (null != creditedBranchName) ? creditedBranchName.trim(): "";
	}
	public void setCreditedBranchName(String creditedBranchName) {
		this.creditedBranchName = creditedBranchName;
	}
	public int getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}
	public String getAccountName() {
		return (null != accountName) ? accountName.trim(): "";
	}
	public String getXMLEncodedShortAccountName() {
		return encodeXMLElementData(getShortAccountName());
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}
	public String getProducerName() {
		return (null!=producerName) ? producerName.trim() : "";
	}
	public void setProducerName(String producerName) {
		this.producerName = producerName;
	}
	public String getUnderwriterName() {
		String firstName = (null!=this.underwriterFirstName) ? this.underwriterFirstName.trim() : "";
		String lastName = (null!=this.underwriterLastName) ? this.underwriterLastName.trim() : "";
		return String.format("%1s %2s", firstName, lastName);
	}
	public String getUnderwriterPhone1() {
		return underwriterPhone1;
	}
	public void setUnderwriterPhone1(String underwriterPhone1) {
		this.underwriterPhone1 = underwriterPhone1;
	}
	public String getUnderwriterEmail() {
		return underwriterEmail;
	}
	public void setUnderwriterEmail(String underwriterEmail) {
		this.underwriterEmail = underwriterEmail;
	}

	private String encodeXMLElementData(String input) {
		return (input != null? "<![CDATA["+input.replaceAll("<", "&lt;").
										replaceAll(">", "&gt;")+"]]>" : "");
	}
	public boolean isDomestic() {
		return ("UNITED STATES".equalsIgnoreCase(this.creditedCountryName) || 
				"CANADA".equalsIgnoreCase(this.creditedCountryName));
	}
	public void put(Object field, Object value) {
		if (value == null) {
			//override underwriter fields with marketable product underwriter details
			if(this.isMarketableProductUWIn()) {
				switch((String) field) { 
					case "MRK_UW_FIRST_NM":this.setUnderwriterFirstName(null);break;
					case "MRK_UW_MIDDLE_NM":this.setUnderwriterMiddleName(null);break;
					case "MRK_UW_LAST_NM":this.setUnderwriterLastName(null);break;
					case "MRK_UW_EMAIL_ADDRESS_TX":this.setUnderwriterEmail(null);break;
					case "MRK_UW_PHONE_NO":this.setUnderwriterPhone1(null);break;
					case "MRK_UW_COUNTRY_NM":this.setUnderwriterCountry(null);break;
				}
			}	
			return;
		}
		try {
			switch((String) field) { 
				case "POLICY_NO":this.setPolicyNo((String)value);break;
				case "POL_EFFECTIVE_DT":this.setPolEffDt((Date)value);break;
				case "POL_UPDATE_TS":
					this.setUpdateTimeStamp((Date)value);
					this.setStatusEnteredDate((Date)value);
					break;
				case "POL_PREMIUM_AM":this.setGrossPremium(((BigDecimal)value).doubleValue());break;
				case "PRODUCT_STATE_NM":this.setBusinessTypeCd((String)value);break;
				case "PRODUCT_STATE_DS":this.setBusinessTypeDescription((String)value);break;
				
				/* December 2017 Maintenance Release 2.8 - Correct division and business type in eStart Ticker for legacy submissions (1600) - Starts */
				case "BUSINESS_TYPE_CD":this.setLegacyBusinessTypeCd((String)value);break;
				case "BUSINESS_TYPE_DESCRIPTION":this.setLegacyBusinessTypeDescription((String)value);break;
				case "LEGACY_IN":this.setLegacyIndicator((String)value);break;
				/* December 2017 Maintenance Release 2.8 - Correct division and business type in eStart Ticker for legacy submissions (1600) - Ends */
				
				//component product underwriter
				case "UW_NO":this.setUnderwriterId(String.valueOf(value));break;
				case "UW_FIRST_NM":this.setUnderwriterFirstName((String)value);break;
				case "UW_MIDDLE_NM":this.setUnderwriterMiddleName((String)value);break;
				case "UW_LAST_NM":this.setUnderwriterLastName((String)value);break;
				case "UW_EMAIL_ADDRESS_TX":this.setUnderwriterEmail((String)value);break;
				case "UW_PHONE_NO":this.setUnderwriterPhone1((String)value);break;
				case "UW_COUNTRY_NM":this.setUnderwriterCountry((String)value);break;
				//marketable product underwriter (overriding component product underwriter)
				case "MRK_UW_NO":
					this.setMarketableProductUWIn(true);
					this.setUnderwriterId((String)value);break;
				case "MRK_UW_FIRST_NM":this.setUnderwriterFirstName((String)value);break;
				case "MRK_UW_MIDDLE_NM":this.setUnderwriterMiddleName((String)value);break;
				case "MRK_UW_LAST_NM":this.setUnderwriterLastName((String)value);break;
				case "MRK_UW_EMAIL_ADDRESS_TX":this.setUnderwriterEmail((String)value);break;
				case "MRK_UW_PHONE_NO":this.setUnderwriterPhone1((String)value);break;
				case "MRK_UW_COUNTRY_NM":this.setUnderwriterCountry((String)value);break;
				case "DIVISION_NM":this.setDivName((String)value);break;
				case "PROFIT_CENTER_CD":this.setProfitCenterCd((String)value);break;
				case "SOURCE_CD":this.setSoruceCd((String)value);break;
				/* Q1 2018 Maintenance Release - NGE UI Ticker Issue - Starts */
				case "LEGACY_WORKING_BRANCH_CD":this.setLegacyWorkingBranchCode((String)value);break;
				case "LEGACY_CREDITED_BRANCH_CD":this.setLegacyCreditedBranchCode((String)value);break;
				/* Q1 2018 Maintenance Release - NGE UI Ticker Issue - Ends */
				case "WORKING_BRANCH_NM":this.setWorkingBranchName((String)value);break;
				case "CREDITED_BRANCH_NM":this.setCreditedBranchName((String)value);break;
				case "CREDITED_BRANCH_COUNTRY_NM":this.setCreditedCountryName((String)value);break;
				case "CREDITED_COUNTRY_REGION":this.setCreditedRegionName((String)value);break;
				case "PRODUCER_NM":this.setProducerName((String)value);break;
				/**
				 * Db2 to Exadata Migration Changes - Cast Exception issues
				 */
				//case "SUBMISSION_NO":this.setSubmissionNo((Long)value);break;
				case "SUBMISSION_NO":this.setSubmissionNo(((BigDecimal) value).longValue());break;
				case "ACCOUNT_NO":this.setAccountNo(Integer.parseInt((String)value));break;
				case "ACCOUNT_NM":this.setAccountName((String)value);break;
				case "POLICY_LIMIT_AM":this.setLimit(((BigDecimal)value).doubleValue());break;
				case "ATTACHMENT_POINT_AM":
					this.setAttachmentPointAmt(((BigDecimal)value).doubleValue());
					if(this.getAttachmentPointAmt() > 0) {
						this.setProductCoverageTypeCd("E");
					} else {
						this.setProductCoverageTypeCd("P");
					}
					break;
				case "TUW_SUB_PRODUCT_CD":this.setUwSubProductCd((String)value);break;
				case "TUW_SUB_PRODUCT_NM":
					this.setUwSubProductNm((String)value);
					this.setProductName(this.uwSubProductNm);
					break;
				case "MARKETABLE_PRODUCT_CD":this.setMarketableProductCd((String)value);break;
				case "MARKETABLE_PRODUCT_NM":
					this.setMarketableProductNm((String)value);
					this.setProductName(this.marketableProductNm);
					break;
				case "MARKETABLE_PRODUCT_CMPNT_CD":this.setMarketableProductComponentCd((String)value);break;
				case "MARKETABLE_PRODUCT_CMPNT_NM":this.setMarketableProductComponentNm((String)value);break;
				/**
				 * Db2 to Exadata Migration Changes - Cast Exception issues
				 */
				//case "TUW_SUB_PRODUCT_ID":this.setTuwSubProductId((int)value);break;
				case "TUW_SUB_PRODUCT_ID":this.setTuwSubProductId(((BigDecimal) value).intValue());break;
				case "DIVISION_NO":
					this.setDivisionNo(String.valueOf(value));
					break;
					/**
					 * Db2 to Exadata Migration Changes - Cast Exception issues
					 */
/*	               case "POLICY_ID":this.setPolicyId((Integer)value);break;
	               case "TRANSACTION_ID":this.setTransactionId((Long)value);break;
	               case "VERSION_SQN":this.setVersionSqn(((Integer)value).shortValue());break;
	               case "TRANSACTION_COMPONENT_ID":this.setTransactionComponentId((Long)value);break;
	               case "COMPONENT_PRODUCT_ID":this.setComponentProductId((Integer)value);break;
	               case "PRODUCT_DETAIL_ID":this.setProductDetailId((Integer)value);break;*/

				case "POLICY_ID":this.setPolicyId(((BigDecimal) value).intValue());break;
				case "TRANSACTION_ID":this.setTransactionId(((BigDecimal) value).longValue());break;
				case "VERSION_SQN":this.setVersionSqn(((BigDecimal) value).shortValue());break;
				case "TRANSACTION_COMPONENT_ID":this.setTransactionComponentId(((BigDecimal) value).longValue());break;
				case "COMPONENT_PRODUCT_ID":this.setComponentProductId(((BigDecimal) value).intValue());break;
				case "PRODUCT_DETAIL_ID":this.setProductDetailId(((BigDecimal) value).intValue());break;
				case "FEED_DS":this.setFeedDs((String)value);break;
			}	
		} catch(Exception e) {
			logger.error(String.format("exception while binding data field: %1s %2s",field, e.toString()));
		}
	}
	public String getBusinessTypeDescription() {
		return businessTypeDescription;
	}
	public void setBusinessTypeDescription(String businessTypeDescription) {
		this.businessTypeDescription = businessTypeDescription;
	}
	public String getUnderwriterMiddleName() {
		return underwriterMiddleName;
	}
	public void setUnderwriterMiddleName(String underwriterMiddleName) {
		this.underwriterMiddleName = underwriterMiddleName;
	}
	public String getUwSubProductCd() {
		return uwSubProductCd;
	}
	public void setUwSubProductCd(String uwSubProductCd) {
		this.uwSubProductCd = uwSubProductCd;
	}
	public String getUwSubProductNm() {
		return uwSubProductNm;
	}
	public void setUwSubProductNm(String uwSubProductNm) {
		this.uwSubProductNm = uwSubProductNm;
	}
	public String getMarketableProductCd() {
		return marketableProductCd;
	}
	public void setMarketableProductCd(String marketableProductCd) {
		this.marketableProductCd = marketableProductCd;
	}
	public String getMarketableProductNm() {
		return marketableProductNm;
	}
	public void setMarketableProductNm(String marketableProductNm) {
		this.marketableProductNm = marketableProductNm;
	}
	public String getMarketableProductComponentCd() {
		return marketableProductComponentCd;
	}
	public void setMarketableProductComponentCd(String marketableProductComponentCd) {
		this.marketableProductComponentCd = marketableProductComponentCd;
	}
	public String getMarketableProductComponentNm() {
		return marketableProductComponentNm;
	}
	public void setMarketableProductComponentNm(
			String marketableProductComponentNm) {
		this.marketableProductComponentNm = marketableProductComponentNm;
	}
	public int getPolicyId() {
		return policyId;
	}
	public void setPolicyId(int policyId) {
		this.policyId = policyId;
	}
	public long getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(long transactionId) {
		this.transactionId = transactionId;
	}
	public short getVersionSqn() {
		return versionSqn;
	}
	public void setVersionSqn(short versionSqn) {
		this.versionSqn = versionSqn;
	}
	public long getTransactionComponentId() {
		return transactionComponentId;
	}
	public void setTransactionComponentId(long transactionComponentId) {
		this.transactionComponentId = transactionComponentId;
	}
	public int getComponentProductId() {
		return componentProductId;
	}
	public void setComponentProductId(int componentProductId) {
		this.componentProductId = componentProductId;
	}
	public int getProductDetailId() {
		return productDetailId;
	}
	public void setProductDetailId(int productDetailId) {
		this.productDetailId = productDetailId;
	}
	public String getMarketableProductKey(){
		StringBuilder key = null;
		if(null!= this.marketableProductCd) {
			key = new StringBuilder();
			key.append(this.policyId);
			key.append(String.format("-%1s", this.transactionId));
			key.append(String.format("-%1s", this.versionSqn));
			key.append(String.format("-%1s", this.marketableProductCd));
		}
		return (null==key ? null: key.toString());
	}
	public double getAttachmentPointAmt() {
		return attachmentPointAmt;
	}
	public void setAttachmentPointAmt(double attachmentPointAmt) {
		this.attachmentPointAmt = attachmentPointAmt;
	}
	public boolean isMarketableProductUWIn() {
		return marketableProductUWIn;
	}
	public void setMarketableProductUWIn(boolean marketableProductUWIn) {
		this.marketableProductUWIn = marketableProductUWIn;
	}
	public int getTuwSubProductId() {
		return tuwSubProductId;
	}
	public void setTuwSubProductId(int tuwSubProductId) {
		this.tuwSubProductId = tuwSubProductId;
	}
	public String getDivisionNo() {
		return divisionNo;
	}
	public void setDivisionNo(String divisionNo) {
		this.divisionNo = divisionNo;
	}
	public String getSoruceCd() {
		return soruceCd;
	}
	public void setSoruceCd(String soruceCd) {
		this.soruceCd = soruceCd;
	}
	public String getProfitCenterCd() {
		return profitCenterCd;
	}
	public void setProfitCenterCd(String profitCenterCd) {
		this.profitCenterCd = profitCenterCd;
	}
}
