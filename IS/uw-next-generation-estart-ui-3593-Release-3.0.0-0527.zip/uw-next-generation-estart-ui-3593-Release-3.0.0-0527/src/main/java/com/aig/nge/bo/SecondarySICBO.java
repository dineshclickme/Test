package com.aig.nge.bo;


public class SecondarySICBO {
    protected String sicCode;
    protected String sicSeqNo;
    protected String stateAbbr;
    protected String countryCode;
    protected String numberOfEmployeesTotal;
    protected String salesAmount;
    protected String locNo;
    protected String groupIndicator;
    protected String description;
	/**
	 * @return the sicCode
	 */
	public String getSicCode() {
		return sicCode;
	}
	/**
	 * @param sicCode the sicCode to set
	 */
	public void setSicCode(String sicCode) {
		this.sicCode = sicCode;
	}
	/**
	 * @return the sicSeqNo
	 */
	public String getSicSeqNo() {
		return sicSeqNo;
	}
	/**
	 * @param sicSeqNo the sicSeqNo to set
	 */
	public void setSicSeqNo(String sicSeqNo) {
		this.sicSeqNo = sicSeqNo;
	}
	/**
	 * @return the stateAbbr
	 */
	public String getStateAbbr() {
		return stateAbbr;
	}
	/**
	 * @param stateAbbr the stateAbbr to set
	 */
	public void setStateAbbr(String stateAbbr) {
		this.stateAbbr = stateAbbr;
	}
	/**
	 * @return the countryCode
	 */
	public String getCountryCode() {
		return countryCode;
	}
	/**
	 * @param countryCode the countryCode to set
	 */
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}
	/**
	 * @return the numberOfEmployeesTotal
	 */
	public String getNumberOfEmployeesTotal() {
		return numberOfEmployeesTotal;
	}
	/**
	 * @param numberOfEmployeesTotal the numberOfEmployeesTotal to set
	 */
	public void setNumberOfEmployeesTotal(String numberOfEmployeesTotal) {
		this.numberOfEmployeesTotal = numberOfEmployeesTotal;
	}
	/**
	 * @return the salesAmount
	 */
	public String getSalesAmount() {
		return salesAmount;
	}
	/**
	 * @param salesAmount the salesAmount to set
	 */
	public void setSalesAmount(String salesAmount) {
		this.salesAmount = salesAmount;
	}
	/**
	 * @return the locNo
	 */
	public String getLocNo() {
		return locNo;
	}
	/**
	 * @param locNo the locNo to set
	 */
	public void setLocNo(String locNo) {
		this.locNo = locNo;
	}
	/**
	 * @return the groupIndicator
	 */
	public String getGroupIndicator() {
		return groupIndicator;
	}
	/**
	 * @param groupIndicator the groupIndicator to set
	 */
	public void setGroupIndicator(String groupIndicator) {
		this.groupIndicator = groupIndicator;
	}
	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}
	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}
}
