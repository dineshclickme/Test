package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Set;


/**
 * The persistent class for the TERROR database table.
 * 
 */
@Entity
public class Terror implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="ERROR_ID")
	private short errorId;

	@Column(name="CREATE_TS")
	private Timestamp createTs;

	@Column(name="CREATE_USER_ID")
	private String createUserId;

	@Column(name="ERROR_CD")
	private String errorCd;

	@Column(name="ERROR_MESAGE_TX")
	private String errorMesageTx;

	@Column(name="UPDATE_TS")
	private Timestamp updateTs;

	@Column(name="UPDATE_USER_ID")
	private String updateUserId;

	//bi-directional many-to-one association to TerrorType
	@ManyToOne
	@JoinColumn(name="ERROR_TYPE_CD")
	private TerrorType terrorType;

	//bi-directional many-to-one association to TseverityLevel
	@ManyToOne
	@JoinColumn(name="SEVERITY_LEVEL_CD")
	private TseverityLevel tseverityLevel;

	//bi-directional many-to-one association to Tsystem
	@ManyToOne
	@JoinColumn(name="SYSTEM_ID")
	private Tsystem tsystem;

	//bi-directional many-to-one association to TerrorMapping
	@OneToMany(mappedBy="terror")
	private Set<TerrorMapping> terrorMappings;

	//bi-directional many-to-one association to TerrorLanguage
	@OneToMany(mappedBy="terror")
	private Set<TerrorLanguage> terrorLanguages;

    public Terror() {
    }

	public short getErrorId() {
		return this.errorId;
	}

	public void setErrorId(short errorId) {
		this.errorId = errorId;
	}

	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public String getErrorCd() {
		return this.errorCd;
	}

	public void setErrorCd(String errorCd) {
		this.errorCd = errorCd;
	}

	public String getErrorMesageTx() {
		return this.errorMesageTx;
	}

	public void setErrorMesageTx(String errorMesageTx) {
		this.errorMesageTx = errorMesageTx;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public TerrorType getTerrorType() {
		return this.terrorType;
	}

	public void setTerrorType(TerrorType terrorType) {
		this.terrorType = terrorType;
	}
	
	public TseverityLevel getTseverityLevel() {
		return this.tseverityLevel;
	}

	public void setTseverityLevel(TseverityLevel tseverityLevel) {
		this.tseverityLevel = tseverityLevel;
	}
	
	public Tsystem getTsystem() {
		return this.tsystem;
	}

	public void setTsystem(Tsystem tsystem) {
		this.tsystem = tsystem;
	}
	
	public Set<TerrorMapping> getTerrorMappings() {
		return this.terrorMappings;
	}

	public void setTerrorMappings(Set<TerrorMapping> terrorMappings) {
		this.terrorMappings = terrorMappings;
	}
	
	public Set<TerrorLanguage> getTerrorLanguages() {
		return this.terrorLanguages;
	}

	public void setTerrorLanguages(Set<TerrorLanguage> terrorLanguages) {
		this.terrorLanguages = terrorLanguages;
	}
	
}