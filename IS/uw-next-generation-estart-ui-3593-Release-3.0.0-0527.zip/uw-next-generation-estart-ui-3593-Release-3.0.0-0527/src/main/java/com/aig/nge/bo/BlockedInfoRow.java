package com.aig.nge.bo;

public class BlockedInfoRow {
	private String blockID;
	private String blockingProduct;
	private String accountName;
	private String submissionNo;
	private String transID;
	private String blockedPerson;
	private String attachementpt;
	private String lmtAmt;
	private String underwiterdetails;
	private String alternateContact;
	/**
	 * @return the blockID
	 */
	public String getBlockID() {
		return blockID;
	}
	/**
	 * @param blockID the blockID to set
	 */
	public void setBlockID(String blockID) {
		this.blockID = blockID;
	}
	/**
	 * @return the blockingProduct
	 */
	public String getBlockingProduct() {
		return blockingProduct;
	}
	/**
	 * @param blockingProduct the blockingProduct to set
	 */
	public void setBlockingProduct(String blockingProduct) {
		this.blockingProduct = blockingProduct;
	}
	/**
	 * @return the accountName
	 */
	public String getAccountName() {
		return accountName;
	}
	/**
	 * @param accountName the accountName to set
	 */
	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}
	/**
	 * @return the submissionNo
	 */
	public String getSubmissionNo() {
		return submissionNo;
	}
	/**
	 * @param submissionNo the submissionNo to set
	 */
	public void setSubmissionNo(String submissionNo) {
		this.submissionNo = submissionNo;
	}
	/**
	 * @return the transID
	 */
	public String getTransID() {
		return transID;
	}
	/**
	 * @param transID the transID to set
	 */
	public void setTransID(String transID) {
		this.transID = transID;
	}
	/**
	 * @return the blockedPerson
	 */
	public String getBlockedPerson() {
		return blockedPerson;
	}
	/**
	 * @param blockedPerson the blockedPerson to set
	 */
	public void setBlockedPerson(String blockedPerson) {
		this.blockedPerson = blockedPerson;
	}
	/**
	 * @return the attachementpt
	 */
	public String getAttachementpt() {
		return attachementpt;
	}
	/**
	 * @param attachementpt the attachementpt to set
	 */
	public void setAttachementpt(String attachementpt) {
		this.attachementpt = attachementpt;
	}
	/**
	 * @return the lmtAmt
	 */
	public String getLmtAmt() {
		return lmtAmt;
	}
	/**
	 * @param lmtAmt the lmtAmt to set
	 */
	public void setLmtAmt(String lmtAmt) {
		this.lmtAmt = lmtAmt;
	}
	/**
	 * @return the underwiterdetails
	 */
	public String getUnderwiterdetails() {
		return underwiterdetails;
	}
	/**
	 * @param underwiterdetails the underwiterdetails to set
	 */
	public void setUnderwiterdetails(String underwiterdetails) {
		this.underwiterdetails = underwiterdetails;
	}
	/**
	 * @return the alternateContact
	 */
	public String getAlternateContact() {
		return alternateContact;
	}
	/**
	 * @param alternateContact the alternateContact to set
	 */
	public void setAlternateContact(String alternateContact) {
		this.alternateContact = alternateContact;
	}
}
