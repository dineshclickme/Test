package com.aig.nge.bo;

import com.aig.nge.bo.MessErrBO;

public class FindAccountResponseBO {
	private FindAccountResultsBO findAccountResults;
    private MessErrBO messages;
    private MessErrBO errors;
    private String masterConditionCode;
	/**
	 * @return the findAccountResults
	 */
	public FindAccountResultsBO getFindAccountResults() {
		return findAccountResults;
	}
	/**
	 * @param findAccountResults the findAccountResults to set
	 */
	public void setFindAccountResults(FindAccountResultsBO findAccountResults) {
		this.findAccountResults = findAccountResults;
	}
	/**
	 * @return the messages
	 */
	public MessErrBO getMessages() {
		return messages;
	}
	/**
	 * @param messages the messages to set
	 */
	public void setMessages(MessErrBO messages) {
		this.messages = messages;
	}
	/**
	 * @return the errors
	 */
	public MessErrBO getErrors() {
		return errors;
	}
	/**
	 * @param errors the errors to set
	 */
	public void setErrors(MessErrBO errors) {
		this.errors = errors;
	}
	/**
	 * @return the masterConditionCode
	 */
	public String getMasterConditionCode() {
		return masterConditionCode;
	}
	/**
	 * @param masterConditionCode the masterConditionCode to set
	 */
	public void setMasterConditionCode(String masterConditionCode) {
		this.masterConditionCode = masterConditionCode;
	}
}
