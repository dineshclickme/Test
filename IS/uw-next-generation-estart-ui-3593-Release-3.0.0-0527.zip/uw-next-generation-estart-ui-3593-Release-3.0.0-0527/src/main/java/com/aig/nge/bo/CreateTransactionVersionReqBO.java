package com.aig.nge.bo;

import com.fasterxml.jackson.annotation.JsonInclude;


public class CreateTransactionVersionReqBO {

	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String transactionId;
	@JsonInclude(JsonInclude.Include.ALWAYS)
    private String transactionVersionNo;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String submissionNo;
	/**
	 * @return the transactionId
	 */
	public String getTransactionId() {
		return transactionId;
	}
	/**
	 * @param transactionId the transactionId to set
	 */
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	/**
	 * @return the transactionVersionNo
	 */
	public String getTransactionVersionNo() {
		return transactionVersionNo;
	}
	/**
	 * @param transactionVersionNo the transactionVersionNo to set
	 */
	public void setTransactionVersionNo(String transactionVersionNo) {
		this.transactionVersionNo = transactionVersionNo;
	}
	public String getSubmissionNo() {
		return submissionNo;
	}
	public void setSubmissionNo(String submissionNo) {
		this.submissionNo = submissionNo;
	}
}
