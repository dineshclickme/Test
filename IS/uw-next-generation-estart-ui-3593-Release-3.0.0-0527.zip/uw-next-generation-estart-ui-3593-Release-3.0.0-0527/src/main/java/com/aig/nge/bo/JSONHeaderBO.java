package com.aig.nge.bo;

public class JSONHeaderBO {
	
	
	private String id;
	private String code;
	private String type;
	private String description;
	private Object data;
	/**
	 * @return the data
	 */
	public Object getData() {
		return data;
	}
	/**
	 * @param data the data to set
	 */
	public void setData(Object data) {
		this.data = data;
	}		
	
	/*private SubmissionBO submission;
	
	public SubmissionBO getSubmission() {
		return submission;
	}
	public void setSubmission(SubmissionBO submission) {
		this.submission = submission;
	}*/
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	
	
	

}
