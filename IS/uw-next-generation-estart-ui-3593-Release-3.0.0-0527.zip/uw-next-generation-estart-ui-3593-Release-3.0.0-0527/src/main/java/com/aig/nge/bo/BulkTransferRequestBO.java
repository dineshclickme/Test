package com.aig.nge.bo;

import com.fasterxml.jackson.annotation.JsonInclude;

public class BulkTransferRequestBO {
	
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String fromUnderwriterId;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String toUnderwriterId;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String fromUnderwritername;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String toUnderwritername;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String productTower;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String divisionNo;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String filterDet;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String componentProductTower;
	
	public String getComponentProductTower() {
		return componentProductTower;
	}
	public void setComponentProductTower(String componentProductTower) {
		this.componentProductTower = componentProductTower;
	}
	public String getFromUnderwritername() {
		return fromUnderwritername;
	}
	public void setFromUnderwritername(String fromUnderwritername) {
		this.fromUnderwritername = fromUnderwritername;
	}
	public String getToUnderwritername() {
		return toUnderwritername;
	}
	public void setToUnderwritername(String toUnderwritername) {
		this.toUnderwritername = toUnderwritername;
	}
	public String getProductTower() {
		return productTower;
	}
	public void setProductTower(String productTower) {
		this.productTower = productTower;
	}
	public String getDivisionNo() {
		return divisionNo;
	}
	public void setDivisionNo(String divisionNo) {
		this.divisionNo = divisionNo;
	}
	public String getFilterDet() {
		return filterDet;
	}
	public void setFilterDet(String filterDet) {
		this.filterDet = filterDet;
	}
	public String getFromUnderwriterId() {
		return fromUnderwriterId;
	}
	public void setFromUnderwriterId(String fromUnderwriterId) {
		this.fromUnderwriterId = fromUnderwriterId;
	}
	public String getToUnderwriterId() {
		return toUnderwriterId;
	}
	public void setToUnderwriterId(String toUnderwriterId) {
		this.toUnderwriterId = toUnderwriterId;
	}

}
