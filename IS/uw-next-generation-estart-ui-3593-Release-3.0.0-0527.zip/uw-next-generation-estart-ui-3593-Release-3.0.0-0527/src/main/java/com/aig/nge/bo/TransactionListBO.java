package com.aig.nge.bo;

import java.util.List;
import java.util.Map;

public class TransactionListBO {
	
	private List<Map<Integer,String>> transactionNo;

	public List<Map<Integer, String>> getTransactionNo() {
		return transactionNo;
	}

	public void setTransactionNo(List<Map<Integer, String>> transactionNo) {
		this.transactionNo = transactionNo;
	}
}
