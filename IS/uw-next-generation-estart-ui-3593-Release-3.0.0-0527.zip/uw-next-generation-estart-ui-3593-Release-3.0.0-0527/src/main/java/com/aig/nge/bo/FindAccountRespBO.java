package com.aig.nge.bo;

import com.aig.nge.bo.IdentityBO;

public class FindAccountRespBO {
    private IdentityBO identity;
    private FindAccountResponseBO response;
	/**
	 * @return the identity
	 */
	public IdentityBO getIdentity() {
		return identity;
	}
	/**
	 * @param identity the identity to set
	 */
	public void setIdentity(IdentityBO identity) {
		this.identity = identity;
	}
	/**
	 * @return the response
	 */
	public FindAccountResponseBO getResponse() {
		return response;
	}
	/**
	 * @param response the response to set
	 */
	public void setResponse(FindAccountResponseBO response) {
		this.response = response;
	}
}
