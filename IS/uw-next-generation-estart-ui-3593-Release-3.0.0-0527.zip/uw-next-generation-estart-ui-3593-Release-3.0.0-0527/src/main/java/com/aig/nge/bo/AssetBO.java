package com.aig.nge.bo;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

public class AssetBO {
	
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String assetId;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String productTabKey;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String componentProductTabKey;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String assetType;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String assetValue;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private List<AttributesInfoBO> attributes;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String action;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String make;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String model;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String latitude;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String tailId;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String vesselId;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String longitude;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String transactionId;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String versionId;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private List<AttributesInfoUpdBO> attributesInfoUpdate;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String exstAttributeVal;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String aircraftserialnumber;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String aircraftregistrationnumber;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String aircraftmake;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String aircraftmodel;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String uavserialnumber;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String uavregistrationnumber;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String productTowerId;
	@JsonInclude(JsonInclude.Include.ALWAYS)	
	private String airportaddress;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String airportcode;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String airportname;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String hangaraddress;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String uavmake;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String uavmodel;
	//private String uavhangarname;
	@JsonInclude(JsonInclude.Include.ALWAYS)	
	private String hangarname;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String othermake;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String othermodel;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String uavothermake;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String uavothermodel;
	
	public String getHangarname() {
		return hangarname;
	}
	public void setHangarname(String hangarname) {
		this.hangarname = hangarname;
	}
	public String getProductTowerId() {
		return productTowerId;
	}
	public void setProductTowerId(String productTowerId) {
		this.productTowerId = productTowerId;
	}
	/**
	 * @return the transactionId
	 */
	public String getTransactionId() {
		return transactionId;
	}
	/**
	 * @param transactionId the transactionId to set
	 */
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	/**
	 * @return the versionId
	 */
	public String getVersionId() {
		return versionId;
	}
	/**
	 * @param versionId the versionId to set
	 */
	public void setVersionId(String versionId) {
		this.versionId = versionId;
	}
	/**
	 * @return the exstAttributeVal
	 */
	public String getExstAttributeVal() {
		return exstAttributeVal;
	}
	/**
	 * @param exstAttributeVal the exstAttributeVal to set
	 */
	public void setExstAttributeVal(String exstAttributeVal) {
		this.exstAttributeVal = exstAttributeVal;
	}
	/**
	 * @return the attributesInfoUpdate
	 */
	public List<AttributesInfoUpdBO> getAttributesInfoUpdate() {
		return attributesInfoUpdate;
	}
	/**
	 * @param attributesInfoUpdate the attributesInfoUpdate to set
	 */
	public void setAttributesInfoUpdate(
			List<AttributesInfoUpdBO> attributesInfoUpdate) {
		this.attributesInfoUpdate = attributesInfoUpdate;
	}
	public String getAssetId() {
		return assetId;
	}
	public void setAssetId(String assetId) {
		this.assetId = assetId;
	}
	/**
	 * @return the action
	 */
	public String getAction() {
		return action;
	}
	/**
	 * @param action the action to set
	 */
	public void setAction(String action) {
		this.action = action;
	}
	
	public String getAssetType() {
		return assetType;
	}
	public void setAssetType(String assetType) {
		this.assetType = assetType;
	}
	public String getAssetValue() {
		return assetValue;
	}
	public void setAssetValue(String assetValue) {
		this.assetValue = assetValue;
	}
	public List<AttributesInfoBO> getAttributes() {
		return attributes;
	}
	public void setAttributes(List<AttributesInfoBO> attributes) {
		this.attributes = attributes;
	}
	
	/**
	 * @return the productTabKey
	 */
	public String getProductTabKey() {
		return productTabKey;
	}
	/**
	 * @param productTabKey the productTabKey to set
	 */
	public void setProductTabKey(String productTabKey) {
		this.productTabKey = productTabKey;
	}
	/**
	 * @return the componentProductTabKey
	 */
	public String getComponentProductTabKey() {
		return componentProductTabKey;
	}
	/**
	 * @param componentProductTabKey the componentProductTabKey to set
	 */
	public void setComponentProductTabKey(String componentProductTabKey) {
		this.componentProductTabKey = componentProductTabKey;
	}
	
	public String getTailId() {
		return tailId;
	}
	public void setTailId(String tailId) {
		this.tailId = tailId;
	}
	public String getVesselId() {
		return vesselId;
	}
	public void setVesselId(String vesselId) {
		this.vesselId = vesselId;
	}
	public String getMake() {
		return make;
	}
	public void setMake(String make) {
		this.make = make;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public String getLatitude() {
		return latitude;
	}
	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}
	public String getLongitude() {
		return longitude;
	}
	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}
	public String getAircraftserialnumber() {
		return aircraftserialnumber;
	}
	public void setAircraftserialnumber(String aircraftserialnumber) {
		this.aircraftserialnumber = aircraftserialnumber;
	}
	public String getAircraftregistrationnumber() {
		return aircraftregistrationnumber;
	}
	public void setAircraftregistrationnumber(String aircraftregistrationnumber) {
		this.aircraftregistrationnumber = aircraftregistrationnumber;
	}
	public String getAircraftmake() {
		return aircraftmake;
	}
	public void setAircraftmake(String aircraftmake) {
		this.aircraftmake = aircraftmake;
	}
	public String getAircraftmodel() {
		return aircraftmodel;
	}
	public void setAircraftmodel(String aircraftmodel) {
		this.aircraftmodel = aircraftmodel;
	}
	public String getUavserialnumber() {
		return uavserialnumber;
	}
	public void setUavserialnumber(String uavserialnumber) {
		this.uavserialnumber = uavserialnumber;
	}
	public String getUavregistrationnumber() {
		return uavregistrationnumber;
	}
	public void setUavregistrationnumber(String uavregistrationnumber) {
		this.uavregistrationnumber = uavregistrationnumber;
	}
	public String getAirportaddress() {
		return airportaddress;
	}
	public void setAirportaddress(String airportaddress) {
		this.airportaddress = airportaddress;
	}
	public String getAirportcode() {
		return airportcode;
	}
	public void setAirportcode(String airportcode) {
		this.airportcode = airportcode;
	}
	public String getAirportname() {
		return airportname;
	}
	public void setAirportname(String airportname) {
		this.airportname = airportname;
	}
	public String getHangaraddress() {
		return hangaraddress;
	}
	public void setHangaraddress(String hangaraddress) {
		this.hangaraddress = hangaraddress;
	}
	public String getUavmake() {
		return uavmake;
	}
	public void setUavmake(String uavmake) {
		this.uavmake = uavmake;
	}
	public String getUavmodel() {
		return uavmodel;
	}
	public void setUavmodel(String uavmodel) {
		this.uavmodel = uavmodel;
	}
	/*public String getUavhangarname() {
		return uavhangarname;
	}
	public void setUavhangarname(String uavhangarname) {
		this.uavhangarname = uavhangarname;
	}*/
	public String getOthermake() {
		return othermake;
	}
	public void setOthermake(String othermake) {
		this.othermake = othermake;
	}
	public String getOthermodel() {
		return othermodel;
	}
	public void setOthermodel(String othermodel) {
		this.othermodel = othermodel;
	}
	public String getUavothermake() {
		return uavothermake;
	}
	public void setUavothermake(String uavothermake) {
		this.uavothermake = uavothermake;
	}
	public String getUavothermodel() {
		return uavothermodel;
	}
	public void setUavothermodel(String uavothermodel) {
		this.uavothermodel = uavothermodel;
	}
	
	

	

}
