package com.aig.nge.bo;


public class ProductTowerAttrBO {
	public String mandatoryInd;
	public String allowMultipleInd;
	public String productTowerId;
	public String labelName;
	public String orderSequence;

	public String getOrderSequence() {
		return orderSequence;
	}
	public void setOrderSequence(String orderSequence) {
		this.orderSequence = orderSequence;
	}
	public String getLabelName() {
		return labelName;
	}
	public void setLabelName(String labelName) {
		this.labelName = labelName;
	}
	public String getProductTowerId() {
		return productTowerId;
	}
	public void setProductTowerId(String productTowerId) {
		this.productTowerId = productTowerId;
	}
	public String getMandatoryInd() {
		return mandatoryInd;
	}
	public void setMandatoryInd(String mandatoryInd) {
		this.mandatoryInd = mandatoryInd;
	}
	public String getAllowMultipleInd() {
		return allowMultipleInd;
	}
	public void setAllowMultipleInd(String allowMultipleInd) {
		this.allowMultipleInd = allowMultipleInd;
	}
}
