package com.aig.nge.bo;

public class ProducerIndividualForGetSubmissionBO {
	
	private String value;
	private String footer;
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	public String getFooter() {
		return footer;
	}
	public void setFooter(String footer) {
		this.footer = footer;
	}

}
