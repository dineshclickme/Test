package com.aig.nge.dao;

import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.aig.nge.entities.Tlanguage;
import com.aig.nge.repository.TLanguageRepository;

@Repository
public class LanguageDAO extends BaseDAO{
	
	@Autowired
	private TLanguageRepository tLanguageRepository;
	
	public Set<Tlanguage> getScreenLanguageDAO(){
		Set<Tlanguage> screenLanguage = tLanguageRepository.getScreenLanguagesDB();
		return screenLanguage;
	}
}