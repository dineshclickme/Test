package com.aig.nge.bo;

import com.fasterxml.jackson.annotation.JsonInclude;


public class UnBindTransactionRequestBO {
	
	@JsonInclude(JsonInclude.Include.ALWAYS)
    private String transactionId;
	@JsonInclude(JsonInclude.Include.ALWAYS)
    private String transactionVersionNo;
	@JsonInclude(JsonInclude.Include.ALWAYS)
    private String reasonCd;
	@JsonInclude(JsonInclude.Include.ALWAYS)
    private String comments;
	
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	/**
	 * @return the transactionId
	 */
	public String getTransactionId() {
		return transactionId;
	}
	/**
	 * @param transactionId the transactionId to set
	 */
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	/**
	 * @return the transactionVersionNo
	 */
	public String getTransactionVersionNo() {
		return transactionVersionNo;
	}
	/**
	 * @param transactionVersionNo the transactionVersionNo to set
	 */
	public void setTransactionVersionNo(String transactionVersionNo) {
		this.transactionVersionNo = transactionVersionNo;
	}
	/**
	 * @return the reasonCd
	 */
	public String getReasonCd() {
		return reasonCd;
	}
	/**
	 * @param reasonCd the reasonCd to set
	 */
	public void setReasonCd(String reasonCd) {
		this.reasonCd = reasonCd;
	}
    
}
