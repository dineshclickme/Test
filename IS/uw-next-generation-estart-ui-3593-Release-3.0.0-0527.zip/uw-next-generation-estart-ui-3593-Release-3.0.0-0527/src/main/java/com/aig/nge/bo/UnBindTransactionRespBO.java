package com.aig.nge.bo;


public class UnBindTransactionRespBO {
    private NGEViewOfMessageBO message;

	/**
	 * @return the message
	 */
	public NGEViewOfMessageBO getMessage() {
		return message;
	}

	/**
	 * @param message the message to set
	 */
	public void setMessage(NGEViewOfMessageBO message) {
		this.message = message;
	}
    
}
