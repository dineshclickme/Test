package com.aig.nge.bo;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

public class AdditionalAttributeReferenceDataBO implements Serializable{
	private static final long serialVersionUID = 1L;
	private String type;
	private List<Map<String,String>> data;
	private String url;
	private List<String> target;
	private ReverseBO reverse; 
	
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public List<Map<String, String>> getData() {
		return data;
	}
	public void setData(List<Map<String, String>> data) {
		this.data = data;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public List<String> getTarget() {
		return target;
	}
	public void setTarget(List<String> target) {
		this.target = target;
	}
	public ReverseBO getReverse() {
		return reverse;
	}
	public void setReverse(ReverseBO reverse) {
		this.reverse = reverse;
	}

}
