package com.aig.nge.dao;

import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;


import com.aig.nge.entities.Tproperty;
import com.aig.nge.repository.TPropertyRepository;

@Repository
public class PropertyDAO extends BaseDAO{

	@Autowired
	private TPropertyRepository tPropertyRepository;
	
	public Set<Tproperty> getpropertyDAO(String systemShortNm, String environment_Nm) {
		Set<Tproperty> propertySet;
		propertySet = tPropertyRepository.getpropertys(systemShortNm, environment_Nm);
		return propertySet;
	}
	public Tproperty getDynaCacheScheduleTimeDao(String systemShortNm, String environment_Nm,String propertyNm) {
		return tPropertyRepository.getDynaCacheScheduleTime(systemShortNm, environment_Nm,propertyNm);
	}
}
