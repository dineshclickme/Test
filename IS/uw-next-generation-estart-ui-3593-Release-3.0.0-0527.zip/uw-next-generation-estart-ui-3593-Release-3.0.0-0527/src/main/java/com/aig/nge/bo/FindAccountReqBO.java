package com.aig.nge.bo;


public class FindAccountReqBO {
    private IdentityBO identity;
    private FindAccountRequestBO request;
	/**
	 * @return the identity
	 */
	public IdentityBO getIdentity() {
		return identity;
	}
	/**
	 * @param identity the identity to set
	 */
	public void setIdentity(IdentityBO identity) {
		this.identity = identity;
	}
	/**
	 * @return the request
	 */
	public FindAccountRequestBO getRequest() {
		return request;
	}
	/**
	 * @param request the request to set
	 */
	public void setRequest(FindAccountRequestBO request) {
		this.request = request;
	}
}
