package com.aig.nge.bo;

import java.util.List;

public class AdditionalInsuredsBO {
	
	 private String processingInd;	    
	 private List<AdditionalInsuredBO> additionalInsuredRq;
	 private String productTabKey;
	 /**
	 * @return the productTabKey
	 */
	public String getProductTabKey() {
		return productTabKey;
	}
	/**
	 * @param productTabKey the productTabKey to set
	 */
	public void setProductTabKey(String productTabKey) {
		this.productTabKey = productTabKey;
	}
	/**
	 * @return the componentProductTabKey
	 */
	public String getComponentProductTabKey() {
		return componentProductTabKey;
	}
	/**
	 * @param componentProductTabKey the componentProductTabKey to set
	 */
	public void setComponentProductTabKey(String componentProductTabKey) {
		this.componentProductTabKey = componentProductTabKey;
	}
	private String componentProductTabKey;
	/**
	 * @return the processingInd
	 */
	public String getProcessingInd() {
		return processingInd;
	}
	/**
	 * @param processingInd the processingInd to set
	 */
	public void setProcessingInd(String processingInd) {
		this.processingInd = processingInd;
	}
	/**
	 * @return the additionalInsuredRq
	 */
	public List<AdditionalInsuredBO> getAdditionalInsuredRq() {
		return additionalInsuredRq;
	}
	/**
	 * @param additionalInsuredRq the additionalInsuredRq to set
	 */
	public void setAdditionalInsuredRq(List<AdditionalInsuredBO> additionalInsuredRq) {
		this.additionalInsuredRq = additionalInsuredRq;
	}
	 
	 
}
