package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Set;


/**
 * The persistent class for the TDIVISION database table.
 * 
 */
@Entity
public class Tdivision implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="DIVISION_NO")
	private short divisionNo;

	@Column(name="CREATE_TS")
	private Timestamp createTs;

	@Column(name="CREATE_USER_ID")
	private String createUserId;

	@Column(name="DIVISION_NM")
	private String divisionNm;

	@Column(name="UPDATE_TS")
	private Timestamp updateTs;

	@Column(name="UPDATE_USER_ID")
	private String updateUserId;


	//bi-directional many-to-one association to TprdctTwrTuwSubPrdctDiv
	@OneToMany(mappedBy="tdivision")
	private Set<TprdctTwrTuwSubPrdctDiv> tprdctTwrTuwSubPrdctDivs;

	//bi-directional many-to-one association to TproductDsp
	@OneToMany(mappedBy="tdivision", cascade={CascadeType.ALL})
	private Set<TproductDsp> tproductDsps;

	//bi-directional many-to-one association to TproductTowerDivision
	@OneToMany(mappedBy="tdivision", cascade={CascadeType.ALL})
	private Set<TproductTowerDivision> tproductTowerDivisions;

	//bi-directional many-to-one association to TtickerDivisionProduct
	@OneToMany(mappedBy="tdivision", cascade={CascadeType.ALL})
	private Set<TtickerDivisionProduct> ttickerDivisionProducts;

	//bi-directional many-to-one association to TlegacyPolicySplitRule
	@OneToMany(mappedBy="tdivision", cascade={CascadeType.ALL})
	private Set<TlegacyPolicySplitRule> tlegacyPolicySplitRules;

    public Tdivision() {
    }

	public short getDivisionNo() {
		return this.divisionNo;
	}

	public void setDivisionNo(short divisionNo) {
		this.divisionNo = divisionNo;
	}

	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public String getDivisionNm() {
		return this.divisionNm;
	}

	public void setDivisionNm(String divisionNm) {
		this.divisionNm = divisionNm;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public Set<TprdctTwrTuwSubPrdctDiv> getTprdctTwrTuwSubPrdctDivs() {
		return this.tprdctTwrTuwSubPrdctDivs;
	}

	public void setTprdctTwrTuwSubPrdctDivs(Set<TprdctTwrTuwSubPrdctDiv> tprdctTwrTuwSubPrdctDivs) {
		this.tprdctTwrTuwSubPrdctDivs = tprdctTwrTuwSubPrdctDivs;
	}
	
	public Set<TproductDsp> getTproductDsps() {
		return this.tproductDsps;
	}

	public void setTproductDsps(Set<TproductDsp> tproductDsps) {
		this.tproductDsps = tproductDsps;
	}
	
	public Set<TproductTowerDivision> getTproductTowerDivisions() {
		return this.tproductTowerDivisions;
	}

	public void setTproductTowerDivisions(Set<TproductTowerDivision> tproductTowerDivisions) {
		this.tproductTowerDivisions = tproductTowerDivisions;
	}
	
	public Set<TtickerDivisionProduct> getTtickerDivisionProducts() {
		return this.ttickerDivisionProducts;
	}

	public void setTtickerDivisionProducts(Set<TtickerDivisionProduct> ttickerDivisionProducts) {
		this.ttickerDivisionProducts = ttickerDivisionProducts;
	}
	
	public Set<TlegacyPolicySplitRule> getTlegacyPolicySplitRules() {
		return this.tlegacyPolicySplitRules;
	}

	public void setTlegacyPolicySplitRules(Set<TlegacyPolicySplitRule> tlegacyPolicySplitRules) {
		this.tlegacyPolicySplitRules = tlegacyPolicySplitRules;
	}
	
}