package com.aig.nge.bo;

import java.util.List;

public class AttributeValuesBO {
	
	List<String> attributeValue;

	public List<String> getAttributeValue() {
		return attributeValue;
	}

	public void setAttributeValue(List<String> attributeValue) {
		this.attributeValue = attributeValue;
	}
	

}
