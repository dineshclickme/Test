package com.aig.nge.bo;


import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;


public class SubmissionBO implements Serializable {
	
	@JsonIgnore
	private static final long serialVersionUID = 1L;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private ValueFooterBO accountName;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private ValueFooterBO initiatingProducerNo;
	private String submissionNo;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String countryName;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String sourceCd;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String accountNumberHidden;
	/* 2021 MDM Changes - Starts */
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String mdmPartyIdHidden;
	/* 2021 MDM Changes - Ends */
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String enableNextPage;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String currentPageNbr;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String pageDisplayCount;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String producerCountryCd;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String producerBranchId;
	//MDM Party ID adding in Create Submission Request - Start	
	@JsonInclude(JsonInclude.Include.ALWAYS)	
	private String mdmpartyIdHidden;	

	public String getMdmpartyIdHidden() {	
		return mdmpartyIdHidden;	
	}	
	public void setMdmpartyIdHidden(String mdmpartyIdHidden) {	
		this.mdmpartyIdHidden = mdmpartyIdHidden;	
	}	
	//MDM Party ID adding in Create Submission Request - End
	
	public String getPageDisplayCount() {
		return pageDisplayCount;
	}
	public void setPageDisplayCount(String pageDisplayCount) {
		this.pageDisplayCount = pageDisplayCount;
	}
	public String getCurrentPageNbr() {
		return currentPageNbr;
	}
	public void setCurrentPageNbr(String currentPageNbr) {
		this.currentPageNbr = currentPageNbr;
	}
	public String getEnableNextPage() {
		return enableNextPage;
	}
	public void setEnableNextPage(String enableNextPage) {
		this.enableNextPage = enableNextPage;
	}
	public String getSourceCd() {
		return sourceCd;
	}
	public void setSourceCd(String sourceCd) {
		this.sourceCd = sourceCd;
	}
	public String getSubmissionNo() {
		return submissionNo;
	}
	public void setSubmissionNo(String submissionNo) {
		this.submissionNo = submissionNo;
	}
	public ValueFooterBO getAccountName() {
		return accountName;
	}
	public void setAccountName(ValueFooterBO accountName) {
		this.accountName = accountName;
	}
	public ValueFooterBO getInitiatingProducerNo() {
		return initiatingProducerNo;
	}
	public void setInitiatingProducerNo(ValueFooterBO initiatingProducerNo) {
		this.initiatingProducerNo = initiatingProducerNo;
	}
	public String getCountryName() {
		return countryName;
	}
	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}
	public String getAccountNumberHidden() {
		return accountNumberHidden;
	}
	public void setAccountNumberHidden(String accountNumberHidden) {
		this.accountNumberHidden = accountNumberHidden;
	}
	public String getMdmPartyIdHidden() {
		return mdmPartyIdHidden;
	}
	public void setMdmPartyIdHidden(String mdmPartyIdHidden) {
		this.mdmPartyIdHidden = mdmPartyIdHidden;
	}
	/**
	 * @return the producerCountryCd
	 */
	public String getProducerCountryCd() {
		return producerCountryCd;
	}
	/**
	 * @param producerCountryCd the producerCountryCd to set
	 */
	public void setProducerCountryCd(String producerCountryCd) {
		this.producerCountryCd = producerCountryCd;
	}
	/**
	 * @return the producerBranchId
	 */
	public String getProducerBranchId() {
		return producerBranchId;
	}
	/**
	 * @param producerBranchId the producerBranchId to set
	 */
	public void setProducerBranchId(String producerBranchId) {
		this.producerBranchId = producerBranchId;
	}
}
