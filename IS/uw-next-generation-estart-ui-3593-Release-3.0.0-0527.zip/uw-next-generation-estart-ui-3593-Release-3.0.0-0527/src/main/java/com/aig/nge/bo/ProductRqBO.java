package com.aig.nge.bo;


public class ProductRqBO {
    /**
	 * @return the marketableProductRq
	 */
	public MarketableProductRqBO getMarketableProductRq() {
		return marketableProductRq;
	}
	/**
	 * @param marketableProductRq the marketableProductRq to set
	 */
	public void setMarketableProductRq(MarketableProductRqBO marketableProductRq) {
		this.marketableProductRq = marketableProductRq;
	}
	/**
	 * @return the componentProductRq
	 */
	public ComponentProductRqBO getComponentProductRq() {
		return componentProductRq;
	}
	/**
	 * @param componentProductRq the componentProductRq to set
	 */
	public void setComponentProductRq(ComponentProductRqBO componentProductRq) {
		this.componentProductRq = componentProductRq;
	}
	private MarketableProductRqBO marketableProductRq;
    private ComponentProductRqBO componentProductRq;
}
