package com.aig.nge.bo;

import java.util.List;

public class CASLuserroleBO {
	private String roleName;
	private List<CASLUserdataBO> userDataCategory;
	public String getRoleName() {
		return roleName;
	}
	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}
	public List<CASLUserdataBO> getUserDataCategory() {
		return userDataCategory;
	}
	public void setUserDataCategory(List<CASLUserdataBO> userDataCategory) {
		this.userDataCategory = userDataCategory;
	}
	

}
