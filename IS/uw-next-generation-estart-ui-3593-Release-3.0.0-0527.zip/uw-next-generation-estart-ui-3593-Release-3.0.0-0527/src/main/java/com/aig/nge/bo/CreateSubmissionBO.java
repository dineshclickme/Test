package com.aig.nge.bo;

public class CreateSubmissionBO {

	public SubmissionBO getSubmission() {
		return Submission;
	}

	public void setSubmission(SubmissionBO submission) {
		Submission = submission;
	}

	private SubmissionBO Submission;
	

}
