package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the TERROR_LANGUAGE database table.
 * 
 */
@Entity
@Table(name="TERROR_LANGUAGE")
public class TerrorLanguage implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private TerrorLanguagePK id;

	@Column(name="CREATE_TS")
	private Timestamp createTs;

	@Column(name="CREATE_USER_ID")
	private String createUserId;

	@Column(name="ERROR_MESAGE_TX")
	private String errorMesageTx;

	@Column(name="UPDATE_TS")
	private Timestamp updateTs;

	@Column(name="UPDATE_USER_ID")
	private String updateUserId;

	//bi-directional many-to-one association to Terror
	@ManyToOne
	@JoinColumn(name="ERROR_ID")
	private Terror terror;

	//bi-directional many-to-one association to Tlanguage
	@ManyToOne
	@JoinColumn(name="LANGUAGE_ID")
	private Tlanguage tlanguage;

    public TerrorLanguage() {
    }

	public TerrorLanguagePK getId() {
		return this.id;
	}

	public void setId(TerrorLanguagePK id) {
		this.id = id;
	}
	
	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public String getErrorMesageTx() {
		return this.errorMesageTx;
	}

	public void setErrorMesageTx(String errorMesageTx) {
		this.errorMesageTx = errorMesageTx;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public Terror getTerror() {
		return this.terror;
	}

	public void setTerror(Terror terror) {
		this.terror = terror;
	}
	
	public Tlanguage getTlanguage() {
		return this.tlanguage;
	}

	public void setTlanguage(Tlanguage tlanguage) {
		this.tlanguage = tlanguage;
	}
	
}