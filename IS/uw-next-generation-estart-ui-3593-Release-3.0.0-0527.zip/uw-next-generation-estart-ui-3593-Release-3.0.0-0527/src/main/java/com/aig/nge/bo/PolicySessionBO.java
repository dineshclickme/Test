package com.aig.nge.bo;

import java.util.List;

public class PolicySessionBO {

	
	public List<PolicyDetailBO> policyDetailBO;

	public List<PolicyDetailBO> getPolicyDetailBO() {
		return policyDetailBO;
	}

	public void setPolicyDetailBO(List<PolicyDetailBO> policyDetailBO) {
		this.policyDetailBO = policyDetailBO;
	}

}
