package com.aig.nge.bo;

import java.util.List;

public class UpdateTransDetailsBO {
    private String marketSegmentCd;
    private String underwriterId;
    private BranchBO creditedBranch;
    private String producerCd;
    private String agentId;
    private BrokerBO broker;
    private String brokerAction;
    private AddressDetailsBO mailingAddress;
    private String mailingAddressAction;
    private List<TransactionVersionBO> transactionVersionRq;
    private String creditedBranchStr;
    private String creditedBranchHiddenStr;
    
    
    /**
	 * @return the marketSegmentCd
	 */
	public String getMarketSegmentCd() {
		return marketSegmentCd;
	}
	/**
	 * @param marketSegmentCd the marketSegmentCd to set
	 */
	public void setMarketSegmentCd(String marketSegmentCd) {
		this.marketSegmentCd = marketSegmentCd;
	}
	/**
	 * @return the underwriterId
	 */
	public String getUnderwriterId() {
		return underwriterId;
	}
	/**
	 * @param underwriterId the underwriterId to set
	 */
	public void setUnderwriterId(String underwriterId) {
		this.underwriterId = underwriterId;
	}
	/**
	 * @return the creditedBranch
	 */
	public BranchBO getCreditedBranch() {
		return creditedBranch;
	}
	/**
	 * @param creditedBranch the creditedBranch to set
	 */
	public void setCreditedBranch(BranchBO creditedBranch) {
		this.creditedBranch = creditedBranch;
	}
	/**
	 * @return the producerCd
	 */
	public String getProducerCd() {
		return producerCd;
	}
	/**
	 * @param producerCd the producerCd to set
	 */
	public void setProducerCd(String producerCd) {
		this.producerCd = producerCd;
	}
	/**
	 * @return the agentId
	 */
	public String getAgentId() {
		return agentId;
	}
	/**
	 * @param agentId the agentId to set
	 */
	public void setAgentId(String agentId) {
		this.agentId = agentId;
	}
	/**
	 * @return the broker
	 */
	public BrokerBO getBroker() {
		return broker;
	}
	/**
	 * @param broker the broker to set
	 */
	public void setBroker(BrokerBO broker) {
		this.broker = broker;
	}
	/**
	 * @return the mailingAddress
	 */
	public AddressDetailsBO getMailingAddress() {
		return mailingAddress;
	}
	/**
	 * @param mailingAddress the mailingAddress to set
	 */
	public void setMailingAddress(AddressDetailsBO mailingAddress) {
		this.mailingAddress = mailingAddress;
	}
	/**
	 * @return the transactionVersionRq
	 */
	public List<TransactionVersionBO> getTransactionVersionRq() {
		return transactionVersionRq;
	}
	/**
	 * @param transactionVersionRq the transactionVersionRq to set
	 */
	public void setTransactionVersionRq(
			List<TransactionVersionBO> transactionVersionRq) {
		this.transactionVersionRq = transactionVersionRq;
	}
	
	public String getCreditedBranchHiddenStr() {
		return creditedBranchHiddenStr;
	}
	public void setCreditedBranchHiddenStr(String creditedBranchHiddenStr) {
		this.creditedBranchHiddenStr = creditedBranchHiddenStr;
	}
	/**
	 * @return the creditedBranchStr
	 */
	public String getCreditedBranchStr() {
		return creditedBranchStr;
	}
	/**
	 * @param creditedBranchStr the creditedBranchStr to set
	 */
	public void setCreditedBranchStr(String creditedBranchStr) {
		this.creditedBranchStr = creditedBranchStr;
	}
	public String getBrokerAction() {
		return brokerAction;
	}
	public void setBrokerAction(String brokerAction) {
		this.brokerAction = brokerAction;
	}
	public String getMailingAddressAction() {
		return mailingAddressAction;
	}
	public void setMailingAddressAction(String mailingAddressAction) {
		this.mailingAddressAction = mailingAddressAction;
	}
}
