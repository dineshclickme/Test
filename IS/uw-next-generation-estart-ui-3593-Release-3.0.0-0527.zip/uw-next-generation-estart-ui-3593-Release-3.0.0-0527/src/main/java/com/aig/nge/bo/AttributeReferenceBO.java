package com.aig.nge.bo;

public class AttributeReferenceBO {
	
	private String label;
	private String name;
	private String type;
	private String defaultValue;
	private AdditionalAttributeReferenceDataBO dataPopulation;
	private boolean required;
	private boolean optional;
	private String initialState;
	public String getLabel() {
		return label;
	}
	public void setLabel(String label) {
		this.label = label;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getDefaultValue() {
		return defaultValue;
	}
	public void setDefaultValue(String defaultValue) {
		this.defaultValue = defaultValue;
	}
	public AdditionalAttributeReferenceDataBO getDataPopulation() {
		return dataPopulation;
	}
	public void setDataPopulation(AdditionalAttributeReferenceDataBO dataPopulation) {
		this.dataPopulation = dataPopulation;
	}
	public boolean getRequired() {
		return required;
	}
	public void setRequired(boolean required) {
		this.required = required;
	}
	public boolean getOptional() {
		return optional;
	}
	public void setOptional(boolean optional) {
		this.optional = optional;
	}
	public String getInitialState() {
		return initialState;
	}
	public void setInitialState(String initialState) {
		this.initialState = initialState;
	}
	@Override
	public String toString() {
		return "AttributeReferenceBO [label=" + label + ", name=" + name
				+ ", type=" + type + ", dataPopulation=" + dataPopulation
				+ ", required=" + required + ", optional=" + optional
				+ ", initialState=" + initialState + "]";
	}

}
