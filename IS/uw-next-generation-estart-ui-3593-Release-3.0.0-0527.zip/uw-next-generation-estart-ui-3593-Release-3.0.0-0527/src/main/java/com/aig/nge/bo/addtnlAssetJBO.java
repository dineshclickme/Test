package com.aig.nge.bo;

public class addtnlAssetJBO {

	private String make;
	private String model;
	private String tailnumber;
	/**
	 * @return the make
	 */
	public String getMake() {
		return make;
	}
	/**
	 * @param make the make to set
	 */
	public void setMake(String make) {
		this.make = make;
	}
	/**
	 * @return the model
	 */
	public String getModel() {
		return model;
	}
	/**
	 * @param model the model to set
	 */
	public void setModel(String model) {
		this.model = model;
	}
	/**
	 * @return the tailnumber
	 */
	public String getTailnumber() {
		return tailnumber;
	}
	/**
	 * @param tailnumber the tailnumber to set
	 */
	public void setTailnumber(String tailnumber) {
		this.tailnumber = tailnumber;
	}
}
