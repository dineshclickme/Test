package com.aig.nge.bo;

public class AlertBlockDetailsBO {

	private String blockNo;
    private String reasonCd;
    private String reasonDesc;
    private String reasonLongDesc;
    private String seDetail;
    private AlternateContactDetailsBO releaserContactDetails;
    private String alternateContact;
    
    
	/**
	 * @return the blockNo
	 */
	public String getBlockNo() {
		return blockNo;
	}
	/**
	 * @param blockNo the blockNo to set
	 */
	public void setBlockNo(String blockNo) {
		this.blockNo = blockNo;
	}
	/**
	 * @return the reasonCd
	 */
	public String getReasonCd() {
		return reasonCd;
	}
	/**
	 * @param reasonCd the reasonCd to set
	 */
	public void setReasonCd(String reasonCd) {
		this.reasonCd = reasonCd;
	}
	/**
	 * @return the reasonDesc
	 */
	public String getReasonDesc() {
		return reasonDesc;
	}
	/**
	 * @param reasonDesc the reasonDesc to set
	 */
	public void setReasonDesc(String reasonDesc) {
		this.reasonDesc = reasonDesc;
	}
	/**
	 * @return the reasonLongDesc
	 */
	public String getReasonLongDesc() {
		return reasonLongDesc;
	}
	/**
	 * @param reasonLongDesc the reasonLongDesc to set
	 */
	public void setReasonLongDesc(String reasonLongDesc) {
		this.reasonLongDesc = reasonLongDesc;
	}
	/**
	 * @return the seDetail
	 */
	public String getSeDetail() {
		return seDetail;
	}
	/**
	 * @param seDetail the seDetail to set
	 */
	public void setSeDetail(String seDetail) {
		this.seDetail = seDetail;
	}
	/**
	 * @return the releaserContactDetails
	 */
	public AlternateContactDetailsBO getReleaserContactDetails() {
		return releaserContactDetails;
	}
	public void setReleaserContactDetails(
			AlternateContactDetailsBO releaserContactDetails) {
		this.releaserContactDetails = releaserContactDetails;
	}
	public String getAlternateContact() {
		return alternateContact;
	}
	public void setAlternateContact(String alternateContact) {
		this.alternateContact = alternateContact;
	}
    
    
}
