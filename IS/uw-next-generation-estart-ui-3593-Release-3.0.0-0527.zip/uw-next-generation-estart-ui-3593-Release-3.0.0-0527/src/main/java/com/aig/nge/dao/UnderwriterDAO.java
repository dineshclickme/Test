package com.aig.nge.dao;

import java.io.File;
import java.io.FileInputStream;
import java.net.URL;
import java.sql.Timestamp;
import java.util.*;

import com.aig.nge.utilities.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Repository;

import com.aig.nge.entities.TbrickMetadata;
import com.aig.nge.entities.Tlocation;
import com.aig.nge.repository.TLocationByBranchRepository;
import com.aig.nge.repository.TPartyRepository;
import com.aig.nge.repository.TbrickMetadataRepository;
//import com.ibm.json.java.JSONObject
import org.json.simple.JSONObject;
import javax.xml.parsers.DocumentBuilderFactory;

import static org.json.simple.JSONObject.*;

@Repository
public class UnderwriterDAO extends BaseDAO {
	
	@Autowired
	private TPartyRepository tPartyRepository;
	
	@Autowired
	private TLocationByBranchRepository tLocationRepository;
	
	@Autowired
	private TbrickMetadataRepository tbrickMetadataRepository;

	public Tlocation getLocationCode(String locationName) {
		
		Tlocation tlocation = tLocationRepository.getLocationId(locationName);
		
		return tlocation;
	}

	
	public Set<Object[]> searchUWByLastNameAndFirstName(String lastName, String firstName) {
		String lastNameUpper = lastName.toUpperCase();
		String firstNameUpper = firstName.toUpperCase();
		Set<Object[]> partyList = tPartyRepository.findUWByLastNameAndFirstName(NGEConstants.UNDERWRITER.toUpperCase(),lastNameUpper,firstNameUpper);
		return partyList;
	}
	
	public List<Object[]> findUWByFilterCondition(String countryCode,String lastName,String firstName,String stateCode,String partyNo,String status) throws AIGCIExceptionMsg {
		NGEProperties ngeProperties = new NGEProperties();
		String count = ngeProperties.readMessageFromFile(NGEConstants.UNDERWRITER_SEARCH_MAX_COUNT,NGEConstants.MESSAGE_FILE_NAME,true);
		
		//Pageable noOfRecords = new PageRequest(0, Integer.parseInt(count));
		/*List<Object[]> partyList = tPartyRepository.findUWByFilterCondition(NGEConstants.UNDERWRITER.toUpperCase(),countryCode,lastName,lastName, firstName,firstName,
				stateCode,partyNo,status,noOfRecords);*/
		String lastNameLike = "%"+lastName+"%";
		String firstNameLike = "%"+firstName+"%";
		List<Object[]> partyList = tPartyRepository.findUWByFilterCondition(NGEConstants.UNDERWRITER.toUpperCase(),countryCode,lastName,lastNameLike, firstName,firstNameLike,
				stateCode,partyNo,status,Long.valueOf(count));
		return partyList;
	}
	public Set<Object[]> searchUWByLastNameAndCountry(String lastName,String locationCode) {
		
		String lastNameUpper = lastName.toUpperCase();
		Set<Object[]> partyList = tPartyRepository.findUWByLastNameAndCountry(NGEConstants.UNDERWRITER.toUpperCase(),lastNameUpper,locationCode);
		return partyList;
	}

	public Set<Object[]> searchUWByLastNameFirstNameAndCountry(String lastName,String firstName, String locationCode) {
		String lastNameUpper = lastName.toUpperCase();
		String firstNameUpper = firstName.toUpperCase();
		Set<Object[]> partyList = tPartyRepository.findUWByLastNameFirstNameAndCountry(NGEConstants.UNDERWRITER.toUpperCase(),lastNameUpper,firstNameUpper,locationCode);
		return partyList;
	}

	public Set<Object[]> searchUWByLastNameCountryAndState(String lastName,String locationCode, String stateCode) {
		String lastNameUpper = lastName.toUpperCase();
		Set<Object[]> partyList = tPartyRepository.findUWByLastNameCountryAndState(NGEConstants.UNDERWRITER.toUpperCase(),lastNameUpper,locationCode,stateCode);
		return partyList;
	}

	public Set<Object[]> searchUWByLastNameFirstNameCountryAndState(String lastName, String firstName, String locationCode,String stateCode) {
		String lastNameUpper = lastName.toUpperCase();
		String firstNameUpper = firstName.toUpperCase();
		Set<Object[]> partyList = tPartyRepository.findUWByLastNameFirstNameCountryAndState(NGEConstants.UNDERWRITER.toUpperCase(),lastNameUpper,firstNameUpper,locationCode,stateCode);
		return partyList;
	}
	
	public Set<Object[]> findUWById(String partyNo) {
		Set<Object[]> partyList = tPartyRepository.findUWById(NGEConstants.UNDERWRITER.toUpperCase(),partyNo);
		return partyList;
	}

	
	public void insertBrickMetaData(){
		try {
			URL resource = Thread.currentThread().getContextClassLoader().getResource(
					"/resources/json/ngeobject.json");
			FileInputStream fis=new FileInputStream(new File(resource.toURI()));
			JSONObject obj = parse(fis);

			Iterator it= obj.keySet().iterator();
			int i=0;
			while(it.hasNext())
			{
				
				Object ob=it.next();
				TbrickMetadata brickMetaData=new TbrickMetadata();
				brickMetaData.setBrickMetadataId(i++);
				brickMetaData.setBrickMetadataKeyCd(String.valueOf(ob));
				brickMetaData.setBrickMetadataOb(String.valueOf(obj.get(ob)));
				brickMetaData.setCreateTs(new Timestamp(new Date().getTime()));
				brickMetaData.setCreateUserId("NGE");
				
				tbrickMetadataRepository.save(brickMetaData);
			}
		} catch (Exception e) {
			//String err="General Exception Occured";
			e.printStackTrace();
		} 
	}

	private JSONObject parse(FileInputStream fis) {
		return null;
	}

	public Set<Object[]> getUnderwriterByID(String id) {
		Set<Object[]> party = tPartyRepository.findUserByPartyNo(NGEConstants.UNDERWRITER.toUpperCase(),id);
		return party;	
	}
}
