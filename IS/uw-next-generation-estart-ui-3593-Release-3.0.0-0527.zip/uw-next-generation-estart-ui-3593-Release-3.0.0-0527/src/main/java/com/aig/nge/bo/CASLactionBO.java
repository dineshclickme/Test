package com.aig.nge.bo;

public class CASLactionBO {
	public String getActionName() {
		return actionName;
	}

	public void setActionName(String actionName) {
		this.actionName = actionName;
	}

	private  String actionName;
}
