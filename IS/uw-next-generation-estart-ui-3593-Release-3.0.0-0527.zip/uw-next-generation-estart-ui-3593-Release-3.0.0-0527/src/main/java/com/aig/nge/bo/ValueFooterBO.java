package com.aig.nge.bo;

public class ValueFooterBO {

	private String value;
	private String footer;
	/* 2021 MDM Changes - Starts */
	private String footerAdtn;
	/* 2021 MDM Changes - Ends */
	/**
	 * @return the value
	 */
	public String getValue() {
		return value;
	}
	/**
	 * @param value the value to set
	 */
	public void setValue(String value) {
		this.value = value;
	}
	/**
	 * @return the footer
	 */
	public String getFooter() {
		return footer;
	}
	/**
	 * @param footer the footer to set
	 */
	public void setFooter(String footer) {
		this.footer = footer;
	}
	//MDM Changes to include party id in footer - Starts
	public String getFooterAdtn() {
		return footerAdtn;
	}
	public void setFooterAdtn(String footerAdtn) {
		this.footerAdtn = footerAdtn;
	}
	//MDM Changes to include party id in footer - Ends
}
