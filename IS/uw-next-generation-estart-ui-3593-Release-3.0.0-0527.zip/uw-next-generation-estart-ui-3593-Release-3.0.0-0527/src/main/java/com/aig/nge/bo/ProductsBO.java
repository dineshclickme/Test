package com.aig.nge.bo;

import java.util.List;


public class ProductsBO {
	private String productTabKey;
	private List<MarketableProductDetailsBO> marketableProduct;
	private List<ComponentProductBO> componentProduct;
	
	public List<MarketableProductDetailsBO> getMarketableProduct() {
		return marketableProduct;
	}
	public void setMarketableProduct(
			List<MarketableProductDetailsBO> marketableProduct) {
		this.marketableProduct = marketableProduct;
	}
	public List<ComponentProductBO> getComponentProduct() {
		return componentProduct;
	}
	public void setComponentProduct(List<ComponentProductBO> componentProduct) {
		this.componentProduct = componentProduct;
	}
	public String getProductTabKey() {
		return productTabKey;
	}
	public void setProductTabKey(String productTabKey) {
		this.productTabKey = productTabKey;
	}
	
	

}
