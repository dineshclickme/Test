package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Set;


/**
 * The persistent class for the TFIELD database table.
 * 
 */
@Entity
public class Tfield implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="FIELD_ID")
	private short fieldId;

	@Column(name="CREATE_TS")
	private Timestamp createTs;

	@Column(name="CREATE_USER_ID")
	private String createUserId;

	@Column(name="FIELD_DS")
	private String fieldDs;

	@Column(name="FIELD_NM")
	private String fieldNm;

	@Column(name="UPDATE_TS")
	private Timestamp updateTs;

	@Column(name="UPDATE_USER_ID")
	private String updateUserId;

	//bi-directional many-to-one association to TscreenField
	@OneToMany(mappedBy="tfield", cascade={CascadeType.ALL})
	private Set<TscreenField> tscreenFields;

	//bi-directional many-to-one association to TfieldLanguage
	@OneToMany(mappedBy="tfield", cascade={CascadeType.ALL})
	private Set<TfieldLanguage> tfieldLanguages;

    public Tfield() {
    }

	public short getFieldId() {
		return this.fieldId;
	}

	public void setFieldId(short fieldId) {
		this.fieldId = fieldId;
	}

	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public String getFieldDs() {
		return this.fieldDs;
	}

	public void setFieldDs(String fieldDs) {
		this.fieldDs = fieldDs;
	}

	public String getFieldNm() {
		return this.fieldNm;
	}

	public void setFieldNm(String fieldNm) {
		this.fieldNm = fieldNm;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public Set<TscreenField> getTscreenFields() {
		return this.tscreenFields;
	}

	public void setTscreenFields(Set<TscreenField> tscreenFields) {
		this.tscreenFields = tscreenFields;
	}
	
	public Set<TfieldLanguage> getTfieldLanguages() {
		return this.tfieldLanguages;
	}

	public void setTfieldLanguages(Set<TfieldLanguage> tfieldLanguages) {
		this.tfieldLanguages = tfieldLanguages;
	}
	
}