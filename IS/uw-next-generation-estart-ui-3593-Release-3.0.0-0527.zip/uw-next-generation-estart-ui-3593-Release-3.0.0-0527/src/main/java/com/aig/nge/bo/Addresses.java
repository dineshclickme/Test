package com.aig.nge.bo;

import java.util.List;

import com.aig.nge.utilities.NGECommonUtil;
import com.fasterxml.jackson.annotation.JsonProperty;

public class Addresses {
	
	@JsonProperty("MailingAddress")
	private String mailingAddress="";
	@JsonProperty("StreetAddress")
	private String streetAddress="";
	@JsonProperty("AddressLine1")
	private String AddressLine1="";
	@JsonProperty("CountryCode_DNB")
	private String countryCode_DNB="";
	@JsonProperty("StateCode")
	private String stateCode="";
	@JsonProperty("CountryCode")
	private String countryCode="";
	@JsonProperty("CountyCode")
	private String countyCode="";
	@JsonProperty("PostalCode")
	private String postalCode="";
	@JsonProperty("CityName")
	private String cityName="";
	@JsonProperty("CountryName")
	private String countryName="";
	@JsonProperty("CountryName_DNB")
	private String countryName_DNB="";
	
	public String getMailingAddress() {
		return mailingAddress;
	}
	public void setMailingAddress(String mailingAddress) {
		mailingAddress=NGECommonUtil.setDefaultStringValue(mailingAddress);
		this.mailingAddress = mailingAddress;
	}
	public String getStreetAddress() {
		return streetAddress;
	}
	public void setStreetAddress(String streetAddress) {
		streetAddress=NGECommonUtil.setDefaultStringValue(streetAddress);
		this.streetAddress = streetAddress;
	}
	public String getAddressLine1() {
		return AddressLine1;
	}
	public void setAddressLine1(String addressLine1) {
		AddressLine1 = addressLine1;
	}
	public String getCountryCode_DNB() {
		return countryCode_DNB;
	}
	public void setCountryCode_DNB(String countryCode_DNB) {
		countryCode_DNB=NGECommonUtil.setDefaultStringValue(countryCode_DNB);
		this.countryCode_DNB = countryCode_DNB;
	}
	public String getStateCode() {
		return stateCode;
	}
	public void setStateCode(String stateCode) {
		stateCode=NGECommonUtil.setDefaultStringValue(stateCode);
		this.stateCode = stateCode;
	}
	public String getCountyCode() {
		return countyCode;
	}
	public void setCountyCode(String countyCode) {
		countyCode=NGECommonUtil.setDefaultStringValue(countyCode);
		this.countyCode = countyCode;
	}
	public String getPostalCode() {
		return postalCode;
	}
	public void setPostalCode(String postalCode) {
		postalCode=NGECommonUtil.setDefaultStringValue(postalCode);
		this.postalCode = postalCode;
	}
	public String getCityName() {
		return cityName;
	}
	public void setCityName(String cityName) {
		cityName=NGECommonUtil.setDefaultStringValue(cityName);
		this.cityName = cityName;
	}
	public String getCountryName() {
		return countryName;
	}
	public void setCountryName(String countryName) {
		countryName=NGECommonUtil.setDefaultStringValue(countryName);
		this.countryName = countryName;
	}
	public String getCountryCode() {
		return countryCode;
	}
	public void setCountryCode(String countryCode) {
		countryCode=NGECommonUtil.setDefaultStringValue(countryCode);
		this.countryCode = countryCode;
	}
	public String getCountryName_DNB() {
		return countryName_DNB;
	}
	public void setCountryName_DNB(String countryName_DNB) {
		countryName_DNB=NGECommonUtil.setDefaultStringValue(countryName_DNB);
		this.countryName_DNB = countryName_DNB;
	}
	
}
