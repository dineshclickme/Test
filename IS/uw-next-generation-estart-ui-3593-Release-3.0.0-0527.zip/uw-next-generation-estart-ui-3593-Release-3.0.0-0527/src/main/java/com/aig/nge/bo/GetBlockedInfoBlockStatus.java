package com.aig.nge.bo;

import java.util.List;

public class GetBlockedInfoBlockStatus {
	
	private GetBlockedInfoRows blocked;
	private GetBlockedInfoRows released;
	private List<AlertBlockDetailsBO> blockingAlertList;
   	private List<AlertBlockDetailsBO> releasedAlertList;
   	private String advancedBlockSearchMaxResult;
	public String getAdvancedBlockSearchMaxResult() {
		return advancedBlockSearchMaxResult;
	}
	public void setAdvancedBlockSearchMaxResult(String advancedBlockSearchMaxResult) {
		this.advancedBlockSearchMaxResult = advancedBlockSearchMaxResult;
	}
	public GetBlockedInfoRows getBlocked() {
		return blocked;
	}
	public void setBlocked(GetBlockedInfoRows blocked) {
		this.blocked = blocked;
	}
	public GetBlockedInfoRows getReleased() {
		return released;
	}
	public void setReleased(GetBlockedInfoRows released) {
		this.released = released;
	}
	public List<AlertBlockDetailsBO> getBlockingAlertList() {
		return blockingAlertList;
	}
	public void setBlockingAlertList(List<AlertBlockDetailsBO> blockingAlertList) {
		this.blockingAlertList = blockingAlertList;
	}
	public List<AlertBlockDetailsBO> getReleasedAlertList() {
		return releasedAlertList;
	}
	public void setReleasedAlertList(List<AlertBlockDetailsBO> releasedAlertList) {
		this.releasedAlertList = releasedAlertList;
	}

}
