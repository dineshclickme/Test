package com.aig.nge.bo;

import java.util.List;

public class AdditionalInsuredSessionBO {
	
	private List<AdditionalInsuredBO> rows;

	public List<AdditionalInsuredBO> getRows() {
		return rows;
	}

	public void setRows(List<AdditionalInsuredBO> rows) {
		this.rows = rows;
	}

}
