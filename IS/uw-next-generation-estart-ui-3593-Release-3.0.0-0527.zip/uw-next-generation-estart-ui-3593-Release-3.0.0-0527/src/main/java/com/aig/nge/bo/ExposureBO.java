package com.aig.nge.bo;

public class ExposureBO {
	
	private String locationTypeCd;
	private String locationTypeName;
	private String locationCd;
	private String locationName;
	private String action;
	
	public String getLocationTypeCd() {
		return locationTypeCd;
	}
	public void setLocationTypeCd(String locationTypeCd) {
		this.locationTypeCd = locationTypeCd;
	}
	public String getLocationTypeName() {
		return locationTypeName;
	}
	public void setLocationTypeName(String locationTypeName) {
		this.locationTypeName = locationTypeName;
	}
	public String getLocationCd() {
		return locationCd;
	}
	public void setLocationCd(String locationCd) {
		this.locationCd = locationCd;
	}
	public String getLocationName() {
		return locationName;
	}
	public void setLocationName(String locationName) {
		this.locationName = locationName;
	}
	/**
	 * @return the action
	 */
	public String getAction() {
		return action;
	}
	/**
	 * @param action the action to set
	 */
	public void setAction(String action) {
		this.action = action;
	}

	
	
}
