package com.aig.nge.bo;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;


public class BindTransactionRequestBO {
	
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String transactionId;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String transactionVersionNo;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private List<BindProductsRqBO> bindProducts;
	
	
    /**
	 * @return the transactionId
	 */
	public String getTransactionId() {
		return transactionId;
	}
	/**
	 * @param transactionId the transactionId to set
	 */
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	/**
	 * @return the transactionVersionNo
	 */
	public String getTransactionVersionNo() {
		return transactionVersionNo;
	}
	/**
	 * @param transactionVersionNo the transactionVersionNo to set
	 */
	public void setTransactionVersionNo(String transactionVersionNo) {
		this.transactionVersionNo = transactionVersionNo;
	}
	/**
	 * @return the bindProducts
	 */
	public List<BindProductsRqBO> getBindProducts() {
		return bindProducts;
	}
	/**
	 * @param bindProducts the bindProducts to set
	 */
	public void setBindProducts(List<BindProductsRqBO> bindProducts) {
		this.bindProducts = bindProducts;
	}
}
