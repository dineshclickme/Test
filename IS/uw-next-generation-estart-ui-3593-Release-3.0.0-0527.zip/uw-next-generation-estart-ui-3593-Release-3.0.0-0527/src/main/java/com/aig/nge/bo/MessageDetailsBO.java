/**
 * 
 */
package com.aig.nge.bo;

/**
 * @author bennym
 *
 */
public class MessageDetailsBO {

	private String segmentCode;
	private String subSegmentCode;
	
	private String attachmentPoint;
	private String productName;
	private String messsage;
	private String errorCode;
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	/**
	 * @return the segmentCode
	 */
	public String getSegmentCode() {
		return segmentCode;
	}
	/**
	 * @param segmentCode the segmentCode to set
	 */
	public void setSegmentCode(String segmentCode) {
		this.segmentCode = segmentCode;
	}
	/**
	 * @return the subSegmentCode
	 */
	public String getSubSegmentCode() {
		return subSegmentCode;
	}
	/**
	 * @param subSegmentCode the subSegmentCode to set
	 */
	public void setSubSegmentCode(String subSegmentCode) {
		this.subSegmentCode = subSegmentCode;
	}
	/**
	 * @return the attachmentPoint
	 */
	public String getAttachmentPoint() {
		return attachmentPoint;
	}
	/**
	 * @param attachmentPoint the attachmentPoint to set
	 */
	public void setAttachmentPoint(String attachmentPoint) {
		this.attachmentPoint = attachmentPoint;
	}
	/**
	 * @return the messsage
	 */
	public String getMesssage() {
		return messsage;
	}
	/**
	 * @param messsage the messsage to set
	 */
	public void setMesssage(String messsage) {
		this.messsage = messsage;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	
}
