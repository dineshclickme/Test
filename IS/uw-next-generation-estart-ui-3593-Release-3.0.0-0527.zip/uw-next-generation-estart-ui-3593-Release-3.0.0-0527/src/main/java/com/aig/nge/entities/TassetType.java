package com.aig.nge.entities;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;


/**
 * The persistent class for the TASSET_TYPE database table.
 * 
 */
@Entity
@Table(name="TASSET_TYPE")
public class TassetType implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="ASSET_TYPE_ID")
	private int assetTypeId;

	@Column(name="ASSET_TYPE_NM")
	private String assetTypeNm;

	@Column(name="CREATE_TS")
	private Timestamp createTs;

	@Column(name="CREATE_USER_ID")
	private String createUserId;

	@Column(name="UPDATE_TS")
	private Timestamp updateTs;

	@Column(name="UPDATE_USER_ID")
	private String updateUserId;

	//bi-directional many-to-one association to Tasset
	@OneToMany(mappedBy="tassetType", cascade={CascadeType.ALL})
	private Set<Tasset> tassets;

	//bi-directional many-to-one association to TassetTypeAttribute
	@OneToMany(mappedBy="tassetType")
	private Set<TassetTypeAttribute> tassetTypeAttributes;

	//bi-directional many-to-one association to TprdctTwrTuwSbprdctAstTyp
	@OneToMany(mappedBy="tassetType")
	private Set<TprdctTwrTuwSbprdctAstTyp> tprdctTwrTuwSbprdctAstTyps;

    public TassetType() {
    }

	public int getAssetTypeId() {
		return this.assetTypeId;
	}

	public void setAssetTypeId(int assetTypeId) {
		this.assetTypeId = assetTypeId;
	}

	public String getAssetTypeNm() {
		return this.assetTypeNm;
	}

	public void setAssetTypeNm(String assetTypeNm) {
		this.assetTypeNm = assetTypeNm;
	}

	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public Set<Tasset> getTassets() {
		return this.tassets;
	}

	public void setTassets(Set<Tasset> tassets) {
		this.tassets = tassets;
	}
	
	public Set<TassetTypeAttribute> getTassetTypeAttributes() {
		return this.tassetTypeAttributes;
	}

	public void setTassetTypeAttributes(Set<TassetTypeAttribute> tassetTypeAttributes) {
		this.tassetTypeAttributes = tassetTypeAttributes;
	}
	
	public Set<TprdctTwrTuwSbprdctAstTyp> getTprdctTwrTuwSbprdctAstTyps() {
		return this.tprdctTwrTuwSbprdctAstTyps;
	}

	public void setTprdctTwrTuwSbprdctAstTyps(Set<TprdctTwrTuwSbprdctAstTyp> tprdctTwrTuwSbprdctAstTyps) {
		this.tprdctTwrTuwSbprdctAstTyps = tprdctTwrTuwSbprdctAstTyps;
	}
	
}