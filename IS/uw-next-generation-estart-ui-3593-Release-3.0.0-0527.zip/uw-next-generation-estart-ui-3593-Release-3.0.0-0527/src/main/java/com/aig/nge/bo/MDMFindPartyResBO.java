package com.aig.nge.bo;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class MDMFindPartyResBO {
	
	@JsonProperty("Parties")
	private List<Parties>  parties;
	@JsonProperty("TotalPages")
	private String 	totalPages="";
	@JsonProperty("TotalRecordCount")
	private String 	totalRecordCount="";
	

	public List<Parties> getParties() {
		return parties;
	}

	public void setParties(List<Parties> parties) {
		this.parties = parties;
	}

	public String getTotalPages() {
		return totalPages;
	}

	public void setTotalPages(String totalPages) {
		this.totalPages = totalPages;
	}

	public String getTotalRecordCount() {
		return totalRecordCount;
	}

	public void setTotalRecordCount(String totalRecordCount) {
		this.totalRecordCount = totalRecordCount;
	}

	
	
}
