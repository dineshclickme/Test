package com.aig.nge.bo;


public class CreateTransactionVersionResBO {

    private String submissionNo;
    private String transactionId;
    private String transactionVersion;
	/**
	 * @return the submissionNo
	 */
	public String getSubmissionNo() {
		return submissionNo;
	}
	/**
	 * @param submissionNo the submissionNo to set
	 */
	public void setSubmissionNo(String submissionNo) {
		this.submissionNo = submissionNo;
	}
	/**
	 * @return the transactionId
	 */
	public String getTransactionId() {
		return transactionId;
	}
	/**
	 * @param transactionId the transactionId to set
	 */
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	/**
	 * @return the transactionVersion
	 */
	public String getTransactionVersion() {
		return transactionVersion;
	}
	/**
	 * @param transactionVersion the transactionVersion to set
	 */
	public void setTransactionVersion(String transactionVersion) {
		this.transactionVersion = transactionVersion;
	}
    
    
    
}
