package com.aig.nge.bo;

public class AccountMailingAddressJSONBO {
	private String dataKey;
	private String transaction;
	private String version;
	private String productId;
	private String mktProduct;
	private String subProduct;
	private String component;
	private String addressLine1;
	private String addressLine2;
	private String addressLine3;
	private String city;
	private String locationstate;
	private String stateNm;
	private String countryselection;
	private String countryNm;
	private String zipCode;
	private String countyNm;
	private String newAccountMailingAddress;
	
	private String viewAddresLines;
	private String viewCountryState;
	
	public String getDataKey() {
		return dataKey;
	}
	public void setDataKey(String dataKey) {
		this.dataKey = dataKey;
	}
	public String getTransaction() {
		return transaction;
	}
	public void setTransaction(String transaction) {
		this.transaction = transaction;
	}
	public String getVersion() {
		return version;
	}
	public void setVersion(String version) {
		this.version = version;
	}
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getMktProduct() {
		return mktProduct;
	}
	public void setMktProduct(String mktProduct) {
		this.mktProduct = mktProduct;
	}
	public String getSubProduct() {
		return subProduct;
	}
	public void setSubProduct(String subProduct) {
		this.subProduct = subProduct;
	}
	public String getComponent() {
		return component;
	}
	public void setComponent(String component) {
		this.component = component;
	}
	public String getAddressLine1() {
		return addressLine1;
	}
	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}
	public String getAddressLine2() {
		return addressLine2;
	}
	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}
	public String getAddressLine3() {
		return addressLine3;
	}
	public void setAddressLine3(String addressLine3) {
		this.addressLine3 = addressLine3;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getLocationstate() {
		return locationstate;
	}
	public void setLocationstate(String locationstate) {
		this.locationstate = locationstate;
	}
	public String getStateNm() {
		return stateNm;
	}
	public void setStateNm(String stateNm) {
		this.stateNm = stateNm;
	}
	public String getCountryselection() {
		return countryselection;
	}
	public void setCountryselection(String countryselection) {
		this.countryselection = countryselection;
	}
	public String getCountryNm() {
		return countryNm;
	}
	public void setCountryNm(String countryNm) {
		this.countryNm = countryNm;
	}
	public String getZipCode() {
		return zipCode;
	}
	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}
	public String getCountyNm() {
		return countyNm;
	}
	public void setCountyNm(String countyNm) {
		this.countyNm = countyNm;
	}
	public String getNewAccountMailingAddress() {
		return newAccountMailingAddress;
	}
	public void setNewAccountMailingAddress(String newAccountMailingAddress) {
		this.newAccountMailingAddress = newAccountMailingAddress;
	}
	public String getViewAddresLines() {
		return viewAddresLines;
	}
	public void setViewAddresLines(String viewAddresLines) {
		this.viewAddresLines = viewAddresLines;
	}
	public String getViewCountryState() {
		return viewCountryState;
	}
	public void setViewCountryState(String viewCountryState) {
		this.viewCountryState = viewCountryState;
	}
}
