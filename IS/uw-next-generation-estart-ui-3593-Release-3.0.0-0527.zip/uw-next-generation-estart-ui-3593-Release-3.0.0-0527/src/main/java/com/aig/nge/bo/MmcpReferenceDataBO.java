package com.aig.nge.bo;

import java.util.List;
import java.util.Map;

public class MmcpReferenceDataBO {
	
	private String mktProduct;
	private String addComponent;
	private List<Map<String,String>> data;
	
	public String getMktProduct() {
		return mktProduct;
	}
	public void setMktProduct(String mktProduct) {
		this.mktProduct = mktProduct;
	}
	public List<Map<String, String>> getData() {
		return data;
	}
	public void setData(List<Map<String, String>> data) {
		this.data = data;
	}
	public String getAddComponent() {
		return addComponent;
	}
	public void setAddComponent(String addComponent) {
		this.addComponent = addComponent;
	}

}
