package com.aig.nge.bo;


public class AddShellAccountResultsBO {
	    private AddShellAccountBO account;
	    private String count;
		/**
		 * @return the account
		 */
		public AddShellAccountBO getAccount() {
			return account;
		}
		/**
		 * @param account the account to set
		 */
		public void setAccount(AddShellAccountBO account) {
			this.account = account;
		}
		/**
		 * @return the count
		 */
		public String getCount() {
			return count;
		}
		/**
		 * @param count the count to set
		 */
		public void setCount(String count) {
			this.count = count;
		}
}
