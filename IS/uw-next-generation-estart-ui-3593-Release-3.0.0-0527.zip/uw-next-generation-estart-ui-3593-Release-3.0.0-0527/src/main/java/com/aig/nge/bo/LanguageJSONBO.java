package com.aig.nge.bo;

public class LanguageJSONBO {
	private String language;

	public String getLanguage() {
		return language;
	}

	public void setLanguage(String language) {
		this.language = language;
	}

	

}
