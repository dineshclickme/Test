package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SetAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-02-19T16:13:03.036+0530")
@StaticMetamodel(Tbranch.class)
public class Tbranch_ {
	public static volatile SingularAttribute<Tbranch, Integer> branchId;
	public static volatile SingularAttribute<Tbranch, String> branchCd;
	public static volatile SingularAttribute<Tbranch, String> branchNm;
	public static volatile SingularAttribute<Tbranch, Timestamp> createTs;
	public static volatile SingularAttribute<Tbranch, String> createUserId;
	public static volatile SingularAttribute<Tbranch, Timestamp> updateTs;
	public static volatile SingularAttribute<Tbranch, String> updateUserId;
	public static volatile SingularAttribute<Tbranch, Tlocation> tlocation;
	public static volatile SetAttribute<Tbranch, Ttransaction> ttransactions;
	public static volatile SetAttribute<Tbranch, TtransactionComponentBranch> ttransactionComponentBranches;
	public static volatile SingularAttribute<Tbranch, Tstatus> tstatus;
}
