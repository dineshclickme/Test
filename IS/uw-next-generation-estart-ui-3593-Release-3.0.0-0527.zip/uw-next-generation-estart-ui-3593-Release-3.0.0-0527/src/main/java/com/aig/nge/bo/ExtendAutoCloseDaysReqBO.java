package com.aig.nge.bo;

import com.fasterxml.jackson.annotation.JsonInclude;

public class ExtendAutoCloseDaysReqBO {
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private ProductBO product;

	/**
	 * @return the product
	 */
	public ProductBO getProduct() {
		return product;
	}

	/**
	 * @param product the product to set
	 */
	public void setProduct(ProductBO product) {
		this.product = product;
	}
}
