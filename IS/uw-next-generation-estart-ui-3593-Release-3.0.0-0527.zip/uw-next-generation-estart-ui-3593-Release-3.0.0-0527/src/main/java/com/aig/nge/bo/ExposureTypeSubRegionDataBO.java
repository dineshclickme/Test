package com.aig.nge.bo;

import java.util.Comparator;
import java.util.List;

public class ExposureTypeSubRegionDataBO {
	private String id;
	private String text;
	private List<ExposureTypeWorldWideBO> children; 
	
	public static Comparator<ExposureTypeSubRegionDataBO> expoSubRegCompartor = new Comparator<ExposureTypeSubRegionDataBO>() {

		public int compare(ExposureTypeSubRegionDataBO child1, ExposureTypeSubRegionDataBO child2) {
			//ascending order
			return child1.getText().compareTo(child2.getText());
		}

	};
	
	public List<ExposureTypeWorldWideBO> getChildren() {
		return children;
	}
	public void setChildren(List<ExposureTypeWorldWideBO> children) {
		this.children = children;
	}
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}
	
}
