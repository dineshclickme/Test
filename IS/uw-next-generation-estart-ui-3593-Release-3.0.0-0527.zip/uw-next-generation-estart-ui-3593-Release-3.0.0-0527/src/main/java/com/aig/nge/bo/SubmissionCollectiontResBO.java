package com.aig.nge.bo;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class SubmissionCollectiontResBO {
	
	@JsonProperty("noOfRecords")
	private String noOfRecords;
	@JsonProperty("submissionDetails")
    private List<SubmissionDetails> submissionDetails;
	
	public String getNoOfRecords() {
		return noOfRecords;
	}
	public void setNoOfRecords(String noOfRecords) {
		this.noOfRecords = noOfRecords;
	}
	public List<SubmissionDetails> getSubmissionDetails() {
		return submissionDetails;
	}
	public void setSubmissionDetails(List<SubmissionDetails> submissionDetails) {
		this.submissionDetails = submissionDetails;
	}
		
}
