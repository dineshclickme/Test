package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;

import java.sql.Timestamp;
import java.util.Set;


/**
 * The persistent class for the TBRANCH database table.
 * 
 */
@Entity
public class Tbranch implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="BRANCH_ID")
	private int branchId;

	@Column(name="BRANCH_CD")
	private String branchCd;

	@Column(name="BRANCH_NM")
	private String branchNm;

	@Column(name="CREATE_TS")
	private Timestamp createTs;

	@Column(name="CREATE_USER_ID")
	private String createUserId;

	@Column(name="UPDATE_TS")
	private Timestamp updateTs;

	@Column(name="UPDATE_USER_ID")
	private String updateUserId;
	
	@Column(name="DELETED_IN")
	private String deletedIn;

	//bi-directional many-to-one association to Tlocation
	@ManyToOne
	@JoinColumn(name="GEOGRAPHIC_LOCATION_ID")
	private Tlocation tlocation;

	//bi-directional many-to-one association to Tstatus
	@ManyToOne
	@JoinColumn(name="BLOCKING_STATUS_ID")
	private Tstatus tstatus;

	//bi-directional many-to-one association to TlegacySourceMapping
	@OneToMany(mappedBy="tbranch")
	private Set<TlegacySourceMapping> tlegacySourceMappings;
	//bi-directional many-to-one association to Ttransaction
	@OneToMany(mappedBy="tbranch", cascade={CascadeType.ALL})
	private Set<Ttransaction> ttransactions;

	//bi-directional many-to-one association to TtransactionComponentBranch
	@OneToMany(mappedBy="tbranch", cascade={CascadeType.ALL})
	private Set<TtransactionComponentBranch> ttransactionComponentBranches;
	
	//bi-directional many-to-one association to TuserPrefernce
	@OneToMany(mappedBy="tbranch")
	private Set<TuserPrefernce> tuserPrefernces;

    public Tbranch() {
    }

	public int getBranchId() {
		return this.branchId;
	}

	public void setBranchId(int branchId) {
		this.branchId = branchId;
	}

	public String getBranchCd() {
		return this.branchCd;
	}

	public void setBranchCd(String branchCd) {
		this.branchCd = branchCd;
	}

	public String getBranchNm() {
		return this.branchNm;
	}

	public void setBranchNm(String branchNm) {
		this.branchNm = branchNm;
	}

	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public Tlocation getTlocation() {
		return this.tlocation;
	}

	public void setTlocation(Tlocation tlocation) {
		this.tlocation = tlocation;
	}
	
	public Tstatus getTstatus() {
		return this.tstatus;
	}

	public void setTstatus(Tstatus tstatus) {
		this.tstatus = tstatus;
	}
	
	public Set<TlegacySourceMapping> getTlegacySourceMappings() {
		return this.tlegacySourceMappings;
	}

	public void setTlegacySourceMappings(Set<TlegacySourceMapping> tlegacySourceMappings) {
		this.tlegacySourceMappings = tlegacySourceMappings;
	}
	public Set<Ttransaction> getTtransactions() {
		return this.ttransactions;
	}

	public void setTtransactions(Set<Ttransaction> ttransactions) {
		this.ttransactions = ttransactions;
	}
	
	public Set<TtransactionComponentBranch> getTtransactionComponentBranches() {
		return this.ttransactionComponentBranches;
	}

	public void setTtransactionComponentBranches(Set<TtransactionComponentBranch> ttransactionComponentBranches) {
		this.ttransactionComponentBranches = ttransactionComponentBranches;
	}

	public String getDeletedIn() {
		return deletedIn;
	}

	public void setDeletedIn(String deletedIn) {
		this.deletedIn = deletedIn;
	}

	public Set<TuserPrefernce> getTuserPrefernces() {
		return tuserPrefernces;
	}

	public void setTuserPrefernces(Set<TuserPrefernce> tuserPrefernces) {
		this.tuserPrefernces = tuserPrefernces;
	}
	
}