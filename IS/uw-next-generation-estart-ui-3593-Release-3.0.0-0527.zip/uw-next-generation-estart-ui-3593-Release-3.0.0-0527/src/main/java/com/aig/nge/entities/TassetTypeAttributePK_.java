package com.aig.nge.entities;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-04-15T15:31:46.604+0530")
@StaticMetamodel(TassetTypeAttributePK.class)
public class TassetTypeAttributePK_ {
	public static volatile SingularAttribute<TassetTypeAttributePK, Integer> assetTypeId;
	public static volatile SingularAttribute<TassetTypeAttributePK, Short> attributeId;
	public static volatile SingularAttribute<TassetTypeAttributePK, Short> attributeSqn;
}
