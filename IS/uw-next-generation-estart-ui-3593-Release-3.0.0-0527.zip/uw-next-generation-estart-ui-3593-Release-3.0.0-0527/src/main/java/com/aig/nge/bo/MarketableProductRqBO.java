package com.aig.nge.bo;

public class MarketableProductRqBO {
    private String segmentCd;
    private String subSegmentCd;
    private String marketableProductCd;
    private String underwriterId;
    
    private String productTowerCd;
	public String getProductTowerCd() {
		return productTowerCd;
	}
	public void setProductTowerCd(String productTowerCd) {
		this.productTowerCd = productTowerCd;
	}
	/**
	 * @return the segmentCd
	 */
	public String getSegmentCd() {
		return segmentCd;
	}
	/**
	 * @param segmentCd the segmentCd to set
	 */
	public void setSegmentCd(String segmentCd) {
		this.segmentCd = segmentCd;
	}
	/**
	 * @return the subSegmentCd
	 */
	public String getSubSegmentCd() {
		return subSegmentCd;
	}
	/**
	 * @param subSegmentCd the subSegmentCd to set
	 */
	public void setSubSegmentCd(String subSegmentCd) {
		this.subSegmentCd = subSegmentCd;
	}
	/**
	 * @return the marketableProductCd
	 */
	public String getMarketableProductCd() {
		return marketableProductCd;
	}
	/**
	 * @param marketableProductCd the marketableProductCd to set
	 */
	public void setMarketableProductCd(String marketableProductCd) {
		this.marketableProductCd = marketableProductCd;
	}
	/**
	 * @return the underwriterId
	 */
	public String getUnderwriterId() {
		return underwriterId;
	}
	/**
	 * @param underwriterId the underwriterId to set
	 */
	public void setUnderwriterId(String underwriterId) {
		this.underwriterId = underwriterId;
	}
    
}
