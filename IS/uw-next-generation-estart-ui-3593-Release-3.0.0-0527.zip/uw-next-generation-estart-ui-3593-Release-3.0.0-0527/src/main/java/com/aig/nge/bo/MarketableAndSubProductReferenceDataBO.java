package com.aig.nge.bo;

import java.io.Serializable;
import java.util.List;

public class MarketableAndSubProductReferenceDataBO implements Serializable{
	private static final long serialVersionUID = 1L;
	private String productTower;
	private String creditedCountryPLHidden;
	private List<MarketableAndSubProductBO> data;
	
	public String getProductTower() {
		return productTower;
	}
	public void setProductTower(String productTower) {
		this.productTower = productTower;
	}
	public List<MarketableAndSubProductBO> getData() {
		return data;
	}
	public void setData(List<MarketableAndSubProductBO> data) {
		this.data = data;
	}
	public String getCreditedCountryPLHidden() {
		return creditedCountryPLHidden;
	}
	public void setCreditedCountryPLHidden(String creditedCountryPLHidden) {
		this.creditedCountryPLHidden = creditedCountryPLHidden;
	}
}
