package com.aig.nge.bo;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonProperty;

public class Parties {
	
	@JsonProperty("AccountNumber")
	private String  accountNumber="";
	@JsonProperty("AccountBusinessName")
	private String 	accountBusinessName="";
	@JsonProperty("Organization")
	private String 	organization="";
	@JsonProperty("PartyId")
	private String 	partyId="";
	@JsonProperty("DUNSActiveIndicator")
	private String 	dunsActiveIndicator="";
	@JsonProperty("TreePositionCode")
	private String treePositionCode="";
	@JsonProperty("Addresses")
	private List<Addresses> addresses;
	@JsonProperty("TaxIdentifiers")
	private List<TaxIdentifiers> taxIdentifiers;
	@JsonProperty("submissionCount")
	private int submissionCount;
	
	
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		accountNumber=setDefaultStringValue(accountNumber);

		this.accountNumber = accountNumber;
	}
	public String getAccountBusinessName() {
		return accountBusinessName;
	}
	public void setAccountBusinessName(String accountBusinessName) {
		accountBusinessName=setDefaultStringValue(accountBusinessName);

		this.accountBusinessName = accountBusinessName;
	}
	
	public List<TaxIdentifiers> getTaxIdentifiers() {
		return taxIdentifiers;
	}
	public void setTaxIdentifiers(List<TaxIdentifiers> taxIdentifiers) {
		this.taxIdentifiers = taxIdentifiers;
	}
	public List<Addresses> getAddresses() {
		return addresses;
	}
	public void setAddresses(List<Addresses> addresses) {
		this.addresses = addresses;
	}
	public String getOrganization() {
		return organization;
	}
	public void setOrganization(String organization) {
		this.organization = organization;
	}
	public String getPartyId() {
		return partyId;
	}
	public void setPartyId(String partyId) {
		this.partyId = partyId;
	}
	public String getDunsActiveIndicator() {
		return dunsActiveIndicator;
	}
	public void setDunsActiveIndicator(String dunsActiveIndicator) {
		this.dunsActiveIndicator = dunsActiveIndicator;
	}
	public String getTreePositionCode() {
		return treePositionCode;
	}
	public void setTreePositionCode(String treePositionCode) {
		this.treePositionCode = treePositionCode;
	}
	public int getSubmissionCount() {
		return submissionCount;
	}
	public void setSubmissionCount(int submissionCount) {
		this.submissionCount = submissionCount;
	}
	
	public static String setDefaultStringValue(String tempValue){
		if(tempValue==null){
			tempValue="";
		}
		return tempValue;
	}
	public static String setDefaultNumValue(String tempValue){
		if(tempValue==null || tempValue.trim().length()==0){
			tempValue="0";
		}
		return tempValue;
	}
}
