package com.aig.nge.bo;

import java.util.List;


public class ComponentProductBO {
	
	private String compProductId;
	private String marketableProductCd;
	private String marketableProductName;
	private String segmentCd;
	private String subSegmentCd;
	private String segmentName;
	private String subSegmentName;
	private String componentProductCd;
	private String componentProductName;
	private String dspMmcp;
	private String divisionNo;
	private String sectionCd;
	private String profitUnitCd;
	private String majorLineCd;
	private String minorLineCd;
	private String classPerilCd;
	private String majorClassCd;
	private String productStateCd;
	private String productStateNm;
	private String effectiveDt;
	private String expirationDt;
	private String limitTypeCd;
	private String lifeCycleStatusCd;
	private String lifeCycleStatusNm;
	private String reservationStatus;
	private String reservationStatusNm;
	private String reasonName;
	private String reasonDs;
	private String autoCloseDt;
	private String underwriterId;
	private String productTower;
	private String componentProductTower;
	
	private List<AttributesInfoBO> attributesInfo;
	private List<BranchBO> branch;
	private LimitBO limit;
	private List<AdditionalInsuredBO> additionalInsured;
	private List<AssetBO> asset;
	private List<BlockComponentProductBO> blockComponentProduct;
	private List<PolicyDetailBO> policyDetail;
	private String reserveProductIn;	
	private AdditionalInsuredsBO additionalInsureds;
	private String componentProductTabKey;
	private String productTabkey;
	private String action;
	private boolean isUpdateRequired;
	private List<AttributesInfoUpdBO> attributesInfoUpdate;
	private MarketableProductDetailsBO marketableProduct;
	private List<ProductBO> expiringProduct;
	private String renewalFlag;
	private String isrenewalProduct;
	private String creditedCountryBranchCd;
	private String transactionComponentId;
	
	private String componentProductSegmentCd;
	private String componentProductSubSegmentCd;
	private String componentProductSegmentName;
	private String componentProductSubSegmentName;
	private String creditedCountryId;
	private ExposureCountryBO exposureCountry;
    private ExposureDataBO exposureType; 
    
    /* 2020 SCUP Changes UI Changes */
    private String masterLineOfCd;
    private String masterLineOfNm;
    private String coverageLineCd;
    private String coverageLineNm;
    
	public String getMasterLineOfCd() {
		return masterLineOfCd;
	}
	public void setMasterLineOfCd(String masterLineOfCd) {
		this.masterLineOfCd = masterLineOfCd;
	}
	public String getMasterLineOfNm() {
		return masterLineOfNm;
	}
	public void setMasterLineOfNm(String masterLineOfNm) {
		this.masterLineOfNm = masterLineOfNm;
	}
	public String getCoverageLineCd() {
		return coverageLineCd;
	}
	public void setCoverageLineCd(String coverageLineCd) {
		this.coverageLineCd = coverageLineCd;
	}
	public String getCoverageLineNm() {
		return coverageLineNm;
	}
	public void setCoverageLineNm(String coverageLineNm) {
		this.coverageLineNm = coverageLineNm;
	}
    
    /* 2020 SCUP Changes UI Changes */
    
	public ExposureDataBO getExposureType() {
		return exposureType;
	}
	public void setExposureType(ExposureDataBO exposureType) {
		this.exposureType = exposureType;
	}
	public ExposureCountryBO getExposureCountry() {
		return exposureCountry;
	}
	public void setExposureCountry(ExposureCountryBO exposureCountry) {
		this.exposureCountry = exposureCountry;
	}
	public String getTransactionComponentId() {
		return transactionComponentId;
	}
	public void setTransactionComponentId(String transactionComponentId) {
		this.transactionComponentId = transactionComponentId;
	}
	public String getCreditedCountryBranchCd() {
		return creditedCountryBranchCd;
	}
	public void setCreditedCountryBranchCd(String creditedCountryBranchCd) {
		this.creditedCountryBranchCd = creditedCountryBranchCd;
	}
	public String getRenewalFlag() {
		return renewalFlag;
	}
	public String getIsrenewalProduct() {
		return isrenewalProduct;
	}
	public void setIsrenewalProduct(String isrenewalProduct) {
		this.isrenewalProduct = isrenewalProduct;
	}
	public void setRenewalFlag(String renewalFlag) {
		this.renewalFlag = renewalFlag;
	}
	public List<ProductBO> getExpiringProduct() {
		return expiringProduct;
	}
	public void setExpiringProduct(List<ProductBO> expiringProduct) {
		this.expiringProduct = expiringProduct;
	}
	public MarketableProductDetailsBO getMarketableProduct() {
		return marketableProduct;
	}
	public void setMarketableProduct(MarketableProductDetailsBO marketableProduct) {
		this.marketableProduct = marketableProduct;
	}
	/**
	 * @return the attributesInfoUpdate
	 */
	public List<AttributesInfoUpdBO> getAttributesInfoUpdate() {
		return attributesInfoUpdate;
	}
	/**
	 * @param attributesInfoUpdate the attributesInfoUpdate to set
	 */
	public void setAttributesInfoUpdate(
			List<AttributesInfoUpdBO> attributesInfoUpdate) {
		this.attributesInfoUpdate = attributesInfoUpdate;
	}
	/**
	 * @return the isUpdateRequired
	 */
	public boolean isUpdateRequired() {
		return isUpdateRequired;
	}
	/**
	 * @param isUpdateRequired the isUpdateRequired to set
	 */
	public void setUpdateRequired(boolean isUpdateRequired) {
		this.isUpdateRequired = isUpdateRequired;
	}
	/**
	 * @return the action
	 */
	public String getAction() {
		return action;
	}
	/**
	 * @param action the action to set
	 */
	public void setAction(String action) {
		this.action = action;
	}
	/**
	 * @return the compProductId
	 */
	public String getCompProductId() {
		return compProductId;
	}
	/**
	 * @param compProductId the compProductId to set
	 */
	public void setCompProductId(String compProductId) {
		this.compProductId = compProductId;
	}
	public String getMarketableProductCd() {
		return marketableProductCd;
	}
	public void setMarketableProductCd(String marketableProductCd) {
		this.marketableProductCd = marketableProductCd;
	}
	public String getMarketableProductName() {
		return marketableProductName;
	}
	public void setMarketableProductName(String marketableProductName) {
		this.marketableProductName = marketableProductName;
	}
	public String getSegmentCd() {
		return segmentCd;
	}
	public void setSegmentCd(String segmentCd) {
		this.segmentCd = segmentCd;
	}
	public String getSubSegmentCd() {
		return subSegmentCd;
	}
	public void setSubSegmentCd(String subSegmentCd) {
		this.subSegmentCd = subSegmentCd;
	}
	public String getSegmentName() {
		return segmentName;
	}
	public void setSegmentName(String segmentName) {
		this.segmentName = segmentName;
	}
	public String getSubSegmentName() {
		return subSegmentName;
	}
	public void setSubSegmentName(String subSegmentName) {
		this.subSegmentName = subSegmentName;
	}
	public String getComponentProductCd() {
		return componentProductCd;
	}
	public void setComponentProductCd(String componentProductCd) {
		this.componentProductCd = componentProductCd;
	}
	public String getComponentProductName() {
		return componentProductName;
	}
	public void setComponentProductName(String componentProductName) {
		this.componentProductName = componentProductName;
	}
	public String getDivisionNo() {
		return divisionNo;
	}
	public void setDivisionNo(String divisionNo) {
		this.divisionNo = divisionNo;
	}
	public String getProductTower() {
		return productTower;
	}
	public void setProductTower(String productTower) {
		this.productTower = productTower;
	}
	public String getSectionCd() {
		return sectionCd;
	}
	public void setSectionCd(String sectionCd) {
		this.sectionCd = sectionCd;
	}
	public String getProfitUnitCd() {
		return profitUnitCd;
	}
	public void setProfitUnitCd(String profitUnitCd) {
		this.profitUnitCd = profitUnitCd;
	}
	public String getMajorLineCd() {
		return majorLineCd;
	}
	public void setMajorLineCd(String majorLineCd) {
		this.majorLineCd = majorLineCd;
	}
	public String getMinorLineCd() {
		return minorLineCd;
	}
	public void setMinorLineCd(String minorLineCd) {
		this.minorLineCd = minorLineCd;
	}
	public String getClassPerilCd() {
		return classPerilCd;
	}
	public void setClassPerilCd(String classPerilCd) {
		this.classPerilCd = classPerilCd;
	}
	public String getMajorClassCd() {
		return majorClassCd;
	}
	public void setMajorClassCd(String majorClassCd) {
		this.majorClassCd = majorClassCd;
	}
	public String getProductStateCd() {
		return productStateCd;
	}
	public void setProductStateCd(String productStateCd) {
		this.productStateCd = productStateCd;
	}
	public String getProductStateNm() {
		return productStateNm;
	}
	public void setProductStateNm(String productStateNm) {
		this.productStateNm = productStateNm;
	}
	public String getEffectiveDt() {
		return effectiveDt;
	}
	public void setEffectiveDt(String effectiveDt) {
		this.effectiveDt = effectiveDt;
	}
	public String getExpirationDt() {
		return expirationDt;
	}
	public void setExpirationDt(String expirationDt) {
		this.expirationDt = expirationDt;
	}
	public String getLimitTypeCd() {
		return limitTypeCd;
	}
	public void setLimitTypeCd(String limitTypeCd) {
		this.limitTypeCd = limitTypeCd;
	}
	public String getLifeCycleStatusCd() {
		return lifeCycleStatusCd;
	}
	public void setLifeCycleStatusCd(String lifeCycleStatusCd) {
		this.lifeCycleStatusCd = lifeCycleStatusCd;
	}
	public String getLifeCycleStatusNm() {
		return lifeCycleStatusNm;
	}
	public void setLifeCycleStatusNm(String lifeCycleStatusNm) {
		this.lifeCycleStatusNm = lifeCycleStatusNm;
	}
	public String getReservationStatus() {
		return reservationStatus;
	}
	public void setReservationStatus(String reservationStatus) {
		this.reservationStatus = reservationStatus;
	}
	public String getReservationStatusNm() {
		return reservationStatusNm;
	}
	public void setReservationStatusNm(String reservationStatusNm) {
		this.reservationStatusNm = reservationStatusNm;
	}
	public String getReasonName() {
		return reasonName;
	}
	public void setReasonName(String reasonName) {
		this.reasonName = reasonName;
	}
	public String getReasonDs() {
		return reasonDs;
	}
	public void setReasonDs(String reasonDs) {
		this.reasonDs = reasonDs;
	}
	public String getAutoCloseDt() {
		return autoCloseDt;
	}
	public void setAutoCloseDt(String autoCloseDt) {
		this.autoCloseDt = autoCloseDt;
	}
	public String getUnderwriterId() {
		return underwriterId;
	}
	public void setUnderwriterId(String underwriterId) {
		this.underwriterId = underwriterId;
	}
	public List<AttributesInfoBO> getAttributesInfo() {
		return attributesInfo;
	}
	public void setAttributesInfo(List<AttributesInfoBO> attributesInfo) {
		this.attributesInfo = attributesInfo;
	}
	public List<BranchBO> getBranch() {
		return branch;
	}
	public void setBranch(List<BranchBO> branch) {
		this.branch = branch;
	}
	public LimitBO getLimit() {
		return limit;
	}
	public void setLimit(LimitBO limit) {
		this.limit = limit;
	}
	
	public List<AdditionalInsuredBO> getAdditionalInsured() {
		return additionalInsured;
	}
	public void setAdditionalInsured(List<AdditionalInsuredBO> additionalInsured) {
		this.additionalInsured = additionalInsured;
	}
	public List<AssetBO> getAsset() {
		return asset;
	}
	public void setAsset(List<AssetBO> asset) {
		this.asset = asset;
	}
	public List<BlockComponentProductBO> getBlockComponentProduct() {
		return blockComponentProduct;
	}
	public void setBlockComponentProduct(
			List<BlockComponentProductBO> blockComponentProduct) {
		this.blockComponentProduct = blockComponentProduct;
	}
	public List<PolicyDetailBO> getPolicyDetail() {
		return policyDetail;
	}
	public void setPolicyDetail(List<PolicyDetailBO> policyDetail) {
		this.policyDetail = policyDetail;
	}
	/**
	 * @return the reserveProductIn
	 */
	public String getReserveProductIn() {
		return reserveProductIn;
	}
	/**
	 * @param reserveProductIn the reserveProductIn to set
	 */
	public void setReserveProductIn(String reserveProductIn) {
		this.reserveProductIn = reserveProductIn;
	}
	/**
	 * @return the additionalInsureds
	 */
	public AdditionalInsuredsBO getAdditionalInsureds() {
		return additionalInsureds;
	}
	/**
	 * @param additionalInsureds the additionalInsureds to set
	 */
	public void setAdditionalInsureds(AdditionalInsuredsBO additionalInsureds) {
		this.additionalInsureds = additionalInsureds;
	}
	public String getDspMmcp() {
		return dspMmcp;
	}
	public void setDspMmcp(String dspMmcp) {
		this.dspMmcp = dspMmcp;
	}
	public String getComponentProductTabKey() {
		return componentProductTabKey;
	}
	public void setComponentProductTabKey(String componentProductTabKey) {
		this.componentProductTabKey = componentProductTabKey;
	}
	public String getProductTabkey() {
		return productTabkey;
	}
	public void setProductTabkey(String productTabkey) {
		this.productTabkey = productTabkey;
	}
	public String getComponentProductSegmentCd() {
		return componentProductSegmentCd;
	}
	public void setComponentProductSegmentCd(String componentProductSegmentCd) {
		this.componentProductSegmentCd = componentProductSegmentCd;
	}
	public String getComponentProductSubSegmentCd() {
		return componentProductSubSegmentCd;
	}
	public void setComponentProductSubSegmentCd(String componentProductSubSegmentCd) {
		this.componentProductSubSegmentCd = componentProductSubSegmentCd;
	}
	public String getComponentProductSegmentName() {
		return componentProductSegmentName;
	}
	public void setComponentProductSegmentName(String componentProductSegmentName) {
		this.componentProductSegmentName = componentProductSegmentName;
	}
	public String getComponentProductSubSegmentName() {
		return componentProductSubSegmentName;
	}
	public void setComponentProductSubSegmentName(
			String componentProductSubSegmentName) {
		this.componentProductSubSegmentName = componentProductSubSegmentName;
	}
	public String getComponentProductTower() {
		return componentProductTower;
	}
	public void setComponentProductTower(String componentProductTower) {
		this.componentProductTower = componentProductTower;
	}
	public String getCreditedCountryId() {
		return creditedCountryId;
	}
	public void setCreditedCountryId(String creditedCountryId) {
		this.creditedCountryId = creditedCountryId;
	}
	
}
