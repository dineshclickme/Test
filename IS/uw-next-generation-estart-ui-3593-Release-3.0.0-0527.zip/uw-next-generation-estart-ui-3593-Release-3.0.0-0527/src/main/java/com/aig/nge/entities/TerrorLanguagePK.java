package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the TERROR_LANGUAGE database table.
 * 
 */
@Embeddable
public class TerrorLanguagePK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="ERROR_ID")
	private short errorId;

	@Column(name="LANGUAGE_ID")
	private short languageId;

    public TerrorLanguagePK() {
    }
	public short getErrorId() {
		return this.errorId;
	}
	public void setErrorId(short errorId) {
		this.errorId = errorId;
	}
	public short getLanguageId() {
		return this.languageId;
	}
	public void setLanguageId(short languageId) {
		this.languageId = languageId;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof TerrorLanguagePK)) {
			return false;
		}
		TerrorLanguagePK castOther = (TerrorLanguagePK)other;
		return 
			(this.errorId == castOther.errorId)
			&& (this.languageId == castOther.languageId);

    }
    
	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.errorId;
		hash = hash * prime + this.languageId;
		
		return hash;
    }
}