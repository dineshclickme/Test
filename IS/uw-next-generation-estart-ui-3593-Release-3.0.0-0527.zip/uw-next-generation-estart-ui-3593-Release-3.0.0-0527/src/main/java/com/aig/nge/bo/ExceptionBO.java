package com.aig.nge.bo;

public class ExceptionBO {

	private String errorCode;
	private String errorType;
	private String errorMessage;
	private String errorFrom;
	/**
	 * @return the errorCode
	 */
	public String getErrorCode() {
		return errorCode;
	}
	/**
	 * @param errorCode the errorCode to set
	 */
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	/**
	 * @return the errorType
	 */
	public String getErrorType() {
		return errorType;
	}
	/**
	 * @param errorType the errorType to set
	 */
	public void setErrorType(String errorType) {
		this.errorType = errorType;
	}
	/**
	 * @return the errorMessage
	 */
	public String getErrorMessage() {
		return errorMessage;
	}
	/**
	 * @param errorMessage the errorMessage to set
	 */
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	/**
	 * @return the errorFrom
	 */
	public String getErrorFrom() {
		return errorFrom;
	}
	/**
	 * @param errorFrom the errorFrom to set
	 */
	public void setErrorFrom(String errorFrom) {
		this.errorFrom = errorFrom;
	}
	
}
