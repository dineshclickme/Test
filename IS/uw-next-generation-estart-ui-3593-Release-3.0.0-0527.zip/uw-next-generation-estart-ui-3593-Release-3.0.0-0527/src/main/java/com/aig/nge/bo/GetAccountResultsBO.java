package com.aig.nge.bo;

import java.util.List;

public class GetAccountResultsBO {
    private AccountDetBO account;
    private List<RowBO> row;
    private List<NCIInfoBO> nci;
    private List<FienInfoBO> fein;
    private List<String> feins;
    private String count;
	/**
	 * @return the account
	 */
	public AccountDetBO getAccount() {
		return account;
	}
	/**
	 * @param account the account to set
	 */
	public void setAccount(AccountDetBO account) {
		this.account = account;
	}
	/**
	 * @return the row
	 */
	public List<RowBO> getRow() {
		return row;
	}
	/**
	 * @param row the row to set
	 */
	public void setRow(List<RowBO> row) {
		this.row = row;
	}
	/**
	 * @return the nci
	 */
	public List<NCIInfoBO> getNci() {
		return nci;
	}
	/**
	 * @param nci the nci to set
	 */
	public void setNci(List<NCIInfoBO> nci) {
		this.nci = nci;
	}
	/**
	 * @return the fein
	 */
	public List<FienInfoBO> getFein() {
		return fein;
	}
	/**
	 * @param fein the fein to set
	 */
	public void setFein(List<FienInfoBO> fein) {
		this.fein = fein;
	}
	/**
	 * @return the feins
	 */
	public List<String> getFeins() {
		return feins;
	}
	/**
	 * @param feins the feins to set
	 */
	public void setFeins(List<String> feins) {
		this.feins = feins;
	}
	/**
	 * @return the count
	 */
	public String getCount() {
		return count;
	}
	/**
	 * @param count the count to set
	 */
	public void setCount(String count) {
		this.count = count;
	}
}
