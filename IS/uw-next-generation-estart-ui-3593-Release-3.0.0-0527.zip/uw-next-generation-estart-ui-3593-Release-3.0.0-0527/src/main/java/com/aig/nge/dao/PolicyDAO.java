package com.aig.nge.dao;

import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.aig.nge.entities.Tpolicy;
import com.aig.nge.entities.TpolicyType;
import com.aig.nge.entities.TreftabMis780;
import com.aig.nge.repository.TPolicyRepository;
import com.aig.nge.repository.TReftabRepository;
import com.aig.nge.repository.TpolicyTypeRepository;

@Repository
public class PolicyDAO extends BaseDAO{

	@Autowired
	private TpolicyTypeRepository tPolicyTypeRepository;
	
	@Autowired
	private TReftabRepository tReftabRepository;
	
	@Autowired
	private TPolicyRepository tPolicyRepository;
	
	/**
	 * @author Ramakrishnas
	 * This method is used to get the list of all policy types
	 */		
	public Set<TpolicyType> getPolicyTypesDAO(){
		Set<TpolicyType> policyTypes = tPolicyTypeRepository.getPolicyTypes();
		return policyTypes;
	}
	
	public Set<TreftabMis780> getCompNames(){
		Set<TreftabMis780> compNames = tReftabRepository.getCompData();
		return compNames;
	}
	
	public Set<Tpolicy> getPolicyInfoByPolicyNoPolicyTypeAndIssuingCompanyDAO(String policyNo, String policyTypeId, String issuingCompanyCd){
		Set<Tpolicy> policies = tPolicyRepository.getPolicyInfoByPolicyNoPolicyTypeAndIssuingCompany(policyNo,policyTypeId,issuingCompanyCd);
		return policies;
	}
	
	public Set<Tpolicy> getPolicyInfoByPolicyTypeAndIssuingCompanyDAO(String policyTypeId, String issuingCompanyCd){
		Set<Tpolicy> policies = tPolicyRepository.getPolicyInfoByPolicyTypeAndIssuingCompany(policyTypeId,issuingCompanyCd);
		return policies;
	}

	public TreftabMis780 getIssuingCompany(String issuingCompanyCode) {
		TreftabMis780 treftabMis780 = tReftabRepository.getIssuingCompany(issuingCompanyCode);
		return treftabMis780;
	}
}
