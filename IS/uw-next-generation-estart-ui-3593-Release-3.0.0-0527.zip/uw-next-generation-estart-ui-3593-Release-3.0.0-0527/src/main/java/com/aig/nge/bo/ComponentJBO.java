package com.aig.nge.bo;

public class ComponentJBO {

	private String dataKey;
	private String workingBranch;
	private String division;
	private String dspMMCP;
	private String underwriter;
	private String currency;
	private String attachmentPoint;
	private String coverageType;
	private String limitAmount;
	private String effectiveDate;
	private String premiumAmount;
	private String technicalPriceAmount;
	private String limitType;
	private String expirationDate;
	private String priorCarrier;
	private String renewableNonRecurringInd;
	private String servicingBranch;
	/**
	 * @return the dataKey
	 */
	public String getDataKey() {
		return dataKey;
	}
	/**
	 * @param dataKey the dataKey to set
	 */
	public void setDataKey(String dataKey) {
		this.dataKey = dataKey;
	}
	/**
	 * @return the workingBranch
	 */
	public String getWorkingBranch() {
		return workingBranch;
	}
	/**
	 * @param workingBranch the workingBranch to set
	 */
	public void setWorkingBranch(String workingBranch) {
		this.workingBranch = workingBranch;
	}
	/**
	 * @return the division
	 */
	public String getDivision() {
		return division;
	}
	/**
	 * @param division the division to set
	 */
	public void setDivision(String division) {
		this.division = division;
	}
	/**
	 * @return the dspMMCP
	 */
	public String getDspMMCP() {
		return dspMMCP;
	}
	/**
	 * @param dspMMCP the dspMMCP to set
	 */
	public void setDspMMCP(String dspMMCP) {
		this.dspMMCP = dspMMCP;
	}
	/**
	 * @return the underwriter
	 */
	public String getUnderwriter() {
		return underwriter;
	}
	/**
	 * @param underwriter the underwriter to set
	 */
	public void setUnderwriter(String underwriter) {
		this.underwriter = underwriter;
	}
	/**
	 * @return the currency
	 */
	public String getCurrency() {
		return currency;
	}
	/**
	 * @param currency the currency to set
	 */
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	/**
	 * @return the attachmentPoint
	 */
	public String getAttachmentPoint() {
		return attachmentPoint;
	}
	/**
	 * @param attachmentPoint the attachmentPoint to set
	 */
	public void setAttachmentPoint(String attachmentPoint) {
		this.attachmentPoint = attachmentPoint;
	}
	/**
	 * @return the coverageType
	 */
	public String getCoverageType() {
		return coverageType;
	}
	/**
	 * @param coverageType the coverageType to set
	 */
	public void setCoverageType(String coverageType) {
		this.coverageType = coverageType;
	}
	/**
	 * @return the limitAmount
	 */
	public String getLimitAmount() {
		return limitAmount;
	}
	/**
	 * @param limitAmount the limitAmount to set
	 */
	public void setLimitAmount(String limitAmount) {
		this.limitAmount = limitAmount;
	}
	/**
	 * @return the effectiveDate
	 */
	public String getEffectiveDate() {
		return effectiveDate;
	}
	/**
	 * @param effectiveDate the effectiveDate to set
	 */
	public void setEffectiveDate(String effectiveDate) {
		this.effectiveDate = effectiveDate;
	}
	/**
	 * @return the premiumAmount
	 */
	public String getPremiumAmount() {
		return premiumAmount;
	}
	/**
	 * @param premiumAmount the premiumAmount to set
	 */
	public void setPremiumAmount(String premiumAmount) {
		this.premiumAmount = premiumAmount;
	}
	/**
	 * @return the technicalPriceAmount
	 */
	public String getTechnicalPriceAmount() {
		return technicalPriceAmount;
	}
	/**
	 * @param technicalPriceAmount the technicalPriceAmount to set
	 */
	public void setTechnicalPriceAmount(String technicalPriceAmount) {
		this.technicalPriceAmount = technicalPriceAmount;
	}
	/**
	 * @return the limitType
	 */
	public String getLimitType() {
		return limitType;
	}
	/**
	 * @param limitType the limitType to set
	 */
	public void setLimitType(String limitType) {
		this.limitType = limitType;
	}
	/**
	 * @return the expirationDate
	 */
	public String getExpirationDate() {
		return expirationDate;
	}
	/**
	 * @param expirationDate the expirationDate to set
	 */
	public void setExpirationDate(String expirationDate) {
		this.expirationDate = expirationDate;
	}
	/**
	 * @return the priorCarrier
	 */
	public String getPriorCarrier() {
		return priorCarrier;
	}
	/**
	 * @param priorCarrier the priorCarrier to set
	 */
	public void setPriorCarrier(String priorCarrier) {
		this.priorCarrier = priorCarrier;
	}
	/**
	 * @return the renewableNonRecurringInd
	 */
	public String getRenewableNonRecurringInd() {
		return renewableNonRecurringInd;
	}
	/**
	 * @param renewableNonRecurringInd the renewableNonRecurringInd to set
	 */
	public void setRenewableNonRecurringInd(String renewableNonRecurringInd) {
		this.renewableNonRecurringInd = renewableNonRecurringInd;
	}
	/**
	 * @return the servicingBranch
	 */
	public String getServicingBranch() {
		return servicingBranch;
	}
	/**
	 * @param servicingBranch the servicingBranch to set
	 */
	public void setServicingBranch(String servicingBranch) {
		this.servicingBranch = servicingBranch;
	}
	
}
