package com.aig.nge.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.aig.nge.bo.ProducerEntitySearchRespBO;
import com.aig.nge.bo.UnderwriterSearchReqBO;
import com.aig.nge.bo.UnderwriterSearchResBO;
import com.aig.nge.bo.UnderwriterSearchResBO1;
import com.aig.nge.bo.UserPrefBO;
import com.aig.nge.entities.Tparty;
import com.aig.nge.entities.Tproducer;
import com.aig.nge.entities.TuserPreferedProducer;
import com.aig.nge.entities.TuserPrefernce;
import com.aig.nge.entities.TuserPreferredAttribute;
import com.aig.nge.entities.TuserPreferredUnderwriter;
import com.aig.nge.helper.UnderwriterSearchHelper;
import com.aig.nge.repository.TPartyRepository;
import com.aig.nge.repository.TProducerRepository;
import com.aig.nge.repository.TUserPrefAttrRepository;
import com.aig.nge.repository.TUserPrefProducerRepository;
import com.aig.nge.repository.TUserPrefRepository;
import com.aig.nge.repository.TUserPrefUnderwriterRepository;
import com.aig.nge.service.DataCacheObject;
import com.aig.nge.utilities.NGEConstants;
import com.aig.nge.utilities.NGEConstants.PartyType;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
//import com.aig.nge.entities.TuserPreferredUnderwriter_;

@Repository
public class UserPrefDAO extends BaseDAO {
	//TCS CE Team Changes Starts Here
	private static final Logger logger = LogManager.getLogger(UserPrefDAO.class);
	//TCS CE Team Changes Ends Here
	
	@Autowired
	private TUserPrefRepository tUserPrefRepository;
	
	@Autowired
	private TUserPrefProducerRepository tUserPrefProducerRepository;

	@Autowired
	private TProducerRepository tProducerRepository;
	
	@Autowired
	private TPartyRepository tPartyRepository;
	
	@Autowired
	private TUserPrefUnderwriterRepository tUserPrefUnderwriterRepository ;
	/*PI3 - Aug release - Add Low goverance attribute in user prefernce starts */
	@Autowired
	private TUserPrefAttrRepository tUserPrefAttrRepository;
	
		
	public void saveUserPreference(TuserPrefernce tuserPrefernce) {
		tUserPrefRepository.save(tuserPrefernce);
	}
	
	public void deleteUserPreference(TuserPrefernce tuserPrefernce) {
		tUserPrefRepository.delete(tuserPrefernce);
	}
	
	public void addUserPrefUnderwriter(TuserPreferredUnderwriter tUserPreferredUnderwriter){
		tUserPrefUnderwriterRepository.save(tUserPreferredUnderwriter);
	}
	/*PI3 - Aug release - Add Low goverance attribute in user prefernce starts */
	public void addUserPrefAttribute(TuserPreferredAttribute tUserPreferredAttribute){
		tUserPrefAttrRepository.save(tUserPreferredAttribute);
	}
	public void deleteUserPrefAttr(TuserPreferredAttribute tUserPreferredUnderwriter){
		tUserPrefAttrRepository.delete(tUserPreferredUnderwriter);
	}
	/*PI3 - Aug release - Add Low goverance attribute in user prefernce end */
	public void deleteUserPrefUnderwriter(TuserPreferredUnderwriter tUserPreferredUnderwriter){
		tUserPrefUnderwriterRepository.delete(tUserPreferredUnderwriter);
	}
	
	public void addUserPrefProducer(TuserPreferedProducer tUserPreferedProducer) {
		tUserPrefProducerRepository.save(tUserPreferedProducer);
	}
	
	public void deleteUserPrefProducer(TuserPreferedProducer tUserPreferedProducer) {
		tUserPrefProducerRepository.delete(tUserPreferedProducer);
	}
	
	public void addParty(Tparty tParty) {
		tPartyRepository.save(tParty);
	}
	
	public void addProducer(Tproducer tProducer) {
		tProducerRepository.save(tProducer);
	}
	
	public int getPartyIdSequence(){
		return tPartyRepository.getPartyIdSequence();
	}
	/*July 2017 Maintenance Release- NGE Role - CASL role sync - starts*/
	public int findPartyIdByNo(String partyNo,String partyType){
		int partyId=-1;
		Set<Object> partyIdList= tPartyRepository.findPartyIdByNum(partyNo,partyType);
		if(partyIdList!=null){
			for(Object partyIdData : partyIdList){
				partyId=Integer.parseInt(partyIdData.toString());
			}
		}
		return partyId;
	}
	/*July 2017 Maintenance Release- NGE Role - CASL role sync - End*/
	public String findPartyNoById(Integer partyID){
		String partyNo="-1";
		Set<Object> partyIdList= tPartyRepository.findPartyNumById(partyID,NGEConstants.UNDERWRITER.toUpperCase());
		if(partyIdList!=null){
			for(Object partyIdData : partyIdList){
				partyNo=partyIdData.toString();
			}
		}
		return partyNo;
	}
	
	public int getProducerEntityPartyId(String partyNo){
		int partyId=-1;
		Set<Object> tParty=tPartyRepository.findPartyIdByNum(partyNo,NGEConstants.PRODUCER_ENTITY_PARTY_TYPE_NAME.toUpperCase() );
		if(tParty!=null){
			for(Object partyIdData : tParty){
				partyId=Integer.parseInt(partyIdData.toString());
			}
		}
		return partyId;
	}
	
	public TuserPrefernce findUserPreference(Integer userId){
		return tUserPrefRepository.findOne(userId);
	}
	
	public UserPrefBO getUserPreferenceData(String partyNo){
		UserPrefBO userprefBO=new UserPrefBO();
		try {
			DataCacheObject cacheObject = new DataCacheObject();
			Map<String,String> currencyIdCodes = (Map<String,String>)cacheObject.getDynacacheObj("CURRENCY_ID_CODE");
			Map<String,String> geographicLocationIdMap = (Map<String,String>)cacheObject.getDynacacheObj("GEOGRAPHIC_ID_MAP_ID");
			Map<String,String> productTowerIdMap = (Map<String,String>)cacheObject.getDynacacheObj("PRODUCT_TOWERS_ID_CODE");
			Map<String,String> branchIdMap = (Map<String,String>)cacheObject.getDynacacheObj("BRANCH_ID_AND_CODE");
			Map<String,String> dateFormatMap = (Map<String,String>)cacheObject.getDynacacheObj("DATE_FORMAT_ID_MAP");
			
			Set<Object[]> tUserPreferenceList=tUserPrefRepository.getUserPreferenceData(partyNo,PartyType.UNDERWRITER_PARTYTYPE.toUpperCase());
			/*July 2017 Maintenance Release- NGE Role - CASL role sync - starts*/
			if(tUserPreferenceList==null ||tUserPreferenceList.size()==0){
				tUserPreferenceList=tUserPrefRepository.getUserPreferenceData(partyNo,PartyType.USER_PARTYTYPE.toUpperCase());
			}
			/*July 2017 Maintenance Release- NGE Role - CASL role sync - End*/
			userprefBO.setLoginUserID(partyNo);
			if(tUserPreferenceList!=null && tUserPreferenceList.size()>0){
				for(Object[] tUserPreference:tUserPreferenceList){
					
					if(tUserPreference[1]!=null){
						userprefBO.setWorkingBranch(geographicLocationIdMap.get(tUserPreference[1].toString()));
						userprefBO.setWorkingBranchHidden(userprefBO.getWorkingBranch());
					}
					else{
						userprefBO.setWorkingBranchHidden(NGEConstants.OPTIONAL_FIELED_DELETE_VALUE);
					}
					if(tUserPreference[2]!=null){
						userprefBO.setCurrency(currencyIdCodes.get(tUserPreference[2].toString()));
						userprefBO.setCurrencyHidden(userprefBO.getCurrency());
					}else{
						userprefBO.setCurrencyHidden(NGEConstants.OPTIONAL_FIELED_DELETE_VALUE);
					}
					if(tUserPreference[3]!=null){
						userprefBO.setProductTower(productTowerIdMap.get(tUserPreference[3].toString()));
						userprefBO.setProductTowerHidden(userprefBO.getProductTower());
					}
					else{
						userprefBO.setProductTowerHidden(NGEConstants.OPTIONAL_FIELED_DELETE_VALUE);
					}
					if(tUserPreference[4]!=null){
						userprefBO.setWorkingCountryBranch(branchIdMap.get(tUserPreference[4].toString()));
						userprefBO.setWorkingCountryBranchHidden(userprefBO.getWorkingCountryBranch());
					}
					else{
						userprefBO.setWorkingCountryBranchHidden(NGEConstants.OPTIONAL_FIELED_DELETE_VALUE);
					}
					if(tUserPreference[5]!=null){
						userprefBO.setDateFormat(dateFormatMap.get(tUserPreference[5].toString()));
					}
					
					 // Q2 May 2018 - Maintenance release - Preferred underwriter List Changes starts
										
					List<String> tUserPrefUnderwriterNoList=tUserPrefRepository.getUserPrefUnderwriterData(Integer.parseInt(tUserPreference[0].toString()));
					
					List<UnderwriterSearchResBO1> underwritersList = new ArrayList<UnderwriterSearchResBO1>();
					if(tUserPrefUnderwriterNoList!=null && tUserPrefUnderwriterNoList.size()>0){
						for (String userPrefUnderwriterNo:tUserPrefUnderwriterNoList){
							UnderwriterSearchHelper underwriterSearchHelper = new UnderwriterSearchHelper();
							UnderwriterSearchReqBO underwriterSearchReqBO=new UnderwriterSearchReqBO();
							underwriterSearchReqBO.setPartyNo(userPrefUnderwriterNo);
							underwriterSearchReqBO.setIncludeSuspend(NGEConstants.YES);
							List<UnderwriterSearchResBO> searchUnderwritersList = new ArrayList<UnderwriterSearchResBO>();
							UnderwriterSearchResBO1 underwriterdetail = new UnderwriterSearchResBO1();
							searchUnderwritersList=underwriterSearchHelper.searchUnderwriterHelper(underwriterSearchReqBO);
							
							if(searchUnderwritersList!=null && searchUnderwritersList.size()>0){
								underwriterdetail.setPartyNo(searchUnderwritersList.get(0).getPartyNo());
								underwriterdetail.setPartyId(searchUnderwritersList.get(0).getPartyId());
								underwriterdetail.setUnderwriterFirstName(searchUnderwritersList.get(0).getUnderwriterFirstName());
								underwriterdetail.setUnderwriterName(searchUnderwritersList.get(0).getUnderwriterName());
								underwriterdetail.setJobTitle(searchUnderwritersList.get(0).getJobTitle());
								underwriterdetail.setContactNumber(searchUnderwritersList.get(0).getContactNumber());
								underwriterdetail.setEmailAddress(searchUnderwritersList.get(0).getEmailAddress());
								underwriterdetail.setLocationAddress(searchUnderwritersList.get(0).getLocationAddress());
								underwritersList.add(underwriterdetail);
							}
						}
					}
					
					userprefBO.setPreferredUnderWriter(underwritersList);
					// Q2 May 2018 - Maintenance release - Preferred underwriter List Changes ends.
					
					Set<Object[]> tUserPrefProducerList=tUserPrefRepository.getUserPreferenceProducerData(Integer.parseInt(tUserPreference[0].toString()));
					List<ProducerEntitySearchRespBO> producerEntityDataList=new ArrayList<ProducerEntitySearchRespBO>();
					if(tUserPrefProducerList!=null){
						for(Object[] tUserPrefProducer : tUserPrefProducerList){
							ProducerEntitySearchRespBO producerEntityData=new ProducerEntitySearchRespBO();
							producerEntityData.setProducerEntityNumber(tUserPrefProducer[0].toString());
							producerEntityData.setProducerEntityName(tUserPrefProducer[1].toString());
							producerEntityDataList.add(producerEntityData);
						}
					}
					
					userprefBO.setProducerEntityData(producerEntityDataList);
					/*PI3 - Aug release - Add Low goverance attribute in user prefernce starts */			
					Set<Object> tUserPrefAttrList=tUserPrefRepository.getUserPreferenceAttributeData(Integer.parseInt(tUserPreference[0].toString()));
					List<String> attrDataList=new ArrayList<String>();
					if(tUserPrefAttrList!=null){
						for(Object tUserPrefAttr : tUserPrefAttrList){
							attrDataList.add(tUserPrefAttr.toString());
						}
					}
					/*PI3 - Aug release - Add Low goverance attribute in user prefernce end */
					userprefBO.setPreferredAttribute(attrDataList);
				}
			}else{
				userprefBO.setCurrencyHidden(NGEConstants.OPTIONAL_FIELED_DELETE_VALUE);
				userprefBO.setWorkingBranchHidden(NGEConstants.OPTIONAL_FIELED_DELETE_VALUE);
				userprefBO.setProductTowerHidden(NGEConstants.OPTIONAL_FIELED_DELETE_VALUE);
				userprefBO.setWorkingCountryBranchHidden(NGEConstants.OPTIONAL_FIELED_DELETE_VALUE);
			}
		} catch (Exception e) {
			logger.debug("NGEUIException",e);
		}
		return userprefBO;
	}
}
