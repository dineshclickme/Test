package com.aig.nge.bo;

public class FiltersBO {

	private String transactionLifeCycleStatusCd;
	private String producerLifeCycleStatusCd;
	
	public String getTransactionLifeCycleStatusCd() {
		return transactionLifeCycleStatusCd;
	}
	public void setTransactionLifeCycleStatusCd(String transactionLifeCycleStatusCd) {
		this.transactionLifeCycleStatusCd = transactionLifeCycleStatusCd;
	}
	public String getProducerLifeCycleStatusCd() {
		return producerLifeCycleStatusCd;
	}
	public void setProducerLifeCycleStatusCd(String producerLifeCycleStatusCd) {
		this.producerLifeCycleStatusCd = producerLifeCycleStatusCd;
	}
}
