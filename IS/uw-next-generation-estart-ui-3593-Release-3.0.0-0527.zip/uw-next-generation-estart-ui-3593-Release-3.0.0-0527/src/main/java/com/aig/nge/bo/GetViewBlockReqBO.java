package com.aig.nge.bo;

import com.fasterxml.jackson.annotation.JsonInclude;



public class GetViewBlockReqBO {
   @JsonInclude(JsonInclude.Include.ALWAYS)
   private GetBlockedProductsRqBO getBlockedProductsRqBO;
   @JsonInclude(JsonInclude.Include.ALWAYS)
   private GetBlockingInfoReqBO getBlockingInfoReqBO;
   
	public GetBlockedProductsRqBO getGetBlockedProductsRqBO() {
		return getBlockedProductsRqBO;
	}
	public void setGetBlockedProductsRqBO(
			GetBlockedProductsRqBO getBlockedProductsRqBO) {
		this.getBlockedProductsRqBO = getBlockedProductsRqBO;
	}
	public GetBlockingInfoReqBO getGetBlockingInfoReqBO() {
		return getBlockingInfoReqBO;
	}
	public void setGetBlockingInfoReqBO(GetBlockingInfoReqBO getBlockingInfoReqBO) {
		this.getBlockingInfoReqBO = getBlockingInfoReqBO;
	}   
}
