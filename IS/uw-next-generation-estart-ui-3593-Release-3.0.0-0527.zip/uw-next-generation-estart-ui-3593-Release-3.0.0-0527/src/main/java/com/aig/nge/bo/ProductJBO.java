package com.aig.nge.bo;

public class ProductJBO {
	private String dataKey;
	private String productTower;
	private String mktProduct;
	private String bundleUnderwriter;
	private String lifeCycleStatus;
	/**
	 * @return the dataKey
	 */
	public String getDataKey() {
		return dataKey;
	}
	/**
	 * @param dataKey the dataKey to set
	 */
	public void setDataKey(String dataKey) {
		this.dataKey = dataKey;
	}
	/**
	 * @return the productTower
	 */
	public String getProductTower() {
		return productTower;
	}
	/**
	 * @param productTower the productTower to set
	 */
	public void setProductTower(String productTower) {
		this.productTower = productTower;
	}
	/**
	 * @return the mktProduct
	 */
	public String getMktProduct() {
		return mktProduct;
	}
	/**
	 * @param mktProduct the mktProduct to set
	 */
	public void setMktProduct(String mktProduct) {
		this.mktProduct = mktProduct;
	}
	/**
	 * @return the bundleUnderwriter
	 */
	public String getBundleUnderwriter() {
		return bundleUnderwriter;
	}
	/**
	 * @param bundleUnderwriter the bundleUnderwriter to set
	 */
	public void setBundleUnderwriter(String bundleUnderwriter) {
		this.bundleUnderwriter = bundleUnderwriter;
	}
	/**
	 * @return the lifeCycleStatus
	 */
	public String getLifeCycleStatus() {
		return lifeCycleStatus;
	}
	/**
	 * @param lifeCycleStatus the lifeCycleStatus to set
	 */
	public void setLifeCycleStatus(String lifeCycleStatus) {
		this.lifeCycleStatus = lifeCycleStatus;
	}
}
