package com.aig.nge.bo;

public class BrickMetaDataBO {
	
	private String brickMetaDataValue;

	public String getBrickMetaDataValue() {
		return brickMetaDataValue;
	}

	public void setBrickMetaDataValue(String brickMetaDataValue) {
		this.brickMetaDataValue = brickMetaDataValue;
	}
	

}
