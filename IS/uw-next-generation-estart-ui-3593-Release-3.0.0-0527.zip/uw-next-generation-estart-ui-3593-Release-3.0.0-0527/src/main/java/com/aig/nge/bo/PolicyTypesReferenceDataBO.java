package com.aig.nge.bo;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

public class PolicyTypesReferenceDataBO implements Serializable{
	private static final long serialVersionUID = 1L;
	
	private String policyRef;
	private List<Map<String,String>> data;
	public String getPolicyRef() {
		return policyRef;
	}
	public void setPolicyRef(String policyRef) {
		this.policyRef = policyRef;
	}
	public List<Map<String, String>> getData() {
		return data;
	}
	public void setData(List<Map<String, String>> data) {
		this.data = data;
	}
}
