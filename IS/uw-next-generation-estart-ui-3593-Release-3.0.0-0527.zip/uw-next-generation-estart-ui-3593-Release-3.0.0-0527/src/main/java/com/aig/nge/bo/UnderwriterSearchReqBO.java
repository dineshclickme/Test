package com.aig.nge.bo;

import com.fasterxml.jackson.annotation.JsonInclude;

public class UnderwriterSearchReqBO {

	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String lastName;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String firstName;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String locationState;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String locationCountry;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String status;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String includeSuspend;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String partyNo;
	
	public String getPartyNo() {
		return partyNo;
	}
	public void setPartyNo(String partyNo) {
		this.partyNo = partyNo;
	}
	public String getIncludeSuspend() {
		return includeSuspend;
	}
	public void setIncludeSuspend(String includeSuspend) {
		this.includeSuspend = includeSuspend;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLocationState() {
		return locationState;
	}
	public void setLocationState(String locationState) {
		this.locationState = locationState;
	}
	public String getLocationCountry() {
		return locationCountry;
	}
	public void setLocationCountry(String locationCountry) {
		this.locationCountry = locationCountry;
	}
}
