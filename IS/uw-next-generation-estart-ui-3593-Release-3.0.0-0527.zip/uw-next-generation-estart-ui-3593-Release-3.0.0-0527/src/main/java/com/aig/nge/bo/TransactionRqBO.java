package com.aig.nge.bo;


public class TransactionRqBO {
    private String transactionId;
    private String transactionVersionNo;
	/**
	 * @return the transactionId
	 */
	public String getTransactionId() {
		return transactionId;
	}
	/**
	 * @param transactionId the transactionId to set
	 */
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	/**
	 * @return the transactionVersionNo
	 */
	public String getTransactionVersionNo() {
		return transactionVersionNo;
	}
	/**
	 * @param transactionVersionNo the transactionVersionNo to set
	 */
	public void setTransactionVersionNo(String transactionVersionNo) {
		this.transactionVersionNo = transactionVersionNo;
	}
}
