package com.aig.nge.bo;

import java.io.Serializable;
import java.util.List;
import java.util.Map;


public class StateCountryReferenceDataBO implements Serializable{
	private static final long serialVersionUID = 1L;
	private String countryselection;
	private List<Map<String,String>> data;
	public String getCountryselection() {
		return countryselection;
	}
	public void setCountryselection(String countryselection) {
		this.countryselection = countryselection;
	}
	public List<Map<String, String>> getData() {
		return data;
	}
	public void setData(List<Map<String, String>> data) {
		this.data = data;
	}
	
	

}
