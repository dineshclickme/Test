package com.aig.nge.bo;

import java.util.List;

public class UpdateComponentProductResBO {
    private String segmentCd;
    private String subSegmentCd;
    private String marketableProductCd;
    private String componentProductCd;
    private String attachmentPointAmt;
    private List<BlockComponentProductBO> productBlocks;
    private List<AlertBlockDetailsBO> alertBlockDetails;
    private NGEViewOfMessageBO message;
	/**
	 * @return the segmentCd
	 */
	public String getSegmentCd() {
		return segmentCd;
	}
	/**
	 * @param segmentCd the segmentCd to set
	 */
	public void setSegmentCd(String segmentCd) {
		this.segmentCd = segmentCd;
	}
	/**
	 * @return the subSegmentCd
	 */
	public String getSubSegmentCd() {
		return subSegmentCd;
	}
	/**
	 * @param subSegmentCd the subSegmentCd to set
	 */
	public void setSubSegmentCd(String subSegmentCd) {
		this.subSegmentCd = subSegmentCd;
	}
	/**
	 * @return the marketableProductCd
	 */
	public String getMarketableProductCd() {
		return marketableProductCd;
	}
	/**
	 * @param marketableProductCd the marketableProductCd to set
	 */
	public void setMarketableProductCd(String marketableProductCd) {
		this.marketableProductCd = marketableProductCd;
	}
	/**
	 * @return the componentProductCd
	 */
	public String getComponentProductCd() {
		return componentProductCd;
	}
	/**
	 * @param componentProductCd the componentProductCd to set
	 */
	public void setComponentProductCd(String componentProductCd) {
		this.componentProductCd = componentProductCd;
	}
	/**
	 * @return the attachmentPointAmt
	 */
	public String getAttachmentPointAmt() {
		return attachmentPointAmt;
	}
	/**
	 * @param attachmentPointAmt the attachmentPointAmt to set
	 */
	public void setAttachmentPointAmt(String attachmentPointAmt) {
		this.attachmentPointAmt = attachmentPointAmt;
	}
	/**
	 * @return the productBlocks
	 */
	public List<BlockComponentProductBO> getProductBlocks() {
		return productBlocks;
	}
	/**
	 * @param productBlocks the productBlocks to set
	 */
	public void setProductBlocks(List<BlockComponentProductBO> productBlocks) {
		this.productBlocks = productBlocks;
	}
	/**
	 * @return the alertBlockDetails
	 */
	
	/**
	 * @return the message
	 */
	public NGEViewOfMessageBO getMessage() {
		return message;
	}
	/**
	 * @param message the message to set
	 */
	public void setMessage(NGEViewOfMessageBO message) {
		this.message = message;
	}
	public List<AlertBlockDetailsBO> getAlertBlockDetails() {
		return alertBlockDetails;
	}
	public void setAlertBlockDetails(List<AlertBlockDetailsBO> alertBlockDetails) {
		this.alertBlockDetails = alertBlockDetails;
	}
    
}
