package com.aig.nge.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.aig.nge.bo.AlertServiceResponseBO;
import com.aig.nge.entities.TassetType;
import com.aig.nge.entities.TproductState;
import com.aig.nge.entities.TproductTower;
import com.aig.nge.entities.Tstatus;
import com.aig.nge.entities.TstatusCondition;
import com.aig.nge.entities.TstatusTransition;
import com.aig.nge.entities.Tsubmission;
import com.aig.nge.entities.TtuwSubProduct;
import com.aig.nge.repository.TCurrencyRepository;
import com.aig.nge.repository.TMarketableProductRepository;
import com.aig.nge.repository.TProductDspRepository;
import com.aig.nge.repository.TProductStateRepository;
import com.aig.nge.repository.TProductTowerRepository;
import com.aig.nge.repository.TStatusConditionRepository;
import com.aig.nge.repository.TStatusRepository;
import com.aig.nge.repository.TStatusTransitionRepository;
import com.aig.nge.repository.TSubmissionRepository;
import com.aig.nge.repository.TassetTypeRepository;
import com.aig.nge.repository.TproductMmcpRepository;
import com.aig.nge.repository.TproductTowerReasonRepository;
import com.aig.nge.repository.TtuwSubProductRepository;
import com.aig.nge.utilities.NGEConstants;

import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.LogManager;

	/**
	 * @author Ramakrishnas
	 * This DAO class is used for accessing the Product related repositories.
	 */

@Repository
public class ProductsDAO extends BaseDAO{
		//TCS CE Team Changes Starts Here
		private static final Logger logger = LogManager.getLogger(ProductsDAO.class);
		//TCS CE Team Changes Ends Here
	@Autowired
	private TProductTowerRepository tProductTowerRepository;
	
	@Autowired
	private TtuwSubProductRepository ttuwSubProductRepository;
	
	@Autowired
	private TCurrencyRepository tCurrencyRepository; 
	
	@Autowired
	private TStatusRepository tStatusRepository;
	
	@Autowired
	private TProductDspRepository tProductDspRepository;
	
	@Autowired
	private TproductMmcpRepository tProductMmcpRepository;
	
	@Autowired
	private TMarketableProductRepository tMarketableProductRepository;
	
	@Autowired
	private TassetTypeRepository tAssetTypeRepository;
	
	@Autowired
	private TProductStateRepository tProductStateRepository;
	
	@Autowired
	private TStatusConditionRepository tStatusConditionRepository;
	
	@Autowired
	private TStatusTransitionRepository tStatusTransitionRepository;
	
	@Autowired
	private TproductTowerReasonRepository tproductTowerReasonRepository;
	
	@Autowired
	private TSubmissionRepository tsubmissionRepository;
	/**
	 * @author Ramakrishnas
	 * This method is used to get the list of all product towers
	 */	
	public Set<TproductTower> getProductTowersDAO(){
		Set<TproductTower> productTowerList = tProductTowerRepository.getProductTowers();
		return productTowerList;
	}
	
	public Set<Object[]> getAllProductTowersSegSubSegDAO(){
		Set<Object[]> productTowerList = tProductTowerRepository.getAllProductTowersSegSubSeg();
		return productTowerList;
	}
	public Set<Object[]> getAllProductTowersIDNameDAO(){
		Set<Object[]> productTowerList = tProductTowerRepository.getAllProductTowersIDName();
		return productTowerList;
	}
	
	public Set<Object[]> getAllProductTowersDivisionDAO(){
		Set<Object[]> productTowerDivisonList = tProductTowerRepository.getAllProductTowersDivision();
		return productTowerDivisonList;
	}
	
	public Set<Object[]> getSubProductDivisionsDAO(){
		Set<Object[]> productTowerDivisonList = tProductTowerRepository.getSubProductDivisions();
		return productTowerDivisonList;
	}
	
	public Set<Object[]> getCmpntProductDivisionsDAO(){
		Set<Object[]> productTowerDivisonList = tProductTowerRepository.getCmpntProductDivisions();
		return productTowerDivisonList;
	}
	
	public Set<Object[]> getAllMarketableProductsDAO(){
		Set<Object[]> productTowerDivisonList = tProductTowerRepository.getAllMarketableProducts();
		return productTowerDivisonList;
	}
	
	public Set<Object[]> getAllSubProductsDAO(){
		Set<Object[]> productTowerDivisonList = tProductTowerRepository.getAllSubProducts();
		return productTowerDivisonList;
	}
	
	/**
	 * @author Ramakrishnas
	 * This method is used to get the list of all sub products
	 */	
	public Set<TtuwSubProduct> getSubProductsDAO(){
		Set<TtuwSubProduct> subProducts = ttuwSubProductRepository.getSubProducts();
		return subProducts;
	}
	
	/**
	 * @author Ramakrishnas
	 * This method is used to get the list of all currencies
	 */	
	
	public Set<Object[]> getCurrecnyListDAO(){
		Set<Object[]> currencyCodesList = tCurrencyRepository.getCurrencyList();
		return currencyCodesList;
	}
	
	public Set<Tstatus> getStatusNamesDAO(){
		Set<Tstatus> statusNamesList = tStatusRepository.getStatusNames();
		return statusNamesList;
	}
	
	public Set<Object[]> getDspCodesDAO(){
		//2019 Q1 release- Display DSP & MMCP in NGE
		Set<Object[]> dspCodes = tProductDspRepository.getDspCodes();
		return dspCodes;
	}
	public Set<Object[]> getDateFormat(){
		return tProductStateRepository.getDateFormat();
	}
	
	
	public Set<Object[]> getMmcpCodesDAO(){
		Set<Object[]> mmcpCodes = tProductMmcpRepository.getMmcpCodes();
		return mmcpCodes;
	}
	
	public Set<Object[]> getMarketableProductsDAO(){
		Set<Object[]> marketableProducts = tMarketableProductRepository.getAllMarketableProducts();
		return marketableProducts;
	}

	public Object[] getSegmentAndSubSegmentByProductTowerDAO(
			String productTowerCode) {

		Object[] segmentCodeBO = tProductTowerRepository.getSegmentCodeByProductTower(Short.valueOf(productTowerCode));
		return segmentCodeBO;
	}

	public Set<TassetType> getAssetTypesDAO() {
		Set<TassetType> assetTypes = tAssetTypeRepository.getAssetTypes();
		return assetTypes;
	}
	
	

	public Set<TproductState> getProductStatesDAO() {
		Set<TproductState> productStates = tProductStateRepository.getProductStates();
		return productStates;
	}

	public Set<TstatusCondition> getStatusConditionsDAO() {
		Set<TstatusCondition> statusConditions = tStatusConditionRepository.getStatusConditions();
		return statusConditions;
	}
	
	public Set<TstatusTransition> getStatusTransitionDAO(){
		Set<TstatusTransition> statusTransitions = tStatusTransitionRepository.getStatusTransition();
		return statusTransitions;
	}

	public Set<Object[]> getProductTowerReasonsDAO() {
		Set<Object[]> productTowerReasons = tproductTowerReasonRepository.getProductTowerReasons();
		return productTowerReasons;
	}
	
	public Tsubmission getSubmission(long submissionNo){
		Tsubmission submission = tsubmissionRepository.findOne(String.valueOf(submissionNo));
		return submission;
	}
	
	@Transactional(propagation=Propagation.REQUIRES_NEW)
	public List<AlertServiceResponseBO> getResultFromQuery(String query, Connection db2Connection,String callString) throws SQLException 
	{
		CallableStatement stmt = null;
		boolean isQuery = false;		
		String seDesc=null;
		ResultSet rs = null;
		AlertServiceResponseBO alertBlockDetails=null;
		List<AlertServiceResponseBO> alertServiceResponseList=new ArrayList<AlertServiceResponseBO>();
		try 
		{
			stmt = db2Connection.prepareCall(query); 	
			stmt.setString(1,callString);
			stmt.registerOutParameter(2,Types.INTEGER);
			isQuery = stmt.execute();
			if(isQuery){
				rs = stmt.getResultSet();

				if (rs != null) 
				{	
					while(rs.next()){

						if(rs.getString(5) != null){
							seDesc=	rs.getString(5).trim();
						}
						if(seDesc!=null){
							alertBlockDetails=new AlertServiceResponseBO();
							alertBlockDetails.setSeReasonCd(rs.getString(1));
							alertBlockDetails.setSeReasonDesc(rs.getString(2));
							alertBlockDetails.setSeReasonLongDesc(rs.getString(3));
							alertBlockDetails.setSeDetail(rs.getString(6));
							alertBlockDetails.setSaClassDesc(rs.getString(5));
							alertBlockDetails.setSubEvalCd(rs.getString(7));
							alertServiceResponseList.add(alertBlockDetails);

						}
					}
				}
			}

		} 
		catch (NumberFormatException e) {
			logger.debug("NGEUIException",e);
			e.printStackTrace();
			throw e;
		} 
		catch (SQLException e) {
			logger.debug("NGEUIException",e);
			e.printStackTrace();
			throw e;
		}
		finally{

			if(stmt!=null){
				try {
					stmt.close();
				} catch (SQLException e) {
					logger.debug("NGEUIException",e);
				}
				stmt=null;
			}
			if(rs!=null){
				try {
					rs.close();
				} catch (SQLException e) {
					logger.debug("NGEUIException",e);
				}
				rs=null;
			}
		}
		if(alertServiceResponseList.size() == 0){
			alertBlockDetails=new AlertServiceResponseBO();
			alertBlockDetails.setSeReasonDesc("This account has no alert factors associated with it.");
			alertBlockDetails.setSaClassDesc(" NO ALERT ");
			alertServiceResponseList.add(alertBlockDetails);
		}
		return alertServiceResponseList;
	}

}
