package com.aig.nge.bo;

import java.util.List;

public class CASLUserdataBO {
	private String userDataCategoryName;
	private List<CASLactionBO> action;
	public String getUserDataCategoryName() {
		return userDataCategoryName;
	}
	public void setUserDataCategoryName(String userDataCategoryName) {
		this.userDataCategoryName = userDataCategoryName;
	}
	public List<CASLactionBO> getAction() {
		return action;
	}
	public void setAction(List<CASLactionBO> action) {
		this.action = action;
	}
	
}
