package com.aig.nge.bo;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

public class SetProductStatusReqBO {

	@JsonInclude(JsonInclude.Include.ALWAYS)
    private TransactionRqBO transactionRq;
	@JsonInclude(JsonInclude.Include.ALWAYS)
    private List<ProductStatusBO> working;
	@JsonInclude(JsonInclude.Include.ALWAYS)
    private List<ProductStatusBO> quoteProducts;
	@JsonInclude(JsonInclude.Include.ALWAYS)
    private List<ProductStatusBO> bindProducts;
	@JsonInclude(JsonInclude.Include.ALWAYS)
    private List<ProductStatusBO> decline;
	@JsonInclude(JsonInclude.Include.ALWAYS)
    private List<ProductStatusBO> lost;
	@JsonInclude(JsonInclude.Include.ALWAYS)
    private List<ProductStatusBO> cancel;
	@JsonInclude(JsonInclude.Include.ALWAYS)
    private List<ProductStatusBO> _void;
	
	/**
	 * @return the transactionRq
	 */
	public TransactionRqBO getTransactionRq() {
		return transactionRq;
	}
	/**
	 * @param transactionRq the transactionRq to set
	 */
	public void setTransactionRq(TransactionRqBO transactionRq) {
		this.transactionRq = transactionRq;
	}
	/**
	 * @return the working
	 */
	public List<ProductStatusBO> getWorking() {
		return working;
	}
	/**
	 * @param working the working to set
	 */
	public void setWorking(List<ProductStatusBO> working) {
		this.working = working;
	}
	/**
	 * @return the quoteProducts
	 */
	public List<ProductStatusBO> getQuoteProducts() {
		return quoteProducts;
	}
	/**
	 * @param quoteProducts the quoteProducts to set
	 */
	public void setQuoteProducts(List<ProductStatusBO> quoteProducts) {
		this.quoteProducts = quoteProducts;
	}
	/**
	 * @return the bindProducts
	 */
	public List<ProductStatusBO> getBindProducts() {
		return bindProducts;
	}
	/**
	 * @param bindProducts the bindProducts to set
	 */
	public void setBindProducts(List<ProductStatusBO> bindProducts) {
		this.bindProducts = bindProducts;
	}
	/**
	 * @return the decline
	 */
	public List<ProductStatusBO> getDecline() {
		return decline;
	}
	/**
	 * @param decline the decline to set
	 */
	public void setDecline(List<ProductStatusBO> decline) {
		this.decline = decline;
	}
	/**
	 * @return the lost
	 */
	public List<ProductStatusBO> getLost() {
		return lost;
	}
	/**
	 * @param lost the lost to set
	 */
	public void setLost(List<ProductStatusBO> lost) {
		this.lost = lost;
	}
	/**
	 * @return the cancel
	 */
	public List<ProductStatusBO> getCancel() {
		return cancel;
	}
	/**
	 * @param cancel the cancel to set
	 */
	public void setCancel(List<ProductStatusBO> cancel) {
		this.cancel = cancel;
	}
	/**
	 * @return the _void
	 */
	public List<ProductStatusBO> get_void() {
		return _void;
	}
	/**
	 * @param _void the _void to set
	 */
	public void set_void(List<ProductStatusBO> _void) {
		this._void = _void;
	}
    
}
