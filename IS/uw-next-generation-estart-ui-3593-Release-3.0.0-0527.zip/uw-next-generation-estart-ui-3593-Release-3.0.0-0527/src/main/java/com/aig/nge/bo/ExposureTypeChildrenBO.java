package com.aig.nge.bo;

import java.util.Comparator;

public class ExposureTypeChildrenBO {
	private String id;
	private String text;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}
	public static Comparator<ExposureTypeChildrenBO> exposureTypeChildrenBOCompartor 
	= new Comparator<ExposureTypeChildrenBO>() {

		public int compare(ExposureTypeChildrenBO child1, ExposureTypeChildrenBO child2) {
			//ascending order
			return child1.getText().compareTo(child2.getText());
		}

	};
}
