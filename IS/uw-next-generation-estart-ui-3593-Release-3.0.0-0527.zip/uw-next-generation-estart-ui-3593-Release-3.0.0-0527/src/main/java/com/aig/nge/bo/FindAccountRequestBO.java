package com.aig.nge.bo;


public class FindAccountRequestBO {
    private SearchKeyBO searchKey;
    private String includeDuns;
    private String includeWorldBase;
    private String includeShells;
    private String maxRows;
    private String searchCountryCode;
    private String searchCountryName;
    private String searchStateCode;
    private String searchStateName;
    private String startTreePos;
    private String startDunsNo;
    private String startRowNo;
    private String searchDirection;
    private String returnCount;
    private String brokerId;
	/**
	 * @return the searchKey
	 */
	public SearchKeyBO getSearchKey() {
		return searchKey;
	}
	/**
	 * @param searchKey the searchKey to set
	 */
	public void setSearchKey(SearchKeyBO searchKey) {
		this.searchKey = searchKey;
	}
	/**
	 * @return the includeDuns
	 */
	public String getIncludeDuns() {
		return includeDuns;
	}
	/**
	 * @param includeDuns the includeDuns to set
	 */
	public void setIncludeDuns(String includeDuns) {
		this.includeDuns = includeDuns;
	}
	/**
	 * @return the includeWorldBase
	 */
	public String getIncludeWorldBase() {
		return includeWorldBase;
	}
	/**
	 * @param includeWorldBase the includeWorldBase to set
	 */
	public void setIncludeWorldBase(String includeWorldBase) {
		this.includeWorldBase = includeWorldBase;
	}
	/**
	 * @return the includeShells
	 */
	public String getIncludeShells() {
		return includeShells;
	}
	/**
	 * @param includeShells the includeShells to set
	 */
	public void setIncludeShells(String includeShells) {
		this.includeShells = includeShells;
	}
	/**
	 * @return the maxRows
	 */
	public String getMaxRows() {
		return maxRows;
	}
	/**
	 * @param maxRows the maxRows to set
	 */
	public void setMaxRows(String maxRows) {
		this.maxRows = maxRows;
	}
	/**
	 * @return the searchCountryCode
	 */
	public String getSearchCountryCode() {
		return searchCountryCode;
	}
	/**
	 * @param searchCountryCode the searchCountryCode to set
	 */
	public void setSearchCountryCode(String searchCountryCode) {
		this.searchCountryCode = searchCountryCode;
	}
	/**
	 * @return the searchCountryName
	 */
	public String getSearchCountryName() {
		return searchCountryName;
	}
	/**
	 * @param searchCountryName the searchCountryName to set
	 */
	public void setSearchCountryName(String searchCountryName) {
		this.searchCountryName = searchCountryName;
	}
	/**
	 * @return the searchStateCode
	 */
	public String getSearchStateCode() {
		return searchStateCode;
	}
	/**
	 * @param searchStateCode the searchStateCode to set
	 */
	public void setSearchStateCode(String searchStateCode) {
		this.searchStateCode = searchStateCode;
	}
	/**
	 * @return the searchStateName
	 */
	public String getSearchStateName() {
		return searchStateName;
	}
	/**
	 * @param searchStateName the searchStateName to set
	 */
	public void setSearchStateName(String searchStateName) {
		this.searchStateName = searchStateName;
	}
	/**
	 * @return the startTreePos
	 */
	public String getStartTreePos() {
		return startTreePos;
	}
	/**
	 * @param startTreePos the startTreePos to set
	 */
	public void setStartTreePos(String startTreePos) {
		this.startTreePos = startTreePos;
	}
	/**
	 * @return the startDunsNo
	 */
	public String getStartDunsNo() {
		return startDunsNo;
	}
	/**
	 * @param startDunsNo the startDunsNo to set
	 */
	public void setStartDunsNo(String startDunsNo) {
		this.startDunsNo = startDunsNo;
	}
	/**
	 * @return the startRowNo
	 */
	public String getStartRowNo() {
		return startRowNo;
	}
	/**
	 * @param startRowNo the startRowNo to set
	 */
	public void setStartRowNo(String startRowNo) {
		this.startRowNo = startRowNo;
	}
	/**
	 * @return the searchDirection
	 */
	public String getSearchDirection() {
		return searchDirection;
	}
	/**
	 * @param searchDirection the searchDirection to set
	 */
	public void setSearchDirection(String searchDirection) {
		this.searchDirection = searchDirection;
	}
	/**
	 * @return the returnCount
	 */
	public String getReturnCount() {
		return returnCount;
	}
	/**
	 * @param returnCount the returnCount to set
	 */
	public void setReturnCount(String returnCount) {
		this.returnCount = returnCount;
	}
	/**
	 * @return the brokerId
	 */
	public String getBrokerId() {
		return brokerId;
	}
	/**
	 * @param brokerId the brokerId to set
	 */
	public void setBrokerId(String brokerId) {
		this.brokerId = brokerId;
	}
}
