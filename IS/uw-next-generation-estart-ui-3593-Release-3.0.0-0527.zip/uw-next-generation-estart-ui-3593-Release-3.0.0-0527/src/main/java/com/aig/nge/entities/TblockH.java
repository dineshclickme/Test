package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the TBLOCK_HS database table.
 * 
 */
@Entity
@Table(name="TBLOCK_HS")
public class TblockH implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private TblockHPK id;

	@Column(name="BLOCK_TYPE_ID")
	private short blockTypeId;

	@Column(name="COMMENT_TX")
	private String commentTx;

	@Column(name="CREATE_TS")
	private Timestamp createTs;

	@Column(name="CREATE_USER_ID")
	private String createUserId;

	@Column(name="PARTY_ID")
	private int partyId;

	@Column(name="REASON_ID")
	private short reasonId;

	@Column(name="ROLE_ID")
	private short roleId;

	@Column(name="STATUS_ID")
	private short statusId;

	@Column(name="SYSTEM_ID")
	private short systemId;

	@Column(name="TRANSACTION_COMPONENT_ID")
	private String transactionComponentId;

	@Column(name="UPDATE_TS")
	private Timestamp updateTs;

	@Column(name="UPDATE_USER_ID")
	private String updateUserId;

    public TblockH() {
    }

	public TblockHPK getId() {
		return this.id;
	}

	public void setId(TblockHPK id) {
		this.id = id;
	}
	
	public short getBlockTypeId() {
		return this.blockTypeId;
	}

	public void setBlockTypeId(short blockTypeId) {
		this.blockTypeId = blockTypeId;
	}

	public String getCommentTx() {
		return this.commentTx;
	}

	public void setCommentTx(String commentTx) {
		this.commentTx = commentTx;
	}

	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public int getPartyId() {
		return this.partyId;
	}

	public void setPartyId(int partyId) {
		this.partyId = partyId;
	}

	public short getReasonId() {
		return this.reasonId;
	}

	public void setReasonId(short reasonId) {
		this.reasonId = reasonId;
	}

	public short getRoleId() {
		return this.roleId;
	}

	public void setRoleId(short roleId) {
		this.roleId = roleId;
	}

	public short getStatusId() {
		return this.statusId;
	}

	public void setStatusId(short statusId) {
		this.statusId = statusId;
	}

	public short getSystemId() {
		return this.systemId;
	}

	public void setSystemId(short systemId) {
		this.systemId = systemId;
	}

	public String getTransactionComponentId() {
		return this.transactionComponentId;
	}

	public void setTransactionComponentId(String transactionComponentId) {
		this.transactionComponentId = transactionComponentId;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

}