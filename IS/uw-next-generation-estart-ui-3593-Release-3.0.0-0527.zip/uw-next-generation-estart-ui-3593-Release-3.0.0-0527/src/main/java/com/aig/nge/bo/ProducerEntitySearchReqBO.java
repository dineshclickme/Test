package com.aig.nge.bo;

import com.fasterxml.jackson.annotation.JsonInclude;

public class ProducerEntitySearchReqBO {

	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String country;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String prodEntityName;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String prodEntityNumber;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String state;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String sourceCode;
	
	public String getSourceCode() {
		return sourceCode;
	}
	public void setSourceCode(String sourceCode) {
		this.sourceCode = sourceCode;
	}
	/**
	 * @return the country
	 */
	public String getCountry() {
		return country;
	}
	/**
	 * @param country the country to set
	 */
	public void setCountry(String country) {
		this.country = country;
	}
	/**
	 * @return the prodEntityName
	 */
	public String getProdEntityName() {
		return prodEntityName;
	}
	/**
	 * @param prodEntityName the prodEntityName to set
	 */
	public void setProdEntityName(String prodEntityName) {
		this.prodEntityName = prodEntityName;
	}
	/**
	 * @return the prodEntityNumber
	 */
	public String getProdEntityNumber() {
		return prodEntityNumber;
	}
	/**
	 * @param prodEntityNumber the prodEntityNumber to set
	 */
	public void setProdEntityNumber(String prodEntityNumber) {
		this.prodEntityNumber = prodEntityNumber;
	}
	/**
	 * @return the state
	 */
	public String getState() {
		return state;
	}
	/**
	 * @param state the state to set
	 */
	public void setState(String state) {
		this.state = state;
	} 
}
