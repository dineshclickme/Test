package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the TASSET_HS database table.
 * 
 */
@Entity
@Table(name="TASSET_HS")
public class TassetH implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private TassetHPK id;

	@Column(name="ASSET_DS")
	private String assetDs;

	@Column(name="ASSET_TYPE_ID")
	private int assetTypeId;

	@Column(name="CREATE_TS")
	private Timestamp createTs;

	@Column(name="CREATE_USER_ID")
	private String createUserId;

	@Column(name="SYSTEM_ID")
	private short systemId;

	@Column(name="UPDATE_TS")
	private Timestamp updateTs;

	@Column(name="UPDATE_USER_ID")
	private String updateUserId;

    public TassetH() {
    }

	public TassetHPK getId() {
		return this.id;
	}

	public void setId(TassetHPK id) {
		this.id = id;
	}
	
	public String getAssetDs() {
		return this.assetDs;
	}

	public void setAssetDs(String assetDs) {
		this.assetDs = assetDs;
	}

	public int getAssetTypeId() {
		return this.assetTypeId;
	}

	public void setAssetTypeId(int assetTypeId) {
		this.assetTypeId = assetTypeId;
	}

	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public short getSystemId() {
		return this.systemId;
	}

	public void setSystemId(short systemId) {
		this.systemId = systemId;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

}