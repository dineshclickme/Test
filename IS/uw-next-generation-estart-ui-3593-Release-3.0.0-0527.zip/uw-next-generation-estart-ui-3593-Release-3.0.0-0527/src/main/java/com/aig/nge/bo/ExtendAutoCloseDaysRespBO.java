package com.aig.nge.bo;

public class ExtendAutoCloseDaysRespBO {
	private String extensionsLeft;

	/**
	 * @return the extensionsLeft
	 */
	public String getExtensionsLeft() {
		return extensionsLeft;
	}

	/**
	 * @param extensionsLeft the extensionsLeft to set
	 */
	public void setExtensionsLeft(String extensionsLeft) {
		this.extensionsLeft = extensionsLeft;
	}
}
