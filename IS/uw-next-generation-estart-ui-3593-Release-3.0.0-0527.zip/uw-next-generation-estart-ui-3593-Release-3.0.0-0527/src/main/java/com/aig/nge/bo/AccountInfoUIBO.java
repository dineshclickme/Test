package com.aig.nge.bo;

public class AccountInfoUIBO {

	private AccountDetails accountdetails;
	private AccountAddtlInfoBO moreinformationaccount;
	private AccContactDetBO contactdetailsaccount;

	/**
	 * @return the moreinformationaccount
	 */
	public AccountAddtlInfoBO getMoreinformationaccount() {
		return moreinformationaccount;
	}

	/**
	 * @param moreinformationaccount the moreinformationaccount to set
	 */
	public void setMoreinformationaccount(AccountAddtlInfoBO moreinformationaccount) {
		this.moreinformationaccount = moreinformationaccount;
	}

	/**
	 * @return the contactdetailsaccount
	 */
	public AccContactDetBO getContactdetailsaccount() {
		return contactdetailsaccount;
	}

	/**
	 * @param contactdetailsaccount the contactdetailsaccount to set
	 */
	public void setContactdetailsaccount(AccContactDetBO contactdetailsaccount) {
		this.contactdetailsaccount = contactdetailsaccount;
	}

	/**
	 * @return the accountdetails
	 */
	public AccountDetails getAccountdetails() {
		return accountdetails;
	}

	/**
	 * @param accountdetails the accountdetails to set
	 */
	public void setAccountdetails(AccountDetails accountdetails) {
		this.accountdetails = accountdetails;
	}
}
