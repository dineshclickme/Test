package com.aig.nge.bo;

import java.util.List;

public class BindProductsRqBO {
    private String segmentCd;
    private String subSegmentCd;
    private String marketableProductCd;
    private String componentProductCd;
    private String componentProductTabKey;
   	private String productTabkey;
    private String attachementPointAmt;
   	
    
    private String divisionNo;
    private AdditionalInsuredsBO additionalInsuredsRq;
    private List<BranchBO> branches;
    private String sectionCd;
    private String profitUnitCd;
    private String majorLineCd;
    private String minorLineCd;
    private String classPerilCd;
    private String majorClassCd;
    private String effectiveDt;
    private String expirationDt;
    private List<AssetBO> assets;
    private List<AttributesInfoBO> attributes;
    private List<AttributesInfoBO> statusAttributes;
    private List<PolicyDetailBO> policies;
    private LimitBO limit;
    private String transactionId;
    private String transactionVersionNo;
    
    private String ComponentProductSegmentCd;
    private String ComponentProductSubSegmentCd;
    private String transactionComponentId;
    
    private String componentProductTowerCd;
    private String productTowerCd;
	
   
	public String getTransactionComponentId() {
		return transactionComponentId;
	}
	public void setTransactionComponentId(String transactionComponentId) {
		this.transactionComponentId = transactionComponentId;
	}
	/**
	 * @return the segmentCd
	 */
	public String getSegmentCd() {
		return segmentCd;
	}
	/**
	 * @param segmentCd the segmentCd to set
	 */
	public void setSegmentCd(String segmentCd) {
		this.segmentCd = segmentCd;
	}
	/**
	 * @return the subSegmentCd
	 */
	public String getSubSegmentCd() {
		return subSegmentCd;
	}
	/**
	 * @param subSegmentCd the subSegmentCd to set
	 */
	public void setSubSegmentCd(String subSegmentCd) {
		this.subSegmentCd = subSegmentCd;
	}
	/**
	 * @return the marketableProductCd
	 */
	public String getMarketableProductCd() {
		return marketableProductCd;
	}
	/**
	 * @param marketableProductCd the marketableProductCd to set
	 */
	public void setMarketableProductCd(String marketableProductCd) {
		this.marketableProductCd = marketableProductCd;
	}
	/**
	 * @return the componentProductCd
	 */
	public String getComponentProductCd() {
		return componentProductCd;
	}
	/**
	 * @param componentProductCd the componentProductCd to set
	 */
	public void setComponentProductCd(String componentProductCd) {
		this.componentProductCd = componentProductCd;
	}
	/**
	 * @return the divisionNo
	 */
	public String getDivisionNo() {
		return divisionNo;
	}
	/**
	 * @param divisionNo the divisionNo to set
	 */
	public void setDivisionNo(String divisionNo) {
		this.divisionNo = divisionNo;
	}
	
	/**
	 * @return the additionalInsuredsRq
	 */
	public AdditionalInsuredsBO getAdditionalInsuredsRq() {
		return additionalInsuredsRq;
	}
	/**
	 * @param additionalInsuredsRq the additionalInsuredsRq to set
	 */
	public void setAdditionalInsuredsRq(AdditionalInsuredsBO additionalInsuredsRq) {
		this.additionalInsuredsRq = additionalInsuredsRq;
	}
	/**
	 * @return the branches
	 */
	public List<BranchBO> getBranches() {
		return branches;
	}
	/**
	 * @param branches the branches to set
	 */
	public void setBranches(List<BranchBO> branches) {
		this.branches = branches;
	}
	/**
	 * @return the sectionCd
	 */
	public String getSectionCd() {
		return sectionCd;
	}
	/**
	 * @param sectionCd the sectionCd to set
	 */
	public void setSectionCd(String sectionCd) {
		this.sectionCd = sectionCd;
	}
	/**
	 * @return the profitUnitCd
	 */
	public String getProfitUnitCd() {
		return profitUnitCd;
	}
	/**
	 * @param profitUnitCd the profitUnitCd to set
	 */
	public void setProfitUnitCd(String profitUnitCd) {
		this.profitUnitCd = profitUnitCd;
	}
	/**
	 * @return the majorLineCd
	 */
	public String getMajorLineCd() {
		return majorLineCd;
	}
	/**
	 * @param majorLineCd the majorLineCd to set
	 */
	public void setMajorLineCd(String majorLineCd) {
		this.majorLineCd = majorLineCd;
	}
	/**
	 * @return the minorLineCd
	 */
	public String getMinorLineCd() {
		return minorLineCd;
	}
	/**
	 * @param minorLineCd the minorLineCd to set
	 */
	public void setMinorLineCd(String minorLineCd) {
		this.minorLineCd = minorLineCd;
	}
	/**
	 * @return the classPerilCd
	 */
	public String getClassPerilCd() {
		return classPerilCd;
	}
	/**
	 * @param classPerilCd the classPerilCd to set
	 */
	public void setClassPerilCd(String classPerilCd) {
		this.classPerilCd = classPerilCd;
	}
	/**
	 * @return the majorClassCd
	 */
	public String getMajorClassCd() {
		return majorClassCd;
	}
	/**
	 * @param majorClassCd the majorClassCd to set
	 */
	public void setMajorClassCd(String majorClassCd) {
		this.majorClassCd = majorClassCd;
	}
	/**
	 * @return the effectiveDt
	 */
	public String getEffectiveDt() {
		return effectiveDt;
	}
	/**
	 * @param effectiveDt the effectiveDt to set
	 */
	public void setEffectiveDt(String effectiveDt) {
		this.effectiveDt = effectiveDt;
	}
	/**
	 * @return the expirationDt
	 */
	public String getExpirationDt() {
		return expirationDt;
	}
	/**
	 * @param expirationDt the expirationDt to set
	 */
	public void setExpirationDt(String expirationDt) {
		this.expirationDt = expirationDt;
	}
	/**
	 * @return the assets
	 */
	public List<AssetBO> getAssets() {
		return assets;
	}
	/**
	 * @param assets the assets to set
	 */
	public void setAssets(List<AssetBO> assets) {
		this.assets = assets;
	}
	/**
	 * @return the attributes
	 */
	public List<AttributesInfoBO> getAttributes() {
		return attributes;
	}
	/**
	 * @param attributes the attributes to set
	 */
	public void setAttributes(List<AttributesInfoBO> attributes) {
		this.attributes = attributes;
	}
	/**
	 * @return the statusAttributes
	 */
	public List<AttributesInfoBO> getStatusAttributes() {
		return statusAttributes;
	}
	/**
	 * @param statusAttributes the statusAttributes to set
	 */
	public void setStatusAttributes(List<AttributesInfoBO> statusAttributes) {
		this.statusAttributes = statusAttributes;
	}
	/**
	 * @return the policies
	 */
	public List<PolicyDetailBO> getPolicies() {
		return policies;
	}
	/**
	 * @param policies the policies to set
	 */
	public void setPolicies(List<PolicyDetailBO> policies) {
		this.policies = policies;
	}
	/**
	 * @return the limit
	 */
	public LimitBO getLimit() {
		return limit;
	}
	/**
	 * @param limit the limit to set
	 */
	public void setLimit(LimitBO limit) {
		this.limit = limit;
	}
	public String getComponentProductTabKey() {
		return componentProductTabKey;
	}
	public void setComponentProductTabKey(String componentProductTabKey) {
		this.componentProductTabKey = componentProductTabKey;
	}
	public String getProductTabkey() {
		return productTabkey;
	}
	public void setProductTabkey(String productTabkey) {
		this.productTabkey = productTabkey;
	}
	public String getAttachementPointAmt() {
		return attachementPointAmt;
	}
	public void setAttachementPointAmt(String attachementPointAmt) {
		this.attachementPointAmt = attachementPointAmt;
	}
	public String getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	public String getTransactionVersionNo() {
		return transactionVersionNo;
	}
	public void setTransactionVersionNo(String transactionVersionNo) {
		this.transactionVersionNo = transactionVersionNo;
	}
	public String getComponentProductSegmentCd() {
		return ComponentProductSegmentCd;
	}
	public void setComponentProductSegmentCd(String componentProductSegmentCd) {
		ComponentProductSegmentCd = componentProductSegmentCd;
	}
	public String getComponentProductSubSegmentCd() {
		return ComponentProductSubSegmentCd;
	}
	public void setComponentProductSubSegmentCd(String componentProductSubSegmentCd) {
		ComponentProductSubSegmentCd = componentProductSubSegmentCd;
	}
	public String getComponentProductTowerCd() {
		return componentProductTowerCd;
	}
	public void setComponentProductTowerCd(String componentProductTowerCd) {
		this.componentProductTowerCd = componentProductTowerCd;
	}
	public String getProductTowerCd() {
		return productTowerCd;
	}
	public void setProductTowerCd(String productTowerCd) {
		this.productTowerCd = productTowerCd;
	}
    
}
