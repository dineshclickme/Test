package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-02-19T16:13:03.155+0530")
@StaticMetamodel(TcomponentBlock.class)
public class TcomponentBlock_ {
	public static volatile SingularAttribute<TcomponentBlock, Integer> blockNo;
	public static volatile SingularAttribute<TcomponentBlock, Timestamp> createTs;
	public static volatile SingularAttribute<TcomponentBlock, String> createUserId;
	public static volatile SingularAttribute<TcomponentBlock, Short> systemId;
	public static volatile SingularAttribute<TcomponentBlock, Timestamp> updateTs;
	public static volatile SingularAttribute<TcomponentBlock, String> updateUserId;
	public static volatile SingularAttribute<TcomponentBlock, Tblock> tblock;
	public static volatile SingularAttribute<TcomponentBlock, TtransactionComponent> ttransactionComponent;
}
