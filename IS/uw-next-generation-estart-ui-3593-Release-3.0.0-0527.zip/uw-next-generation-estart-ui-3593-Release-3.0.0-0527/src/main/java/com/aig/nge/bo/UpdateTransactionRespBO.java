package com.aig.nge.bo;

import java.util.List;


public class UpdateTransactionRespBO {
    private NGEViewOfMessageBO message;
    private List<BlockComponentProductBO> productBlocks;
    private List<AlertBlockDetailsBO> alertBlockDetails;
    private LicenseBO licenseDetails;
    private String transactionId;
    private String versionId;
    private List<ProductBO> addProducts;
    private List<ProductBO> updateProducts;
    private List<ProductBO> removeProducts;
    private List<MessageDetailsBO> serviceMessages;
    private List<String> exceptionMessage;
    private List<ProductBO> updateProductStatus;
    private List<ProductBO> reopenProduct;
    private List<ProductBO> unbindProduct;
    protected String statuscode;
    protected String statuscategory;
    protected String statusMessage;
    
	/**
	 * @return the serviceMessages
	 */
	public List<MessageDetailsBO> getServiceMessages() {
		return serviceMessages;
	}
	/**
	 * @param serviceMessages the serviceMessages to set
	 */
	public void setServiceMessages(List<MessageDetailsBO> serviceMessages) {
		this.serviceMessages = serviceMessages;
	}
	/**
	 * @return the addProducts
	 */
	public List<ProductBO> getAddProducts() {
		return addProducts;
	}
	/**
	 * @param addProducts the addProducts to set
	 */
	public void setAddProducts(List<ProductBO> addProducts) {
		this.addProducts = addProducts;
	}
	/**
	 * @return the updateProducts
	 */
	public List<ProductBO> getUpdateProducts() {
		return updateProducts;
	}
	/**
	 * @param updateProducts the updateProducts to set
	 */
	public void setUpdateProducts(List<ProductBO> updateProducts) {
		this.updateProducts = updateProducts;
	}
	/**
	 * @return the removeProducts
	 */
	public List<ProductBO> getRemoveProducts() {
		return removeProducts;
	}
	/**
	 * @param removeProducts the removeProducts to set
	 */
	public void setRemoveProducts(List<ProductBO> removeProducts) {
		this.removeProducts = removeProducts;
	}
	/**
	 * @return the transactionId
	 */
	public String getTransactionId() {
		return transactionId;
	}
	/**
	 * @param transactionId the transactionId to set
	 */
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	/**
	 * @return the message
	 */
	public NGEViewOfMessageBO getMessage() {
		return message;
	}
	/**
	 * @param message the message to set
	 */
	public void setMessage(NGEViewOfMessageBO message) {
		this.message = message;
	}
	/**
	 * @return the productBlocks
	 */
	public List<BlockComponentProductBO> getProductBlocks() {
		return productBlocks;
	}
	/**
	 * @param productBlocks the productBlocks to set
	 */
	public void setProductBlocks(List<BlockComponentProductBO> productBlocks) {
		this.productBlocks = productBlocks;
	}
	/**
	 * @return the alertBlockDetails
	 */
	
	/**
	 * @return the licenseDetails
	 */
	public LicenseBO getLicenseDetails() {
		return licenseDetails;
	}
	/**
	 * @param licenseDetails the licenseDetails to set
	 */
	public void setLicenseDetails(LicenseBO licenseDetails) {
		this.licenseDetails = licenseDetails;
	}
	public List<ProductBO> getUpdateProductStatus() {
		return updateProductStatus;
	}
	public void setUpdateProductStatus(List<ProductBO> updateProductStatus) {
		this.updateProductStatus = updateProductStatus;
	}
	public List<ProductBO> getReopenProduct() {
		return reopenProduct;
	}
	public void setReopenProduct(List<ProductBO> reopenProduct) {
		this.reopenProduct = reopenProduct;
	}
	public List<ProductBO> getUnbindProduct() {
		return unbindProduct;
	}
	public void setUnbindProduct(List<ProductBO> unbindProduct) {
		this.unbindProduct = unbindProduct;
	}
	public String getStatuscode() {
		return statuscode;
	}
	public void setStatuscode(String statuscode) {
		this.statuscode = statuscode;
	}
	public String getStatuscategory() {
		return statuscategory;
	}
	public void setStatuscategory(String statuscategory) {
		this.statuscategory = statuscategory;
	}
	public String getStatusMessage() {
		return statusMessage;
	}
	public void setStatusMessage(String statusMessage) {
		this.statusMessage = statusMessage;
	}
	public String getVersionId() {
		return versionId;
	}
	public void setVersionId(String versionId) {
		this.versionId = versionId;
	}
	public List<AlertBlockDetailsBO> getAlertBlockDetails() {
		return alertBlockDetails;
	}
	public void setAlertBlockDetails(List<AlertBlockDetailsBO> alertBlockDetails) {
		this.alertBlockDetails = alertBlockDetails;
	}
	public List<String> getExceptionMessage() {
		return exceptionMessage;
	}
	public void setExceptionMessage(List<String> exceptionMessage) {
		this.exceptionMessage = exceptionMessage;
	}
    
}
