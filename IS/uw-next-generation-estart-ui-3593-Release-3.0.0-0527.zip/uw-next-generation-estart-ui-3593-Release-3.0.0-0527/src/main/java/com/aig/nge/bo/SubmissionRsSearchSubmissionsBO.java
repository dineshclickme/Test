package com.aig.nge.bo;

public class SubmissionRsSearchSubmissionsBO {
	
	private String submissionNo;
	private String creationTs;
	private String accountNo;
	private String accountNm;
	private String producerNm;
	private String mdmPartyId;//2021 MDM
	
	public String getSubmissionNo() {
		return submissionNo;
	}
	public void setSubmissionNo(String submissionNo) {
		this.submissionNo = submissionNo;
	}
	public String getCreationTs() {
		return creationTs;
	}
	public void setCreationTs(String creationTs) {
		this.creationTs = creationTs;
	}
	public String getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}
	public String getAccountNm() {
		return accountNm;
	}
	public void setAccountNm(String accountNm) {
		this.accountNm = accountNm;
	}
	public String getProducerNm() {
		return producerNm;
	}
	public void setProducerNm(String producerNm) {
		this.producerNm = producerNm;
	}
	public String getMdmPartyId() {
		return mdmPartyId;
	}
	public void setMdmPartyId(String mdmPartyId) {
		this.mdmPartyId = mdmPartyId;
	}
}
