package com.aig.nge.bo;


public class NGEViewOfMessageBO {
	
	    private String messageCode;
	    private MsgResponseBO response;
		/**
		 * @return the messageCode
		 */
		public String getMessageCode() {
			return messageCode;
		}
		/**
		 * @param messageCode the messageCode to set
		 */
		public void setMessageCode(String messageCode) {
			this.messageCode = messageCode;
		}
		/**
		 * @return the response
		 */
		public MsgResponseBO getResponse() {
			return response;
		}
		/**
		 * @param response the response to set
		 */
		public void setResponse(MsgResponseBO response) {
			this.response = response;
		}
	    
}
