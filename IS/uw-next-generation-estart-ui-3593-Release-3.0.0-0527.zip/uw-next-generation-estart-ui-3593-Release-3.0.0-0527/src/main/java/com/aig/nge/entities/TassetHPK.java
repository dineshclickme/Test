package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the TASSET_HS database table.
 * 
 */
@Embeddable
public class TassetHPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="ASSET_ID")
	private int assetId;

    @Temporal( TemporalType.TIMESTAMP)
	@Column(name="CREATE_HISTORY_TS")
	private java.util.Date createHistoryTs;

    public TassetHPK() {
    }
	public int getAssetId() {
		return this.assetId;
	}
	public void setAssetId(int assetId) {
		this.assetId = assetId;
	}
	public java.util.Date getCreateHistoryTs() {
		return this.createHistoryTs;
	}
	public void setCreateHistoryTs(java.util.Date createHistoryTs) {
		this.createHistoryTs = createHistoryTs;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof TassetHPK)) {
			return false;
		}
		TassetHPK castOther = (TassetHPK)other;
		return 
			(this.assetId == castOther.assetId)
			&& this.createHistoryTs.equals(castOther.createHistoryTs);

    }
    
	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.assetId;
		hash = hash * prime + this.createHistoryTs.hashCode();
		
		return hash;
    }
}