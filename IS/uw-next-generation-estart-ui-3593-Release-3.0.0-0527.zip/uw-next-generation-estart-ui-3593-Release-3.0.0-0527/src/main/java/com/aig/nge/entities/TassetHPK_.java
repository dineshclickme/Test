package com.aig.nge.entities;

import java.util.Date;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-03-02T12:10:24.675+0530")
@StaticMetamodel(TassetHPK.class)
public class TassetHPK_ {
	public static volatile SingularAttribute<TassetHPK, Integer> assetId;
	public static volatile SingularAttribute<TassetHPK, Date> createHistoryTs;
}
