package com.aig.nge.bo;

import java.util.List;

public class AgentInfoBO {

	private String agentEmailAddr;
	private String agentFirstNm;
	private String agentId;
	private String agentLastNm;
	private List<LicenseTypeBO> agentLicense;
	private String agentMiddleNm;
	private String agentStatusCd;
	/**
	 * @return the agentEmailAddr
	 */
	public String getAgentEmailAddr() {
		return agentEmailAddr;
	}
	/**
	 * @param agentEmailAddr the agentEmailAddr to set
	 */
	public void setAgentEmailAddr(String agentEmailAddr) {
		this.agentEmailAddr = agentEmailAddr;
	}
	/**
	 * @return the agentFirstNm
	 */
	public String getAgentFirstNm() {
		return agentFirstNm;
	}
	/**
	 * @param agentFirstNm the agentFirstNm to set
	 */
	public void setAgentFirstNm(String agentFirstNm) {
		this.agentFirstNm = agentFirstNm;
	}
	/**
	 * @return the agentId
	 */
	public String getAgentId() {
		return agentId;
	}
	/**
	 * @param agentId the agentId to set
	 */
	public void setAgentId(String agentId) {
		this.agentId = agentId;
	}
	/**
	 * @return the agentLastNm
	 */
	public String getAgentLastNm() {
		return agentLastNm;
	}
	/**
	 * @param agentLastNm the agentLastNm to set
	 */
	public void setAgentLastNm(String agentLastNm) {
		this.agentLastNm = agentLastNm;
	}
	/**
	 * @return the agentLicense
	 */
	public List<LicenseTypeBO> getAgentLicense() {
		return agentLicense;
	}
	/**
	 * @param agentLicense the agentLicense to set
	 */
	public void setAgentLicense(List<LicenseTypeBO> agentLicense) {
		this.agentLicense = agentLicense;
	}
	/**
	 * @return the agentMiddleNm
	 */
	public String getAgentMiddleNm() {
		return agentMiddleNm;
	}
	/**
	 * @param agentMiddleNm the agentMiddleNm to set
	 */
	public void setAgentMiddleNm(String agentMiddleNm) {
		this.agentMiddleNm = agentMiddleNm;
	}
	/**
	 * @return the agentStatusCd
	 */
	public String getAgentStatusCd() {
		return agentStatusCd;
	}
	/**
	 * @param agentStatusCd the agentStatusCd to set
	 */
	public void setAgentStatusCd(String agentStatusCd) {
		this.agentStatusCd = agentStatusCd;
	}	
}
