package com.aig.nge.dao;

import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.aig.nge.entities.TreasonType;
import com.aig.nge.repository.TReasonTypeRepository;

@Repository
public class ReasonDAO {
	
	@Autowired
	private TReasonTypeRepository tReasonTypeRepository;
	
	public Set<TreasonType> getReasonTypesDAO(){
		Set<TreasonType> reasonTypes = null;
		reasonTypes = tReasonTypeRepository.getResonType();
		return reasonTypes;
	}
}
