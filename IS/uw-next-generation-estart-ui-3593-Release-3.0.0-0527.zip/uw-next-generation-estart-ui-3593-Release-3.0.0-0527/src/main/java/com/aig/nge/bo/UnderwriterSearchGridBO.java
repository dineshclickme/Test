package com.aig.nge.bo;

import java.util.List;

public class UnderwriterSearchGridBO {
	private String records;
	private String page;
	private String total;
	private List<UnderwriterSearchResBO> rows;
	/**
	 * @return the records
	 */
	public String getRecords() {
		return records;
	}
	/**
	 * @param records the records to set
	 */
	public void setRecords(String records) {
		this.records = records;
	}
	/**
	 * @return the page
	 */
	public String getPage() {
		return page;
	}
	/**
	 * @param page the page to set
	 */
	public void setPage(String page) {
		this.page = page;
	}
	/**
	 * @return the total
	 */
	public String getTotal() {
		return total;
	}
	/**
	 * @param total the total to set
	 */
	public void setTotal(String total) {
		this.total = total;
	}
	/**
	 * @return the rows
	 */
	public List<UnderwriterSearchResBO> getRows() {
		return rows;
	}
	/**
	 * @param rows the rows to set
	 */
	public void setRows(List<UnderwriterSearchResBO> rows) {
		this.rows = rows;
	}
	
}
