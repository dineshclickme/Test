package com.aig.nge.dao;

import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.aig.nge.entities.TscreenField;
import com.aig.nge.repository.TErrorLanguageRepository;
import com.aig.nge.repository.TScreenFieldRepository;

@Repository
public class ScreenFieldDAO extends BaseDAO{
	
	@Autowired
	private TScreenFieldRepository tScreenFieldRepository;
	
	@Autowired
	private TErrorLanguageRepository tErrorLanguageRepository;
	
	public Set<TscreenField> getScreenFieldsDAO(){
		Set<TscreenField> screenFields = tScreenFieldRepository.getScreenFields();
		return screenFields;
	}
	
	public List<Object[]> getScreenFieldsDAO(String screenLanguage){
		List<Object[]> screenFields = tScreenFieldRepository.getScreenFields(screenLanguage);
		return screenFields;
	}
	
	public List<Object[]> getErrorFieldsDAO(String screenLanguage,String systemShortName){
		screenLanguage="en-US";
		List<Object[]> errorFields = tErrorLanguageRepository.getScreenFields(screenLanguage,systemShortName);
		return errorFields;
	}
}
