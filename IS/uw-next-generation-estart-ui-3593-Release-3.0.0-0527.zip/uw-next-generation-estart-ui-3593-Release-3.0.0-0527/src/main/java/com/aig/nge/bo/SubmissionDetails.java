package com.aig.nge.bo;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class SubmissionDetails {
	
	@JsonProperty("submissionNo")
	private String submissionNo;
	@JsonProperty("transactionId")
	private String transactionId;
	@JsonProperty("version")
	private String version;
	@JsonProperty("componentProductName")
	private String componentProductName;
	@JsonProperty("marketableProductName")
	private String marketableProductName;
	@JsonProperty("lifeCycleStatus")
	private String lifeCycleStatus;
	@JsonProperty("lifeCycleStatusTimeStamp")
	private String lifeCycleStatusTimeStamp;
	@JsonProperty("reservationStatus")
	private String reservationStatus;
	@JsonProperty("divisionName")
	private String divisionName;
	@JsonProperty("creditedBranchName")
	private String creditedBranchName;
	@JsonProperty("underWriteName")
	private String underWriteName;	
	@JsonProperty("segmentName")
	private String segmentName;
	@JsonProperty("subSegmentName")
	private String subSegmentName;
	
	public String getSubmissionNo() {
		return submissionNo;
	}
	public void setSubmissionNo(String submissionNo) {
		this.submissionNo = submissionNo;
	}
	public String getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	public String getVersion() {
		return version;
	}
	public void setVersion(String version) {
		this.version = version;
	}
	public String getComponentProductName() {
		return componentProductName;
	}
	public void setComponentProductName(String componentProductName) {
		this.componentProductName = componentProductName;
	}
	public String getMarketableProductName() {
		return marketableProductName;
	}
	public void setMarketableProductName(String marketableProductName) {
		this.marketableProductName = marketableProductName;
	}
	public String getLifeCycleStatus() {
		return lifeCycleStatus;
	}
	public void setLifeCycleStatus(String lifeCycleStatus) {
		this.lifeCycleStatus = lifeCycleStatus;
	}
	public String getLifeCycleStatusTimeStamp() {
		return lifeCycleStatusTimeStamp;
	}
	public void setLifeCycleStatusTimeStamp(String lifeCycleStatusTimeStamp) {
		this.lifeCycleStatusTimeStamp = lifeCycleStatusTimeStamp;
	}
	public String getReservationStatus() {
		return reservationStatus;
	}
	public void setReservationStatus(String reservationStatus) {
		this.reservationStatus = reservationStatus;
	}
	public String getDivisionName() {
		return divisionName;
	}
	public void setDivisionName(String divisionName) {
		this.divisionName = divisionName;
	}
	public String getCreditedBranchName() {
		return creditedBranchName;
	}
	public void setCreditedBranchName(String creditedBranchName) {
		this.creditedBranchName = creditedBranchName;
	}
	public String getSegmentName() {
		return segmentName;
	}
	public void setSegmentName(String segmentName) {
		this.segmentName = segmentName;
	}
	public String getSubSegmentName() {
		return subSegmentName;
	}
	public void setSubSegmentName(String subSegmentName) {
		this.subSegmentName = subSegmentName;
	}
	public String getUnderWriteName() {
		return underWriteName;
	}
	public void setUnderWriteName(String underWriteName) {
		this.underWriteName = underWriteName;
	}
	
	
}
