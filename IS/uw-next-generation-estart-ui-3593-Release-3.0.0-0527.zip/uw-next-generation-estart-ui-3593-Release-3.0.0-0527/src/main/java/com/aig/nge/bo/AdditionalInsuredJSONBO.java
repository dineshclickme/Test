package com.aig.nge.bo;

import java.util.List;

public class AdditionalInsuredJSONBO {
	
	private String dataKey;
	private String transaction;
	private String version;
	private String productId;
	private String mktProduct;
	private String subProduct;
	private String component;
	private String componentCd;
	private String processingIndDs;
	private List<AdditionalInsuredBO> data;
	private String productTabKey;
	private String componentProductTabKey;
	public String getDataKey() {
		return dataKey;
	}
	public void setDataKey(String dataKey) {
		this.dataKey = dataKey;
	}
	public String getTransaction() {
		return transaction;
	}
	public void setTransaction(String transaction) {
		this.transaction = transaction;
	}
	public String getVersion() {
		return version;
	}
	public void setVersion(String version) {
		this.version = version;
	}
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getMktProduct() {
		return mktProduct;
	}
	public void setMktProduct(String mktProduct) {
		this.mktProduct = mktProduct;
	}
	public String getSubProduct() {
		return subProduct;
	}
	public void setSubProduct(String subProduct) {
		this.subProduct = subProduct;
	}
	public String getComponent() {
		return component;
	}
	public void setComponent(String component) {
		this.component = component;
	}
	public String getComponentCd() {
		return componentCd;
	}
	public void setComponentCd(String componentCd) {
		this.componentCd = componentCd;
	}
	public List<AdditionalInsuredBO> getData() {
		return data;
	}
	public void setData(List<AdditionalInsuredBO> data) {
		this.data = data;
	}
	public String getProcessingIndDs() {
		return processingIndDs;
	}
	public void setProcessingIndDs(String processingIndDs) {
		this.processingIndDs = processingIndDs;
	}
	public String getProductTabKey() {
		return productTabKey;
	}
	public void setProductTabKey(String productTabKey) {
		this.productTabKey = productTabKey;
	}
	public String getComponentProductTabKey() {
		return componentProductTabKey;
	}
	public void setComponentProductTabKey(String componentProductTabKey) {
		this.componentProductTabKey = componentProductTabKey;
	}
}
