package com.aig.nge.bo;

import java.util.List;

public class GetBlockingInfoResBO {

    private ProductBO blockedComponentProduct;
    private LimitBO limit;
    private List<BlockComponentProductBO> blockingProductsDetail;
    private List<AlertBlockDetailsBO> alertBlockDetails;
    private String emailiconproductBlock  ;
   	private String emailiconalertBlock ;
   	
   	private List<AlertBlockDetailsBO> blockingAlertList;
   	private List<AlertBlockDetailsBO> releasedAlertList;
   	
    public List<AlertBlockDetailsBO> getAlertBlockDetails() {
		return alertBlockDetails;
	}
	public void setAlertBlockDetails(List<AlertBlockDetailsBO> alertBlockDetails) {
		this.alertBlockDetails = alertBlockDetails;
	}
	private GetBlockedInfoRows blocking;
    private GetBlockedInfoRows released;
   	public GetBlockedInfoRows getReleased() {
		return released;
	}
	public void setReleased(GetBlockedInfoRows released) {
		this.released = released;
	}
	public GetBlockedInfoRows getBlocking() {
   		return blocking;
   	}
   	public void setBlocking(GetBlockedInfoRows blocking) {
   		this.blocking = blocking;
   	}
	/**
	 * @return the blockedComponentProduct
	 */
	public ProductBO getBlockedComponentProduct() {
		return blockedComponentProduct;
	}
	/**
	 * @param blockedComponentProduct the blockedComponentProduct to set
	 */
	public void setBlockedComponentProduct(ProductBO blockedComponentProduct) {
		this.blockedComponentProduct = blockedComponentProduct;
	}
	/**
	 * @return the limit
	 */
	public LimitBO getLimit() {
		return limit;
	}
	/**
	 * @param limit the limit to set
	 */
	public void setLimit(LimitBO limit) {
		this.limit = limit;
	}
	/**
	 * @return the blockingProductsDetail
	 */
	public List<BlockComponentProductBO> getBlockingProductsDetail() {
		return blockingProductsDetail;
	}
	/**
	 * @param blockingProductsDetail the blockingProductsDetail to set
	 */
	public void setBlockingProductsDetail(
			List<BlockComponentProductBO> blockingProductsDetail) {
		this.blockingProductsDetail = blockingProductsDetail;
	}
	
	public String getEmailiconproductBlock() {
		return emailiconproductBlock;
	}
	public void setEmailiconproductBlock(String emailiconproductBlock) {
		this.emailiconproductBlock = emailiconproductBlock;
	}
	public String getEmailiconalertBlock() {
		return emailiconalertBlock;
	}
	public void setEmailiconalertBlock(String emailiconalertBlock) {
		this.emailiconalertBlock = emailiconalertBlock;
	}
	public List<AlertBlockDetailsBO> getBlockingAlertList() {
		return blockingAlertList;
	}
	public void setBlockingAlertList(List<AlertBlockDetailsBO> blockingAlertList) {
		this.blockingAlertList = blockingAlertList;
	}
	public List<AlertBlockDetailsBO> getReleasedAlertList() {
		return releasedAlertList;
	}
	public void setReleasedAlertList(List<AlertBlockDetailsBO> releasedAlertList) {
		this.releasedAlertList = releasedAlertList;
	}    
}
