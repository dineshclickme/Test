package com.aig.nge.bo;

import com.fasterxml.jackson.annotation.JsonInclude;


public class ReassignProdOwnerReqBO {
	
	@JsonInclude(JsonInclude.Include.ALWAYS)
    private String transactionId;
	@JsonInclude(JsonInclude.Include.ALWAYS)
    private String transactionVersionNo;
	@JsonInclude(JsonInclude.Include.ALWAYS)
    private ProductRqBO products;
	/**
	 * @return the transactionId
	 */
	public String getTransactionId() {
		return transactionId;
	}
	/**
	 * @param transactionId the transactionId to set
	 */
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	/**
	 * @return the transactionVersionNo
	 */
	public String getTransactionVersionNo() {
		return transactionVersionNo;
	}
	/**
	 * @param transactionVersionNo the transactionVersionNo to set
	 */
	public void setTransactionVersionNo(String transactionVersionNo) {
		this.transactionVersionNo = transactionVersionNo;
	}
	/**
	 * @return the products
	 */
	public ProductRqBO getProducts() {
		return products;
	}
	/**
	 * @param products the products to set
	 */
	public void setProducts(ProductRqBO products) {
		this.products = products;
	}
}
