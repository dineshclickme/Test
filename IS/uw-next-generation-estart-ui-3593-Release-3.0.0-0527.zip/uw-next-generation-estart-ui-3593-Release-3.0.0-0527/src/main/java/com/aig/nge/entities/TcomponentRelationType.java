package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Set;


/**
 * The persistent class for the TCOMPONENT_RELATION_TYPE database table.
 * 
 */
@Entity
@Table(name="TCOMPONENT_RELATION_TYPE")
public class TcomponentRelationType implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="RELATION_TYPE_ID")
	private short relationTypeId;

	@Column(name="CREATE_TS")
	private Timestamp createTs;

	@Column(name="CREATE_USER_ID")
	private String createUserId;

	@Column(name="RELATION_TYPE_NM")
	private String relationTypeNm;

	@Column(name="UPDATE_TS")
	private Timestamp updateTs;

	@Column(name="UPDATE_USER_ID")
	private String updateUserId;

	//bi-directional many-to-one association to TtransactionComponentRltn
	@OneToMany(mappedBy="tcomponentRelationType", cascade={CascadeType.ALL})
	private Set<TtransactionComponentRltn> ttransactionComponentRltns;

    public TcomponentRelationType() {
    }

	public short getRelationTypeId() {
		return this.relationTypeId;
	}

	public void setRelationTypeId(short relationTypeId) {
		this.relationTypeId = relationTypeId;
	}

	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public String getRelationTypeNm() {
		return this.relationTypeNm;
	}

	public void setRelationTypeNm(String relationTypeNm) {
		this.relationTypeNm = relationTypeNm;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public Set<TtransactionComponentRltn> getTtransactionComponentRltns() {
		return this.ttransactionComponentRltns;
	}

	public void setTtransactionComponentRltns(Set<TtransactionComponentRltn> ttransactionComponentRltns) {
		this.ttransactionComponentRltns = ttransactionComponentRltns;
	}
	
}