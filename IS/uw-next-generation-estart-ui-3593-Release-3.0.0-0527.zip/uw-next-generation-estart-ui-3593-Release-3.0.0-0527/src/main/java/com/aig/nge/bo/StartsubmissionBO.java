package com.aig.nge.bo;

import java.util.List;

public class StartsubmissionBO {
	private List<SubmissionBO> startsubmission;

	public List<SubmissionBO> getStartsubmission() {
		return startsubmission;
	}

	public void setStartsubmission(List<SubmissionBO> startsubmission) {
		this.startsubmission = startsubmission;
	}
	
	
}
