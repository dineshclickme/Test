package com.aig.nge.bo;

import java.util.List;

public class RenewTransactionBO {
	
	private long transactionId;
	private short transactionVersionNo;
	private List<ProductBO> renewProducts;
	public long getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(long transactionId) {
		this.transactionId = transactionId;
	}
	public short getTransactionVersionNo() {
		return transactionVersionNo;
	}
	public void setTransactionVersionNo(short transactionVersionNo) {
		this.transactionVersionNo = transactionVersionNo;
	}
	public List<ProductBO> getRenewProducts() {
		return renewProducts;
	}
	public void setRenewProducts(List<ProductBO> renewProducts) {
		this.renewProducts = renewProducts;
	}
}
