package com.aig.nge.bo;

public class LimitBO {
	
	private String currencyCd;
	private String attachmentPointAmt;
	private String limitAmt;
	private String estimatedPremiumAmt;
	private String technicalPriceAmt;
	private String expiringPremiumAmt;	
	private String premiumAmt;
	private String existingAttachmentAmt;
	
	/**
	 * @return the existingAttachmentAmt
	 */
	public String getExistingAttachmentAmt() {
		return existingAttachmentAmt;
	}
	/**
	 * @param existingAttachmentAmt the existingAttachmentAmt to set
	 */
	public void setExistingAttachmentAmt(String existingAttachmentAmt) {
		this.existingAttachmentAmt = existingAttachmentAmt;
	}
	public String getCurrencyCd() {
		return currencyCd;
	}
	public void setCurrencyCd(String currencyCd) {
		this.currencyCd = currencyCd;
	}
	public String getAttachmentPointAmt() {
		return attachmentPointAmt;
	}
	public void setAttachmentPointAmt(String attachmentPointAmt) {
		this.attachmentPointAmt = attachmentPointAmt;
	}
	public String getLimitAmt() {
		return limitAmt;
	}
	public void setLimitAmt(String limitAmt) {
		this.limitAmt = limitAmt;
	}
	public String getEstimatedPremiumAmt() {
		return estimatedPremiumAmt;
	}
	public void setEstimatedPremiumAmt(String estimatedPremiumAmt) {
		this.estimatedPremiumAmt = estimatedPremiumAmt;
	}
	public String getTechnicalPriceAmt() {
		return technicalPriceAmt;
	}
	public void setTechnicalPriceAmt(String technicalPriceAmt) {
		this.technicalPriceAmt = technicalPriceAmt;
	}
	public String getExpiringPremiumAmt() {
		return expiringPremiumAmt;
	}
	public void setExpiringPremiumAmt(String expiringPremiumAmt) {
		this.expiringPremiumAmt = expiringPremiumAmt;
	}
	/**
	 * @return the premiumAmt
	 */
	public String getPremiumAmt() {
		return premiumAmt;
	}
	/**
	 * @param premiumAmt the premiumAmt to set
	 */
	public void setPremiumAmt(String premiumAmt) {
		this.premiumAmt = premiumAmt;
	}
	
	
	

}
