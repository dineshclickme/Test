/**
 * 
 */
package com.aig.nge.bo;

import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * @author Bennym
 *
 */
public class FindAgentReqBO {
	
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String agentEmailAddr;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String agentFirstNm;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String agentId;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String agentLastNm;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String agentNPN;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String agentStatusCd;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String licenseNo;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String producerCd;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String rowEnd;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String rowStart;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String sourceCd;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String stateCd;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String totalRecCount;
	/**
	 * @return the agentEmailAddr
	 */
	public String getAgentEmailAddr() {
		return agentEmailAddr;
	}
	/**
	 * @param agentEmailAddr the agentEmailAddr to set
	 */
	public void setAgentEmailAddr(String agentEmailAddr) {
		this.agentEmailAddr = agentEmailAddr;
	}
	/**
	 * @return the agentFirstNm
	 */
	public String getAgentFirstNm() {
		return agentFirstNm;
	}
	/**
	 * @param agentFirstNm the agentFirstNm to set
	 */
	public void setAgentFirstNm(String agentFirstNm) {
		this.agentFirstNm = agentFirstNm;
	}
	/**
	 * @return the agentId
	 */
	public String getAgentId() {
		return agentId;
	}
	/**
	 * @param agentId the agentId to set
	 */
	public void setAgentId(String agentId) {
		this.agentId = agentId;
	}
	/**
	 * @return the agentLastNm
	 */
	public String getAgentLastNm() {
		return agentLastNm;
	}
	/**
	 * @param agentLastNm the agentLastNm to set
	 */
	public void setAgentLastNm(String agentLastNm) {
		this.agentLastNm = agentLastNm;
	}
	/**
	 * @return the agentNPN
	 */
	public String getAgentNPN() {
		return agentNPN;
	}
	/**
	 * @param agentNPN the agentNPN to set
	 */
	public void setAgentNPN(String agentNPN) {
		this.agentNPN = agentNPN;
	}
	/**
	 * @return the agentStatusCd
	 */
	public String getAgentStatusCd() {
		return agentStatusCd;
	}
	/**
	 * @param agentStatusCd the agentStatusCd to set
	 */
	public void setAgentStatusCd(String agentStatusCd) {
		this.agentStatusCd = agentStatusCd;
	}
	/**
	 * @return the licenseNo
	 */
	public String getLicenseNo() {
		return licenseNo;
	}
	/**
	 * @param licenseNo the licenseNo to set
	 */
	public void setLicenseNo(String licenseNo) {
		this.licenseNo = licenseNo;
	}
	/**
	 * @return the producerCd
	 */
	public String getProducerCd() {
		return producerCd;
	}
	/**
	 * @param producerCd the producerCd to set
	 */
	public void setProducerCd(String producerCd) {
		this.producerCd = producerCd;
	}
	/**
	 * @return the rowEnd
	 */
	public String getRowEnd() {
		return rowEnd;
	}
	/**
	 * @param rowEnd the rowEnd to set
	 */
	public void setRowEnd(String rowEnd) {
		this.rowEnd = rowEnd;
	}
	/**
	 * @return the rowStart
	 */
	public String getRowStart() {
		return rowStart;
	}
	/**
	 * @param rowStart the rowStart to set
	 */
	public void setRowStart(String rowStart) {
		this.rowStart = rowStart;
	}
	/**
	 * @return the sourceCd
	 */
	public String getSourceCd() {
		return sourceCd;
	}
	/**
	 * @param sourceCd the sourceCd to set
	 */
	public void setSourceCd(String sourceCd) {
		this.sourceCd = sourceCd;
	}
	/**
	 * @return the stateCd
	 */
	public String getStateCd() {
		return stateCd;
	}
	/**
	 * @param stateCd the stateCd to set
	 */
	public void setStateCd(String stateCd) {
		this.stateCd = stateCd;
	}
	/**
	 * @return the totalRecCount
	 */
	public String getTotalRecCount() {
		return totalRecCount;
	}
	/**
	 * @param totalRecCount the totalRecCount to set
	 */
	public void setTotalRecCount(String totalRecCount) {
		this.totalRecCount = totalRecCount;
	}
}
