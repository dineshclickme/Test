package com.aig.nge.bo;


public class GetAccountRespBO {
    private IdentityBO identity;
    private GetAccountResponseBO response;
	/**
	 * @return the identity
	 */
	public IdentityBO getIdentity() {
		return identity;
	}
	/**
	 * @param identity the identity to set
	 */
	public void setIdentity(IdentityBO identity) {
		this.identity = identity;
	}
	/**
	 * @return the response
	 */
	public GetAccountResponseBO getResponse() {
		return response;
	}
	/**
	 * @param response the response to set
	 */
	public void setResponse(GetAccountResponseBO response) {
		this.response = response;
	}
}
