package com.aig.nge.bo;

import java.util.List;
import java.util.Map;

public class ExposureTypeRegionBO {
	private String id;
	private String text;
	private Map<String,String> state;
	public Map<String, String> getState() {
		return state;
	}
	public void setState(Map<String, String> state) {
		this.state = state;
	}
	private List<ExposureTypeRegionDataBO> children; 
	public List<ExposureTypeRegionDataBO> getChildren() {
		return children;
	}
	public void setChildren(List<ExposureTypeRegionDataBO> children) {
		this.children = children;
	}
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}
	
}
