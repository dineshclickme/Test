package com.aig.nge.bo;

import com.fasterxml.jackson.annotation.JsonInclude;

public class PolicySearchReqBO {

	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String policyNumber;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String policyType;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String issuingCompany;
	
	public String getPolicyNumber() {
		return policyNumber;
	}
	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}
	public String getPolicyType() {
		return policyType;
	}
	public void setPolicyType(String policyType) {
		this.policyType = policyType;
	}
	public String getIssuingCompany() {
		return issuingCompany;
	}
	public void setIssuingCompany(String issuingCompany) {
		this.issuingCompany = issuingCompany;
	}
}
