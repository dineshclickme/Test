package com.aig.nge.bo;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

public class PolicyDetailBO {
	
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String policynumber;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String policytype;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String currency;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String premium;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String premiumWithCurrency;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String policyeffectivedate;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String policyexpirationdate;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String policyeffectivedateFormat;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String policyexpirationdateFormat;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String issuingcompany;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String policyActionInd;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private List<AttributesInfoBO> attributes;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private List<AttributesInfoUpdBO> policyAttributesUpdate;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String productTabKey;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String componentProductTabKey;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String globalpolicyidentifier;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String transactionId;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String versionId;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String marketPrdCd;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String compPrdCd;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String policyAddedIn;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String isPolicyNewlyAdded;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String issuingcompanyname;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private AttributesInfoBO attributeInfo;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String policySequenceId;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String attachementPointAmt;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String dbData;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String currencyHidden;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String issuingCompanyCdHidden;
	
	public String getDbData() {
		return dbData;
	}
	public void setDbData(String dbData) {
		this.dbData = dbData;
	}
	public String getAttachementPointAmt() {
		return attachementPointAmt;
	}
	public void setAttachementPointAmt(String attachementPointAmt) {
		this.attachementPointAmt = attachementPointAmt;
	}
	public String getPolicySequenceId() {
		return policySequenceId;
	}
	public void setPolicySequenceId(String policySequenceId) {
		this.policySequenceId = policySequenceId;
	}
	/**
	 * @return the transactionId
	 */
	public String getTransactionId() {
		return transactionId;
	}
	/**
	 * @param transactionId the transactionId to set
	 */
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	/**
	 * @return the versionId
	 */
	public String getVersionId() {
		return versionId;
	}
	/**
	 * @param versionId the versionId to set
	 */
	public void setVersionId(String versionId) {
		this.versionId = versionId;
	}
	/**
	 * @return the marketPrdCd
	 */
	public String getMarketPrdCd() {
		return marketPrdCd;
	}
	/**
	 * @param marketPrdCd the marketPrdCd to set
	 */
	public void setMarketPrdCd(String marketPrdCd) {
		this.marketPrdCd = marketPrdCd;
	}
	/**
	 * @return the compPrdCd
	 */
	public String getCompPrdCd() {
		return compPrdCd;
	}
	/**
	 * @param compPrdCd the compPrdCd to set
	 */
	public void setCompPrdCd(String compPrdCd) {
		this.compPrdCd = compPrdCd;
	}
	/**
	 * @return the attributes
	 */
	public String getPolicynumber() {
		return policynumber;
	}
	public void setPolicynumber(String policynumber) {
		this.policynumber = policynumber;
	}
	
	public String getPolicytype() {
		return policytype;
	}
	public void setPolicytype(String policytype) {
		this.policytype = policytype;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public String getPremium() {
		return premium;
	}
	public void setPremium(String premium) {
		this.premium = premium;
	}

	public String getIssuingcompany() {
		return issuingcompany;
	}
	public void setIssuingcompany(String issuingcompany) {
		this.issuingcompany = issuingcompany;
	}
	
	public String getPolicyActionInd() {
		return policyActionInd;
	}
	public void setPolicyActionInd(String policyActionInd) {
		this.policyActionInd = policyActionInd;
	}
	
	public String getProductTabKey() {
		return productTabKey;
	}
	public void setProductTabKey(String productTabKey) {
		this.productTabKey = productTabKey;
	}
	public String getComponentProductTabKey() {
		return componentProductTabKey;
	}
	public void setComponentProductTabKey(String componentProductTabKey) {
		this.componentProductTabKey = componentProductTabKey;
	}
	
	public String getPolicyAddedIn() {
		return policyAddedIn;
	}
	public void setPolicyAddedIn(String policyAddedIn) {
		this.policyAddedIn = policyAddedIn;
	}
	public String getIsPolicyNewlyAdded() {
		return isPolicyNewlyAdded;
	}
	public void setIsPolicyNewlyAdded(String isPolicyNewlyAdded) {
		this.isPolicyNewlyAdded = isPolicyNewlyAdded;
	}
	public String getIssuingcompanyname() {
		return issuingcompanyname;
	}
	public void setIssuingcompanyname(String issuingcompanyname) {
		this.issuingcompanyname = issuingcompanyname;
	}
	public String getPolicyeffectivedate() {
		return policyeffectivedate;
	}
	public void setPolicyeffectivedate(String policyeffectivedate) {
		this.policyeffectivedate = policyeffectivedate;
	}
	public String getPolicyexpirationdate() {
		return policyexpirationdate;
	}
	public void setPolicyexpirationdate(String policyexpirationdate) {
		this.policyexpirationdate = policyexpirationdate;
	}
	public List<AttributesInfoUpdBO> getPolicyAttributesUpdate() {
		return policyAttributesUpdate;
	}
	public void setPolicyAttributesUpdate(
			List<AttributesInfoUpdBO> policyAttributesUpdate) {
		this.policyAttributesUpdate = policyAttributesUpdate;
	}
	public AttributesInfoBO getAttributeInfo() {
		return attributeInfo;
	}
	public void setAttributeInfo(AttributesInfoBO attributeInfo) {
		this.attributeInfo = attributeInfo;
	}
	public String getPremiumWithCurrency() {
		return premiumWithCurrency;
	}
	public String getPolicyeffectivedateFormat() {
		return policyeffectivedateFormat;
	}
	public void setPolicyeffectivedateFormat(String policyeffectivedateFormat) {
		this.policyeffectivedateFormat = policyeffectivedateFormat;
	}
	public String getPolicyexpirationdateFormat() {
		return policyexpirationdateFormat;
	}
	public void setPolicyexpirationdateFormat(String policyexpirationdateFormat) {
		this.policyexpirationdateFormat = policyexpirationdateFormat;
	}
	public void setPremiumWithCurrency(String premiumWithCurrency) {
		this.premiumWithCurrency = premiumWithCurrency;
	}
	public String getGlobalpolicyidentifier() {
		return globalpolicyidentifier;
	}
	public void setGlobalpolicyidentifier(String globalpolicyidentifier) {
		this.globalpolicyidentifier = globalpolicyidentifier;
	}
	public List<AttributesInfoBO> getAttributes() {
		return attributes;
	}
	public void setAttributes(List<AttributesInfoBO> attributes) {
		this.attributes = attributes;
	}
	public String getCurrencyHidden() {
		return currencyHidden;
	}
	public void setCurrencyHidden(String currencyHidden) {
		this.currencyHidden = currencyHidden;
	}
	
	public String getIssuingCompanyCdHidden() {
		return issuingCompanyCdHidden;
	}
	public void setIssuingCompanyCdHidden(String issuingCompanyCdHidden) {
		this.issuingCompanyCdHidden = issuingCompanyCdHidden;
	}
	
	

}
