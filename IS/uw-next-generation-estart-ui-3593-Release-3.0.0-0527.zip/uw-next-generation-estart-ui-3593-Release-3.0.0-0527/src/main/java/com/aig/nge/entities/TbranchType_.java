package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SetAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-02-19T16:13:03.044+0530")
@StaticMetamodel(TbranchType.class)
public class TbranchType_ {
	public static volatile SingularAttribute<TbranchType, Short> branchTypeId;
	public static volatile SingularAttribute<TbranchType, String> branchTypeNm;
	public static volatile SingularAttribute<TbranchType, Timestamp> createTs;
	public static volatile SingularAttribute<TbranchType, String> createUserId;
	public static volatile SingularAttribute<TbranchType, Timestamp> updateTs;
	public static volatile SingularAttribute<TbranchType, String> updateUserId;
	public static volatile SetAttribute<TbranchType, TtransactionComponentBranch> ttransactionComponentBranches;
}
