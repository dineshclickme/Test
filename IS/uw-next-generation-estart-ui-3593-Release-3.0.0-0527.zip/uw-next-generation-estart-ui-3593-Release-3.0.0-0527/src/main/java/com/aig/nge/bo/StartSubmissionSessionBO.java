package com.aig.nge.bo;

public class StartSubmissionSessionBO {
	
	private SubmissionStartDetailsSessionBO startsubmission;

	public SubmissionStartDetailsSessionBO getStartsubmission() {
		return startsubmission;
	}

	public void setStartsubmission(SubmissionStartDetailsSessionBO startsubmission) {
		this.startsubmission = startsubmission;
	}

}
