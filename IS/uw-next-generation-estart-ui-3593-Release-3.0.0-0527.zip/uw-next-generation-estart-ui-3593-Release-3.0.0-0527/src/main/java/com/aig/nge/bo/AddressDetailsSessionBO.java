package com.aig.nge.bo;

public class AddressDetailsSessionBO {

	public AddressDetailsBO accountmailingaddress;

	public AddressDetailsBO getAccountmailingaddress() {
		return accountmailingaddress;
	}

	public void setAccountmailingaddress(AddressDetailsBO accountmailingaddress) {
		this.accountmailingaddress = accountmailingaddress;
	}

		
}
