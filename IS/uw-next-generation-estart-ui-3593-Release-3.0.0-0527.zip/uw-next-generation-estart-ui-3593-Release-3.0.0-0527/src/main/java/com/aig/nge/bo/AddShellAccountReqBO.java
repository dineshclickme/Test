/**
 * 
 */
package com.aig.nge.bo;


/**
 * @author Bennym
 *
 */
public class AddShellAccountReqBO {
    private IdentityBO identity;
    private AddShellAccountReqDataTypeBO request;
	/**
	 * @return the identity
	 */
	public IdentityBO getIdentity() {
		return identity;
	}
	/**
	 * @param identity the identity to set
	 */
	public void setIdentity(IdentityBO identity) {
		this.identity = identity;
	}
	/**
	 * @return the request
	 */
	public AddShellAccountReqDataTypeBO getRequest() {
		return request;
	}
	/**
	 * @param request the request to set
	 */
	public void setRequest(AddShellAccountReqDataTypeBO request) {
		this.request = request;
	}
}
