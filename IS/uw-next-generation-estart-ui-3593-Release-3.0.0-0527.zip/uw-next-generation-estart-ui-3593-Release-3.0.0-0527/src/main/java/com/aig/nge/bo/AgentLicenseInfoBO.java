package com.aig.nge.bo;

import java.util.List;

public class AgentLicenseInfoBO {
	private List<AgentInfoBO> agentInfo;
	private String totalRecCount;
	/**
	 * @return the agentInfo
	 */
	public List<AgentInfoBO> getAgentInfo() {
		return agentInfo;
	}
	/**
	 * @param agentInfo the agentInfo to set
	 */
	public void setAgentInfo(List<AgentInfoBO> agentInfo) {
		this.agentInfo = agentInfo;
	}
	/**
	 * @return the totalRecCount
	 */
	public String getTotalRecCount() {
		return totalRecCount;
	}
	/**
	 * @param totalRecCount the totalRecCount to set
	 */
	public void setTotalRecCount(String totalRecCount) {
		this.totalRecCount = totalRecCount;
	}
}
