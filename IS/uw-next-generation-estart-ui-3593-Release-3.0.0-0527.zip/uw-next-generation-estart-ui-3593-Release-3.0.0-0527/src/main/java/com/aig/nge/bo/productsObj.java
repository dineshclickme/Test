package com.aig.nge.bo;

public class productsObj {
	
		private String prdTower;
		private String mktPrd;
		private String bundleUnderwriter;
		private String lifeCycleStatus;
		private String workingBranch;
		private String division;
		private String dspMMCP;
		private String underwriter;
		private String currency;
		private String attachmentPoint;
		private String coverageType;
		private String limitAmount;
		private String effectiveDate;
		private String premiumAmount;
		private String technicalPriceAmount;
		private String limitType;
		private String priorCarrier;
		private String expirationDate;
		private String expPremiumAmount;
		private String renewableNonRecurringInd;
		private String servicingBranch;
		private String exposureCountry;
		private String directAssumedBusiness;
		private String schemeFacilityNo;
		private String controlledMasterProgram;
		private String globalPolicyIdentifier;
		private String programIdentifier;
		private String grsIndicator;
		private String fosIndicator;
		private String multinationalIndicator;
		private String multiyearIndicator;
		private String crossborderplacementIndicator;
		private String wrapupIndicator;
		private String productlowgovernanceattributes;
		private String reserveproduct;
		private String renewprod;
		private String businessType;
		/**
		 * @return the prdTower
		 */
		public String getPrdTower() {
			return prdTower;
		}
		/**
		 * @param prdTower the prdTower to set
		 */
		public void setPrdTower(String prdTower) {
			this.prdTower = prdTower;
		}
		/**
		 * @return the mktPrd
		 */
		public String getMktPrd() {
			return mktPrd;
		}
		/**
		 * @param mktPrd the mktPrd to set
		 */
		public void setMktPrd(String mktPrd) {
			this.mktPrd = mktPrd;
		}
		/**
		 * @return the bundleUnderwriter
		 */
		public String getBundleUnderwriter() {
			return bundleUnderwriter;
		}
		/**
		 * @param bundleUnderwriter the bundleUnderwriter to set
		 */
		public void setBundleUnderwriter(String bundleUnderwriter) {
			this.bundleUnderwriter = bundleUnderwriter;
		}
		/**
		 * @return the lifeCycleStatus
		 */
		public String getLifeCycleStatus() {
			return lifeCycleStatus;
		}
		/**
		 * @param lifeCycleStatus the lifeCycleStatus to set
		 */
		public void setLifeCycleStatus(String lifeCycleStatus) {
			this.lifeCycleStatus = lifeCycleStatus;
		}
		/**
		 * @return the workingBranch
		 */
		public String getWorkingBranch() {
			return workingBranch;
		}
		/**
		 * @param workingBranch the workingBranch to set
		 */
		public void setWorkingBranch(String workingBranch) {
			this.workingBranch = workingBranch;
		}
		/**
		 * @return the division
		 */
		public String getDivision() {
			return division;
		}
		/**
		 * @param division the division to set
		 */
		public void setDivision(String division) {
			this.division = division;
		}
		/**
		 * @return the dspMMCP
		 */
		public String getDspMMCP() {
			return dspMMCP;
		}
		/**
		 * @param dspMMCP the dspMMCP to set
		 */
		public void setDspMMCP(String dspMMCP) {
			this.dspMMCP = dspMMCP;
		}
		/**
		 * @return the underwriter
		 */
		public String getUnderwriter() {
			return underwriter;
		}
		/**
		 * @param underwriter the underwriter to set
		 */
		public void setUnderwriter(String underwriter) {
			this.underwriter = underwriter;
		}
		/**
		 * @return the currency
		 */
		public String getCurrency() {
			return currency;
		}
		/**
		 * @param currency the currency to set
		 */
		public void setCurrency(String currency) {
			this.currency = currency;
		}
		/**
		 * @return the attachmentPoint
		 */
		public String getAttachmentPoint() {
			return attachmentPoint;
		}
		/**
		 * @param attachmentPoint the attachmentPoint to set
		 */
		public void setAttachmentPoint(String attachmentPoint) {
			this.attachmentPoint = attachmentPoint;
		}
		/**
		 * @return the coverageType
		 */
		public String getCoverageType() {
			return coverageType;
		}
		/**
		 * @param coverageType the coverageType to set
		 */
		public void setCoverageType(String coverageType) {
			this.coverageType = coverageType;
		}
		/**
		 * @return the limitAmount
		 */
		public String getLimitAmount() {
			return limitAmount;
		}
		/**
		 * @param limitAmount the limitAmount to set
		 */
		public void setLimitAmount(String limitAmount) {
			this.limitAmount = limitAmount;
		}
		/**
		 * @return the effectiveDate
		 */
		public String getEffectiveDate() {
			return effectiveDate;
		}
		/**
		 * @param effectiveDate the effectiveDate to set
		 */
		public void setEffectiveDate(String effectiveDate) {
			this.effectiveDate = effectiveDate;
		}
		/**
		 * @return the premiumAmount
		 */
		public String getPremiumAmount() {
			return premiumAmount;
		}
		/**
		 * @param premiumAmount the premiumAmount to set
		 */
		public void setPremiumAmount(String premiumAmount) {
			this.premiumAmount = premiumAmount;
		}
		/**
		 * @return the technicalPriceAmount
		 */
		public String getTechnicalPriceAmount() {
			return technicalPriceAmount;
		}
		/**
		 * @param technicalPriceAmount the technicalPriceAmount to set
		 */
		public void setTechnicalPriceAmount(String technicalPriceAmount) {
			this.technicalPriceAmount = technicalPriceAmount;
		}
		/**
		 * @return the limitType
		 */
		public String getLimitType() {
			return limitType;
		}
		/**
		 * @param limitType the limitType to set
		 */
		public void setLimitType(String limitType) {
			this.limitType = limitType;
		}
		/**
		 * @return the priorCarrier
		 */
		public String getPriorCarrier() {
			return priorCarrier;
		}
		/**
		 * @param priorCarrier the priorCarrier to set
		 */
		public void setPriorCarrier(String priorCarrier) {
			this.priorCarrier = priorCarrier;
		}
		/**
		 * @return the expirationDate
		 */
		public String getExpirationDate() {
			return expirationDate;
		}
		/**
		 * @param expirationDate the expirationDate to set
		 */
		public void setExpirationDate(String expirationDate) {
			this.expirationDate = expirationDate;
		}
		/**
		 * @return the expPremiumAmount
		 */
		public String getExpPremiumAmount() {
			return expPremiumAmount;
		}
		/**
		 * @param expPremiumAmount the expPremiumAmount to set
		 */
		public void setExpPremiumAmount(String expPremiumAmount) {
			this.expPremiumAmount = expPremiumAmount;
		}
		/**
		 * @return the renewableNonRecurringInd
		 */
		public String getRenewableNonRecurringInd() {
			return renewableNonRecurringInd;
		}
		/**
		 * @param renewableNonRecurringInd the renewableNonRecurringInd to set
		 */
		public void setRenewableNonRecurringInd(String renewableNonRecurringInd) {
			this.renewableNonRecurringInd = renewableNonRecurringInd;
		}
		/**
		 * @return the servicingBranch
		 */
		public String getServicingBranch() {
			return servicingBranch;
		}
		/**
		 * @param servicingBranch the servicingBranch to set
		 */
		public void setServicingBranch(String servicingBranch) {
			this.servicingBranch = servicingBranch;
		}
		/**
		 * @return the exposureCountry
		 */
		public String getExposureCountry() {
			return exposureCountry;
		}
		/**
		 * @param exposureCountry the exposureCountry to set
		 */
		public void setExposureCountry(String exposureCountry) {
			this.exposureCountry = exposureCountry;
		}
		/**
		 * @return the directAssumedBusiness
		 */
		public String getDirectAssumedBusiness() {
			return directAssumedBusiness;
		}
		/**
		 * @param directAssumedBusiness the directAssumedBusiness to set
		 */
		public void setDirectAssumedBusiness(String directAssumedBusiness) {
			this.directAssumedBusiness = directAssumedBusiness;
		}
		/**
		 * @return the schemeFacilityNo
		 */
		public String getSchemeFacilityNo() {
			return schemeFacilityNo;
		}
		/**
		 * @param schemeFacilityNo the schemeFacilityNo to set
		 */
		public void setSchemeFacilityNo(String schemeFacilityNo) {
			this.schemeFacilityNo = schemeFacilityNo;
		}
		/**
		 * @return the controlledMasterProgram
		 */
		public String getControlledMasterProgram() {
			return controlledMasterProgram;
		}
		/**
		 * @param controlledMasterProgram the controlledMasterProgram to set
		 */
		public void setControlledMasterProgram(String controlledMasterProgram) {
			this.controlledMasterProgram = controlledMasterProgram;
		}
		/**
		 * @return the globalPolicyIdentifier
		 */
		public String getGlobalPolicyIdentifier() {
			return globalPolicyIdentifier;
		}
		/**
		 * @param globalPolicyIdentifier the globalPolicyIdentifier to set
		 */
		public void setGlobalPolicyIdentifier(String globalPolicyIdentifier) {
			this.globalPolicyIdentifier = globalPolicyIdentifier;
		}
		/**
		 * @return the programIdentifier
		 */
		public String getProgramIdentifier() {
			return programIdentifier;
		}
		/**
		 * @param programIdentifier the programIdentifier to set
		 */
		public void setProgramIdentifier(String programIdentifier) {
			this.programIdentifier = programIdentifier;
		}
		/**
		 * @return the grsIndicator
		 */
		public String getGrsIndicator() {
			return grsIndicator;
		}
		/**
		 * @param grsIndicator the grsIndicator to set
		 */
		public void setGrsIndicator(String grsIndicator) {
			this.grsIndicator = grsIndicator;
		}
		/**
		 * @return the fosIndicator
		 */
		public String getFosIndicator() {
			return fosIndicator;
		}
		/**
		 * @param fosIndicator the fosIndicator to set
		 */
		public void setFosIndicator(String fosIndicator) {
			this.fosIndicator = fosIndicator;
		}
		/**
		 * @return the multinationalIndicator
		 */
		public String getMultinationalIndicator() {
			return multinationalIndicator;
		}
		/**
		 * @param multinationalIndicator the multinationalIndicator to set
		 */
		public void setMultinationalIndicator(String multinationalIndicator) {
			this.multinationalIndicator = multinationalIndicator;
		}
		/**
		 * @return the multiyearIndicator
		 */
		public String getMultiyearIndicator() {
			return multiyearIndicator;
		}
		/**
		 * @param multiyearIndicator the multiyearIndicator to set
		 */
		public void setMultiyearIndicator(String multiyearIndicator) {
			this.multiyearIndicator = multiyearIndicator;
		}
		/**
		 * @return the crossborderplacementIndicator
		 */
		public String getCrossborderplacementIndicator() {
			return crossborderplacementIndicator;
		}
		/**
		 * @param crossborderplacementIndicator the crossborderplacementIndicator to set
		 */
		public void setCrossborderplacementIndicator(
				String crossborderplacementIndicator) {
			this.crossborderplacementIndicator = crossborderplacementIndicator;
		}
		/**
		 * @return the wrapupIndicator
		 */
		public String getWrapupIndicator() {
			return wrapupIndicator;
		}
		/**
		 * @param wrapupIndicator the wrapupIndicator to set
		 */
		public void setWrapupIndicator(String wrapupIndicator) {
			this.wrapupIndicator = wrapupIndicator;
		}
		/**
		 * @return the productlowgovernanceattributes
		 */
		public String getProductlowgovernanceattributes() {
			return productlowgovernanceattributes;
		}
		/**
		 * @param productlowgovernanceattributes the productlowgovernanceattributes to set
		 */
		public void setProductlowgovernanceattributes(
				String productlowgovernanceattributes) {
			this.productlowgovernanceattributes = productlowgovernanceattributes;
		}
		/**
		 * @return the reserveproduct
		 */
		public String getReserveproduct() {
			return reserveproduct;
		}
		/**
		 * @param reserveproduct the reserveproduct to set
		 */
		public void setReserveproduct(String reserveproduct) {
			this.reserveproduct = reserveproduct;
		}
		/**
		 * @return the renewprod
		 */
		public String getRenewprod() {
			return renewprod;
		}
		/**
		 * @param renewprod the renewprod to set
		 */
		public void setRenewprod(String renewprod) {
			this.renewprod = renewprod;
		}
		/**
		 * @return the businessType
		 */
		public String getBusinessType() {
			return businessType;
		}
		/**
		 * @param businessType the businessType to set
		 */
		public void setBusinessType(String businessType) {
			this.businessType = businessType;
		}
		
}
