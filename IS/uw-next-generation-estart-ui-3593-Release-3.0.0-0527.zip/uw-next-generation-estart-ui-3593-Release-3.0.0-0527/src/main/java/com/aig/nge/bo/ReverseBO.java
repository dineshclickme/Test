package com.aig.nge.bo;

import java.util.List;

public class ReverseBO {
	
	private String url;
	private List<String> source;
	private List<String> target;
	private List<String> param;
	
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public List<String> getSource() {
		return source;
	}
	public void setSource(List<String> source) {
		this.source = source;
	}
	public List<String> getTarget() {
		return target;
	}
	public void setTarget(List<String> target) {
		this.target = target;
	}
	public List<String> getParam() {
		return param;
	}
	public void setParam(List<String> param) {
		this.param = param;
	}
	
}
