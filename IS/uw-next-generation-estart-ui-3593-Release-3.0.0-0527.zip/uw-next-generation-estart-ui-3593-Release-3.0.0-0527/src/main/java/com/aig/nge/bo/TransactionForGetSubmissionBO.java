package com.aig.nge.bo;

import java.util.List;

public class TransactionForGetSubmissionBO {
	
	private String dataKey;
	private String transaction;
	private String version;
	private ProducerEntityForGetSubmissionBO producerEntity;
	private ProducerIndividualForGetSubmissionBO producerIndividual;
	private String creditedBranch;
	private String creditedBranchHidden;
	private String underwriter;
	private String transactionVersionBoundIndicator;
	private String transactionVersionLockIndicator;
	/*
	private String leadfollowindicator;
	private String indicativequoteindicator;
	private String coinsuranceindicator;
	private String unsolicitedquoteindicator;
	private String contractNo;
	private String contractnumber;*/
	
	private String producernumberHidden;
	private String producerIndividualHidden;
	private String existProdNumberHidden;
	private String existProdIndHidden;
	private String transactionLifeStatusCode;
	private String underwriterPartyNo;	
	private String creditedCountryBranch;
	private String marketableProductIndicator;
	private String creditedBranchCdHidden;
	
	public String getCreditedBranchCdHidden() {
		return creditedBranchCdHidden;
	}
	public void setCreditedBranchCdHidden(String creditedBranchCdHidden) {
		this.creditedBranchCdHidden = creditedBranchCdHidden;
	}
	public String getMarketableProductIndicator() {
		return marketableProductIndicator;
	}
	public void setMarketableProductIndicator(String marketableProductIndicator) {
		this.marketableProductIndicator = marketableProductIndicator;
	}
	public String getCreditedCountryBranch() {
		return creditedCountryBranch;
	}
	public void setCreditedCountryBranch(String creditedCountryBranch) {
		this.creditedCountryBranch = creditedCountryBranch;
	}
	List<AttributesInfoBO> attributes;
	public String getDataKey() {
		return dataKey;
	}
	public void setDataKey(String dataKey) {
		this.dataKey = dataKey;
	}
	public String getTransaction() {
		return transaction;
	}
	public void setTransaction(String transaction) {
		this.transaction = transaction;
	}
	public String getVersion() {
		return version;
	}
	public void setVersion(String version) {
		this.version = version;
	}
	public ProducerEntityForGetSubmissionBO getProducerEntity() {
		return producerEntity;
	}
	public void setProducerEntity(ProducerEntityForGetSubmissionBO producerEntity) {
		this.producerEntity = producerEntity;
	}
	public ProducerIndividualForGetSubmissionBO getProducerIndividual() {
		return producerIndividual;
	}
	public void setProducerIndividual(
			ProducerIndividualForGetSubmissionBO producerIndividual) {
		this.producerIndividual = producerIndividual;
	}
	public String getCreditedBranch() {
		return creditedBranch;
	}
	public void setCreditedBranch(String creditedBranch) {
		this.creditedBranch = creditedBranch;
	}
	public String getCreditedBranchHidden() {
		return creditedBranchHidden;
	}
	public void setCreditedBranchHidden(String creditedBranchHidden) {
		this.creditedBranchHidden = creditedBranchHidden;
	}
	public String getUnderwriter() {
		return underwriter;
	}
	public void setUnderwriter(String underwriter) {
		this.underwriter = underwriter;
	}
	public String getTransactionVersionBoundIndicator() {
		return transactionVersionBoundIndicator;
	}
	public void setTransactionVersionBoundIndicator(
			String transactionVersionBoundIndicator) {
		this.transactionVersionBoundIndicator = transactionVersionBoundIndicator;
	}
	public String getTransactionVersionLockIndicator() {
		return transactionVersionLockIndicator;
	}
	public void setTransactionVersionLockIndicator(
			String transactionVersionLockIndicator) {
		this.transactionVersionLockIndicator = transactionVersionLockIndicator;
	}
	
	public String getProducernumberHidden() {
		return producernumberHidden;
	}
	public void setProducernumberHidden(String producernumberHidden) {
		this.producernumberHidden = producernumberHidden;
	}
	public String getProducerIndividualHidden() {
		return producerIndividualHidden;
	}
	public void setProducerIndividualHidden(String producerIndividualHidden) {
		this.producerIndividualHidden = producerIndividualHidden;
	}
	public String getExistProdNumberHidden() {
		return existProdNumberHidden;
	}
	public void setExistProdNumberHidden(String existProdNumberHidden) {
		this.existProdNumberHidden = existProdNumberHidden;
	}
	public String getExistProdIndHidden() {
		return existProdIndHidden;
	}
	public void setExistProdIndHidden(String existProdIndHidden) {
		this.existProdIndHidden = existProdIndHidden;
	}
	public String getTransactionLifeStatusCode() {
		return transactionLifeStatusCode;
	}
	public void setTransactionLifeStatusCode(String transactionLifeStatusCode) {
		this.transactionLifeStatusCode = transactionLifeStatusCode;
	}
	public String getUnderwriterPartyNo() {
		return underwriterPartyNo;
	}
	public void setUnderwriterPartyNo(String underwriterPartyNo) {
		this.underwriterPartyNo = underwriterPartyNo;
	}
	
	public List<AttributesInfoBO> getAttributes() {
		return attributes;
	}
	public void setAttributes(List<AttributesInfoBO> attributes) {
		this.attributes = attributes;
	}
	
	
}
