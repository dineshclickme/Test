package com.aig.nge.bo;

import com.fasterxml.jackson.annotation.JsonInclude;


public class GetBlockedProductsRqBO {

	@JsonInclude(JsonInclude.Include.ALWAYS)
    private String blockNo;
	@JsonInclude(JsonInclude.Include.ALWAYS)
    private ProductBO blockingComponentProduct;
	@JsonInclude(JsonInclude.Include.ALWAYS)
    private String emailiconalertBlock;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String emailiconproductBlock;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private BlockAdvancedSearchBO blockAdvancedSearchBO;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String callType;
	
	/**
	 * @return the blockNo
	 */
	public String getBlockNo() {
		return blockNo;
	}
	/**
	 * @param blockNo the blockNo to set
	 */
	public void setBlockNo(String blockNo) {
		this.blockNo = blockNo;
	}
	/**
	 * @return the blockingComponentProduct
	 */
	public ProductBO getBlockingComponentProduct() {
		return blockingComponentProduct;
	}
	/**
	 * @param blockingComponentProduct the blockingComponentProduct to set
	 */
	public void setBlockingComponentProduct(ProductBO blockingComponentProduct) {
		this.blockingComponentProduct = blockingComponentProduct;
	}
	public String getEmailiconalertBlock() {
		return emailiconalertBlock;
	}
	public void setEmailiconalertBlock(String emailiconalertBlock) {
		this.emailiconalertBlock = emailiconalertBlock;
	}
	public String getEmailiconproductBlock() {
		return emailiconproductBlock;
	}
	public void setEmailiconproductBlock(String emailiconproductBlock) {
		this.emailiconproductBlock = emailiconproductBlock;
	}
	public BlockAdvancedSearchBO getBlockAdvancedSearchBO() {
		return blockAdvancedSearchBO;
	}
	public void setBlockAdvancedSearchBO(BlockAdvancedSearchBO blockAdvancedSearchBO) {
		this.blockAdvancedSearchBO = blockAdvancedSearchBO;
	}
	public String getCallType() {
		return callType;
	}
	public void setCallType(String callType) {
		this.callType = callType;
	}
    
}
