package com.aig.nge.bo;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;


public class ProductStatusBO {
	
	@JsonInclude(JsonInclude.Include.ALWAYS)
    private String segmentCd;
	@JsonInclude(JsonInclude.Include.ALWAYS)
    private String subSegmentCd;
	@JsonInclude(JsonInclude.Include.ALWAYS)
    private String marketableProductCd;
	@JsonInclude(JsonInclude.Include.ALWAYS)
    private String componentProductCd;
	@JsonInclude(JsonInclude.Include.ALWAYS)
    private String attachmentPointAmt;
	@JsonInclude(JsonInclude.Include.ALWAYS)
    private String expirationDt;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String reasonCd;
	@JsonInclude(JsonInclude.Include.ALWAYS)
    private List<AttributesInfoBO> statusAttributes;
	@JsonInclude(JsonInclude.Include.ALWAYS)
    private List<PolicyDetailBO> policyDetail;
	@JsonInclude(JsonInclude.Include.ALWAYS)
    private String lifeCycleStatus;
	@JsonInclude(JsonInclude.Include.ALWAYS)
    private String transactionId;
	@JsonInclude(JsonInclude.Include.ALWAYS)
    private String transactionVersionNo;
	@JsonInclude(JsonInclude.Include.ALWAYS)
    private String tabId;
	@JsonInclude(JsonInclude.Include.ALWAYS)
    private String productTowerId;
	@JsonInclude(JsonInclude.Include.ALWAYS)
    private String componentProductTowerCd;
	@JsonInclude(JsonInclude.Include.ALWAYS)
    private boolean deleteFromSession;
	@JsonInclude(JsonInclude.Include.ALWAYS)
    private String comments;
	@JsonInclude(JsonInclude.Include.ALWAYS)
    private String lifeCycleStausUpdateAction;
	@JsonInclude(JsonInclude.Include.ALWAYS)
    private PolicyDetailBO policyDetailBO;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String componentProductTabKey;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String productTabkey;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String componentProductSegmentCd;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String componentProductSubSegmentCd;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String transactionComponentId;
	
	/**
	 * @return the segmentCd
	 */
	public String getSegmentCd() {
		return segmentCd;
	}
	/**
	 * @param segmentCd the segmentCd to set
	 */
	public void setSegmentCd(String segmentCd) {
		this.segmentCd = segmentCd;
	}
	/**
	 * @return the subSegmentCd
	 */
	public String getSubSegmentCd() {
		return subSegmentCd;
	}
	/**
	 * @param subSegmentCd the subSegmentCd to set
	 */
	public void setSubSegmentCd(String subSegmentCd) {
		this.subSegmentCd = subSegmentCd;
	}
	/**
	 * @return the marketableProductCd
	 */
	public String getMarketableProductCd() {
		return marketableProductCd;
	}
	/**
	 * @param marketableProductCd the marketableProductCd to set
	 */
	public void setMarketableProductCd(String marketableProductCd) {
		this.marketableProductCd = marketableProductCd;
	}
	/**
	 * @return the componentProductCd
	 */
	public String getComponentProductCd() {
		return componentProductCd;
	}
	/**
	 * @param componentProductCd the componentProductCd to set
	 */
	public void setComponentProductCd(String componentProductCd) {
		this.componentProductCd = componentProductCd;
	}
	/**
	 * @return the attachmentPointAmt
	 */
	public String getAttachmentPointAmt() {
		return attachmentPointAmt;
	}
	/**
	 * @param attachmentPointAmt the attachmentPointAmt to set
	 */
	public void setAttachmentPointAmt(String attachmentPointAmt) {
		this.attachmentPointAmt = attachmentPointAmt;
	}
	/**
	 * @return the expirationDt
	 */
	public String getExpirationDt() {
		return expirationDt;
	}
	/**
	 * @param expirationDt the expirationDt to set
	 */
	public void setExpirationDt(String expirationDt) {
		this.expirationDt = expirationDt;
	}
	/**
	 * @return the reasonCd
	 */
	public String getReasonCd() {
		return reasonCd;
	}
	/**
	 * @param reasonCd the reasonCd to set
	 */
	public void setReasonCd(String reasonCd) {
		this.reasonCd = reasonCd;
	}
	/**
	 * @return the statusAttributes
	 */
	public List<AttributesInfoBO> getStatusAttributes() {
		return statusAttributes;
	}
	/**
	 * @param statusAttributes the statusAttributes to set
	 */
	public void setStatusAttributes(List<AttributesInfoBO> statusAttributes) {
		this.statusAttributes = statusAttributes;
	}
	public List<PolicyDetailBO> getPolicyDetail() {
		return policyDetail;
	}
	public void setPolicyDetail(List<PolicyDetailBO> policyDetail) {
		this.policyDetail = policyDetail;
	}
	public String getLifeCycleStatus() {
		return lifeCycleStatus;
	}
	public void setLifeCycleStatus(String lifeCycleStatus) {
		this.lifeCycleStatus = lifeCycleStatus;
	}
	public String getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	public String getTransactionVersionNo() {
		return transactionVersionNo;
	}
	public void setTransactionVersionNo(String transactionVersionNo) {
		this.transactionVersionNo = transactionVersionNo;
	}
	public String getTabId() {
		return tabId;
	}
	public void setTabId(String tabId) {
		this.tabId = tabId;
	}
	public String getProductTowerId() {
		return productTowerId;
	}
	public void setProductTowerId(String productTowerId) {
		this.productTowerId = productTowerId;
	}
	public boolean isDeleteFromSession() {
		return deleteFromSession;
	}
	public void setDeleteFromSession(boolean deleteFromSession) {
		this.deleteFromSession = deleteFromSession;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public String getLifeCycleStausUpdateAction() {
		return lifeCycleStausUpdateAction;
	}
	public void setLifeCycleStausUpdateAction(String lifeCycleStausUpdateAction) {
		this.lifeCycleStausUpdateAction = lifeCycleStausUpdateAction;
	}
	public PolicyDetailBO getPolicyDetailBO() {
		return policyDetailBO;
	}
	public void setPolicyDetailBO(PolicyDetailBO policyDetailBO) {
		this.policyDetailBO = policyDetailBO;
	}
	public String getComponentProductTabKey() {
		return componentProductTabKey;
	}
	public void setComponentProductTabKey(String componentProductTabKey) {
		this.componentProductTabKey = componentProductTabKey;
	}
	public String getProductTabkey() {
		return productTabkey;
	}
	public void setProductTabkey(String productTabkey) {
		this.productTabkey = productTabkey;
	}
	public String getComponentProductSegmentCd() {
		return componentProductSegmentCd;
	}
	public void setComponentProductSegmentCd(String componentProductSegmentCd) {
		this.componentProductSegmentCd = componentProductSegmentCd;
	}
	public String getComponentProductSubSegmentCd() {
		return componentProductSubSegmentCd;
	}
	public void setComponentProductSubSegmentCd(String componentProductSubSegmentCd) {
		this.componentProductSubSegmentCd = componentProductSubSegmentCd;
	}
	public String getTransactionComponentId() {
		return transactionComponentId;
	}
	public void setTransactionComponentId(String transactionComponentId) {
		this.transactionComponentId = transactionComponentId;
	}
	
	public String getComponentProductTowerCd() {
		return componentProductTowerCd;
	}
	public void setComponentProductTowerCd(String componentProductTowerCd) {
		this.componentProductTowerCd = componentProductTowerCd;
	}

}
