/**
 * 
 */
package com.aig.nge.bo;


/**
 * @author Bennym
 *
 */
public class AddShellAccountRespBO {
    private IdentityBO identity;
    private AddShellAccRespBO response;
	/**
	 * @return the identity
	 */
	public IdentityBO getIdentity() {
		return identity;
	}
	/**
	 * @param identity the identity to set
	 */
	public void setIdentity(IdentityBO identity) {
		this.identity = identity;
	}
	/**
	 * @return the response
	 */
	public AddShellAccRespBO getResponse() {
		return response;
	}
	/**
	 * @param response the response to set
	 */
	public void setResponse(AddShellAccRespBO response) {
		this.response = response;
	}
}
