package com.aig.nge.bo;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

public class UpdateTransactionRequestBO {
	
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private SetProductStatusReqBO setProductStatusReq;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private ReopenProductsReqBO reopenProductsReq;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private UnBindProductReqBO unBindProductsRq;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private boolean isUpdateRequired;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String transactionId;
	@JsonInclude(JsonInclude.Include.ALWAYS)
    private UpdateTransDetailsBO updateTransactionDetails;
	@JsonInclude(JsonInclude.Include.ALWAYS)
    private List<ProductBO> reserveProductReq;
	@JsonInclude(JsonInclude.Include.ALWAYS)
    private String submissionNo;
	@JsonInclude(JsonInclude.Include.ALWAYS)
    private String versionId;
    
    /**
	 * @return the isUpdateRequired
	 */
	public boolean isUpdateRequired() {
		return isUpdateRequired;
	}
	/**
	 * @param isUpdateRequired the isUpdateRequired to set
	 */
	public void setUpdateRequired(boolean isUpdateRequired) {
		this.isUpdateRequired = isUpdateRequired;
	}
	/**
	 * @return the transactionId
	 */
	public String getTransactionId() {
		return transactionId;
	}
	/**
	 * @param transactionId the transactionId to set
	 */
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	/**
	 * @return the updateTransactionDetails
	 */
	public UpdateTransDetailsBO getUpdateTransactionDetails() {
		return updateTransactionDetails;
	}
	/**
	 * @param updateTransactionDetails the updateTransactionDetails to set
	 */
	public void setUpdateTransactionDetails(
			UpdateTransDetailsBO updateTransactionDetails) {
		this.updateTransactionDetails = updateTransactionDetails;
	}
	
    
	/**
	 * @return the submissionNo
	 */
	public String getSubmissionNo() {
		return submissionNo;
	}
	/**
	 * @param submissionNo the submissionNo to set
	 */
	public void setSubmissionNo(String submissionNo) {
		this.submissionNo = submissionNo;
	}
	public List<ProductBO> getReserveProductReq() {
		return reserveProductReq;
	}
	public void setReserveProductReq(List<ProductBO> reserveProductReq) {
		this.reserveProductReq = reserveProductReq;
	}
	public SetProductStatusReqBO getSetProductStatusReq() {
		return setProductStatusReq;
	}
	public void setSetProductStatusReq(SetProductStatusReqBO setProductStatusReq) {
		this.setProductStatusReq = setProductStatusReq;
	}
	public ReopenProductsReqBO getReopenProductsReq() {
		return reopenProductsReq;
	}
	public void setReopenProductsReq(ReopenProductsReqBO reopenProductsReq) {
		this.reopenProductsReq = reopenProductsReq;
	}
	public UnBindProductReqBO getUnBindProductsRq() {
		return unBindProductsRq;
	}
	public void setUnBindProductsRq(UnBindProductReqBO unBindProductsRq) {
		this.unBindProductsRq = unBindProductsRq;
	}
	public String getVersionId() {
		return versionId;
	}
	public void setVersionId(String versionId) {
		this.versionId = versionId;
	}
}
