package com.aig.nge.entities;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-02-19T16:13:03.430+0530")
@StaticMetamodel(TextractAttributePK.class)
public class TextractAttributePK_ {
	public static volatile SingularAttribute<TextractAttributePK, String> extractNm;
	public static volatile SingularAttribute<TextractAttributePK, Short> attributeId;
}
