package com.aig.nge.bo;

import java.util.List;

public class ComponentForGetSubmissionBO {
	
	private String dataKey;
	private String transaction;
	private String version;
	private String productId;
	private String mktproduct;
	private String subproduct;
	private String component;
	private String mktProductName;
	private String workingBranch;
	private String division;
	private String divisionHidden;
	private String DSP;
	private String MMCP;
	private String mmcpHidden;
	private String underwriter;
	private String currency;
	private String attachmentPoint;
	private String coverageType;
	private String limitAmount;
	private String effectivedate;
	private String premiumAmount;
	private String technicalPriceAmount;
	
	private String expirationdate;
	
	
	private String servicingBranch;
	private List<AttributesInfoBO> attributes;
	private String componentHidden;
	private String componentunderwriterPartyNo;
	private String componentunderwriter;
	private String reservationStatus;
	private String reservationStatusNm;
	private String creditedCountryId;
	
	/*private String limittype;
	private List<String> priorcarrier;
	private String multiyearindicator;
	private String wrapupindicator;
	private String programidentifier;
	private String schemefacilitynumber;
	private String nonrecurring;
	private String directassumedindicator;
	private String crossborderplacementindicator;
	private String controlledmasterprogramidentifier;
	private String freedomofserviceindicator;
	private String grsindicator;
	private String multinationalindicator;
	private String controlnumber;
	private String bookedindicator;
	private String renewableNonRecurringInd;*/
	
	private String lifeCycleStatusHidden;
	private String expPremiumAmount;
	private String businessType;
	private String attachmentPointHidden;
	private String reservationStatusHidden;
	private String lifeCycleStatus;
	private String reasonNm;
	private String comment;
	private AttributesInfoBO statusAttributes;
	private String statusAttrValue;
	private String statusAttrName;
	private String mktProductwrHidden;
	private String componentProductwrHidden;
	private String productTowerwrHidden;
	private String productTabKey;
	private String componentProductTabKey;
	private String policyDetailsDataKey;
	private String expiringProductDataKey;
	private String assetDetailsDataKey;
	private String exposureDetailsDataKey;
	private String additionalInsuredDataKey;
	
	private String segmentCdHidden;
	private String subSegmentCdHidden;
	private String exposureCountryName;
	private String renewalFlag;
	private String productStateCd;
	
	private String isrenewalInd;
	private List<String> exposureCountry;
	private String transactionComponentId;
	private String marketableProductTowerHidden;
	private String dspHidden;
	private String workingCountryBranch;
	private String currencyHidden;
	private String workingBranchHidden;
	private String workingCountryBranchHidden;
	private ExposureDataBO exposureType;
	
	 /* 2020 SCUP Changes UI Changes */
    private String masterLineOfCdHidden;
    private String masterLineOfName;
    private String coverageLineCdHidden;
    private String coverageLineName;
    
	public String getMasterLineOfCdHidden() {
		return masterLineOfCdHidden;
	}
	public void setMasterLineOfCdHidden(String masterLineOfCdHidden) {
		this.masterLineOfCdHidden = masterLineOfCdHidden;
	}
	public String getMasterLineOfName() {
		return masterLineOfName;
	}
	public void setMasterLineOfName(String masterLineOfName) {
		this.masterLineOfName = masterLineOfName;
	}
	public String getCoverageLineCdHidden() {
		return coverageLineCdHidden;
	}
	public void setCoverageLineCdHidden(String coverageLineCdHidden) {
		this.coverageLineCdHidden = coverageLineCdHidden;
	}
	public String getCoverageLineName() {
		return coverageLineName;
	}
	public void setCoverageLineName(String coverageLineName) {
		this.coverageLineName = coverageLineName;
	}
	
	 /* 2020 SCUP Changes UI Changes */
	public ExposureDataBO getExposureType() {
		return exposureType;
	}
	public void setExposureType(ExposureDataBO exposureType) {
		this.exposureType = exposureType;
	}
	public String getMarketableProductTowerHidden() {
		return marketableProductTowerHidden;
	}
	public void setMarketableProductTowerHidden(String marketableProductTowerHidden) {
		this.marketableProductTowerHidden = marketableProductTowerHidden;
	}
	public String getTransactionComponentId() {
		return transactionComponentId;
	}
	public void setTransactionComponentId(String transactionComponentId) {
		this.transactionComponentId = transactionComponentId;
	}
	public String getDataKey() {
		return dataKey;
	}
	public void setDataKey(String dataKey) {
		this.dataKey = dataKey;
	}
	public String getTransaction() {
		return transaction;
	}
	public void setTransaction(String transaction) {
		this.transaction = transaction;
	}
	public String getVersion() {
		return version;
	}
	public void setVersion(String version) {
		this.version = version;
	}
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getMktproduct() {
		return mktproduct;
	}
	public void setMktproduct(String mktproduct) {
		this.mktproduct = mktproduct;
	}
	public String getSubproduct() {
		return subproduct;
	}
	public void setSubproduct(String subproduct) {
		this.subproduct = subproduct;
	}
	public String getComponent() {
		return component;
	}
	public void setComponent(String component) {
		this.component = component;
	}
	public String getMktProductName() {
		return mktProductName;
	}
	public void setMktProductName(String mktProductName) {
		this.mktProductName = mktProductName;
	}
	public String getWorkingBranch() {
		return workingBranch;
	}
	public void setWorkingBranch(String workingBranch) {
		this.workingBranch = workingBranch;
	}
	public String getDivision() {
		return division;
	}
	public void setDivision(String division) {
		this.division = division;
	}
	public String getDSP() {
		return DSP;
	}
	public void setDSP(String dSP) {
		DSP = dSP;
	}
	public String getMMCP() {
		return MMCP;
	}
	public void setMMCP(String mMCP) {
		MMCP = mMCP;
	}
	public String getUnderwriter() {
		return underwriter;
	}
	public void setUnderwriter(String underwriter) {
		this.underwriter = underwriter;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public String getAttachmentPoint() {
		return attachmentPoint;
	}
	public void setAttachmentPoint(String attachmentPoint) {
		this.attachmentPoint = attachmentPoint;
	}
	public String getCoverageType() {
		return coverageType;
	}
	public void setCoverageType(String coverageType) {
		this.coverageType = coverageType;
	}
	public String getLimitAmount() {
		return limitAmount;
	}
	public void setLimitAmount(String limitAmount) {
		this.limitAmount = limitAmount;
	}
	public String getEffectivedate() {
		return effectivedate;
	}
	public void setEffectivedate(String effectivedate) {
		this.effectivedate = effectivedate;
	}
	public String getPremiumAmount() {
		return premiumAmount;
	}
	public void setPremiumAmount(String premiumAmount) {
		this.premiumAmount = premiumAmount;
	}
	public String getTechnicalPriceAmount() {
		return technicalPriceAmount;
	}
	public void setTechnicalPriceAmount(String technicalPriceAmount) {
		this.technicalPriceAmount = technicalPriceAmount;
	}
	
	public String getExpirationdate() {
		return expirationdate;
	}
	public void setExpirationdate(String expirationdate) {
		this.expirationdate = expirationdate;
	}
	
	public String getServicingBranch() {
		return servicingBranch;
	}
	public void setServicingBranch(String servicingBranch) {
		this.servicingBranch = servicingBranch;
	}
	public List<AttributesInfoBO> getAttributes() {
		return attributes;
	}
	public void setAttributes(List<AttributesInfoBO> attributes) {
		this.attributes = attributes;
	}
	public String getComponentHidden() {
		return componentHidden;
	}
	public void setComponentHidden(String componentHidden) {
		this.componentHidden = componentHidden;
	}
	public String getComponentunderwriterPartyNo() {
		return componentunderwriterPartyNo;
	}
	public void setComponentunderwriterPartyNo(String componentunderwriterPartyNo) {
		this.componentunderwriterPartyNo = componentunderwriterPartyNo;
	}
	public String getComponentunderwriter() {
		return componentunderwriter;
	}
	public void setComponentunderwriter(String componentunderwriter) {
		this.componentunderwriter = componentunderwriter;
	}
	public String getReservationStatus() {
		return reservationStatus;
	}
	public void setReservationStatus(String reservationStatus) {
		this.reservationStatus = reservationStatus;
	}
	public String getReservationStatusNm() {
		return reservationStatusNm;
	}
	public void setReservationStatusNm(String reservationStatusNm) {
		this.reservationStatusNm = reservationStatusNm;
	}
	
	public String getLifeCycleStatusHidden() {
		return lifeCycleStatusHidden;
	}
	public void setLifeCycleStatusHidden(String lifeCycleStatusHidden) {
		this.lifeCycleStatusHidden = lifeCycleStatusHidden;
	}
	public String getExpPremiumAmount() {
		return expPremiumAmount;
	}
	public void setExpPremiumAmount(String expPremiumAmount) {
		this.expPremiumAmount = expPremiumAmount;
	}
	public String getBusinessType() {
		return businessType;
	}
	public void setBusinessType(String businessType) {
		this.businessType = businessType;
	}
	public String getAttachmentPointHidden() {
		return attachmentPointHidden;
	}
	public void setAttachmentPointHidden(String attachmentPointHidden) {
		this.attachmentPointHidden = attachmentPointHidden;
	}
	public String getReservationStatusHidden() {
		return reservationStatusHidden;
	}
	public void setReservationStatusHidden(String reservationStatusHidden) {
		this.reservationStatusHidden = reservationStatusHidden;
	}
	public String getLifeCycleStatus() {
		return lifeCycleStatus;
	}
	public void setLifeCycleStatus(String lifeCycleStatus) {
		this.lifeCycleStatus = lifeCycleStatus;
	}
	public String getReasonNm() {
		return reasonNm;
	}
	public void setReasonNm(String reasonNm) {
		this.reasonNm = reasonNm;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	public AttributesInfoBO getStatusAttributes() {
		return statusAttributes;
	}
	public void setStatusAttributes(AttributesInfoBO statusAttributes) {
		this.statusAttributes = statusAttributes;
	}
	public String getStatusAttrValue() {
		return statusAttrValue;
	}
	public void setStatusAttrValue(String statusAttrValue) {
		this.statusAttrValue = statusAttrValue;
	}
	public String getStatusAttrName() {
		return statusAttrName;
	}
	public void setStatusAttrName(String statusAttrName) {
		this.statusAttrName = statusAttrName;
	}
	public String getMktProductwrHidden() {
		return mktProductwrHidden;
	}
	public void setMktProductwrHidden(String mktProductwrHidden) {
		this.mktProductwrHidden = mktProductwrHidden;
	}
	public String getComponentProductwrHidden() {
		return componentProductwrHidden;
	}
	public void setComponentProductwrHidden(String componentProductwrHidden) {
		this.componentProductwrHidden = componentProductwrHidden;
	}
	public String getProductTowerwrHidden() {
		return productTowerwrHidden;
	}
	public void setProductTowerwrHidden(String productTowerwrHidden) {
		this.productTowerwrHidden = productTowerwrHidden;
	}
	public String getProductTabKey() {
		return productTabKey;
	}
	public void setProductTabKey(String productTabKey) {
		this.productTabKey = productTabKey;
	}
	public String getComponentProductTabKey() {
		return componentProductTabKey;
	}
	public void setComponentProductTabKey(String componentProductTabKey) {
		this.componentProductTabKey = componentProductTabKey;
	}
	public String getPolicyDetailsDataKey() {
		return policyDetailsDataKey;
	}
	public void setPolicyDetailsDataKey(String policyDetailsDataKey) {
		this.policyDetailsDataKey = policyDetailsDataKey;
	}
	public String getExpiringProductDataKey() {
		return expiringProductDataKey;
	}
	public void setExpiringProductDataKey(String expiringProductDataKey) {
		this.expiringProductDataKey = expiringProductDataKey;
	}
	public String getAssetDetailsDataKey() {
		return assetDetailsDataKey;
	}
	public void setAssetDetailsDataKey(String assetDetailsDataKey) {
		this.assetDetailsDataKey = assetDetailsDataKey;
	}
	
	public String getSegmentCdHidden() {
		return segmentCdHidden;
	}
	public void setSegmentCdHidden(String segmentCdHidden) {
		this.segmentCdHidden = segmentCdHidden;
	}
	public String getSubSegmentCdHidden() {
		return subSegmentCdHidden;
	}
	public void setSubSegmentCdHidden(String subSegmentCdHidden) {
		this.subSegmentCdHidden = subSegmentCdHidden;
	}
	public String getExposureCountryName() {
		return exposureCountryName;
	}
	public void setExposureCountryName(String exposureCountryName) {
		this.exposureCountryName = exposureCountryName;
	}
	public String getRenewalFlag() {
		return renewalFlag;
	}
	public void setRenewalFlag(String renewalFlag) {
		this.renewalFlag = renewalFlag;
	}
	public String getProductStateCd() {
		return productStateCd;
	}
	public void setProductStateCd(String productStateCd) {
		this.productStateCd = productStateCd;
	}
	
	public String getIsrenewalInd() {
		return isrenewalInd;
	}
	public void setIsrenewalInd(String isrenewalInd) {
		this.isrenewalInd = isrenewalInd;
	}
	public List<String> getExposureCountry() {
		return exposureCountry;
	}
	public void setExposureCountry(List<String> exposureCountry) {
		this.exposureCountry = exposureCountry;
	}
	public String getDspHidden() {
		return dspHidden;
	}
	public void setDspHidden(String dspHidden) {
		this.dspHidden = dspHidden;
	}
	public String getCreditedCountryId() {
		return creditedCountryId;
	}
	public void setCreditedCountryId(String creditedCountryId) {
		this.creditedCountryId = creditedCountryId;
	}
	/**
	 * @return the workingCountryBranch
	 */
	public String getWorkingCountryBranch() {
		return workingCountryBranch;
	}
	/**
	 * @param workingCountryBranch the workingCountryBranch to set
	 */
	public void setWorkingCountryBranch(String workingCountryBranch) {
		this.workingCountryBranch = workingCountryBranch;
	}
	
	public String getCurrencyHidden() {
		return currencyHidden;
	}
	public void setCurrencyHidden(String currencyHidden) {
		this.currencyHidden = currencyHidden;
	}
	public String getMmcpHidden() {
		return mmcpHidden;
	}
	public void setMmcpHidden(String mmcpHidden) {
		this.mmcpHidden = mmcpHidden;
	}
	public String getDivisionHidden() {
		return divisionHidden;
	}
	public void setDivisionHidden(String divisionHidden) {
		this.divisionHidden = divisionHidden;
	}
	public String getWorkingBranchHidden() {
		return workingBranchHidden;
	}
	public void setWorkingBranchHidden(String workingBranchHidden) {
		this.workingBranchHidden = workingBranchHidden;
	}
	public String getWorkingCountryBranchHidden() {
		return workingCountryBranchHidden;
	}
	public void setWorkingCountryBranchHidden(String workingCountryBranchHidden) {
		this.workingCountryBranchHidden = workingCountryBranchHidden;
	}
	public String getExposureDetailsDataKey() {
		return exposureDetailsDataKey;
	}
	public void setExposureDetailsDataKey(String exposureDetailsDataKey) {
		this.exposureDetailsDataKey = exposureDetailsDataKey;
	}
	public String getAdditionalInsuredDataKey() {
		return additionalInsuredDataKey;
	}
	public void setAdditionalInsuredDataKey(String additionalInsuredDataKey) {
		this.additionalInsuredDataKey = additionalInsuredDataKey;
	}
	
}
