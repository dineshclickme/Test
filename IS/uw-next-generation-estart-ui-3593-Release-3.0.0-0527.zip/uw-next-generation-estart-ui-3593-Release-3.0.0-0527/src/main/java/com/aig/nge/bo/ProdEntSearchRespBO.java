package com.aig.nge.bo;

import java.util.List;

public class ProdEntSearchRespBO {
	
	private List<ProducerEntitySearchRespBO> rows;
	private String error; 

	/**
	 * @return the error
	 */
	public String getError() {
		return error;
	}

	/**
	 * @param error the error to set
	 */
	public void setError(String error) {
		this.error = error;
	}

	/**
	 * @return the rows
	 */
	public List<ProducerEntitySearchRespBO> getRows() {
		return rows;
	}

	/**
	 * @param rows the rows to set
	 */
	public void setRows(List<ProducerEntitySearchRespBO> rows) {
		this.rows = rows;
	}
	

}
