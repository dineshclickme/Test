package com.aig.nge.bo;

import java.util.List;

public class AccountAddtlInfoBO {
	private String primarySic;
	private List<String> secondarySic;
	private String dandbName;
	private String businessAs;
	private String topHq;
	private String ceo;
	private String multinational;
	private String totalEmpolyes;
	private String lob;
	private String bStart;	
	private String sales;
	/** PI3 2018 release - display market segment in account popup Start*/
	private String marketSegmentCode;
	private String marketSegmentName;
	/** PI3 2018 release - display market segment in account popup end*/
	//MDM Changes - Starts
	protected String topHQMDMPartyId;
	//MDM Changes - Ends
	
	/**
	 * @return the primarySic
	 */
	public String getPrimarySic() {
		return primarySic;
	}
	/**
	 * @param primarySic the primarySic to set
	 */
	public void setPrimarySic(String primarySic) {
		this.primarySic = primarySic;
	}
	/**
	 * @return the secondarySic
	 */
	public List<String> getSecondarySic() {
		return secondarySic;
	}
	/**
	 * @param secondarySic the secondarySic to set
	 */
	public void setSecondarySic(List<String> secondarySic) {
		this.secondarySic = secondarySic;
	}
	/**
	 * @return the dandbName
	 */
	public String getDandbName() {
		return dandbName;
	}
	/**
	 * @param dandbName the dandbName to set
	 */
	public void setDandbName(String dandbName) {
		this.dandbName = dandbName;
	}
	/**
	 * @return the businessAs
	 */
	public String getBusinessAs() {
		return businessAs;
	}
	/**
	 * @param businessAs the businessAs to set
	 */
	public void setBusinessAs(String businessAs) {
		this.businessAs = businessAs;
	}
	/**
	 * @return the topHq
	 */
	public String getTopHq() {
		return topHq;
	}
	/**
	 * @param topHq the topHq to set
	 */
	public void setTopHq(String topHq) {
		this.topHq = topHq;
	}
	/**
	 * @return the ceo
	 */
	public String getCeo() {
		return ceo;
	}
	/**
	 * @param ceo the ceo to set
	 */
	public void setCeo(String ceo) {
		this.ceo = ceo;
	}
	/**
	 * @return the multinational
	 */
	public String getMultinational() {
		return multinational;
	}
	/**
	 * @param multinational the multinational to set
	 */
	public void setMultinational(String multinational) {
		this.multinational = multinational;
	}
	/**
	 * @return the totalEmpolyes
	 */
	public String getTotalEmpolyes() {
		return totalEmpolyes;
	}
	/**
	 * @param totalEmpolyes the totalEmpolyes to set
	 */
	public void setTotalEmpolyes(String totalEmpolyes) {
		this.totalEmpolyes = totalEmpolyes;
	}
	/**
	 * @return the lob
	 */
	public String getLob() {
		return lob;
	}
	/**
	 * @param lob the lob to set
	 */
	public void setLob(String lob) {
		this.lob = lob;
	}
	/**
	 * @return the bStart
	 */
	public String getbStart() {
		return bStart;
	}
	/**
	 * @param bStart the bStart to set
	 */
	public void setbStart(String bStart) {
		this.bStart = bStart;
	}
	/**
	 * @return the sales
	 */
	public String getSales() {
		return sales;
	}
	/**
	 * @param sales the sales to set
	 */
	public void setSales(String sales) {
		this.sales = sales;
	}
	
	/** PI3 2018 release - display market segment in account popup Start*/
	public String getMarketSegmentCode() {
		return marketSegmentCode;
	}
	public void setMarketSegmentCode(String marketSegmentCode) {
		this.marketSegmentCode = marketSegmentCode;
	}
	public String getMarketSegmentName() {
		return marketSegmentName;
	}
	public void setMarketSegmentName(String marketSegmentName) {
		this.marketSegmentName = marketSegmentName;
	}	
	/** PI3 2018 release - display market segment in account popup end*/
	//MDM Changes - Starts
	public String getTopHQMDMPartyId() {
		return topHQMDMPartyId;
	}
	public void setTopHQMDMPartyId(String topHQMDMPartyId) {
		this.topHQMDMPartyId = topHQMDMPartyId;
	}
	//MDM Changes - Ends
}
