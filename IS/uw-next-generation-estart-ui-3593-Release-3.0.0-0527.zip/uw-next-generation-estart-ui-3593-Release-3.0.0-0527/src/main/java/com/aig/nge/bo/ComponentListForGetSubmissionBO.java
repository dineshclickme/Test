package com.aig.nge.bo;

public class ComponentListForGetSubmissionBO {
	
	private String dataKey;
	private String transactionId;
	private String versionId;
	private String mktProductCmpwrHidden;
	private String productTowerwrHidden;
	private String creditedCountrywrHidden;
	
	public String getProductTowerwrHidden() {
		return productTowerwrHidden;
	}
	public void setProductTowerwrHidden(String productTowerwrHidden) {
		this.productTowerwrHidden = productTowerwrHidden;
	}
	public String getDataKey() {
		return dataKey;
	}
	public void setDataKey(String dataKey) {
		this.dataKey = dataKey;
	}
	public String getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	public String getVersionId() {
		return versionId;
	}
	public void setVersionId(String versionId) {
		this.versionId = versionId;
	}
	public String getMktProductCmpwrHidden() {
		return mktProductCmpwrHidden;
	}
	public void setMktProductCmpwrHidden(String mktProductCmpwrHidden) {
		this.mktProductCmpwrHidden = mktProductCmpwrHidden;
	}
	public String getCreditedCountrywrHidden() {
		return creditedCountrywrHidden;
	}
	public void setCreditedCountrywrHidden(String creditedCountrywrHidden) {
		this.creditedCountrywrHidden = creditedCountrywrHidden;
	}
	
}
