package com.aig.nge.dao;

import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.aig.nge.bo.UnderWriterDiarySearchReqBO;
import com.aig.nge.bo.UnderWriterDiarySearchResBO;
import com.aig.nge.repository.TPartyRepository;
import com.aig.nge.utilities.NGEConstants;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.LogManager;


@Repository
public class UnderwriterDiaryDAO extends BaseDAO{
	//TCS CE Team Changes Starts Here
	private static final Logger logger = LogManager.getLogger(UnderwriterDiaryDAO.class);
	//TCS CE Team Changes Ends Here
	@Autowired
	private TPartyRepository tPartyRepository;
	
	
	public List<UnderWriterDiarySearchResBO> underWriterDiarySearch(UnderWriterDiarySearchReqBO underWriterDiarySearchReq){
		logger.debug("Entering underWriterDiarySearch");
		
		List<UnderWriterDiarySearchResBO> underWriterDiaryResList=new ArrayList<UnderWriterDiarySearchResBO>();
		List<Object[]> resObjectList=new ArrayList<Object[]>();
		String fromAutoCloseDay="CURRENT DATE + ";
		String toAutoCloseDay="CURRENT DATE + ";
		if(underWriterDiarySearchReq.getAutoCloseDays().equals("All")){
			resObjectList=tPartyRepository.getTUWProductByUnderwriterId(NGEConstants.UNDERWRITER,underWriterDiarySearchReq.getUnderwriterId(),underWriterDiarySearchReq.getFromDate(),underWriterDiarySearchReq.getToDate());
			createUnderWriterDiarySearchRes(resObjectList,underWriterDiaryResList);
			resObjectList=tPartyRepository.getMarketableProductByUnderwriterId(NGEConstants.UNDERWRITER,underWriterDiarySearchReq.getUnderwriterId(),underWriterDiarySearchReq.getFromDate(),underWriterDiarySearchReq.getToDate());
			createUnderWriterDiarySearchRes(resObjectList,underWriterDiaryResList);
		}
		else{
			fromAutoCloseDay=underWriterDiarySearchReq.getAutoCloseDays().split("-")[0]+" DAYS";
			toAutoCloseDay=underWriterDiarySearchReq.getAutoCloseDays().split("-")[1].split("\\s+")[0] + " DAYS";
			
			resObjectList=tPartyRepository.getTUWProductByAutoCloseDays(NGEConstants.UNDERWRITER,underWriterDiarySearchReq.getUnderwriterId(),underWriterDiarySearchReq.getFromDate(),underWriterDiarySearchReq.getToDate()
					,fromAutoCloseDay,toAutoCloseDay);
			createUnderWriterDiarySearchRes(resObjectList,underWriterDiaryResList);
			resObjectList=tPartyRepository.getMarketableProductByAutoCloseDays(NGEConstants.UNDERWRITER,underWriterDiarySearchReq.getUnderwriterId(),underWriterDiarySearchReq.getFromDate(),underWriterDiarySearchReq.getToDate()
					,fromAutoCloseDay,toAutoCloseDay);
			createUnderWriterDiarySearchRes(resObjectList,underWriterDiaryResList);
		}
		
		logger.debug("Exiting underWriterDiarySearch");
		return underWriterDiaryResList;
	}
	private void createUnderWriterDiarySearchRes(List<Object[]> resObjectList,List<UnderWriterDiarySearchResBO> underWriterDiaryResList){
		if(resObjectList!=null && resObjectList.size()>0){
			for(Object[] resObject:resObjectList){
				UnderWriterDiarySearchResBO underWriterDiarySearchRes=new UnderWriterDiarySearchResBO();
				underWriterDiarySearchRes.setAccountName((String) resObject[0]);
				underWriterDiarySearchRes.setEffDate( String.valueOf(resObject[2]));
				underWriterDiarySearchRes.setExpDate( String.valueOf(resObject[3]));
				underWriterDiarySearchRes.setSubmissionNo((String) resObject[4]);
				underWriterDiarySearchRes.setTransVersion( String.valueOf(((short)resObject[5])));
				underWriterDiarySearchRes.setLifeCycleStatus((String) resObject[6]);
				underWriterDiarySearchRes.setProductName((String) resObject[7]);
				underWriterDiarySearchRes.setuWId((String) resObject[8]);
				underWriterDiarySearchRes.setResrvCondition((String) resObject[9]);
				underWriterDiarySearchRes.setNonrecurInd((String) resObject[10]);
				underWriterDiaryResList.add(underWriterDiarySearchRes);
				
			}
		}
	}
}
