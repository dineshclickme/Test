package com.aig.nge.bo;

public class ProducerBO {

	private String producerCd;
	private String producerNm;
	private String countryNm;
	private String sourceCd;
	private String countryId;
	private String branchNo;
	
	public String getSourceCd() {
		return sourceCd;
	}
	public void setSourceCd(String sourceCd) {
		this.sourceCd = sourceCd;
	}
	public String getCountryNm() {
		return countryNm;
	}
	public void setCountryNm(String countryNm) {
		this.countryNm = countryNm;
	}
	public String getProducerCd() {
		return producerCd;
	}
	public void setProducerCd(String producerCd) {
		this.producerCd = producerCd;
	}
	public String getProducerNm() {
		return producerNm;
	}
	public void setProducerNm(String producerNm) {
		this.producerNm = producerNm;
	}
	/**
	 * @return the countryId
	 */
	public String getCountryId() {
		return countryId;
	}
	/**
	 * @param countryId the countryId to set
	 */
	public void setCountryId(String countryId) {
		this.countryId = countryId;
	}
	/**
	 * @return the branchNo
	 */
	public String getBranchNo() {
		return branchNo;
	}
	/**
	 * @param branchNo the branchNo to set
	 */
	public void setBranchNo(String branchNo) {
		this.branchNo = branchNo;
	}
}
