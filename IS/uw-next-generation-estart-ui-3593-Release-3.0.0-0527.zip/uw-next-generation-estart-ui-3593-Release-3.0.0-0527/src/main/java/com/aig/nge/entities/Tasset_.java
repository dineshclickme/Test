package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SetAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-02-19T16:13:02.790+0530")
@StaticMetamodel(Tasset.class)
public class Tasset_ {
	public static volatile SingularAttribute<Tasset, Integer> assetId;
	public static volatile SingularAttribute<Tasset, String> assetDs;
	public static volatile SingularAttribute<Tasset, Timestamp> createTs;
	public static volatile SingularAttribute<Tasset, String> createUserId;
	public static volatile SingularAttribute<Tasset, Short> systemId;
	public static volatile SingularAttribute<Tasset, Timestamp> updateTs;
	public static volatile SingularAttribute<Tasset, String> updateUserId;
	public static volatile SingularAttribute<Tasset, TassetType> tassetType;
	public static volatile SetAttribute<Tasset, TassetAttribute> tassetAttributes;
	public static volatile SetAttribute<Tasset, TtransactionComponentAsset> ttransactionComponentAssets;
}
