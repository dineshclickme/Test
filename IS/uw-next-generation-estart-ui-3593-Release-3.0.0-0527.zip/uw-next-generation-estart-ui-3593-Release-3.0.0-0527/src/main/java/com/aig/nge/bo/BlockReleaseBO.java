package com.aig.nge.bo;

import com.fasterxml.jackson.annotation.JsonInclude;


public class BlockReleaseBO {

	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String blockNo;
	@JsonInclude(JsonInclude.Include.ALWAYS)
    private String reasonCd;
	@JsonInclude(JsonInclude.Include.ALWAYS)
    private String comment;
	/**
	 * @return the blockNo
	 */
	public String getBlockNo() {
		return blockNo;
	}
	/**
	 * @param blockNo the blockNo to set
	 */
	public void setBlockNo(String blockNo) {
		this.blockNo = blockNo;
	}
	/**
	 * @return the reasonCd
	 */
	public String getReasonCd() {
		return reasonCd;
	}
	/**
	 * @param reasonCd the reasonCd to set
	 */
	public void setReasonCd(String reasonCd) {
		this.reasonCd = reasonCd;
	}
	/**
	 * @return the comment
	 */
	public String getComment() {
		return comment;
	}
	/**
	 * @param comment the comment to set
	 */
	public void setComment(String comment) {
		this.comment = comment;
	}
}
