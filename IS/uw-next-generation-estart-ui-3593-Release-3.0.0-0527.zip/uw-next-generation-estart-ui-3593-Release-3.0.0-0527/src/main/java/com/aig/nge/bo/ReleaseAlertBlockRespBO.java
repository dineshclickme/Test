package com.aig.nge.bo;

import java.util.List;

public class ReleaseAlertBlockRespBO {

	 private List<ReleaseProductBO> product;

	/**
	 * @return the product
	 */
	public List<ReleaseProductBO> getProduct() {
		return product;
	}

	/**
	 * @param product the product to set
	 */
	public void setProduct(List<ReleaseProductBO> product) {
		this.product = product;
	}
	 
}
