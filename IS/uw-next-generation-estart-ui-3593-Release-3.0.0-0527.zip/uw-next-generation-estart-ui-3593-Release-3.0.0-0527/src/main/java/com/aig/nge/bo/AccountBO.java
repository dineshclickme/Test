package com.aig.nge.bo;

public class AccountBO {

	
	private String accountNo;
	private String accountNm;
	private String resolvedDNBNo;
	private String resolvedDNBNm;
	private String ultimateDNBNo;
	private String ultimateDNBNm;
	private String mdmPartyId; //2021 MDM
	
	public String getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}
	public String getAccountNm() {
		return accountNm;
	}
	public void setAccountNm(String accountNm) {
		this.accountNm = accountNm;
	}
	public String getResolvedDNBNo() {
		return resolvedDNBNo;
	}
	public void setResolvedDNBNo(String resolvedDNBNo) {
		this.resolvedDNBNo = resolvedDNBNo;
	}
	public String getResolvedDNBNm() {
		return resolvedDNBNm;
	}
	public void setResolvedDNBNm(String resolvedDNBNm) {
		this.resolvedDNBNm = resolvedDNBNm;
	}
	public String getUltimateDNBNo() {
		return ultimateDNBNo;
	}
	public void setUltimateDNBNo(String ultimateDNBNo) {
		this.ultimateDNBNo = ultimateDNBNo;
	}
	public String getUltimateDNBNm() {
		return ultimateDNBNm;
	}
	public void setUltimateDNBNm(String ultimateDNBNm) {
		this.ultimateDNBNm = ultimateDNBNm;
	}
	public String getMdmPartyId() {
		return mdmPartyId;
	}
	public void setMdmPartyId(String mdmPartyId) {
		this.mdmPartyId = mdmPartyId;
	}
	
	
}
