package com.aig.nge.bo;

import java.util.List;

public class UnderwriterSearchlistBO {
	
	private List<UnderwriterSearchBO> underwriterList;

	public List<UnderwriterSearchBO> getUnderwriterList() {
		return underwriterList;
	}

	public void setUnderwriterList(List<UnderwriterSearchBO> underwriterList) {
		this.underwriterList = underwriterList;
	}
	
	

}
