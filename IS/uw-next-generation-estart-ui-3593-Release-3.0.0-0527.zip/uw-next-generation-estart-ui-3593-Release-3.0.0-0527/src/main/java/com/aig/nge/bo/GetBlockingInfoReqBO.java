package com.aig.nge.bo;

import com.fasterxml.jackson.annotation.JsonInclude;

public class GetBlockingInfoReqBO {
	
	@JsonInclude(JsonInclude.Include.ALWAYS)
    protected String blockNo;
	@JsonInclude(JsonInclude.Include.ALWAYS)
    protected ProductBO blockedProductsDetails;
	@JsonInclude(JsonInclude.Include.ALWAYS)
    private String emailiconproductBlock;
	@JsonInclude(JsonInclude.Include.ALWAYS)
  	private String emailiconalertBlock;
	/**
	 * @return the blockNo
	 */
	public String getBlockNo() {
		return blockNo;
	}
	/**
	 * @param blockNo the blockNo to set
	 */
	public void setBlockNo(String blockNo) {
		this.blockNo = blockNo;
	}
	/**
	 * @return the blockedProductsDetails
	 */
	public ProductBO getBlockedProductsDetails() {
		return blockedProductsDetails;
	}
	/**
	 * @param blockedProductsDetails the blockedProductsDetails to set
	 */
	public void setBlockedProductsDetails(ProductBO blockedProductsDetails) {
		this.blockedProductsDetails = blockedProductsDetails;
	}
	public String getEmailiconproductBlock() {
		return emailiconproductBlock;
	}
	public void setEmailiconproductBlock(String emailiconproductBlock) {
		this.emailiconproductBlock = emailiconproductBlock;
	}
	public String getEmailiconalertBlock() {
		return emailiconalertBlock;
	}
	public void setEmailiconalertBlock(String emailiconalertBlock) {
		this.emailiconalertBlock = emailiconalertBlock;
	}
    
}
