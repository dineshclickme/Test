package com.aig.nge.bo;

import java.util.List;

public class GetBlockedInfoRows {
	

	private List<BlockedInfoRow> rows;

	public List<BlockedInfoRow> getRows() {
		return rows;
	}

	public void setRows(List<BlockedInfoRow> rows) {
		this.rows = rows;
	}
	



	/**
	 * @return the rows
	 */
}
