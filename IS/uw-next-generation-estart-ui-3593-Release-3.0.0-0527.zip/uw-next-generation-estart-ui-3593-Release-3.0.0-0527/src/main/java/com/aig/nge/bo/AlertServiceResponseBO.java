package com.aig.nge.bo;

public class AlertServiceResponseBO {
	
	private String seReasonCd;
	private String seReasonDesc;
	private String seReasonLongDesc;
	private String referTo;
	private String saClassDesc;
	private String seDetail;
	private String subEvalCd;
	public String getSeReasonCd() {
		return seReasonCd;
	}
	public void setSeReasonCd(String seReasonCd) {
		this.seReasonCd = seReasonCd;
	}
	public String getSeReasonDesc() {
		return seReasonDesc;
	}
	public void setSeReasonDesc(String seReasonDesc) {
		this.seReasonDesc = seReasonDesc;
	}
	public String getSeReasonLongDesc() {
		return seReasonLongDesc;
	}
	public void setSeReasonLongDesc(String seReasonLongDesc) {
		this.seReasonLongDesc = seReasonLongDesc;
	}
	public String getReferTo() {
		return referTo;
	}
	public void setReferTo(String referTo) {
		this.referTo = referTo;
	}
	public String getSaClassDesc() {
		return saClassDesc;
	}
	public void setSaClassDesc(String saClassDesc) {
		this.saClassDesc = saClassDesc;
	}
	public String getSeDetail() {
		return seDetail;
	}
	public void setSeDetail(String seDetail) {
		this.seDetail = seDetail;
	}
	public String getSubEvalCd() {
		return subEvalCd;
	}
	public void setSubEvalCd(String subEvalCd) {
		this.subEvalCd = subEvalCd;
	}
	
}
