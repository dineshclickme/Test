package com.aig.nge.bo;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class SubmissionCountResBO {
	
	@JsonProperty("Response")
	private List<Response>  response;

	public List<Response> getResponse() {
		return response;
	}

	public void setResponse(List<Response> response) {
		this.response = response;
	}
	
	
}
