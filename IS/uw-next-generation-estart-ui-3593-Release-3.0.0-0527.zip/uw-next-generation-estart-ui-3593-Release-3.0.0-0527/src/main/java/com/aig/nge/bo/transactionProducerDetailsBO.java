package com.aig.nge.bo;

public class transactionProducerDetailsBO {
	
	private String producerCode;
	private String producerName;
	private AddressDetailsBO transactioproducerAddress;
	
	
	public String getProducerCode() {
		return producerCode;
	}
	public void setProducerCode(String producerCode) {
		this.producerCode = producerCode;
	}
	public String getProducerName() {
		return producerName;
	}
	public void setProducerName(String producerName) {
		this.producerName = producerName;
	}
	public AddressDetailsBO getTransactioproducerAddress() {
		return transactioproducerAddress;
	}
	public void setTransactioproducerAddress(
			AddressDetailsBO transactioproducerAddress) {
		this.transactioproducerAddress = transactioproducerAddress;
	}

	
	

}
