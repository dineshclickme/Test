package com.aig.nge.bo;

public class SessionBlockDetailsBO {
	
	private ViewblockBO viewblockdetails;

	public ViewblockBO getViewblockdetails() {
		return viewblockdetails;
	}

	public void setViewblockdetails(ViewblockBO viewblockdetails) {
		this.viewblockdetails = viewblockdetails;
	}

}
