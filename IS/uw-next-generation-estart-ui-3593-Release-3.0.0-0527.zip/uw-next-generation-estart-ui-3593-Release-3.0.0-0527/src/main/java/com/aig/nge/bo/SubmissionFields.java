package com.aig.nge.bo;

public class SubmissionFields {
	CustomTag []submission;
	CustomTag []transactionfields;
	CustomTag []productfields;
	CustomTag submissiondata;
	CustomTag transactiondata;
	CustomTag productdata;
	
	
	public CustomTag getSubmissiondata() {
		return submissiondata;
	}
	public void setSubmissiondata(CustomTag submissiondata) {
		this.submissiondata = submissiondata;
	}
	public CustomTag getTransactiondata() {
		return transactiondata;
	}
	public void setTransactiondata(CustomTag transactiondata) {
		this.transactiondata = transactiondata;
	}
	public CustomTag getProductdata() {
		return productdata;
	}
	public void setProductdata(CustomTag productdata) {
		this.productdata = productdata;
	}

	public CustomTag[] getSubmissionfields() {
		return submission;
	}
	public void setSubmissionfields(CustomTag[] submissionfields) {
		this.submission = submissionfields;
	}
	public CustomTag[] getTransactionfields() {
		return transactionfields;
	}
	public void setTransactionfields(CustomTag[] transactionfields) {
		this.transactionfields = transactionfields;
	}
	public CustomTag[] getProductfields() {
		return productfields;
	}
	public void setProductfields(CustomTag[] productfields) {
		this.productfields = productfields;
	}
	 
}
