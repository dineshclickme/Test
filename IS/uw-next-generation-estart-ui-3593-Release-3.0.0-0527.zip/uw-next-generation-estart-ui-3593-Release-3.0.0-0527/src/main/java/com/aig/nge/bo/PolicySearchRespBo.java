package com.aig.nge.bo;

public class PolicySearchRespBo {
	
	private String policytype;
	private String policyno;
	private String issuingcompany;
	private String issuingcompanyCode;
	private String policyeffectivedate;
	private String policyexpirationdate;
	private String policyeffectivedateFormat;
	private String policyexpirationdateFormat;
	private String currency;
	private String premium;
	private String premiumWithCurrency;	
	public String getPremiumWithCurrency() {
		return premiumWithCurrency;
	}
	public void setPremiumWithCurrency(String premiumWithCurrency) {
		this.premiumWithCurrency = premiumWithCurrency;
	}
	public String getPolicytype() {
		return policytype;
	}
	public void setPolicytype(String policytype) {
		this.policytype = policytype;
	}
	public String getPolicyno() {
		return policyno;
	}
	public void setPolicyno(String policyno) {
		this.policyno = policyno;
	}
	public String getIssuingcompany() {
		return issuingcompany;
	}
	public void setIssuingcompany(String issuingcompany) {
		this.issuingcompany = issuingcompany;
	}
	
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public String getPremium() {
		return premium;
	}
	public void setPremium(String premium) {
		this.premium = premium;
	}
	public String getIssuingcompanyCode() {
		return issuingcompanyCode;
	}
	public void setIssuingcompanyCode(String issuingcompanyCode) {
		this.issuingcompanyCode = issuingcompanyCode;
	}
	public String getPolicyeffectivedate() {
		return policyeffectivedate;
	}
	public void setPolicyeffectivedate(String policyeffectivedate) {
		this.policyeffectivedate = policyeffectivedate;
	}
	public String getPolicyexpirationdate() {
		return policyexpirationdate;
	}
	public void setPolicyexpirationdate(String policyexpirationdate) {
		this.policyexpirationdate = policyexpirationdate;
	}
	public String getPolicyeffectivedateFormat() {
		return policyeffectivedateFormat;
	}
	public void setPolicyeffectivedateFormat(String policyeffectivedateFormat) {
		this.policyeffectivedateFormat = policyeffectivedateFormat;
	}
	public String getPolicyexpirationdateFormat() {
		return policyexpirationdateFormat;
	}
	public void setPolicyexpirationdateFormat(String policyexpirationdateFormat) {
		this.policyexpirationdateFormat = policyexpirationdateFormat;
	}

}
