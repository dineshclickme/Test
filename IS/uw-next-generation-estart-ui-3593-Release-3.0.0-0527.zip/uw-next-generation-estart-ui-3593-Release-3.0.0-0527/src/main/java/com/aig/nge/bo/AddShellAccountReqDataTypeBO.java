package com.aig.nge.bo;

import com.fasterxml.jackson.annotation.JsonInclude;


public class AddShellAccountReqDataTypeBO {
	
	@JsonInclude(JsonInclude.Include.ALWAYS)
    private String accountBusinessName;
	@JsonInclude(JsonInclude.Include.ALWAYS)
    private String streetAddress;
	@JsonInclude(JsonInclude.Include.ALWAYS)
    private String cityName;
	@JsonInclude(JsonInclude.Include.ALWAYS)
    private String stateCode;
	@JsonInclude(JsonInclude.Include.ALWAYS)
    private String countryCode;
	@JsonInclude(JsonInclude.Include.ALWAYS)
    private String postalCode;
	@JsonInclude(JsonInclude.Include.ALWAYS)
    private String fein;
	/* Q1 2018 Maintenance Release - Add Shell Account Enhancement - Starts */
	@JsonInclude(JsonInclude.Include.ALWAYS)
    private String sicCode;
	@JsonInclude(JsonInclude.Include.ALWAYS)
    private String salesAmount;
	@JsonInclude(JsonInclude.Include.ALWAYS)
    private String sicCodeDetails;

	public String getSicCodeDetails() {
		return sicCodeDetails;
	}
	public void setSicCodeDetails(String sicCodeDetails) {
		this.sicCodeDetails = sicCodeDetails;
	}
	public String getSicCode() {
		return sicCode;
	}
	public void setSicCode(String sicCode) {
		this.sicCode = sicCode;
	}
	public String getSalesAmount() {
		return salesAmount;
	}
	public void setSalesAmount(String salesAmount) {
		this.salesAmount = salesAmount;
	}
	/* Q1 2018 Maintenance Release - Add Shell Account Enhancement - Ends */
	
	/* MDM Migration 2021 - Add Shell Account Enhancement - Starts */
	@JsonInclude(JsonInclude.Include.ALWAYS)
    private String mailingAddress;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String streetAddress2;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String mailingAddress2;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String mailingCityName;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String mailingPostalCode;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String mailingStateCode;
	
	/**
	 * @return the mailingAddress
	 */
	public String getMailingAddress() {
		return mailingAddress;
	}
	/**
	 * @param mailingAddress the mailingAddress to set
	 */
	public void setMailingAddress(String mailingAddress) {
		this.mailingAddress = mailingAddress;
	}
	/**
	 * @return the streetAddress2
	 */
	public String getStreetAddress2() {
		return streetAddress2;
	}
	/**
	 * @param streetAddress2 the streetAddress2 to set
	 */
	public void setStreetAddress2(String streetAddress2) {
		this.streetAddress2 = streetAddress2;
	}
	/**
	 * @return the mailingAddress2
	 */
	public String getMailingAddress2() {
		return mailingAddress2;
	}
	/**
	 * @param mailingAddress2 the mailingAddress2 to set
	 */
	public void setMailingAddress2(String mailingAddress2) {
		this.mailingAddress2 = mailingAddress2;
	}
	/**
	 * @return the mailingCityName
	 */
	public String getMailingCityName() {
		return mailingCityName;
	}
	/**
	 * @param mailingCityName the mailingCityName to set
	 */
	public void setMailingCityName(String mailingCityName) {
		this.mailingCityName = mailingCityName;
	}
	/**
	 * @return the mailingPostalCode
	 */
	public String getMailingPostalCode() {
		return mailingPostalCode;
	}
	/**
	 * @param mailingPostalCode the mailingPostalCode to set
	 */
	public void setMailingPostalCode(String mailingPostalCode) {
		this.mailingPostalCode = mailingPostalCode;
	}
	/**
	 * @return the mailingStateCode
	 */
	public String getMailingStateCode() {
		return mailingStateCode;
	}
	/**
	 * @param mailingStateCode the mailingStateCode to set
	 */
	public void setMailingStateCode(String mailingStateCode) {
		this.mailingStateCode = mailingStateCode;
	}
	
	/* MDM Migration 2021 - Add Shell Account Enhancement - End */
	
	/**
	 * @return the accountBusinessName
	 */
	public String getAccountBusinessName() {
		return accountBusinessName;
	}
	/**
	 * @param accountBusinessName the accountBusinessName to set
	 */
	public void setAccountBusinessName(String accountBusinessName) {
		this.accountBusinessName = accountBusinessName;
	}
	/**
	 * @return the streetAddress
	 */
	public String getStreetAddress() {
		return streetAddress;
	}
	/**
	 * @param streetAddress the streetAddress to set
	 */
	public void setStreetAddress(String streetAddress) {
		this.streetAddress = streetAddress;
	}
	/**
	 * @return the cityName
	 */
	public String getCityName() {
		return cityName;
	}
	/**
	 * @param cityName the cityName to set
	 */
	public void setCityName(String cityName) {
		this.cityName = cityName;
	}
	/**
	 * @return the stateCode
	 */
	public String getStateCode() {
		return stateCode;
	}
	/**
	 * @param stateCode the stateCode to set
	 */
	public void setStateCode(String stateCode) {
		this.stateCode = stateCode;
	}
	/**
	 * @return the countryCode
	 */
	public String getCountryCode() {
		return countryCode;
	}
	/**
	 * @param countryCode the countryCode to set
	 */
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}
	/**
	 * @return the postalCode
	 */
	public String getPostalCode() {
		return postalCode;
	}
	/**
	 * @param postalCode the postalCode to set
	 */
	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}
	/**
	 * @return the fein
	 */
	public String getFein() {
		return fein;
	}
	/**
	 * @param fein the fein to set
	 */
	public void setFein(String fein) {
		this.fein = fein;
	}
}
