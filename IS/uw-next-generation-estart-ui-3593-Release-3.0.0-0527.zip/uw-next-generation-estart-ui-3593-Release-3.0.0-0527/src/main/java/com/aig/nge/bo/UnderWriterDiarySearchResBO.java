package com.aig.nge.bo;

import java.util.Comparator;

public class UnderWriterDiarySearchResBO {
	private String accountName;
	private String accountNo;
	private String submissionNo;
	private String productName;
	private Integer autoCloseDays;
	private String lifeCycleStatus;
	private String lifeCycleStatusHidden;
	private String transVersion;

	private String uWId;
	
	private String producerEntity;
	private String producerEntityCd;
	private String effDate;
	private String expDate;
	private String busType;
	private String resrvCondition;
	private String reservationStatusHidden;
	private String nonrecurInd;
	private String productState;
	private String componentProductCd;
	private String marketableProductCd;
	private String transId;
	private String marketableProductName;
	private String componentProductName;
	private String extCount;
	private String extDayCount;
	private String productTowerCd;
	private String productTowerName;
	private String segmentCd;
	private String subSegmentCd;
	private String attachmentPointAmt;
	private String currencyCode;
	private String uwName;
	private int underwriterRowId;
	private String limitAmt;
	private String premiumAmt;
	private String techPremiumAmt;
	 private String transactionComponentId;
	    private String componentProductTowerCd;
	    private String componentProductTowerNm;
		private String componentSegmentCd;
		private String componentSubSegmentCd;
    //US145616 SCUP Changes 2020 started//
	    private String masterLineOfBusinessCd;
	    private String masterLineOfBusinessNm;
	    private String coverageLineCd;
	    private String coverageLineNm;
	    
	
	public String getMasterLineOfBusinessCd() {
			return masterLineOfBusinessCd;
		}
		public void setMasterLineOfBusinessCd(String masterLineOfBusinessCd) {
			this.masterLineOfBusinessCd = masterLineOfBusinessCd;
		}
		public String getMasterLineOfBusinessNm() {
			return masterLineOfBusinessNm;
		}
		public void setMasterLineOfBusinessNm(String masterLineOfBusinessNm) {
			this.masterLineOfBusinessNm = masterLineOfBusinessNm;
		}
		public String getCoverageLineCd() {
			return coverageLineCd;
		}
		public void setCoverageLineCd(String coverageLineCd) {
			this.coverageLineCd = coverageLineCd;
		}
		public String getCoverageLineNm() {
			return coverageLineNm;
		}
		public void setCoverageLineNm(String coverageLineNm) {
			this.coverageLineNm = coverageLineNm;
		}
	//US145616 SCUP Changes 2020 ended//
	public String getTechPremiumAmt() {
		return techPremiumAmt;
	}
	public void setTechPremiumAmt(String techPremiumAmt) {
		this.techPremiumAmt = techPremiumAmt;
	}
	public int getUnderwriterRowId() {
		return underwriterRowId;
	}
	public void setUnderwriterRowId(int underwriterRowId) {
		this.underwriterRowId = underwriterRowId;
	}
	
	public String getUwName() {
		return uwName;
	}
	public void setUwName(String uwName) {
		this.uwName = uwName;
	}
	public String getProductState() {
		return productState;
	}
	public void setProductState(String productState) {
		this.productState = productState;
	}
	public String getAccountName() {
		return accountName;
	}
	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}
	public String getSubmissionNo() {
		return submissionNo;
	}
	public void setSubmissionNo(String submissionNo) {
		this.submissionNo = submissionNo;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	
	public String getLifeCycleStatus() {
		return lifeCycleStatus;
	}
	public void setLifeCycleStatus(String lifeCycleStatus) {
		this.lifeCycleStatus = lifeCycleStatus;
	}
	public String getTransVersion() {
		return transVersion;
	}
	public void setTransVersion(String transVersion) {
		this.transVersion = transVersion;
	}
	public String getuWId() {
		return uWId;
	}
	public void setuWId(String uWId) {
		this.uWId = uWId;
	}
	public String getProducerEntity() {
		return producerEntity;
	}
	public void setProducerEntity(String producerEntity) {
		this.producerEntity = producerEntity;
	}
	public String getEffDate() {
		return effDate;
	}
	public void setEffDate(String effDate) {
		this.effDate = effDate;
	}
	public String getExpDate() {
		return expDate;
	}
	public void setExpDate(String expDate) {
		this.expDate = expDate;
	}
	public String getBusType() {
		return busType;
	}
	public void setBusType(String busType) {
		this.busType = busType;
	}
	public String getResrvCondition() {
		return resrvCondition;
	}
	public void setResrvCondition(String reserved) {
		resrvCondition = reserved;
	}
	public String getNonrecurInd() {
		return nonrecurInd;
	}
	public void setNonrecurInd(String nonrecurInd) {
		this.nonrecurInd = nonrecurInd;
	}
	public String getComponentProductCd() {
		return componentProductCd;
	}
	public void setComponentProductCd(String componentProductCd) {
		this.componentProductCd = componentProductCd;
	}
	public String getMarketableProductCd() {
		return marketableProductCd;
	}
	public void setMarketableProductCd(String marketableProductCd) {
		this.marketableProductCd = marketableProductCd;
	}
	public String getTransId() {
		return transId;
	}
	public void setTransId(String transId) {
		this.transId = transId;
	}
	public String getMarketableProductName() {
		return marketableProductName;
	}
	public void setMarketableProductName(String marketableProductName) {
		this.marketableProductName = marketableProductName;
	}
	public String getComponentProductName() {
		return componentProductName;
	}
	public void setComponentProductName(String componentProductName) {
		this.componentProductName = componentProductName;
	}
	public String getExtCount() {
		return extCount;
	}
	public void setExtCount(String extCount) {
		this.extCount = extCount;
	}
	public Integer getAutoCloseDays() {
		return autoCloseDays;
	}
	public void setAutoCloseDays(Integer autoCloseDays) {
		this.autoCloseDays = autoCloseDays;
	}
	public String getProductTowerCd() {
		return productTowerCd;
	}
	public void setProductTowerCd(String productTowerCd) {
		this.productTowerCd = productTowerCd;
	}
	public String getSegmentCd() {
		return segmentCd;
	}
	public void setSegmentCd(String segmentCd) {
		this.segmentCd = segmentCd;
	}
	public String getSubSegmentCd() {
		return subSegmentCd;
	}
	public void setSubSegmentCd(String subSegmentCd) {
		this.subSegmentCd = subSegmentCd;
	}

	public String getLifeCycleStatusHidden() {
		return lifeCycleStatusHidden;
	}
	public void setLifeCycleStatusHidden(String lifeCycleStatusHidden) {
		this.lifeCycleStatusHidden = lifeCycleStatusHidden;
	}
	public String getReservationStatusHidden() {
		return reservationStatusHidden;
	}
	public void setReservationStatusHidden(String reservationStatusHidden) {
		this.reservationStatusHidden = reservationStatusHidden;
	}

	public String getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}

	public static Comparator<UnderWriterDiarySearchResBO> underWriterDiarySearchResComparator 
			= new Comparator<UnderWriterDiarySearchResBO>() {

		public int compare(UnderWriterDiarySearchResBO res1, UnderWriterDiarySearchResBO res2) {
			//ascending order
			return res1.autoCloseDays-res2.autoCloseDays;
		}

	};
	public String getProductTowerName() {
		return productTowerName;
	}
	public void setProductTowerName(String productTowerName) {
		this.productTowerName = productTowerName;
	}
	
	public String getExtDayCount() {
		return extDayCount;
	}
	public void setExtDayCount(String extDayCount) {
		this.extDayCount = extDayCount;
	}
	public String getProducerEntityCd() {
		return producerEntityCd;
	}
	public void setProducerEntityCd(String producerEntityCd) {
		this.producerEntityCd = producerEntityCd;
	}
	public String getAttachmentPointAmt() {
		return attachmentPointAmt;
	}
	public void setAttachmentPointAmt(String attachmentPointAmt) {
		this.attachmentPointAmt = attachmentPointAmt;
	}
	public String getCurrencyCode() {
		return currencyCode;
	}
	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}
	public String getLimitAmt() {
		return limitAmt;
	}
	public void setLimitAmt(String limitAmt) {
		this.limitAmt = limitAmt;
	}
	public String getPremiumAmt() {
		return premiumAmt;
	}
	public void setPremiumAmt(String premiumAmt) {
		this.premiumAmt = premiumAmt;
	}
	public String getTransactionComponentId() {
		return transactionComponentId;
	}
	public void setTransactionComponentId(String transactionComponentId) {
		this.transactionComponentId = transactionComponentId;
	}
	public String getComponentProductTowerCd() {
		return componentProductTowerCd;
	}
	public void setComponentProductTowerCd(String componentProductTowerCd) {
		this.componentProductTowerCd = componentProductTowerCd;
	}
	public String getComponentSegmentCd() {
		return componentSegmentCd;
	}
	public void setComponentSegmentCd(String componentSegmentCd) {
		this.componentSegmentCd = componentSegmentCd;
	}
	public String getComponentSubSegmentCd() {
		return componentSubSegmentCd;
	}
	public void setComponentSubSegmentCd(String componentSubSegmentCd) {
		this.componentSubSegmentCd = componentSubSegmentCd;
	}
	public String getComponentProductTowerNm() {
		return componentProductTowerNm;
	}
	public void setComponentProductTowerNm(String componentProductTowerNm) {
		this.componentProductTowerNm = componentProductTowerNm;
	}	
}
