package com.aig.nge.bo;

public class AdditionalInsuredBO {
	
	private String transactionId;
	private String versionId;
	private String productTabKey;
	private String componentProductTabKey;
	private String accountNo;
	private String mdmPartyId; //2021 MDM

	private String accountName;
	private String attributeAction;
	private String accountType;
	private String address;
	private String organization;
	private String processingInd;
	/*July 2017 Maintenance Release - Inactive Account - Starts*/
	private String status;
	/*July 2017 Maintenance Release - Inactive Account - Ends*/
	
	public String getProcessingInd() {
		return processingInd;
	}
	public void setProcessingInd(String processingInd) {
		this.processingInd = processingInd;
	}
	public String getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}
	public String getAccountName() {
		return accountName;
	}
	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}
	/**
	 * @return the attributeAction
	 */
	public String getAttributeAction() {
		return attributeAction;
	}
	/**
	 * @param attributeAction the attributeAction to set
	 */
	public void setAttributeAction(String attributeAction) {
		this.attributeAction = attributeAction;
	}
	/**
	 * @return the productTabKey
	 */
	public String getProductTabKey() {
		return productTabKey;
	}
	/**
	 * @param productTabKey the productTabKey to set
	 */
	public void setProductTabKey(String productTabKey) {
		this.productTabKey = productTabKey;
	}
	/**
	 * @return the componentProductTabKey
	 */
	public String getComponentProductTabKey() {
		return componentProductTabKey;
	}
	/**
	 * @param componentProductTabKey the componentProductTabKey to set
	 */
	public void setComponentProductTabKey(String componentProductTabKey) {
		this.componentProductTabKey = componentProductTabKey;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getOrganization() {
		return organization;
	}
	public void setOrganization(String organization) {
		this.organization = organization;
	}
	public String getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	public String getVersionId() {
		return versionId;
	}
	public void setVersionId(String versionId) {
		this.versionId = versionId;
	}
	/*July 2017 Maintenance Release - Inactive Account - Starts*/
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	/*July 2017 Maintenance Release - Inactive Account - Ends*/
	public String getMdmPartyId() {
		return mdmPartyId;
	}
	public void setMdmPartyId(String mdmPartyId) {
		this.mdmPartyId = mdmPartyId;
	}
}
