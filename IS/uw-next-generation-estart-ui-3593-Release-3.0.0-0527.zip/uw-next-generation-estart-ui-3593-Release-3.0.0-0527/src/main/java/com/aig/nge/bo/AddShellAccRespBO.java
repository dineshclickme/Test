package com.aig.nge.bo;


public class AddShellAccRespBO {
	private AddShellAccountResultsBO addShellAccountResults;
    private MessErrBO messages;
    private MessErrBO errors;
    private String masterConditionCode;
	/**
	 * @return the addShellAccountResults
	 */
	public AddShellAccountResultsBO getAddShellAccountResults() {
		return addShellAccountResults;
	}
	/**
	 * @param addShellAccountResults the addShellAccountResults to set
	 */
	public void setAddShellAccountResults(
			AddShellAccountResultsBO addShellAccountResults) {
		this.addShellAccountResults = addShellAccountResults;
	}
	/**
	 * @return the messages
	 */
	public MessErrBO getMessages() {
		return messages;
	}
	/**
	 * @param messages the messages to set
	 */
	public void setMessages(MessErrBO messages) {
		this.messages = messages;
	}
	/**
	 * @return the errors
	 */
	public MessErrBO getErrors() {
		return errors;
	}
	/**
	 * @param errors the errors to set
	 */
	public void setErrors(MessErrBO errors) {
		this.errors = errors;
	}
	/**
	 * @return the masterConditionCode
	 */
	public String getMasterConditionCode() {
		return masterConditionCode;
	}
	/**
	 * @param masterConditionCode the masterConditionCode to set
	 */
	public void setMasterConditionCode(String masterConditionCode) {
		this.masterConditionCode = masterConditionCode;
	}
}
