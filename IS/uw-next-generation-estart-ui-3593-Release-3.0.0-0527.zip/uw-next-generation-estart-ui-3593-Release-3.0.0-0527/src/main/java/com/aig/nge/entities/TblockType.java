package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Set;


/**
 * The persistent class for the TBLOCK_TYPE database table.
 * 
 */
@Entity
@Table(name="TBLOCK_TYPE")
public class TblockType implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="BLOCK_TYPE_ID")
	private short blockTypeId;

	@Column(name="BLOCK_TYPE_DS")
	private String blockTypeDs;

	@Column(name="CREATE_TS")
	private Timestamp createTs;

	@Column(name="CREATE_USER_ID")
	private String createUserId;

	@Column(name="UPDATE_TS")
	private Timestamp updateTs;

	@Column(name="UPDATE_USER_ID")
	private String updateUserId;

	//bi-directional many-to-one association to Tblock
	@OneToMany(mappedBy="tblockType", cascade={CascadeType.ALL})
	private Set<Tblock> tblocks;

    public TblockType() {
    }

	public short getBlockTypeId() {
		return this.blockTypeId;
	}

	public void setBlockTypeId(short blockTypeId) {
		this.blockTypeId = blockTypeId;
	}

	public String getBlockTypeDs() {
		return this.blockTypeDs;
	}

	public void setBlockTypeDs(String blockTypeDs) {
		this.blockTypeDs = blockTypeDs;
	}

	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public Set<Tblock> getTblocks() {
		return this.tblocks;
	}

	public void setTblocks(Set<Tblock> tblocks) {
		this.tblocks = tblocks;
	}
	
}