package com.aig.nge.bo;

import java.util.List;

import com.aig.nge.bo.RowBO;

public class FindAccountResultsBO {
    private List<RowBO> row;
    private String count;
	/**
	 * @return the row
	 */
	public List<RowBO> getRow() {
		return row;
	}
	/**
	 * @param row the row to set
	 */
	public void setRow(List<RowBO> row) {
		this.row = row;
	}
	/**
	 * @return the count
	 */
	public String getCount() {
		return count;
	}
	/**
	 * @param count the count to set
	 */
	public void setCount(String count) {
		this.count = count;
	}
}
