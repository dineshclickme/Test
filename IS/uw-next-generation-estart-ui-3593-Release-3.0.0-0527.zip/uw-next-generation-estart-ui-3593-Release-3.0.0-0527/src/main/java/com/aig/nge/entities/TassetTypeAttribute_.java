package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-04-15T15:31:46.589+0530")
@StaticMetamodel(TassetTypeAttribute.class)
public class TassetTypeAttribute_ {
	public static volatile SingularAttribute<TassetTypeAttribute, TassetTypeAttributePK> id;
	public static volatile SingularAttribute<TassetTypeAttribute, String> attributeVal;
	public static volatile SingularAttribute<TassetTypeAttribute, Timestamp> createTs;
	public static volatile SingularAttribute<TassetTypeAttribute, String> createUserId;
	public static volatile SingularAttribute<TassetTypeAttribute, Timestamp> updateTs;
	public static volatile SingularAttribute<TassetTypeAttribute, String> updateUserId;
	public static volatile SingularAttribute<TassetTypeAttribute, TassetType> tassetType;
	public static volatile SingularAttribute<TassetTypeAttribute, Tattribute> tattribute;
}
