package com.aig.nge.accountservice;

import javax.naming.InitialContext;
import javax.naming.NamingException;

import java.net.URL;

import javax.xml.namespace.QName;
import javax.xml.transform.Source;
import javax.xml.ws.BindingProvider;
import javax.xml.ws.Dispatch;
import javax.xml.ws.Service;
import javax.xml.ws.soap.SOAPBinding;
import javax.xml.ws.Holder;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;


public class AccountServiceSOAPProxy{
    //TCS CE Team Changes Starts Here
    private static final Logger logger = LogManager.getLogger(AccountServiceSOAPProxy.class);
    //TCS CE Team Changes Ends Here

    protected Descriptor _descriptor;


    public class Descriptor {
        private  AccountServiceV1 _service = null;
        private AccountService _proxy = null;
        private Dispatch<Source> _dispatch = null;
        private boolean _useJNDIOnly = false;

        public Descriptor() {
            init();
        }

        public Descriptor(URL wsdlLocation, QName serviceName) {
            _service = new com.aig.nge.accountservice.AccountServiceV1(wsdlLocation, serviceName);
            initCommon();
        }

        public void init() {
            _service = null;
            _proxy = null;
            _dispatch = null;
            try
            {
                InitialContext ctx = new InitialContext();
                _service = (com.aig.nge.accountservice.AccountServiceV1)ctx.lookup("service/AccountServiceV1");
            }
            catch (NamingException e)
            {
                if ("true".equalsIgnoreCase(System.getProperty("DEBUG_PROXY"))) {
                    //System.out.println("JNDI lookup failure: javax.naming.NamingException: " + e.getMessage());
                	logger.info("Porxy Debugging");
                    e.printStackTrace(System.out);
                }
            }

            if (_service == null && !_useJNDIOnly)
                _service = new com.aig.nge.accountservice.AccountServiceV1();
            initCommon();
        }

        private void initCommon() {
            _proxy = _service.getAccountServiceSOAP();
        }

        public com.aig.nge.accountservice.AccountService getProxy() {
            return _proxy;
        }

        public void useJNDIOnly(boolean useJNDIOnly) {
            _useJNDIOnly = useJNDIOnly;
            init();
        }

        public Dispatch<Source> getDispatch() {
            if (_dispatch == null ) {
                QName portQName = new QName("http://www.aig.com/AccountServiceV1/", "AccountServiceSOAP");
                _dispatch = _service.createDispatch(portQName, Source.class, Service.Mode.MESSAGE);

                String proxyEndpointUrl = getEndpoint();
                BindingProvider bp = _dispatch;
                String dispatchEndpointUrl = (String) bp.getRequestContext().get(BindingProvider.ENDPOINT_ADDRESS_PROPERTY);
                if (!dispatchEndpointUrl.equals(proxyEndpointUrl))
                    bp.getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, proxyEndpointUrl);
            }
            return _dispatch;
        }

        public String getEndpoint() {
            BindingProvider bp = (BindingProvider) _proxy;
            return (String) bp.getRequestContext().get(BindingProvider.ENDPOINT_ADDRESS_PROPERTY);
        }

        public void setEndpoint(String endpointUrl) {
            BindingProvider bp = (BindingProvider) _proxy;
            bp.getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, endpointUrl);

            if (_dispatch != null ) {
                bp = _dispatch;
                bp.getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, endpointUrl);
            }
        }

        public void setMTOMEnabled(boolean enable) {
            SOAPBinding binding = (SOAPBinding) ((BindingProvider) _proxy).getBinding();
            binding.setMTOMEnabled(enable);
        }
    }

    public AccountServiceSOAPProxy() {
        _descriptor = new Descriptor();
        _descriptor.setMTOMEnabled(false);
    }

    public AccountServiceSOAPProxy(URL wsdlLocation, QName serviceName) {
        _descriptor = new Descriptor(wsdlLocation, serviceName);
        _descriptor.setMTOMEnabled(false);
    }

    public Descriptor _getDescriptor() {
        return _descriptor;
    }

    public void getAccount(AccountServiceRequestHeader getAccountRequestHeader, GetAccountRequest getAccountRequestParameters, Holder<AccountServiceResponseHeader> getAccountResponseHeader, Holder<GetAccountResponse> getAccountResponseParameters) throws AccountServiceExceptionMsg {
        _getDescriptor().getProxy().getAccount(getAccountRequestHeader,getAccountRequestParameters,getAccountResponseHeader,getAccountResponseParameters);
    }

    public void findAccount(AccountServiceRequestHeader findAccountRequestHeader, FindAccountRequest findAccountRequestParameters, Holder<AccountServiceResponseHeader> findAccountResponseHeader, Holder<FindAccountResponse> findAccountResponseParameters) throws AccountServiceExceptionMsg {
        _getDescriptor().getProxy().findAccount(findAccountRequestHeader,findAccountRequestParameters,findAccountResponseHeader,findAccountResponseParameters);
    }

    public void addShellAccount(AccountServiceRequestHeader addShellAccountRequestHeader, AddShellRequest addShellAccountRequestParameters, Holder<AccountServiceResponseHeader> addShellAccountResponseHeader, Holder<AddShellResponse> addShellAccountResponseParameters) throws AccountServiceExceptionMsg {
        _getDescriptor().getProxy().addShellAccount(addShellAccountRequestHeader,addShellAccountRequestParameters,addShellAccountResponseHeader,addShellAccountResponseParameters);
    }

    public void addFeinToDnb(AccountServiceRequestHeader addFeinToDnbRequestHeader, AddFeinToDnbRequest addFeinToDnbRequestParameters, Holder<AccountServiceResponseHeader> addFeinToDnbResponseHeader, Holder<AddFeinToDnbResponse> addFeinToDnbResponseParameters) throws AccountServiceExceptionMsg {
        _getDescriptor().getProxy().addFeinToDnb(addFeinToDnbRequestHeader,addFeinToDnbRequestParameters,addFeinToDnbResponseHeader,addFeinToDnbResponseParameters);
    }

    public void getEbxAccount(AccountServiceRequestHeader getEbxAccountRequestHeader, GetEbxAccountRequest getEbxAccountRequestParameters, Holder<AccountServiceResponseHeader> getEbxAccountResponseHeader, Holder<GetEbxAccountResponse> getEbxAccountResponseParameters) throws AccountServiceExceptionMsg {
        _getDescriptor().getProxy().getEbxAccount(getEbxAccountRequestHeader,getEbxAccountRequestParameters,getEbxAccountResponseHeader,getEbxAccountResponseParameters);
    }

    public void getAigActivity(AccountServiceRequestHeader getAigActivityRequestHeader, GetAigActivityRequest getAigActivityRequestParameters, Holder<AccountServiceResponseHeader> getAigActivityResponseHeader, Holder<GetAigActivityResponse> getAigActivityResponseParameters) throws AccountServiceExceptionMsg {
        _getDescriptor().getProxy().getAigActivity(getAigActivityRequestHeader,getAigActivityRequestParameters,getAigActivityResponseHeader,getAigActivityResponseParameters);
    }

}