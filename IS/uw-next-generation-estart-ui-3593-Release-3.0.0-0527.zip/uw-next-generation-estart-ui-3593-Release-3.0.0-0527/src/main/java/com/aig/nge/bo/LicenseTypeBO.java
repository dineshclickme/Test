package com.aig.nge.bo;

import java.util.List;

public class LicenseTypeBO {

	private List<AppointmentInfoTypeBO> appointmentInfo;
	private String assignCd;
	private String licenseEffDt;
	private String licenseeNm;
	private String licenseExpDt;
	private String licenseInd;
	private String licenseNo;
	private String licenseReceivedDt;
	private String licenseStateCd;
	private String licenseStatusCd;
	private String licenseStatusDt;
	private String licenseTypeCd;
	private String lineOfBusinessCd;
	private List<QualificationInfoTypeBO> qualifications;
	private String residentInd;
	private String updateTimeStamp;
	private String updateUserID;
	/**
	 * @return the appointmentInfo
	 */
	public List<AppointmentInfoTypeBO> getAppointmentInfo() {
		return appointmentInfo;
	}
	/**
	 * @param appointmentInfo the appointmentInfo to set
	 */
	public void setAppointmentInfo(List<AppointmentInfoTypeBO> appointmentInfo) {
		this.appointmentInfo = appointmentInfo;
	}
	/**
	 * @return the assignCd
	 */
	public String getAssignCd() {
		return assignCd;
	}
	/**
	 * @param assignCd the assignCd to set
	 */
	public void setAssignCd(String assignCd) {
		this.assignCd = assignCd;
	}
	/**
	 * @return the licenseEffDt
	 */
	public String getLicenseEffDt() {
		return licenseEffDt;
	}
	/**
	 * @param licenseEffDt the licenseEffDt to set
	 */
	public void setLicenseEffDt(String licenseEffDt) {
		this.licenseEffDt = licenseEffDt;
	}
	/**
	 * @return the licenseeNm
	 */
	public String getLicenseeNm() {
		return licenseeNm;
	}
	/**
	 * @param licenseeNm the licenseeNm to set
	 */
	public void setLicenseeNm(String licenseeNm) {
		this.licenseeNm = licenseeNm;
	}
	/**
	 * @return the licenseExpDt
	 */
	public String getLicenseExpDt() {
		return licenseExpDt;
	}
	/**
	 * @param licenseExpDt the licenseExpDt to set
	 */
	public void setLicenseExpDt(String licenseExpDt) {
		this.licenseExpDt = licenseExpDt;
	}
	/**
	 * @return the licenseInd
	 */
	public String getLicenseInd() {
		return licenseInd;
	}
	/**
	 * @param licenseInd the licenseInd to set
	 */
	public void setLicenseInd(String licenseInd) {
		this.licenseInd = licenseInd;
	}
	/**
	 * @return the licenseNo
	 */
	public String getLicenseNo() {
		return licenseNo;
	}
	/**
	 * @param licenseNo the licenseNo to set
	 */
	public void setLicenseNo(String licenseNo) {
		this.licenseNo = licenseNo;
	}
	/**
	 * @return the licenseReceivedDt
	 */
	public String getLicenseReceivedDt() {
		return licenseReceivedDt;
	}
	/**
	 * @param licenseReceivedDt the licenseReceivedDt to set
	 */
	public void setLicenseReceivedDt(String licenseReceivedDt) {
		this.licenseReceivedDt = licenseReceivedDt;
	}
	/**
	 * @return the licenseStateCd
	 */
	public String getLicenseStateCd() {
		return licenseStateCd;
	}
	/**
	 * @param licenseStateCd the licenseStateCd to set
	 */
	public void setLicenseStateCd(String licenseStateCd) {
		this.licenseStateCd = licenseStateCd;
	}
	/**
	 * @return the licenseStatusCd
	 */
	public String getLicenseStatusCd() {
		return licenseStatusCd;
	}
	/**
	 * @param licenseStatusCd the licenseStatusCd to set
	 */
	public void setLicenseStatusCd(String licenseStatusCd) {
		this.licenseStatusCd = licenseStatusCd;
	}
	/**
	 * @return the licenseStatusDt
	 */
	public String getLicenseStatusDt() {
		return licenseStatusDt;
	}
	/**
	 * @param licenseStatusDt the licenseStatusDt to set
	 */
	public void setLicenseStatusDt(String licenseStatusDt) {
		this.licenseStatusDt = licenseStatusDt;
	}
	/**
	 * @return the licenseTypeCd
	 */
	public String getLicenseTypeCd() {
		return licenseTypeCd;
	}
	/**
	 * @param licenseTypeCd the licenseTypeCd to set
	 */
	public void setLicenseTypeCd(String licenseTypeCd) {
		this.licenseTypeCd = licenseTypeCd;
	}
	/**
	 * @return the lineOfBusinessCd
	 */
	public String getLineOfBusinessCd() {
		return lineOfBusinessCd;
	}
	/**
	 * @param lineOfBusinessCd the lineOfBusinessCd to set
	 */
	public void setLineOfBusinessCd(String lineOfBusinessCd) {
		this.lineOfBusinessCd = lineOfBusinessCd;
	}
	/**
	 * @return the qualifications
	 */
	public List<QualificationInfoTypeBO> getQualifications() {
		return qualifications;
	}
	/**
	 * @param qualifications the qualifications to set
	 */
	public void setQualifications(List<QualificationInfoTypeBO> qualifications) {
		this.qualifications = qualifications;
	}
	/**
	 * @return the residentInd
	 */
	public String getResidentInd() {
		return residentInd;
	}
	/**
	 * @param residentInd the residentInd to set
	 */
	public void setResidentInd(String residentInd) {
		this.residentInd = residentInd;
	}
	/**
	 * @return the updateTimeStamp
	 */
	public String getUpdateTimeStamp() {
		return updateTimeStamp;
	}
	/**
	 * @param updateTimeStamp the updateTimeStamp to set
	 */
	public void setUpdateTimeStamp(String updateTimeStamp) {
		this.updateTimeStamp = updateTimeStamp;
	}
	/**
	 * @return the updateUserID
	 */
	public String getUpdateUserID() {
		return updateUserID;
	}
	/**
	 * @param updateUserID the updateUserID to set
	 */
	public void setUpdateUserID(String updateUserID) {
		this.updateUserID = updateUserID;
	}
	
}
