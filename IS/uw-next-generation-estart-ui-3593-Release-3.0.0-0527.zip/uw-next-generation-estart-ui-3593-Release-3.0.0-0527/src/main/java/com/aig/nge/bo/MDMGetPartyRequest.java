package com.aig.nge.bo;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL) 
public class MDMGetPartyRequest {
	/* F56355 - Modify request parameter names for MDM services - starts */
	private String originatingsystem;
	private String originuser;
	/* F56355 - Modify request parameter names for MDM services - ends */
	private String searchcriteria;
	private String searchtext;
	private String legacycountryflag;
	
	/* F56355 - Modify request parameter names for MDM services - starts */
	
	public String getOriginatingsystem() {
		return originatingsystem;
	}

	public void setOriginatingsystem(String originatingsystem) {
		this.originatingsystem = originatingsystem;
	}
	
	public String getOriginuser() {
		return originuser;
	}

	public void setOriginuser(String originuser) {
		this.originuser = originuser;
	}
   /* F56355 - Modify request parameter names for MDM services - ends */
	
	public String getSearchcriteria() {
		return searchcriteria;
	}
	public void setSearchcriteria(String searchcriteria) {
		this.searchcriteria = searchcriteria;
	}
	public String getSearchtext() {
		return searchtext;
	}
	public void setSearchtext(String searchtext) {
		this.searchtext = searchtext;
	}
	public String getLegacycountryflag() {
		return legacycountryflag;
	}
	public void setLegacycountryflag(String legacycountryflag) {
		this.legacycountryflag = legacycountryflag;
	}

/*
	@Override
	public String toString() {
		return "RDMServiceResponse [count=" + count + ", metadata=" + metadata + ", totalRecords=" + totalRecords
				+ "]";
	}*/
}
