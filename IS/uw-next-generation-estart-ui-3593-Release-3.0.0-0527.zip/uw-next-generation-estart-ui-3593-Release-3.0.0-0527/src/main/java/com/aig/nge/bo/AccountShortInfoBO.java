package com.aig.nge.bo;


public class AccountShortInfoBO {
    private String accountNumber;
    private String resolvedDunsNumber;
    private String accountBusinessName;
    private String organization;
    private String activeIndicator;
    private String parentAccountNumber;
    private String topHQAccountNumber;
    private String accountType;
    private String treePosition;
    //MDM Changes - Starts
    protected String mdmPartyId;
    protected String resolvedMDMPartyId;
    protected String parentMDMPartyId;
    protected String topHQMDMPartyId;
    //MDM Changes - Ends
	/**
	 * @return the accountNumber
	 */
	public String getAccountNumber() {
		return accountNumber;
	}
	/**
	 * @param accountNumber the accountNumber to set
	 */
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	/**
	 * @return the resolvedDunsNumber
	 */
	public String getResolvedDunsNumber() {
		return resolvedDunsNumber;
	}
	/**
	 * @param resolvedDunsNumber the resolvedDunsNumber to set
	 */
	public void setResolvedDunsNumber(String resolvedDunsNumber) {
		this.resolvedDunsNumber = resolvedDunsNumber;
	}
	/**
	 * @return the accountBusinessName
	 */
	public String getAccountBusinessName() {
		return accountBusinessName;
	}
	/**
	 * @param accountBusinessName the accountBusinessName to set
	 */
	public void setAccountBusinessName(String accountBusinessName) {
		this.accountBusinessName = accountBusinessName;
	}
	/**
	 * @return the organization
	 */
	public String getOrganization() {
		return organization;
	}
	/**
	 * @param organization the organization to set
	 */
	public void setOrganization(String organization) {
		this.organization = organization;
	}
	/**
	 * @return the activeIndicator
	 */
	public String getActiveIndicator() {
		return activeIndicator;
	}
	/**
	 * @param activeIndicator the activeIndicator to set
	 */
	public void setActiveIndicator(String activeIndicator) {
		this.activeIndicator = activeIndicator;
	}
	/**
	 * @return the parentAccountNumber
	 */
	public String getParentAccountNumber() {
		return parentAccountNumber;
	}
	/**
	 * @param parentAccountNumber the parentAccountNumber to set
	 */
	public void setParentAccountNumber(String parentAccountNumber) {
		this.parentAccountNumber = parentAccountNumber;
	}
	/**
	 * @return the topHQAccountNumber
	 */
	public String getTopHQAccountNumber() {
		return topHQAccountNumber;
	}
	/**
	 * @param topHQAccountNumber the topHQAccountNumber to set
	 */
	public void setTopHQAccountNumber(String topHQAccountNumber) {
		this.topHQAccountNumber = topHQAccountNumber;
	}
	/**
	 * @return the accountType
	 */
	public String getAccountType() {
		return accountType;
	}
	/**
	 * @param accountType the accountType to set
	 */
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	/**
	 * @return the treePosition
	 */
	public String getTreePosition() {
		return treePosition;
	}
	/**
	 * @param treePosition the treePosition to set
	 */
	public void setTreePosition(String treePosition) {
		this.treePosition = treePosition;
	}
	//MDM Changes - Starts
	public String getMdmPartyId() {
		return mdmPartyId;
	}
	public void setMdmPartyId(String mdmPartyId) {
		this.mdmPartyId = mdmPartyId;
	}
	public String getResolvedMDMPartyId() {
		return resolvedMDMPartyId;
	}
	public void setResolvedMDMPartyId(String resolvedMDMPartyId) {
		this.resolvedMDMPartyId = resolvedMDMPartyId;
	}
	public String getParentMDMPartyId() {
		return parentMDMPartyId;
	}
	public void setParentMDMPartyId(String parentMDMPartyId) {
		this.parentMDMPartyId = parentMDMPartyId;
	}
	public String getTopHQMDMPartyId() {
		return topHQMDMPartyId;
	}
	public void setTopHQMDMPartyId(String topHQMDMPartyId) {
		this.topHQMDMPartyId = topHQMDMPartyId;
	}
	//MDM Changes - Starts
}
