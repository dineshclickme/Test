package com.aig.nge.bo;

import java.util.List;

public class AdditionalProducersJSONBO {
	private String dataKey;
	private String transaction;
	private String version;
	private String productId;
	private String mktProduct;
	private String subProduct;
	private String component;
	private List<AdditionalProducerBO> data;
	/**
	 * @return the dataKey
	 */
	public String getDataKey() {
		return dataKey;
	}
	/**
	 * @param dataKey the dataKey to set
	 */
	public void setDataKey(String dataKey) {
		this.dataKey = dataKey;
	}
	/**
	 * @return the transaction
	 */
	public String getTransaction() {
		return transaction;
	}
	/**
	 * @param transaction the transaction to set
	 */
	public void setTransaction(String transaction) {
		this.transaction = transaction;
	}
	/**
	 * @return the version
	 */
	public String getVersion() {
		return version;
	}
	/**
	 * @param version the version to set
	 */
	public void setVersion(String version) {
		this.version = version;
	}
	/**
	 * @return the productId
	 */
	public String getProductId() {
		return productId;
	}
	/**
	 * @param productId the productId to set
	 */
	public void setProductId(String productId) {
		this.productId = productId;
	}
	/**
	 * @return the mktProduct
	 */
	public String getMktProduct() {
		return mktProduct;
	}
	/**
	 * @param mktProduct the mktProduct to set
	 */
	public void setMktProduct(String mktProduct) {
		this.mktProduct = mktProduct;
	}
	/**
	 * @return the subProduct
	 */
	public String getSubProduct() {
		return subProduct;
	}
	/**
	 * @param subProduct the subProduct to set
	 */
	public void setSubProduct(String subProduct) {
		this.subProduct = subProduct;
	}
	/**
	 * @return the component
	 */
	public String getComponent() {
		return component;
	}
	/**
	 * @param component the component to set
	 */
	public void setComponent(String component) {
		this.component = component;
	}
	/**
	 * @return the data
	 */
	public List<AdditionalProducerBO> getData() {
		return data;
	}
	/**
	 * @param data the data to set
	 */
	public void setData(List<AdditionalProducerBO> data) {
		this.data = data;
	}
}
