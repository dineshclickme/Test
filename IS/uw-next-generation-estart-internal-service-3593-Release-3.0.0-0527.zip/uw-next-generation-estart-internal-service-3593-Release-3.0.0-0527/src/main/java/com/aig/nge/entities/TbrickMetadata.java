package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the TBRICK_METADATA database table.
 * 
 */
@Entity
@Table(name="TBRICK_METADATA")
public class TbrickMetadata implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="BRICK_METADATA_ID")
	private int brickMetadataId;

	@Column(name="BRICK_METADATA_KEY_CD")
	private String brickMetadataKeyCd;

    @Lob()
	@Column(name="BRICK_METADATA_OB")
	private String brickMetadataOb;

	@Column(name="CREATE_TS")
	private Timestamp createTs;

	@Column(name="CREATE_USER_ID")
	private String createUserId;

	@Column(name="UPDATE_TS")
	private Timestamp updateTs;

	@Column(name="UPDATE_USER_ID")
	private String updateUserId;

    public TbrickMetadata() {
    }

	public int getBrickMetadataId() {
		return this.brickMetadataId;
	}

	public void setBrickMetadataId(int brickMetadataId) {
		this.brickMetadataId = brickMetadataId;
	}

	public String getBrickMetadataKeyCd() {
		return this.brickMetadataKeyCd;
	}

	public void setBrickMetadataKeyCd(String brickMetadataKeyCd) {
		this.brickMetadataKeyCd = brickMetadataKeyCd;
	}

	public String getBrickMetadataOb() {
		return this.brickMetadataOb;
	}

	public void setBrickMetadataOb(String brickMetadataOb) {
		this.brickMetadataOb = brickMetadataOb;
	}

	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

}