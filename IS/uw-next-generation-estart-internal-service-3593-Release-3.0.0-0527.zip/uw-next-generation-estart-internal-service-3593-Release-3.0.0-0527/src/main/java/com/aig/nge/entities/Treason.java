package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;

import org.apache.openjpa.persistence.DataCache;
import java.sql.Timestamp;
import java.util.Set;


/**
 * The persistent class for the TREASON database table.
 * 
 */
@Entity
@DataCache
public class Treason implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="REASON_ID")
	private short reasonId;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="CREATE_TS")
	private Timestamp createTs;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="CREATE_USER_ID")
	private String createUserId;

	@Column(name="DELETED_IN")
	private String deletedIn;

	@Column(name="REASON_DS")
	private String reasonDs;

	@Column(name="REASON_NM")
	private String reasonNm;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="UPDATE_TS")
	private Timestamp updateTs;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="UPDATE_USER_ID")
	private String updateUserId;

	//bi-directional many-to-one association to Tblock
	@OneToMany(mappedBy="treason", cascade={CascadeType.ALL})
	private Set<Tblock> tblocks;

	//bi-directional many-to-one association to TproductTowerReason
	@OneToMany(mappedBy="treason", cascade={CascadeType.ALL})
	private Set<TproductTowerReason> tproductTowerReasons;

	//bi-directional many-to-one association to TreasonType
	@ManyToOne
	@JoinColumn(name="REASON_TYPE_ID")
	private TreasonType treasonType;

	//bi-directional many-to-one association to TtransactionComponentStatus
	@OneToMany(mappedBy="treason", cascade={CascadeType.ALL})
	private Set<TtransactionComponentStatus> ttransactionComponentStatuses;

    public Treason() {
    }

	public short getReasonId() {
		return this.reasonId;
	}

	public void setReasonId(short reasonId) {
		this.reasonId = reasonId;
	}

	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public String getDeletedIn() {
		return this.deletedIn;
	}

	public void setDeletedIn(String deletedIn) {
		this.deletedIn = deletedIn;
	}

	public String getReasonDs() {
		return this.reasonDs;
	}

	public void setReasonDs(String reasonDs) {
		this.reasonDs = reasonDs;
	}

	public String getReasonNm() {
		if(this.reasonNm != null)
			return this.reasonNm.trim();
		else
			return this.reasonNm;
	}

	public void setReasonNm(String reasonNm) {
		this.reasonNm = reasonNm;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public Set<Tblock> getTblocks() {
		return this.tblocks;
	}

	public void setTblocks(Set<Tblock> tblocks) {
		this.tblocks = tblocks;
	}
	
	public Set<TproductTowerReason> getTproductTowerReasons() {
		return this.tproductTowerReasons;
	}

	public void setTproductTowerReasons(Set<TproductTowerReason> tproductTowerReasons) {
		this.tproductTowerReasons = tproductTowerReasons;
	}
	
	public TreasonType getTreasonType() {
		return this.treasonType;
	}

	public void setTreasonType(TreasonType treasonType) {
		this.treasonType = treasonType;
	}
	
	public Set<TtransactionComponentStatus> getTtransactionComponentStatuses() {
		return this.ttransactionComponentStatuses;
	}

	public void setTtransactionComponentStatuses(Set<TtransactionComponentStatus> ttransactionComponentStatuses) {
		this.ttransactionComponentStatuses = ttransactionComponentStatuses;
	}
	
}