package com.aig.nge.entities;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;
import javax.annotation.Generated;
import javax.persistence.metamodel.SetAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-08-04T13:12:21.347+0530")
@StaticMetamodel(TlegacySubmissionExtension.class)
public class TlegacySubmissionExtension_ {
	public static volatile SingularAttribute<TlegacySubmissionExtension, String> submissionNo;
	public static volatile SingularAttribute<TlegacySubmissionExtension, BigDecimal> aigPc;
	public static volatile SingularAttribute<TlegacySubmissionExtension, BigDecimal> brokerPc;
	public static volatile SingularAttribute<TlegacySubmissionExtension, BigDecimal> coinsuranceCd;
	public static volatile SingularAttribute<TlegacySubmissionExtension, Timestamp> createTs;
	public static volatile SingularAttribute<TlegacySubmissionExtension, String> createUserId;
	public static volatile SingularAttribute<TlegacySubmissionExtension, String> displayCurrencyCd;
	public static volatile SingularAttribute<TlegacySubmissionExtension, String> fedrlEmplrIdNo;
	public static volatile SingularAttribute<TlegacySubmissionExtension, String> geoTeamIn;
	public static volatile SingularAttribute<TlegacySubmissionExtension, BigDecimal> heronPc;
	public static volatile SingularAttribute<TlegacySubmissionExtension, String> publicEntityIn;
	public static volatile SingularAttribute<TlegacySubmissionExtension, Date> sbmnReceivedDt;
	public static volatile SingularAttribute<TlegacySubmissionExtension, Timestamp> updateTs;
	public static volatile SingularAttribute<TlegacySubmissionExtension, String> updateUserId;
	public static volatile SingularAttribute<TlegacySubmissionExtension, Tproforma> tproforma;
	public static volatile SingularAttribute<TlegacySubmissionExtension, Tsubmission> tsubmission;
	public static volatile SingularAttribute<TlegacySubmissionExtension, String> commentTx;
	public static volatile SingularAttribute<TlegacySubmissionExtension, String> sbmnCntryCd;
	public static volatile SetAttribute<TlegacySubmissionExtension, TlegacySubmissionAddlInfo> tlegacySubmissionAddlInfos;
	public static volatile SingularAttribute<TlegacySubmissionExtension, String> creditedBranchCd;
	public static volatile SingularAttribute<TlegacySubmissionExtension, String> domesticXpsrIn;
	public static volatile SingularAttribute<TlegacySubmissionExtension, String> foreignXpsrIn;
}
