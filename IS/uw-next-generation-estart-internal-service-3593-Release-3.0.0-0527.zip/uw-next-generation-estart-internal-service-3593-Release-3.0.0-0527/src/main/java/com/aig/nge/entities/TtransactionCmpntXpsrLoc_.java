package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-02-24T11:59:50.518+0530")
@StaticMetamodel(TtransactionCmpntXpsrLoc.class)
public class TtransactionCmpntXpsrLoc_ {
	public static volatile SingularAttribute<TtransactionCmpntXpsrLoc, TtransactionCmpntXpsrLocPK> id;
	public static volatile SingularAttribute<TtransactionCmpntXpsrLoc, Timestamp> createTs;
	public static volatile SingularAttribute<TtransactionCmpntXpsrLoc, String> createUserId;
	public static volatile SingularAttribute<TtransactionCmpntXpsrLoc, String> deletedIn;
	public static volatile SingularAttribute<TtransactionCmpntXpsrLoc, Short> systemId;
	public static volatile SingularAttribute<TtransactionCmpntXpsrLoc, Timestamp> updateTs;
	public static volatile SingularAttribute<TtransactionCmpntXpsrLoc, String> updateUserId;
	public static volatile SingularAttribute<TtransactionCmpntXpsrLoc, Tlocation> tlocation;
	public static volatile SingularAttribute<TtransactionCmpntXpsrLoc, TtransactionComponent> ttransactionComponent;
	public static volatile SingularAttribute<TtransactionCmpntXpsrLoc, String> excludeIn;
}
