package com.aig.nge.dao;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.xml.datatype.XMLGregorianCalendar;

import org.owasp.esapi.ESAPI;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.aig.nge.entities.TcompnentStatusAttribute;
import com.aig.nge.entities.Tcurrency;
import com.aig.nge.entities.TlegacyWipQuote;
import com.aig.nge.entities.TlegacyWipQuoteCurrency;
import com.aig.nge.entities.TlegacyWipQuoteCurrencyPK;
import com.aig.nge.entities.TlegacyWipQuotePK;
import com.aig.nge.entities.Tpolicy;
import com.aig.nge.entities.TpolicyType;
import com.aig.nge.entities.Tsystem;
import com.aig.nge.entities.TtransactionComponent;
import com.aig.nge.entities.TtransactionComponentAtrbt;
import com.aig.nge.entities.TtransactionComponentLimit;
import com.aig.nge.entities.TtransactionComponentRltn;
import com.aig.nge.entities.TtransactionComponentStatus;
import com.aig.nge.helper.CommonServiceHelper;
import com.aig.nge.helper.HistoryHelper;
import com.aig.nge.helper.ProductHelper;
import com.aig.nge.repository.TLegacyWIPQuoteHsRepository;
import com.aig.nge.repository.TLegacyWipQuoteRepository;
import com.aig.nge.repository.TSystemRepository;
import com.aig.nge.repository.TTransactionComponentAtrbtRepository;
import com.aig.nge.repository.TTransactionComponentLimitRepository;
import com.aig.nge.repository.TTransactionComponentRelationRepository;
import com.aig.nge.repository.TTransactionComponentRepository;
import com.aig.nge.repository.TTransactionComponentStatusRepository;
import com.aig.nge.repository.TlegacyWipQuoteCurrencyRepository;
import com.aig.nge.utilities.AIGCIExceptionMsg;
import com.aig.nge.utilities.CurrencyConversionDynaCache;
import com.aig.nge.utilities.LegacyValidations;
import com.aig.nge.utilities.NGECommonUtil;
import com.aig.nge.utilities.NGEConstants;
import com.aig.nge.utilities.NGEDateUtil;
import com.aig.nge.utilities.NGEErrorCodes;
import com.aig.nge.utilities.NGEException;
import com.aig.nge.utilities.NGESession;
import com.aig.nge.utilities.NGEValidations;
import com.aig.nge.wsdl.skeleton.PolicyDetails;
import com.aig.nge.wsdl.skeleton.ReopenProduct;
import com.aig.nge.wsdl.skeleton.WIPQuoteDetails;import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
/**
 * @author Padma This DAO class is used for accessing the 
 * legacy wip quote repository functions
 */
@Repository
public class LegacyWipDAO {

	@Autowired
	private LegacyValidations legacyValidations;

	@Autowired
	private TLegacyWipQuoteRepository tLegacyWipQuoteRepository;

	@Autowired
	private TlegacyWipQuoteCurrencyRepository tlegacyWipQuoteCurrencyRepository; 

	@Autowired
	private TLegacyWIPQuoteHsRepository tLegacyWIPQuoteHsRepository;

/*	@Autowired
	private TlegacyWipQuoteCurrencyHsRepository tlegacyWipQuoteCurrencyHsRepository;*/

	@Autowired
	private NGEException ngeException;

	@Autowired
	private CommonDAO commonDAO;

	@Autowired
	private CurrencyConversionDynaCache cache;

	@Autowired
	private PolicyDAO policyDAO;
	
	@Autowired
	private ProductHelper productHelper;

	@Autowired
	private TTransactionComponentAtrbtRepository transactionComponentAtrbtRepository;

	@Autowired
	private TTransactionComponentLimitRepository transactionComponentLimitRepository;
	
	@Autowired
	private TTransactionComponentRepository ttransactionComponentRepository;
	
	@Autowired
	private TTransactionComponentStatusRepository transactionComponentstatusRepository;
	
	@Autowired
	private TSystemRepository tSystemRepository;
	
	@Autowired
	private HistoryHelper historyHelper;
	
	@Autowired
	private TTransactionComponentRelationRepository transactionComponentRelationRepository;
	
	
	/*@Autowired
	private TSystemRepository tSystemRepository;*/
	
	@Autowired
	private NGEValidations ngeValidations;

	/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
	@Autowired
	private CommonServiceHelper commonServiceHelper;
	/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */

    @Autowired
    private TransactionComponentDAO transactionComponentDAO;

	private static final Logger logger = LogManager.getLogger(LegacyWipDAO.class);


	public List<TlegacyWipQuote> getWIPQuoteDetails(String transactionComponentId) 
	{
		List<TlegacyWipQuote> tlegacyWipQuotes = null;
		tlegacyWipQuotes = tLegacyWipQuoteRepository.findByTransactionComponentId(transactionComponentId);
		return tlegacyWipQuotes;
	}

	public List<TlegacyWipQuoteCurrency> getTlegacyWipQuoteCurrencyDetails(
			String transactionComponentId, String wipId, short quoteSqn) {
		List<TlegacyWipQuoteCurrency> legacyWipQuoteCurrencies = new ArrayList<TlegacyWipQuoteCurrency>();
		legacyWipQuoteCurrencies = tlegacyWipQuoteCurrencyRepository.findByTransCompIdAndWipIdAndQuoteSqn(transactionComponentId, wipId, quoteSqn);
		return legacyWipQuoteCurrencies;
	}

	public List<TlegacyWipQuote> getWIPQuote(String transactionComponentId, int policyId) 
	{
		List<TlegacyWipQuote> tlegacyWipQuote = null;
		tlegacyWipQuote = tLegacyWipQuoteRepository.findByTransactionComponentIdAndPolicyId(transactionComponentId, policyId);
		return tlegacyWipQuote;
	}

	public List<TlegacyWipQuote> getWIPQuoteInBind(String transactionComponentId, int policyId, List<String> statusList) 
	{
		List<TlegacyWipQuote> tlegacyWipQuoteList = null;
		tlegacyWipQuoteList = tLegacyWipQuoteRepository.findByTransactionComponentIdAndPolicyWIPStatus(transactionComponentId, policyId, statusList, NGEConstants.YES);
		return tlegacyWipQuoteList;
	}

	public List<TlegacyWipQuote> getWIPQuoteDetails(String transactionComponentId, String wipId) 
	{
		List<TlegacyWipQuote> tlegacyWipQuotesList = null;		
		tlegacyWipQuotesList = transactionComponentDAO.findByTransCompIdandWipId(transactionComponentId, NGECommonUtil.convertToString(wipId));
		return tlegacyWipQuotesList;
	}

	public TlegacyWipQuote saveLegacyWipQuote(TlegacyWipQuote legacyWipQuote) {
		TlegacyWipQuote legacyWipQuoteData = new TlegacyWipQuote();
		
		/* Exadata changes - Not null issue starts */
		
		if(legacyWipQuote.getWinningCarrierNm()!=null){
			if(legacyWipQuote.getWinningCarrierNm().trim().equals(NGEConstants.EMPTY_STRING))
				legacyWipQuote.setWinningCarrierNm(NGEConstants.EMPTY_SPACE);
		}		
		
		if(legacyWipQuote.getAccountLegalNm() != null){
			if(legacyWipQuote.getAccountLegalNm().trim().equals(NGEConstants.EMPTY_STRING))
				legacyWipQuote.setAccountLegalNm(NGEConstants.EMPTY_SPACE);
		}
		
		if(legacyWipQuote.getAcctngPolPrfxCd() != null){
			if(legacyWipQuote.getAcctngPolPrfxCd().trim().equals(NGEConstants.EMPTY_STRING))
				legacyWipQuote.setAcctngPolPrfxCd(NGEConstants.EMPTY_SPACE);
		}
		
		if(legacyWipQuote.getLossrsnAdlcmtsTx() != null){
			if(legacyWipQuote.getLossrsnAdlcmtsTx().trim().equals(NGEConstants.EMPTY_STRING))
				legacyWipQuote.setLossrsnAdlcmtsTx(NGEConstants.EMPTY_SPACE);
		}
		
		if(legacyWipQuote.getMasterContractNo() != null){
			if(legacyWipQuote.getMasterContractNo().trim().equals(NGEConstants.EMPTY_STRING))
				legacyWipQuote.setMasterContractNo(NGEConstants.EMPTY_SPACE);
		}
		
		if(legacyWipQuote.getNonRenewalReasonCd() != null){
			if(legacyWipQuote.getNonRenewalReasonCd().trim().equals(NGEConstants.EMPTY_STRING))
				legacyWipQuote.setNonRenewalReasonCd(NGEConstants.EMPTY_SPACE);
		}
		
		if(legacyWipQuote.getReasonCd() != null){
			if(legacyWipQuote.getReasonCd().trim().equals(NGEConstants.EMPTY_STRING))
				legacyWipQuote.setReasonCd(NGEConstants.EMPTY_SPACE);
		}
		
		/* Exadata changes - Not null issue ends */
		
		legacyWipQuoteData = tLegacyWipQuoteRepository.save(legacyWipQuote);
		return legacyWipQuoteData;
	}

	/**
	 * @author Prabha
	 * @param wipDetailsData
	 * @param transactionComponentForWip
	 * @param lifeCycleStatus
	 * @param exsitingLifeCycleStatus
	 * @throws AIGCIExceptionMsg
	 */
	public void updateWipDetails(WIPQuoteDetails wipDetailsData, TtransactionComponent transactionComponentForWip, String lifeCycleStatus,String exsitingLifeCycleStatus) throws AIGCIExceptionMsg {

		TlegacyWipQuote legacyWipQuoteData = new TlegacyWipQuote();
		List<TlegacyWipQuote> legacyWipQuoteListData = new ArrayList<TlegacyWipQuote>();
		List<TlegacyWipQuote> leagacyWipQuoteWithSystemId = new ArrayList<TlegacyWipQuote>();
		List<TlegacyWipQuote> leagacyWipQuoteWithOutSystemId = new ArrayList<TlegacyWipQuote>();
		List<TlegacyWipQuote> leagacyWipQuoteListForQuote = new ArrayList<TlegacyWipQuote>();
		List<TlegacyWipQuoteCurrency> leagacyWipQuoteListForCurrency = new ArrayList<TlegacyWipQuoteCurrency>();
		TlegacyWipQuote  legacyWipQuoteRetrivedData = new TlegacyWipQuote();
		TlegacyWipQuotePK legacyWipQuotePKData = new TlegacyWipQuotePK();
		//TlegacyWipQuoteCurrency legacyWipQuoteCurrency = new TlegacyWipQuoteCurrency();	
		List<TlegacyWipQuoteCurrency> legacyWipQuoteCurrencyList = new ArrayList<TlegacyWipQuoteCurrency>();	
		String transactionComponentId = NGEConstants.EMPTY_STRING;
		String wipId = NGEConstants.EMPTY_STRING;
		//String systemNm = NGEConstants.EMPTY_STRING;
		short uwSystemId = NGESession.getSessionData().getSystem().getSystemId();
		//List<Tsystem> systemData = tSystemRepository.findBySystemId(uwSystemId);
		//if(systemData!=null){
		//	systemNm = systemData.get(0).getSystemShortNm();
		//}
		String userId = NGESession.getSessionData().getUserId();
		transactionComponentId = transactionComponentForWip.getTransactionComponentId();
		legacyWipQuotePKData.setTransactionComponentId(transactionComponentId);
		legacyWipQuotePKData.setQuoteSqn(NGEConstants.ONE_SHORT);
/*		legacyWipQuoteData.setCreateTs(NGEDateUtil.getTodayDate());
		legacyWipQuoteData.setCreateUserId(userId);*/
		List<Tsystem> systemData =  new ArrayList<Tsystem>();			
		systemData = tSystemRepository.findBySystemId(NGESession.getSessionData().getSystem().getSystemId());
		
//		legacyWipQuoteData.setTsystem(systemData.get(0));
		legacyWipQuoteData.setUwSystemID(uwSystemId);

		if(exsitingLifeCycleStatus.equalsIgnoreCase(NGEConstants.LifeCycleStatus.WORKING) && lifeCycleStatus.equalsIgnoreCase(NGEConstants.LifeCycleStatus.QUOTED) ){

			wipId = "1";
			
			if(wipDetailsData != null){
				
				if(wipDetailsData.getWIPId()!=null)
					legacyWipQuotePKData.setWipId(wipDetailsData.getWIPId());
			}
			else
				legacyWipQuotePKData.setWipId(wipId);
			
			if(legacyWipQuotePKData.getWipId() == null || legacyWipQuotePKData.getWipId().equalsIgnoreCase(""))
			{
				legacyWipQuotePKData.setWipId(wipId);
			}
			
			//Open Item - Same wip id should not be inserted  during renewal for the same product.It should be incremented. 
			if(legacyWipQuotePKData.getWipId().equalsIgnoreCase("1"))
			{
				List<TtransactionComponentRltn> transactionComponentRltnList = transactionComponentRelationRepository.findByTransactionComponentId(transactionComponentId);
				
				if(transactionComponentRltnList.size() > 0)
				{
					if(transactionComponentRltnList.get(0).getTcomponentRelationType().getRelationTypeNm().equalsIgnoreCase(NGEConstants.RelationTypeName.RENEWALPRODUCT))
					{
						legacyWipQuoteListData = tLegacyWipQuoteRepository.findByTransactionComponentId(transactionComponentRltnList.get(0).getTtransactionComponent2().getTransactionComponentId());
						
						 for(TlegacyWipQuote legacyWIPQuote1: legacyWipQuoteListData){
							//Abul Added Starts
						historyHelper.createTlegacyWipQuoteHHistory(legacyWIPQuote1);
						//Abul Added Ends
						 }
								
						wipId = generateWipId(legacyWipQuoteListData);
						legacyWipQuotePKData.setWipId(wipId);
					}
				}
			}

			
			/*historyHelper.createTlegacyWipQuoteHHistory(legacyWipQuoteData);*/
			
			legacyWipQuoteData.setId(legacyWipQuotePKData);
			

			legacyWipQuoteData.setCreateTs(NGEDateUtil.getTodayDate());
			legacyWipQuoteData.setCreateUserId(userId);
			//legacyWipQuoteData.setTsystem(systemData.get(0));
			legacyWipQuoteData.setUwSystemID(NGESession.getSessionData().getSystem().getSystemId());

				callUpdateWipDetailsFromNGETables(transactionComponentForWip,wipDetailsData,lifeCycleStatus, legacyWipQuoteData);



		}
		else if(exsitingLifeCycleStatus.equalsIgnoreCase(NGEConstants.LifeCycleStatus.QUOTED)&& lifeCycleStatus.equalsIgnoreCase(NGEConstants.LifeCycleStatus.WORKING)){
			deleteWIPDetails( wipDetailsData, legacyWipQuotePKData,  transactionComponentId,  legacyWipQuoteCurrencyList,  leagacyWipQuoteListForQuote,legacyWipQuoteRetrivedData,leagacyWipQuoteListForCurrency);//PI3 Maintenance Release 2.16 release - Remove WIP when changing the status from Quoted to void 
		}
		
		else if(exsitingLifeCycleStatus.equalsIgnoreCase(NGEConstants.LifeCycleStatus.QUOTED)&& lifeCycleStatus.equalsIgnoreCase(NGEConstants.LifeCycleStatus.LOST) ){
			
			legacyWipQuoteData = findWipQuoteList(legacyWipQuoteData,transactionComponentId,wipDetailsData,NGEConstants.LegacyWIPStatusCd.QUOTE);
		
			if(legacyWipQuoteData != null){
				//Abul Added Starts
				historyHelper.createTlegacyWipQuoteHHistory(legacyWipQuoteData);
				//Abul Added Ends
				legacyWipQuoteData.setUpdateTs(NGEDateUtil.getTodayDate());
				legacyWipQuoteData.setUpdateUserId(NGESession.getSessionData().getUserId());
				// Setting the System Id
//				legacyWipQuoteData.setTsystem(systemData.get(0));
				legacyWipQuoteData.setUwSystemID(NGESession.getSessionData().getSystem().getSystemId());

				callUpdateWipDetailsFromNGETables(transactionComponentForWip,wipDetailsData,lifeCycleStatus, legacyWipQuoteData);
			}
			else{
				/* PI3 - Q3 2018 Maintenance Release 2.12 - Ensure to Bind all components in a bundle - Starts */
				logger.error("LegacyWipDAO - Debug - 1");
				/* PI3 - Q3 2018 Maintenance Release 2.12 - Ensure to Bind all components in a bundle - Ends */
				ngeException.throwException(NGEErrorCodes.SERVICE_FAILED,NGEErrorCodes.ERROR_TYPE, null, null);
			}
		}
		else if(exsitingLifeCycleStatus.equalsIgnoreCase(NGEConstants.LifeCycleStatus.LOST)&& lifeCycleStatus.equalsIgnoreCase(NGEConstants.LifeCycleStatus.QUOTED)){
			if(wipDetailsData!=null && wipDetailsData.getWIPId()!=null && wipDetailsData.getWIPId().trim().length() != 0){
				
					wipId = wipDetailsData.getWIPId();
					
					if(wipDetailsData.getQuoteSqn() != null){
						
						short quoteSqn = 0; 
						quoteSqn = wipDetailsData.getQuoteSqn();
						
						legacyWipQuotePKData.setWipId(wipId);
						legacyWipQuotePKData.setQuoteSqn(quoteSqn);
						legacyWipQuotePKData.setTransactionComponentId(transactionComponentId);
						
						legacyWipQuoteRetrivedData = tLegacyWipQuoteRepository.findOne(legacyWipQuotePKData);
					}
					else{
						List<TlegacyWipQuote> legacyWipQuoteList = new ArrayList<TlegacyWipQuote>();
						legacyWipQuoteList = tLegacyWipQuoteRepository.findByTransactionComponentIdandWipId(transactionComponentId, wipId);
						if(!legacyWipQuoteList.isEmpty()){
							
							legacyWipQuoteRetrivedData = legacyWipQuoteList.get(0);
							legacyWipQuotePKData.setWipId(legacyWipQuoteRetrivedData.getId().getWipId());
							legacyWipQuotePKData.setQuoteSqn(legacyWipQuoteRetrivedData.getId().getQuoteSqn());
							legacyWipQuotePKData.setTransactionComponentId(legacyWipQuoteRetrivedData.getId().getTransactionComponentId());
						}
					}
						
					//Abul Added Starts
					historyHelper.createTlegacyWipQuoteHHistory(legacyWipQuoteData);
					//Abul Added Ends
					if(legacyWipQuoteRetrivedData!=null){
						legacyWipQuoteData.setUpdateTs(NGEDateUtil.getTodayDate());
						legacyWipQuoteData.setUpdateUserId(NGESession.getSessionData().getUserId());						
						// Setting the System Id
						//legacyWipQuoteData.setTsystem(systemData.get(0));
						legacyWipQuoteData.setUwSystemID(NGESession.getSessionData().getSystem().getSystemId());
						
						legacyWipQuoteData.setId(legacyWipQuotePKData);
						legacyWipQuoteCurrencyList = tlegacyWipQuoteCurrencyRepository.findByTransCompIdandWipId(transactionComponentId, wipDetailsData.getWIPId());
						//insertWipQuoteAndCurrencyDetailsToHistoryTable(legacyWipQuoteRetrivedData,legacyWipQuoteCurrencyList);	
					}else{
						legacyWipQuoteData.setCreateTs(NGEDateUtil.getTodayDate());
						legacyWipQuoteData.setCreateUserId(NGESession.getSessionData().getUserId());
						// Setting the System Id
						//legacyWipQuoteData.setTsystem(systemData.get(0));
						legacyWipQuoteData.setUwSystemID(NGESession.getSessionData().getSystem().getSystemId());
						
						legacyWipQuoteData.setId(legacyWipQuotePKData);
					}	
			}
			else{
				
				//retrieves the WIP records for the corresponding transactionComponentId
				legacyWipQuoteListData = tLegacyWipQuoteRepository.findByTransCompId(transactionComponentId, NGEConstants.LegacyWIPStatusCd.LOST);
				//Abul Added Starts
				historyHelper.createTlegacyWipQuoteHHistory(legacyWipQuoteData);
				//Abul Added Ends
				
				
				
				//If the list has only one record , then the related WIP ID is fetched
				if(legacyWipQuoteListData!= null && legacyWipQuoteListData.size()== NGEConstants.ONE_SHORT ){
					
					for(TlegacyWipQuote wipQuoteItr2 :legacyWipQuoteListData ){
						
						legacyWipQuotePKData.setWipId(wipQuoteItr2.getId().getWipId());
						legacyWipQuotePKData.setQuoteSqn(wipQuoteItr2.getId().getQuoteSqn());
						legacyWipQuoteCurrencyList = tlegacyWipQuoteCurrencyRepository.findByTransCompIdandWipId(wipQuoteItr2.getId().getTransactionComponentId(),wipQuoteItr2.getId().getWipId());
						//Abul Added Starts
						historyHelper.createTlegacyWipQuoteHHistory(wipQuoteItr2);
						//Abul Added Ends
						//insertWipQuoteAndCurrencyDetailsToHistoryTable(wipQuoteItr2,legacyWipQuoteCurrencyList);
					}
					legacyWipQuoteData.setId(legacyWipQuotePKData);
					legacyWipQuoteData.setUpdateTs(NGEDateUtil.getTodayDate());
					legacyWipQuoteData.setUpdateUserId(NGESession.getSessionData().getUserId());
					// Setting the System Id
					//legacyWipQuoteData.setTsystem(systemData.get(0));
					legacyWipQuoteData.setUwSystemID(NGESession.getSessionData().getSystem().getSystemId());
				}
				
				//If the list has more than one record , then the related WIPId is fetched
				else if(legacyWipQuoteListData!= null && legacyWipQuoteListData.size()> NGEConstants.ONE_SHORT){
					
						//Retrieves transactionComponentId is having the wip records for the the incoming underwriting system ID
						leagacyWipQuoteWithSystemId = tLegacyWipQuoteRepository.findByTransCompIdAndUWSystemId(transactionComponentId, uwSystemId,NGEConstants.LegacyWIPStatusCd.LOST);
						//If WIP record is present , the least time stamp record is fetched the WIP ID value is retrieved 
						if(leagacyWipQuoteWithSystemId != null && leagacyWipQuoteWithSystemId.size()>0){
							findWipQuoteDetailsWithOldestTimestamp(legacyWipQuoteData,legacyWipQuotePKData,leagacyWipQuoteWithSystemId);
						}
						//If WIP record is not present for incoming system ID, the least time stamp record is fetched among other system IDs and he WIP ID value is retrieved 
						else{
							leagacyWipQuoteWithOutSystemId = tLegacyWipQuoteRepository.findByTransCompIdAndExcludingUWSystemId(transactionComponentId, uwSystemId, NGEConstants.LegacyWIPStatusCd.QUOTE);
							if(leagacyWipQuoteWithSystemId != null){
								findWipQuoteDetailsWithOldestTimestamp(legacyWipQuoteData,legacyWipQuotePKData,leagacyWipQuoteWithOutSystemId);
							}
						}
					
				}
				//If the list contains no records , new WIP is created
				else{
					legacyWipQuoteListData = tLegacyWipQuoteRepository.findByTransactionComponentId(transactionComponentId);
					//Abul Added Starts
					historyHelper.createTlegacyWipQuoteHHistory(legacyWipQuoteData);
					//Abul Added Ends
					
					
					if(legacyWipQuoteListData==null){
						long wipIdLong = 1;
						wipId = Long.toString(wipIdLong);
					}
					else {
						wipId = generateWipId(legacyWipQuoteListData);
					}
					legacyWipQuotePKData.setWipId(wipId);
					
					//Open Item - Same wip id should not be inserted  during renewal for the same product.It should be incremented. 
					if(legacyWipQuotePKData.getWipId().equalsIgnoreCase("1"))
					{
						List<TtransactionComponentRltn> transactionComponentRltnList = transactionComponentRelationRepository.findByTransactionComponentId(transactionComponentId);
						
						if(transactionComponentRltnList.size() > 0)
						{
							if(transactionComponentRltnList.get(0).getTcomponentRelationType().getRelationTypeNm().equalsIgnoreCase(NGEConstants.RelationTypeName.RENEWALPRODUCT))
							{
								legacyWipQuoteListData = tLegacyWipQuoteRepository.findByTransactionComponentId(transactionComponentRltnList.get(0).getTtransactionComponent2().getTransactionComponentId());
								wipId = generateWipId(legacyWipQuoteListData);
								legacyWipQuotePKData.setWipId(wipId);
							}
						}
					}
					legacyWipQuotePKData.setQuoteSqn(NGEConstants.ONE_SHORT);
					legacyWipQuoteData.setId(legacyWipQuotePKData);		
					legacyWipQuoteData.setCreateTs(NGEDateUtil.getTodayDate());
					legacyWipQuoteData.setCreateUserId(NGESession.getSessionData().getUserId());
					// Setting the System Id
					//legacyWipQuoteData.setTsystem(systemData.get(0));
					legacyWipQuoteData.setUwSystemID(NGESession.getSessionData().getSystem().getSystemId());
				}
			}

			callUpdateWipDetailsFromNGETables(transactionComponentForWip,wipDetailsData,lifeCycleStatus, legacyWipQuoteData);
		}
		else if(exsitingLifeCycleStatus.equalsIgnoreCase(NGEConstants.LifeCycleStatus.BOUND)&& lifeCycleStatus.equalsIgnoreCase(NGEConstants.LifeCycleStatus.CANCELLED)){
			
			List<String> statusCdList = new ArrayList<String>();
			statusCdList.add(NGEConstants.LegacyWIPStatusCd.BOUND);
			statusCdList.add(NGEConstants.LegacyWIPStatusCd.BOOK);
			String reasonCd = NGEConstants.EMPTY_STRING;
			legacyWipQuoteListData = tLegacyWipQuoteRepository.findByTransactionComponentIdAndWipStatusCd(transactionComponentId, statusCdList);
					if(legacyWipQuoteListData!=null){
						
						for(TlegacyWipQuote  legacyWipQuoteListItr : legacyWipQuoteListData){
																	
							// TtransactionComponentStatus transactionComponentStatus = transactionComponentstatusRepository.findByTransactionComponentIdAndStatusType(transactionComponentForWip.getTransactionComponentId(), NGEConstants.StatusType.LIFECYCLE_STATUS);
                            TtransactionComponentStatus transactionComponentStatus = transactionComponentDAO.findByTransactionComponentIdAndStatusType(transactionComponentForWip.getTransactionComponentId(), NGEConstants.StatusType.LIFECYCLE_STATUS);
							reasonCd = transactionComponentStatus.getTreason().getReasonNm();

						/*	//Abul Added Starts
							historyHelper.createTlegacyWipQuoteHHistory(legacyWipQuoteData);
							//Abul Added Ends
*/
							//Abul Added Starts
							historyHelper.createTlegacyWipQuoteHHistory(legacyWipQuoteListItr);
							//Abul Added Ends
							legacyWipQuoteListItr.setUpdateTs(NGEDateUtil.getTodayDate());
							legacyWipQuoteListItr.setUpdateUserId(NGESession.getSessionData().getUserId());
							// Setting the System Id
							//legacyWipQuoteListItr.setTsystem(systemData.get(0));
							legacyWipQuoteData.setUwSystemID(NGESession.getSessionData().getSystem().getSystemId());
							legacyWipQuoteListItr.setReasonCd(reasonCd);
							/*F46227-US245579-eStart-Correct Business type for Cancelled policies-starts*/
							logger.info("Business type update logic call for incoming cancelled lifecycle status");
							/*F46227-US245579-eStart-Correct Business type for Cancelled policies-ends*/
							callUpdateWipDetailsFromNGETables(transactionComponentForWip,wipDetailsData,lifeCycleStatus, legacyWipQuoteListItr);
						}
					}
			
		}
		/*PI3 Maintenance Release 2.16 release - Remove WIP when changing the status from Quoted to void starts */
		else if(exsitingLifeCycleStatus.equalsIgnoreCase(NGEConstants.LifeCycleStatus.QUOTED)&& lifeCycleStatus.equalsIgnoreCase(NGEConstants.LifeCycleStatus.VOID)){
			deleteWIPDetails( wipDetailsData, legacyWipQuotePKData,  transactionComponentId,  legacyWipQuoteCurrencyList,  leagacyWipQuoteListForQuote,legacyWipQuoteRetrivedData,leagacyWipQuoteListForCurrency);//PI3 Maintenance Release 2.16 release - Remove WIP whe chnaging te status from Quoted to void
		}
		/*PI3 Maintenance Release 2.16 release - Remove WIP when changing the status from Quoted to void */
	}
	private void findWipQuoteDetailsWithOldestTimestamp(TlegacyWipQuote legacyWipQuoteData,TlegacyWipQuotePK legacyWipQuotePKData,List<TlegacyWipQuote> leagacyWipQuoteWithSystemId) throws AIGCIExceptionMsg {
		
		String wipId = NGEConstants.EMPTY_STRING;
		List<Tsystem> systemData =  new ArrayList<Tsystem>();			
		systemData = tSystemRepository.findBySystemId(NGESession.getSessionData().getSystem().getSystemId());
		/*TlegacyWipQuote  legacyWipQuoteRetrivedData = new TlegacyWipQuote();
		List<TlegacyWipQuoteCurrency> legacyWipQuoteCurrencyList = new ArrayList<TlegacyWipQuoteCurrency>();*/
		
		
		
		wipId = getOldestTimeStamp(leagacyWipQuoteWithSystemId);
		legacyWipQuotePKData.setWipId(wipId);
		
		//Abul Added Starts
		legacyWipQuoteData = tLegacyWipQuoteRepository.findOne(legacyWipQuotePKData);
		historyHelper.createTlegacyWipQuoteHHistory(legacyWipQuoteData);
		//Abul Added Ends
		
		legacyWipQuoteData.setId(legacyWipQuotePKData);
		legacyWipQuoteData.setUpdateTs(NGEDateUtil.getTodayDate());
		legacyWipQuoteData.setUpdateUserId(NGESession.getSessionData().getUserId());
		// Setting the System Id
		//legacyWipQuoteData.setTsystem(systemData.get(0));
		legacyWipQuoteData.setUwSystemID(NGESession.getSessionData().getSystem().getSystemId());
		
		//legacyWipQuoteRetrivedData = tLegacyWipQuoteRepository.findByTransCompIdandWipId(legacyWipQuotePKData.getTransactionComponentId(), wipId);	
		//legacyWipQuoteCurrencyList = tlegacyWipQuoteCurrencyRepository.findByTransCompIdandWipId(legacyWipQuotePKData.getTransactionComponentId(), wipId);
		
		//insertWipQuoteAndCurrencyDetailsToHistoryTable(legacyWipQuoteRetrivedData,legacyWipQuoteCurrencyList);
		
		
	}

/*	private void insertWipQuoteAndCurrencyDetailsToHistoryTable(TlegacyWipQuote legacyWipQuoteRetrivedData,List<TlegacyWipQuoteCurrency> legacyWipQuoteCurrencyList) {
	
		if(legacyWipQuoteRetrivedData!=null){
			tLegacyWIPQuoteHsRepository.insertLegacyWIPQuoteHistory(legacyWipQuoteRetrivedData.getId().getTransactionComponentId(),
				legacyWipQuoteRetrivedData.getId().getWipId(),legacyWipQuoteRetrivedData.getId().getQuoteSqn());
		}
		else{
			//handle exception
		}
		if(legacyWipQuoteCurrencyList!=null){
			
			for (TlegacyWipQuoteCurrency legacyWipQuoteCurrency:legacyWipQuoteCurrencyList){
				tlegacyWipQuoteCurrencyHsRepository.insertLegacyWIPQuoteCurrencyHistory(legacyWipQuoteCurrency.getId().getTransactionComponentId(),
				legacyWipQuoteCurrency.getId().getWipId(),legacyWipQuoteCurrency.getId().getQuoteSqn());
			}
		}
		else{
			//handle exception
		}
		
	}*/

	private TlegacyWipQuote findWipQuoteList(TlegacyWipQuote legacyWipQuoteData,
			String transactionComponentId,WIPQuoteDetails wipDetailsData, String lifeCycleStatus) {
			
		List<TlegacyWipQuote> legacyWipQuoteListData = new ArrayList<TlegacyWipQuote>();
		TlegacyWipQuotePK legacyWipQuotePKData = new TlegacyWipQuotePK();
		//List<TlegacyWipQuoteCurrency> legacyWipQuoteCurrencyList = new ArrayList<TlegacyWipQuoteCurrency>();		
		
		String wipId = null;
        
        if(wipDetailsData != null)
        {
              wipId = wipDetailsData.getWIPId();
              
              if(wipId != null && wipId.isEmpty())
              {
                    wipId = null;     
              }
        }
        
        if(wipId != null){

			legacyWipQuoteListData = tLegacyWipQuoteRepository.findByTransCompIdWipIdStatusId(transactionComponentId, lifeCycleStatus, NGECommonUtil.convertToString(wipId));
		}
		else{
			legacyWipQuoteListData = tLegacyWipQuoteRepository.findByTransCompId(transactionComponentId, lifeCycleStatus);
		}
		
        TlegacyWipQuote legacyWipQuote = null;
		if(legacyWipQuoteListData!= null && legacyWipQuoteListData.size()>= NGEConstants.ONE_SHORT ){
			for(TlegacyWipQuote wipQuoteItr2 :legacyWipQuoteListData ){
				legacyWipQuotePKData.setTransactionComponentId(transactionComponentId);
				legacyWipQuotePKData.setQuoteSqn(wipQuoteItr2.getId().getQuoteSqn());
				legacyWipQuotePKData.setWipId(wipQuoteItr2.getId().getWipId());
				legacyWipQuote = wipQuoteItr2;
				//legacyWipQuoteCurrencyList = tlegacyWipQuoteCurrencyRepository.findByTransCompIdandWipId(transactionComponentId, wipQuoteItr2.getId().getWipId());
				//insertWipQuoteAndCurrencyDetailsToHistoryTable(wipQuoteItr2,legacyWipQuoteCurrencyList);
			}
			//legacyWipQuoteData.setId(legacyWipQuotePKData);
			
		}
		return legacyWipQuote;
		
	}
	/**
	 * @author Prabha
	 * @param transactionComponentForWip
	 * @param wipDetailsData
	 * @param lifeCycleStatus
	 * @param legacyWipQuoteData
	 * @param userId
	 * @throws AIGCIExceptionMsg
	 */
	private void callUpdateWipDetailsFromNGETables(	TtransactionComponent transactionComponentForWip,WIPQuoteDetails wipDetailsData,String lifeCycleStatus,TlegacyWipQuote legacyWipQuoteData) throws AIGCIExceptionMsg {

		Set<TtransactionComponentLimit> limitList = new HashSet<TtransactionComponentLimit>();
		//Set<TtransactionComponentStatus> statusList = new HashSet<TtransactionComponentStatus>();
	/*	Set<TlegacyWipQuoteCurrency> wipQuoteCurrencyList = new HashSet<TlegacyWipQuoteCurrency>();
		
	TlegacyWipQuoteCurrency wipQuoteCurrencyData = new TlegacyWipQuoteCurrency();
	TlegacyWipQuoteCurrencyPK wipQuoteCurrencyPKData = new TlegacyWipQuoteCurrencyPK();
	TlegacyWipQuoteCurrency legacyWipQuoteCurrencyLocal = new TlegacyWipQuoteCurrency();
	String localCurrencyCd = NGEConstants.EMPTY_STRING;
	Tcurrency currency = null;
	BigDecimal limitAmt = new BigDecimal(0);;
	BigDecimal attachmentPointAmt = new BigDecimal(0);
	BigDecimal premiumAmt = new BigDecimal(0) ;*/
	//BigDecimal limitAmtInUSD = new BigDecimal(0);
	//BigDecimal attachmentPointAmtInUSD = new BigDecimal(0) ;
	//BigDecimal premiumAmtInUSD = new BigDecimal(0);
		BigDecimal rate = new BigDecimal("1");
	//String aigCurrencyCd = NGEConstants.EMPTY_STRING;
	//HashMap<String, BigDecimal> sourceMap = null;
	/*short currencyId = NGEConstants.ZERO_SHORT;*/
	//Tcurrency currencyData = new Tcurrency();
		String reasonCd = NGEConstants.EMPTY_STRING;
		String commentTx = NGEConstants.EMPTY_STRING;
		Date expiration = null;
		Tpolicy priorPolicyInfo = null;
		
	legacyWipQuoteData.setTtransactionComponent(transactionComponentForWip)	;
	limitList = transactionComponentForWip.getTtransactionComponentLimits();
		//statusList = transactionComponentForWip.getTtransactionComponentStatuses();
	
		//TtransactionComponentStatus transactionComponentStatus = transactionComponentstatusRepository.findByTransactionComponentIdAndStatusType(transactionComponentForWip.getTransactionComponentId(), NGEConstants.StatusType.LIFECYCLE_STATUS);
        TtransactionComponentStatus transactionComponentStatus = transactionComponentDAO.findByTransactionComponentIdAndStatusType(transactionComponentForWip.getTransactionComponentId(), NGEConstants.StatusType.LIFECYCLE_STATUS);
		
		if(transactionComponentStatus.getTreason()!=null){
			reasonCd = transactionComponentStatus.getTreason().getReasonNm();
			commentTx = transactionComponentStatus.getCommentTx();
		}
			
		
		legacyWipQuoteData.setTtransactionComponent(transactionComponentForWip)	;
			if(lifeCycleStatus.equalsIgnoreCase(NGEConstants.LifeCycleStatus.QUOTED)){
				legacyWipQuoteData.setWipStatusCd(NGEConstants.LegacyWIPStatusCd.QUOTE);
				// Set REASON_CD and WINNING_CARRIER_NM as empty When status changes from Lost to Quote  
				legacyWipQuoteData.setReasonCd(NGEConstants.EMPTY_STRING);
				legacyWipQuoteData.setWinningCarrierNm(NGEConstants.EMPTY_STRING);
			}
		
			if(lifeCycleStatus.equalsIgnoreCase(NGEConstants.LifeCycleStatus.LOST)){
				legacyWipQuoteData.setWipStatusCd(NGEConstants.LegacyWIPStatusCd.LOST);	
				legacyWipQuoteData.setReasonCd(reasonCd);
				legacyWipQuoteData.setLossrsnAdlcmtsTx(commentTx);
				//Defect #894 -To set winning carrier in TlegacyWipquote table
				if(transactionComponentStatus.getTcompnentStatusAttributes() !=null){
				Set<TcompnentStatusAttribute>  tcompnentStatusAttributeSet = transactionComponentStatus.getTcompnentStatusAttributes();
				
				for (TcompnentStatusAttribute tcompnentStatusAttribute:tcompnentStatusAttributeSet)
				{
					if(tcompnentStatusAttribute.getTattribute().getAttributeNm().equalsIgnoreCase(NGEConstants.WINNING_CARRIER))
						legacyWipQuoteData.setWinningCarrierNm(tcompnentStatusAttribute.getAttributeVal());		
				}
					
				}	
			}
			
			if(lifeCycleStatus.equalsIgnoreCase(NGEConstants.LifeCycleStatus.CANCELLED)){
				legacyWipQuoteData.setWipStatusCd(NGEConstants.LegacyWIPStatusCd.CANCELLED);	
				legacyWipQuoteData.setReasonCd(reasonCd);
				logger.debug("legacyWipQuoteData.setReasonCd(reasonCd)"+legacyWipQuoteData.getReasonCd());
			}
			
			legacyWipQuoteData.setStatusEnteredDt(NGEDateUtil.getTodayDate());
			
			//If lifeCycleStatus is cancelled, then don't update the QuoteAcceptedIn, Else update it.
			if(!lifeCycleStatus.equalsIgnoreCase(NGEConstants.LifeCycleStatus.CANCELLED))
			{
				if(lifeCycleStatus.equalsIgnoreCase(NGEConstants.LifeCycleStatus.BOUND)){
					legacyWipQuoteData.setQuoteAcceptedIn(NGEConstants.YES);
				}
				else{
					legacyWipQuoteData.setQuoteAcceptedIn(NGEConstants.NO);
				}
			}
			
		if(wipDetailsData!= null ){
			
			logger.debug("transactionComponentForWip.getTransactionComponentId()" +transactionComponentForWip.getTransactionComponentId() + "wipDetailsData - " + wipDetailsData.getBusinessTypeCode());
			
				if(wipDetailsData.getWIPSectionCd()!= null){
					legacyWipQuoteData.setSectionCd(wipDetailsData.getWIPSectionCd());
				}
						
				if(wipDetailsData.getWIPProfitUnitCd()!= null){
					legacyWipQuoteData.setProfitUnitCd(wipDetailsData.getWIPProfitUnitCd());
				}
			
				if(wipDetailsData.getWinningCarrierNm()!= null){
					legacyWipQuoteData.setWinningCarrierNm(wipDetailsData.getWinningCarrierNm());
				}
				
				if(wipDetailsData.getNonRenewalIn() != null){
					legacyWipQuoteData.setNonRenewalIn(wipDetailsData.getNonRenewalIn());
				}
				else if(getNonRenewalInd(transactionComponentForWip.getTransactionComponentId()))
				{
					legacyWipQuoteData.setNonRenewalIn(NGEConstants.YES);
				}
				else
				{
					legacyWipQuoteData.setNonRenewalIn(NGEConstants.NO);				
				}
				
				if(wipDetailsData.getNonRenewalRsnCd() != null){
					legacyWipQuoteData.setNonRenewalReasonCd(wipDetailsData.getNonRenewalRsnCd());
				}					
				
		
				if(wipDetailsData.getMasterContractNo()!=null){
					legacyWipQuoteData.setMasterContractNo(wipDetailsData.getMasterContractNo());
				}
		
				if(wipDetailsData.getQuoteEffectiveDt()!=null){
					legacyWipQuoteData.setQuoteEfctvDt(NGEDateUtil.getStringDate(wipDetailsData.getQuoteEffectiveDt()));
				}
		
				if(wipDetailsData.getQuoteExpDt()!= null){
					legacyWipQuoteData.setQuoteXprtnDt(NGEDateUtil.getStringDate(wipDetailsData.getQuoteExpDt()));
				}
				if(null != wipDetailsData.getPriorPolicyDetails())
                {
                      PolicyDetails priorPolicy = wipDetailsData.getPriorPolicyDetails();
                      Date effectiveDate = NGEDateUtil.getStringDate(priorPolicy.getEffectiveDt());
                      short issuingCompanyCd = 0;
                      Tpolicy priorPolicyData = null;
                      
                      try
                      {
                            issuingCompanyCd = (short) priorPolicy.getIssuingCompanyCd(); 
                      }
                      catch(ClassCastException e)
                      {
                            ngeException.throwException(NGEErrorCodes.INVALID_POLICY_ISS_COMP_CD,NGEErrorCodes.ERROR_TYPE, null, null);
                      }
                      if(null != priorPolicy.getPolicyNo() && null != priorPolicy.getEffectiveDt())
                      {
                            priorPolicyInfo = policyDAO.getPolicy(priorPolicy.getPolicyNo(), issuingCompanyCd, effectiveDate);
                            if(null != priorPolicyInfo)
                            {
                            	logger.debug("priorPolicyInfo.getPolicyId() already available"+priorPolicyInfo.getPolicyId());
                            	legacyWipQuoteData.setPriorPolicyId(priorPolicyInfo.getPolicyId());
                            }
                            else{
                            	
                            	// Create a new Prior Policy - Requested for Coexistence
                            	priorPolicyData = insertPriorPolicyInTPolicy(priorPolicy);
                            	if(priorPolicyData != null){
                            		
                            		logger.debug("priorPolicyInfo.getPolicyId() newly created"+priorPolicyData.getPolicyId());
                            		legacyWipQuoteData.setPriorPolicyId(priorPolicyData.getPolicyId());
                            	}
                            }
                      }
                      
                    if(null != wipDetailsData.getPolicyEventNo())
      				{
      					legacyWipQuoteData.setPolEventNo(wipDetailsData.getPolicyEventNo());
      				}
                    //Set POL_EVENT_NO as null if it is not passed 
      			 	else
      				{
      				legacyWipQuoteData.setPolEventNo(null);
      					
      				} 
      				
      				if(null != wipDetailsData.getAccountLegalNm())
      				{
      					legacyWipQuoteData.setAccountLegalNm(wipDetailsData.getAccountLegalNm());
      				}
      				if(null != wipDetailsData.getAccountingPolicyNo())
      				{
      					legacyWipQuoteData.setAccountingPolNo(wipDetailsData.getAccountingPolicyNo());
      				}
      				if(null != wipDetailsData.getAccountingPolPrefixCd())
      				{
      					legacyWipQuoteData.setAcctngPolPrfxCd(wipDetailsData.getAccountingPolPrefixCd());
      				}
      				
      				if(null != wipDetailsData.getReasonCd())  //test for empty string
      				{
      					legacyWipQuoteData.setReasonCd(wipDetailsData.getReasonCd());
      				}
      				
      				if(null != wipDetailsData.getPolicyDetails() &&  null != wipDetailsData.getPolicyDetails().getExpirationDt())
      				{
      					expiration = NGEDateUtil.getStringDate(wipDetailsData.getPolicyDetails().getExpirationDt());
      				}
      				else
      				{
      					
      				  if(null != priorPolicyInfo)
                      {
      					  expiration = NGEDateUtil.getStringDate(NGEDateUtil.convertDateToXMLGregorianCalendar(priorPolicyInfo.getExpirationDt()));
                      }
      				}
      				legacyWipQuoteData.setPolicyXprtnDt(expiration);
      		
      				if(null != wipDetailsData.getPolicyMailedDt())
      				{
      					legacyWipQuoteData.setPolicyMailedDt(NGEDateUtil.getStringDate(wipDetailsData.getPolicyMailedDt()));
      				}  
                }
				
				logger.debug("transactionComponentForWip.getTransactionComponentId()" +transactionComponentForWip.getTransactionComponentId());
				
  				if(wipDetailsData.getBusinessTypeCode()!=null){
  					legacyWipQuoteData.setBusinessTypeCd(wipDetailsData.getBusinessTypeCode());

  				}
  				else{
  					try{
						String transaCompId = transactionComponentForWip.getTransactionComponentId();
						//TtransactionComponent transCompData = ttransactionComponentRepository.findByTransactionComponentId(transaCompId);
                        TtransactionComponent transCompData = transactionComponentDAO.findByTransactionComponentIdForWIPS(transaCompId);
                        
						String businessType =  transCompData.getTproductState().getProductStateNm();
						logger.debug("businessType" +businessType);
						/*F46227-US245579-eStart-Correct Business type for Cancelled policies-starts*/						 
						if(!lifeCycleStatus.equalsIgnoreCase(NGEConstants.LifeCycleStatus.CANCELLED)){
							logger.info("Business type update logic for incoming cancelled lifecycle status"); 
							if(businessType.equalsIgnoreCase(NGEConstants.ProductState.NEW)){
								
								legacyWipQuoteData.setBusinessTypeCd(NGEConstants.BusinessTypeCd.NEW);
							}
							else{
								legacyWipQuoteData.setBusinessTypeCd(NGEConstants.BusinessTypeCd.RENEWAL);
							}							
						}									
						/*if(businessType.equalsIgnoreCase(NGEConstants.ProductState.NEW)){
							
							legacyWipQuoteData.setBusinessTypeCd(NGEConstants.BusinessTypeCd.NEW);
						}
						else{
							legacyWipQuoteData.setBusinessTypeCd(NGEConstants.BusinessTypeCd.RENEWAL);
						}*/
						/*F46227-US245579-eStart-Correct Business type for Cancelled policies-ends*/
					}catch(Exception e){
						/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
						if(commonServiceHelper.checkForRetryExceptions(e, 3, NGEConstants.CatchExceptionTypes.THROW_EXCEPTION))
						{
							logger.error("checkForRetryExceptions returned true");
						}
						/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
						/* 2019 PI5 - Release 2.18.0 - Ensure NGE IS Retry Logic - Starts */
						logger.error("Exception message - Retry Logic : " +e.getMessage());
						throw e;
						/* 2019 PI5 - Release 2.18.0 - Ensure NGE IS Retry Logic - Ends */
						}
  					}				
				
				if(wipDetailsData.getCurrencyCd()!=null && !wipDetailsData.getCurrencyCd().equalsIgnoreCase("") && !wipDetailsData.getCurrencyCd().equalsIgnoreCase(NGEConstants.USD)){
					
					
					rate = getCurrencyRate(null, wipDetailsData.getCurrencyCd());
					if(rate == null){
						logger.debug("Given Currency Code is not available from Currency Conversion Service");
						ngeException.throwException(NGEErrorCodes.AIG_CURRENCY_NOT_MATCHING,
								NGEErrorCodes.ERROR_TYPE, "Given Currency Code is not available from Currency Conversion Service", null);
					}
					logger.info("Currency Rate" + rate);
					//Abul changes Defect 409 starts
					insertCurrencyWipQuote(transactionComponentForWip.getTransactionComponentId(),null,wipDetailsData,rate,legacyWipQuoteData,lifeCycleStatus);
					//Abul changes Defect 409 starts
					
				}
				else{
					
					limitList = transactionComponentForWip.getTtransactionComponentLimits();
					
					if(limitList.size() > 1){
						for(TtransactionComponentLimit transactionComponentLimit:limitList)
						{
							if(!NGEConstants.USD.equalsIgnoreCase(transactionComponentLimit.getTcurrency().getCurrencyCd()))
							{
								
								rate = getCurrencyRate(limitList, transactionComponentLimit.getTcurrency().getCurrencyCd());
								if(rate == null){
									logger.debug("Given Currency Code is not available from Currency Conversion Service");
									ngeException.throwException(NGEErrorCodes.AIG_CURRENCY_NOT_MATCHING,
											NGEErrorCodes.ERROR_TYPE, "Given Currency Code is not available from Currency Conversion Service", null);
								}
								logger.info("Currency Rate" + rate);
								//Abul changes Defect 409 starts
								wipDetailsData.setCurrencyCd(transactionComponentLimit.getTcurrency().getCurrencyCd());
								insertCurrencyWipQuote(transactionComponentForWip.getTransactionComponentId(),null,wipDetailsData,rate,legacyWipQuoteData,lifeCycleStatus);
								//Abul changes Defect 409 ends
							}
						}
					}
					else{
							wipDetailsData.setCurrencyCd(NGEConstants.USD);
							//Abul changes Defect 409 starts
							insertCurrencyWipQuote(transactionComponentForWip.getTransactionComponentId(),null,wipDetailsData,null,legacyWipQuoteData,lifeCycleStatus);
							//Abul changes Defect 409 ends
					}
					
				}
				
				
			
				
		}
		else {
					
					
			
		try
		{
				wipDetailsData = new WIPQuoteDetails();
				wipDetailsData.setWIPId(legacyWipQuoteData.getId().getWipId());
				wipDetailsData.setQuoteSqn(legacyWipQuoteData.getId().getQuoteSqn());
				wipDetailsData.setCurrencyCd(NGEConstants.USD);
				
				
				logger.debug("transactionComponentForWip.getTransactionComponentId()" +transactionComponentForWip.getTransactionComponentId());
					
					try{
						String transaCompId = transactionComponentForWip.getTransactionComponentId();
						//TtransactionComponent transCompData = ttransactionComponentRepository.findByTransactionComponentId(transaCompId);
                        TtransactionComponent transCompData = transactionComponentDAO.findByTransactionComponentIdForWIPS(transaCompId);

						String businessType =  transCompData.getTproductState().getProductStateNm();
						logger.debug("businessType" +businessType);
						if(businessType.equalsIgnoreCase(NGEConstants.ProductState.NEW)){
							
							legacyWipQuoteData.setBusinessTypeCd(NGEConstants.BusinessTypeCd.NEW);
						}
						else{
							legacyWipQuoteData.setBusinessTypeCd(NGEConstants.BusinessTypeCd.RENEWAL);
						}
					}catch(Exception e){
						/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
						if(commonServiceHelper.checkForRetryExceptions(e, 4, NGEConstants.CatchExceptionTypes.THROW_EXCEPTION))
						{
							logger.error("checkForRetryExceptions returned true");
						}
						/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
						/* 2019 PI5 - Release 2.18.0 - Ensure NGE IS Retry Logic - Starts */
						logger.error("Exception message - Retry Logic : " +e.getMessage());
						throw e;
						/* 2019 PI5 - Release 2.18.0 - Ensure NGE IS Retry Logic - Ends */
					}
					
					
					
				if(wipDetailsData.getNonRenewalIn() != null){
					legacyWipQuoteData.setNonRenewalIn(wipDetailsData.getNonRenewalIn());	
				}
				else if(getNonRenewalInd(transactionComponentForWip.getTransactionComponentId()))
				{
					legacyWipQuoteData.setNonRenewalIn(NGEConstants.YES);
				}
				else
				{
					legacyWipQuoteData.setNonRenewalIn(NGEConstants.NO);					
				}
				
				if(wipDetailsData.getNonRenewalRsnCd() != null){
					legacyWipQuoteData.setNonRenewalReasonCd(wipDetailsData.getNonRenewalRsnCd());
				}					
				
				logger.debug("transactionComponentForWip.getTransactionComponentId()" +transactionComponentForWip.getTransactionComponentId());
				
  				if(wipDetailsData.getBusinessTypeCode()!=null){
  					legacyWipQuoteData.setBusinessTypeCd(wipDetailsData.getBusinessTypeCode());

  				}
  				else{
  					try{
						String transaCompId = transactionComponentForWip.getTransactionComponentId();
						//TtransactionComponent transCompData = ttransactionComponentRepository.findByTransactionComponentId(transaCompId);
                        TtransactionComponent transCompData = transactionComponentDAO.findByTransactionComponentIdForWIPS(transaCompId);

						String businessType =  transCompData.getTproductState().getProductStateNm();
						logger.debug("businessType" +businessType);
						if(businessType.equalsIgnoreCase(NGEConstants.ProductState.NEW)){
							
							legacyWipQuoteData.setBusinessTypeCd(NGEConstants.BusinessTypeCd.NEW);
						}
						else{
							legacyWipQuoteData.setBusinessTypeCd(NGEConstants.BusinessTypeCd.RENEWAL);
						}
					}catch(Exception e){
						/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
						if(commonServiceHelper.checkForRetryExceptions(e, 5, NGEConstants.CatchExceptionTypes.THROW_EXCEPTION))
						{
							logger.error("checkForRetryExceptions returned true");
						}
						/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
						/* 2019 PI5 - Release 2.18.0 - Ensure NGE IS Retry Logic - Starts */
						logger.error("Exception message - Retry Logic : " +e.getMessage());
						throw e;
						/* 2019 PI5 - Release 2.18.0 - Ensure NGE IS Retry Logic - Ends */
						}
  					}
						
			//logger.debug("before save : "+legacyWipQuoteData.toString());
				//legacyWipQuoteData = tLegacyWipQuoteRepository.save(legacyWipQuoteData);
				limitList = transactionComponentForWip.getTtransactionComponentLimits();
				
				if(limitList.size() > 1){
					for(TtransactionComponentLimit transactionComponentLimit:limitList)
					{
						if(!NGEConstants.USD.equalsIgnoreCase(transactionComponentLimit.getTcurrency().getCurrencyCd()))
						{
							wipDetailsData.setCurrencyCd(transactionComponentLimit.getTcurrency().getCurrencyCd());
							try{
							rate = getCurrencyRate(limitList, transactionComponentLimit.getTcurrency().getCurrencyCd());
							}catch(Exception e){
								/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
								if(commonServiceHelper.checkForRetryExceptions(e, 6, NGEConstants.CatchExceptionTypes.THROW_EXCEPTION))
								{
									logger.error("checkForRetryExceptions returned true");
								}
								/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
								/* 2019 PI5 - Release 2.18.0 - Ensure NGE IS Retry Logic - Starts */
								logger.error("Exception message - Retry Logic : " +e.getMessage());
								throw e;
								/* 2019 PI5 - Release 2.18.0 - Ensure NGE IS Retry Logic - Ends */
							}
							//Abul changes Defect 409 starts
							insertCurrencyWipQuote(transactionComponentForWip.getTransactionComponentId(),null,wipDetailsData,rate,legacyWipQuoteData,lifeCycleStatus);
							//Abul changes Defetc 409 ends
							
						}
					}
				}
				else{
					wipDetailsData.setCurrencyCd(NGEConstants.USD);
					//try{
					//rate = getCurrencyRate(null,NGEConstants.USD );
					//}catch(Exception e){
					//logger.debug("Exception : " +e.getMessage());
					//}
					//Abul changes Defect 409 starts
					insertCurrencyWipQuote(transactionComponentForWip.getTransactionComponentId(),null,wipDetailsData,null,legacyWipQuoteData,lifeCycleStatus);
					//Abul changes Defect 409 ends
				}
				logger.debug(legacyWipQuoteData.getId().getTransactionComponentId());
				//medium low issue fixes-2020 starts
				//logger.debug(legacyWipQuoteData.getId().getWipId());
				logger.debug(ESAPI.encoder().encodeForHTML(legacyWipQuoteData.getId().getWipId()));
				//medium low issue fixes-2020 ends
				logger.debug(legacyWipQuoteData.getId().getQuoteSqn());
				logger.debug("after save");
        }
        catch(Exception e)
        {
        	/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
			if(commonServiceHelper.checkForRetryExceptions(e, 7, NGEConstants.CatchExceptionTypes.THROW_HANDLED_EXCEPTION))
			{
				logger.error("checkForRetryExceptions returned true");
			}
			/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
        	logger.error("Exception : " +e.getMessage());
              ngeException.throwException(NGEErrorCodes.SERVICE_FAILED,NGEErrorCodes.ERROR_TYPE, null, null);
        	}
        }

	
}

	private void insertCurrencyIfWIPDetailsNotNull(
			WIPQuoteDetails wipQuoteDetails, String transactionComponentId,TlegacyWipQuote legacyWipQuoteData , BigDecimal conversionRate, TtransactionComponentLimit transactionCompUSDLimit) throws AIGCIExceptionMsg {
		
		// Re-Open Cancel to Bind Issue
		if(conversionRate == null){
			
			conversionRate = new BigDecimal("1");
		}
				
		String inputCurrency = NGEConstants.EMPTY_STRING;
		TlegacyWipQuote legacyWipQuoteRslt = null;
		TlegacyWipQuoteCurrency legacyWipQuoteCurrRslt = null;
		TlegacyWipQuoteCurrency legacyWipQuoteCurrLocalRslt = null;
		Tcurrency currencyUsd = commonDAO.getCurrency(NGEConstants.USD);
		Set<TlegacyWipQuoteCurrency> TlegacyWipQuoteCurrencies = new HashSet<TlegacyWipQuoteCurrency>();
		List<TlegacyWipQuoteCurrency> legacyWipQuoteCurrencyData = getTlegacyWipQuoteCurrencyDetails(transactionComponentId, wipQuoteDetails.getWIPId(), wipQuoteDetails.getQuoteSqn());
		inputCurrency = wipQuoteDetails.getCurrencyCd();
		BigDecimal policyPremiumAmount = null;
		if(wipQuoteDetails.getPolicyDetails() != null){
			
			if(wipQuoteDetails.getPolicyDetails().getPolicyPremiumAmt() != null){
				
				policyPremiumAmount = wipQuoteDetails.getPolicyDetails().getPolicyPremiumAmt();
			}			
		}
		
			if(null != legacyWipQuoteCurrencyData && !legacyWipQuoteCurrencyData.isEmpty())
			{
				for(TlegacyWipQuoteCurrency legacyWipQuoteCurrency: legacyWipQuoteCurrencyData)
				{	
					//tlegacyWipQuoteCurrencyHsRepository.insertLegacyWIPQuoteCurrencyHistory(legacyWipQuoteCurrency.getId().getTransactionComponentId(),legacyWipQuoteCurrency.getId().getWipId(), legacyWipQuoteCurrency.getId().getQuoteSqn());
					
					if(legacyWipQuoteCurrency != null){
						historyHelper.createTlegacyWipQuoteCurrencyHHistory(legacyWipQuoteCurrency);
					}
				}			
				 
				//Input has USD Currency
				if(NGEConstants.USD.equalsIgnoreCase(inputCurrency))
				{
					if(legacyWipQuoteCurrencyData.size() == 1) //Input USD - table USD
					{
						legacyWipQuoteCurrRslt = setLegacyWipCurrencyForUsd(wipQuoteDetails, null, legacyWipQuoteCurrencyData.get(0), policyPremiumAmount, transactionCompUSDLimit, true);
						legacyWipQuoteCurrRslt.setUpdateTs(NGEDateUtil.getTodayDate());
						legacyWipQuoteCurrRslt.setUpdateUserId(NGESession.getSessionData().getUserId());
						TlegacyWipQuoteCurrencies.add(legacyWipQuoteCurrRslt);
					}
					else //Input USD - table local
					{
						for(TlegacyWipQuoteCurrency legacyWipQuoteCurr: legacyWipQuoteCurrencyData)
						{
							if(null != currencyUsd && legacyWipQuoteCurr.getId().getCurrencyId() != currencyUsd.getCurrencyId())
							{
								try
								{
									deleteLegacyWipQuoteCurrency(legacyWipQuoteCurr);
								}
								catch(Exception e)
								{
									/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
									if(commonServiceHelper.checkForRetryExceptions(e, 8, NGEConstants.CatchExceptionTypes.THROW_HANDLED_EXCEPTION))
									{
										logger.error("checkForRetryExceptions returned true");
									}
									/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
									ngeException.throwException(NGEErrorCodes.SERVICE_FAILED,NGEErrorCodes.ERROR_TYPE, null, null);
								}
							}
							else
							{
								legacyWipQuoteCurrRslt = setLegacyWipCurrencyForUsd(wipQuoteDetails, null, legacyWipQuoteCurr, policyPremiumAmount, transactionCompUSDLimit, true);
								legacyWipQuoteCurrRslt.setUpdateTs(NGEDateUtil.getTodayDate());
								legacyWipQuoteCurrRslt.setUpdateUserId(NGESession.getSessionData().getUserId());
								TlegacyWipQuoteCurrencies.add(legacyWipQuoteCurrRslt);
							}
						}
					}
				}
				//Input has local currency
				else
				{
					
					TtransactionComponentLimit transactionCompLocalLimit = null;
					List<TtransactionComponentLimit> transactionComponentLimits = new ArrayList<TtransactionComponentLimit>();
					transactionComponentLimits = transactionComponentLimitRepository.getComponentLimit(transactionComponentId);
					if(transactionComponentLimits.isEmpty())
					{
						/* PI3 - Q3 2018 Maintenance Release 2.12 - Ensure to Bind all components in a bundle - Starts */
						logger.error("LegacyWipDAO - Debug - 8");
						/* PI3 - Q3 2018 Maintenance Release 2.12 - Ensure to Bind all components in a bundle - Ends */
						ngeException.throwException(NGEErrorCodes.SERVICE_FAILED,NGEErrorCodes.ERROR_TYPE, null, null);
					}
					
					transactionCompLocalLimit = productHelper.fetchLimitAmountByTransLimit(transactionComponentLimits, NGEConstants.LOCAL);
					
					if(legacyWipQuoteCurrencyData.size() == 1) //Input has local currency and table has USD
					{
						
						
						legacyWipQuoteCurrRslt = setLegacyWipCurrencyForUsd(wipQuoteDetails, conversionRate, legacyWipQuoteCurrencyData.get(0), policyPremiumAmount, transactionCompUSDLimit, true);
						legacyWipQuoteCurrRslt.setUpdateTs(NGEDateUtil.getTodayDate());
						legacyWipQuoteCurrRslt.setUpdateUserId(NGESession.getSessionData().getUserId());
						TlegacyWipQuoteCurrencies.add(legacyWipQuoteCurrRslt);
						
						legacyWipQuoteCurrLocalRslt = insertLocalCurrency(legacyWipQuoteCurrRslt.getId(), wipQuoteDetails, policyPremiumAmount , transactionCompLocalLimit);					
						TlegacyWipQuoteCurrencies.add(legacyWipQuoteCurrLocalRslt);
					}
					else //Input has local and table has local currency
					{
						
						for(TlegacyWipQuoteCurrency legacyWipQuoteCurr: legacyWipQuoteCurrencyData)
						{
							if(null != currencyUsd && legacyWipQuoteCurr.getId().getCurrencyId() == currencyUsd.getCurrencyId()) // USD record
							{
								legacyWipQuoteCurrRslt = setLegacyWipCurrencyForUsd(wipQuoteDetails, conversionRate, legacyWipQuoteCurr, policyPremiumAmount, transactionCompUSDLimit, true);
								legacyWipQuoteCurrRslt.setUpdateTs(NGEDateUtil.getTodayDate());
								legacyWipQuoteCurrRslt.setUpdateUserId(NGESession.getSessionData().getUserId());
								TlegacyWipQuoteCurrencies.add(legacyWipQuoteCurrRslt);
							}
							else
							{
								legacyWipQuoteCurrLocalRslt = setLegacyWipCurrencyForLocal(wipQuoteDetails, legacyWipQuoteCurr, policyPremiumAmount, transactionCompLocalLimit);
								legacyWipQuoteCurrLocalRslt.setUpdateTs(NGEDateUtil.getTodayDate());
								legacyWipQuoteCurrLocalRslt.setUpdateUserId(NGESession.getSessionData().getUserId());
								TlegacyWipQuoteCurrencies.add(legacyWipQuoteCurrLocalRslt);
							}
						}
					}	

				}
				legacyWipQuoteData.setTlegacyWipQuoteCurrencies(TlegacyWipQuoteCurrencies);

			}
		try
		{
			legacyWipQuoteRslt = saveLegacyWipQuote(legacyWipQuoteData);
		}
		catch(Exception e)
		{
			/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
			if(commonServiceHelper.checkForRetryExceptions(e, 9, NGEConstants.CatchExceptionTypes.THROW_HANDLED_EXCEPTION))
			{
				logger.error("checkForRetryExceptions returned true");
			}
			/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
			ngeException.throwException(NGEErrorCodes.SERVICE_FAILED,NGEErrorCodes.ERROR_TYPE, null, null);
		}
		if(null == legacyWipQuoteRslt)
		{
			/* PI3 - Q3 2018 Maintenance Release 2.12 - Ensure to Bind all components in a bundle - Starts */
			logger.error("LegacyWipDAO - Debug - 10");
			/* PI3 - Q3 2018 Maintenance Release 2.12 - Ensure to Bind all components in a bundle - Ends */
			ngeException.throwException(NGEErrorCodes.SERVICE_FAILED,NGEErrorCodes.ERROR_TYPE, null, null);
		}
	}
	//Abul changes defect 409 starts
	private void insertCurrencyIfAnyOneOfTheValuesAsNull(
			WIPQuoteDetails wipQuoteDetails, TlegacyWipQuote legacyWipQuoteData, String transactionComponentId,String lifeCycleStatus, BigDecimal conversionRate) throws AIGCIExceptionMsg {
		//Abul changes defect 409 ends
		
		// Re-Open Cancel to Bind Issue
		if(conversionRate == null){
			
			conversionRate = new BigDecimal("1");
		}
		
		String inputCurrency = NGEConstants.EMPTY_STRING;
		TlegacyWipQuote legacyWipQuoteRslt = null;
		TlegacyWipQuoteCurrency legacyWipQuoteCurrRslt = null;
		TlegacyWipQuoteCurrencyPK legacyWipQuoteCurrRsltPK = null;
		TlegacyWipQuoteCurrency legacyWipQuoteCurrLocalRslt = null;
		Tcurrency currencyUsd = commonDAO.getCurrency(NGEConstants.USD);
	//	short currencyId = 0;
		//Timestamp createTs = null;
		//String createUserId = NGEConstants.EMPTY_STRING;
		Set<TlegacyWipQuoteCurrency> TlegacyWipQuoteCurrencies = new HashSet<TlegacyWipQuoteCurrency>();
		List<TtransactionComponentLimit> transactionComponentLimits = new ArrayList<TtransactionComponentLimit>();
		transactionComponentLimits = transactionComponentLimitRepository.getComponentLimit(transactionComponentId);
		//List<TlegacyWipQuoteCurrency> legacyWipQuoteCurrencyData = getTlegacyWipQuoteCurrencyDetails(transactionComponentId, legacyWipQuoteData.getId().getWipId(), legacyWipQuoteData.getId().getQuoteSqn());
		logger.debug("insertCurrencyIfAnyOneOfTheValuesAsNull");
		Tcurrency currencyForWip=null;
			if(!transactionComponentLimits.isEmpty())
			{
				
				if(wipQuoteDetails.getCurrencyCd()!=null && !wipQuoteDetails.getCurrencyCd().isEmpty()){
					inputCurrency = wipQuoteDetails.getCurrencyCd();
					  currencyForWip= commonDAO.getCurrency(inputCurrency);
					 //currencyId = currencyForWip.getCurrencyId();
					  
						for(TtransactionComponentLimit transactionComponentLimit:transactionComponentLimits)
						{
							if(currencyForWip.getCurrencyCd().equalsIgnoreCase(transactionComponentLimit.getTcurrency().getCurrencyCd()))
							{
								inputCurrency = transactionComponentLimit.getTcurrency().getCurrencyCd();
							//	currencyId = transactionComponentLimit.getTcurrency().getCurrencyId();
								//createTs =  transactionComponentLimit.getTcurrency().getCreateTs();
								//createUserId = transactionComponentLimit.getTcurrency().getCreateUserId();
								logger.debug("insertCurrencyIfAnyOneOfTheValuesAsNull- inputCurrency" +inputCurrency);
							}
						}
						
						logger.debug("insertCurrencyIfAnyOneOfTheValuesAsNull- currencyForWip" +currencyForWip);
				}
				else
				{
					if(transactionComponentLimits.size() >1)
					{
						for(TtransactionComponentLimit transactionComponentLimit:transactionComponentLimits)
						{
							if(!NGEConstants.USD.equalsIgnoreCase(transactionComponentLimit.getTcurrency().getCurrencyCd()))
							{
								inputCurrency = transactionComponentLimit.getTcurrency().getCurrencyCd();
							//	currencyId = transactionComponentLimit.getTcurrency().getCurrencyId();
								//createTs =  transactionComponentLimit.getTcurrency().getCreateTs();
								//createUserId = transactionComponentLimit.getTcurrency().getCreateUserId();
								logger.debug("insertCurrencyIfAnyOneOfTheValuesAsNull- inputCurrency" +inputCurrency);
							}
						}
					}
					else
					{
						inputCurrency = transactionComponentLimits.get(0).getTcurrency().getCurrencyCd();
					//	currencyId = transactionComponentLimits.get(0).getTcurrency().getCurrencyId();
						logger.debug("insertCurrencyIfAnyOneOfTheValuesAsNull- inputCurrency" +inputCurrency);
					}					
				}				

				legacyWipQuoteCurrRsltPK = new TlegacyWipQuoteCurrencyPK();
				legacyWipQuoteCurrRsltPK.setQuoteSqn(legacyWipQuoteData.getId().getQuoteSqn());
				legacyWipQuoteCurrRsltPK.setTransactionComponentId(legacyWipQuoteData.getId().getTransactionComponentId());
				logger.debug("legacyWipQuoteData.getId().getQuoteSqn() -" + legacyWipQuoteData.getId().getQuoteSqn());
				logger.debug("legacyWipQuoteData.getId().getWipId() -" + legacyWipQuoteData.getId().getWipId());
				logger.debug("legacyWipQuoteData.getId().getTransactionComponentId() -" + legacyWipQuoteData.getId().getTransactionComponentId());
/*							if(legacyWipQuoteData.getId().getWipId()==null)
					legacyWipQuoteData.getId().setWipId("1");*/
				legacyWipQuoteCurrRsltPK.setWipId(legacyWipQuoteData.getId().getWipId());
				
					//Input has USD Currency
					if(NGEConstants.USD.equalsIgnoreCase(inputCurrency))
					{
						logger.debug("inside 1");
						
						if(transactionComponentLimits.size() == 1) //Input USD - table USD
						{
							
							
							logger.debug("inside a");
							
							
							
							for(TtransactionComponentLimit transactionComponentLimit:transactionComponentLimits)
							{
								legacyWipQuoteCurrRslt = new TlegacyWipQuoteCurrency();
								legacyWipQuoteCurrRsltPK= new TlegacyWipQuoteCurrencyPK();
								legacyWipQuoteCurrRsltPK.setQuoteSqn(legacyWipQuoteData.getId().getQuoteSqn());
								legacyWipQuoteCurrRsltPK.setTransactionComponentId(legacyWipQuoteData.getId().getTransactionComponentId());
								legacyWipQuoteCurrRsltPK.setWipId(legacyWipQuoteData.getId().getWipId());
								legacyWipQuoteCurrRsltPK.setCurrencyId(transactionComponentLimit.getTcurrency().getCurrencyId());
								Tcurrency currencyData = new Tcurrency();
								currencyData.setCurrencyId(transactionComponentLimit.getTcurrency().getCurrencyId());
								legacyWipQuoteCurrRslt.setTcurrency(currencyData);
								legacyWipQuoteCurrRslt.setId(legacyWipQuoteCurrRsltPK);
								
								if(NGEConstants.USD.equalsIgnoreCase(transactionComponentLimit.getTcurrency().getCurrencyCd()))
								{
									
									if(wipQuoteDetails.getPolicyDetails()!=null){
										
										if(wipQuoteDetails.getPolicyDetails().getPolicyAttachmentPointAmt()==null){
											legacyWipQuoteCurrRslt.setPolicyAtchmtPointAm(transactionComponentLimit.getAttachmentPointAm());
										}else{
											legacyWipQuoteCurrRslt.setPolicyAtchmtPointAm(wipQuoteDetails.getPolicyDetails().getPolicyAttachmentPointAmt());
										}
										if(wipQuoteDetails.getPolicyDetails().getPolicyLimitAmt()==null){
											legacyWipQuoteCurrRslt.setPolicyLimitAm(transactionComponentLimit.getLimitAm());
										}
										else{
											legacyWipQuoteCurrRslt.setPolicyLimitAm(wipQuoteDetails.getPolicyDetails().getPolicyLimitAmt());
										}
									}
									//abul chnages defetc 409 starts
									//abul.........need to check this
									/*if(wipQuoteDetails.getQuotedAttachmentPointAmt()==null)*/
									if(wipQuoteDetails.getQuotedAttachmentPointAmt()==null && lifeCycleStatus!=null && !lifeCycleStatus.equalsIgnoreCase(NGEConstants.LifeCycleStatus.CANCELLED)){
										//abul chnages defetc 409 ends
										legacyWipQuoteCurrRslt.setQuotedAtchmtPointAm(transactionComponentLimit.getAttachmentPointAm());
									}else{
											if(wipQuoteDetails.getQuotedAttachmentPointAmt() != null){
												legacyWipQuoteCurrRslt.setQuotedAtchmtPointAm(wipQuoteDetails.getQuotedAttachmentPointAmt());
											}
											else{
												legacyWipQuoteCurrRslt.setQuotedAtchmtPointAm(transactionComponentLimit.getAttachmentPointAm());
											}										
									}
									//abul changes defetc 409 starts
									/*if(wipQuoteDetails.getQuotedLimitAmt()==null){*/
									if(wipQuoteDetails.getQuotedLimitAmt()==null && lifeCycleStatus!=null && !lifeCycleStatus.equalsIgnoreCase(NGEConstants.LifeCycleStatus.CANCELLED)){
										//abul changes defetc 409 starts
										legacyWipQuoteCurrRslt.setQuotedLimitAm(transactionComponentLimit.getLimitAm());
									}
									else{
										if(wipQuoteDetails.getQuotedLimitAmt() != null){
											legacyWipQuoteCurrRslt.setQuotedLimitAm(wipQuoteDetails.getQuotedLimitAmt());
										}
										else{
											legacyWipQuoteCurrRslt.setQuotedLimitAm(transactionComponentLimit.getLimitAm());
										}										
									}
									
									if(wipQuoteDetails.getQuotedPremiumAmt()==null){
										if(transactionComponentLimit.getPremiumAm() != null){
											legacyWipQuoteCurrRslt.setQuotedPremiumAm(transactionComponentLimit.getPremiumAm());
										}
										else{
											legacyWipQuoteCurrRslt.setQuotedPremiumAm(BigDecimal.ZERO);
										}
										
									}
									else{
										legacyWipQuoteCurrRslt.setQuotedPremiumAm(wipQuoteDetails.getQuotedPremiumAmt());
									}
									
									// Update the Bound Premium Amount with Policy Premium Amount - Requested by 1B Team
									if(wipQuoteDetails.getPolicyDetails() != null && wipQuoteDetails.getPolicyDetails().getPolicyPremiumAmt() != null){
										legacyWipQuoteCurrRslt.setBoundPremiumAm(wipQuoteDetails.getPolicyDetails().getPolicyPremiumAmt());
									}
																	
									
										legacyWipQuoteCurrRslt.setCreateTs(NGEDateUtil.getTodayDate());										
										legacyWipQuoteCurrRslt.setCreateUserId(NGESession.getSessionData().getUserId());	
										
										legacyWipQuoteCurrRslt.setUpdateTs(NGEDateUtil.getTodayDate());
										legacyWipQuoteCurrRslt.setUpdateUserId(NGESession.getSessionData().getUserId());
									
								}
							}
							 
							 
							
							
							TlegacyWipQuoteCurrencies.add(legacyWipQuoteCurrRslt);
						}
						else //Input USD - table local
						{
							logger.debug("inside b");
							
								for(TtransactionComponentLimit transactionComponentLimit:transactionComponentLimits)
								{
									legacyWipQuoteCurrRslt = new TlegacyWipQuoteCurrency();
									legacyWipQuoteCurrRsltPK= new TlegacyWipQuoteCurrencyPK();
									logger.debug(legacyWipQuoteData.getId().getQuoteSqn());
									logger.debug(legacyWipQuoteData.getId().getTransactionComponentId());
									logger.debug(legacyWipQuoteData.getId().getWipId());
									
									legacyWipQuoteCurrRsltPK.setQuoteSqn(legacyWipQuoteData.getId().getQuoteSqn());
									legacyWipQuoteCurrRsltPK.setTransactionComponentId(legacyWipQuoteData.getId().getTransactionComponentId());
									legacyWipQuoteCurrRsltPK.setWipId(legacyWipQuoteData.getId().getWipId());
									legacyWipQuoteCurrRsltPK.setCurrencyId(transactionComponentLimit.getTcurrency().getCurrencyId());
									Tcurrency currencyData = new Tcurrency();
									currencyData.setCurrencyId(transactionComponentLimit.getTcurrency().getCurrencyId());
									legacyWipQuoteCurrRslt.setTcurrency(currencyData);
									legacyWipQuoteCurrRslt.setId(legacyWipQuoteCurrRsltPK);	
									
									if(NGEConstants.USD.equalsIgnoreCase(transactionComponentLimit.getTcurrency().getCurrencyCd()))
										{
											//legacyWipQuoteCurrRslt = new TlegacyWipQuoteCurrency();
											if(wipQuoteDetails.getPolicyDetails()!=null){
											if(wipQuoteDetails.getPolicyDetails().getPolicyAttachmentPointAmt()==null){
												legacyWipQuoteCurrRslt.setPolicyAtchmtPointAm(transactionComponentLimit.getAttachmentPointAm());
											}else{
												legacyWipQuoteCurrRslt.setPolicyAtchmtPointAm(wipQuoteDetails.getPolicyDetails().getPolicyAttachmentPointAmt());
												}
												if(wipQuoteDetails.getPolicyDetails().getPolicyLimitAmt()==null){
													legacyWipQuoteCurrRslt.setPolicyLimitAm(transactionComponentLimit.getLimitAm());
												}
												else{
													legacyWipQuoteCurrRslt.setPolicyLimitAm(wipQuoteDetails.getPolicyDetails().getPolicyLimitAmt());
												}
											}
											
											//Abul changes defetc 409 starts
											/*if(wipQuoteDetails.getQuotedAttachmentPointAmt()==null){*/
											if(wipQuoteDetails.getQuotedAttachmentPointAmt()==null && lifeCycleStatus!=null && !lifeCycleStatus.equalsIgnoreCase(NGEConstants.LifeCycleStatus.CANCELLED)){
												//abul changes defetc 409 ends 
												legacyWipQuoteCurrRslt.setQuotedAtchmtPointAm(transactionComponentLimit.getAttachmentPointAm());
											}else{
												if(wipQuoteDetails.getQuotedAttachmentPointAmt() != null){
													legacyWipQuoteCurrRslt.setQuotedAtchmtPointAm(wipQuoteDetails.getQuotedAttachmentPointAmt());
												}
												else{
													legacyWipQuoteCurrRslt.setQuotedAtchmtPointAm(transactionComponentLimit.getAttachmentPointAm());
												}
											}
											//Abul changes defect 409 starts
											/*if(wipQuoteDetails.getQuotedLimitAmt()==null){*/
											if(wipQuoteDetails.getQuotedLimitAmt()==null && lifeCycleStatus!=null && !lifeCycleStatus.equalsIgnoreCase(NGEConstants.LifeCycleStatus.CANCELLED)){
												//Abul changes defect 409 ends
												legacyWipQuoteCurrRslt.setQuotedLimitAm(transactionComponentLimit.getLimitAm());
											} 
											else{
												if(wipQuoteDetails.getQuotedLimitAmt() != null){
													legacyWipQuoteCurrRslt.setQuotedLimitAm(wipQuoteDetails.getQuotedLimitAmt());
												}
												else{
													legacyWipQuoteCurrRslt.setQuotedLimitAm(transactionComponentLimit.getLimitAm());
												}
											}
											
											if(wipQuoteDetails.getQuotedPremiumAmt()==null){
												if(transactionComponentLimit.getPremiumAm() != null){
													legacyWipQuoteCurrRslt.setQuotedPremiumAm(transactionComponentLimit.getPremiumAm());
												}
												else{
													legacyWipQuoteCurrRslt.setQuotedPremiumAm(BigDecimal.ZERO);
												}												
											}
											else{
												legacyWipQuoteCurrRslt.setQuotedPremiumAm(wipQuoteDetails.getQuotedPremiumAmt());
											}
											
											// Update the Bound Premium Amount with Policy Premium Amount - Requested by 1B Team
											if(wipQuoteDetails.getPolicyDetails() != null && wipQuoteDetails.getPolicyDetails().getPolicyPremiumAmt() != null){
												legacyWipQuoteCurrRslt.setBoundPremiumAm(wipQuoteDetails.getPolicyDetails().getPolicyPremiumAmt());
											}
											
											legacyWipQuoteCurrRslt.setCreateTs(NGEDateUtil.getTodayDate());
											legacyWipQuoteCurrRslt.setCreateUserId(NGESession.getSessionData().getUserId());
											
											legacyWipQuoteCurrRslt.setUpdateTs(NGEDateUtil.getTodayDate());
											legacyWipQuoteCurrRslt.setUpdateUserId(NGESession.getSessionData().getUserId());											
										}
									}

								logger.debug("insertCurrencyIfAnyOneOfTheValuesAsNull- legacyWipQuoteCurrRslt" +legacyWipQuoteCurrRslt);
								
								TlegacyWipQuoteCurrencies.add(legacyWipQuoteCurrRslt);
								
								for (TlegacyWipQuoteCurrency itr:TlegacyWipQuoteCurrencies){
									logger.debug("itr" +itr);
								}
								}
							
						
					}
					//Input has local currency
					else
					{
						
						logger.debug("inside 2");
						legacyWipQuoteCurrRslt = new TlegacyWipQuoteCurrency();
						if(transactionComponentLimits.size() == 1) //Input has local currency and table has USD
						{
							logger.debug("inside c");
							for(TtransactionComponentLimit transactionComponentLimit:transactionComponentLimits)
							{
								if(NGEConstants.USD.equalsIgnoreCase(transactionComponentLimit.getTcurrency().getCurrencyCd()))
								{
									
									if(wipQuoteDetails.getPolicyDetails()!=null){
										
										if(wipQuoteDetails.getPolicyDetails().getPolicyAttachmentPointAmt()==null){
											legacyWipQuoteCurrRslt.setPolicyAtchmtPointAm(transactionComponentLimit.getAttachmentPointAm());
										}else{
											legacyWipQuoteCurrRslt.setPolicyAtchmtPointAm(wipQuoteDetails.getPolicyDetails().getPolicyAttachmentPointAmt().multiply(conversionRate));
										}
										if(wipQuoteDetails.getPolicyDetails().getPolicyLimitAmt()==null){
											legacyWipQuoteCurrRslt.setPolicyLimitAm(transactionComponentLimit.getLimitAm());
										}
										else{
											legacyWipQuoteCurrRslt.setPolicyLimitAm(wipQuoteDetails.getPolicyDetails().getPolicyLimitAmt().multiply(conversionRate));
										}
									}
									//Abul changes defetc 409 starts
									/*if(wipQuoteDetails.getQuotedAttachmentPointAmt()==null){*/
									if(wipQuoteDetails.getQuotedAttachmentPointAmt()==null && lifeCycleStatus!=null && !lifeCycleStatus.equalsIgnoreCase(NGEConstants.LifeCycleStatus.CANCELLED)){
										//Abul changes defect 409 ends
										legacyWipQuoteCurrRslt.setQuotedAtchmtPointAm(transactionComponentLimit.getAttachmentPointAm());
									}else{
										if(wipQuoteDetails.getQuotedAttachmentPointAmt() != null){
											legacyWipQuoteCurrRslt.setQuotedAtchmtPointAm(wipQuoteDetails.getQuotedAttachmentPointAmt().multiply(conversionRate));
										}
										else{
											legacyWipQuoteCurrRslt.setQuotedAtchmtPointAm(transactionComponentLimit.getAttachmentPointAm());
										}
									}
									//Abul changes defect 409 starts
									/*if(wipQuoteDetails.getQuotedLimitAmt()==null){*/
									if(wipQuoteDetails.getQuotedLimitAmt()==null && lifeCycleStatus!=null && !lifeCycleStatus.equalsIgnoreCase(NGEConstants.LifeCycleStatus.CANCELLED)){
										//Abul changes defect 409 ends
										legacyWipQuoteCurrRslt.setQuotedLimitAm(transactionComponentLimit.getLimitAm());
									}
									else{
										if(wipQuoteDetails.getQuotedLimitAmt() != null){
											legacyWipQuoteCurrRslt.setQuotedLimitAm(wipQuoteDetails.getQuotedLimitAmt().multiply(conversionRate));
										}
										else{
											legacyWipQuoteCurrRslt.setQuotedLimitAm(transactionComponentLimit.getLimitAm());
										}
									}
									if(wipQuoteDetails.getQuotedPremiumAmt()==null){
										if(transactionComponentLimit.getPremiumAm() != null){
											legacyWipQuoteCurrRslt.setQuotedPremiumAm(transactionComponentLimit.getPremiumAm());
										}
										else{
											legacyWipQuoteCurrRslt.setQuotedPremiumAm(BigDecimal.ZERO);
										}										
									}
									else{
										legacyWipQuoteCurrRslt.setQuotedPremiumAm(wipQuoteDetails.getQuotedPremiumAmt().multiply(conversionRate));
									}
									
									// Update the Bound Premium Amount with Policy Premium Amount - Requested by 1B Team
									if(wipQuoteDetails.getPolicyDetails() != null && wipQuoteDetails.getPolicyDetails().getPolicyPremiumAmt() != null){
										legacyWipQuoteCurrRslt.setBoundPremiumAm(wipQuoteDetails.getPolicyDetails().getPolicyPremiumAmt().multiply(conversionRate));
									}
									
									legacyWipQuoteCurrRslt.setCreateTs(NGEDateUtil.getTodayDate());
									legacyWipQuoteCurrRslt.setCreateUserId(NGESession.getSessionData().getUserId());
									
									if(wipQuoteDetails.getCurrencyCd()==null || wipQuoteDetails.getCurrencyCd().isEmpty()){
										
										Tcurrency currencyData = new Tcurrency();
										currencyData.setCurrencyId(transactionComponentLimit.getTcurrency().getCurrencyId());
										legacyWipQuoteCurrRslt.setTcurrency(currencyData);
									}else{
										if(currencyForWip!=null)
											legacyWipQuoteCurrRsltPK.setCurrencyId(currencyForWip.getCurrencyId());
											legacyWipQuoteCurrRslt.setId(legacyWipQuoteCurrRsltPK);
											logger.debug("Currency values --->"+ legacyWipQuoteCurrRslt.toString()+"******************");
											logger.debug("Currency PK  values --->"+ legacyWipQuoteCurrRsltPK.toString()+"*****************");
											legacyWipQuoteCurrRslt.setId(legacyWipQuoteCurrRsltPK);
									}
									legacyWipQuoteCurrRslt.setUpdateTs(NGEDateUtil.getTodayDate());
									legacyWipQuoteCurrRslt.setUpdateUserId(NGESession.getSessionData().getUserId());
									TlegacyWipQuoteCurrencies.add(legacyWipQuoteCurrRslt);
								}
								else
								{
									legacyWipQuoteCurrRslt = new TlegacyWipQuoteCurrency();
									legacyWipQuoteCurrLocalRslt = new TlegacyWipQuoteCurrency();
									TlegacyWipQuoteCurrencyPK legacyWipQuoteCurrencyPk = new TlegacyWipQuoteCurrencyPK();
									legacyWipQuoteCurrencyPk.setTransactionComponentId(transactionComponentId);
									legacyWipQuoteCurrencyPk.setQuoteSqn(legacyWipQuoteCurrRslt.getId().getQuoteSqn());
									legacyWipQuoteCurrencyPk.setWipId(legacyWipQuoteCurrRslt.getId().getWipId());
									Tcurrency currencyLocal = commonDAO.getCurrency(inputCurrency);
									legacyWipQuoteCurrencyPk.setCurrencyId(currencyLocal.getCurrencyId());
									legacyWipQuoteCurrLocalRslt.setId(legacyWipQuoteCurrencyPk);
									
										legacyWipQuoteCurrRslt.setCreateTs(NGEDateUtil.getTodayDate());									
										legacyWipQuoteCurrRslt.setCreateUserId(NGESession.getSessionData().getUserId());
										
										legacyWipQuoteCurrRslt.setUpdateTs(NGEDateUtil.getTodayDate());
										legacyWipQuoteCurrRslt.setUpdateUserId(NGESession.getSessionData().getUserId());
									
									if(wipQuoteDetails.getPolicyDetails()!=null){
										
										if(wipQuoteDetails.getPolicyDetails().getPolicyAttachmentPointAmt()==null){
											legacyWipQuoteCurrLocalRslt.setPolicyAtchmtPointAm(transactionComponentLimit.getAttachmentPointAm());
										}else{
											legacyWipQuoteCurrLocalRslt.setPolicyAtchmtPointAm(wipQuoteDetails.getPolicyDetails().getPolicyAttachmentPointAmt());
										}
										if(wipQuoteDetails.getPolicyDetails().getPolicyLimitAmt()==null){
											legacyWipQuoteCurrLocalRslt.setPolicyLimitAm(transactionComponentLimit.getLimitAm());
										}
										else{
											legacyWipQuoteCurrLocalRslt.setPolicyLimitAm(wipQuoteDetails.getPolicyDetails().getPolicyLimitAmt());
										}
									}
									//Abul changes defetc 409 starts
									/*if(wipQuoteDetails.getQuotedAttachmentPointAmt()==null){*/
									if(wipQuoteDetails.getQuotedAttachmentPointAmt()==null && lifeCycleStatus!=null && !lifeCycleStatus.equalsIgnoreCase(NGEConstants.LifeCycleStatus.CANCELLED)){
										//Abul changes defetc 409 ends
										legacyWipQuoteCurrLocalRslt.setQuotedAtchmtPointAm(transactionComponentLimit.getAttachmentPointAm());
									}else{
										if(wipQuoteDetails.getQuotedAttachmentPointAmt() != null){
											legacyWipQuoteCurrRslt.setQuotedAtchmtPointAm(wipQuoteDetails.getQuotedAttachmentPointAmt());
										}
										else{
											legacyWipQuoteCurrRslt.setQuotedAtchmtPointAm(transactionComponentLimit.getAttachmentPointAm());
										}
									}
									//Abul changes defect 409 starts
									/*if(wipQuoteDetails.getQuotedLimitAmt()==null){*/
									if(wipQuoteDetails.getQuotedLimitAmt()==null && lifeCycleStatus!=null && !lifeCycleStatus.equalsIgnoreCase(NGEConstants.LifeCycleStatus.CANCELLED)){
										//Abul changes defect 409 ends
										legacyWipQuoteCurrLocalRslt.setQuotedLimitAm(transactionComponentLimit.getLimitAm());
									}
									else{
										if(wipQuoteDetails.getQuotedLimitAmt() != null){
											legacyWipQuoteCurrRslt.setQuotedLimitAm(wipQuoteDetails.getQuotedLimitAmt());
										}
										else{
											legacyWipQuoteCurrRslt.setQuotedLimitAm(transactionComponentLimit.getLimitAm());
										}
									}
									
									// Update the Bound Premium Amount with Policy Premium Amount - Requested by 1B Team
									if(wipQuoteDetails.getPolicyDetails() != null && wipQuoteDetails.getPolicyDetails().getPolicyPremiumAmt() != null){
										legacyWipQuoteCurrRslt.setBoundPremiumAm(wipQuoteDetails.getPolicyDetails().getPolicyPremiumAmt());
									}
									
									if(wipQuoteDetails.getQuotedPremiumAmt()==null){
										if(transactionComponentLimit.getPremiumAm() != null){
											legacyWipQuoteCurrLocalRslt.setQuotedPremiumAm(transactionComponentLimit.getPremiumAm());
										}
										else{
											legacyWipQuoteCurrLocalRslt.setQuotedPremiumAm(BigDecimal.ZERO);
										}										
									}
									else{
										legacyWipQuoteCurrRslt.setQuotedPremiumAm(wipQuoteDetails.getQuotedPremiumAmt());
									}	TlegacyWipQuoteCurrencies.add(legacyWipQuoteCurrLocalRslt);
								}
							}
							
						}
						else //Input has local and table has local curr
						{
							logger.debug("inside d");
							
							for(TtransactionComponentLimit transactionComponentLimit:transactionComponentLimits)
								{
								legacyWipQuoteCurrRslt = new TlegacyWipQuoteCurrency();
								legacyWipQuoteCurrRsltPK= new TlegacyWipQuoteCurrencyPK();
								legacyWipQuoteCurrRsltPK.setQuoteSqn(legacyWipQuoteData.getId().getQuoteSqn());
								legacyWipQuoteCurrRsltPK.setTransactionComponentId(legacyWipQuoteData.getId().getTransactionComponentId());
								legacyWipQuoteCurrRsltPK.setWipId(legacyWipQuoteData.getId().getWipId());
								legacyWipQuoteCurrRsltPK.setCurrencyId(transactionComponentLimit.getTcurrency().getCurrencyId());
								Tcurrency currencyData = new Tcurrency();
								currencyData.setCurrencyId(transactionComponentLimit.getTcurrency().getCurrencyId());
								legacyWipQuoteCurrRslt.setTcurrency(currencyData);
								legacyWipQuoteCurrRslt.setId(legacyWipQuoteCurrRsltPK);

									if(NGEConstants.USD.equalsIgnoreCase(transactionComponentLimit.getTcurrency().getCurrencyCd())
											&& currencyUsd.getCurrencyId() == transactionComponentLimit.getId().getCurrencyId())
									{
										logger.debug("inside USD");
										if(wipQuoteDetails.getPolicyDetails()!=null){
											
											if(wipQuoteDetails.getPolicyDetails().getPolicyAttachmentPointAmt()==null){
												legacyWipQuoteCurrRslt.setPolicyAtchmtPointAm(transactionComponentLimit.getAttachmentPointAm());
											}else{
												legacyWipQuoteCurrRslt.setPolicyAtchmtPointAm(wipQuoteDetails.getPolicyDetails().getPolicyAttachmentPointAmt().multiply(conversionRate));
											}
											if(wipQuoteDetails.getPolicyDetails().getPolicyLimitAmt()==null){
												legacyWipQuoteCurrRslt.setPolicyLimitAm(transactionComponentLimit.getLimitAm());
											}
											else{
												legacyWipQuoteCurrRslt.setPolicyLimitAm(wipQuoteDetails.getPolicyDetails().getPolicyLimitAmt().multiply(conversionRate));
											}
										}
										//Abul changes defetc 409 starts
										/*if(wipQuoteDetails.getQuotedAttachmentPointAmt()==null){*/
										if(wipQuoteDetails.getQuotedAttachmentPointAmt()==null && lifeCycleStatus!=null && !lifeCycleStatus.equalsIgnoreCase(NGEConstants.LifeCycleStatus.CANCELLED)){
										//Abul changes defetc 409 ends
											legacyWipQuoteCurrRslt.setQuotedAtchmtPointAm(transactionComponentLimit.getAttachmentPointAm());
										}else{
											if(wipQuoteDetails.getQuotedAttachmentPointAmt() != null){
												legacyWipQuoteCurrRslt.setQuotedAtchmtPointAm(wipQuoteDetails.getQuotedAttachmentPointAmt().multiply(conversionRate));
											}
											else{
												legacyWipQuoteCurrRslt.setQuotedAtchmtPointAm(transactionComponentLimit.getAttachmentPointAm());
											}
										}
										//Abul changes defetc 409 starts
										/*if(wipQuoteDetails.getQuotedLimitAmt()==null){*/
										if(wipQuoteDetails.getQuotedLimitAmt()==null && lifeCycleStatus!=null && !lifeCycleStatus.equalsIgnoreCase(NGEConstants.LifeCycleStatus.CANCELLED)){
											//Abul changes defetc 409 ends
											legacyWipQuoteCurrRslt.setQuotedLimitAm(transactionComponentLimit.getLimitAm());
										}
										else{
											if(wipQuoteDetails.getQuotedLimitAmt() != null){
												legacyWipQuoteCurrRslt.setQuotedLimitAm(wipQuoteDetails.getQuotedLimitAmt().multiply(conversionRate));
											}
											else{
												legacyWipQuoteCurrRslt.setQuotedLimitAm(transactionComponentLimit.getLimitAm());
											}
										}
										if(wipQuoteDetails.getQuotedPremiumAmt()==null){
											if(transactionComponentLimit.getPremiumAm() != null){
												legacyWipQuoteCurrRslt.setQuotedPremiumAm(transactionComponentLimit.getPremiumAm());
											}
											else{
												legacyWipQuoteCurrRslt.setQuotedPremiumAm(BigDecimal.ZERO);
											}											
										}
										else{
											legacyWipQuoteCurrRslt.setQuotedPremiumAm(wipQuoteDetails.getQuotedPremiumAmt().multiply(conversionRate));
										}
										
										// Update the Bound Premium Amount with Policy Premium Amount - Requested by 1B Team
										if(wipQuoteDetails.getPolicyDetails() != null && wipQuoteDetails.getPolicyDetails().getPolicyPremiumAmt() != null){
											legacyWipQuoteCurrRslt.setBoundPremiumAm(wipQuoteDetails.getPolicyDetails().getPolicyPremiumAmt().multiply(conversionRate));
										}
										
										legacyWipQuoteCurrRslt.setCreateTs(NGEDateUtil.getTodayDate());									
										legacyWipQuoteCurrRslt.setCreateUserId(NGESession.getSessionData().getUserId());
										

										legacyWipQuoteCurrRslt.setUpdateTs(NGEDateUtil.getTodayDate());
										legacyWipQuoteCurrRslt.setUpdateUserId(NGESession.getSessionData().getUserId());
																				
										TlegacyWipQuoteCurrencies.add(legacyWipQuoteCurrRslt);
									
									}
									else if(!NGEConstants.USD.equalsIgnoreCase(transactionComponentLimit.getTcurrency().getCurrencyCd()))
											
									{
										logger.debug("inside non-usd");
										
										if(wipQuoteDetails.getPolicyDetails()!=null){
											
											if(wipQuoteDetails.getPolicyDetails().getPolicyAttachmentPointAmt()==null){
												legacyWipQuoteCurrRslt.setPolicyAtchmtPointAm(transactionComponentLimit.getAttachmentPointAm());
											}else{
												legacyWipQuoteCurrRslt.setPolicyAtchmtPointAm(wipQuoteDetails.getPolicyDetails().getPolicyAttachmentPointAmt());
											}
											if(wipQuoteDetails.getPolicyDetails().getPolicyLimitAmt()==null){
												legacyWipQuoteCurrRslt.setPolicyLimitAm(transactionComponentLimit.getLimitAm());
											}
											else{
												legacyWipQuoteCurrRslt.setPolicyLimitAm(wipQuoteDetails.getPolicyDetails().getPolicyLimitAmt());
											}
										}
										//Abul changes defetc 409 starts
										/*if(wipQuoteDetails.getQuotedAttachmentPointAmt()==null){*/
										if(wipQuoteDetails.getQuotedAttachmentPointAmt()==null && lifeCycleStatus!=null && !lifeCycleStatus.equalsIgnoreCase(NGEConstants.LifeCycleStatus.CANCELLED)){
											//Abul changes defetc 409 ends
											legacyWipQuoteCurrRslt.setQuotedAtchmtPointAm(transactionComponentLimit.getAttachmentPointAm());
										}else{
											if(wipQuoteDetails.getQuotedAttachmentPointAmt() != null){
												legacyWipQuoteCurrRslt.setQuotedAtchmtPointAm(wipQuoteDetails.getQuotedAttachmentPointAmt());
											}
											else{
												legacyWipQuoteCurrRslt.setQuotedAtchmtPointAm(transactionComponentLimit.getAttachmentPointAm());
											}
										}
										//abul changes defetc 409 starts
										/*if(wipQuoteDetails.getQuotedLimitAmt()==null){*/
										if(wipQuoteDetails.getQuotedLimitAmt()==null && lifeCycleStatus!=null && !lifeCycleStatus.equalsIgnoreCase(NGEConstants.LifeCycleStatus.CANCELLED)){
											//abul changes defetc 409 ends
											legacyWipQuoteCurrRslt.setQuotedLimitAm(transactionComponentLimit.getLimitAm());
										}
										else{
											if(wipQuoteDetails.getQuotedLimitAmt() != null){
												legacyWipQuoteCurrRslt.setQuotedLimitAm(wipQuoteDetails.getQuotedLimitAmt());
											}
											else{
												legacyWipQuoteCurrRslt.setQuotedLimitAm(transactionComponentLimit.getLimitAm());
											}
										}
										
										if(wipQuoteDetails.getQuotedPremiumAmt()==null){
											if(transactionComponentLimit.getPremiumAm() != null){
												legacyWipQuoteCurrRslt.setQuotedPremiumAm(transactionComponentLimit.getPremiumAm());
											}
											else{
												legacyWipQuoteCurrRslt.setQuotedPremiumAm(BigDecimal.ZERO);
											}											
										}
										else{
											legacyWipQuoteCurrRslt.setQuotedPremiumAm(wipQuoteDetails.getQuotedPremiumAmt());
										}
										
										// Update the Bound Premium Amount with Policy Premium Amount - Requested by 1B Team
										if(wipQuoteDetails.getPolicyDetails() != null && wipQuoteDetails.getPolicyDetails().getPolicyPremiumAmt() != null){
											legacyWipQuoteCurrRslt.setBoundPremiumAm(wipQuoteDetails.getPolicyDetails().getPolicyPremiumAmt());
										}
										
										legacyWipQuoteCurrRslt.setCreateTs(NGEDateUtil.getTodayDate());										
										legacyWipQuoteCurrRslt.setCreateUserId(NGESession.getSessionData().getUserId());
										
										legacyWipQuoteCurrRslt.setUpdateTs(NGEDateUtil.getTodayDate());
										legacyWipQuoteCurrRslt.setUpdateUserId(NGESession.getSessionData().getUserId());
																				
										TlegacyWipQuoteCurrencies.add(legacyWipQuoteCurrRslt);
									}

								}
							
						}
					}	
				
				for(TlegacyWipQuoteCurrency itr:TlegacyWipQuoteCurrencies){
					
					logger.debug(itr.toString());
				}
				legacyWipQuoteData.setTlegacyWipQuoteCurrencies(TlegacyWipQuoteCurrencies);
				
			
		}
		try
		{
			legacyWipQuoteRslt = saveLegacyWipQuote(legacyWipQuoteData);
		}
		catch(Exception e)
		{
			/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
			if(commonServiceHelper.checkForRetryExceptions(e, 10, NGEConstants.CatchExceptionTypes.THROW_HANDLED_EXCEPTION))
			{
				logger.error("checkForRetryExceptions returned true");
			}
			/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
			ngeException.throwException(NGEErrorCodes.SERVICE_FAILED,NGEErrorCodes.ERROR_TYPE, null, null);
		}
		if(null == legacyWipQuoteRslt)
		{
			/* PI3 - Q3 2018 Maintenance Release 2.12 - Ensure to Bind all components in a bundle - Starts */
			logger.error("LegacyWipDAO - Debug - 12");
			/* PI3 - Q3 2018 Maintenance Release 2.12 - Ensure to Bind all components in a bundle - Ends */
			ngeException.throwException(NGEErrorCodes.SERVICE_FAILED,NGEErrorCodes.ERROR_TYPE, null, null);
		}
	}

	private void insertWithOutWIPDetails(TlegacyWipQuote legacyWipQuoteData, String transactionComponentId,Tpolicy policyInfo) throws AIGCIExceptionMsg {
		
		String inputCurrency = NGEConstants.EMPTY_STRING;
		TlegacyWipQuote legacyWipQuoteRslt = null;
		TlegacyWipQuoteCurrency legacyWipQuoteCurrRslt = null;
		//TlegacyWipQuoteCurrency legacyWipQuoteCurrLocalRslt = null;
		TlegacyWipQuoteCurrencyPK legacyWipQuoteCurrLocalRsltPK = null;	
		List<TlegacyWipQuoteCurrency>  legacyWipQuoteCurrencyData = new ArrayList<TlegacyWipQuoteCurrency>();
		Tcurrency currencyUsd = commonDAO.getCurrency(NGEConstants.USD);
		Set<TlegacyWipQuoteCurrency> TlegacyWipQuoteCurrencies = new HashSet<TlegacyWipQuoteCurrency>();
		List<TtransactionComponentLimit> transactionComponentLimits = new ArrayList<TtransactionComponentLimit>();
		transactionComponentLimits = transactionComponentLimitRepository.getComponentLimit(transactionComponentId);
		
		legacyWipQuoteCurrencyData = getTlegacyWipQuoteCurrencyDetails(transactionComponentId, legacyWipQuoteData.getId().getWipId(), legacyWipQuoteData.getId().getQuoteSqn());

		
		if(!transactionComponentLimits.isEmpty())
		{
			
			if(transactionComponentLimits.size() >1)
			{
				for(TtransactionComponentLimit transactionComponentLimit:transactionComponentLimits)
				{
					if(!NGEConstants.USD.equalsIgnoreCase(transactionComponentLimit.getTcurrency().getCurrencyCd()))
					{
						inputCurrency = transactionComponentLimit.getTcurrency().getCurrencyCd();
					//	currencyId = transactionComponentLimit.getTcurrency().getCurrencyId();
					//	createTs =  transactionComponentLimit.getTcurrency().getCreateTs();
					//	createUserId = transactionComponentLimit.getTcurrency().getCreateUserId();
						logger.debug("insertCurrencyIfAnyOneOfTheValuesAsNull- inputCurrency" +inputCurrency);
					}
				}
			}
			else
			{
				inputCurrency = transactionComponentLimits.get(0).getTcurrency().getCurrencyCd();
			//	currencyId = transactionComponentLimits.get(0).getTcurrency().getCurrencyId();
				logger.debug("insertCurrencyIfAnyOneOfTheValuesAsNull- inputCurrency" +inputCurrency);
			}
			
				//Input has USD Currency
				if(NGEConstants.USD.equalsIgnoreCase(inputCurrency))
				{
				if(legacyWipQuoteCurrencyData != null && !legacyWipQuoteCurrencyData.isEmpty()){
					
					for(TlegacyWipQuoteCurrency legacyWipQuoteCurrency: legacyWipQuoteCurrencyData)
					{	
						//tlegacyWipQuoteCurrencyHsRepository.insertLegacyWIPQuoteCurrencyHistory(legacyWipQuoteCurrency.getId().getTransactionComponentId(),legacyWipQuoteCurrency.getId().getWipId(), legacyWipQuoteCurrency.getId().getQuoteSqn());
						
						if(legacyWipQuoteCurrency != null){
							historyHelper.createTlegacyWipQuoteCurrencyHHistory(legacyWipQuoteCurrency);
						}
					}
					
					if( legacyWipQuoteCurrencyData.size() == 1 ) //Input USD - table USD
					{
						legacyWipQuoteCurrRslt = legacyWipQuoteCurrencyData.get(0);
						legacyWipQuoteCurrLocalRsltPK = new TlegacyWipQuoteCurrencyPK();
						legacyWipQuoteCurrLocalRsltPK.setTransactionComponentId(legacyWipQuoteData.getId().getTransactionComponentId());
						legacyWipQuoteCurrLocalRsltPK.setWipId(legacyWipQuoteData.getId().getWipId());
						legacyWipQuoteCurrLocalRsltPK.setQuoteSqn(legacyWipQuoteData.getId().getQuoteSqn());
						for(TtransactionComponentLimit transactionComponentLimit:transactionComponentLimits)
						{
							if(NGEConstants.USD.equalsIgnoreCase(transactionComponentLimit.getTcurrency().getCurrencyCd()))
							{
								legacyWipQuoteCurrLocalRsltPK.setCurrencyId(transactionComponentLimit.getTcurrency().getCurrencyId());			
								legacyWipQuoteCurrRslt.setId(legacyWipQuoteCurrLocalRsltPK);
								if(policyInfo!=null){
									legacyWipQuoteCurrRslt.setPolicyAtchmtPointAm(transactionComponentLimit.getAttachmentPointAm());
									legacyWipQuoteCurrRslt.setPolicyLimitAm(transactionComponentLimit.getLimitAm());							
								}
								legacyWipQuoteCurrRslt.setQuotedAtchmtPointAm(transactionComponentLimit.getAttachmentPointAm());
								legacyWipQuoteCurrRslt.setQuotedLimitAm(transactionComponentLimit.getLimitAm());
								legacyWipQuoteCurrRslt.setQuotedPremiumAm(transactionComponentLimit.getPremiumAm());
							}
						}
						legacyWipQuoteCurrRslt.setUpdateTs(NGEDateUtil.getTodayDate());
						legacyWipQuoteCurrRslt.setUpdateUserId(NGESession.getSessionData().getUserId());
												
						TlegacyWipQuoteCurrencies.add(legacyWipQuoteCurrRslt);
					}
					else //Input USD - table local
					{
						for(TlegacyWipQuoteCurrency legacyWipQuoteCurr: legacyWipQuoteCurrencyData)
						{
							if(null != currencyUsd && legacyWipQuoteCurr.getId().getCurrencyId() != currencyUsd.getCurrencyId())
							{
								try
								{
									deleteLegacyWipQuoteCurrency(legacyWipQuoteCurr);
								}
								catch(Exception e)
								{
									/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
									if(commonServiceHelper.checkForRetryExceptions(e, 11, NGEConstants.CatchExceptionTypes.THROW_HANDLED_EXCEPTION))
									{
										logger.error("checkForRetryExceptions returned true");
									}
									/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
									ngeException.throwException(NGEErrorCodes.SERVICE_FAILED,NGEErrorCodes.ERROR_TYPE, null, null);
								}
							}
							else
							{	
								legacyWipQuoteCurrLocalRsltPK = new TlegacyWipQuoteCurrencyPK();
								legacyWipQuoteCurrLocalRsltPK.setTransactionComponentId(legacyWipQuoteData.getId().getTransactionComponentId());
								legacyWipQuoteCurrLocalRsltPK.setWipId(legacyWipQuoteData.getId().getWipId());
								legacyWipQuoteCurrLocalRsltPK.setQuoteSqn(legacyWipQuoteData.getId().getQuoteSqn());
								
								for(TtransactionComponentLimit transactionComponentLimit:transactionComponentLimits)
								{
									if(NGEConstants.USD.equalsIgnoreCase(transactionComponentLimit.getTcurrency().getCurrencyCd()))
									{
										legacyWipQuoteCurrLocalRsltPK.setCurrencyId(transactionComponentLimit.getTcurrency().getCurrencyId());			
										legacyWipQuoteCurr.setId(legacyWipQuoteCurrLocalRsltPK);
										if(policyInfo!=null){
											legacyWipQuoteCurr.setPolicyAtchmtPointAm(transactionComponentLimit.getAttachmentPointAm());
											legacyWipQuoteCurr.setPolicyLimitAm(transactionComponentLimit.getLimitAm());							
										}
										legacyWipQuoteCurr.setQuotedAtchmtPointAm(transactionComponentLimit.getAttachmentPointAm());
										legacyWipQuoteCurr.setQuotedLimitAm(transactionComponentLimit.getLimitAm());
										legacyWipQuoteCurr.setQuotedPremiumAm(transactionComponentLimit.getPremiumAm());
									}
								}
								legacyWipQuoteCurr.setUpdateTs(NGEDateUtil.getTodayDate());
								legacyWipQuoteCurr.setUpdateUserId(NGESession.getSessionData().getUserId());
																
								TlegacyWipQuoteCurrencies.add(legacyWipQuoteCurr);
							}
						}
					}
				}	
				else{
					
					legacyWipQuoteCurrRslt = new TlegacyWipQuoteCurrency();
					legacyWipQuoteCurrLocalRsltPK = new TlegacyWipQuoteCurrencyPK();
					legacyWipQuoteCurrLocalRsltPK.setTransactionComponentId(legacyWipQuoteData.getId().getTransactionComponentId());
					legacyWipQuoteCurrLocalRsltPK.setWipId(legacyWipQuoteData.getId().getWipId());
					legacyWipQuoteCurrLocalRsltPK.setQuoteSqn(legacyWipQuoteData.getId().getQuoteSqn());
					
					
					
					if( transactionComponentLimits.size() == 1 ) //Input USD - table USD
					{
						
						for(TtransactionComponentLimit transactionComponentLimit:transactionComponentLimits)
						{
							if(NGEConstants.USD.equalsIgnoreCase(transactionComponentLimit.getTcurrency().getCurrencyCd()))
							{
								legacyWipQuoteCurrLocalRsltPK.setCurrencyId(transactionComponentLimit.getTcurrency().getCurrencyId());			
								legacyWipQuoteCurrRslt.setId(legacyWipQuoteCurrLocalRsltPK);
								
								if(policyInfo!=null){
									legacyWipQuoteCurrRslt.setPolicyAtchmtPointAm(transactionComponentLimit.getAttachmentPointAm());
									legacyWipQuoteCurrRslt.setPolicyLimitAm(transactionComponentLimit.getLimitAm());							
								}
								
								legacyWipQuoteCurrRslt.setQuotedAtchmtPointAm(transactionComponentLimit.getAttachmentPointAm());
								legacyWipQuoteCurrRslt.setQuotedLimitAm(transactionComponentLimit.getLimitAm());
								legacyWipQuoteCurrRslt.setQuotedPremiumAm(transactionComponentLimit.getPremiumAm());
								
							}
						}
						legacyWipQuoteCurrRslt.setCreateTs(NGEDateUtil.getTodayDate());
						legacyWipQuoteCurrRslt.setCreateUserId(NGESession.getSessionData().getUserId());
						
						legacyWipQuoteCurrRslt.setUpdateTs(NGEDateUtil.getTodayDate());
						legacyWipQuoteCurrRslt.setUpdateUserId(NGESession.getSessionData().getUserId());
						
						TlegacyWipQuoteCurrencies.add(legacyWipQuoteCurrRslt);
					}
			
				}
				}
		/*		//Input has local currency
				else
				{
					if(){
					
					if(legacyWipQuoteCurrencyData.size() == 1) //Input has local currency and table has USD
					{
						legacyWipQuoteCurrRslt = legacyWipQuoteCurrencyData.get(0);
						for(TtransactionComponentLimit transactionComponentLimit:transactionComponentLimits)
						{
							if(NGEConstants.USD.equalsIgnoreCase(transactionComponentLimit.getTcurrency().getCurrencyCd()))
							{
								legacyWipQuoteCurrRslt.setPolicyAtchmtPointAm(transactionComponentLimit.getAttachmentPointAm());
								legacyWipQuoteCurrRslt.setQuotedAtchmtPointAm(transactionComponentLimit.getAttachmentPointAm());
								legacyWipQuoteCurrRslt.setQuotedLimitAm(transactionComponentLimit.getLimitAm());
								legacyWipQuoteCurrRslt.setPolicyLimitAm(transactionComponentLimit.getLimitAm());
								legacyWipQuoteCurrRslt.setUpdateTs(NGEDateUtil.getTodayDate());
								legacyWipQuoteCurrRslt.setUpdateUserId(NGESession.getSessionData().getUserId());
								TlegacyWipQuoteCurrencies.add(legacyWipQuoteCurrRslt);
							}
							else
							{
								legacyWipQuoteCurrLocalRslt = new TlegacyWipQuoteCurrency();
								TlegacyWipQuoteCurrencyPK legacyWipQuoteCurrencyPk = new TlegacyWipQuoteCurrencyPK();
								legacyWipQuoteCurrencyPk.setTransactionComponentId(transactionComponentId);
								legacyWipQuoteCurrencyPk.setQuoteSqn(legacyWipQuoteCurrRslt.getId().getQuoteSqn());
								legacyWipQuoteCurrencyPk.setWipId(legacyWipQuoteCurrRslt.getId().getWipId());
								Tcurrency currencyLocal = commonDAO.getCurrency(inputCurrency);
								legacyWipQuoteCurrencyPk.setCurrencyId(currencyLocal.getCurrencyId());
								legacyWipQuoteCurrLocalRslt.setId(legacyWipQuoteCurrencyPk);
								legacyWipQuoteCurrLocalRslt.setCreateUserId(NGESession.getSessionData().getUserId());
								legacyWipQuoteCurrLocalRslt.setCreateTs(NGEDateUtil.getTodayDate());
								legacyWipQuoteCurrLocalRslt.setPolicyAtchmtPointAm(transactionComponentLimit.getAttachmentPointAm());
								legacyWipQuoteCurrLocalRslt.setQuotedAtchmtPointAm(transactionComponentLimit.getAttachmentPointAm());
								legacyWipQuoteCurrLocalRslt.setQuotedPremiumAm(policyInfo.getLocalCurrencyPremiumAm());
								legacyWipQuoteCurrLocalRslt.setQuotedLimitAm(transactionComponentLimit.getLimitAm());
								legacyWipQuoteCurrLocalRslt.setPolicyLimitAm(transactionComponentLimit.getLimitAm());
								TlegacyWipQuoteCurrencies.add(legacyWipQuoteCurrLocalRslt);
							}
						}
						
					}
					else //Input has local and table has local curr
					{
						for(TlegacyWipQuoteCurrency legacyWipQuoteCurr: legacyWipQuoteCurrencyData)
						{
							for(TtransactionComponentLimit transactionComponentLimit:transactionComponentLimits)
							{
								attachmentPointAmt = transactionComponentLimit.getAttachmentPointAm().divide(conversionRate);
								attachmentPointAmt = attachmentPointAmt.setScale(6, RoundingMode.HALF_UP);
								limitAmt = transactionComponentLimit.getLimitAm().divide(conversionRate);
								limitAmt = limitAmt.setScale(6, RoundingMode.HALF_UP);
								if(NGEConstants.USD.equalsIgnoreCase(transactionComponentLimit.getTcurrency().getCurrencyCd())
										&& currencyUsd.getCurrencyId() == legacyWipQuoteCurr.getId().getCurrencyId())
								{
									legacyWipQuoteCurr.setPolicyAtchmtPointAm(transactionComponentLimit.getAttachmentPointAm());
									legacyWipQuoteCurr.setQuotedAtchmtPointAm(transactionComponentLimit.getAttachmentPointAm());
									legacyWipQuoteCurr.setQuotedLimitAm(transactionComponentLimit.getLimitAm());
									legacyWipQuoteCurr.setPolicyLimitAm(transactionComponentLimit.getLimitAm());
									legacyWipQuoteCurr.setUpdateTs(NGEDateUtil.getTodayDate());
									legacyWipQuoteCurr.setUpdateUserId(NGESession.getSessionData().getUserId());
									TlegacyWipQuoteCurrencies.add(legacyWipQuoteCurr);
								}
								else if(!NGEConstants.USD.equalsIgnoreCase(transactionComponentLimit.getTcurrency().getCurrencyCd())
										&& currencyUsd.getCurrencyId() != legacyWipQuoteCurr.getId().getCurrencyId())
								{
									legacyWipQuoteCurr.setPolicyAtchmtPointAm(transactionComponentLimit.getAttachmentPointAm());
									legacyWipQuoteCurr.setPolicyLimitAm(transactionComponentLimit.getLimitAm());
									legacyWipQuoteCurr.setQuotedAtchmtPointAm(transactionComponentLimit.getAttachmentPointAm());
									legacyWipQuoteCurr.setQuotedLimitAm(transactionComponentLimit.getLimitAm());
									legacyWipQuoteCurr.setUpdateTs(NGEDateUtil.getTodayDate());
									legacyWipQuoteCurr.setUpdateUserId(NGESession.getSessionData().getUserId());
									TlegacyWipQuoteCurrencies.add(legacyWipQuoteCurr);
								}

							}
						}
					}
				}
				
				else{
					
				}
			}*/
				
			}
			legacyWipQuoteData.setTlegacyWipQuoteCurrencies(TlegacyWipQuoteCurrencies);
			
		try
		{
			legacyWipQuoteRslt = saveLegacyWipQuote(legacyWipQuoteData);
		}
		catch(Exception e)
		{
			/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
			if(commonServiceHelper.checkForRetryExceptions(e, 12, NGEConstants.CatchExceptionTypes.THROW_HANDLED_EXCEPTION))
			{
				logger.error("checkForRetryExceptions returned true");
			}
			/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
			logger.error("Exception : " +e.getMessage());
			ngeException.throwException(NGEErrorCodes.SERVICE_FAILED,NGEErrorCodes.ERROR_TYPE, null, null);
			
		}
		if(null == legacyWipQuoteRslt)
		{
			/* PI3 - Q3 2018 Maintenance Release 2.12 - Ensure to Bind all components in a bundle - Starts */
			logger.error("LegacyWipDAO - Debug - 15");
			/* PI3 - Q3 2018 Maintenance Release 2.12 - Ensure to Bind all components in a bundle - Ends */
			ngeException.throwException(NGEErrorCodes.SERVICE_FAILED,NGEErrorCodes.ERROR_TYPE, null, null);
		}
		
	}	


	
	/**
	 * @author Padma
	 * @param transactionComponentId
	 * @param policyInfo
	 * @param wipQuoteDetails
	 * @param conversionRate
	 * @param indicator 
	 * @throws AIGCIExceptionMsg
	 */
	public void updatePolicyWipQuote(String transactionComponentId, Tpolicy policyInfo, WIPQuoteDetails wipQuoteDetails, BigDecimal conversionRate) throws AIGCIExceptionMsg {
		List<String> statusCdList = new ArrayList<String>();
		statusCdList.add(NGEConstants.LegacyWIPStatusCd.BOUND);
		statusCdList.add(NGEConstants.LegacyWIPStatusCd.BOOK);
		
		List<TlegacyWipQuote> legacyWipQuoteList = getWIPQuoteInBind(transactionComponentId, policyInfo.getPolicyId(), statusCdList);
		TlegacyWipQuote legacyWipQuoteRslt = null;
		TlegacyWipQuoteCurrency legacyWipQuoteCurrRslt = null;
		TlegacyWipQuoteCurrency legacyWipQuoteCurrLocalRslt = null;
		String inputCurrency = NGEConstants.EMPTY_STRING;
		Tcurrency currencyUsd = commonDAO.getCurrency(NGEConstants.USD);
		Set<TlegacyWipQuoteCurrency> TlegacyWipQuoteCurrencies = new HashSet<TlegacyWipQuoteCurrency>();
		
		List<Tsystem> systemData =  new ArrayList<Tsystem>();			
		systemData = tSystemRepository.findBySystemId(NGESession.getSessionData().getSystem().getSystemId());
		if(null != legacyWipQuoteList && !legacyWipQuoteList.isEmpty())
		{
			for(TlegacyWipQuote legacyWipQuote : legacyWipQuoteList){
			/*tLegacyWIPQuoteHsRepository.insertLegacyWIPQuoteHistory(legacyWipQuote.getId().getTransactionComponentId(),
					legacyWipQuote.getId().getWipId(),legacyWipQuote.getId().getQuoteSqn());*/
				
				//Abul Added Starts
				historyHelper.createTlegacyWipQuoteHHistory(legacyWipQuote);
				//Abul Added Ends
			legacyWipQuote.setQuoteXprtnDt(policyInfo.getExpirationDt());
			legacyWipQuote.setPolicyXprtnDt(policyInfo.getExpirationDt());
            legacyWipQuote.setUpdateUserId(NGESession.getSessionData().getUserId());
            //legacyWipQuote.setTsystem(systemData.get(0));
			legacyWipQuote.setUwSystemID(NGESession.getSessionData().getSystem().getSystemId());
            legacyWipQuote.setUpdateTs(NGEDateUtil.getTodayDate());
            
            legacyWipQuote.setWipStatusCd(NGEConstants.LegacyWIPStatusCd.BOUND);
			List<TlegacyWipQuoteCurrency> legacyWipQuoteCurrencyData = getTlegacyWipQuoteCurrencyDetails(transactionComponentId, legacyWipQuote.getId().getWipId(), legacyWipQuote.getId().getQuoteSqn());
			if(null == wipQuoteDetails)
			{
				inputCurrency = policyInfo.getTcurrency().getCurrencyCd();
				List<TtransactionComponentLimit> transactionComponentLimits = new ArrayList<TtransactionComponentLimit>();
				transactionComponentLimits = transactionComponentLimitRepository.getComponentLimit(transactionComponentId);
				if(transactionComponentLimits.isEmpty())
				{
					/* PI3 - Q3 2018 Maintenance Release 2.12 - Ensure to Bind all components in a bundle - Starts */
					logger.error("LegacyWipDAO - Debug - 16");
					/* PI3 - Q3 2018 Maintenance Release 2.12 - Ensure to Bind all components in a bundle - Ends */
					ngeException.throwException(NGEErrorCodes.SERVICE_FAILED,NGEErrorCodes.ERROR_TYPE, null, null);
				}
				else
				{
					if(null != legacyWipQuoteCurrencyData && !legacyWipQuoteCurrencyData.isEmpty())
					{
						for(TlegacyWipQuoteCurrency legacyWipQuoteCurrency: legacyWipQuoteCurrencyData)
						{	
							//tlegacyWipQuoteCurrencyHsRepository.insertLegacyWIPQuoteCurrencyHistory(legacyWipQuoteCurrency.getId().getTransactionComponentId(),legacyWipQuoteCurrency.getId().getWipId(), legacyWipQuoteCurrency.getId().getQuoteSqn());
							if(legacyWipQuoteCurrency != null){
								historyHelper.createTlegacyWipQuoteCurrencyHHistory(legacyWipQuoteCurrency);
							}
						}
						//Input has USD Currency
						if(NGEConstants.USD.equalsIgnoreCase(inputCurrency))
						{
							if(legacyWipQuoteCurrencyData.size() == 1) //Input USD - table USD
							{
								legacyWipQuoteCurrRslt = legacyWipQuoteCurrencyData.get(0);
								for(TtransactionComponentLimit transactionComponentLimit:transactionComponentLimits)
								{
									if(NGEConstants.USD.equalsIgnoreCase(transactionComponentLimit.getTcurrency().getCurrencyCd()))
									{
										legacyWipQuoteCurrRslt.setPolicyAtchmtPointAm(transactionComponentLimit.getAttachmentPointAm());
										legacyWipQuoteCurrRslt.setQuotedAtchmtPointAm(transactionComponentLimit.getAttachmentPointAm());
										legacyWipQuoteCurrRslt.setQuotedLimitAm(transactionComponentLimit.getLimitAm());
										legacyWipQuoteCurrRslt.setPolicyLimitAm(transactionComponentLimit.getLimitAm());
									}
								}
								legacyWipQuoteCurrRslt.setQuotedPremiumAm(policyInfo.getPremiumAm());
								legacyWipQuoteCurrRslt.setBoundPremiumAm(policyInfo.getPremiumAm());
								legacyWipQuoteCurrRslt.setUpdateTs(NGEDateUtil.getTodayDate());
								legacyWipQuoteCurrRslt.setUpdateUserId(NGESession.getSessionData().getUserId());
															
								TlegacyWipQuoteCurrencies.add(legacyWipQuoteCurrRslt);
							}
							else //Input USD - table local
							{
								for(TlegacyWipQuoteCurrency legacyWipQuoteCurr: legacyWipQuoteCurrencyData)
								{
									if(null != currencyUsd && legacyWipQuoteCurr.getId().getCurrencyId() != currencyUsd.getCurrencyId())
									{
										try
										{
											deleteLegacyWipQuoteCurrency(legacyWipQuoteCurr);
										}
										catch(Exception e)
										{
											/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
											if(commonServiceHelper.checkForRetryExceptions(e, 13, NGEConstants.CatchExceptionTypes.THROW_HANDLED_EXCEPTION))
											{
												logger.error("checkForRetryExceptions returned true");
											}
											/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
											ngeException.throwException(NGEErrorCodes.SERVICE_FAILED,NGEErrorCodes.ERROR_TYPE, null, null);
										}
									}
									else
									{
										for(TtransactionComponentLimit transactionComponentLimit:transactionComponentLimits)
										{
											if(NGEConstants.USD.equalsIgnoreCase(transactionComponentLimit.getTcurrency().getCurrencyCd()))
											{
												legacyWipQuoteCurr.setPolicyAtchmtPointAm(transactionComponentLimit.getAttachmentPointAm());
												legacyWipQuoteCurr.setQuotedAtchmtPointAm(transactionComponentLimit.getAttachmentPointAm());
												legacyWipQuoteCurr.setQuotedLimitAm(transactionComponentLimit.getLimitAm());
												legacyWipQuoteCurr.setPolicyLimitAm(transactionComponentLimit.getLimitAm());
												legacyWipQuoteCurr.setBoundPremiumAm(policyInfo.getPremiumAm());
												legacyWipQuoteCurr.setQuotedPremiumAm(policyInfo.getPremiumAm());
											}
										}
										legacyWipQuoteCurr.setUpdateTs(NGEDateUtil.getTodayDate());
										legacyWipQuoteCurr.setUpdateUserId(NGESession.getSessionData().getUserId());
																			
										TlegacyWipQuoteCurrencies.add(legacyWipQuoteCurr);
									}
								}
							}
						}
						//Input has local currency
						else
						{
							if(legacyWipQuoteCurrencyData.size() == 1) //Input has local currency and table has USD
							{
								legacyWipQuoteCurrRslt = legacyWipQuoteCurrencyData.get(0);
								for(TtransactionComponentLimit transactionComponentLimit:transactionComponentLimits)
								{
									if(NGEConstants.USD.equalsIgnoreCase(transactionComponentLimit.getTcurrency().getCurrencyCd()))
									{
										legacyWipQuoteCurrRslt.setPolicyAtchmtPointAm(transactionComponentLimit.getAttachmentPointAm());
										legacyWipQuoteCurrRslt.setQuotedAtchmtPointAm(transactionComponentLimit.getAttachmentPointAm());
										legacyWipQuoteCurrRslt.setQuotedLimitAm(transactionComponentLimit.getLimitAm());
										legacyWipQuoteCurrRslt.setPolicyLimitAm(transactionComponentLimit.getLimitAm());
										legacyWipQuoteCurrRslt.setQuotedPremiumAm(policyInfo.getPremiumAm());
										legacyWipQuoteCurrRslt.setBoundPremiumAm(policyInfo.getPremiumAm());
										legacyWipQuoteCurrRslt.setUpdateTs(NGEDateUtil.getTodayDate());
										legacyWipQuoteCurrRslt.setUpdateUserId(NGESession.getSessionData().getUserId());
																			
										TlegacyWipQuoteCurrencies.add(legacyWipQuoteCurrRslt);
									}
									else
									{
										legacyWipQuoteCurrLocalRslt = new TlegacyWipQuoteCurrency();
										TlegacyWipQuoteCurrencyPK legacyWipQuoteCurrencyPk = new TlegacyWipQuoteCurrencyPK();
										legacyWipQuoteCurrencyPk.setTransactionComponentId(transactionComponentId);
										legacyWipQuoteCurrencyPk.setQuoteSqn(legacyWipQuoteCurrRslt.getId().getQuoteSqn());
										legacyWipQuoteCurrencyPk.setWipId(legacyWipQuoteCurrRslt.getId().getWipId());
										Tcurrency currencyLocal = commonDAO.getCurrency(inputCurrency);
										legacyWipQuoteCurrencyPk.setCurrencyId(currencyLocal.getCurrencyId());
										legacyWipQuoteCurrLocalRslt.setId(legacyWipQuoteCurrencyPk);
										legacyWipQuoteCurrLocalRslt.setCreateUserId(NGESession.getSessionData().getUserId());
										legacyWipQuoteCurrLocalRslt.setCreateTs(NGEDateUtil.getTodayDate());
										
										legacyWipQuoteCurrLocalRslt.setUpdateTs(NGEDateUtil.getTodayDate());
										legacyWipQuoteCurrLocalRslt.setUpdateUserId(NGESession.getSessionData().getUserId());
										
										legacyWipQuoteCurrLocalRslt.setPolicyAtchmtPointAm(transactionComponentLimit.getAttachmentPointAm());
										legacyWipQuoteCurrLocalRslt.setQuotedAtchmtPointAm(transactionComponentLimit.getAttachmentPointAm());
										legacyWipQuoteCurrLocalRslt.setQuotedPremiumAm(policyInfo.getLocalCurrencyPremiumAm());
										legacyWipQuoteCurrLocalRslt.setBoundPremiumAm(policyInfo.getLocalCurrencyPremiumAm());
										legacyWipQuoteCurrLocalRslt.setQuotedLimitAm(transactionComponentLimit.getLimitAm());
										legacyWipQuoteCurrLocalRslt.setPolicyLimitAm(transactionComponentLimit.getLimitAm());
																			
										TlegacyWipQuoteCurrencies.add(legacyWipQuoteCurrLocalRslt);
									}
								}
								
							}
							else //Input has local and table has local curr
							{
								for(TlegacyWipQuoteCurrency legacyWipQuoteCurr: legacyWipQuoteCurrencyData)
								{
									for(TtransactionComponentLimit transactionComponentLimit:transactionComponentLimits)
									{
										/*attachmentPointAmt = transactionComponentLimit.getAttachmentPointAm().divide(conversionRate);
										attachmentPointAmt = attachmentPointAmt.setScale(6, RoundingMode.HALF_UP);
										limitAmt = transactionComponentLimit.getLimitAm().divide(conversionRate);
										limitAmt = limitAmt.setScale(6, RoundingMode.HALF_UP);*/
										if(NGEConstants.USD.equalsIgnoreCase(transactionComponentLimit.getTcurrency().getCurrencyCd())
												&& currencyUsd.getCurrencyId() == legacyWipQuoteCurr.getId().getCurrencyId())
										{
											legacyWipQuoteCurr.setPolicyAtchmtPointAm(transactionComponentLimit.getAttachmentPointAm());
											legacyWipQuoteCurr.setQuotedAtchmtPointAm(transactionComponentLimit.getAttachmentPointAm());
											legacyWipQuoteCurr.setQuotedLimitAm(transactionComponentLimit.getLimitAm());
											legacyWipQuoteCurr.setPolicyLimitAm(transactionComponentLimit.getLimitAm());
											legacyWipQuoteCurr.setUpdateTs(NGEDateUtil.getTodayDate());
											legacyWipQuoteCurr.setUpdateUserId(NGESession.getSessionData().getUserId());
											legacyWipQuoteCurr.setQuotedPremiumAm(policyInfo.getPremiumAm());
											legacyWipQuoteCurr.setBoundPremiumAm(policyInfo.getPremiumAm());
											TlegacyWipQuoteCurrencies.add(legacyWipQuoteCurr);
										}
										else if(!NGEConstants.USD.equalsIgnoreCase(transactionComponentLimit.getTcurrency().getCurrencyCd())
												&& currencyUsd.getCurrencyId() != legacyWipQuoteCurr.getId().getCurrencyId())
										{
											legacyWipQuoteCurr.setPolicyAtchmtPointAm(transactionComponentLimit.getAttachmentPointAm());
											legacyWipQuoteCurr.setPolicyLimitAm(transactionComponentLimit.getLimitAm());
											legacyWipQuoteCurr.setQuotedAtchmtPointAm(transactionComponentLimit.getAttachmentPointAm());
											legacyWipQuoteCurr.setQuotedLimitAm(transactionComponentLimit.getLimitAm());
											legacyWipQuoteCurr.setQuotedPremiumAm(policyInfo.getLocalCurrencyPremiumAm());
											legacyWipQuoteCurr.setBoundPremiumAm(policyInfo.getLocalCurrencyPremiumAm());
											legacyWipQuoteCurr.setUpdateTs(NGEDateUtil.getTodayDate());
											legacyWipQuoteCurr.setUpdateUserId(NGESession.getSessionData().getUserId());
											TlegacyWipQuoteCurrencies.add(legacyWipQuoteCurr);
										}

									}
								}
							}
						}	
					}
				legacyWipQuote.setTlegacyWipQuoteCurrencies(TlegacyWipQuoteCurrencies);
				}
			}
			else
			{
				if(null != wipQuoteDetails.getPolicyMailedDt())
                {
                      Date polMailDt = NGEDateUtil.getStringDate(wipQuoteDetails.getPolicyMailedDt());
                      legacyWipQuote.setPolicyMailedDt(polMailDt);
                }
				updateWIPDetais(legacyWipQuote, wipQuoteDetails, true);
				List<TtransactionComponentLimit> transactionComponentLimits = new ArrayList<TtransactionComponentLimit>();
				transactionComponentLimits = transactionComponentLimitRepository.getComponentLimit(transactionComponentId);
				TtransactionComponentLimit limitUSD = null;
				TtransactionComponentLimit limitLocal = null;
				if(transactionComponentLimits.isEmpty())
				{
					/* PI3 - Q3 2018 Maintenance Release 2.12 - Ensure to Bind all components in a bundle - Starts */
					logger.error("LegacyWipDAO - Debug - 18");
					/* PI3 - Q3 2018 Maintenance Release 2.12 - Ensure to Bind all components in a bundle - Ends */
					ngeException.throwException(NGEErrorCodes.SERVICE_FAILED,NGEErrorCodes.ERROR_TYPE, null, null);
				}
				for(int i=0;i<transactionComponentLimits.size();i++)
				{
					if(transactionComponentLimits.get(i).getTcurrency().getCurrencyCd().equalsIgnoreCase(NGEConstants.USD))
					{
						limitUSD = transactionComponentLimits.get(i);
					}
					else
					{
						limitLocal = transactionComponentLimits.get(i);
					}
					
				}
				inputCurrency = policyInfo.getTcurrency().getCurrencyCd();
				if(null != legacyWipQuoteCurrencyData && !legacyWipQuoteCurrencyData.isEmpty())
				{
					for(TlegacyWipQuoteCurrency legacyWipQuoteCurrency: legacyWipQuoteCurrencyData)
					{	
						//tlegacyWipQuoteCurrencyHsRepository.insertLegacyWIPQuoteCurrencyHistory(legacyWipQuoteCurrency.getId().getTransactionComponentId(),legacyWipQuoteCurrency.getId().getWipId(), legacyWipQuoteCurrency.getId().getQuoteSqn());
						
						if(legacyWipQuoteCurrency != null){
							historyHelper.createTlegacyWipQuoteCurrencyHHistory(legacyWipQuoteCurrency);
						}
					}
					//Input has USD Currency
					if(NGEConstants.USD.equalsIgnoreCase(inputCurrency))
					{
						if(legacyWipQuoteCurrencyData.size() == 1) //Input USD - table USD
						{
							legacyWipQuoteCurrRslt = setLegacyWipCurrencyForUsd(wipQuoteDetails, null, legacyWipQuoteCurrencyData.get(0), policyInfo.getPremiumAm(), limitUSD, true);
							legacyWipQuoteCurrRslt.setUpdateTs(NGEDateUtil.getTodayDate());
							legacyWipQuoteCurrRslt.setUpdateUserId(NGESession.getSessionData().getUserId());
							TlegacyWipQuoteCurrencies.add(legacyWipQuoteCurrRslt);
						}
						else //Input USD - table local
						{
							for(TlegacyWipQuoteCurrency legacyWipQuoteCurr: legacyWipQuoteCurrencyData)
							{
								if(null != currencyUsd && legacyWipQuoteCurr.getId().getCurrencyId() != currencyUsd.getCurrencyId())
								{
									try
									{
										deleteLegacyWipQuoteCurrency(legacyWipQuoteCurr);
									}
									catch(Exception e)
									{
										/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
										if(commonServiceHelper.checkForRetryExceptions(e, 14, NGEConstants.CatchExceptionTypes.THROW_HANDLED_EXCEPTION))
										{
											logger.error("checkForRetryExceptions returned true");
										}
										/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
										ngeException.throwException(NGEErrorCodes.SERVICE_FAILED,NGEErrorCodes.ERROR_TYPE, null, null);
									}
								}
								else
								{
									legacyWipQuoteCurrRslt = setLegacyWipCurrencyForUsd(wipQuoteDetails, null, legacyWipQuoteCurr, policyInfo.getPremiumAm(), limitUSD, true);
									legacyWipQuoteCurrRslt.setUpdateTs(NGEDateUtil.getTodayDate());
									legacyWipQuoteCurrRslt.setUpdateUserId(NGESession.getSessionData().getUserId());
									TlegacyWipQuoteCurrencies.add(legacyWipQuoteCurrRslt);
								}
							}
						}
					}
					//Input has local currency
					else
					{
						if(legacyWipQuoteCurrencyData.size() == 1) //Input has local currency and table has USD
						{
							legacyWipQuoteCurrRslt = setLegacyWipCurrencyForUsd(wipQuoteDetails, conversionRate, legacyWipQuoteCurrencyData.get(0), policyInfo.getPremiumAm(), limitUSD, true);
							legacyWipQuoteCurrRslt.setUpdateTs(NGEDateUtil.getTodayDate());
							legacyWipQuoteCurrRslt.setUpdateUserId(NGESession.getSessionData().getUserId());
							TlegacyWipQuoteCurrencies.add(legacyWipQuoteCurrRslt);
							
							legacyWipQuoteCurrLocalRslt = insertLocalCurrency(legacyWipQuoteCurrRslt.getId(), wipQuoteDetails, policyInfo.getPremiumAm(), limitLocal);					
							TlegacyWipQuoteCurrencies.add(legacyWipQuoteCurrLocalRslt);
						}
						else //Input has local and table has local curr
						{
							for(TlegacyWipQuoteCurrency legacyWipQuoteCurr: legacyWipQuoteCurrencyData)
							{
								if(null != currencyUsd && legacyWipQuoteCurr.getId().getCurrencyId() == currencyUsd.getCurrencyId()) // USD record
								{
									legacyWipQuoteCurrRslt = setLegacyWipCurrencyForUsd(wipQuoteDetails, conversionRate, legacyWipQuoteCurr, policyInfo.getPremiumAm(), limitUSD, true);
									legacyWipQuoteCurrRslt.setUpdateTs(NGEDateUtil.getTodayDate());
									legacyWipQuoteCurrRslt.setUpdateUserId(NGESession.getSessionData().getUserId());
									TlegacyWipQuoteCurrencies.add(legacyWipQuoteCurrRslt);
								}
								else
								{
									legacyWipQuoteCurrLocalRslt = setLegacyWipCurrencyForLocal(wipQuoteDetails, legacyWipQuoteCurr, policyInfo.getPremiumAm(), limitLocal);
									legacyWipQuoteCurrLocalRslt.setUpdateTs(NGEDateUtil.getTodayDate());
									legacyWipQuoteCurrLocalRslt.setUpdateUserId(NGESession.getSessionData().getUserId());
									TlegacyWipQuoteCurrencies.add(legacyWipQuoteCurrLocalRslt);
								}
							}
						}	

					}
					legacyWipQuote.setTlegacyWipQuoteCurrencies(TlegacyWipQuoteCurrencies);

				}
			}
			try
			{
				legacyWipQuoteRslt = saveLegacyWipQuote(legacyWipQuote);
			}
			catch(Exception e)
			{
				/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
				if(commonServiceHelper.checkForRetryExceptions(e, 15, NGEConstants.CatchExceptionTypes.THROW_HANDLED_EXCEPTION))
				{
					logger.error("checkForRetryExceptions returned true");
				}
				/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
				ngeException.throwException(NGEErrorCodes.SERVICE_FAILED,NGEErrorCodes.ERROR_TYPE, null, null);
			}
			if(null == legacyWipQuoteRslt)
			{
				/* PI3 - Q3 2018 Maintenance Release 2.12 - Ensure to Bind all components in a bundle - Starts */
				logger.error("LegacyWipDAO - Debug - 21");
				/* PI3 - Q3 2018 Maintenance Release 2.12 - Ensure to Bind all components in a bundle - Ends */
				ngeException.throwException(NGEErrorCodes.SERVICE_FAILED,NGEErrorCodes.ERROR_TYPE, null, null);
			}

		}
		}
		else
		{
			addPolicyWipQuote(transactionComponentId, policyInfo.getPolicyId(), wipQuoteDetails, conversionRate, policyInfo);
		}
	}

	private TlegacyWipQuoteCurrency insertLocalCurrency(
			TlegacyWipQuoteCurrencyPK id, WIPQuoteDetails wipQuoteDetails, BigDecimal premium, TtransactionComponentLimit productlimit) throws AIGCIExceptionMsg {
		TlegacyWipQuoteCurrency legacyWipQuoteCurrency = new TlegacyWipQuoteCurrency();
		TlegacyWipQuoteCurrencyPK legacyWipQuoteCurrencyPK = new TlegacyWipQuoteCurrencyPK();
		Tcurrency localCurrency = null;
		legacyWipQuoteCurrencyPK.setTransactionComponentId(id.getTransactionComponentId());
		legacyWipQuoteCurrencyPK.setWipId(id.getWipId());
		legacyWipQuoteCurrencyPK.setQuoteSqn(id.getQuoteSqn());
		localCurrency = commonDAO.getCurrency(wipQuoteDetails.getCurrencyCd());
		if(localCurrency != null)
		{
			legacyWipQuoteCurrencyPK.setCurrencyId(localCurrency.getCurrencyId());
		}
		else
		{
			/* PI3 - Q3 2018 Maintenance Release 2.12 - Ensure to Bind all components in a bundle - Starts */
			logger.error("LegacyWipDAO - Debug - 22");
			/* PI3 - Q3 2018 Maintenance Release 2.12 - Ensure to Bind all components in a bundle - Ends */
			ngeException.throwException(NGEErrorCodes.SERVICE_FAILED,NGEErrorCodes.ERROR_TYPE, null, null);
		}
		legacyWipQuoteCurrency.setId(legacyWipQuoteCurrencyPK);
		legacyWipQuoteCurrency = setLocalAmt(wipQuoteDetails, legacyWipQuoteCurrency, premium, productlimit, true);
		legacyWipQuoteCurrency.setCreateTs(NGEDateUtil.getTodayDate());
		legacyWipQuoteCurrency.setCreateUserId(NGESession.getSessionData().getUserId());
		
		legacyWipQuoteCurrency.setUpdateTs(NGEDateUtil.getTodayDate());
		legacyWipQuoteCurrency.setUpdateUserId(NGESession.getSessionData().getUserId());
		
		
		return legacyWipQuoteCurrency;
	}

	/**
	 * @author Padma
	 * @param wipQuoteDetails
	 * @param conversionRate
	 * @param legacyWipQuoteCurrUSD
	 * @param premium 
	 * @param productlimit 
	 * @return
	 */
	private TlegacyWipQuoteCurrency setLegacyWipCurrencyForUsd(
			WIPQuoteDetails wipQuoteDetails, BigDecimal conversionRate, TlegacyWipQuoteCurrency legacyWipQuoteCurrUSD, BigDecimal premium, TtransactionComponentLimit productlimit, boolean canUpdateQuoteAmts) 
	{
		BigDecimal amount = null;
		
		if(canUpdateQuoteAmts){
			
			if(wipQuoteDetails.getQuotedAttachmentPointAmt()!=null){
				amount = wipQuoteDetails.getQuotedAttachmentPointAmt();
				if(null != conversionRate)
				{
					amount = conversion(amount, conversionRate);
				}
				legacyWipQuoteCurrUSD.setQuotedAtchmtPointAm(amount);
			}		
		
		/*else
		{
			amount = productlimit.getAttachmentPointAm();
			if(null != conversionRate)
			{
				amount = conversion(amount, conversionRate);
			}
			legacyWipQuoteCurrUSD.setQuotedAtchmtPointAm(amount);
		}
*/	
			
			if(wipQuoteDetails.getQuotedLimitAmt()!=null){
				amount = wipQuoteDetails.getQuotedLimitAmt();
				if(null != conversionRate)
				{
					amount = conversion(amount, conversionRate);
				}
				legacyWipQuoteCurrUSD.setQuotedLimitAm(amount);
			}		
		
		/*else
		{
			amount = productlimit.getLimitAm();
			if(null != conversionRate)
			{
				amount = conversion(amount, conversionRate);
			}
			legacyWipQuoteCurrUSD.setQuotedLimitAm(amount);
		}*/
		
			if(wipQuoteDetails.getQuotedPremiumAmt()!=null){
				amount = wipQuoteDetails.getQuotedPremiumAmt();
				if(null != conversionRate)
				{
					amount = conversion(amount, conversionRate);
				}
				legacyWipQuoteCurrUSD.setQuotedPremiumAm(amount);
			}
		}
		
		/*else
		{
			if(null != conversionRate)
			{
				amount = conversion(premium, conversionRate);
			}
			legacyWipQuoteCurrUSD.setQuotedPremiumAm(amount);
			legacyWipQuoteCurrUSD.setBoundPremiumAm(amount);
		}*/
		
		PolicyDetails policyDetails = wipQuoteDetails.getPolicyDetails();
		if(policyDetails != null)
		{
			if(policyDetails.getPolicyAttachmentPointAmt()!=null){
				amount = policyDetails.getPolicyAttachmentPointAmt();
				if(null != conversionRate)
				{
					amount = conversion(amount, conversionRate);
				}
				legacyWipQuoteCurrUSD.setPolicyAtchmtPointAm(amount);
			}
			else
			{
				amount = productlimit.getAttachmentPointAm();
				if(null != conversionRate)
				{
					amount = conversion(amount, conversionRate);
					legacyWipQuoteCurrUSD.setPolicyAtchmtPointAm(amount);
				}
			}

			if(policyDetails.getPolicyLimitAmt()!=null){
				amount = policyDetails.getPolicyLimitAmt();
				if(null != conversionRate)
				{
					amount = conversion(amount, conversionRate);
				}
				legacyWipQuoteCurrUSD.setPolicyLimitAm(amount);
			}
			else
			{
				amount = productlimit.getLimitAm();
				if(null != conversionRate)
				{
					amount = conversion(amount, conversionRate);
					legacyWipQuoteCurrUSD.setPolicyLimitAm(amount);
				}
			}

			if(policyDetails.getPolicyPartOfAmt()!=null){
				amount = policyDetails.getPolicyPartOfAmt();
				if(null != conversionRate)
				{
					amount = conversion(amount, conversionRate);
				}
				legacyWipQuoteCurrUSD.setPolicyPartOfAm(amount);
			}
			
			legacyWipQuoteCurrUSD.setBoundPremiumAm(premium);
		}
		return legacyWipQuoteCurrUSD;
	}
	//Abul changes defect 409 starts	
	public void insertCurrencyWipQuote(String transactionComponentId, Tpolicy policyInfo, WIPQuoteDetails wipQuoteDetails, BigDecimal conversionRate, TlegacyWipQuote legacyWipQuoteData,String lifeCycleStatus) throws AIGCIExceptionMsg {
		//Abul changes defect 409 ends
		
		TtransactionComponentLimit transactionCompUSDLimit = null;
		List<TtransactionComponentLimit> transactionComponentLimits = new ArrayList<TtransactionComponentLimit>();
		transactionComponentLimits = transactionComponentLimitRepository.getComponentLimit(transactionComponentId);
		if(transactionComponentLimits.isEmpty())
		{
			/* PI3 - Q3 2018 Maintenance Release 2.12 - Ensure to Bind all components in a bundle - Starts */
			logger.error("LegacyWipDAO - Debug - 23");
			/* PI3 - Q3 2018 Maintenance Release 2.12 - Ensure to Bind all components in a bundle - Ends */
			ngeException.throwException(NGEErrorCodes.SERVICE_FAILED,NGEErrorCodes.ERROR_TYPE, null, null);
		}
		
		transactionCompUSDLimit = productHelper.fetchLimitAmountByTransLimit(transactionComponentLimits, NGEConstants.USD);

			if(null == wipQuoteDetails)
			{
				insertWithOutWIPDetails(legacyWipQuoteData,transactionComponentId,policyInfo);
			}
			else if(wipQuoteDetails.getQuotedAttachmentPointAmt() == null || wipQuoteDetails.getQuotedLimitAmt() == null
					|| wipQuoteDetails.getQuotedPremiumAmt() == null || wipQuoteDetails.getPolicyDetails() == null)
			{
				//Abul changes defect 409 starts
				insertCurrencyIfAnyOneOfTheValuesAsNull(wipQuoteDetails,legacyWipQuoteData,transactionComponentId,lifeCycleStatus,conversionRate);
				//Abul changes defect 409 ends
			}
			else if((wipQuoteDetails.getPolicyDetails()!= null) && (wipQuoteDetails.getPolicyDetails().getPolicyAttachmentPointAmt()== null || wipQuoteDetails.getPolicyDetails().getPolicyLimitAmt() == null
					|| wipQuoteDetails.getPolicyDetails().getPolicyPartOfAmt() == null)){
				//Abul changes defect 409 starts
				insertCurrencyIfAnyOneOfTheValuesAsNull(wipQuoteDetails,legacyWipQuoteData,transactionComponentId,lifeCycleStatus,conversionRate);
				//Abul changes defect 409 ends
					
			}
			else{
				
				insertCurrencyIfWIPDetailsNotNull(wipQuoteDetails,transactionComponentId,legacyWipQuoteData,conversionRate,transactionCompUSDLimit);
			
			}

	}
	
	/*private void updateCurrencyIfWIPDetailsNotNull(
			WIPQuoteDetails wipQuoteDetails, TlegacyWipQuote legacyWipQuote, String transactionComponentId, BigDecimal conversionRate) throws AIGCIExceptionMsg {
		
		String inputCurrency = NGEConstants.EMPTY_STRING;
		TlegacyWipQuote legacyWipQuoteRslt = null;
		TlegacyWipQuoteCurrency legacyWipQuoteCurrRslt = null;
		TlegacyWipQuoteCurrency legacyWipQuoteCurrLocalRslt = null;
		Tcurrency currencyUsd = commonDAO.getCurrency(NGEConstants.USD);
		Set<TlegacyWipQuoteCurrency> TlegacyWipQuoteCurrencies = new HashSet<TlegacyWipQuoteCurrency>();
		List<TlegacyWipQuoteCurrency> legacyWipQuoteCurrencyData = getTlegacyWipQuoteCurrencyDetails(transactionComponentId, legacyWipQuote.getId().getWipId(), legacyWipQuote.getId().getQuoteSqn());
		inputCurrency = wipQuoteDetails.getCurrencyCd();
			if(null != legacyWipQuoteCurrencyData && !legacyWipQuoteCurrencyData.isEmpty())
			{
				for(TlegacyWipQuoteCurrency legacyWipQuoteCurrency: legacyWipQuoteCurrencyData)
				{	
					tlegacyWipQuoteCurrencyHsRepository.insertLegacyWIPQuoteCurrencyHistory(legacyWipQuoteCurrency.getId().getTransactionComponentId(), 
							legacyWipQuoteCurrency.getId().getWipId(), legacyWipQuoteCurrency.getId().getQuoteSqn());
				}
				//Input has USD Currency
				if(NGEConstants.USD.equalsIgnoreCase(inputCurrency))
				{
					if(legacyWipQuoteCurrencyData.size() == 1) //Input USD - table USD
					{
						legacyWipQuoteCurrRslt = setLegacyWipCurrencyForUsd(wipQuoteDetails, null, legacyWipQuoteCurrencyData.get(0));
						legacyWipQuoteCurrRslt.setUpdateTs(NGEDateUtil.getTodayDate());
						legacyWipQuoteCurrRslt.setUpdateUserId(NGESession.getSessionData().getUserId());
						TlegacyWipQuoteCurrencies.add(legacyWipQuoteCurrRslt);
					}
					else //Input USD - table local
					{
						for(TlegacyWipQuoteCurrency legacyWipQuoteCurr: legacyWipQuoteCurrencyData)
						{
							if(null != currencyUsd && legacyWipQuoteCurr.getId().getCurrencyId() != currencyUsd.getCurrencyId())
							{
								try
								{
									deleteLegacyWipQuoteCurrency(legacyWipQuoteCurr);
								}
								catch(Exception e)
								{
									ngeException.throwException(NGEErrorCodes.SERVICE_FAILED,NGEErrorCodes.ERROR_TYPE, null, null);
								}
							}
							else
							{
								legacyWipQuoteCurrRslt = setLegacyWipCurrencyForUsd(wipQuoteDetails, null, legacyWipQuoteCurr);
								TlegacyWipQuoteCurrencies.add(legacyWipQuoteCurrRslt);
							}
						}
					}
				}
				//Input has local currency
				else
				{
					if(legacyWipQuoteCurrencyData.size() == 1) //Input has local currency and table has USD
					{
						legacyWipQuoteCurrRslt = setLegacyWipCurrencyForUsd(wipQuoteDetails, conversionRate, legacyWipQuoteCurrencyData.get(0));
						TlegacyWipQuoteCurrencies.add(legacyWipQuoteCurrRslt);
						legacyWipQuoteCurrLocalRslt = insertLocalCurrency(legacyWipQuoteCurrRslt.getId(), wipQuoteDetails);					
						TlegacyWipQuoteCurrencies.add(legacyWipQuoteCurrLocalRslt);
					}
					else //Input has local and table has local curr
					{
						for(TlegacyWipQuoteCurrency legacyWipQuoteCurr: legacyWipQuoteCurrencyData)
						{
							if(null != currencyUsd && legacyWipQuoteCurr.getId().getCurrencyId() == currencyUsd.getCurrencyId()) // USD record
							{
								legacyWipQuoteCurrRslt = setLegacyWipCurrencyForUsd(wipQuoteDetails, conversionRate, legacyWipQuoteCurr);
								TlegacyWipQuoteCurrencies.add(legacyWipQuoteCurrRslt);
							}
							else
							{
								legacyWipQuoteCurrLocalRslt = setLegacyWipCurrencyForLocal(wipQuoteDetails, legacyWipQuoteCurr);
								TlegacyWipQuoteCurrencies.add(legacyWipQuoteCurrLocalRslt);
							}
						}
					}	

				}
				legacyWipQuote.setTlegacyWipQuoteCurrencies(TlegacyWipQuoteCurrencies);

			}
		try
		{
			legacyWipQuoteRslt = saveLegacyWipQuote(legacyWipQuote);
		}
		catch(Exception e)
		{
			ngeException.throwException(NGEErrorCodes.SERVICE_FAILED,NGEErrorCodes.ERROR_TYPE, null, null);
		}
		if(null == legacyWipQuoteRslt)
		{
			ngeException.throwException(NGEErrorCodes.SERVICE_FAILED,NGEErrorCodes.ERROR_TYPE, null, null);
		}
	}
*/
	/*private void updateCurrencyIfAnyOneOfTheValuesAsNull(
			WIPQuoteDetails wipQuoteDetails, TlegacyWipQuote legacyWipQuote, String transactionComponentId) throws AIGCIExceptionMsg {
		
		String inputCurrency = NGEConstants.EMPTY_STRING;
		TlegacyWipQuote legacyWipQuoteRslt = null;
		TlegacyWipQuoteCurrency legacyWipQuoteCurrRslt = null;
		TlegacyWipQuoteCurrency legacyWipQuoteCurrLocalRslt = null;
		Tcurrency currencyUsd = commonDAO.getCurrency(NGEConstants.USD);
		Set<TlegacyWipQuoteCurrency> TlegacyWipQuoteCurrencies = new HashSet<TlegacyWipQuoteCurrency>();
		List<TtransactionComponentLimit> transactionComponentLimits = new ArrayList<TtransactionComponentLimit>();
		transactionComponentLimits = transactionComponentLimitRepository.getComponentLimit(transactionComponentId);
		List<TlegacyWipQuoteCurrency> legacyWipQuoteCurrencyData = getTlegacyWipQuoteCurrencyDetails(transactionComponentId, legacyWipQuote.getId().getWipId(), legacyWipQuote.getId().getQuoteSqn());
		
			if(!transactionComponentLimits.isEmpty())
			{
				
				if(wipQuoteDetails.getCurrencyCd()!=null){
					inputCurrency = wipQuoteDetails.getCurrencyCd();
					
				}
				else
				{
					if(transactionComponentLimits.size() >1)
					{
						for(TtransactionComponentLimit transactionComponentLimit:transactionComponentLimits)
						{
							if(!NGEConstants.USD.equalsIgnoreCase(transactionComponentLimit.getTcurrency().getCurrencyCd()))
							{
								inputCurrency = transactionComponentLimit.getTcurrency().getCurrencyCd();
							}
						}
					}
					else
					{
						inputCurrency = transactionComponentLimits.get(0).getTcurrency().getCurrencyCd();
					}
					
					
				}
				
				if(null != legacyWipQuoteCurrencyData && !legacyWipQuoteCurrencyData.isEmpty())
				{
					for(TlegacyWipQuoteCurrency legacyWipQuoteCurrency: legacyWipQuoteCurrencyData)
					{	
						tlegacyWipQuoteCurrencyHsRepository.insertLegacyWIPQuoteCurrencyHistory(legacyWipQuoteCurrency.getId().getTransactionComponentId(), 
								legacyWipQuoteCurrency.getId().getWipId(), legacyWipQuoteCurrency.getId().getQuoteSqn());
					}
					//Input has USD Currency
					if(NGEConstants.USD.equalsIgnoreCase(inputCurrency))
					{
						if(legacyWipQuoteCurrencyData.size() == 1) //Input USD - table USD
						{
							legacyWipQuoteCurrRslt = legacyWipQuoteCurrencyData.get(0);
							for(TtransactionComponentLimit transactionComponentLimit:transactionComponentLimits)
							{
								if(NGEConstants.USD.equalsIgnoreCase(transactionComponentLimit.getTcurrency().getCurrencyCd()))
								{
									
									if(wipQuoteDetails.getPolicyDetails().getPolicyAttachmentPointAmt()==null){
										legacyWipQuoteCurrRslt.setPolicyAtchmtPointAm(transactionComponentLimit.getAttachmentPointAm());
									}else{
										legacyWipQuoteCurrRslt.setPolicyAtchmtPointAm(wipQuoteDetails.getPolicyDetails().getPolicyAttachmentPointAmt());
									}
									if(wipQuoteDetails.getQuotedAttachmentPointAmt()==null){
										legacyWipQuoteCurrRslt.setQuotedAtchmtPointAm(transactionComponentLimit.getAttachmentPointAm());
									}else{
										legacyWipQuoteCurrRslt.setQuotedAtchmtPointAm(wipQuoteDetails.getQuotedAttachmentPointAmt());
									}
									
									if(wipQuoteDetails.getQuotedLimitAmt()==null){
										legacyWipQuoteCurrRslt.setQuotedLimitAm(transactionComponentLimit.getLimitAm());
									}
									else{
										legacyWipQuoteCurrRslt.setQuotedLimitAm(wipQuoteDetails.getQuotedLimitAmt());
									}
									if(wipQuoteDetails.getPolicyDetails().getPolicyLimitAmt()==null){
										legacyWipQuoteCurrRslt.setPolicyLimitAm(transactionComponentLimit.getLimitAm());
									}
									else{
										legacyWipQuoteCurrRslt.setPolicyLimitAm(wipQuoteDetails.getPolicyDetails().getPolicyLimitAmt());
									}
									if(wipQuoteDetails.getQuotedPremiumAmt()==null){
										legacyWipQuoteCurrRslt.setQuotedPremiumAm(transactionComponentLimit.getPremiumAm());
									}
									else{
										legacyWipQuoteCurrRslt.setQuotedPremiumAm(wipQuoteDetails.getQuotedPremiumAmt());
									}
									
								}
							}
							legacyWipQuoteCurrRslt.setUpdateTs(NGEDateUtil.getTodayDate());
							legacyWipQuoteCurrRslt.setUpdateUserId(NGESession.getSessionData().getUserId());
							TlegacyWipQuoteCurrencies.add(legacyWipQuoteCurrRslt);
						}
						else //Input USD - table local
						{
							legacyWipQuoteCurrRslt = legacyWipQuoteCurrencyData.get(0);
							for(TlegacyWipQuoteCurrency legacyWipQuoteCurr: legacyWipQuoteCurrencyData)
							{
								if(null != currencyUsd && legacyWipQuoteCurr.getId().getCurrencyId() != currencyUsd.getCurrencyId())
								{
									try
									{
										deleteLegacyWipQuoteCurrency(legacyWipQuoteCurr);
									}
									catch(Exception e)
									{
										ngeException.throwException(NGEErrorCodes.SERVICE_FAILED,NGEErrorCodes.ERROR_TYPE, null, null);
									}
								}
								else
								{
									for(TtransactionComponentLimit transactionComponentLimit:transactionComponentLimits)
									{
										if(NGEConstants.USD.equalsIgnoreCase(transactionComponentLimit.getTcurrency().getCurrencyCd()))
										{
											if(wipQuoteDetails.getPolicyDetails().getPolicyAttachmentPointAmt()==null){
												legacyWipQuoteCurrRslt.setPolicyAtchmtPointAm(transactionComponentLimit.getAttachmentPointAm());
											}else{
												legacyWipQuoteCurrRslt.setPolicyAtchmtPointAm(wipQuoteDetails.getPolicyDetails().getPolicyAttachmentPointAmt());
											}
											if(wipQuoteDetails.getQuotedAttachmentPointAmt()==null){
												legacyWipQuoteCurrRslt.setQuotedAtchmtPointAm(transactionComponentLimit.getAttachmentPointAm());
											}else{
												legacyWipQuoteCurrRslt.setQuotedAtchmtPointAm(wipQuoteDetails.getQuotedAttachmentPointAmt());
											}
											
											if(wipQuoteDetails.getQuotedLimitAmt()==null){
												legacyWipQuoteCurrRslt.setQuotedLimitAm(transactionComponentLimit.getLimitAm());
											}
											else{
												legacyWipQuoteCurrRslt.setQuotedLimitAm(wipQuoteDetails.getQuotedLimitAmt());
											}
											if(wipQuoteDetails.getPolicyDetails().getPolicyLimitAmt()==null){
												legacyWipQuoteCurrRslt.setPolicyLimitAm(transactionComponentLimit.getLimitAm());
											}
											else{
												legacyWipQuoteCurrRslt.setPolicyLimitAm(wipQuoteDetails.getPolicyDetails().getPolicyLimitAmt());
											}
											if(wipQuoteDetails.getQuotedPremiumAmt()==null){
												legacyWipQuoteCurrRslt.setQuotedPremiumAm(transactionComponentLimit.getPremiumAm());
											}
											else{
												legacyWipQuoteCurrRslt.setQuotedPremiumAm(wipQuoteDetails.getQuotedPremiumAmt());
											}
										}
									}
									legacyWipQuoteCurr.setUpdateTs(NGEDateUtil.getTodayDate());
									legacyWipQuoteCurr.setUpdateUserId(NGESession.getSessionData().getUserId());
									TlegacyWipQuoteCurrencies.add(legacyWipQuoteCurr);
								}
							}
						}
					}
					//Input has local currency
					else
					{
						legacyWipQuoteCurrRslt = legacyWipQuoteCurrencyData.get(0);
						if(legacyWipQuoteCurrencyData.size() == 1) //Input has local currency and table has USD
						{
							legacyWipQuoteCurrRslt = legacyWipQuoteCurrencyData.get(0);
							for(TtransactionComponentLimit transactionComponentLimit:transactionComponentLimits)
							{
								if(NGEConstants.USD.equalsIgnoreCase(transactionComponentLimit.getTcurrency().getCurrencyCd()))
								{
									if(wipQuoteDetails.getPolicyDetails().getPolicyAttachmentPointAmt()==null){
										legacyWipQuoteCurrRslt.setPolicyAtchmtPointAm(transactionComponentLimit.getAttachmentPointAm());
									}else{
										legacyWipQuoteCurrRslt.setPolicyAtchmtPointAm(wipQuoteDetails.getPolicyDetails().getPolicyAttachmentPointAmt());
									}
									if(wipQuoteDetails.getQuotedAttachmentPointAmt()==null){
										legacyWipQuoteCurrRslt.setQuotedAtchmtPointAm(transactionComponentLimit.getAttachmentPointAm());
									}else{
										legacyWipQuoteCurrRslt.setQuotedAtchmtPointAm(wipQuoteDetails.getQuotedAttachmentPointAmt());
									}
									
									if(wipQuoteDetails.getQuotedLimitAmt()==null){
										legacyWipQuoteCurrRslt.setQuotedLimitAm(transactionComponentLimit.getLimitAm());
									}
									else{
										legacyWipQuoteCurrRslt.setQuotedLimitAm(wipQuoteDetails.getQuotedLimitAmt());
									}
									if(wipQuoteDetails.getPolicyDetails().getPolicyLimitAmt()==null){
										legacyWipQuoteCurrRslt.setPolicyLimitAm(transactionComponentLimit.getLimitAm());
									}
									else{
										legacyWipQuoteCurrRslt.setPolicyLimitAm(wipQuoteDetails.getPolicyDetails().getPolicyLimitAmt());
									}
									if(wipQuoteDetails.getQuotedPremiumAmt()==null){
										legacyWipQuoteCurrRslt.setQuotedPremiumAm(transactionComponentLimit.getPremiumAm());
									}
									else{
										legacyWipQuoteCurrRslt.setQuotedPremiumAm(wipQuoteDetails.getQuotedPremiumAmt());
									}
									legacyWipQuoteCurrRslt.setUpdateTs(NGEDateUtil.getTodayDate());
									legacyWipQuoteCurrRslt.setUpdateUserId(NGESession.getSessionData().getUserId());
									TlegacyWipQuoteCurrencies.add(legacyWipQuoteCurrRslt);
								}
								else
								{
									legacyWipQuoteCurrRslt = legacyWipQuoteCurrencyData.get(0);
									legacyWipQuoteCurrLocalRslt = new TlegacyWipQuoteCurrency();
									TlegacyWipQuoteCurrencyPK legacyWipQuoteCurrencyPk = new TlegacyWipQuoteCurrencyPK();
									legacyWipQuoteCurrencyPk.setTransactionComponentId(transactionComponentId);
									legacyWipQuoteCurrencyPk.setQuoteSqn(legacyWipQuoteCurrRslt.getId().getQuoteSqn());
									legacyWipQuoteCurrencyPk.setWipId(legacyWipQuoteCurrRslt.getId().getWipId());
									Tcurrency currencyLocal = commonDAO.getCurrency(inputCurrency);
									legacyWipQuoteCurrencyPk.setCurrencyId(currencyLocal.getCurrencyId());
									legacyWipQuoteCurrLocalRslt.setId(legacyWipQuoteCurrencyPk);
									legacyWipQuoteCurrLocalRslt.setCreateUserId(NGESession.getSessionData().getUserId());
									legacyWipQuoteCurrLocalRslt.setCreateTs(NGEDateUtil.getTodayDate());
									if(wipQuoteDetails.getPolicyDetails().getPolicyAttachmentPointAmt()==null){
										legacyWipQuoteCurrRslt.setPolicyAtchmtPointAm(transactionComponentLimit.getAttachmentPointAm());
									}else{
										legacyWipQuoteCurrRslt.setPolicyAtchmtPointAm(wipQuoteDetails.getPolicyDetails().getPolicyAttachmentPointAmt());
									}
									if(wipQuoteDetails.getQuotedAttachmentPointAmt()==null){
										legacyWipQuoteCurrRslt.setQuotedAtchmtPointAm(transactionComponentLimit.getAttachmentPointAm());
									}else{
										legacyWipQuoteCurrRslt.setQuotedAtchmtPointAm(wipQuoteDetails.getQuotedAttachmentPointAmt());
									}
									
									if(wipQuoteDetails.getQuotedLimitAmt()==null){
										legacyWipQuoteCurrRslt.setQuotedLimitAm(transactionComponentLimit.getLimitAm());
									}
									else{
										legacyWipQuoteCurrRslt.setQuotedLimitAm(wipQuoteDetails.getQuotedLimitAmt());
									}
									if(wipQuoteDetails.getPolicyDetails().getPolicyLimitAmt()==null){
										legacyWipQuoteCurrRslt.setPolicyLimitAm(transactionComponentLimit.getLimitAm());
									}
									else{
										legacyWipQuoteCurrRslt.setPolicyLimitAm(wipQuoteDetails.getPolicyDetails().getPolicyLimitAmt());
									}
									if(wipQuoteDetails.getQuotedPremiumAmt()==null){
										legacyWipQuoteCurrRslt.setQuotedPremiumAm(transactionComponentLimit.getPremiumAm());
									}
									else{
										legacyWipQuoteCurrRslt.setQuotedPremiumAm(wipQuoteDetails.getQuotedPremiumAmt());
									}										TlegacyWipQuoteCurrencies.add(legacyWipQuoteCurrLocalRslt);
								}
							}
							
						}
						else //Input has local and table has local curr
						{
							for(TlegacyWipQuoteCurrency legacyWipQuoteCurr: legacyWipQuoteCurrencyData)
							{
								for(TtransactionComponentLimit transactionComponentLimit:transactionComponentLimits)
								{
									attachmentPointAmt = transactionComponentLimit.getAttachmentPointAm().divide(conversionRate);
									attachmentPointAmt = attachmentPointAmt.setScale(6, RoundingMode.HALF_UP);
									limitAmt = transactionComponentLimit.getLimitAm().divide(conversionRate);
									limitAmt = limitAmt.setScale(6, RoundingMode.HALF_UP);
									if(NGEConstants.USD.equalsIgnoreCase(transactionComponentLimit.getTcurrency().getCurrencyCd())
											&& currencyUsd.getCurrencyId() == legacyWipQuoteCurr.getId().getCurrencyId())
									{
										if(wipQuoteDetails.getPolicyDetails().getPolicyAttachmentPointAmt()==null){
											legacyWipQuoteCurr.setPolicyAtchmtPointAm(transactionComponentLimit.getAttachmentPointAm());
										}else{
											legacyWipQuoteCurr.setPolicyAtchmtPointAm(wipQuoteDetails.getPolicyDetails().getPolicyAttachmentPointAmt());
										}
										if(wipQuoteDetails.getQuotedAttachmentPointAmt()==null){
											legacyWipQuoteCurr.setQuotedAtchmtPointAm(transactionComponentLimit.getAttachmentPointAm());
										}else{
											legacyWipQuoteCurr.setQuotedAtchmtPointAm(wipQuoteDetails.getQuotedAttachmentPointAmt());
										}
										
										if(wipQuoteDetails.getQuotedLimitAmt()==null){
											legacyWipQuoteCurr.setQuotedLimitAm(transactionComponentLimit.getLimitAm());
										}
										else{
											legacyWipQuoteCurr.setQuotedLimitAm(wipQuoteDetails.getQuotedLimitAmt());
										}
										if(wipQuoteDetails.getPolicyDetails().getPolicyLimitAmt()==null){
											legacyWipQuoteCurr.setPolicyLimitAm(transactionComponentLimit.getLimitAm());
										}
										else{
											legacyWipQuoteCurr.setPolicyLimitAm(wipQuoteDetails.getPolicyDetails().getPolicyLimitAmt());
										}
										if(wipQuoteDetails.getQuotedPremiumAmt()==null){
											legacyWipQuoteCurr.setQuotedPremiumAm(transactionComponentLimit.getPremiumAm());
										}
										else{
											legacyWipQuoteCurr.setQuotedPremiumAm(wipQuoteDetails.getQuotedPremiumAmt());
										}
										legacyWipQuoteCurr.setUpdateTs(NGEDateUtil.getTodayDate());
										legacyWipQuoteCurr.setUpdateUserId(NGESession.getSessionData().getUserId());
										TlegacyWipQuoteCurrencies.add(legacyWipQuoteCurr);
									}
									else if(!NGEConstants.USD.equalsIgnoreCase(transactionComponentLimit.getTcurrency().getCurrencyCd())
											&& currencyUsd.getCurrencyId() != legacyWipQuoteCurr.getId().getCurrencyId())
									{
										if(wipQuoteDetails.getPolicyDetails().getPolicyAttachmentPointAmt()==null){
											legacyWipQuoteCurr.setPolicyAtchmtPointAm(transactionComponentLimit.getAttachmentPointAm());
										}else{
											legacyWipQuoteCurr.setPolicyAtchmtPointAm(wipQuoteDetails.getPolicyDetails().getPolicyAttachmentPointAmt());
										}
										if(wipQuoteDetails.getQuotedAttachmentPointAmt()==null){
											legacyWipQuoteCurr.setQuotedAtchmtPointAm(transactionComponentLimit.getAttachmentPointAm());
										}else{
											legacyWipQuoteCurr.setQuotedAtchmtPointAm(wipQuoteDetails.getQuotedAttachmentPointAmt());
										}
										
										if(wipQuoteDetails.getQuotedLimitAmt()==null){
											legacyWipQuoteCurr.setQuotedLimitAm(transactionComponentLimit.getLimitAm());
										}
										else{
											legacyWipQuoteCurr.setQuotedLimitAm(wipQuoteDetails.getQuotedLimitAmt());
										}
										if(wipQuoteDetails.getPolicyDetails().getPolicyLimitAmt()==null){
											legacyWipQuoteCurr.setPolicyLimitAm(transactionComponentLimit.getLimitAm());
										}
										else{
											legacyWipQuoteCurr.setPolicyLimitAm(wipQuoteDetails.getPolicyDetails().getPolicyLimitAmt());
										}
										if(wipQuoteDetails.getQuotedPremiumAmt()==null){
											legacyWipQuoteCurr.setQuotedPremiumAm(transactionComponentLimit.getPremiumAm());
										}
										else{
											legacyWipQuoteCurr.setQuotedPremiumAm(wipQuoteDetails.getQuotedPremiumAmt());
										}
										legacyWipQuoteCurr.setUpdateTs(NGEDateUtil.getTodayDate());
										legacyWipQuoteCurr.setUpdateUserId(NGESession.getSessionData().getUserId());
										TlegacyWipQuoteCurrencies.add(legacyWipQuoteCurr);
									}

								}
							}
						}
					}	
				}
			legacyWipQuote.setTlegacyWipQuoteCurrencies(TlegacyWipQuoteCurrencies);
				
			
		}
		try
		{
			legacyWipQuoteRslt = saveLegacyWipQuote(legacyWipQuote);
		}
		catch(Exception e)
		{
			ngeException.throwException(NGEErrorCodes.SERVICE_FAILED,NGEErrorCodes.ERROR_TYPE, null, null);
		}
		if(null == legacyWipQuoteRslt)
		{
			ngeException.throwException(NGEErrorCodes.SERVICE_FAILED,NGEErrorCodes.ERROR_TYPE, null, null);
		}
	}

	private void updateWithOutWIPDetails(WIPQuoteDetails wipQuoteDetails, TlegacyWipQuote legacyWipQuoteData, String transactionComponentId,Tpolicy policyInfo) throws AIGCIExceptionMsg {
		
		String inputCurrency = NGEConstants.EMPTY_STRING;
		TlegacyWipQuote legacyWipQuoteRslt = null;
		TlegacyWipQuoteCurrency legacyWipQuoteCurrRslt = null;
		TlegacyWipQuoteCurrency legacyWipQuoteCurrLocalRslt = null;
		Tcurrency currencyUsd = commonDAO.getCurrency(NGEConstants.USD);
		Set<TlegacyWipQuoteCurrency> TlegacyWipQuoteCurrencies = new HashSet<TlegacyWipQuoteCurrency>();
		List<TtransactionComponentLimit> transactionComponentLimits = new ArrayList<TtransactionComponentLimit>();
		transactionComponentLimits = transactionComponentLimitRepository.getComponentLimit(transactionComponentId);
		
		List<TlegacyWipQuoteCurrency> legacyWipQuoteCurrencyData = getTlegacyWipQuoteCurrencyDetails(transactionComponentId, legacyWipQuoteData.getId().getWipId(), legacyWipQuoteData.getId().getQuoteSqn());

		inputCurrency = policyInfo.getTcurrency().getCurrencyCd();
		if(!transactionComponentLimits.isEmpty())
		{
			if(null != legacyWipQuoteCurrencyData && !legacyWipQuoteCurrencyData.isEmpty())
			{
				for(TlegacyWipQuoteCurrency legacyWipQuoteCurrency: legacyWipQuoteCurrencyData)
				{	
					tlegacyWipQuoteCurrencyHsRepository.insertLegacyWIPQuoteCurrencyHistory(legacyWipQuoteCurrency.getId().getTransactionComponentId(), 
							legacyWipQuoteCurrency.getId().getWipId(), legacyWipQuoteCurrency.getId().getQuoteSqn());
				}
				//Input has USD Currency
				if(NGEConstants.USD.equalsIgnoreCase(inputCurrency))
				{
					if(legacyWipQuoteCurrencyData.size() == 1) //Input USD - table USD
					{
						legacyWipQuoteCurrRslt = legacyWipQuoteCurrencyData.get(0);
						for(TtransactionComponentLimit transactionComponentLimit:transactionComponentLimits)
						{
							if(NGEConstants.USD.equalsIgnoreCase(transactionComponentLimit.getTcurrency().getCurrencyCd()))
							{
								legacyWipQuoteCurrRslt.setPolicyAtchmtPointAm(transactionComponentLimit.getAttachmentPointAm());
								legacyWipQuoteCurrRslt.setQuotedAtchmtPointAm(transactionComponentLimit.getAttachmentPointAm());
								legacyWipQuoteCurrRslt.setQuotedLimitAm(transactionComponentLimit.getLimitAm());
								legacyWipQuoteCurrRslt.setPolicyLimitAm(transactionComponentLimit.getLimitAm());
							}
						}
						legacyWipQuoteCurrRslt.setUpdateTs(NGEDateUtil.getTodayDate());
						legacyWipQuoteCurrRslt.setUpdateUserId(NGESession.getSessionData().getUserId());
						TlegacyWipQuoteCurrencies.add(legacyWipQuoteCurrRslt);
					}
					else //Input USD - table local
					{
						for(TlegacyWipQuoteCurrency legacyWipQuoteCurr: legacyWipQuoteCurrencyData)
						{
							if(null != currencyUsd && legacyWipQuoteCurr.getId().getCurrencyId() != currencyUsd.getCurrencyId())
							{
								try
								{
									deleteLegacyWipQuoteCurrency(legacyWipQuoteCurr);
								}
								catch(Exception e)
								{
									ngeException.throwException(NGEErrorCodes.SERVICE_FAILED,NGEErrorCodes.ERROR_TYPE, null, null);
								}
							}
							else
							{
								for(TtransactionComponentLimit transactionComponentLimit:transactionComponentLimits)
								{
									if(NGEConstants.USD.equalsIgnoreCase(transactionComponentLimit.getTcurrency().getCurrencyCd()))
									{
										legacyWipQuoteCurr.setPolicyAtchmtPointAm(transactionComponentLimit.getAttachmentPointAm());
										legacyWipQuoteCurr.setQuotedAtchmtPointAm(transactionComponentLimit.getAttachmentPointAm());
										legacyWipQuoteCurr.setQuotedLimitAm(transactionComponentLimit.getLimitAm());
										legacyWipQuoteCurr.setPolicyLimitAm(transactionComponentLimit.getLimitAm());
									}
								}
								legacyWipQuoteCurr.setUpdateTs(NGEDateUtil.getTodayDate());
								legacyWipQuoteCurr.setUpdateUserId(NGESession.getSessionData().getUserId());
								TlegacyWipQuoteCurrencies.add(legacyWipQuoteCurr);
							}
						}
					}
				}
				//Input has local currency
				else
				{
					if(legacyWipQuoteCurrencyData.size() == 1) //Input has local currency and table has USD
					{
						legacyWipQuoteCurrRslt = legacyWipQuoteCurrencyData.get(0);
						for(TtransactionComponentLimit transactionComponentLimit:transactionComponentLimits)
						{
							if(NGEConstants.USD.equalsIgnoreCase(transactionComponentLimit.getTcurrency().getCurrencyCd()))
							{
								legacyWipQuoteCurrRslt.setPolicyAtchmtPointAm(transactionComponentLimit.getAttachmentPointAm());
								legacyWipQuoteCurrRslt.setQuotedAtchmtPointAm(transactionComponentLimit.getAttachmentPointAm());
								legacyWipQuoteCurrRslt.setQuotedLimitAm(transactionComponentLimit.getLimitAm());
								legacyWipQuoteCurrRslt.setPolicyLimitAm(transactionComponentLimit.getLimitAm());
								legacyWipQuoteCurrRslt.setUpdateTs(NGEDateUtil.getTodayDate());
								legacyWipQuoteCurrRslt.setUpdateUserId(NGESession.getSessionData().getUserId());
								TlegacyWipQuoteCurrencies.add(legacyWipQuoteCurrRslt);
							}
							else
							{
								legacyWipQuoteCurrLocalRslt = new TlegacyWipQuoteCurrency();
								TlegacyWipQuoteCurrencyPK legacyWipQuoteCurrencyPk = new TlegacyWipQuoteCurrencyPK();
								legacyWipQuoteCurrencyPk.setTransactionComponentId(transactionComponentId);
								legacyWipQuoteCurrencyPk.setQuoteSqn(legacyWipQuoteCurrRslt.getId().getQuoteSqn());
								legacyWipQuoteCurrencyPk.setWipId(legacyWipQuoteCurrRslt.getId().getWipId());
								Tcurrency currencyLocal = commonDAO.getCurrency(inputCurrency);
								legacyWipQuoteCurrencyPk.setCurrencyId(currencyLocal.getCurrencyId());
								legacyWipQuoteCurrLocalRslt.setId(legacyWipQuoteCurrencyPk);
								legacyWipQuoteCurrLocalRslt.setCreateUserId(NGESession.getSessionData().getUserId());
								legacyWipQuoteCurrLocalRslt.setCreateTs(NGEDateUtil.getTodayDate());
								legacyWipQuoteCurrLocalRslt.setPolicyAtchmtPointAm(transactionComponentLimit.getAttachmentPointAm());
								legacyWipQuoteCurrLocalRslt.setQuotedAtchmtPointAm(transactionComponentLimit.getAttachmentPointAm());
								legacyWipQuoteCurrLocalRslt.setQuotedPremiumAm(policyInfo.getLocalCurrencyPremiumAm());
								legacyWipQuoteCurrLocalRslt.setQuotedLimitAm(transactionComponentLimit.getLimitAm());
								legacyWipQuoteCurrLocalRslt.setPolicyLimitAm(transactionComponentLimit.getLimitAm());
								TlegacyWipQuoteCurrencies.add(legacyWipQuoteCurrLocalRslt);
							}
						}
						
					}
					else //Input has local and table has local curr
					{
						for(TlegacyWipQuoteCurrency legacyWipQuoteCurr: legacyWipQuoteCurrencyData)
						{
							for(TtransactionComponentLimit transactionComponentLimit:transactionComponentLimits)
							{
								attachmentPointAmt = transactionComponentLimit.getAttachmentPointAm().divide(conversionRate);
								attachmentPointAmt = attachmentPointAmt.setScale(6, RoundingMode.HALF_UP);
								limitAmt = transactionComponentLimit.getLimitAm().divide(conversionRate);
								limitAmt = limitAmt.setScale(6, RoundingMode.HALF_UP);
								if(NGEConstants.USD.equalsIgnoreCase(transactionComponentLimit.getTcurrency().getCurrencyCd())
										&& currencyUsd.getCurrencyId() == legacyWipQuoteCurr.getId().getCurrencyId())
								{
									legacyWipQuoteCurr.setPolicyAtchmtPointAm(transactionComponentLimit.getAttachmentPointAm());
									legacyWipQuoteCurr.setQuotedAtchmtPointAm(transactionComponentLimit.getAttachmentPointAm());
									legacyWipQuoteCurr.setQuotedLimitAm(transactionComponentLimit.getLimitAm());
									legacyWipQuoteCurr.setPolicyLimitAm(transactionComponentLimit.getLimitAm());
									legacyWipQuoteCurr.setUpdateTs(NGEDateUtil.getTodayDate());
									legacyWipQuoteCurr.setUpdateUserId(NGESession.getSessionData().getUserId());
									TlegacyWipQuoteCurrencies.add(legacyWipQuoteCurr);
								}
								else if(!NGEConstants.USD.equalsIgnoreCase(transactionComponentLimit.getTcurrency().getCurrencyCd())
										&& currencyUsd.getCurrencyId() != legacyWipQuoteCurr.getId().getCurrencyId())
								{
									legacyWipQuoteCurr.setPolicyAtchmtPointAm(transactionComponentLimit.getAttachmentPointAm());
									legacyWipQuoteCurr.setPolicyLimitAm(transactionComponentLimit.getLimitAm());
									legacyWipQuoteCurr.setQuotedAtchmtPointAm(transactionComponentLimit.getAttachmentPointAm());
									legacyWipQuoteCurr.setQuotedLimitAm(transactionComponentLimit.getLimitAm());
									legacyWipQuoteCurr.setUpdateTs(NGEDateUtil.getTodayDate());
									legacyWipQuoteCurr.setUpdateUserId(NGESession.getSessionData().getUserId());
									TlegacyWipQuoteCurrencies.add(legacyWipQuoteCurr);
								}

							}
						}
					}
				}	
			}
			legacyWipQuoteData.setTlegacyWipQuoteCurrencies(TlegacyWipQuoteCurrencies);
		}
	
		
		try
		{
			legacyWipQuoteRslt = saveLegacyWipQuote(legacyWipQuoteData);
		}
		catch(Exception e)
		{
			ngeException.throwException(NGEErrorCodes.SERVICE_FAILED,NGEErrorCodes.ERROR_TYPE, null, null);
		}
		if(null == legacyWipQuoteRslt)
		{
			ngeException.throwException(NGEErrorCodes.SERVICE_FAILED,NGEErrorCodes.ERROR_TYPE, null, null);
		}
	}*/
	
	

	/**
	 * @author Padma
	 * @param legacyWipQuoteCurr
	 */
	private void deleteLegacyWipQuoteCurrency(
			TlegacyWipQuoteCurrency legacyWipQuoteCurr) {
		try {
			historyHelper.createTlegacyWipQuoteCurrencyHHistory(legacyWipQuoteCurr);
		} catch (AIGCIExceptionMsg e) {
			logger.error(e.getMessage());
		}
		tlegacyWipQuoteCurrencyRepository.delete(legacyWipQuoteCurr);
	}

	/**
	 * @author Padma
	 * @param wipQuoteDetails
	 * @param legacyWipQuoteCurrency
	 * @param productlimit 
	 * @param premium 
	 * @return
	 * @throws AIGCIExceptionMsg 
	 */
	private TlegacyWipQuoteCurrency setLegacyWipCurrencyForLocal(
			WIPQuoteDetails wipQuoteDetails, TlegacyWipQuoteCurrency legacyWipQuoteCurrency, BigDecimal premium, TtransactionComponentLimit productlimit) throws AIGCIExceptionMsg {
		//TlegacyWipQuoteCurrencyPK legacyWipQuoteCurrencyPK = legacyWipQuoteCurrency.getId();
		Tcurrency currency = commonDAO.getCurrency(wipQuoteDetails.getCurrencyCd());
		/*legacyWipQuoteCurrencyPK.setCurrencyId(currency.getCurrencyId());
		legacyWipQuoteCurrency.setId(legacyWipQuoteCurrencyPK);*/
		legacyWipQuoteCurrency.setTcurrency(currency);
		legacyWipQuoteCurrency = setLocalAmt(wipQuoteDetails, legacyWipQuoteCurrency, premium, productlimit, true);
		/*legacyWipQuoteCurrency.setUpdateUserId(NGESession.getSessionData().getUserId());
		legacyWipQuoteCurrency.setUpdateTs(NGEDateUtil.getTodayDate());*/
		return legacyWipQuoteCurrency;
	}

	
	private BigDecimal getCurrencyRate(Set<TtransactionComponentLimit> limitList, String currencyCd) throws AIGCIExceptionMsg {
		
		HashMap<String, BigDecimal> sourceMap = null;
		String localCurrencyCd = NGEConstants.EMPTY_STRING;
		Tcurrency currency = null;
		BigDecimal rate = new BigDecimal("0");
		String aigCurrencyCd = NGEConstants.EMPTY_STRING;
		
		
		if(null != limitList){
			for(TtransactionComponentLimit limitItr : limitList){
		
				localCurrencyCd = limitItr.getTcurrency().getCurrencyCd();
			
				if(!localCurrencyCd.equalsIgnoreCase(NGEConstants.USD)){
					currency = commonDAO.getCurrency(localCurrencyCd);
				}
			}
		}
		else{
			currency = commonDAO.getCurrency(currencyCd);
		}
		if(null != currency)
		{
			aigCurrencyCd = currency.getAigCurrencyCd();
		}
		
		sourceMap = cache.getCurrencyRate();
		if(null == sourceMap)
		{
			ngeException.throwException(NGEErrorCodes.PROBLEM_IN_CURRENCY_CONNVERSION_SERVICE,
					NGEErrorCodes.ERROR_TYPE, "Problem occurred in currency conversion service", null);
		}
		else
		{	
			logger.info("SourceMap Values:" +sourceMap.values());
			rate = sourceMap.get(aigCurrencyCd);
			if(rate == null){
				logger.info("AIG Currency Code not available from Currency Conversion Service Response");
				ngeException.throwException(NGEErrorCodes.AIG_CURRENCY_NOT_MATCHING,
						NGEErrorCodes.ERROR_TYPE, "AIG Currency Code not available from Currency Conversion Service Response", null);
			}
			logger.info("Currency Rate" + rate);
			
		}
		
		return rate;
	}

	public String getOldestTimeStamp(List<TlegacyWipQuote> legacyWipQuoteList)
	{
		String wipId = NGEConstants.EMPTY_STRING;
		
		if (legacyWipQuoteList != null && legacyWipQuoteList.size()> 0)
	    {
			Timestamp oldestTimestamp = legacyWipQuoteList.get(0).getUpdateTs();

			for (int i = 1; i < legacyWipQuoteList.size(); i++)
			{
	       		if(legacyWipQuoteList.get(i).getWipStatusCd().equalsIgnoreCase(NGEConstants.LegacyWIPStatusCd.QUOTE))
				{
					if (oldestTimestamp.after(legacyWipQuoteList.get(i).getUpdateTs()))
					{
						oldestTimestamp = legacyWipQuoteList.get(i).getUpdateTs();
						wipId = legacyWipQuoteList.get(i).getId().getWipId();
					}
				}
			}

	    }
	    return wipId;
	}

	public void deletePolicyWIPQuote(String transactionComponentId, int policyId) throws AIGCIExceptionMsg {
		List<TlegacyWipQuote> legacyWipQuoteList = getWIPQuote(transactionComponentId, policyId);
		TlegacyWipQuote legacyWipQuoteRslt = null;
		Set<TlegacyWipQuoteCurrency> TlegacyWipQuoteCurrencies = new HashSet<TlegacyWipQuoteCurrency>();
		List<TlegacyWipQuoteCurrency> legacyWipQuoteCurrencyData = null;
		
		List<Tsystem> systemData =  new ArrayList<Tsystem>();			
		systemData = tSystemRepository.findBySystemId(NGESession.getSessionData().getSystem().getSystemId());
		
		if(legacyWipQuoteList != null && !legacyWipQuoteList.isEmpty())
		{
			for(TlegacyWipQuote legacyWipQuote : legacyWipQuoteList)
			{
				/*tLegacyWIPQuoteHsRepository.insertLegacyWIPQuoteHistory(legacyWipQuote.getId().getTransactionComponentId(),
						legacyWipQuote.getId().getWipId(),legacyWipQuote.getId().getQuoteSqn());*/
				//Abul Added Starts
				historyHelper.createTlegacyWipQuoteHHistory(legacyWipQuote);
				//Abul Added Ends
				legacyWipQuote.setWipStatusCd(NGEConstants.LegacyWIPStatusCd.QUOTE);
				legacyWipQuote.setStatusEnteredDt(NGEDateUtil.getTodayDate());
				legacyWipQuote.setQuoteAcceptedIn(NGEConstants.NO);
				legacyWipQuote.setPolicyId(null);
				legacyWipQuote.setPolEventNo(NGEConstants.ZERO_SHORT);
				legacyWipQuote.setAccountingPolNo(NGEConstants.ZERO_SHORT);
				legacyWipQuote.setAcctngPolPrfxCd(null);
				legacyWipQuote.setPolicyMailedDt(null);
				legacyWipQuote.setPolicyXprtnDt(null);
				legacyWipQuote.setUpdateTs(NGEDateUtil.getTodayDate());
				legacyWipQuote.setUpdateUserId(NGESession.getSessionData().getUserId());
				// Setting the System Id
				//legacyWipQuote.setTsystem(systemData.get(0));
				legacyWipQuote.setUwSystemID(NGESession.getSessionData().getSystem().getSystemId());
	
				legacyWipQuoteCurrencyData = getTlegacyWipQuoteCurrencyDetails(legacyWipQuote.getId().getTransactionComponentId(), 
						legacyWipQuote.getId().getWipId(), legacyWipQuote.getId().getQuoteSqn());
				if(null != legacyWipQuoteCurrencyData && !legacyWipQuoteCurrencyData.isEmpty())
				{
					for(TlegacyWipQuoteCurrency legacyWipQuoteCurrency:legacyWipQuoteCurrencyData)
					{
						//tlegacyWipQuoteCurrencyHsRepository.insertLegacyWIPQuoteCurrencyHistory(legacyWipQuoteCurrency.getId().getTransactionComponentId(), legacyWipQuoteCurrency.getId().getWipId(), legacyWipQuoteCurrency.getId().getQuoteSqn());
						if(legacyWipQuoteCurrency != null){
							historyHelper.createTlegacyWipQuoteCurrencyHHistory(legacyWipQuoteCurrency);	
						}						
						
						legacyWipQuoteCurrency.setPolicyAtchmtPointAm(null);
						legacyWipQuoteCurrency.setPolicyLimitAm(null);
						legacyWipQuoteCurrency.setPolicyPartOfAm(null);
						legacyWipQuoteCurrency.setBoundPremiumAm(null);
						legacyWipQuoteCurrency.setUpdateUserId(NGESession.getSessionData().getUserId());
						legacyWipQuoteCurrency.setUpdateTs(NGEDateUtil.getTodayDate());
						TlegacyWipQuoteCurrencies.add(legacyWipQuoteCurrency);
					}
					legacyWipQuote.setTlegacyWipQuoteCurrencies(TlegacyWipQuoteCurrencies);
				}
	
				try
				{
					legacyWipQuoteRslt = saveLegacyWipQuote(legacyWipQuote);
				}
				catch(Exception e)
				{
					/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
					if(commonServiceHelper.checkForRetryExceptions(e, 16, NGEConstants.CatchExceptionTypes.THROW_HANDLED_EXCEPTION))
					{
						logger.error("checkForRetryExceptions returned true");
					}
					/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
					ngeException.throwException(NGEErrorCodes.SERVICE_FAILED,NGEErrorCodes.ERROR_TYPE, null, null);
				}
				if(null == legacyWipQuoteRslt)
				{
					/* PI3 - Q3 2018 Maintenance Release 2.12 - Ensure to Bind all components in a bundle - Starts */
					logger.error("LegacyWipDAO - Debug - 25");
					/* PI3 - Q3 2018 Maintenance Release 2.12 - Ensure to Bind all components in a bundle - Ends */
					ngeException.throwException(NGEErrorCodes.SERVICE_FAILED,NGEErrorCodes.ERROR_TYPE, null, null);
				}
			}
		}
	}

	
	/**
	 * @author Padma
	 * @param transactionComponentId 
	 * @param wipQuoteDetails
	 * @param legacyWipQuoteCurrency
	 * @param currencyCd 
	 * @param premium 
	 * @param productlimit 
	 * @return
	 * @throws AIGCIExceptionMsg 
	 */
	private TlegacyWipQuoteCurrency setLocalAmt(WIPQuoteDetails wipQuoteDetails, TlegacyWipQuoteCurrency legacyWipQuoteCurrency, BigDecimal premium, TtransactionComponentLimit productlimit, boolean canUpdateQuoteAmts) throws AIGCIExceptionMsg {
		
		if(canUpdateQuoteAmts){
			
			if(wipQuoteDetails.getQuotedLimitAmt() != null)
			{
				legacyWipQuoteCurrency.setQuotedLimitAm(wipQuoteDetails.getQuotedLimitAmt());
			}
			if(null != wipQuoteDetails.getQuotedAttachmentPointAmt())
			{
				legacyWipQuoteCurrency.setQuotedAtchmtPointAm(wipQuoteDetails.getQuotedAttachmentPointAmt());
			}
			if(null != wipQuoteDetails.getQuotedPremiumAmt())
			{
				legacyWipQuoteCurrency.setQuotedPremiumAm(wipQuoteDetails.getQuotedPremiumAmt());
			}
		}
		
		PolicyDetails policyDetails = wipQuoteDetails.getPolicyDetails();

		if(policyDetails != null)
		{
			if(policyDetails.getPolicyAttachmentPointAmt() != null)
			{
				legacyWipQuoteCurrency.setPolicyAtchmtPointAm(policyDetails.getPolicyAttachmentPointAmt());
			//	legacyWipQuoteCurrency.setQuotedAtchmtPointAm(wipQuoteDetails.getQuotedAttachmentPointAmt());
			}
			if(policyDetails.getPolicyLimitAmt() != null)
			{
				legacyWipQuoteCurrency.setPolicyLimitAm(policyDetails.getPolicyLimitAmt());
			//	legacyWipQuoteCurrency.setQuotedLimitAm(policyDetails.getPolicyLimitAmt());
			}
			/*else if(null != productlimit)
			{
				legacyWipQuoteCurrency.setQuotedLimitAm(productlimit.getLimitAm());
			}*/
			if(policyDetails.getPolicyPartOfAmt() != null)
			{
				legacyWipQuoteCurrency.setPolicyPartOfAm(policyDetails.getPolicyPartOfAmt());
			}
		}
	/*	else if(null != productlimit)
		{
			legacyWipQuoteCurrency.setQuotedLimitAm(productlimit.getLimitAm());
		}*/
		//legacyWipQuoteCurrency.setQuotedPremiumAm(premium);
		legacyWipQuoteCurrency.setBoundPremiumAm(premium);
		return legacyWipQuoteCurrency;
	}

	/**
	 * @author Padma
	 * @param amount
	 * @param rate
	 * @return
	 */
	public BigDecimal conversion(BigDecimal amount, BigDecimal rate)
	{
		amount = amount.multiply(rate); 
		amount = amount.setScale(6, RoundingMode.HALF_UP);
		return amount;
	}
	/*padma add starts*/
	/*public WIPQuoteDetailsRs setLegacyWipQuote(WIPQuoteDetailsRs wipQuoteDetailsRs, TransactionComponentChildEntriesBO.WIPQuoteDetails legacyWipQuote) throws AIGCIExceptionMsg 
	{

		PolicyDetails priorPolicyDetails = null;

		Tpolicy wipPriorPolicy = null;

		List<TransactionComponentChildEntriesBO.WIPQuoteCurrencyDetails> tlegacyWipQuoteCurrencies = null;
		Tcurrency currency = null;
		wipQuoteDetailsRs.setWIPId(legacyWipQuote.getWipId());
		wipQuoteDetailsRs.setQuoteSqn(legacyWipQuote.getQuoteSqn());

		wipQuoteDetailsRs.setWIPStatusCd(legacyWipQuote.getWipStatusCd());

		wipQuoteDetailsRs.setWIPStatusEnteredDt(NGEDateUtil.convertDateToXMLGregorianCalendar(legacyWipQuote.getWipStatusEnteredDt()));
		if(legacyWipQuote.getSectionCd() != null)
		{
			wipQuoteDetailsRs.setWIPSectionCd(legacyWipQuote.getSectionCd());
		}
		if(legacyWipQuote.getProfitUnitCd() != null)
		{
			wipQuoteDetailsRs.setWIPProfitUnitCd(legacyWipQuote.getProfitUnitCd());
		}
		if(null != legacyWipQuote.getWinningCarrierNm())
		{
			wipQuoteDetailsRs.setWinningCarrierNm(legacyWipQuote.getWinningCarrierNm());
		}
		if(null != legacyWipQuote.getLossrsn())
		{
			wipQuoteDetailsRs.setLossrsnAdLcmtsTx(legacyWipQuote.getLossrsn());
		}
		wipQuoteDetailsRs.setQuoteAcceptedIn(legacyWipQuote.getQuoteAcceptedIn());
		if(null != legacyWipQuote.getQuoteEffectedDt())
		{
			wipQuoteDetailsRs.setQuoteEffectiveDt(NGEDateUtil.convertDateToXMLGregorianCalendar(legacyWipQuote.getQuoteEffectedDt()));
		}
		if(null != legacyWipQuote.getQuoteExpirationDt())
		{
			wipQuoteDetailsRs.setQuoteExpDt(NGEDateUtil.convertDateToXMLGregorianCalendar(legacyWipQuote.getQuoteExpirationDt()));
		}
		if(legacyWipQuote.getPolicyEventNo()!=null && legacyWipQuote.getPolicyEventNo() >= 0)
		{
			wipQuoteDetailsRs.setPolicyEventNo(legacyWipQuote.getPolicyEventNo());
		}
		if(null != legacyWipQuote.getMasterContractNo())
		{
			wipQuoteDetailsRs.setMasterContractNo(legacyWipQuote.getMasterContractNo());
		}
		if(null != legacyWipQuote.getAccountLegalNm())
		{
			wipQuoteDetailsRs.setAccountLegalNm(legacyWipQuote.getAccountLegalNm());
		}
		if(legacyWipQuote.getAccountPolNo() != null)
		{
			wipQuoteDetailsRs.setAccountingPolicyNo(legacyWipQuote.getAccountPolNo());
		}
		if(null!= legacyWipQuote.getAccountPolPrfxCd())
		{
			wipQuoteDetailsRs.setAccountingPolPrefixCd(legacyWipQuote.getAccountPolPrfxCd());
		}
		wipQuoteDetailsRs.setNonRenewalIn(legacyWipQuote.getNonRenewalIn());
		if(null != legacyWipQuote.getNonRenewalReasonCd())
		{
			wipQuoteDetailsRs.setNonRenewalRsnCd(legacyWipQuote.getNonRenewalReasonCd());
		}
		if(null != legacyWipQuote.getPolicyMailedDt())
		{
			wipQuoteDetailsRs.setPolicyMailedDt(NGEDateUtil.convertDateToXMLGregorianCalendar(legacyWipQuote.getPolicyMailedDt()));
		}
		if(null != legacyWipQuote.getReasonCd())
		{
			wipQuoteDetailsRs.setReasonCd(legacyWipQuote.getReasonCd());
		}
		
		wipQuoteDetailsRs.setSystemId(legacyWipQuote.getSystemId());

		tlegacyWipQuoteCurrencies = getTlegacyWipQuoteCurrencyDetails(legacyWipQuote.getId().getTransactionComponentId(), 
				legacyWipQuote.getId().getWipId(), legacyWipQuote.getId().getQuoteSqn());
		tlegacyWipQuoteCurrencies = legacyWipQuote.getWIPQuoteCurrencyDetailsList();

		if(tlegacyWipQuoteCurrencies!= null && !tlegacyWipQuoteCurrencies.isEmpty())
		{
			if(tlegacyWipQuoteCurrencies.size() == 1)
			{
				wipQuoteDetailsRs = setLegacyWipQuoteCUrrency(wipQuoteDetailsRs, tlegacyWipQuoteCurrencies.get(0), legacyWipQuote);
			}
			else if(tlegacyWipQuoteCurrencies.size() == 2)
			{
				currency = commonDAO.getCurrency(NGEConstants.USD);
				for(TransactionComponentChildEntriesBO.WIPQuoteCurrencyDetails legacyWipQuoteCurrency:tlegacyWipQuoteCurrencies)
				{
					if(legacyWipQuoteCurrency.getCurrencyId() != currency.getCurrencyId())
					{
						wipQuoteDetailsRs = setLegacyWipQuoteCUrrency(wipQuoteDetailsRs, legacyWipQuoteCurrency, legacyWipQuote);
					}
				}
			}
		}

		if(legacyWipQuote.getPriorPolicyId() != null)
		{
			wipPriorPolicy = policyDAO.findpolicy(legacyWipQuote.getPriorPolicyId());
			priorPolicyDetails = new PolicyDetails();
			priorPolicyDetails.setPolicyNo(wipPriorPolicy.getPolicyNo());
			priorPolicyDetails.setIssuingCompanyCd(wipPriorPolicy.getCompanyCd());
			priorPolicyDetails.setEffectiveDt(NGEDateUtil.convertDateToXMLGregorianCalendar(wipPriorPolicy.getEffectiveDt()));
			wipQuoteDetailsRs.setPriorPolicyDetails(priorPolicyDetails);
		}
		return wipQuoteDetailsRs;
	}

	private WIPQuoteDetailsRs setLegacyWipQuoteCUrrency(
			WIPQuoteDetailsRs wipQuoteDetailsRs,
			TransactionComponentChildEntriesBO.WIPQuoteCurrencyDetails legacyWipQuoteCurrency, TransactionComponentChildEntriesBO.WIPQuoteDetails legacyWipQuote) throws AIGCIExceptionMsg {

		PolicyDetails policyDetails = new PolicyDetails();
		Tpolicy wipPolicy = null;
		Tcurrency currency = commonDAO.getCurrencyByCurrencyId(legacyWipQuoteCurrency.getCurrencyId());
		if(currency != null)
		{
			wipQuoteDetailsRs.setCurrencyCd(currency.getCurrencyCd());
		}
		wipQuoteDetailsRs.setQuotedPremiumAmt(legacyWipQuoteCurrency.getQuotedPremiumAmt());
		wipQuoteDetailsRs.setQuotedLimitAmt(legacyWipQuoteCurrency.getQuoteLimitAmt());
		if(null != legacyWipQuoteCurrency.getQuoteAttachmentPointAmt())
		{
			wipQuoteDetailsRs.setQuotedAttachmentPointAmt(legacyWipQuoteCurrency.getQuoteAttachmentPointAmt());
		}
		if(legacyWipQuote.getPolicyId() != null)
		{
			wipPolicy = policyDAO.findpolicy(legacyWipQuote.getPolicyId());
			if(wipPolicy != null)
			{
				policyDetails.setPolicyNo(wipPolicy.getPolicyNo());
				policyDetails.setIssuingCompanyCd(wipPolicy.getCompanyCd());
				policyDetails.setEffectiveDt(NGEDateUtil.convertDateToXMLGregorianCalendar(wipPolicy.getEffectiveDt()));
				if(currency != null)
				{
					policyDetails.setCurrencyCd(currency.getCurrencyCd());
				}
			}					
			if(null!= legacyWipQuoteCurrency.getPolicyAttachmentPointAmt())
			{
				policyDetails.setPolicyAttachmentPointAmt(legacyWipQuoteCurrency.getPolicyAttachmentPointAmt());
			}
			if(null != legacyWipQuoteCurrency.getPolicyLimitAmt())
			{
				policyDetails.setPolicyLimitAmt(legacyWipQuoteCurrency.getPolicyLimitAmt());
			}
			if(null != legacyWipQuoteCurrency.getPolicyPartOfAmt())
			{
				policyDetails.setPolicyPartOfAmt(legacyWipQuoteCurrency.getPolicyPartOfAmt());
			}
			wipQuoteDetailsRs.setPolicyDetails(policyDetails);
		}

		return wipQuoteDetailsRs;
	}
*/
	public List<TlegacyWipQuote> fetchComponentWIPQuoteDetails(String transactionComponentId) 
	{
		List<TlegacyWipQuote> tlegacyWipQuotes = null;
		tlegacyWipQuotes = getWIPQuoteDetails(transactionComponentId);
		return tlegacyWipQuotes;
	}
	/* padma add ends */

	public void addPolicyWipQuote(String transactionComponentId, int policyId,
			WIPQuoteDetails wipQuoteDetails, BigDecimal conversionRate, Tpolicy policy) throws AIGCIExceptionMsg {
		TlegacyWipQuote legacyWipQuote = new TlegacyWipQuote();
		TlegacyWipQuote legacyWipQuoteRslt = null;
		Set<TlegacyWipQuoteCurrency> legacyWipQuoteCurrencies = new HashSet<TlegacyWipQuoteCurrency>();
		TlegacyWipQuoteCurrency legacyWipQuoteCurrencyUsd = new TlegacyWipQuoteCurrency();
		TlegacyWipQuoteCurrency legacyWipQuoteCurrencyLocal = new TlegacyWipQuoteCurrency();
		Date effective = null;
		Date expiration = null;
		List<Tsystem> systemData =  new ArrayList<Tsystem>();			
		systemData = tSystemRepository.findBySystemId(NGESession.getSessionData().getSystem().getSystemId());
		
		if(wipQuoteDetails != null)     //request has wip details
		{
			if(null != wipQuoteDetails.getPolicyDetails() && null != wipQuoteDetails.getPolicyDetails().getEffectiveDt())
			{
				effective = NGEDateUtil.getStringDate(wipQuoteDetails.getPolicyDetails().getEffectiveDt());
			}
			else
			{
				effective = NGEDateUtil.getStringDate(NGEDateUtil.convertDateToXMLGregorianCalendar(policy.getEffectiveDt()));
			}
			if(null != wipQuoteDetails.getPolicyDetails() &&  null != wipQuoteDetails.getPolicyDetails().getExpirationDt())
			{
				expiration = NGEDateUtil.getStringDate(wipQuoteDetails.getPolicyDetails().getExpirationDt());
			}
			else
			{
				expiration = NGEDateUtil.getStringDate(NGEDateUtil.convertDateToXMLGregorianCalendar(policy.getExpirationDt()));
			}
			legacyValidations.validateWip(wipQuoteDetails);
			if(null == wipQuoteDetails.getWIPId())
			{
				legacyWipQuote = addPolicyWithoutWip(transactionComponentId, policyId, effective, expiration);
			}
			else
			{
				short quoteSqn = 0;
				quoteSqn = wipQuoteDetails.getQuoteSqn();
				TlegacyWipQuotePK legacyWipQuotePK = new TlegacyWipQuotePK();
				legacyWipQuotePK.setTransactionComponentId(transactionComponentId);
				legacyWipQuotePK.setWipId(wipQuoteDetails.getWIPId().trim());
				legacyWipQuotePK.setQuoteSqn(quoteSqn);
				legacyWipQuote = getLegacyWipQuote(legacyWipQuotePK);
				List<TlegacyWipQuote> legacyWipQuoteList = tLegacyWipQuoteRepository.findByTransactionComponentIdandWipId(transactionComponentId, wipQuoteDetails.getWIPId().trim());
				//if(null != legacyWipQuote)
				int counter = 0;
				if(legacyWipQuoteList!=null && !legacyWipQuoteList.isEmpty())
				{
				/*	tLegacyWIPQuoteHsRepository.insertLegacyWIPQuoteHistory(legacyWipQuote.getId().getTransactionComponentId(),
							legacyWipQuote.getId().getWipId(),legacyWipQuote.getId().getQuoteSqn());
					
					List<TlegacyWipQuoteCurrency> currencyToHs = getTlegacyWipQuoteCurrencyDetails(legacyWipQuote.getId().getTransactionComponentId(),
							legacyWipQuote.getId().getWipId(),legacyWipQuote.getId().getQuoteSqn());
					
					if(currencyToHs != null && !currencyToHs.isEmpty())
					{
						for( TlegacyWipQuoteCurrency legacyWipQuoteCurrencyItr:currencyToHs){
							tlegacyWipQuoteCurrencyHsRepository.insertLegacyWIPQuoteCurrencyHistory(legacyWipQuoteCurrencyItr.getId().getTransactionComponentId(),
								legacyWipQuoteCurrencyItr.getId().getWipId(),legacyWipQuoteCurrencyItr.getId().getQuoteSqn());
						}
					}*/
						for(TlegacyWipQuote legacyWipQuote1 : legacyWipQuoteList)
						{
							if(legacyWipQuote1.getId().getQuoteSqn() == quoteSqn)
							{
								//Abul Added Starts
								historyHelper.createTlegacyWipQuoteHHistory(legacyWipQuote1);
								//Abul Added Ends
								counter++;
								legacyWipQuote1 = updateWIPDetais(legacyWipQuote1, wipQuoteDetails, true);
								legacyWipQuote1.setWipStatusCd(NGEConstants.LegacyWIPStatusCd.BOUND);
								legacyWipQuote1.setStatusEnteredDt(NGEDateUtil.getTodayDate());
								//legacyWipQuote1.setTsystem(systemData.get(0));
								legacyWipQuote1.setUwSystemID(NGESession.getSessionData().getSystem().getSystemId());
								legacyWipQuote1.setQuoteAcceptedIn(NGEConstants.YES);
								legacyWipQuote1.setPolicyId(policyId);
								legacyWipQuote1.setQuoteEfctvDt(effective);
								legacyWipQuote1.setQuoteXprtnDt(expiration);
								legacyWipQuote1.setPolicyXprtnDt(expiration);
								legacyWipQuote1.setReasonCd(null);
								if(null != wipQuoteDetails.getNonRenewalIn())
								{
									legacyWipQuote1.setNonRenewalIn(wipQuoteDetails.getNonRenewalIn());
								}
								else if(getNonRenewalInd(legacyWipQuote1.getId().getTransactionComponentId()))
								{
									legacyWipQuote1.setNonRenewalIn(NGEConstants.YES);
								}
								else
								{
									legacyWipQuote1.setNonRenewalIn(NGEConstants.NO);
								}
								
								if(null != wipQuoteDetails.getNonRenewalRsnCd()){
									
									legacyWipQuote1.setNonRenewalReasonCd(wipQuoteDetails.getNonRenewalRsnCd());
								}
								
								if(null != wipQuoteDetails.getPolicyEventNo())
								{
									legacyWipQuote1.setPolEventNo(wipQuoteDetails.getPolicyEventNo());
								}
								else
								{
									legacyWipQuote1.setPolEventNo(NGEConstants.ONE_SHORT);
								}
								if(null != wipQuoteDetails.getBusinessTypeCode())
								{
									legacyWipQuote1.setBusinessTypeCd(wipQuoteDetails.getBusinessTypeCode());
								}
								else
								{
									try{
										//TtransactionComponent transCompData = ttransactionComponentRepository.findByTransactionComponentId(transactionComponentId);
                                        TtransactionComponent transCompData = transactionComponentDAO.findByTransactionComponentIdForWIPS(transactionComponentId);

										String businessType =  transCompData.getTproductState().getProductStateNm();
										logger.debug("businessType" +businessType);
										if(businessType.equalsIgnoreCase(NGEConstants.ProductState.NEW)){
											
											legacyWipQuote1.setBusinessTypeCd(NGEConstants.BusinessTypeCd.NEW);
										}
										else{
											legacyWipQuote1.setBusinessTypeCd(NGEConstants.BusinessTypeCd.RENEWAL);
										}
									}catch(Exception e){
										/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
										if(commonServiceHelper.checkForRetryExceptions(e, 17, NGEConstants.CatchExceptionTypes.THROW_EXCEPTION))
										{
											logger.error("checkForRetryExceptions returned true");
										}
										/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
										logger.error("Exception : " +e.getMessage());
										/* PI3 - Q3 2018 Maintenance Release 2.12 - Ensure to Bind all components in a bundle - Starts */
										throw e;
										/* PI3 - Q3 2018 Maintenance Release 2.12 - Ensure to Bind all components in a bundle - Ends */
									}
								}
								legacyWipQuote1.setUpdateUserId(NGESession.getSessionData().getUserId());
								legacyWipQuote1.setUpdateTs(NGEDateUtil.getTodayDate());
								
								// PROD Issue - Prior Policy Id copied to all quote SQN's
								if(null != wipQuoteDetails.getPriorPolicyDetails())
				                {
				                      PolicyDetails priorPolicy = wipQuoteDetails.getPriorPolicyDetails();
				                      Date effectiveDate = NGEDateUtil.getStringDate(priorPolicy.getEffectiveDt());
				                      short issuingCompanyCd = 0;
				                      try
				                      {
				                            issuingCompanyCd = (short) priorPolicy.getIssuingCompanyCd(); 
				                      }
				                      catch(ClassCastException e)
				                      {
				                            ngeException.throwException(NGEErrorCodes.INVALID_POLICY_ISS_COMP_CD,NGEErrorCodes.ERROR_TYPE, null, null);
				                      }
				                      if(null != priorPolicy.getPolicyNo() && null != priorPolicy.getEffectiveDt())
				                      {
				                    	  	Tpolicy priorPolicyInfo = null;
				                            priorPolicyInfo = policyDAO.getPolicy(priorPolicy.getPolicyNo(), issuingCompanyCd, effectiveDate);
				                            if(null != priorPolicyInfo)
				                            {
				                            	legacyWipQuote1.setPriorPolicyId(priorPolicyInfo.getPolicyId());
				                            }
				                            else{
				                            	
				                            	// Create a new Prior Policy - Requested for Coexistence
				                            	priorPolicyInfo = insertPriorPolicyInTPolicy(priorPolicy);
				                            	if(priorPolicyInfo != null){
				                            		
				                            		logger.debug("priorPolicyInfo.getPolicyId() newly created"+priorPolicyInfo.getPolicyId());
				                            		legacyWipQuote1.setPriorPolicyId(priorPolicyInfo.getPolicyId());
				                            	}
				                            }
				                      }
				                }
							}
							else
							{
								// PROD Issue Fix - Accounting Policy Number not returned issue
								//Abul Added Starts
								historyHelper.createTlegacyWipQuoteHHistory(legacyWipQuote1);
								//Abul Added Ends
								//counter++;
								legacyWipQuote1 = updateWIPDetais(legacyWipQuote1, wipQuoteDetails, false);
								legacyWipQuote1.setWipStatusCd(NGEConstants.LegacyWIPStatusCd.BOUND);
								legacyWipQuote1.setStatusEnteredDt(NGEDateUtil.getTodayDate());
								//legacyWipQuote1.setTsystem(systemData.get(0));
								legacyWipQuote1.setUwSystemID(NGESession.getSessionData().getSystem().getSystemId());
								legacyWipQuote1.setQuoteAcceptedIn(NGEConstants.NO);
								legacyWipQuote1.setPolicyId(policyId);
								
								// Commented Out to support existing legacy behavior - PROD Issue - PPS Systems - Quote details should be updated only for that particular SQN
								/*legacyWipQuote1.setQuoteEfctvDt(effective);
								legacyWipQuote1.setQuoteXprtnDt(expiration);*/
								
								legacyWipQuote1.setPolicyXprtnDt(expiration);
								legacyWipQuote1.setReasonCd(null);
								if(null != wipQuoteDetails.getNonRenewalIn())
								{
									legacyWipQuote1.setNonRenewalIn(wipQuoteDetails.getNonRenewalIn());
								}
								else if(getNonRenewalInd(legacyWipQuote1.getId().getTransactionComponentId()))
								{
									legacyWipQuote1.setNonRenewalIn(NGEConstants.YES);
								}
								else
								{
									legacyWipQuote1.setNonRenewalIn(NGEConstants.NO);
								}
								
								if(null != wipQuoteDetails.getNonRenewalRsnCd()){
									
									legacyWipQuote1.setNonRenewalReasonCd(wipQuoteDetails.getNonRenewalRsnCd());
								}
								
								if(null != wipQuoteDetails.getPolicyEventNo())
								{
									legacyWipQuote1.setPolEventNo(wipQuoteDetails.getPolicyEventNo());
								}
								else
								{
									legacyWipQuote1.setPolEventNo(NGEConstants.ONE_SHORT);
								}
								if(null != wipQuoteDetails.getBusinessTypeCode())
								{
									legacyWipQuote1.setBusinessTypeCd(wipQuoteDetails.getBusinessTypeCode());
								}
								else
								{
									try{
										//TtransactionComponent transCompData = ttransactionComponentRepository.findByTransactionComponentId(transactionComponentId);
                                        TtransactionComponent transCompData = transactionComponentDAO.findByTransactionComponentIdForWIPS(transactionComponentId);

										String businessType =  transCompData.getTproductState().getProductStateNm();
										logger.debug("businessType" +businessType);
										if(businessType.equalsIgnoreCase(NGEConstants.ProductState.NEW)){
											
											legacyWipQuote1.setBusinessTypeCd(NGEConstants.BusinessTypeCd.NEW);
										}
										else{
											legacyWipQuote1.setBusinessTypeCd(NGEConstants.BusinessTypeCd.RENEWAL);
										}
									}catch(Exception e){
										/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
										if(commonServiceHelper.checkForRetryExceptions(e, 18, NGEConstants.CatchExceptionTypes.THROW_EXCEPTION))
										{
											logger.error("checkForRetryExceptions returned true");
										}
										/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
										/* 2019 PI5 - Release 2.18.0 - Ensure NGE IS Retry Logic - Starts */
										logger.error("Exception message - Retry Logic : " +e.getMessage());
										throw e;
										/* 2019 PI5 - Release 2.18.0 - Ensure NGE IS Retry Logic - Ends */
									}
								}
								legacyWipQuote1.setUpdateUserId(NGESession.getSessionData().getUserId());
								legacyWipQuote1.setUpdateTs(NGEDateUtil.getTodayDate());
								
								// PROD Issue - Prior Policy Id copied to all quote SQN's
								if(null != wipQuoteDetails.getPriorPolicyDetails())
				                {
				                      PolicyDetails priorPolicy = wipQuoteDetails.getPriorPolicyDetails();
				                      Date effectiveDate = NGEDateUtil.getStringDate(priorPolicy.getEffectiveDt());
				                      short issuingCompanyCd = 0;
				                      try
				                      {
				                            issuingCompanyCd = (short) priorPolicy.getIssuingCompanyCd(); 
				                      }
				                      catch(ClassCastException e)
				                      {
				                            ngeException.throwException(NGEErrorCodes.INVALID_POLICY_ISS_COMP_CD,NGEErrorCodes.ERROR_TYPE, null, null);
				                      }
				                      if(null != priorPolicy.getPolicyNo() && null != priorPolicy.getEffectiveDt())
				                      {
				                    	  	Tpolicy priorPolicyInfo = null;
				                            priorPolicyInfo = policyDAO.getPolicy(priorPolicy.getPolicyNo(), issuingCompanyCd, effectiveDate);
				                            if(null != priorPolicyInfo)
				                            {
				                            	legacyWipQuote1.setPriorPolicyId(priorPolicyInfo.getPolicyId());
				                            }
				                            else{
				                            	
				                            	// Create a new Prior Policy - Requested for Coexistence
				                            	priorPolicyInfo = insertPriorPolicyInTPolicy(priorPolicy);
				                            	if(priorPolicyInfo != null){
				                            		
				                            		logger.debug("priorPolicyInfo.getPolicyId() newly created"+priorPolicyInfo.getPolicyId());
				                            		legacyWipQuote1.setPriorPolicyId(priorPolicyInfo.getPolicyId());
				                            	}
				                            }
				                      }
				                }							
							}
					}
						
						if(counter == 0)
						{
							List<TlegacyWipQuote> legacyWipQuotes = getWIPQuoteDetails(transactionComponentId);
							legacyWipQuote = createNewLegacyWipQuote(transactionComponentId, policyId, wipQuoteDetails.getWIPId().trim(), wipQuoteDetails.getQuoteSqn(), legacyWipQuotes, effective, expiration, wipQuoteDetails.getNonRenewalIn());
							legacyWipQuote = updateWIPDetais(legacyWipQuote, wipQuoteDetails, true);
						}

				}
				else
				{
					List<TlegacyWipQuote> legacyWipQuotes = getWIPQuoteDetails(transactionComponentId);
					legacyWipQuote = createNewLegacyWipQuote(transactionComponentId, policyId, wipQuoteDetails.getWIPId().trim(), wipQuoteDetails.getQuoteSqn(), legacyWipQuotes, effective, expiration, wipQuoteDetails.getNonRenewalIn());
					legacyWipQuote = updateWIPDetais(legacyWipQuote, wipQuoteDetails, true);
				}
				
				if(null != wipQuoteDetails.getPriorPolicyDetails())
                {
                      PolicyDetails priorPolicy = wipQuoteDetails.getPriorPolicyDetails();
                      Date effectiveDate = NGEDateUtil.getStringDate(priorPolicy.getEffectiveDt());
                      short issuingCompanyCd = 0;
                      try
                      {
                            issuingCompanyCd = (short) priorPolicy.getIssuingCompanyCd(); 
                      }
                      catch(ClassCastException e)
                      {
                            ngeException.throwException(NGEErrorCodes.INVALID_POLICY_ISS_COMP_CD,NGEErrorCodes.ERROR_TYPE, null, null);
                      }
                      if(null != priorPolicy.getPolicyNo() && null != priorPolicy.getEffectiveDt())
                      {
                    	  	Tpolicy priorPolicyInfo = null;
                            priorPolicyInfo = policyDAO.getPolicy(priorPolicy.getPolicyNo(), issuingCompanyCd, effectiveDate);
                            if(null != priorPolicyInfo)
                            {
                            	legacyWipQuote.setPriorPolicyId(priorPolicyInfo.getPolicyId());
                            }
                            else{
                            	
                            	// Create a new Prior Policy - Requested for Coexistence
                            	priorPolicyInfo = insertPriorPolicyInTPolicy(priorPolicy);
                            	if(priorPolicyInfo != null){
                            		
                            		logger.debug("priorPolicyInfo.getPolicyId() newly created"+priorPolicyInfo.getPolicyId());
                            		legacyWipQuote.setPriorPolicyId(priorPolicyInfo.getPolicyId());
                            	}
                            }
                      }
                }

			}
			if(NGEConstants.USD.equalsIgnoreCase(policy.getTcurrency().getCurrencyCd()))
			{
				List<TlegacyWipQuote> tlegacyWipQuotesList = null;
				tlegacyWipQuotesList = getWIPQuoteDetails(transactionComponentId, legacyWipQuote.getId().getWipId());
				if(tlegacyWipQuotesList != null && !tlegacyWipQuotesList.isEmpty()){
					
					boolean newQuoteSQNExistInDB = false;
					for(TlegacyWipQuote legacyWIPQuote : tlegacyWipQuotesList){
						
						if(legacyWIPQuote.getId().getQuoteSqn() == legacyWipQuote.getId().getQuoteSqn()){
							
							legacyWipQuoteCurrencyUsd = addLegacyWipQuoteCurrency(transactionComponentId, wipQuoteDetails, null, legacyWipQuote.getId().getWipId(), legacyWIPQuote.getId().getQuoteSqn(), policy.getTcurrency().getCurrencyCd(), policy.getPremiumAm(), true);
							legacyWipQuoteCurrencies.add(legacyWipQuoteCurrencyUsd);
							
							newQuoteSQNExistInDB = true;
						}
						else{
							
							legacyWipQuoteCurrencyUsd = addLegacyWipQuoteCurrency(transactionComponentId, wipQuoteDetails, null, legacyWipQuote.getId().getWipId(), legacyWIPQuote.getId().getQuoteSqn(), policy.getTcurrency().getCurrencyCd(), policy.getPremiumAm(), false);
							legacyWipQuoteCurrencies.add(legacyWipQuoteCurrencyUsd);
						}
					}
					
					if(!newQuoteSQNExistInDB){
						
						legacyWipQuoteCurrencyUsd = addLegacyWipQuoteCurrency(transactionComponentId, wipQuoteDetails, null, legacyWipQuote.getId().getWipId(), legacyWipQuote.getId().getQuoteSqn(), policy.getTcurrency().getCurrencyCd(), policy.getPremiumAm(), true);
						legacyWipQuoteCurrencies.add(legacyWipQuoteCurrencyUsd);
					}
				}
				else{
					
					legacyWipQuoteCurrencyUsd = addLegacyWipQuoteCurrency(transactionComponentId, wipQuoteDetails, null, legacyWipQuote.getId().getWipId(), legacyWipQuote.getId().getQuoteSqn(), policy.getTcurrency().getCurrencyCd(), policy.getPremiumAm(), true);
					legacyWipQuoteCurrencies.add(legacyWipQuoteCurrencyUsd);
				}
				
				legacyWipQuote.setTlegacyWipQuoteCurrencies(legacyWipQuoteCurrencies);
			}
			else
			{
				List<TlegacyWipQuote> tlegacyWipQuotesList = null;
				tlegacyWipQuotesList = getWIPQuoteDetails(transactionComponentId, legacyWipQuote.getId().getWipId());
				if(tlegacyWipQuotesList != null && !tlegacyWipQuotesList.isEmpty()){
					
					boolean newQuoteSQNExistInDB = false;
					for(TlegacyWipQuote legacyWIPQuote : tlegacyWipQuotesList){
						
						if(legacyWIPQuote.getId().getQuoteSqn() == legacyWipQuote.getId().getQuoteSqn()){
						
							legacyWipQuoteCurrencyLocal = addLegacyWipQuoteCurrency(transactionComponentId, wipQuoteDetails, null, legacyWipQuote.getId().getWipId(), legacyWIPQuote.getId().getQuoteSqn(), policy.getTcurrency().getCurrencyCd(), policy.getLocalCurrencyPremiumAm(), true);
							legacyWipQuoteCurrencies.add(legacyWipQuoteCurrencyLocal);
							legacyWipQuoteCurrencyUsd = addLegacyWipQuoteCurrency(transactionComponentId, wipQuoteDetails, conversionRate, legacyWipQuote.getId().getWipId(), legacyWIPQuote.getId().getQuoteSqn(), NGEConstants.USD, policy.getPremiumAm(), true);
							legacyWipQuoteCurrencies.add(legacyWipQuoteCurrencyUsd);
							
							newQuoteSQNExistInDB = true;
						}
						else{
							
							legacyWipQuoteCurrencyLocal = addLegacyWipQuoteCurrency(transactionComponentId, wipQuoteDetails, null, legacyWipQuote.getId().getWipId(), legacyWIPQuote.getId().getQuoteSqn(), policy.getTcurrency().getCurrencyCd(), policy.getLocalCurrencyPremiumAm(), false);
							legacyWipQuoteCurrencies.add(legacyWipQuoteCurrencyLocal);
							legacyWipQuoteCurrencyUsd = addLegacyWipQuoteCurrency(transactionComponentId, wipQuoteDetails, conversionRate, legacyWipQuote.getId().getWipId(), legacyWIPQuote.getId().getQuoteSqn(), NGEConstants.USD, policy.getPremiumAm(), false);
							legacyWipQuoteCurrencies.add(legacyWipQuoteCurrencyUsd);
						}
					}
					
					if(!newQuoteSQNExistInDB){
						
						legacyWipQuoteCurrencyLocal = addLegacyWipQuoteCurrency(transactionComponentId, wipQuoteDetails, null, legacyWipQuote.getId().getWipId(), legacyWipQuote.getId().getQuoteSqn(), policy.getTcurrency().getCurrencyCd(), policy.getLocalCurrencyPremiumAm(), true);
						legacyWipQuoteCurrencies.add(legacyWipQuoteCurrencyLocal);
						legacyWipQuoteCurrencyUsd = addLegacyWipQuoteCurrency(transactionComponentId, wipQuoteDetails, conversionRate, legacyWipQuote.getId().getWipId(), legacyWipQuote.getId().getQuoteSqn(), NGEConstants.USD, policy.getPremiumAm(), true);
						legacyWipQuoteCurrencies.add(legacyWipQuoteCurrencyUsd);
					}
				}
				else{
					
					legacyWipQuoteCurrencyLocal = addLegacyWipQuoteCurrency(transactionComponentId, wipQuoteDetails, null, legacyWipQuote.getId().getWipId(), legacyWipQuote.getId().getQuoteSqn(), policy.getTcurrency().getCurrencyCd(), policy.getLocalCurrencyPremiumAm(), true);
					legacyWipQuoteCurrencies.add(legacyWipQuoteCurrencyLocal);
					legacyWipQuoteCurrencyUsd = addLegacyWipQuoteCurrency(transactionComponentId, wipQuoteDetails, conversionRate, legacyWipQuote.getId().getWipId(), legacyWipQuote.getId().getQuoteSqn(), NGEConstants.USD, policy.getPremiumAm(), true);
					legacyWipQuoteCurrencies.add(legacyWipQuoteCurrencyUsd);
				}
				
				legacyWipQuote.setTlegacyWipQuoteCurrencies(legacyWipQuoteCurrencies);
			}
		}
		//request does not have wip details block
		else
		{
			legacyWipQuote = addPolicyWithoutWip(transactionComponentId, policyId , policy.getEffectiveDt(), policy.getExpirationDt());
			List<TtransactionComponentLimit> transactionComponentLimits = new ArrayList<TtransactionComponentLimit>();
			transactionComponentLimits = transactionComponentLimitRepository.getComponentLimit(transactionComponentId);
			if(transactionComponentLimits.isEmpty())
			{
				/* PI3 - Q3 2018 Maintenance Release 2.12 - Ensure to Bind all components in a bundle - Starts */
				logger.error("LegacyWipDAO - Debug - 28");
				/* PI3 - Q3 2018 Maintenance Release 2.12 - Ensure to Bind all components in a bundle - Ends */
				ngeException.throwException(NGEErrorCodes.SERVICE_FAILED,NGEErrorCodes.ERROR_TYPE, null, null);
			}
			else
			{
				if(NGEConstants.USD.equalsIgnoreCase(policy.getTcurrency().getCurrencyCd()))
				{
					for(TtransactionComponentLimit transactionComponentLimit:transactionComponentLimits)
					{
						if(NGEConstants.USD.equalsIgnoreCase(transactionComponentLimit.getTcurrency().getCurrencyCd()))
						{
							legacyWipQuoteCurrencyUsd = addLegacyWipQuoteCurrencyWithoutWipBlock(policy, legacyWipQuote);
							legacyWipQuoteCurrencyUsd.setPolicyAtchmtPointAm(transactionComponentLimit.getAttachmentPointAm());
							legacyWipQuoteCurrencyUsd.setQuotedAtchmtPointAm(transactionComponentLimit.getAttachmentPointAm());
							legacyWipQuoteCurrencyUsd.setQuotedPremiumAm(policy.getPremiumAm());
							legacyWipQuoteCurrencyUsd.setBoundPremiumAm(policy.getPremiumAm());
							legacyWipQuoteCurrencyUsd.setQuotedLimitAm(transactionComponentLimit.getLimitAm());
							legacyWipQuoteCurrencyUsd.setPolicyLimitAm(transactionComponentLimit.getLimitAm());
							legacyWipQuoteCurrencies.add(legacyWipQuoteCurrencyUsd);
						}
					}
				}
				else
				{
					legacyWipQuoteCurrencyUsd = addLegacyWipQuoteCurrencyWithoutWipBlock(policy, legacyWipQuote);
					legacyWipQuoteCurrencyLocal = addLegacyWipQuoteCurrencyWithoutWipBlock(policy, legacyWipQuote);
					
					Tcurrency currency = commonDAO.getCurrency(NGEConstants.USD);
					if(currency != null)
					{
						legacyWipQuoteCurrencyUsd.getId().setCurrencyId(currency.getCurrencyId());
					}
					else
					{
						/* PI3 - Q3 2018 Maintenance Release 2.12 - Ensure to Bind all components in a bundle - Starts */
						logger.error("LegacyWipDAO - Debug - 29");
						/* PI3 - Q3 2018 Maintenance Release 2.12 - Ensure to Bind all components in a bundle - Ends */
						ngeException.throwException(NGEErrorCodes.SERVICE_FAILED,NGEErrorCodes.ERROR_TYPE, null, null);
					}
					
					BigDecimal attachmentPointAmt = new BigDecimal(0);
					BigDecimal limitAmt = new BigDecimal(0);
					if(transactionComponentLimits.size() == 1){
						
						for(TtransactionComponentLimit transactionComponentLimit:transactionComponentLimits)
						{
							if(NGEConstants.USD.equalsIgnoreCase(transactionComponentLimit.getTcurrency().getCurrencyCd()))
							{
								attachmentPointAmt = transactionComponentLimit.getAttachmentPointAm();								
								limitAmt = transactionComponentLimit.getLimitAm();								
								legacyWipQuoteCurrencyUsd.setPolicyAtchmtPointAm(transactionComponentLimit.getAttachmentPointAm());
								legacyWipQuoteCurrencyUsd.setQuotedAtchmtPointAm(transactionComponentLimit.getAttachmentPointAm());
								legacyWipQuoteCurrencyUsd.setQuotedLimitAm(transactionComponentLimit.getLimitAm());
								legacyWipQuoteCurrencyUsd.setPolicyLimitAm(transactionComponentLimit.getLimitAm());
								legacyWipQuoteCurrencyUsd.setQuotedPremiumAm(policy.getPremiumAm());
								legacyWipQuoteCurrencyUsd.setBoundPremiumAm(policy.getPremiumAm());
								legacyWipQuoteCurrencies.add(legacyWipQuoteCurrencyUsd);
							}
						}
					}
					else if(transactionComponentLimits.size() == 2){
						
						for(TtransactionComponentLimit transactionComponentLimit:transactionComponentLimits)
						{
							if(NGEConstants.USD.equalsIgnoreCase(transactionComponentLimit.getTcurrency().getCurrencyCd()))
							{
								legacyWipQuoteCurrencyUsd.setPolicyAtchmtPointAm(transactionComponentLimit.getAttachmentPointAm());
								legacyWipQuoteCurrencyUsd.setQuotedAtchmtPointAm(transactionComponentLimit.getAttachmentPointAm());
								legacyWipQuoteCurrencyUsd.setQuotedLimitAm(transactionComponentLimit.getLimitAm());
								legacyWipQuoteCurrencyUsd.setPolicyLimitAm(transactionComponentLimit.getLimitAm());
								legacyWipQuoteCurrencyUsd.setQuotedPremiumAm(policy.getPremiumAm());
								legacyWipQuoteCurrencyUsd.setBoundPremiumAm(policy.getPremiumAm());
								legacyWipQuoteCurrencies.add(legacyWipQuoteCurrencyUsd);
							}
							else{
								
								attachmentPointAmt = transactionComponentLimit.getAttachmentPointAm();								
								limitAmt = transactionComponentLimit.getLimitAm();	
							}
						}
					}
					
					legacyWipQuoteCurrencyLocal.setPolicyAtchmtPointAm(attachmentPointAmt);
					legacyWipQuoteCurrencyLocal.setPolicyLimitAm(limitAmt);
					legacyWipQuoteCurrencyLocal.setQuotedAtchmtPointAm(attachmentPointAmt);
					legacyWipQuoteCurrencyLocal.setQuotedLimitAm(limitAmt);
					legacyWipQuoteCurrencyLocal.setQuotedPremiumAm(policy.getLocalCurrencyPremiumAm());
					legacyWipQuoteCurrencyLocal.setBoundPremiumAm(policy.getLocalCurrencyPremiumAm());
					legacyWipQuoteCurrencies.add(legacyWipQuoteCurrencyLocal);
				}

			}
			legacyWipQuote.setTlegacyWipQuoteCurrencies(legacyWipQuoteCurrencies);
		}
		try
		{
			legacyWipQuoteRslt = saveLegacyWipQuote(legacyWipQuote);
		}
		catch(Exception e)
		{
			/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
			if(commonServiceHelper.checkForRetryExceptions(e, 19, NGEConstants.CatchExceptionTypes.THROW_EXCEPTION))
			{
				logger.error("checkForRetryExceptions returned true");
			}
			/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
			/* 2019 PI5 - Release 2.18.0 - Ensure NGE IS Retry Logic - Starts */
			logger.error("Exception message - Retry Logic : " +e.getMessage());			
			throw e;
			//ngeException.throwException(NGEErrorCodes.SERVICE_FAILED,NGEErrorCodes.ERROR_TYPE, null, null);
			/* 2019 PI5 - Release 2.18.0 - Ensure NGE IS Retry Logic - Ends */
		}
		if(legacyWipQuoteRslt == null)
		{
			/* PI3 - Q3 2018 Maintenance Release 2.12 - Ensure to Bind all components in a bundle - Starts */
			logger.error("LegacyWipDAO - Debug - 31");
			/* PI3 - Q3 2018 Maintenance Release 2.12 - Ensure to Bind all components in a bundle - Ends */
			ngeException.throwException(NGEErrorCodes.SERVICE_FAILED,NGEErrorCodes.ERROR_TYPE, null, null);
		}
	}

	private TlegacyWipQuote updateWIPDetais(TlegacyWipQuote legacyWipQuote,
			WIPQuoteDetails wipQuoteDetails, boolean canUpdateQuoteDates) throws AIGCIExceptionMsg {


		if(null != wipQuoteDetails.getWIPSectionCd())
		{
			legacyWipQuote.setSectionCd(wipQuoteDetails.getWIPSectionCd());
		}
		if(null != wipQuoteDetails.getWIPProfitUnitCd())
		{
			legacyWipQuote.setProfitUnitCd(wipQuoteDetails.getWIPProfitUnitCd());
		}
		if(null != wipQuoteDetails.getReasonCd())  //test for empty string
		{
			legacyWipQuote.setReasonCd(wipQuoteDetails.getReasonCd());
		}
		if(null != wipQuoteDetails.getWinningCarrierNm())
		{
			legacyWipQuote.setWinningCarrierNm(wipQuoteDetails.getWinningCarrierNm());
		}
		if(null != wipQuoteDetails.getLossrsnAdLcmtsTx())
		{
			legacyWipQuote.setLossrsnAdlcmtsTx(wipQuoteDetails.getLossrsnAdLcmtsTx());
		}

		if(canUpdateQuoteDates){
			
			if(null != wipQuoteDetails.getQuoteEffectiveDt())
			{
				legacyWipQuote.setQuoteEfctvDt(NGEDateUtil.getStringDate(wipQuoteDetails.getQuoteEffectiveDt()));
			}
			if(null != wipQuoteDetails.getQuoteExpDt())
			{
				legacyWipQuote.setQuoteXprtnDt(NGEDateUtil.getStringDate(wipQuoteDetails.getQuoteExpDt()));
			}
		}
		

		if(null != wipQuoteDetails.getPolicyEventNo())
		{
			legacyWipQuote.setPolEventNo(wipQuoteDetails.getPolicyEventNo());
		}
		if(wipQuoteDetails.getMasterContractNo()!=null){
			legacyWipQuote.setMasterContractNo(wipQuoteDetails.getMasterContractNo());
		}
		if(null != wipQuoteDetails.getAccountLegalNm())
		{
			legacyWipQuote.setAccountLegalNm(wipQuoteDetails.getAccountLegalNm());
		}
		if(null != wipQuoteDetails.getAccountingPolicyNo())
		{
			legacyWipQuote.setAccountingPolNo(wipQuoteDetails.getAccountingPolicyNo());
		}
		if(null != wipQuoteDetails.getAccountingPolPrefixCd())
		{
			legacyWipQuote.setAcctngPolPrfxCd(wipQuoteDetails.getAccountingPolPrefixCd());
		}
		if(null != wipQuoteDetails.getNonRenewalIn() && wipQuoteDetails.getNonRenewalIn().trim().length() != 0)
		{
			legacyWipQuote.setNonRenewalIn(wipQuoteDetails.getNonRenewalIn());
			if(wipQuoteDetails.getNonRenewalIn().trim().equalsIgnoreCase(NGEConstants.YES))
			{
				if(null != wipQuoteDetails.getNonRenewalRsnCd())
				{
					legacyWipQuote.setNonRenewalReasonCd(wipQuoteDetails.getNonRenewalRsnCd());
				}
			}
			else
			{
				legacyWipQuote.setNonRenewalReasonCd(null);
			}
		}
		if(null != wipQuoteDetails.getBusinessTypeCode()){
			
			legacyWipQuote.setBusinessTypeCd(wipQuoteDetails.getBusinessTypeCode());
		}
		if(null != wipQuoteDetails.getPolicyMailedDt())
		{
			legacyWipQuote.setPolicyMailedDt(NGEDateUtil.getStringDate(wipQuoteDetails.getPolicyMailedDt()));
		}
		return legacyWipQuote;
	}

	private TlegacyWipQuoteCurrency addLegacyWipQuoteCurrencyWithoutWipBlock(
			Tpolicy policy, TlegacyWipQuote legacyWipQuote) 
	{
		TlegacyWipQuoteCurrency legacyWipQuoteCurrency = new TlegacyWipQuoteCurrency();
		TlegacyWipQuoteCurrencyPK legacyWipQuoteCurrencyPK  = new TlegacyWipQuoteCurrencyPK();
		legacyWipQuoteCurrencyPK.setTransactionComponentId(legacyWipQuote.getId().getTransactionComponentId());
		legacyWipQuoteCurrencyPK.setWipId(legacyWipQuote.getId().getWipId());
		legacyWipQuoteCurrencyPK.setQuoteSqn(legacyWipQuote.getId().getQuoteSqn());
		legacyWipQuoteCurrencyPK.setCurrencyId(policy.getTcurrency().getCurrencyId());

		legacyWipQuoteCurrency.setId(legacyWipQuoteCurrencyPK);
		legacyWipQuoteCurrency.setQuotedPremiumAm(policy.getLocalCurrencyPremiumAm());
		legacyWipQuoteCurrency.setBoundPremiumAm(policy.getLocalCurrencyPremiumAm());
		legacyWipQuoteCurrency.setPolicyPartOfAm(BigDecimal.ZERO);
		legacyWipQuoteCurrency.setCreateUserId(NGESession.getSessionData().getUserId());
		legacyWipQuoteCurrency.setCreateTs(NGEDateUtil.getTodayDate());
		
		legacyWipQuoteCurrency.setUpdateTs(NGEDateUtil.getTodayDate());
		legacyWipQuoteCurrency.setUpdateUserId(NGESession.getSessionData().getUserId());

		return legacyWipQuoteCurrency;
	}

	private TlegacyWipQuote addPolicyWithoutWip(String transactionComponentId, int policyId, Date effective, Date expiration) throws AIGCIExceptionMsg
	{
		List<TlegacyWipQuote> legacyWipQuotes = getWIPQuoteDetails(transactionComponentId);
		List<TlegacyWipQuote> legacyWipQuotesInQuoteStatus = new ArrayList<TlegacyWipQuote>();
		TlegacyWipQuote legacyWipQuoteData = null;
		List<Tsystem> systemData =  new ArrayList<Tsystem>();			
		systemData = tSystemRepository.findBySystemId(NGESession.getSessionData().getSystem().getSystemId());
		//TtransactionComponent transCompData = ttransactionComponentRepository.findByTransactionComponentId(transactionComponentId);
        TtransactionComponent transCompData = transactionComponentDAO.findByTransactionComponentIdForWIPS(transactionComponentId);
		
		if(null != legacyWipQuotes && !legacyWipQuotes.isEmpty())
		{
			for(TlegacyWipQuote legacyWipQuote:legacyWipQuotes)
			{	
				//Abul Added Starts
				historyHelper.createTlegacyWipQuoteHHistory(legacyWipQuote);
				//Abul Added Ends
				if( legacyWipQuote.getPolicyId() !=null && legacyWipQuote.getPolicyId() == policyId && NGEConstants.LegacyWIPStatusCd.CANCELLED.equalsIgnoreCase(legacyWipQuote.getWipStatusCd()))
				{
					legacyWipQuote.setWipStatusCd(NGEConstants.LegacyWIPStatusCd.BOUND);
					legacyWipQuote.setStatusEnteredDt(NGEDateUtil.getTodayDate());
					//legacyWipQuote.setTsystem(systemData.get(0));
					legacyWipQuote.setUwSystemID(NGESession.getSessionData().getSystem().getSystemId());
					legacyWipQuote.setQuoteAcceptedIn(NGEConstants.YES);
					legacyWipQuote.setQuoteEfctvDt(effective);
					legacyWipQuote.setQuoteXprtnDt(expiration);
					legacyWipQuote.setPolicyXprtnDt(expiration);
					legacyWipQuote.setUpdateUserId(NGESession.getSessionData().getUserId());
					legacyWipQuote.setUpdateTs(NGEDateUtil.getTodayDate());
					legacyWipQuote.setReasonCd(NGEConstants.EMPTY_STRING);
					try{
						String businessType =  transCompData.getTproductState().getProductStateNm();
						logger.debug("businessType" +businessType);
						if(businessType.equalsIgnoreCase(NGEConstants.ProductState.NEW)){
							
							legacyWipQuote.setBusinessTypeCd(NGEConstants.BusinessTypeCd.NEW);
						}
						else{
							legacyWipQuote.setBusinessTypeCd(NGEConstants.BusinessTypeCd.RENEWAL);
						}
					}catch(Exception e){
						/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
						if(commonServiceHelper.checkForRetryExceptions(e, 20, NGEConstants.CatchExceptionTypes.THROW_EXCEPTION))
						{
							logger.error("checkForRetryExceptions returned true");
						}
						/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
						
						/* 2019 PI5 - Release 2.18.0 - Ensure NGE IS Retry Logic - Starts */
						logger.error("Exception message - Retry Logic : " +e.getMessage());
						throw e;
						/* 2019 PI5 - Release 2.18.0 - Ensure NGE IS Retry Logic - Ends */
					}
					return legacyWipQuote;
				}
				else if(NGEConstants.LegacyWIPStatusCd.QUOTE.equalsIgnoreCase(legacyWipQuote.getWipStatusCd()))
				{
					legacyWipQuotesInQuoteStatus.add(legacyWipQuote);
				}
			}
			if(!legacyWipQuotesInQuoteStatus.isEmpty())
			{
				TlegacyWipQuote legacyWipQuote = null;
				legacyWipQuote = legacyWipQuotesInQuoteStatus.get(0);
				legacyWipQuote.setWipStatusCd(NGEConstants.LegacyWIPStatusCd.BOUND);
				legacyWipQuote.setStatusEnteredDt(NGEDateUtil.getTodayDate());
				//legacyWipQuote.setTsystem(systemData.get(0));
				legacyWipQuote.setUwSystemID(NGESession.getSessionData().getSystem().getSystemId());
				legacyWipQuote.setQuoteAcceptedIn(NGEConstants.YES);
				legacyWipQuote.setPolicyId(policyId);
				legacyWipQuote.setQuoteEfctvDt(effective);
				legacyWipQuote.setQuoteXprtnDt(expiration);
				legacyWipQuote.setPolicyXprtnDt(expiration);
				legacyWipQuote.setUpdateUserId(NGESession.getSessionData().getUserId());
				legacyWipQuote.setUpdateTs(NGEDateUtil.getTodayDate());
				legacyWipQuote.setPolEventNo(NGEConstants.ONE_SHORT);
				try{
					String businessType =  transCompData.getTproductState().getProductStateNm();
					logger.debug("businessType" +businessType);
					if(businessType.equalsIgnoreCase(NGEConstants.ProductState.NEW)){
						
						legacyWipQuote.setBusinessTypeCd(NGEConstants.BusinessTypeCd.NEW);
					}
					else{
						legacyWipQuote.setBusinessTypeCd(NGEConstants.BusinessTypeCd.RENEWAL);
					}
				}catch(Exception e){
					/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
					if(commonServiceHelper.checkForRetryExceptions(e, 21, NGEConstants.CatchExceptionTypes.THROW_EXCEPTION))
					{
						logger.error("checkForRetryExceptions returned true");
					}
					/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
					
					/* 2019 PI5 - Release 2.18.0 - Ensure NGE IS Retry Logic - Starts */
					logger.error("Exception message - Retry Logic : " +e.getMessage());
					throw e;
					/* 2019 PI5 - Release 2.18.0 - Ensure NGE IS Retry Logic - Ends */
				}
				return legacyWipQuote;
			}
		
			legacyWipQuoteData = createNewLegacyWipQuote(transactionComponentId, policyId, null, null, legacyWipQuotes,effective, expiration, null);	
			return legacyWipQuoteData;
		}
		legacyWipQuoteData = createNewLegacyWipQuote(transactionComponentId, policyId, null, null, null, effective, expiration, null);	
		return legacyWipQuoteData;
	}

	private TlegacyWipQuote createNewLegacyWipQuote(String transactionComponentId,
			int policyId, String wipId, Short quoteSqn, List<TlegacyWipQuote> legacyWipQuotes, Date effective, Date expiration, String nonRenewalInd) throws AIGCIExceptionMsg {
		TlegacyWipQuote legacyWipQuote = new TlegacyWipQuote();
		TlegacyWipQuotePK legacyWipQuotePK = new TlegacyWipQuotePK();
		String wipIdNew = NGEConstants.EMPTY_STRING;
		legacyWipQuotePK.setTransactionComponentId(transactionComponentId);
		
		List<Tsystem> systemData =  new ArrayList<Tsystem>();			
		systemData = tSystemRepository.findBySystemId(NGESession.getSessionData().getSystem().getSystemId());
		
		if(wipId == null)
		{
			if(legacyWipQuotes == null)
			{
				long wipIdLong = 1;
				wipIdNew = Long.toString(wipIdLong);
				legacyWipQuotePK.setWipId(wipIdNew);
			}
			else
			{
				wipIdNew = generateWipId(legacyWipQuotes);
				legacyWipQuotePK.setWipId(wipIdNew);
			}
		}
		else
		{
			legacyWipQuotePK.setWipId(wipId);
		}

		//Open Item - Same wip id should not be inserted  during renewal for the same product.It should be incremented. 
		if(legacyWipQuotePK.getWipId().equalsIgnoreCase("1"))
		{
			List<TtransactionComponentRltn> transactionComponentRltnList = transactionComponentRelationRepository.findByTransactionComponentId(transactionComponentId);
			
			if(transactionComponentRltnList.size() > 0)
			{
				if(transactionComponentRltnList.get(0).getTcomponentRelationType().getRelationTypeNm().equalsIgnoreCase(NGEConstants.RelationTypeName.RENEWALPRODUCT))
				{
					List<TlegacyWipQuote> legacyWipQuoteListData = tLegacyWipQuoteRepository.findByTransactionComponentId(transactionComponentRltnList.get(0).getTtransactionComponent2().getTransactionComponentId());
					wipId = generateWipId(legacyWipQuoteListData);
					legacyWipQuotePK.setWipId(wipId);
				}
			}
		}
		
		if(null == quoteSqn)
		{
			quoteSqn = 1;
		}
		legacyWipQuotePK.setQuoteSqn(quoteSqn);
		legacyWipQuote.setId(legacyWipQuotePK);
		legacyWipQuote.setWipStatusCd(NGEConstants.LegacyWIPStatusCd.BOUND);
		legacyWipQuote.setStatusEnteredDt(NGEDateUtil.getTodayDate());
		//legacyWipQuote.setTsystem(systemData.get(0));
		legacyWipQuote.setUwSystemID(NGESession.getSessionData().getSystem().getSystemId());
		try{
			//TtransactionComponent transCompData = ttransactionComponentRepository.findByTransactionComponentId(transactionComponentId);
            TtransactionComponent transCompData = transactionComponentDAO.findByTransactionComponentIdForWIPS(transactionComponentId);

			String businessType =  transCompData.getTproductState().getProductStateNm();
			logger.debug("businessType" +businessType);
			if(businessType.equalsIgnoreCase(NGEConstants.ProductState.NEW)){
				
				legacyWipQuote.setBusinessTypeCd(NGEConstants.BusinessTypeCd.NEW);
			}
			else{
				legacyWipQuote.setBusinessTypeCd(NGEConstants.BusinessTypeCd.RENEWAL);
			}
		}catch(Exception e){
			/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
			if(commonServiceHelper.checkForRetryExceptions(e, 22, NGEConstants.CatchExceptionTypes.THROW_EXCEPTION))
			{
				logger.error("checkForRetryExceptions returned true");
			}
			/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
			logger.error("Exception : " +e.getMessage());
			/* PI4 - Q4 2018 Maintenance Release 2.13 - Ensure to Bind all components in a bundle - Starts */
			throw e;
			/* PI4 - Q4 2018 Maintenance Release 2.13 - Ensure to Bind all components in a bundle - Ends */
		}
		legacyWipQuote.setQuoteEfctvDt(effective);
		legacyWipQuote.setQuoteXprtnDt(expiration);
		legacyWipQuote.setPolicyXprtnDt(expiration);
		legacyWipQuote.setQuoteAcceptedIn(NGEConstants.YES);
		legacyWipQuote.setPolEventNo(NGEConstants.ONE_SHORT);
		if(null != nonRenewalInd)
		{
			legacyWipQuote.setNonRenewalIn(nonRenewalInd);
		}
		else if(getNonRenewalInd(legacyWipQuote.getId().getTransactionComponentId()))
		{
			legacyWipQuote.setNonRenewalIn(NGEConstants.YES);
		}
		else
		{
			legacyWipQuote.setNonRenewalIn(NGEConstants.NO);
		}
		legacyWipQuote.setPolicyId(policyId);
		legacyWipQuote.setCreateUserId(NGESession.getSessionData().getUserId());
		legacyWipQuote.setCreateTs(NGEDateUtil.getTodayDate());
		legacyWipQuote.setUpdateUserId(NGESession.getSessionData().getUserId());
		legacyWipQuote.setUpdateTs(NGEDateUtil.getTodayDate());
		return legacyWipQuote;
	}

	private boolean getNonRenewalInd(String transactionComponentId) throws AIGCIExceptionMsg
	{
		List<TtransactionComponentAtrbt> transactionComponentAtrbts= transactionComponentAtrbtRepository.findByTransactionComponentIdAndAttributeNm(transactionComponentId, NGEConstants.GetUnderWriter.NON_RECURRING);
		if(null == transactionComponentAtrbts || transactionComponentAtrbts.isEmpty())
		{
			/* PI3 - Q3 2018 Maintenance Release 2.12 - Ensure to Bind all components in a bundle - Starts */
			logger.error("LegacyWipDAO - Debug - 35");
			/* PI3 - Q3 2018 Maintenance Release 2.12 - Ensure to Bind all components in a bundle - Ends */
			ngeException.throwException(NGEErrorCodes.SERVICE_FAILED,NGEErrorCodes.ERROR_TYPE, null, null);
		}
		else
		{
			if(NGEConstants.RECURRING_VALUE.equalsIgnoreCase(transactionComponentAtrbts.get(0).getAttributeVal()))
			{
				return false;
			}
		}
		return true;		
	}
	private String generateWipId(List<TlegacyWipQuote> legacyWipQuotes) throws AIGCIExceptionMsg {
		String wipId = Long.toString(0)	;
		try
		{
			long maxWipId = 0 ;
			long currentWipId = 0 ;
			for (int i=0;i<legacyWipQuotes.size();i++)
			{
				try{
					currentWipId = Long.parseLong(legacyWipQuotes.get(i).getId().getWipId().trim());
				}
				catch(NumberFormatException e){
					
					logger.info("Unable to Parse WIP ID for current iteration : " +legacyWipQuotes.get(i).getId().getWipId().trim());
					continue;
				}
				
				if ( maxWipId < currentWipId ){
					
					maxWipId = currentWipId;
				}					
			}
			wipId = Long.toString(maxWipId + 1);
			
			return wipId;
		}
		catch(Exception e){
			/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
			if(commonServiceHelper.checkForRetryExceptions(e, 23, NGEConstants.CatchExceptionTypes.THROW_HANDLED_EXCEPTION))
			{
				logger.error("checkForRetryExceptions returned true");
			}
			/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
			
			ngeException.throwException(NGEErrorCodes.UNABLE_TO_GENERATE_WIP_ID,NGEErrorCodes.ERROR_TYPE, null, null);
		}
		return wipId;
	}

	public TlegacyWipQuote getLegacyWipQuote(TlegacyWipQuotePK legacyWipQuotePK) {
		TlegacyWipQuote legacyWipQuote = tLegacyWipQuoteRepository.findOne(legacyWipQuotePK);
		return legacyWipQuote;
	}
	
	private TlegacyWipQuoteCurrency addLegacyWipQuoteCurrency(String transactionComponentId, 
			WIPQuoteDetails wipQuoteDetails, BigDecimal conversionRate, String wipID, short quoteSQN, String currencyCd, BigDecimal premium, boolean canUpdateQuoteAmts) throws AIGCIExceptionMsg {
		TlegacyWipQuoteCurrency legacyWipQuoteCurrency = new TlegacyWipQuoteCurrency();
		TlegacyWipQuoteCurrencyPK legacyWipQuoteCurrencyPK = new TlegacyWipQuoteCurrencyPK();
		legacyWipQuoteCurrencyPK.setTransactionComponentId(transactionComponentId);
		legacyWipQuoteCurrencyPK.setWipId(wipID);
		legacyWipQuoteCurrencyPK.setQuoteSqn(quoteSQN);
		legacyWipQuoteCurrency.setCreateTs(NGEDateUtil.getTodayDate());
		legacyWipQuoteCurrency.setCreateUserId(NGESession.getSessionData().getUserId());
		
		legacyWipQuoteCurrency.setUpdateTs(NGEDateUtil.getTodayDate());
		legacyWipQuoteCurrency.setUpdateUserId(NGESession.getSessionData().getUserId());
		
		TtransactionComponentLimit productlimit = null;
		List<TtransactionComponentLimit> limits = new ArrayList<TtransactionComponentLimit>();  
		limits = transactionComponentLimitRepository.getComponentLimit(transactionComponentId);
		if(limits.size() == 0)
		{
			/* PI3 - Q3 2018 Maintenance Release 2.12 - Ensure to Bind all components in a bundle - Starts */
			logger.error("LegacyWipDAO - Debug - 36");
			/* PI3 - Q3 2018 Maintenance Release 2.12 - Ensure to Bind all components in a bundle - Ends */
			ngeException.throwException(NGEErrorCodes.SERVICE_FAILED,NGEErrorCodes.ERROR_TYPE, null, null);
		}
		if(limits.size() > 1)
		{
			for(TtransactionComponentLimit limit: limits)
			{
				if(!limit.getTcurrency().getCurrencyCd().equalsIgnoreCase(NGEConstants.USD))
				{
					productlimit = limit;
				}
			}
		}
		else
		{
			productlimit = limits.get(0);
		}
		if(null == productlimit)
		{
			/* PI3 - Q3 2018 Maintenance Release 2.12 - Ensure to Bind all components in a bundle - Starts */
			logger.error("LegacyWipDAO - Debug - 37");
			/* PI3 - Q3 2018 Maintenance Release 2.12 - Ensure to Bind all components in a bundle - Ends */
			ngeException.throwException(NGEErrorCodes.SERVICE_FAILED,NGEErrorCodes.ERROR_TYPE, null, null);
		}
		if(conversionRate == null) // local currency code
		{
			Tcurrency currency = commonDAO.getCurrency(currencyCd);
			if(currency != null)
			{
				legacyWipQuoteCurrencyPK.setCurrencyId(currency.getCurrencyId());
			}
			else
			{
				/* PI3 - Q3 2018 Maintenance Release 2.12 - Ensure to Bind all components in a bundle - Starts */
				logger.error("LegacyWipDAO - Debug - 38");
				/* PI3 - Q3 2018 Maintenance Release 2.12 - Ensure to Bind all components in a bundle - Ends */
				ngeException.throwException(NGEErrorCodes.SERVICE_FAILED,NGEErrorCodes.ERROR_TYPE, null, null);
			}
			legacyWipQuoteCurrency.setId(legacyWipQuoteCurrencyPK);
			legacyWipQuoteCurrency = setLocalAmt(wipQuoteDetails, legacyWipQuoteCurrency, premium, productlimit, canUpdateQuoteAmts);
		}
		else //USD currency setting
		{
			Tcurrency currency = commonDAO.getCurrency(NGEConstants.USD);

			if(null != currency)
			{
				legacyWipQuoteCurrencyPK.setCurrencyId(currency.getCurrencyId());
			}
			else
			{
				/* PI3 - Q3 2018 Maintenance Release 2.12 - Ensure to Bind all components in a bundle - Starts */
				logger.error("LegacyWipDAO - Debug - 39");
				/* PI3 - Q3 2018 Maintenance Release 2.12 - Ensure to Bind all components in a bundle - Ends */
				ngeException.throwException(NGEErrorCodes.SERVICE_FAILED,NGEErrorCodes.ERROR_TYPE, null, null);
			}
			legacyWipQuoteCurrency.setId(legacyWipQuoteCurrencyPK);
			legacyWipQuoteCurrency = setLegacyWipCurrencyForUsd(wipQuoteDetails, conversionRate, legacyWipQuoteCurrency, premium, productlimit, canUpdateQuoteAmts);
		}
		
		return legacyWipQuoteCurrency;
	}
	/*Cancel to bind reopen starts*/
	/**
	 * @author Padma
	 * @param product
	 * @param tTransactionComponent
	 * @throws AIGCIExceptionMsg
	 */
	public void wipCancelToBind(ReopenProduct product,
			TtransactionComponent tTransactionComponent) throws AIGCIExceptionMsg {
		short issuingCompanyCd = 0;
		List<TlegacyWipQuote> legacyWipQuotesToBind = new ArrayList<TlegacyWipQuote>();
		List<TlegacyWipQuote> cancelledWip = new ArrayList<TlegacyWipQuote>();
		List<TlegacyWipQuote> lostWip = new ArrayList<TlegacyWipQuote>();
		legacyWipQuotesToBind = getWIPQuoteDetails(tTransactionComponent.getTransactionComponentId());
		WIPQuoteDetails wipDetails = product.getWIPQuoteDetails();
		Tpolicy policy = null;
		
		BigDecimal localPremiumAmount = null;
		BigDecimal premiumAmountInUSD = null;
		Tcurrency currency = null;
		Tpolicy policyResult = null;
		String aigCurrencyCd = null;
		String localCurrencyCode = null;
		BigDecimal rate = new BigDecimal(0);
		HashMap<String, BigDecimal> sourceMap = null;
		String wipCurrencyCode = null;
		
		
		if(!legacyWipQuotesToBind.isEmpty())
		{
			if(null!= product.getWIPQuoteDetails())
			{
				if(null != wipDetails && null!= wipDetails.getWIPId() && null!= wipDetails.getQuoteSqn() && null!= wipDetails.getPolicyDetails())
				{
					PolicyDetails policyDetails = wipDetails.getPolicyDetails();
					if(policyDetails != null){						
					
					Date effectiveDt = NGEDateUtil.getStringDate(policyDetails.getEffectiveDt());
					try
					{
						issuingCompanyCd = (short) policyDetails.getIssuingCompanyCd();
					}
					catch(ClassCastException e)
					{
						ngeException.throwException(NGEErrorCodes.INVALID_POLICY_ISS_COMP_CD,NGEErrorCodes.ERROR_TYPE, null, null);
					}
					policy = policyDAO.getPolicy(policyDetails.getPolicyNo(), issuingCompanyCd, effectiveDt);
					if(null!= policy)
					{
						
						// Update the TPOLICY table for the columns PREMIUM_AM, LOCAL_CURRENCY_PREMIUM_AM
						historyHelper.createPolicyHistory(policy);
						
						localPremiumAmount = policyDetails.getPolicyPremiumAmt();
						localCurrencyCode = policyDetails.getCurrencyCd();
						
						wipCurrencyCode = wipDetails.getCurrencyCd();
						
						if(localCurrencyCode != null){
							currency = commonDAO.getCurrency(localCurrencyCode);
							if(null == currency)
							{
								ngeException.throwException(NGEErrorCodes.INVALID_CURRENCY,NGEErrorCodes.ERROR_TYPE, null, null);
							}
						}
						else if(wipCurrencyCode != null){
							currency = commonDAO.getCurrency(wipCurrencyCode);
							if(null == currency)
							{
								ngeException.throwException(NGEErrorCodes.INVALID_CURRENCY,NGEErrorCodes.ERROR_TYPE, null, null);
							}
						}

						//If localCurrencyCode is USD, skip calling currency conversion
						if(localCurrencyCode != null && localCurrencyCode.equalsIgnoreCase(NGEConstants.USD))
						{
							premiumAmountInUSD = localPremiumAmount;
						}
						else if(wipCurrencyCode != null && wipCurrencyCode.equalsIgnoreCase(NGEConstants.USD)){
							
							premiumAmountInUSD = localPremiumAmount;
						}
						else
						{
							//call currency conversion service to calculate premiumAmountInUSD
							if(null != currency)
							{
								aigCurrencyCd = currency.getAigCurrencyCd();
							}
							sourceMap = cache.getCurrencyRate();
							if(null == sourceMap || sourceMap.isEmpty())
							{
								ngeException.throwException(NGEErrorCodes.PROBLEM_IN_CURRENCY_CONNVERSION_SERVICE,
										NGEErrorCodes.ERROR_TYPE, "Problem occurred in currency conversion service", null);
							}
							else
							{	
								logger.debug("SourceMap Values:" +sourceMap.values());
								if(aigCurrencyCd != null){
									
									rate = sourceMap.get(aigCurrencyCd);
									if(rate == null){
										logger.debug("Given Currency Code is not available from Currency Conversion Service");
										ngeException.throwException(NGEErrorCodes.AIG_CURRENCY_NOT_MATCHING,
												NGEErrorCodes.ERROR_TYPE, "Given Currency Code is not available from Currency Conversion Service", null);
									}
									logger.info("Currency Rate" + rate);
									if(localPremiumAmount != null){
										premiumAmountInUSD = localPremiumAmount.multiply(rate); //To be validated for boundary check
									}
									if(premiumAmountInUSD != null){
										premiumAmountInUSD=premiumAmountInUSD.setScale(6, RoundingMode.HALF_UP);
										ngeValidations.validatePolicyPremiumAmount(premiumAmountInUSD);
									}
								}																
							}							
						}
						
						policy.setLocalCurrencyPremiumAm(localPremiumAmount);
						policy.setPremiumAm(premiumAmountInUSD);
						
						try
						{
							policyResult = policyDAO.savePolicy(policy);

							if(null == policyResult)
							{
								/* PI3 - Q3 2018 Maintenance Release 2.12 - Ensure to Bind all components in a bundle - Starts */
								logger.error("LegacyWipDAO - Debug - 40");
								/* PI3 - Q3 2018 Maintenance Release 2.12 - Ensure to Bind all components in a bundle - Ends */
								ngeException.throwException(NGEErrorCodes.SERVICE_FAILED,NGEErrorCodes.ERROR_TYPE, null, null);
							}
						}
						catch(Exception e)
						{
							/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
							if(commonServiceHelper.checkForRetryExceptions(e, 24, NGEConstants.CatchExceptionTypes.THROW_HANDLED_EXCEPTION))
							{
								logger.error("checkForRetryExceptions returned true");
							}
							/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
							logger.error("Exception Message :" +e.getMessage());
							ngeException.throwException(NGEErrorCodes.SERVICE_FAILED,NGEErrorCodes.ERROR_TYPE, null, null);
						}
						
						
						for(TlegacyWipQuote cancel:legacyWipQuotesToBind)
						{
							if(cancel.getId().getWipId().trim().equalsIgnoreCase(wipDetails.getWIPId()) &&
							   cancel.getId().getQuoteSqn() == wipDetails.getQuoteSqn() &&
							   cancel.getPolicyId() == policy.getPolicyId() &&
							   cancel.getWipStatusCd().equalsIgnoreCase(NGEConstants.LegacyWIPStatusCd.CANCELLED))
							{
								cancelledWip.add(cancel);
							}
							else if(cancel.getId().getWipId().trim().equalsIgnoreCase(wipDetails.getWIPId()) &&
									   cancel.getId().getQuoteSqn() == wipDetails.getQuoteSqn() &&
									   cancel.getWipStatusCd().equalsIgnoreCase(NGEConstants.LegacyWIPStatusCd.LOST))
							{
								lostWip.add(cancel);
							}
						}
					}
					else
					{
						for(TlegacyWipQuote lost:legacyWipQuotesToBind)
						{
							if(lost.getId().getWipId().trim().equalsIgnoreCase(wipDetails.getWIPId()) &&
									lost.getId().getQuoteSqn() == wipDetails.getQuoteSqn() &&
											lost.getWipStatusCd().equalsIgnoreCase(NGEConstants.LegacyWIPStatusCd.LOST))
							{
								lostWip.add(lost);
							}
						}
					}
				}
			}
				else if(null!= wipDetails.getWIPId() && null!= wipDetails.getQuoteSqn())
				{
					for(TlegacyWipQuote cancel:legacyWipQuotesToBind)
					{
						if(cancel.getId().getWipId().trim().equalsIgnoreCase(wipDetails.getWIPId()) &&
						   cancel.getId().getQuoteSqn() == wipDetails.getQuoteSqn() &&
						   cancel.getWipStatusCd().equalsIgnoreCase(NGEConstants.LegacyWIPStatusCd.CANCELLED))
						{
							cancelledWip.add(cancel);
						}
						else if(cancel.getId().getWipId().trim().equalsIgnoreCase(wipDetails.getWIPId()) &&
								   cancel.getId().getQuoteSqn() == wipDetails.getQuoteSqn() &&
								   cancel.getWipStatusCd().equalsIgnoreCase(NGEConstants.LegacyWIPStatusCd.LOST))
						{
							lostWip.add(cancel);
						}
					}
				}
				else if(null!= wipDetails.getWIPId())
				{
					for(TlegacyWipQuote cancel:legacyWipQuotesToBind)
					{
						if(cancel.getId().getWipId().trim().equalsIgnoreCase(wipDetails.getWIPId()) && 
								cancel.getWipStatusCd().equalsIgnoreCase(NGEConstants.LegacyWIPStatusCd.CANCELLED))
						{
							cancelledWip.add(cancel);
						}
						else if(cancel.getId().getWipId().trim().equalsIgnoreCase(wipDetails.getWIPId()) &&
								   cancel.getId().getQuoteSqn() == wipDetails.getQuoteSqn() &&
								   cancel.getWipStatusCd().equalsIgnoreCase(NGEConstants.LegacyWIPStatusCd.LOST))
						{
							lostWip.add(cancel);
						}
					}
				}
				if(!cancelledWip.isEmpty())
				{
					//updateLegacyWipQuoteHs(cancelledWip);
					UpdateToBind(cancelledWip, wipDetails, policy);
				}
				else if(!lostWip.isEmpty())
				{
					updateWipDetails(wipDetails,tTransactionComponent,NGEConstants.LifeCycleStatus.QUOTED,NGEConstants.LifeCycleStatus.LOST);
				}
			}
			else
			{
				for(TlegacyWipQuote cancel:legacyWipQuotesToBind)
				{
					if(cancel.getWipStatusCd().equalsIgnoreCase(NGEConstants.LegacyWIPStatusCd.CANCELLED))
					{
						cancelledWip.add(cancel);
					}
				}
				if(!cancelledWip.isEmpty())
				{
					//updateLegacyWipQuoteHs(cancelledWip);
					UpdateToBind(cancelledWip, wipDetails, policy);
				}
			}
		}
	}

/*	private List<TlegacyWipQuote> getCancelledPolicies(String transactionComponentId) 
	{
		List<TlegacyWipQuote> legacyWipQuotesToBind = tLegacyWipQuoteRepository.findCancelledPolicies(transactionComponentId, NGEConstants.LegacyWIPStatusCd.CANCELLED);
		List<TlegacyWipQuote> legacyWipQuotes= new ArrayList<TlegacyWipQuote>();
		if(!legacyWipQuotesToBind.isEmpty())
		{
			for(TlegacyWipQuote legacyWipToBind:legacyWipQuotesToBind)
			{
				if(legacyWipToBind.getPolicyId() != 0)
				{
					legacyWipQuotes.add(legacyWipToBind);
				}
			}
		}
		return legacyWipQuotes;
	}*/

/*	private void updateLegacyWipQuoteHs(
			List<TlegacyWipQuote> legacyWipQuotesToBind) 
	{
		for(TlegacyWipQuote legacyWip: legacyWipQuotesToBind)
		{
			tLegacyWIPQuoteHsRepository.insertLegacyWIPQuoteHistory(legacyWip.getId().getTransactionComponentId(),
					legacyWip.getId().getWipId(),legacyWip.getId().getQuoteSqn());
		}
	}*/

	private void UpdateToBind(List<TlegacyWipQuote> legacyWipQuotesToBind, WIPQuoteDetails wipDetails, Tpolicy policyInfo) throws AIGCIExceptionMsg 
	{
		List<Tsystem> systemData =  new ArrayList<Tsystem>();			
		systemData = tSystemRepository.findBySystemId(NGESession.getSessionData().getSystem().getSystemId());
		
		BigDecimal rate = new BigDecimal("1");
		Set<TtransactionComponentLimit> limitList = new HashSet<TtransactionComponentLimit>();
		
		//Abul changes defect 409 starts
		String LifeCycleStatus=NGEConstants.LifeCycleStatus.BOUND;
		//Abul changes defect 409 ends
		for(TlegacyWipQuote legacyWip:legacyWipQuotesToBind)
		{
			//Abul Added Starts
			historyHelper.createTlegacyWipQuoteHHistory(legacyWip);
			//Abul Added Ends
			
			legacyWip.setQuoteAcceptedIn(NGEConstants.YES);
			//legacyWip.setTsystem(systemData.get(0));
			legacyWip.setUwSystemID(NGESession.getSessionData().getSystem().getSystemId());
			legacyWip.setWipStatusCd(NGEConstants.LegacyWIPStatusCd.BOUND);
			legacyWip.setUpdateUserId(NGESession.getSessionData().getUserId());
			legacyWip.setUpdateTs(NGEDateUtil.getTodayDate());
			legacyWip.setReasonCd(NGEConstants.EMPTY_STRING);
			legacyWip.setStatusEnteredDt(NGEDateUtil.getTodayDate());
			
			if(wipDetails != null)
			{
				legacyWip = updateWIPDetais(legacyWip, wipDetails, true);
			}
			
			//Abul Changes defect 409 starts
			//insertCurrencyWipQuote(legacyWip.getTtransactionComponent().getTransactionComponentId(),policyInfo,wipDetails,null,legacyWip,LifeCycleStatus);
			//Abul Changes defect 409 ends
			
			if(wipDetails != null && wipDetails.getCurrencyCd()!=null && !wipDetails.getCurrencyCd().equalsIgnoreCase("") && !wipDetails.getCurrencyCd().equalsIgnoreCase(NGEConstants.USD)){
				
				
				rate = getCurrencyRate(null, wipDetails.getCurrencyCd());
				if(rate == null){
					logger.debug("Given Currency Code is not available from Currency Conversion Service");
					ngeException.throwException(NGEErrorCodes.AIG_CURRENCY_NOT_MATCHING,
							NGEErrorCodes.ERROR_TYPE, "Given Currency Code is not available from Currency Conversion Service", null);
				}
				logger.info("Currency Rate" + rate);
				//Abul changes Defect 409 starts
				insertCurrencyWipQuote(legacyWip.getTtransactionComponent().getTransactionComponentId(),policyInfo,wipDetails,rate,legacyWip,LifeCycleStatus);
				//Abul changes Defect 409 starts
				
			}
			else{
				
				limitList = legacyWip.getTtransactionComponent().getTtransactionComponentLimits();
				
				if(limitList.size() > 1){
					for(TtransactionComponentLimit transactionComponentLimit:limitList)
					{
						if(!NGEConstants.USD.equalsIgnoreCase(transactionComponentLimit.getTcurrency().getCurrencyCd()))
						{
							
							rate = getCurrencyRate(limitList, transactionComponentLimit.getTcurrency().getCurrencyCd());
							if(rate == null){
								logger.debug("Given Currency Code is not available from Currency Conversion Service");
								ngeException.throwException(NGEErrorCodes.AIG_CURRENCY_NOT_MATCHING,
										NGEErrorCodes.ERROR_TYPE, "Given Currency Code is not available from Currency Conversion Service", null);
							}
							logger.info("Currency Rate" + rate);
							//Abul changes Defect 409 starts
							if(wipDetails != null && wipDetails.getCurrencyCd() == null){
							
								wipDetails.setCurrencyCd(transactionComponentLimit.getTcurrency().getCurrencyCd());
							}
							
							insertCurrencyWipQuote(legacyWip.getTtransactionComponent().getTransactionComponentId(),policyInfo,wipDetails,rate,legacyWip,LifeCycleStatus);
							//Abul changes Defect 409 ends
						}
					}
				}
				else{					
						if(wipDetails != null && wipDetails.getCurrencyCd() == null){
							
							wipDetails.setCurrencyCd(NGEConstants.USD);
						}
						
						//Abul changes Defect 409 starts
						insertCurrencyWipQuote(legacyWip.getTtransactionComponent().getTransactionComponentId(),policyInfo,wipDetails,rate,legacyWip,LifeCycleStatus);
						//Abul changes Defect 409 ends
				}
				
			}
			
			/*try
			{
				tLegacyWipQuoteRepository.save(legacyWip);
			}
			catch(Exception e)
			{
				logger.error("Exception : " +e.getMessage());
				ngeException.throwException(NGEErrorCodes.SERVICE_FAILED,NGEErrorCodes.ERROR_TYPE, null, null);
			}*/
		}
	}
	
	/*Cancel to bind reopen ends*/
	
	public List<TlegacyWipQuote> getWipQuoteDetailsList(String transactionComponentId,String wipStatusCd) throws AIGCIExceptionMsg{
		List<TlegacyWipQuote> wipQuoteDetailsList=null;
		wipQuoteDetailsList=tLegacyWipQuoteRepository.findByTransCompId(transactionComponentId,wipStatusCd);
		if(wipQuoteDetailsList==null){
			/* PI3 - Q3 2018 Maintenance Release 2.12 - Ensure to Bind all components in a bundle - Starts */
			logger.error("LegacyWipDAO - Debug - 42");
			/* PI3 - Q3 2018 Maintenance Release 2.12 - Ensure to Bind all components in a bundle - Ends */
			ngeException.throwException(NGEErrorCodes.SERVICE_FAILED,NGEErrorCodes.ERROR_TYPE, null, null);
		}
		return wipQuoteDetailsList;
	}
	public void legacyWipQuotesToBook(Set<TlegacyWipQuote> legacyWipQuotesToBook) throws AIGCIExceptionMsg {
		List<Tsystem> systemData =  new ArrayList<Tsystem>();			
		systemData = tSystemRepository.findBySystemId(NGESession.getSessionData().getSystem().getSystemId());
		
		for(TlegacyWipQuote legacyWip:legacyWipQuotesToBook)
		{
			legacyWip.setQuoteAcceptedIn(NGEConstants.YES);
			//legacyWip.setUwSystemID((NGESession.getSessionData().getSystem().getSystemId()));
			legacyWip.setWipStatusCd(NGEConstants.LegacyWIPStatusCd.BOOK);
			legacyWip.setUpdateUserId(NGESession.getSessionData().getUserId());
			legacyWip.setUpdateTs(NGEDateUtil.getTodayDate());
			// Setting the System Id
			//legacyWip.setTsystem(systemData.get(0));
			legacyWip.setUwSystemID(NGESession.getSessionData().getSystem().getSystemId());
			
			try
			{
				tLegacyWipQuoteRepository.save(legacyWip);
			}
			catch(Exception e)
			{
				/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
				if(commonServiceHelper.checkForRetryExceptions(e, 25, NGEConstants.CatchExceptionTypes.THROW_HANDLED_EXCEPTION))
				{
					logger.error("checkForRetryExceptions returned true");
				}
				/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
				logger.error("Exception : " +e.getMessage());
				ngeException.throwException(NGEErrorCodes.SERVICE_FAILED,NGEErrorCodes.ERROR_TYPE, null, null);
			}
		}
	}
	public void updateLegacyWipQuoteHs(
			List<TlegacyWipQuote> legacyWipQuotesToBind) 
	{
		for(TlegacyWipQuote legacyWip: legacyWipQuotesToBind)
		{
			tLegacyWIPQuoteHsRepository.insertLegacyWIPQuoteHistory(legacyWip.getId().getTransactionComponentId(),
					NGECommonUtil.convertToString(legacyWip.getId().getWipId()),legacyWip.getId().getQuoteSqn());
		}
	}
	public void deleteWipList(List<TlegacyWipQuote> wipQuoteList) {
		if(wipQuoteList.size()>0){
			for(TlegacyWipQuote legacyWipQuote:wipQuoteList){
				try {
					historyHelper.createTlegacyWipQuoteHHistory(legacyWipQuote);
				} catch (AIGCIExceptionMsg e) {
					logger.error(e.getMessage());
				}
				tLegacyWipQuoteRepository.delete(legacyWipQuote);	
			}
			
		}
	}
	
	public Tpolicy insertPriorPolicyInTPolicy(PolicyDetails priorPolicy) throws AIGCIExceptionMsg{
		
		String policyNo = NGEConstants.EMPTY_STRING;
		short issuingCompanyCd = 0;
		XMLGregorianCalendar effDate = null;
		XMLGregorianCalendar exprDate = null;
		Tpolicy policyInfo = new Tpolicy();		
		String policyTypeName = NGEConstants.EMPTY_STRING;
		String localCurrencyCode = null;
		BigDecimal localPremiumAmount;
		BigDecimal premiumAmountInUSD = new BigDecimal(0);
		Tcurrency currency = null;		
		String aigCurrencyCd = NGEConstants.EMPTY_STRING;
		HashMap<String, BigDecimal> sourceMap = null;
		BigDecimal rate = new BigDecimal(0);
		TpolicyType policyType = null;
		Date effectiveDate = null;
		Date expirationDate = null;
		
		  policyNo = priorPolicy.getPolicyNo();
		  try
		  {
		        issuingCompanyCd = (short) priorPolicy.getIssuingCompanyCd(); 
		  }
		  catch(ClassCastException e)
		  {
		        ngeException.throwException(NGEErrorCodes.INVALID_POLICY_ISS_COMP_CD,NGEErrorCodes.ERROR_TYPE, null, null);
		  }
		effDate = priorPolicy.getEffectiveDt();
		if(effDate != null){
			
			effectiveDate = NGEDateUtil.getStringDate(effDate);
		}		
		
		policyTypeName = NGEConstants.PRIOR_POLICY;
		policyType = policyDAO.getPolicyType(policyTypeName);
		if(null == policyType)
		{
			ngeException.throwException(NGEErrorCodes.INVALID_POLICY_TYPE,NGEErrorCodes.ERROR_TYPE, null, null);
		}
		
		exprDate = priorPolicy.getExpirationDt();
		if(exprDate != null){
		
			expirationDate = NGEDateUtil.getStringDate(exprDate);
		}
		else{
			
			expirationDate = NGEDateUtil.incrementDateByDate(effectiveDate,NGEConstants.DATE_INCREMENT_BY_ONE_YEAR);
		}
		
		localPremiumAmount = priorPolicy.getPolicyPremiumAmt();
		localCurrencyCode = priorPolicy.getCurrencyCd();
		
		if(localCurrencyCode != null){
			
			currency = commonDAO.getCurrency(localCurrencyCode);
			
			if(null == currency)
			{
				ngeException.throwException(NGEErrorCodes.INVALID_CURRENCY,NGEErrorCodes.ERROR_TYPE, null, null);
			}
			
			if(localCurrencyCode.equalsIgnoreCase(NGEConstants.USD))
			{
				premiumAmountInUSD = localPremiumAmount;
			}
			else
			{
				//call currency conversion service to calculate premiumAmountInUSD
				if(null != currency)
				{
					aigCurrencyCd = currency.getAigCurrencyCd();
				}
				sourceMap = cache.getCurrencyRate();
				if(null == sourceMap || sourceMap.isEmpty())
				{
					ngeException.throwException(NGEErrorCodes.PROBLEM_IN_CURRENCY_CONNVERSION_SERVICE,
							NGEErrorCodes.ERROR_TYPE, "Problem occurred in currency conversion service", null);
				}
				else
				{
					logger.debug("SourceMap Values:" +sourceMap.values());
					rate = sourceMap.get(aigCurrencyCd);
					if(rate == null){
						logger.debug("Given Currency Code is not available from Currency Conversion Service");
						ngeException.throwException(NGEErrorCodes.AIG_CURRENCY_NOT_MATCHING,
								NGEErrorCodes.ERROR_TYPE, "Given Currency Code is not available from Currency Conversion Service", null);
					}
					logger.info("Currency Rate" + rate);
					premiumAmountInUSD = localPremiumAmount.multiply(rate); //To be validated for boundary check
					premiumAmountInUSD=premiumAmountInUSD.setScale(6, RoundingMode.HALF_UP);
					ngeValidations.validatePolicyPremiumAmount(premiumAmountInUSD);
				}
			}
		}		
				
		policyInfo.setPolicyNo(policyNo);
		policyInfo.setCompanyCd(issuingCompanyCd); 
		policyInfo.setEffectiveDt(effectiveDate);
		policyInfo.setExpirationDt(expirationDate);
		policyInfo.setLocalCurrencyPremiumAm(localPremiumAmount);
		policyInfo.setTpolicyType(policyType);
		policyInfo.setTcurrency(currency);
		policyInfo.setPremiumAm(premiumAmountInUSD);
		policyInfo.setSystemId(NGESession.getSessionData().getSystem().getSystemId());
		policyInfo.setCreateUserId(NGESession.getSessionData().getUserId());
		policyInfo.setCreateTs(NGEDateUtil.getTodayDate());
		
		
		try
		{
			policyInfo = policyDAO.savePolicy(policyInfo);
			
			if(null == policyInfo)
			{
				/* PI3 - Q3 2018 Maintenance Release 2.12 - Ensure to Bind all components in a bundle - Starts */
				logger.error("LegacyWipDAO - Debug - 44");
				/* PI3 - Q3 2018 Maintenance Release 2.12 - Ensure to Bind all components in a bundle - Ends */
				ngeException.throwException(NGEErrorCodes.SERVICE_FAILED,NGEErrorCodes.ERROR_TYPE, null, null);
			}			
		}
		catch(Exception e)
		{
			/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
			if(commonServiceHelper.checkForRetryExceptions(e, 26, NGEConstants.CatchExceptionTypes.THROW_HANDLED_EXCEPTION))
			{
				logger.error("checkForRetryExceptions returned true");
			}
			/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
			logger.error("Exception Message :" +e.getMessage());
			ngeException.throwException(NGEErrorCodes.SERVICE_FAILED,NGEErrorCodes.ERROR_TYPE, null, null);
		}
		
		return policyInfo;
	}
/**
 * PI3 Maintenance Release 2.16 release - Remove WIP when changing the status from Quoted to void 
 * @param wipDetailsData
 * @param legacyWipQuotePKData
 * @param transactionComponentId
 * @param legacyWipQuoteCurrencyList
 * @param leagacyWipQuoteListForQuote
 * @param legacyWipQuoteRetrivedData
 * @param leagacyWipQuoteListForCurrency
 * @throws AIGCIExceptionMsg
 */
private void deleteWIPDetails(WIPQuoteDetails wipDetailsData, TlegacyWipQuotePK legacyWipQuotePKData, String transactionComponentId, List<TlegacyWipQuoteCurrency> legacyWipQuoteCurrencyList, List<TlegacyWipQuote> leagacyWipQuoteListForQuote,TlegacyWipQuote  legacyWipQuoteRetrivedData,List<TlegacyWipQuoteCurrency> leagacyWipQuoteListForCurrency) throws AIGCIExceptionMsg{


			if(wipDetailsData!=null && wipDetailsData.getWIPId()!=null){

				/*if(wipDetailsData.getWIPId()!=null){*/
					
					if(wipDetailsData.getQuoteSqn() != null){
						
						legacyWipQuotePKData.setTransactionComponentId(transactionComponentId);
						legacyWipQuotePKData.setWipId(wipDetailsData.getWIPId());
						legacyWipQuotePKData.setQuoteSqn(wipDetailsData.getQuoteSqn());
						
						legacyWipQuoteRetrivedData = tLegacyWipQuoteRepository.findOne(legacyWipQuotePKData);
						
						legacyWipQuoteCurrencyList = tlegacyWipQuoteCurrencyRepository.findByTransCompIdAndWipIdAndQuoteSqn(transactionComponentId, wipDetailsData.getWIPId(), wipDetailsData.getQuoteSqn());
						
						if(legacyWipQuoteCurrencyList != null && !legacyWipQuoteCurrencyList.isEmpty()){
							
							for(TlegacyWipQuoteCurrency legacyWIPQuoteCurrency : legacyWipQuoteCurrencyList){
								
								historyHelper.createTlegacyWipQuoteCurrencyHHistory(legacyWIPQuoteCurrency);
								tlegacyWipQuoteCurrencyRepository.delete(legacyWIPQuoteCurrency);
							}
						}
						
						if(legacyWipQuoteRetrivedData != null){
							
							historyHelper.createTlegacyWipQuoteHHistory(legacyWipQuoteRetrivedData);
							tLegacyWipQuoteRepository.delete(legacyWipQuoteRetrivedData);
						}
						
					}
					else{
						
						leagacyWipQuoteListForQuote = tLegacyWipQuoteRepository.findByTransactionComponentIdandWipId(transactionComponentId, wipDetailsData.getWIPId());

						legacyWipQuoteCurrencyList = tlegacyWipQuoteCurrencyRepository.findByTransCompIdandWipId(transactionComponentId, wipDetailsData.getWIPId());

						/*tLegacyWIPQuoteHsRepository.insertLegacyWIPQuoteHistory(legacyWipQuoteRetrivedData.getId().getTransactionComponentId(),
								legacyWipQuoteRetrivedData.getId().getWipId(),legacyWipQuoteRetrivedData.getId().getQuoteSqn());*/
						if(legacyWipQuoteCurrencyList != null && !legacyWipQuoteCurrencyList.isEmpty()){
							for( TlegacyWipQuoteCurrency legacyWipQuoteCurrencyItr:legacyWipQuoteCurrencyList){
								//tlegacyWipQuoteCurrencyHsRepository.insertLegacyWIPQuoteCurrencyHistory(legacyWipQuoteCurrencyItr.getId().getTransactionComponentId(),legacyWipQuoteCurrencyItr.getId().getWipId(),legacyWipQuoteCurrencyItr.getId().getQuoteSqn());
								
								if(legacyWipQuoteCurrencyItr != null){
									historyHelper.createTlegacyWipQuoteCurrencyHHistory(legacyWipQuoteCurrencyItr);
								}								
							}
							for(TlegacyWipQuoteCurrency itrForCurrency :legacyWipQuoteCurrencyList ){								
								
								tlegacyWipQuoteCurrencyRepository.delete(itrForCurrency);    
							}							   
						}
						
						if(leagacyWipQuoteListForQuote != null && !leagacyWipQuoteListForQuote.isEmpty()){
							
							for(TlegacyWipQuote itrForQuote : leagacyWipQuoteListForQuote){
								
								historyHelper.createTlegacyWipQuoteHHistory(itrForQuote);
								tLegacyWipQuoteRepository.delete(itrForQuote);
							}						
						}
					}				
				/*}*/
			}
			else{

				leagacyWipQuoteListForQuote = tLegacyWipQuoteRepository.findByTransactionComponentId(transactionComponentId);
				
				leagacyWipQuoteListForCurrency = tlegacyWipQuoteCurrencyRepository.findByTransCompId(transactionComponentId);

				if(leagacyWipQuoteListForCurrency!=null && !leagacyWipQuoteListForCurrency.isEmpty()){

					for(TlegacyWipQuoteCurrency itrForCurrency :leagacyWipQuoteListForCurrency ){
						//tlegacyWipQuoteCurrencyHsRepository.insertLegacyWIPQuoteCurrencyHistory(itrForCurrency.getId().getTransactionComponentId(),itrForCurrency.getId().getWipId(), itrForCurrency.getId().getQuoteSqn());
						
						if(itrForCurrency != null){
							historyHelper.createTlegacyWipQuoteCurrencyHHistory(itrForCurrency);
						}						
						tlegacyWipQuoteCurrencyRepository.delete(itrForCurrency); 
					}
					/*tLegacyWIPQuoteHsRepository.insertLegacyWIPQuoteHistory(itrForQuote.getId().getTransactionComponentId(),
							itrForQuote.getId().getWipId(),itrForQuote.getId().getQuoteSqn());*/					
				}
				
				if(leagacyWipQuoteListForQuote!=null && !leagacyWipQuoteListForQuote.isEmpty()){

					for(TlegacyWipQuote itrForQuote : leagacyWipQuoteListForQuote){

						historyHelper.createTlegacyWipQuoteHHistory(itrForQuote);
						tLegacyWipQuoteRepository.delete(itrForQuote);
					}
				}
			}
	
	}
}