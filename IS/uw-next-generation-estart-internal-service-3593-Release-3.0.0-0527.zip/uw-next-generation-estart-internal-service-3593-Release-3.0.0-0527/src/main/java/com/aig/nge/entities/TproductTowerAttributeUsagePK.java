package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the TPRODUCT_TOWER_ATTRIBUTE_USAGE database table.
 * 
 */
@Embeddable
public class TproductTowerAttributeUsagePK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="PRODUCT_TOWER_ID")
	private short productTowerId;

	@Column(name="TABLE_ID")
	private short tableId;

	@Column(name="ATTRIBUTE_ID")
	private short attributeId;

	@Column(name="USAGE_TYPE_ID")
	private short usageTypeId;

    public TproductTowerAttributeUsagePK() {
    }
	public short getProductTowerId() {
		return this.productTowerId;
	}
	public void setProductTowerId(short productTowerId) {
		this.productTowerId = productTowerId;
	}
	public short getTableId() {
		return this.tableId;
	}
	public void setTableId(short tableId) {
		this.tableId = tableId;
	}
	public short getAttributeId() {
		return this.attributeId;
	}
	public void setAttributeId(short attributeId) {
		this.attributeId = attributeId;
	}
	public short getUsageTypeId() {
		return this.usageTypeId;
	}
	public void setUsageTypeId(short usageTypeId) {
		this.usageTypeId = usageTypeId;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof TproductTowerAttributeUsagePK)) {
			return false;
		}
		TproductTowerAttributeUsagePK castOther = (TproductTowerAttributeUsagePK)other;
		return 
			(this.productTowerId == castOther.productTowerId)
			&& (this.tableId == castOther.tableId)
			&& (this.attributeId == castOther.attributeId)
			&& (this.usageTypeId == castOther.usageTypeId);

    }
    
	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + ((int) this.productTowerId);
		hash = hash * prime + ((int) this.tableId);
		hash = hash * prime + ((int) this.attributeId);
		hash = hash * prime + ((int) this.usageTypeId);
		
		return hash;
    }
}