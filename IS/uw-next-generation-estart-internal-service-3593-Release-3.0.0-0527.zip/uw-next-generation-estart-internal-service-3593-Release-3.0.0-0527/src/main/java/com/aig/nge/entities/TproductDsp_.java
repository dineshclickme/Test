package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-02-24T11:59:49.968+0530")
@StaticMetamodel(TproductDsp.class)
public class TproductDsp_ {
	public static volatile SingularAttribute<TproductDsp, Integer> productDspId;
	public static volatile SingularAttribute<TproductDsp, Timestamp> createTs;
	public static volatile SingularAttribute<TproductDsp, String> createUserId;
	public static volatile SingularAttribute<TproductDsp, String> deletedIn;
	public static volatile SingularAttribute<TproductDsp, Short> profitUnitCd;
	public static volatile SingularAttribute<TproductDsp, Short> sectionCd;
	public static volatile SingularAttribute<TproductDsp, Timestamp> updateTs;
	public static volatile SingularAttribute<TproductDsp, String> updateUserId;
	public static volatile SingularAttribute<TproductDsp, Tdivision> tdivision;
	public static volatile SingularAttribute<TproductDsp, Tproduct> tproduct;
	public static volatile SingularAttribute<TproductDsp, TproductTowerTuwSubProduct> tproductTowerTuwSubProduct;
	public static volatile SingularAttribute<TproductDsp, String> dspNm;
}
