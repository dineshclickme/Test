package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2016-03-30T12:48:47.842+0530")
@StaticMetamodel(TlegacyRulesViolation.class)
public class TlegacyRulesViolation_ {
	public static volatile SingularAttribute<TlegacyRulesViolation, String> transactionComponentId;
	public static volatile SingularAttribute<TlegacyRulesViolation, Timestamp> createTs;
	public static volatile SingularAttribute<TlegacyRulesViolation, String> createUserId;
	public static volatile SingularAttribute<TlegacyRulesViolation, String> methodNm;
	public static volatile SingularAttribute<TlegacyRulesViolation, Timestamp> updateTs;
	public static volatile SingularAttribute<TlegacyRulesViolation, String> updateUserId;
	public static volatile SingularAttribute<TlegacyRulesViolation, TlegacyError> tlegacyError;
	public static volatile SingularAttribute<TlegacyRulesViolation, Tsystem> tsystem;
	public static volatile SingularAttribute<TlegacyRulesViolation, TtransactionComponent> ttransactionComponent;
}
