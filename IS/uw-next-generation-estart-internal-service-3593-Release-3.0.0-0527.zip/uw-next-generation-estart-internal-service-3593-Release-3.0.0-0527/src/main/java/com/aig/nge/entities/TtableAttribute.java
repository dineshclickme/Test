package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;

import org.apache.openjpa.persistence.DataCache;
import java.sql.Timestamp;
import java.util.Set;


/**
 * The persistent class for the TTABLE_ATTRIBUTE database table.
 * 
 */
@Entity
@DataCache
@Table(name="TTABLE_ATTRIBUTE")
public class TtableAttribute implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private TtableAttributePK id;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="CREATE_TS")
	private Timestamp createTs;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="CREATE_USER_ID")
	private String createUserId;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="UPDATE_TS")
	private Timestamp updateTs;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="UPDATE_USER_ID")
	private String updateUserId;

	//bi-directional many-to-one association to TproductTowerAttribute
	@OneToMany(mappedBy="ttableAttribute", cascade={CascadeType.ALL})
	private Set<TproductTowerAttribute> tproductTowerAttributes;

	//bi-directional many-to-one association to Tattribute
	@ManyToOne
	@JoinColumn(name="ATTRIBUTE_ID")
	private Tattribute tattribute;

	//bi-directional many-to-one association to Ttable
	@ManyToOne
	@JoinColumn(name="TABLE_ID")
	private Ttable ttable;

	//bi-directional many-to-one association to TtableAttributeReference
	@OneToMany(mappedBy="ttableAttribute", cascade={CascadeType.ALL})
	private Set<TtableAttributeReference> ttableAttributeReferences;

    public TtableAttribute() {
    }

	public TtableAttributePK getId() {
		return this.id;
	}

	public void setId(TtableAttributePK id) {
		this.id = id;
	}
	
	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public Set<TproductTowerAttribute> getTproductTowerAttributes() {
		return this.tproductTowerAttributes;
	}

	public void setTproductTowerAttributes(Set<TproductTowerAttribute> tproductTowerAttributes) {
		this.tproductTowerAttributes = tproductTowerAttributes;
	}
	
	public Tattribute getTattribute() {
		return this.tattribute;
	}

	public void setTattribute(Tattribute tattribute) {
		this.tattribute = tattribute;
	}
	
	public Ttable getTtable() {
		return this.ttable;
	}

	public void setTtable(Ttable ttable) {
		this.ttable = ttable;
	}
	
	public Set<TtableAttributeReference> getTtableAttributeReferences() {
		return this.ttableAttributeReferences;
	}

	public void setTtableAttributeReferences(Set<TtableAttributeReference> ttableAttributeReferences) {
		this.ttableAttributeReferences = ttableAttributeReferences;
	}
	
}