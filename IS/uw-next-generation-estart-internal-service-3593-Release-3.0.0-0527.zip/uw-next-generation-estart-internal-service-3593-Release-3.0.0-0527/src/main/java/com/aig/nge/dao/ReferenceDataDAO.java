package com.aig.nge.dao;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.activation.FileDataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.Cache;
import org.springframework.cache.support.SimpleCacheManager;
import org.springframework.cache.support.SimpleValueWrapper;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.aig.nge.entities.TassetType;
import com.aig.nge.entities.TassetTypeAttribute;
import com.aig.nge.entities.Tattribute;
import com.aig.nge.entities.TblockType;
import com.aig.nge.entities.Tbranch;
import com.aig.nge.entities.TbranchType;
import com.aig.nge.entities.TcomponentRelationType;
import com.aig.nge.entities.Tcurrency;
import com.aig.nge.entities.Terror;
import com.aig.nge.entities.TexposureLookup;
import com.aig.nge.entities.TlegacyError;
import com.aig.nge.entities.Tlocation;
import com.aig.nge.entities.TmarketableProduct;
import com.aig.nge.entities.TmarketableProductLocation;
import com.aig.nge.entities.Tparty;
import com.aig.nge.entities.TpartyProcessing;
import com.aig.nge.entities.TpartyType;
import com.aig.nge.entities.TpolicyType;
import com.aig.nge.entities.TprdctTwrTuwSbprdctAstTyp;
import com.aig.nge.entities.TproductState;
import com.aig.nge.entities.TproductTower;
import com.aig.nge.entities.TproductTowerAttribute;
import com.aig.nge.entities.TproductTowerAttributeUsage;
import com.aig.nge.entities.TproductTowerAutoCloseRule;
import com.aig.nge.entities.TproductTowerDivision;
import com.aig.nge.entities.TproductTowerReason;
import com.aig.nge.entities.Tproperty;
import com.aig.nge.entities.Treason;
import com.aig.nge.entities.TreftabMis780;
import com.aig.nge.entities.TrelationType;
import com.aig.nge.entities.Trole;
import com.aig.nge.entities.Tstatus;
import com.aig.nge.entities.Tsystem;
import com.aig.nge.entities.Ttable;
import com.aig.nge.entities.TtableAttribute;
import com.aig.nge.entities.TtableAttributeReference;
import com.aig.nge.entities.TusageType;
import com.aig.nge.helper.CommonServiceHelper;
import com.aig.nge.repository.TAssetTypeRepository;
import com.aig.nge.repository.TAttributeRepository;
import com.aig.nge.repository.TBlockTypeRepository;
import com.aig.nge.repository.TBranchRepository;
import com.aig.nge.repository.TBranchTypeRepository;
import com.aig.nge.repository.TComponentRelationTypeRepository;
import com.aig.nge.repository.TCurrencyRepository;
import com.aig.nge.repository.TErrorRepository;
import com.aig.nge.repository.TEventRepository;
import com.aig.nge.repository.TExposureLookupRepository;
import com.aig.nge.repository.TLegacyErrorRepository;
import com.aig.nge.repository.TLocationRepository;
import com.aig.nge.repository.TMarketableProductLocationRepository;
import com.aig.nge.repository.TMarketableProductRepository;
import com.aig.nge.repository.TPartyDetailsRepository;
import com.aig.nge.repository.TPartyProcessingRepository;
import com.aig.nge.repository.TPartyRepository;
import com.aig.nge.repository.TPartyTypeRepository;
import com.aig.nge.repository.TPolicyTypeRepository;
import com.aig.nge.repository.TProductStateRepository;
import com.aig.nge.repository.TProductTowerAttributeRepository;
import com.aig.nge.repository.TProductTowerAutoCloseRuleRepository;
import com.aig.nge.repository.TProductTowerDivsionRepository;
import com.aig.nge.repository.TProductTowerReasonRepository;
import com.aig.nge.repository.TProductTowerRepository;
import com.aig.nge.repository.TProductTowerTUWSubProductAssetTypeRepository;
import com.aig.nge.repository.TPropertyRepository;
import com.aig.nge.repository.TReasonRepository;
import com.aig.nge.repository.TReftabRepository;
import com.aig.nge.repository.TRelationTypeRepository;
import com.aig.nge.repository.TRoleRepository;
import com.aig.nge.repository.TStatusRepository;
import com.aig.nge.repository.TStatusTypeRepository;
import com.aig.nge.repository.TSystemRepository;
import com.aig.nge.repository.TTableAttributeReferenceRepository;
import com.aig.nge.repository.TTableAttributeRepository;
import com.aig.nge.repository.TTableRepository;
import com.aig.nge.repository.TassetTypeAttributeRepository;
import com.aig.nge.repository.TproductTowerAttributeUsageRepository;
import com.aig.nge.repository.TusageTypeRepository;
import com.aig.nge.utilities.NGEConstants;

@Repository
public class ReferenceDataDAO {

	private static final Logger logger = LogManager.getLogger(ReferenceDataDAO.class);
	@Autowired
	private TProductTowerRepository productTowerRepository;
	
	@Autowired
	private TPropertyRepository propertyRepository;
	
	@Autowired
	private TErrorRepository errorRepository;
	@Autowired
	private TRoleRepository roleRepository;
	
	@Autowired
	private TSystemRepository systemRepository;
	
	@Autowired
	private TStatusTypeRepository statusTypeRepository;
	
	@Autowired
	private TProductTowerAutoCloseRuleRepository productTowerAutoCloseRuleRepository;
	
	@Autowired
	private TTableRepository tableRepository;

	@Autowired
	private TusageTypeRepository usageTypeRepository;
	
	@Autowired
	private TRelationTypeRepository relationTypeRepository;
	
	@Autowired
	private TBranchRepository branchRepository;
	
	@Autowired
	private TBranchTypeRepository branchTypeRepository;
	
	@Autowired
	private TBlockTypeRepository blockTypeRepository;

	@Autowired
	private TMarketableProductRepository marketableProductRepository;
	
	@Autowired
	private TPartyProcessingRepository partyProcessingRepository;
	
	@Autowired
	private TCurrencyRepository currencyRepository;
	
	@Autowired
	private TPartyTypeRepository partyTypeRepository;
	
	@Autowired
	private TPolicyTypeRepository policyTypeRepository;
	
	@Autowired
	private TProductStateRepository productStateRepository;
	
	@Autowired
	private TProductTowerDivsionRepository productTowerDivsionRepository;
	
	@Autowired
	private TProductTowerReasonRepository productTowerReasonRepository; 
	
	@Autowired
	private TProductTowerTUWSubProductAssetTypeRepository productTowerTUWSubProductAssetTypeRepository; 
	
	@Autowired
	private TTableAttributeRepository tableAttributeRepository; 
	
	@Autowired
	private TTableAttributeReferenceRepository tableAttributeReferenceRepository;
	
	@Autowired
	private TAssetTypeRepository assetTypeRepository;
	
	@Autowired
	private TassetTypeAttributeRepository assetTypeAttributeRepository;
	
	@Autowired
	private TLocationRepository locationRepository;
	
	@Autowired
	private TStatusRepository statusRepository;
	
	@Autowired
	private TproductTowerAttributeUsageRepository productTowerAttributeUsageRepository;
	
	@Autowired
	private TReasonRepository reasonRepository;
	
	@Autowired
	private TProductTowerAttributeRepository productTowerAttributeRepository;
	
	@Autowired
	private TAttributeRepository attributeRepository; 
	
	@Autowired
	private TPartyRepository partyRepository; 

	@Autowired
	private TReftabRepository reftabRepository;
	
	@Autowired
	private SimpleCacheManager cacheMng;
	
	@Autowired
	private TLegacyErrorRepository legacyErrorRepository;
	
	@Autowired
	private TExposureLookupRepository exposureLookupRepository;
	
	@Autowired
	private TComponentRelationTypeRepository tComponentRelationTypeRepository;
	
	@Autowired
	private TMarketableProductLocationRepository marketableProductLocationRepository;
	
	/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
	@Autowired
	private CommonServiceHelper commonServiceHelper;
	/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
	
	public void putInCache(String cacheName, Object keyParameters, Object keyValues)
	{
		Cache cache = cacheMng.getCache(cacheName);
		SimpleValueWrapper svw = new SimpleValueWrapper(keyValues);
		cache.put(keyParameters, svw.get());
	}
	
	public Object getFromCache(String cacheName, Object keyParameters)
	{
		Cache cache = cacheMng.getCache(cacheName);
		SimpleValueWrapper keyValue = (SimpleValueWrapper) cache.get(keyParameters);
		if(keyValue != null)
		{
			return keyValue.get();
		}
		return null;
		
	}
	
	// July Release Item 2.6 - Underwriter Information Cache Evicted and Reload - Started

	//F46228-US243213-Enhance logs and remove unwanted exception-added rollback
	@Transactional(rollbackFor = Exception.class)
	public void loadUnderwriterDetails()
	{
		loadTparty();
	}
	// July Release Item 2.6 - Underwriter Information Cache Evicted and Reload - Completed
	
	//F46228-US243213-Enhance logs and remove unwanted exception-added rollback
	@Transactional(rollbackFor = Exception.class)
	public void loadAllReferenceData()
	{
		loadProductTower(); 
		loadTblockType();
		loadTbranch();
		loadTbranchType();
		loadTmarketableProduct();
		loadTpartyProcessing();
		loadTproductTowerAutoCloseRule();
		loadTProperty();
		loadTrelationType();
		loadTRole();
		loadTstatusType();
		loadTsystem();
		loadTtable();
		loadTusageType();
		loadTassetType();
		loadTassetTypeAttribute();
		loadTcurrency();
		loadTlocation();
		loadTpartyType();
		loadTpolicyType();
		loadTprdctTwrTuwSbprdctAstTyp();
		loadTproductState();
		loadTproductTowerAttributeUsage();
		loadTproductTowerDivision();
		loadTstatus();
		loadTtableAttribute();
		loadTtableAttributeReference();
		loadTreason();
		loadTproductTowerReason();
		loadTproductTowerAttribute();
		loadTattribute();
		loadTError();
		loadReftabData();
		loadTLegacyError();
		loadTExposureLookup();
		loadTComponentRelationType();
		loadTmarketableProductLocation();
		loadTparty();
	}

	@Transactional(rollbackFor = Exception.class)
	public void loadProductTower()
	{
		try {

			List<TproductTower> productTowerList = productTowerRepository.findAll();
			
			for(final TproductTower productTower : productTowerList)
			{
				List<TproductTower> productTowerList1 = new ArrayList<TproductTower>();
				try
				{
					productTowerList1.add(productTower);
					putInCache("TProductTowerRepository.findBySegmentCdAndSubSegmentCd",productTower.getTsegment1().getSegmentCd()+","+productTower.getTsegment2().getSegmentCd(), productTowerList1);
				}
				catch(Exception e)
				{
					/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
					if(commonServiceHelper.checkForRetryExceptions(e, 27, NGEConstants.CatchExceptionTypes.NO_THROW))
					{
						logger.error("checkForRetryExceptions returned true");
					}
					/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
					logger.error("Exception in inner loadProductTower"+e);
				}
			}

		} catch (Exception e) {
			/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
			if(commonServiceHelper.checkForRetryExceptions(e, 28, NGEConstants.CatchExceptionTypes.NO_THROW))
			{
				logger.error("checkForRetryExceptions returned true");
			}
			/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
			logger.error("Exception in loadProductTower"+e);
		}
	}

	@Async
	@Transactional(rollbackFor = Exception.class)
	public void loadReftabData()
	{
		try {

			List<TreftabMis780> reftabList = reftabRepository.findAll();
			
			for(final TreftabMis780 reftabData : reftabList)
			{
				try
				{
					putInCache("TReftabRepository.validateIssueCompanyCd",reftabData.getMis780CompCode(), reftabData);					
				}
				catch(Exception e)
				{
					/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
					if(commonServiceHelper.checkForRetryExceptions(e, 29, NGEConstants.CatchExceptionTypes.NO_THROW))
					{
						logger.error("checkForRetryExceptions returned true");
					}
					/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
					logger.error("Exception in inner loadReftabData"+e);
				}
			}

		} catch (Exception e) {
			/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
			if(commonServiceHelper.checkForRetryExceptions(e, 30, NGEConstants.CatchExceptionTypes.NO_THROW))
			{
				logger.error("checkForRetryExceptions returned true");
			}
			/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
			logger.error("Exception in loadReftabData"+e);
		}
	}

	@Transactional(rollbackFor = Exception.class)
	public void loadTError()
	{
		try {
			List<Terror> errorList= errorRepository.findAll();
			for(Terror error : errorList)
			{
				try
				{
					List<Terror> errorList1=new ArrayList<Terror>();
										
					if(error.getTsystem().getSystemShortNm().equalsIgnoreCase(NGEConstants.APPLICATION_ID_NGE))
					{
						errorList1.add(error);
						putInCache("TErrorRepository.getProperty",error.getTsystem().getSystemId()+","+error.getErrorCd(),errorList1);
					}
				}
				catch(Exception e)
				{
					/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
					if(commonServiceHelper.checkForRetryExceptions(e, 31, NGEConstants.CatchExceptionTypes.NO_THROW))
					{
						logger.error("checkForRetryExceptions returned true");
					}
					/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
					logger.error("Exception in inner loadTError"+e);
				}
			}
		} catch (Exception e) {
			/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
			if(commonServiceHelper.checkForRetryExceptions(e, 32, NGEConstants.CatchExceptionTypes.NO_THROW))
			{
				logger.error("checkForRetryExceptions returned true");
			}
			/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
			logger.error("Exception in loadTError"+e);
		}
	}

	@Transactional(rollbackFor = Exception.class)
	public void loadTProperty()
	{
		try {
			List<Tproperty> propertyList = propertyRepository.findAll();
			for(Tproperty property : propertyList)
			{
				try
				{
					List<Tproperty> propertyList1 = new ArrayList<Tproperty>();
					
					if(property.getTsystem().getSystemShortNm().equalsIgnoreCase(NGEConstants.APPLICATION_ID_NGE) && (property.getId().getEvironmentNm().equalsIgnoreCase(NGEConstants.ALL_REGION) 
							|| property.getId().getEvironmentNm().equalsIgnoreCase(System.getenv(NGEConstants.ENVIRONMENT_NAME).toUpperCase())))
					{
						propertyList1.add(property);
						putInCache("TPropertyRepository.getProperty",property.getTsystem().getSystemId()+","+property.getId().getPropertyNm()+","+property.getId().getEvironmentNm(),propertyList1);
					}
				}
				catch(Exception e)
				{
					/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
					if(commonServiceHelper.checkForRetryExceptions(e, 33, NGEConstants.CatchExceptionTypes.NO_THROW))
					{
						logger.error("checkForRetryExceptions returned true");
					}
					/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
					logger.error("Exception in inner loadTProperty"+e);
				}
			}
		} catch (Exception e) {
			/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
			if(commonServiceHelper.checkForRetryExceptions(e, 34, NGEConstants.CatchExceptionTypes.NO_THROW))
			{
				logger.error("checkForRetryExceptions returned true");
			}
			/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
			logger.error("Exception in loadTProperty"+e);
		}
	}

	@Transactional(rollbackFor = Exception.class)
	public void loadTRole()
	{
		try {
			List<Trole> roleList = roleRepository.findAll();
			for(Trole role : roleList)
			{
				try
				{
					putInCache("TRoleRepository.findByRoleNmIgnoreCase",role.getRoleNm(),role);
				}
				catch(Exception e)
				{
					/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
					if(commonServiceHelper.checkForRetryExceptions(e, 35, NGEConstants.CatchExceptionTypes.NO_THROW))
					{
						logger.error("checkForRetryExceptions returned true");
					}
					/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
					logger.error("Exception in inner loadTRole"+e);
				}
			}
		} catch (Exception e) {
			/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
			if(commonServiceHelper.checkForRetryExceptions(e, 36, NGEConstants.CatchExceptionTypes.NO_THROW))
			{
				logger.error("checkForRetryExceptions returned true");
			}
			/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
			logger.error("Exception in loadTRole"+e);
		}
	}

	@Transactional(rollbackFor = Exception.class)
	public void loadTsystem()
	{
		try {
			List<Tsystem> systemList = systemRepository.findAll();
			for(Tsystem system : systemList)
			{
				List<Tsystem> systemList1 = new ArrayList<Tsystem>();
				try
				{	
					systemList1.add(system);
					putInCache("TSystemRepository.findBySystemShortNm",system.getSystemShortNm(),systemList1);
					putInCache("TSystemRepository.findBySystemId",system.getSystemId(),systemList1);
				}
				catch(Exception e)
				{
					/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
					if(commonServiceHelper.checkForRetryExceptions(e, 37, NGEConstants.CatchExceptionTypes.NO_THROW))
					{
						logger.error("checkForRetryExceptions returned true");
					}
					/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
					logger.error("Exception in inner loadTsystem"+e);
				}
			}
		} catch (Exception e) {
			/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
			if(commonServiceHelper.checkForRetryExceptions(e, 38, NGEConstants.CatchExceptionTypes.NO_THROW))
			{
				logger.error("checkForRetryExceptions returned true");
			}
			/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
			logger.error("Exception in loadTsystem"+e);
		}
	}

	@Transactional(rollbackFor = Exception.class)
	public void loadTstatusType()
	{
		try
		{
			statusTypeRepository.findStatusType();
		}
		catch(Exception e)
		{
			/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
			if(commonServiceHelper.checkForRetryExceptions(e, 39, NGEConstants.CatchExceptionTypes.NO_THROW))
			{
				logger.error("checkForRetryExceptions returned true");
			}
			/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
			logger.error("Exception in inner loadTstatusType"+e);
		}
	}

	@Transactional(rollbackFor = Exception.class)
	public void loadTproductTowerAutoCloseRule()
	{
		try {
			List<TproductTowerAutoCloseRule> productTowerAutoCloseRuleList = productTowerAutoCloseRuleRepository.findAll();
			for(TproductTowerAutoCloseRule productTowerAutoCloseRule : productTowerAutoCloseRuleList)
			{
				List<TproductTowerAutoCloseRule> productTowerAutoCloseRuleList1 = new ArrayList<TproductTowerAutoCloseRule>();
				
				try
				{
					productTowerAutoCloseRuleList1.add(productTowerAutoCloseRule);
					
					putInCache("TProductTowerAutoCloseRuleRepository.findBySegmentCdAndSubSegmentCd",
							productTowerAutoCloseRule.getTproductTower().getTsegment1().getSegmentCd()+","+ 
							productTowerAutoCloseRule.getTproductTower().getTsegment2().getSegmentCd()+","+
							productTowerAutoCloseRule.getTstatus2().getStatusNm()+","+
							productTowerAutoCloseRule.getTstatus1().getStatusNm(),
							productTowerAutoCloseRule);
					
					putInCache("TProductTowerAutoCloseRuleRepository.findAutoCloseDaysNoByTowerID",
							productTowerAutoCloseRule.getTproductTower().getProductTowerId()+","+ 
							productTowerAutoCloseRule.getTstatus2().getStatusNm(),
							productTowerAutoCloseRuleList1);
				}
				catch(Exception e)
				{
					/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
					if(commonServiceHelper.checkForRetryExceptions(e, 40, NGEConstants.CatchExceptionTypes.NO_THROW))
					{
						logger.error("checkForRetryExceptions returned true");
					}
					/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
					logger.error("Exception in inner loadTproductTowerAutoCloseRule"+e);
				}
			}
		} catch (Exception e) {
			/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
			if(commonServiceHelper.checkForRetryExceptions(e, 41, NGEConstants.CatchExceptionTypes.NO_THROW))
			{
				logger.error("checkForRetryExceptions returned true");
			}
			/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
			logger.error("Exception in loadTproductTowerAutoCloseRule"+e);
		}
	}

	@Transactional(rollbackFor = Exception.class)
	public void loadTtable()
	{
		try {
			List<Ttable> tableList = tableRepository.findAll();
			for(Ttable table : tableList)
			{
				try
				{
					putInCache("TTableRepository.findByTableNm",table.getTableNm(),table);
				}
				catch(Exception e)
				{
					/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
					if(commonServiceHelper.checkForRetryExceptions(e, 42, NGEConstants.CatchExceptionTypes.NO_THROW))
					{
						logger.error("checkForRetryExceptions returned true");
					}
					/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
					logger.error("Exception in inner loadTtable"+e);
				}
			}
		} catch (Exception e) {
			/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
			if(commonServiceHelper.checkForRetryExceptions(e, 43, NGEConstants.CatchExceptionTypes.NO_THROW))
			{
				logger.error("checkForRetryExceptions returned true");
			}
			/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
			logger.error("Exception in loadTtable"+e);
		}
	}

	@Transactional(rollbackFor = Exception.class)
	public void loadTusageType()
	{
		try {
			List<TusageType> usageTypeList = usageTypeRepository.findAll();
			for(TusageType usageType : usageTypeList)
			{
				List<TusageType> usageTypeList1 = new ArrayList<TusageType>();
				try
				{
					usageTypeList1.add(usageType);
					putInCache("TusageTypeRepository.findByUsageTypeDs",usageType.getUsageTypeDs(),usageTypeList1);
				}
				catch(Exception e)
				{
					/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
					if(commonServiceHelper.checkForRetryExceptions(e, 44, NGEConstants.CatchExceptionTypes.NO_THROW))
					{
						logger.error("checkForRetryExceptions returned true");
					}
					/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
					logger.error("Exception in inner loadTusageType"+e);
				}
			}
		} catch (Exception e) {
			/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
			if(commonServiceHelper.checkForRetryExceptions(e, 45, NGEConstants.CatchExceptionTypes.NO_THROW))
			{
				logger.error("checkForRetryExceptions returned true");
			}
			/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
			logger.error("Exception in loadTusageType"+e);
		}
	}

	@Transactional(rollbackFor = Exception.class)
	public void loadTrelationType()
	{
		try {
			List<TrelationType> relationTypeList = relationTypeRepository.findAll();
			for(TrelationType relationType : relationTypeList)
			{
				List<TrelationType> relationTypeList1 = new ArrayList<TrelationType>();
				try
				{
					relationTypeList1.add(relationType);
					putInCache("TRelationTypeRepository.findByRelationTypeNm",relationType.getRelationTypeNm(),relationTypeList1);
				}
				catch(Exception e)
				{
					/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
					if(commonServiceHelper.checkForRetryExceptions(e, 46, NGEConstants.CatchExceptionTypes.NO_THROW))
					{
						logger.error("checkForRetryExceptions returned true");
					}
					/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
					logger.error("Exception in inner loadTrelationType"+e);
				}
			}
		} catch (Exception e) {
			/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
			if(commonServiceHelper.checkForRetryExceptions(e, 47, NGEConstants.CatchExceptionTypes.NO_THROW))
			{
				logger.error("checkForRetryExceptions returned true");
			}
			/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
			logger.error("Exception in loadTrelationType"+e);
		}
	}

	@Transactional(rollbackFor = Exception.class)
	public void loadTbranch()
	{
		try {
			List<Tbranch> branchList = branchRepository.findAll();
			for(Tbranch branch : branchList)
			{
				try
				{
					putInCache("TBranchRepository.findByBranchCdAndLocationCd",
							branch.getBranchCd().trim()+","+
							branch.getTlocation().getLocationCd()+","+
							branch.getTlocation().getTlocationType().getLocationTypeNm(),
							branch);
					
					putInCache("TBranchRepository.findByBranchCd",branch.getBranchCd().trim(),branch);
				}
				catch(Exception e)
				{
					/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
					if(commonServiceHelper.checkForRetryExceptions(e, 48, NGEConstants.CatchExceptionTypes.NO_THROW))
					{
						logger.error("checkForRetryExceptions returned true");
					}
					/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
					logger.error("Exception in inner loadTbranch"+e);
				}
			}
		} catch (Exception e) {
			/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
			if(commonServiceHelper.checkForRetryExceptions(e, 49, NGEConstants.CatchExceptionTypes.NO_THROW))
			{
				logger.error("checkForRetryExceptions returned true");
			}
			/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
			logger.error("Exception in loadTbranch"+e);
		}
	}

	@Transactional(rollbackFor = Exception.class)
	public void loadTbranchType()
	{
		try {
			List<TbranchType> branchTypeList = branchTypeRepository.findAll();
			for(TbranchType branchType : branchTypeList)
			{
				try
				{
					putInCache("TBranchTypeRepository.findByBranchTypeCd",branchType.getBranchTypeNm(),branchType);
				}
				catch(Exception e)
				{
					/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
					if(commonServiceHelper.checkForRetryExceptions(e, 50, NGEConstants.CatchExceptionTypes.NO_THROW))
					{
						logger.error("checkForRetryExceptions returned true");
					}
					/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
					logger.error("Exception in inner loadTbranchType"+e);
				}
			}
		} catch (Exception e) {
			/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
			if(commonServiceHelper.checkForRetryExceptions(e, 51, NGEConstants.CatchExceptionTypes.NO_THROW))
			{
				logger.error("checkForRetryExceptions returned true");
			}
			/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
			logger.error("Exception in loadTbranchType"+e);
		}
	}

	@Transactional(rollbackFor = Exception.class)
	public void loadTblockType()
	{
		try {
			List<TblockType> blockTypeList = blockTypeRepository.findAll();
			for(TblockType blockType : blockTypeList)
			{
				try
				{
					putInCache("TBlockTypeRepository.findByBlockTypeDs",blockType.getBlockTypeDs(),blockType);
				}
				catch(Exception e)
				{
					/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
					if(commonServiceHelper.checkForRetryExceptions(e, 52, NGEConstants.CatchExceptionTypes.NO_THROW))
					{
						logger.error("checkForRetryExceptions returned true");
					}
					/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
					logger.error("Exception in inner loadTblockType"+e);
				}
			}
		} catch (Exception e) {
			/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
			if(commonServiceHelper.checkForRetryExceptions(e, 53, NGEConstants.CatchExceptionTypes.NO_THROW))
			{
				logger.error("checkForRetryExceptions returned true");
			}
			/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
			logger.error("Exception in loadTblockType"+e);
		}
	}

	@Transactional(rollbackFor = Exception.class)
	public void loadTmarketableProduct()
	{
		try {
			List<TmarketableProduct> marketableProductList = marketableProductRepository.findAll();
			for(TmarketableProduct marketableProduct : marketableProductList)
			{
				try
				{
					putInCache("TMarketableProductRepository.findBySegmentCdAndSubSegmentCdAndMarketableProductCd",
							marketableProduct.getTproductTower().getTsegment1().getSegmentCd()+","+
							marketableProduct.getTproductTower().getTsegment2().getSegmentCd()+","+
							marketableProduct.getMarketableProductCd(),
							marketableProduct);
				}
				catch(Exception e)
				{
					/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
					if(commonServiceHelper.checkForRetryExceptions(e, 56, NGEConstants.CatchExceptionTypes.NO_THROW))
					{
						logger.error("checkForRetryExceptions returned true");
					}
					/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
					logger.error("Exception in inner loadTmarketableProduct"+e);
				}
			}
		} catch (Exception e) {
			/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
			if(commonServiceHelper.checkForRetryExceptions(e, 57, NGEConstants.CatchExceptionTypes.NO_THROW))
			{
				logger.error("checkForRetryExceptions returned true");
			}
			/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
			logger.error("Exception in loadTmarketableProduct"+e);
		}
	}

	@Transactional(rollbackFor = Exception.class)
	public void loadTpartyProcessing()
	{
		try {
			List<TpartyProcessing> partyProcessingList = partyProcessingRepository.findAll();
			for(TpartyProcessing partyProcessing : partyProcessingList)
			{
				try
				{					
					putInCache("TPartyProcessingRepository.findByPartyProcessingID",partyProcessing.getPartyProcessingDs(),partyProcessing);
				}
				catch(Exception e)
				{
					/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
					if(commonServiceHelper.checkForRetryExceptions(e, 58, NGEConstants.CatchExceptionTypes.NO_THROW))
					{
						logger.error("checkForRetryExceptions returned true");
					}
					/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
					logger.error("Exception in inner loadTpartyProcessing"+e);
				}
			}
		} catch (Exception e) {
			/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
			if(commonServiceHelper.checkForRetryExceptions(e, 59, NGEConstants.CatchExceptionTypes.NO_THROW))
			{
				logger.error("checkForRetryExceptions returned true");
			}
			/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
			logger.error("Exception in loadTpartyProcessing"+e);
		}
	}

	@Transactional(rollbackFor = Exception.class)
	public void loadTcurrency()
	{
		try {
			List<Tcurrency> currencyList = currencyRepository.findAll();
			for(Tcurrency currency : currencyList)
			{
				try
				{					
					putInCache("TCurrencyRepository.findByCurrencyCd",currency.getCurrencyCd(),currency);
					putInCache("TCurrencyRepository.findByCurrencyID",currency.getCurrencyId(),currency);
				}
				catch(Exception e)
				{
					/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
					if(commonServiceHelper.checkForRetryExceptions(e, 60, NGEConstants.CatchExceptionTypes.NO_THROW))
					{
						logger.error("checkForRetryExceptions returned true");
					}
					/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
					logger.error("Exception in inner loadTcurrency"+e);
				}
			}
		} catch (Exception e) {
			/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
			if(commonServiceHelper.checkForRetryExceptions(e, 61, NGEConstants.CatchExceptionTypes.NO_THROW))
			{
				logger.error("checkForRetryExceptions returned true");
			}
			/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
			logger.error("Exception in loadTcurrency"+e);
		}
	}

	@Transactional(rollbackFor = Exception.class)
	public void loadTpartyType()
	{
		try {
			List<TpartyType> partyTypeList = partyTypeRepository.findAll();
			for(TpartyType partyType : partyTypeList)
			{
				List<TpartyType> partyTypeList1 = new ArrayList<TpartyType>();
				try
				{	
					partyTypeList1.add(partyType);
					putInCache("TPartyTypeRepository.findByPartyTypeNm",partyType.getPartyTypeNm(),partyTypeList1);
				}
				catch(Exception e)
				{
					/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
					if(commonServiceHelper.checkForRetryExceptions(e, 62, NGEConstants.CatchExceptionTypes.NO_THROW))
					{
						logger.error("checkForRetryExceptions returned true");
					}
					/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
					logger.error("Exception in inner loadTcurrency"+e);
				}
			}
		} catch (Exception e) {
			/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
			if(commonServiceHelper.checkForRetryExceptions(e, 63, NGEConstants.CatchExceptionTypes.NO_THROW))
			{
				logger.error("checkForRetryExceptions returned true");
			}
			/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
			logger.error("Exception in loadTcurrency"+e);
		}
	}

	@Transactional(rollbackFor = Exception.class)
	public void loadTpolicyType()
	{
		try {
			List<TpolicyType> policyTypeList = policyTypeRepository.findAll();
			for(TpolicyType policyType : policyTypeList)
			{
				try
				{					
					putInCache("TPolicyTypeRepository.findByPolicyTypeNm",policyType.getPolicyTypeNm(),policyType);
				}
				catch(Exception e)
				{
					/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
					if(commonServiceHelper.checkForRetryExceptions(e, 64, NGEConstants.CatchExceptionTypes.NO_THROW))
					{
						logger.error("checkForRetryExceptions returned true");
					}
					/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
					logger.error("Exception in inner loadTpolicyType"+e);
				}
			}
		} catch (Exception e) {
			/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
			if(commonServiceHelper.checkForRetryExceptions(e, 65, NGEConstants.CatchExceptionTypes.NO_THROW))
			{
				logger.error("checkForRetryExceptions returned true");
			}
			/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
			logger.error("Exception in loadTpolicyType"+e);
		}
	}

	@Transactional(rollbackFor = Exception.class)
	public void loadTproductState()
	{
		try {
			List<TproductState> productStateList = productStateRepository.findAll();
			for(TproductState productState : productStateList)
			{
				try
				{					
					putInCache("TProductStateRepository.findByProductStateNm",productState.getProductStateNm(),productState);
				}
				catch(Exception e)
				{
					/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
					if(commonServiceHelper.checkForRetryExceptions(e, 66, NGEConstants.CatchExceptionTypes.NO_THROW))
					{
						logger.error("checkForRetryExceptions returned true");
					}
					/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
					logger.error("Exception in inner loadTproductState"+e);
				}
			}
		} catch (Exception e) {
			/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
			if(commonServiceHelper.checkForRetryExceptions(e, 67, NGEConstants.CatchExceptionTypes.NO_THROW))
			{
				logger.error("checkForRetryExceptions returned true");
			}
			/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
			logger.error("Exception in loadTproductState"+e);
		}
	}

	@Transactional(rollbackFor = Exception.class)
	public void loadTproductTowerDivision()
	{
		try {
			List<TproductTowerDivision> productTowerDivisionList = productTowerDivsionRepository.findAll();
			for(TproductTowerDivision productTowerDivision : productTowerDivisionList)
			{
				try
				{					
					putInCache("TProductTowerDivsionRepository.findProductTowerDivisionIDByDivisionNoAndTowerID",
							productTowerDivision.getTdivision().getDivisionNo()+","+productTowerDivision.getTproductTower().getProductTowerId(),
							productTowerDivision);
				}
				catch(Exception e)
				{
					/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
					if(commonServiceHelper.checkForRetryExceptions(e, 68, NGEConstants.CatchExceptionTypes.NO_THROW))
					{
						logger.error("checkForRetryExceptions returned true");
					}
					/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
					logger.error("Exception in inner loadTproductTowerDivision"+e);
				}
			}
		} catch (Exception e) {
			/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
			if(commonServiceHelper.checkForRetryExceptions(e, 69, NGEConstants.CatchExceptionTypes.NO_THROW))
			{
				logger.error("checkForRetryExceptions returned true");
			}
			/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
			logger.error("Exception in loadTproductTowerDivision"+e);
		}
	}

	@Transactional(rollbackFor = Exception.class)
	public void loadTproductTowerReason()
	{
		try {
			List<TproductTowerReason> productTowerReasonList = productTowerReasonRepository.findAll();
			for(TproductTowerReason productTowerReason : productTowerReasonList)
			{
				try
				{					
					putInCache("TProductTowerReasonRepository.findByProductTowerIdAndReasonId",
							productTowerReason.getId().getProductTowerId()+","+productTowerReason.getId().getReasonId(),
							productTowerReason);
				}
				catch(Exception e)
				{
					/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
					if(commonServiceHelper.checkForRetryExceptions(e, 70, NGEConstants.CatchExceptionTypes.NO_THROW))
					{
						logger.error("checkForRetryExceptions returned true");
					}
					/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
					logger.error("Exception in inner loadTproductTowerReason"+e);
				}
			}
		} catch (Exception e) {
			/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
			if(commonServiceHelper.checkForRetryExceptions(e, 71, NGEConstants.CatchExceptionTypes.NO_THROW))
			{
				logger.error("checkForRetryExceptions returned true");
			}
			/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
			logger.error("Exception in loadTproductTowerReason"+e);
		}
	}

	@Transactional(rollbackFor = Exception.class)
	public void loadTprdctTwrTuwSbprdctAstTyp()
	{
		try {
			List<TprdctTwrTuwSbprdctAstTyp> prdctTwrTuwSbprdctAstTypList = productTowerTUWSubProductAssetTypeRepository.findAll();
			for(TprdctTwrTuwSbprdctAstTyp prdctTwrTuwSbprdctAstTyp : prdctTwrTuwSbprdctAstTypList)
			{
				try
				{					
					putInCache("TProductTowerTUWSubProductAssetTypeRepository.validatePrdTwrSubPrdAstType",
							prdctTwrTuwSbprdctAstTyp.getId().getProductTowerId()+","+
							prdctTwrTuwSbprdctAstTyp.getId().getTuwSubProductId()+","+
							prdctTwrTuwSbprdctAstTyp.getId().getAssetTypeId(),
							prdctTwrTuwSbprdctAstTyp);
				}
				catch(Exception e)
				{
					/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
					if(commonServiceHelper.checkForRetryExceptions(e, 72, NGEConstants.CatchExceptionTypes.NO_THROW))
					{
						logger.error("checkForRetryExceptions returned true");
					}
					/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
					logger.error("Exception in inner loadTprdctTwrTuwSbprdctAstTyp"+e);
				}
			}
		} catch (Exception e) {
			/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
			if(commonServiceHelper.checkForRetryExceptions(e, 73, NGEConstants.CatchExceptionTypes.NO_THROW))
			{
				logger.error("checkForRetryExceptions returned true");
			}
			/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
			logger.error("Exception in loadTprdctTwrTuwSbprdctAstTyp"+e);
		}
	}

	@Transactional(rollbackFor = Exception.class)
	public void loadTtableAttribute()
	{
		try {
			List<TtableAttribute> tableAttributeList = tableAttributeRepository.findAll();
			List<Tattribute> attributeList = attributeRepository.findAll();
			
			for(TtableAttribute tableAttribute : tableAttributeList)
			{
				for(Tattribute attribute : attributeList)
				{
					List<TtableAttribute> tableAttributeList1 = new ArrayList<TtableAttribute>();
					
					try
					{	
						tableAttributeList1.add(tableAttribute);
						putInCache("TTableAttributeRepository.findByTableNmAndAttributeNm",
								tableAttribute.getId().getTableId()+","+
								attribute.getAttributeNm().toUpperCase(),
								tableAttribute);
						
						putInCache("TTableAttributeRepository.findByAttributeIDAndTableName",
								attribute.getAttributeId()+","+
								tableAttribute.getTtable().getTableNm(),
								tableAttributeList1);
					}
					catch(Exception e)
					{
						/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
						if(commonServiceHelper.checkForRetryExceptions(e, 74, NGEConstants.CatchExceptionTypes.NO_THROW))
						{
							logger.error("checkForRetryExceptions returned true");
						}
						/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
						logger.error("Exception in inner loadTtableAttribute"+e);
					}
				}
			}
		} catch (Exception e) {
			/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
			if(commonServiceHelper.checkForRetryExceptions(e, 75, NGEConstants.CatchExceptionTypes.NO_THROW))
			{
				logger.error("checkForRetryExceptions returned true");
			}
			/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
			logger.error("Exception in loadTtableAttribute"+e);
		}
	}

	@Async
	@Transactional(rollbackFor = Exception.class)
	public void loadTtableAttributeReference()
	{
		try {
			List<TtableAttributeReference> tableAttributeReferenceList = tableAttributeReferenceRepository.findAll();
			
			List<Ttable> tableList = tableRepository.findAll();
			List<Tattribute> attributeList = attributeRepository.findAll();
			
			
			for(TtableAttributeReference tableAttributeReference : tableAttributeReferenceList)
			{
					List<TtableAttributeReference> tableAttributeReferenceList1 = new ArrayList<TtableAttributeReference>();
					try
					{	
						tableAttributeReferenceList1.add(tableAttributeReference);
						
						for(Ttable table : tableList)
						{
							for(Tattribute attribute : attributeList)
							{
								List<TtableAttributeReference> tableAttributeReferenceList2 = new ArrayList<TtableAttributeReference>();
								
								if(tableAttributeReference.getId().getAttributeId() == attribute.getAttributeId()){
									
									if(tableAttributeReference.getId().getTableId() == table.getTableId()){
										
										List<TtableAttributeReference> existingValuesList = (List<TtableAttributeReference>) getFromCache("TTableAttributeReferenceRepository.getReferenceDataByTabeIdAndAttributeName", 
												table.getTableId()+","+
												attribute.getAttributeNm().toUpperCase());
										
										if(existingValuesList != null && existingValuesList.size()>0)
										{
											tableAttributeReferenceList2.addAll(existingValuesList);
											tableAttributeReferenceList2.add(tableAttributeReference);
										}
										else
										{
											tableAttributeReferenceList2.add(tableAttributeReference);
										}
										
										putInCache("TTableAttributeReferenceRepository.getReferenceDataByTabeIdAndAttributeName",
												table.getTableId()+","+
												attribute.getAttributeNm().toUpperCase(),
												tableAttributeReferenceList2);
										
									}
								}			
							}
						}
						
						putInCache("TTableAttributeReferenceRepository.getReferenceDataByReferenceValue",
								tableAttributeReference.getId().getTableId()+","+
								tableAttributeReference.getTtableAttribute().getTattribute().getAttributeNm().toUpperCase()+","+
								tableAttributeReference.getTattributeReference().getReferenceVal().toUpperCase(),
								tableAttributeReferenceList1);
					}
					catch(Exception e)
					{
						/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
						if(commonServiceHelper.checkForRetryExceptions(e, 76, NGEConstants.CatchExceptionTypes.NO_THROW))
						{
							logger.error("checkForRetryExceptions returned true");
						}
						/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
						logger.error("Exception in inner loadTtableAttributeReference"+e);
					}
				}
		} catch (Exception e) {
			/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
			if(commonServiceHelper.checkForRetryExceptions(e, 77, NGEConstants.CatchExceptionTypes.NO_THROW))
			{
				logger.error("checkForRetryExceptions returned true");
			}
			/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
			logger.error("Exception in loadTtableAttributeReference"+e);
		}
	}

	@Transactional(rollbackFor = Exception.class)
	public void loadTassetType()
	{
		try {
			List<TassetType> assetTypeList = assetTypeRepository.findAll();
			for(TassetType assetType : assetTypeList)
			{
				List<TassetType> assetTypeList1 = new ArrayList<TassetType>();
				try
				{		
					assetTypeList1.add(assetType);
					putInCache("TAssetTypeRepository.findByAssetTypeNmIgnoreCase",assetType.getAssetTypeNm(), assetTypeList1);
				}
				catch(Exception e)
				{
					/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
					if(commonServiceHelper.checkForRetryExceptions(e, 78, NGEConstants.CatchExceptionTypes.NO_THROW))
					{
						logger.error("checkForRetryExceptions returned true");
					}
					/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
					logger.error("Exception in inner loadTassetType"+e);
				}
			}
		} catch (Exception e) {
			/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
			if(commonServiceHelper.checkForRetryExceptions(e, 79, NGEConstants.CatchExceptionTypes.NO_THROW))
			{
				logger.error("checkForRetryExceptions returned true");
			}
			/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
			logger.error("Exception in loadTassetType"+e);
		}
	}

	@Transactional(rollbackFor = Exception.class)
	public void loadTassetTypeAttribute()
	{
		try {
			List<TassetTypeAttribute> assetTypeAttributeList = assetTypeAttributeRepository.findAll();
			for(TassetTypeAttribute assetTypeAttribute : assetTypeAttributeList)
			{
				List<TassetTypeAttribute> assetTypeAttributeList1 = new ArrayList<TassetTypeAttribute>();
				List<Short> assetTypeAttributeShort = new ArrayList<Short>();
				try
				{					
					assetTypeAttributeList1.add(assetTypeAttribute);
					assetTypeAttributeShort.add(assetTypeAttribute.getTattribute().getAttributeId());
					
					putInCache("TassetTypeAttributeRepository.validateAstTypeandAttribute",assetTypeAttribute.getId().getAssetTypeId()+","+assetTypeAttribute.getId().getAttributeId(), assetTypeAttributeList1);
					putInCache("TassetTypeAttributeRepository.getAssetTypeAttributes",assetTypeAttribute.getId().getAssetTypeId(), assetTypeAttributeList1);
					putInCache("TassetTypeAttributeRepository.getAssetTypeAttributesForAssetType",assetTypeAttribute.getTassetType().getAssetTypeNm(), assetTypeAttributeShort);
				}
				catch(Exception e)
				{
					/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
					if(commonServiceHelper.checkForRetryExceptions(e, 80, NGEConstants.CatchExceptionTypes.NO_THROW))
					{
						logger.error("checkForRetryExceptions returned true");
					}
					/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
					logger.error("Exception in inner loadTassetTypeAttribute"+e);
				}
			}
		} catch (Exception e) {
			/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
			if(commonServiceHelper.checkForRetryExceptions(e, 81, NGEConstants.CatchExceptionTypes.NO_THROW))
			{
				logger.error("checkForRetryExceptions returned true");
			}
			/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
			logger.error("Exception in loadTassetTypeAttribute"+e);
		}
	}

	@Transactional(rollbackFor = Exception.class)
	public void loadTlocation()
	{
		try {
			List<Tlocation> locationList = locationRepository.findAll();
			for(Tlocation location : locationList)
			{
				
				Set<Integer> geoLocationIdSet = new HashSet<Integer>();
				Set<Integer> geoLocationIdSet2 = new HashSet<Integer>();
				
				List<Tlocation> locationList1 = new ArrayList<Tlocation>();
				try
				{		
					locationList1.add(location);
					putInCache("TLocationRepository.findByCountryCdAndCountry",location.getLocationCd()+","+location.getTlocationType().getLocationTypeNm(), locationList1);
					putInCache("TLocationRepository.getByLocationCode",location.getLocationCd()+","+location.getTlocationType().getLocationTypeNm(), location);
					putInCache("TLocationRepository.getByLocationName",location.getLocationNm().toUpperCase()+","+location.getTlocationType().getLocationTypeNm().toUpperCase(), location);
					if(location.getTlocation() != null){
						putInCache("TLocationRepository.getISOCountryCd",location.getTlocation().getLocationCd()+","+location.getTlocation().getTlocationType().getLocationTypeNm(), location);
					}
					
					putInCache("TLocationRepository.getCountryByAlternateLocationCd",location.getAlternateLocationCd()+","+location.getTlocationType().getLocationTypeNm(), location);
					
					if(location.getDeletedIn().equalsIgnoreCase(NGEConstants.NO))
					{
					Set<Integer> existingValuesList = (Set<Integer>) getFromCache("TLocationRepository.getLocationIdByLocationType", 
							location.getTlocationType().getLocationTypeNm());
					
					if(existingValuesList != null && existingValuesList.size()>0)
					{
						geoLocationIdSet.addAll(existingValuesList);
						geoLocationIdSet.add(location.getGeographicLocationId());
					}
					else
					{
						geoLocationIdSet.add(location.getGeographicLocationId());
					}
					putInCache("TLocationRepository.getLocationIdByLocationType",location.getTlocationType().getLocationTypeNm(), geoLocationIdSet);
					}
					
					
					Set<Integer> existingValuesList2 = (Set<Integer>) getFromCache("TLocationRepository.getLocationIdByLocationTypeAndCountryCode", 
							location.getTlocationType().getLocationTypeNm()+","+location.getLocationCd());
					
					if(existingValuesList2 != null && existingValuesList2.size()>0)
					{
						geoLocationIdSet2.addAll(existingValuesList2);
						geoLocationIdSet2.add(location.getGeographicLocationId());
					}
					else
					{
						geoLocationIdSet2.add(location.getGeographicLocationId());
					}
					putInCache("TLocationRepository.getLocationIdByLocationTypeAndCountryCode",location.getTlocationType().getLocationTypeNm()+","+location.getLocationCd(), geoLocationIdSet2);
					
					putInCache("TLocationRepository.getLocationAndLocationTypeCombination",location.getLocationCd()+","+location.getTlocationType().getLocationTypeNm(), location);
				}
				catch(Exception e)
				{
					/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
					if(commonServiceHelper.checkForRetryExceptions(e, 82, NGEConstants.CatchExceptionTypes.NO_THROW))
					{
						logger.error("checkForRetryExceptions returned true");
					}
					/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
					logger.error("Exception in inner loadTlocation"+e);
				}
			}
		} catch (Exception e) {
			/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
			if(commonServiceHelper.checkForRetryExceptions(e, 83, NGEConstants.CatchExceptionTypes.NO_THROW))
			{
				logger.error("checkForRetryExceptions returned true");
			}
			/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
			logger.error("Exception in loadTlocation"+e);
		}
	}

	@Async
	@Transactional(rollbackFor = Exception.class)
	public void loadTExposureLookup()
	{
		try {
			List<TexposureLookup> exposureLookupList = exposureLookupRepository.findAll();
			for(TexposureLookup exposureLookup : exposureLookupList)
			{
				
				Set<Integer> countryLocationIdSet = new HashSet<Integer>();
				Set<Integer> countryLocationIdSet2 = new HashSet<Integer>();
				Set<Integer> countryLocationIdSet3 = new HashSet<Integer>();
				
				
				try
				{							
						
					Set<Integer> existingValuesList = (Set<Integer>) getFromCache("TExposureLookupRepository.getCountryCodesByRegionCode", 
							exposureLookup.getRegionCd());
					
					if(existingValuesList != null && existingValuesList.size()>0)
					{
						countryLocationIdSet.addAll(existingValuesList);
						countryLocationIdSet.add(exposureLookup.getCountryLocationId());
					}
					else
					{
						countryLocationIdSet.add(exposureLookup.getCountryLocationId());
					}
					putInCache("TExposureLookupRepository.getCountryCodesByRegionCode",exposureLookup.getRegionCd(), countryLocationIdSet);
					
					
					Set<Integer> existingValuesList2 = (Set<Integer>) getFromCache("TExposureLookupRepository.getCountryCodesBySubRegionCode", 
							exposureLookup.getSubRegionCd());
					
					if(existingValuesList2 != null && existingValuesList2.size()>0)
					{
						countryLocationIdSet2.addAll(existingValuesList2);
						countryLocationIdSet2.add(exposureLookup.getCountryLocationId());
					}
					else
					{
						countryLocationIdSet2.add(exposureLookup.getCountryLocationId());
					}
					putInCache("TExposureLookupRepository.getCountryCodesBySubRegionCode",exposureLookup.getSubRegionCd(), countryLocationIdSet2);
					
					
					Set<Integer> existingValuesList3 = (Set<Integer>) getFromCache("TExposureLookupRepository.getCountryCodesByGeoClusterCode", 
							exposureLookup.getGeoClusterCd());
					
					if(existingValuesList3 != null && existingValuesList3.size()>0)
					{
						countryLocationIdSet3.addAll(existingValuesList3);
						countryLocationIdSet3.add(exposureLookup.getCountryLocationId());
					}
					else
					{
						countryLocationIdSet3.add(exposureLookup.getCountryLocationId());
					}
					putInCache("TExposureLookupRepository.getCountryCodesByGeoClusterCode",exposureLookup.getGeoClusterCd(), countryLocationIdSet3);
					
				}
				catch(Exception e)
				{
					/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
					if(commonServiceHelper.checkForRetryExceptions(e, 84, NGEConstants.CatchExceptionTypes.NO_THROW))
					{
						logger.error("checkForRetryExceptions returned true");
					}
					/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
					logger.error("Exception in inner loadTExposureLookup"+e);
				}
			}
		} catch (Exception e) {
			logger.error("Exception in loadTExposureLookup"+e);
		}
	}

	@Transactional(rollbackFor = Exception.class)
	public void loadTstatus()
	{
		try {
			List<Tstatus> statusList = statusRepository.findAll();
			for(Tstatus status : statusList)
			{
				List<Tstatus> statusList1 = new ArrayList<Tstatus>();
				try
				{	
					statusList1.add(status);
					putInCache("TStatusRepository.findByStatusTypeNmAndStatusNm",status.getTstatusType().getStatusTypeNm()+","+status.getStatusNm(), statusList1);
					putInCache("TStatusRepository.findByStatusNm",status.getStatusNm(), status);
				}
				catch(Exception e)
				{
					/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
					if(commonServiceHelper.checkForRetryExceptions(e, 85, NGEConstants.CatchExceptionTypes.NO_THROW))
					{
						logger.error("checkForRetryExceptions returned true");
					}
					/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
					logger.error("Exception in inner loadTstatus"+e);
				}
			}
		} catch (Exception e) {
			/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
			if(commonServiceHelper.checkForRetryExceptions(e, 86, NGEConstants.CatchExceptionTypes.NO_THROW))
			{
				logger.error("checkForRetryExceptions returned true");
			}
			/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
			logger.error("Exception in loadTstatus"+e);
		}
	}

	@Transactional(rollbackFor = Exception.class)
	public void loadTproductTowerAttributeUsage()
	{
		try {
			List<TproductTowerAttributeUsage> productTowerAttributeUsageList = productTowerAttributeUsageRepository.findAll();
			for(TproductTowerAttributeUsage productTowerAttributeUsage : productTowerAttributeUsageList)
			{
				List<TproductTowerAttributeUsage> findAttributesForBlockingList = new ArrayList<TproductTowerAttributeUsage>();
				List<TproductTowerAttributeUsage> getODMRelatedAttributesList = new ArrayList<TproductTowerAttributeUsage>();
				List<Short> productTowerAttributeUsageShort = new ArrayList<Short>();
				
				try
				{
					
					List<TproductTowerAttributeUsage> existingValuesList = (List<TproductTowerAttributeUsage>) getFromCache("TproductTowerAttributeUsageRepository.findAttributesForBlocking", 
							productTowerAttributeUsage.getId().getProductTowerId()+","+
							productTowerAttributeUsage.getTusageType().getUsageTypeDs());
					
					if(existingValuesList != null && existingValuesList.size()>0)
					{
						findAttributesForBlockingList.addAll(existingValuesList);
						findAttributesForBlockingList.add(productTowerAttributeUsage);
					}
					else
					{
						findAttributesForBlockingList.add(productTowerAttributeUsage);
					}
					putInCache("TproductTowerAttributeUsageRepository.findAttributesForBlocking",
									productTowerAttributeUsage.getId().getProductTowerId()+","+
									productTowerAttributeUsage.getTusageType().getUsageTypeDs(), 
									findAttributesForBlockingList);
					
					// findAttributesForBatch - Implementation					
					List<Short> existingBatchAttributesList = (List<Short>) getFromCache("TproductTowerAttributeUsageRepository.findAttributesForBatch", 
							productTowerAttributeUsage.getId().getProductTowerId()+","+
							productTowerAttributeUsage.getId().getTableId()+","+
							productTowerAttributeUsage.getTusageType().getUsageTypeDs());
					
					if(existingBatchAttributesList != null && existingBatchAttributesList.size()>0)
					{
						for(Short existingBatchAttribute : existingBatchAttributesList){
							
							productTowerAttributeUsageShort.add(existingBatchAttribute);
						}
						productTowerAttributeUsageShort.add(productTowerAttributeUsage.getId().getAttributeId());
					}
					else
					{
						productTowerAttributeUsageShort.add(productTowerAttributeUsage.getId().getAttributeId());
					}
					
					putInCache("TproductTowerAttributeUsageRepository.findAttributesForBatch",
									productTowerAttributeUsage.getId().getProductTowerId()+","+
									productTowerAttributeUsage.getId().getTableId()+","+
									productTowerAttributeUsage.getTusageType().getUsageTypeDs(), 
									productTowerAttributeUsageShort);
					
					List<TproductTowerAttributeUsage> existingValuesODMRelatedAttributesList = (List<TproductTowerAttributeUsage>) getFromCache("TproductTowerAttributeUsageRepository.getODMRelatedAttributes", 
							productTowerAttributeUsage.getId().getProductTowerId()+","+
									productTowerAttributeUsage.getTproductTowerAttribute().getTtableAttribute().getTtable().getTableNm()+","+
									productTowerAttributeUsage.getTproductTowerAttribute().getTattribute().getAttributeNm().toUpperCase()+","+
									productTowerAttributeUsage.getTusageType().getUsageTypeDs());
					
					if(existingValuesODMRelatedAttributesList != null && existingValuesODMRelatedAttributesList.size()>0)
					{
						getODMRelatedAttributesList.addAll(existingValuesODMRelatedAttributesList);
						getODMRelatedAttributesList.add(productTowerAttributeUsage);
					}
					else
					{
						getODMRelatedAttributesList.add(productTowerAttributeUsage);
					}
					
					putInCache("TproductTowerAttributeUsageRepository.getODMRelatedAttributes",
									productTowerAttributeUsage.getId().getProductTowerId()+","+
									productTowerAttributeUsage.getTproductTowerAttribute().getTtableAttribute().getTtable().getTableNm()+","+
									productTowerAttributeUsage.getTproductTowerAttribute().getTattribute().getAttributeNm().toUpperCase()+","+
									productTowerAttributeUsage.getTusageType().getUsageTypeDs(), 
									getODMRelatedAttributesList);
				}
				catch(Exception e)
				{
					/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
					if(commonServiceHelper.checkForRetryExceptions(e, 87, NGEConstants.CatchExceptionTypes.NO_THROW))
					{
						logger.error("checkForRetryExceptions returned true");
					}
					/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
					logger.error("Exception in inner loadTproductTowerAttributeUsage"+e);
				}
			}
		} catch (Exception e) {
			/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
			if(commonServiceHelper.checkForRetryExceptions(e, 88, NGEConstants.CatchExceptionTypes.NO_THROW))
			{
				logger.error("checkForRetryExceptions returned true");
			}
			/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
			logger.error("Exception in loadTproductTowerAttributeUsage"+e);
		}
	}

	@Transactional(rollbackFor = Exception.class)
	public void loadTreason()
	{
		try {
			List<Treason> reasonList = reasonRepository.findAll();
			for(Treason reason : reasonList)
			{
				try
				{					
					putInCache("TReasonRepository.findByReasonTypeIdAndReasonNm",
									reason.getTreasonType().getReasonTypeNm()+","+
									reason.getReasonNm(), 
									reason);
					
					putInCache("TReasonRepository.findByReasonNm", reason.getReasonNm(), reason);
					
					putInCache("TReasonRepository.findByReasonDs", reason.getReasonDs(), reason);
				}
				catch(Exception e)
				{
					/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
					if(commonServiceHelper.checkForRetryExceptions(e, 89, NGEConstants.CatchExceptionTypes.NO_THROW))
					{
						logger.error("checkForRetryExceptions returned true");
					}
					/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
					logger.error("Exception in inner loadTreason"+e);
				}
			}
		} catch (Exception e) {
			/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
			if(commonServiceHelper.checkForRetryExceptions(e, 90, NGEConstants.CatchExceptionTypes.NO_THROW))
			{
				logger.error("checkForRetryExceptions returned true");
			}
			/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
			logger.error("Exception in loadTreason"+e);
		}
	}

	@Transactional(rollbackFor = Exception.class)
	public void loadTproductTowerAttribute()
	{
		try {
			List<TproductTowerAttribute> productTowerAttributeList = productTowerAttributeRepository.findAll();
			
			for(TproductTowerAttribute productTowerAttribute : productTowerAttributeList)
			{
				List<TproductTowerAttribute> productTowerAttributeList1 = new ArrayList<TproductTowerAttribute>();
				try
				{			
					productTowerAttributeList1.add(productTowerAttribute);
					
					putInCache("TProductTowerAttributeRepository.findByAttributeNameAndProdTowerID",
							productTowerAttribute.getId().getAttributeId()+","+
							productTowerAttribute.getId().getProductTowerId(), 
							productTowerAttributeList1);
					
					putInCache("TProductTowerAttributeRepository.findMandatoryAttributesByAttributeNameAndProdTowerID", productTowerAttribute.getId().getProductTowerId(), productTowerAttributeList1);
					
					putInCache("TProductTowerAttributeRepository.findByProdTowerIdAndTableId", 
							productTowerAttribute.getId().getProductTowerId()+","+
							productTowerAttribute.getId().getTableId()+","+
							productTowerAttribute.getDeletedIn()+","+
							productTowerAttribute.getMandatoryIn(),
							productTowerAttributeList1);
					
					putInCache("TProductTowerAttributeRepository.findByProdTowerIdAndTableIdAndAssetId", 
							productTowerAttribute.getId().getProductTowerId()+","+
							productTowerAttribute.getId().getTableId()+","+
							productTowerAttribute.getDeletedIn()+","+
							productTowerAttribute.getTattribute().getAttributeId(),
							productTowerAttributeList1);
					
					putInCache("TProductTowerAttributeRepository.findByProdTowerAttributeId", 
							productTowerAttribute.getId().getProductTowerId()+","+
							productTowerAttribute.getId().getTableId()+","+
							productTowerAttribute.getDeletedIn()+","+
							productTowerAttribute.getTattribute().getAttributeNm().toUpperCase(),
							productTowerAttributeList1);
				}
				catch(Exception e)
				{
					/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
					if(commonServiceHelper.checkForRetryExceptions(e, 91, NGEConstants.CatchExceptionTypes.NO_THROW))
					{
						logger.error("checkForRetryExceptions returned true");
					}
					/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
					logger.error("Exception in inner loadTproductTowerAttribute"+e);
				}
			}
		} catch (Exception e) {
			/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
			if(commonServiceHelper.checkForRetryExceptions(e, 92, NGEConstants.CatchExceptionTypes.NO_THROW))
			{
				logger.error("checkForRetryExceptions returned true");
			}
			/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
			logger.error("Exception in loadTproductTowerAttribute"+e);
		}
	}

	@Transactional(rollbackFor = Exception.class)
	public void loadTattribute()
	{
		try {
			List<Tattribute> attributeList = attributeRepository.findAll();
			for(Tattribute attribute : attributeList)
			{
				try
				{					
					putInCache("TAttributeRepository.findByAttributeName", attribute.getAttributeNm().toUpperCase(), attribute);
					
					putInCache("TAttributeRepository.getAttributeNm", attribute.getAttributeId(), attribute);
				}
				catch(Exception e)
				{
					/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
					if(commonServiceHelper.checkForRetryExceptions(e, 93, NGEConstants.CatchExceptionTypes.NO_THROW))
					{
						logger.error("checkForRetryExceptions returned true");
					}
					/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
					logger.error("Exception in inner loadTattribute"+e);
				}
			}
		} catch (Exception e) {
			/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
			if(commonServiceHelper.checkForRetryExceptions(e, 94, NGEConstants.CatchExceptionTypes.NO_THROW))
			{
				logger.error("checkForRetryExceptions returned true");
			}
			/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
			logger.error("Exception in loadTattribute"+e);
		}
	}

	@Async
	@Transactional(rollbackFor = Exception.class)
	public void loadTparty()
	{
		try {
			List<Tparty> partyList = partyRepository.getAllUnderwriterParty(NGEConstants.PartyType.UNDERWRITER);
			for(Tparty party : partyList)
			{
				try
				{					
					putInCache("PartyDAO.getUnderwriterParty", party.getPartyNo()+","+party.getTpartyType().getPartyTypeNm(), party);
				}
				catch(Exception e)
				{
					/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
					if(commonServiceHelper.checkForRetryExceptions(e, 95, NGEConstants.CatchExceptionTypes.NO_THROW))
					{
						logger.error("checkForRetryExceptions returned true");
					}
					/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
					logger.error("Exception in inner loadTparty"+e);
				}
			}
		} catch (Exception e) {
			/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
			if(commonServiceHelper.checkForRetryExceptions(e, 96, NGEConstants.CatchExceptionTypes.NO_THROW))
			{
				logger.error("checkForRetryExceptions returned true");
			}
			/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
			logger.error("Exception in loadTparty"+e);
		}
	}

	@Async
	@Transactional(rollbackFor = Exception.class)
	public void loadTLegacyError()
	{
		try {
			List<TlegacyError> errorList= legacyErrorRepository.findAll();
			for(TlegacyError error : errorList)
			{
				try
				{
					List<TlegacyError> errorList1=new ArrayList<TlegacyError>();
						errorList1.add(error);
						putInCache("TLegacyErrorRepository.getlegacyError",error.getUwSystemId()+","+error.getLegacyErrorCd(),errorList1);
				}
				catch(Exception e)
				{
					/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
					if(commonServiceHelper.checkForRetryExceptions(e, 101, NGEConstants.CatchExceptionTypes.NO_THROW))
					{
						logger.error("checkForRetryExceptions returned true");
					}
					/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
					logger.error("Exception in inner loadTLegacyError"+e);
				}
			}
		} catch (Exception e) {
			/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
			if(commonServiceHelper.checkForRetryExceptions(e, 102, NGEConstants.CatchExceptionTypes.NO_THROW))
			{
				logger.error("checkForRetryExceptions returned true");
			}
			/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
			logger.error("Exception in loadTLegacyError"+e);
		}
	}

	@Transactional(rollbackFor = Exception.class)
	public void loadTComponentRelationType()
	{
		try {
			List<TcomponentRelationType> componentRelationTypeList = tComponentRelationTypeRepository.findAll();
			for(TcomponentRelationType componentRelationType : componentRelationTypeList)
			{
				List<TcomponentRelationType> componentRelationTypeList1 = new ArrayList<TcomponentRelationType>();
				try
				{
					componentRelationTypeList1.add(componentRelationType);
					putInCache("TComponentRelationTypeRepository.findByRelationTypeNm",componentRelationType.getRelationTypeNm(),componentRelationTypeList1);
				}
				catch(Exception e)
				{
					/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
					if(commonServiceHelper.checkForRetryExceptions(e, 103, NGEConstants.CatchExceptionTypes.NO_THROW))
					{
						logger.error("checkForRetryExceptions returned true");
					}
					/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
					logger.error("Exception in inner loadTComponentRelationType"+e);
				}
			}
		} catch (Exception e) {
			/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
			if(commonServiceHelper.checkForRetryExceptions(e, 104, NGEConstants.CatchExceptionTypes.NO_THROW))
			{
				logger.error("checkForRetryExceptions returned true");
			}
			/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
			logger.error("Exception in loadTComponentRelationType"+e);
		}
	}
	
	/* April 2017 Maintenance Release 2.4 - Move AIG Image from DYNA Cache to Spring Cache - Starts */
	@Transactional(rollbackFor = Exception.class)
	public void loadAIGLogo(FileDataSource fds)
	{
		try {
				if(fds != null){
					putInCache("ReferenceDataController.getAIGImage", NGEConstants.AIG_LOGO, fds);
				}			
			
		} catch (Exception e) {
			/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
			if(commonServiceHelper.checkForRetryExceptions(e, 105, NGEConstants.CatchExceptionTypes.NO_THROW))
			{
				logger.error("checkForRetryExceptions returned true");
			}
			/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
			logger.error("Exception in loadAIGLogo"+e);
		}
	}
	/* April 2017 Maintenance Release 2.4 - Move AIG Image from DYNA Cache to Spring Cache - Ends */

	/*Feb 27, 2018. NGE-AIQ Performance fixes - Starts*/
	@Transactional(rollbackFor = Exception.class)
	public void loadTmarketableProductLocation()
	{
		try {
			List<TmarketableProductLocation> marketableProductList = marketableProductLocationRepository.findAll();
			for(TmarketableProductLocation marketableProduct : marketableProductList)
			{
				try
				{
					putInCache("TMarketableProductLocationRepository.getMarketableProdLocationCombination",
							marketableProduct.getTmarketableProduct().getMarketableProductId()+","+
							marketableProduct.getTlocation().getGeographicLocationId(),
							marketableProduct);
				}
				catch(Exception e)
				{
					/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
					if(commonServiceHelper.checkForRetryExceptions(e, 106, NGEConstants.CatchExceptionTypes.NO_THROW))
					{
						logger.error("checkForRetryExceptions returned true");
					}
					/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
					logger.error("Exception in inner loadTmarketableProduct"+e);
				}
			}
		} catch (Exception e) {
			/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
			if(commonServiceHelper.checkForRetryExceptions(e, 107, NGEConstants.CatchExceptionTypes.NO_THROW))
			{
				logger.error("checkForRetryExceptions returned true");
			}
			/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
			logger.error("Exception in loadTmarketableProduct"+e);
		}
	}
	/*Feb 27, 2018. NGE-AIQ Performance fixes - Ends*/
}
