package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.text.DecimalFormat;
import java.math.BigDecimal;
import java.util.Set;


/**
 * The persistent class for the TTICKER_FEED database table.
 * 
 */
@Entity
@Table(name="TTICKER_FEED")
public class TtickerFeed implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="FEED_ID")
	private short feedId;

	@Column(name="CREATE_TS")
	private Timestamp createTs;

	@Column(name="CREATE_USER_ID")
	private String createUserId;

	@Column(name="DELETED_IN")
	private String deletedIn;

	@Column(name="FEED_DS")
	private String feedDs;

	@Column(name="FEED_NM")
	private String feedNm;

	@Column(name="MINIMUM_PREMIUM_AM")
	private BigDecimal minimumPremiumAm;

	@Column(name="SEGMENT_CD")
	private String segmentCd;

	@Column(name="UPDATE_TS")
	private Timestamp updateTs;

	@Column(name="UPDATE_USER_ID")
	private String updateUserId;

	//bi-directional many-to-one association to TtickerDivisionProduct
	@OneToMany(mappedBy="ttickerFeed")
	private Set<TtickerDivisionProduct> ttickerDivisionProducts;

    public TtickerFeed() {
    }

	public short getFeedId() {
		return this.feedId;
	}

	public void setFeedId(short feedId) {
		this.feedId = feedId;
	}

	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public String getDeletedIn() {
		return this.deletedIn;
	}

	public void setDeletedIn(String deletedIn) {
		this.deletedIn = deletedIn;
	}

	public String getFeedDs() {
		return this.feedDs;
	}

	public void setFeedDs(String feedDs) {
		this.feedDs = feedDs;
	}

	public String getFeedNm() {
		return this.feedNm;
	}

	public void setFeedNm(String feedNm) {
		this.feedNm = feedNm;
	}

	public BigDecimal getMinimumPremiumAm() {
		//return this.minimumPremiumAm;
		/* exadata changes - formatting the decimal field */
		if(this.minimumPremiumAm != null){
			DecimalFormat df = new DecimalFormat("0.000000");
		    BigDecimal formattedAm = new BigDecimal(df.format(this.minimumPremiumAm));	
		    return formattedAm;
		}else{
			return this.minimumPremiumAm;
		}
		
	}

	public void setMinimumPremiumAm(BigDecimal minimumPremiumAm) {
		this.minimumPremiumAm = minimumPremiumAm;
	}

	public String getSegmentCd() {
		return this.segmentCd;
	}

	public void setSegmentCd(String segmentCd) {
		this.segmentCd = segmentCd;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public Set<TtickerDivisionProduct> getTtickerDivisionProducts() {
		return this.ttickerDivisionProducts;
	}

	public void setTtickerDivisionProducts(Set<TtickerDivisionProduct> ttickerDivisionProducts) {
		this.ttickerDivisionProducts = ttickerDivisionProducts;
	}
	
}