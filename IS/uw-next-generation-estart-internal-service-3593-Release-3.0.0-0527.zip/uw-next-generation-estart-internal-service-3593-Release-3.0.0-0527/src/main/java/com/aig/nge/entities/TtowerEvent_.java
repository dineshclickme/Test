package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-02-24T11:59:50.415+0530")
@StaticMetamodel(TtowerEvent.class)
public class TtowerEvent_ {
	public static volatile SingularAttribute<TtowerEvent, TtowerEventPK> id;
	public static volatile SingularAttribute<TtowerEvent, Timestamp> createTs;
	public static volatile SingularAttribute<TtowerEvent, String> createUserId;
	public static volatile SingularAttribute<TtowerEvent, Timestamp> updateTs;
	public static volatile SingularAttribute<TtowerEvent, String> updateUserId;
	public static volatile SingularAttribute<TtowerEvent, Tattribute> tattribute;
	public static volatile SingularAttribute<TtowerEvent, Tevent> tevent;
	public static volatile SingularAttribute<TtowerEvent, TproductTower> tproductTower;
}
