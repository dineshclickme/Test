package com.aig.nge.entities;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-02-19T16:13:04.918+0530")
@StaticMetamodel(TtransactionComponentAssetPK.class)
public class TtransactionComponentAssetPK_ {
	public static volatile SingularAttribute<TtransactionComponentAssetPK, String> transactionComponentId;
	public static volatile SingularAttribute<TtransactionComponentAssetPK, Integer> assetId;
}
