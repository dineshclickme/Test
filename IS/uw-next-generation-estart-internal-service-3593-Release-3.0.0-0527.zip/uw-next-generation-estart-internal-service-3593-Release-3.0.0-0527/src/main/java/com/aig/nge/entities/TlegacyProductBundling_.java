package com.aig.nge.entities;

import java.sql.Timestamp;
import java.util.Date;
import javax.annotation.Generated;
import javax.persistence.metamodel.SetAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-04-15T15:31:47.025+0530")
@StaticMetamodel(TlegacyProductBundling.class)
public class TlegacyProductBundling_ {
	public static volatile SingularAttribute<TlegacyProductBundling, TlegacyProductBundlingPK> id;
	public static volatile SingularAttribute<TlegacyProductBundling, String> createdById;
	public static volatile SingularAttribute<TlegacyProductBundling, Date> enteredDt;
	public static volatile SingularAttribute<TlegacyProductBundling, Timestamp> lastUpdtTs;
	public static volatile SingularAttribute<TlegacyProductBundling, String> lastUpdtUserId;
	public static volatile SingularAttribute<TlegacyProductBundling, String> mndtryInBundlIn;
	public static volatile SingularAttribute<TlegacyProductBundling, Date> prdBndlgEfctvDt;
	public static volatile SingularAttribute<TlegacyProductBundling, Date> prdBndlgXprtnDt;
	public static volatile SingularAttribute<TlegacyProductBundling, String> productionIn;
	public static volatile SingularAttribute<TlegacyProductBundling, TlegacyProduct> tlegacyProduct1;
	public static volatile SingularAttribute<TlegacyProductBundling, TlegacyProduct> tlegacyProduct2;
	public static volatile SetAttribute<TlegacyProductBundling, TlegacyTrnsctnCmpntXtensn> tlegacyTrnsctnCmpntXtensns;
}
