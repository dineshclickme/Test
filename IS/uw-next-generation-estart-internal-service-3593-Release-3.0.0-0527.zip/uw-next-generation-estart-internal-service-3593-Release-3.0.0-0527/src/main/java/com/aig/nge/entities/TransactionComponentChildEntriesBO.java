package com.aig.nge.entities;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.StringTokenizer;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityResult;
import javax.persistence.FieldResult;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.NamedNativeQuery;
import javax.persistence.SqlResultSetMapping;

import com.aig.nge.utilities.NGEConstants;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@Entity
@SqlResultSetMapping(name = "DataMapping", 
	entities = {
		@EntityResult(entityClass = TransactionComponentChildEntriesBO.class, fields = {
			@FieldResult(name = "transactionComponentId", column = "TRANSACTION_COMPONENT_ID")
			})})

@NamedNativeQuery(name="TransactionComponentChildEntriesBO.fetchTransactionComponentChildData",
		query="SELECT    "+
				"				 cmp.TRANSACTION_COMPONENT_ID as TRANSACTION_COMPONENT_ID,   "+
				"				   fn_string_agg(   "+
				"				   CASE    "+
				"						WHEN statType.STATUS_TYPE_NM is not NULL and stat.STATUS_ID is not NULL THEN   "+
				"						  statType.STATUS_TYPE_NM || '|' || stat.STATUS_ID   "+
				"						ELSE   "+
				"						  NULL   "+
				"						END) AS STATUS_ID,   "+
				"				   fn_string_agg(   "+
				"				   CASE    "+
				"						WHEN atrb.ATTRIBUTE_ID is not NULL AND atrb.ATTRIBUTE_VAL is not NULL THEN   "+
				"						  atrb.ATTRIBUTE_ID || '|' || atrb.ATTRIBUTE_VAL   "+
				"						ELSE   "+
				"						  NULL   "+
				"						END) AS ATTRIBUTE_DETAILS,   "+
				"					fn_string_agg(   "+
				"				    CASE   "+
				"						WHEN ass.ASSET_ID is not null and ass.ASSET_DS is not null and ast.ASSET_TYPE_NM is not null THEN   "+
				"						  ass.ASSET_ID || '|' || ass.ASSET_DS || '|' || ast.ASSET_TYPE_NM   "+
				"						ELSE   "+
				"						  NULL   "+
				"					  END) AS ASSET_DETAILS,   "+
				"					fn_string_agg(   "+
				"				    CASE    "+
				"						  WHEN ass.ASSET_ID is not null and assAtt.ATTRIBUTE_ID is NOT NULL and assAtt.ATTRIBUTE_VAL is NOT NULL THEN   "+
				"							ass.ASSET_ID || '|' || assAtt.ATTRIBUTE_ID || '|' || assAtt.ATTRIBUTE_VAL   "+
				"						  ELSE   "+
				"							NULL   "+
				"						  END) AS ASSET_ATTRIBUTE_DETAILS,   "+
				"					fn_string_agg(    "+
				"					CASE    "+
				"						WHEN branchType.BRANCH_TYPE_NM is not NULL and branch.BRANCH_ID is not NULL THEN   "+
				"						  branchType.BRANCH_TYPE_NM || '|' || branch.BRANCH_ID   "+
				"						ELSE   "+
				"						  NULL   "+
				"						END) AS BRANCH_ID,   "+
				"					fn_string_agg(    "+
				"					CASE    "+
				"						WHEN rolet.ROLE_NM is not NULL and party.PARTY_NO is not NULL and cmptpartytype.PARTY_TYPE_NM is not null   "+
				"						AND COALESCE(cmpAcc.ORGANIZATION_NM,cmpShellAcc.ORGANIZATION_NM) is not null   "+
				"						AND COALESCE(cmpUltPty.PARTY_NO,party.PARTY_NO) is not null THEN   "+
				"						  rolet.ROLE_NM || '|' || party.PARTY_NO || '|' || cmptpartytype.PARTY_TYPE_NM ||  '|' || "+
				"						  COALESCE(cmpAcc.ORGANIZATION_NM,cmpShellAcc.ORGANIZATION_NM) ||  '|' || "+
				"						  COALESCE(cmpUltPty.PARTY_NO,party.PARTY_NO) ||  '|' || "+
				"						  COALESCE(cmpUltRelType.RELATION_TYPE_NM,'NA')   "+
				"						ELSE   "+
				"						  NULL   "+
				"						END) AS CMPNENT_ADNT_PRTY_DTLS,   "+
				"					fn_string_agg(    "+
				"					CASE    "+
				"						  WHEN cmprelation.TRANSACTION_ID is not NULL and cmprelation.TRANSACTION_COMPONENT_ID is not NULL    "+
				"						  AND cmprelationtype.RELATION_TYPE_NM is not null THEN   "+
				"							cmprelation.TRANSACTION_ID || '|' || cmprelation.TRANSACTION_COMPONENT_ID || '|' || cmprelationtype.RELATION_TYPE_NM   "+
				"						  ELSE   "+
				"							NULL   "+
				"						  END) AS RELATED_TRANSACTION_ID,   "+
				"					fn_string_agg(    "+
				"					CASE    "+
				"						WHEN renewedPrdrelation.TRANSACTION_ID is not NULL and renewedPrdrelation.TRANSACTION_COMPONENT_ID is not null    "+
				"						AND renewedPrdrelationtype.RELATION_TYPE_NM is not null THEN   "+
				"						  renewedPrdrelation.TRANSACTION_ID || '|' || renewedPrdrelation.TRANSACTION_COMPONENT_ID || '|' || renewedPrdrelationtype.RELATION_TYPE_NM   "+
				"						ELSE   "+
				"						  NULL   "+
				"						END) AS IS_RENEWED_CHECK,   "+
				"					fn_string_agg(    "+
				"							sbmn.SUBMISSION_NO) AS SUBMISSION_NO,   "+
				"					fn_string_agg(    "+
				"						dnbparty.PARTY_NO) AS DNBNO,   "+
				"					fn_string_agg(    "+
				"					 CASE   "+
				"					  WHEN rptype.RELATION_TYPE_NM is not null and relatedParty.PARTY_NO is not null THEN   "+
				"						rptype.RELATION_TYPE_NM || '|' || relatedParty.PARTY_NO   "+
				"					  ELSE   "+
				"						NULL   "+
				"					  END) AS RELATED_PARTY_DETAILS,   "+
				"					fn_string_agg(    "+
				"					  CASE    "+
				"						  WHEN txnrolet.ROLE_NM is not null and txntparty.PARTY_NO is not null and txntpartytype.PARTY_TYPE_NM is not null   "+
				"						  AND COALESCE(txnUltPty.PARTY_NO, txntparty.PARTY_NO) is not null THEN   "+
				"							txnrolet.ROLE_NM || '|' || txntparty.PARTY_NO || '|' || txntpartytype.PARTY_TYPE_NM || '|' ||   "+
				"							COALESCE(txnUltPty.PARTY_NO, txntparty.PARTY_NO) || '|' || COALESCE(txnUltRelType.RELATION_TYPE_NM, 'NA')   "+
				"						  ELSE   "+
				"							NULL   "+
				"						  END) AS TXN_PARTY_NO,   "+
				"					 fn_string_agg(    "+
				"					 cmpuwparty.PARTY_NO) AS UNDERWRITER_ID,   "+
				"					 fn_string_agg(    "+
				"					  CASE   "+
				"				              WHEN acc2.ORGANIZATION_NM is not null and acc2.MULTINATIONAL_IN is not null THEN   "+
				"				                acc2.ORGANIZATION_NM||'|'||acc2.MULTINATIONAL_IN   "+
				"				              WHEN acc3.ORGANIZATION_NM is not null and acc3.MULTINATIONAL_IN is not null THEN   "+
				"				                acc3.ORGANIZATION_NM||'|'||acc3.MULTINATIONAL_IN   "+
				"				              ELSE   "+
				"				                NULL   "+
				"				              END) AS ACCOUNT_DETAILS,   "+
				"					fn_string_agg(    "+
				"						creditedbranch.BRANCH_ID) AS CREDITED_BRANCH_ID,   "+
				"					fn_string_agg(    "+
				"						txn.TRANSACTION_ID) AS TRANSACTION_ID,   "+
				"					fn_string_agg(    "+
				"					   CASE   "+
				"				              WHEN crncy.CURRENCY_CD is not NULL and limits.ATTACHMENT_POINT_AM is not NULL THEN   "+
				"				                crncy.CURRENCY_CD || '|' || trim(to_char(limits.ATTACHMENT_POINT_AM,'99999999999999999999990D999999'))  "+
				"				              ELSE   "+
				"				                NULL   "+
				"				              END) AS ATTACHMENT_AM,   "+
				"				    fn_string_agg(    "+
				"						CASE   "+
				"				              WHEN crncy.CURRENCY_CD is not null and limits.LIMIT_AM is not null THEN   "+
				"				                crncy.CURRENCY_CD || '|' || trim(to_char(limits.LIMIT_AM ,'99999999999999999999990D999999')) "+
				"				              ELSE   "+
				"				                NULL   "+
				"				              END) AS LIMIT_AM,   "+
				"					fn_string_agg(    "+
				"						CASE   "+
				"				              WHEN crncy.CURRENCY_CD is not null and limits.PREMIUM_AM is not null then   "+
				"				                crncy.CURRENCY_CD || '|' || trim(to_char(limits.PREMIUM_AM ,'99999999999999999999990D999999')) "+
				"				              ELSE   "+
				"				                NULL   "+
				"				              END) AS PREMIUM_AM,   "+
				"					fn_string_agg(    "+
				"						CASE    "+
				"				              WHEN crncy.CURRENCY_CD is not null and limits.TECHNICAL_PRICE_AM is not null then   "+
				"				                crncy.CURRENCY_CD || '|' || trim(to_char(limits.TECHNICAL_PRICE_AM ,'99999999999999999999990D999999')) "+
				"				              ELSE   "+
				"				                NULL   "+
				"				              END) AS TECHNICAL_PRICE_AM,   "+
				"					fn_string_agg(    "+
				"					   CASE    "+
				"				              WHEN crncy.CURRENCY_CD is not null and limits.EXPIRING_PREMIUM_AM is not null then   "+
				"				                crncy.CURRENCY_CD || '|' || trim(to_char(limits.EXPIRING_PREMIUM_AM ,'99999999999999999999990D999999'))  "+
				"				              ELSE   "+
				"				                NULL   "+
				"				              END) AS EXPIRING_PREMIUM_AM,   "+
				"					fn_string_agg(    "+
				"					   CASE    "+
				"				                WHEN stat.STATUS_ID is not null and stat.REASON_ID is not null THEN   "+
				"				                  stat.STATUS_ID || '|' || stat.REASON_ID   "+
				"				                ELSE   "+
				"				                  NULL   "+
				"				                END) AS STATUS_WITH_REASON,   "+
				"					fn_string_agg(    "+
				"					    CASE    "+
				"				              WHEN stat.STATUS_ID is not null and stat.COMMENT_TX is not null then   "+
				"				                stat.STATUS_ID || '|' || stat.COMMENT_TX   "+
				"				              ELSE   "+
				"				                NULL   "+
				"				              END) AS STATUS_WITH_COMMENTS,   "+
				"					fn_string_agg(    "+
				"					    CASE    "+
				"				              WHEN statatrbt.ATTRIBUTE_ID is not null and statatrbt.ATTRIBUTE_VAL is not null THEN   "+
				"				                statatrbt.ATTRIBUTE_ID || '|' || statatrbt.ATTRIBUTE_VAL   "+
				"				              ELSE   "+
				"				                NULL   "+
				"				              END) AS STATUS_ATTRIBUTES   "+
				"					  from TTRANSACTION_COMPONENT cmp     "+
				"										left join TPARTY cmpuwparty on cmp.UNDERWRITER_ID = cmpuwparty.PARTY_ID     "+
				"										left join TTRANSACTION_VERSION txnversion on cmp.TRANSACTION_ID = txnversion.TRANSACTION_ID and cmp.VERSION_SQN = txnversion.VERSION_SQN     "+
				"										left join TTRANSACTION txn on cmp.TRANSACTION_ID = txn.TRANSACTION_ID     "+
				"										left join TTRANSACTION_PARTY txnparty on txnversion.TRANSACTION_ID = txnparty.TRANSACTION_ID and txnversion.VERSION_SQN = txnparty.VERSION_SQN AND txnparty.DELETED_IN='N'     "+
				"										left join TPARTY txntparty on txnparty.PARTY_ID = txntparty.PARTY_ID     "+
				"										left join TPARTY_TYPE txntpartytype on txntparty.PARTY_TYPE_ID = txntpartytype.PARTY_TYPE_ID     "+
				"										left join TROLE txnrolet on txnparty.ROLE_ID = txnrolet.ROLE_ID     "+
				"										left join TRELATED_PARTY txnRelPty on txnparty.PARTY_ID = txnRelPty.PARTY_ID     "+
				"										left join TPARTY txnUltPty on txnRelPty.RELATED_PARTY_ID = txnUltPty.PARTY_ID     "+
				"										left join TPARTY_RELATION_TYPE txnUltRelType on txnRelPty.RELATION_TYPE_ID = txnUltRelType.RELATION_TYPE_ID     "+
				"										left join TBRANCH creditedbranch on txn.CREDITED_BRANCH_ID = creditedbranch.BRANCH_ID     "+
				"										left join TSUBMISSION sbmn on txn.SUBMISSION_NO = sbmn.SUBMISSION_NO     "+
				"										left join TPARTY dnbparty on sbmn.ACCOUNT_ID = dnbparty.PARTY_ID     "+
				"										LEFT JOIN TACCOUNT acc2 on dnbparty.PARTY_ID=acc2.PARTY_ID     "+
				"										LEFT JOIN TSHELL_ACCOUNT acc3 on dnbparty.PARTY_ID=acc3.PARTY_ID     "+
				"										left join TRELATED_PARTY rp on dnbparty.PARTY_ID=rp.PARTY_ID     "+
				"										left join TPARTY_RELATION_TYPE rptype on rp.RELATION_TYPE_ID=rptype.RELATION_TYPE_ID     "+
				"										left join TPARTY relatedParty on rp.RELATED_PARTY_ID = relatedParty.PARTY_ID     "+
				"										left JOIN TTRANSACTION_COMPONENT_STATUS stat on cmp.TRANSACTION_COMPONENT_ID = stat.TRANSACTION_COMPONENT_ID     "+
				"										left JOIN TCOMPNENT_STATUS_ATTRIBUTE statatrbt on stat.TRANSACTION_COMPONENT_ID=statatrbt.TRANSACTION_COMPONENT_ID and stat.STATUS_ID=statatrbt.STATUS_ID  			   "+
				"										left JOIN TSTATUS status on status.STATUS_ID = stat.STATUS_ID     "+
				"										left JOIN TSTATUS_TYPE statType on statType.STATUS_TYPE_ID = status.STATUS_TYPE_ID     "+
				"										left JOIN TTRANSACTION_COMPONENT_LIMIT limits on cmp.TRANSACTION_COMPONENT_ID = limits.TRANSACTION_COMPONENT_ID     "+
				"										left JOIN TCURRENCY crncy on limits.CURRENCY_ID = crncy.CURRENCY_ID     "+
				"										left join TTRANSACTION_COMPONENT_ATRBT atrb on  cmp.TRANSACTION_COMPONENT_ID = atrb.TRANSACTION_COMPONENT_ID     "+
				"										left join TTRANSACTION_COMPONENT_ASSET asset on  cmp.TRANSACTION_COMPONENT_ID = asset.TRANSACTION_COMPONENT_ID AND asset.DELETED_IN='N'     "+
				"										left join TASSET ass on  asset.ASSET_ID = ass.ASSET_ID     "+
				"										left join TASSET_TYPE ast on ass.ASSET_TYPE_ID = ast.ASSET_TYPE_ID     "+
				"										left join TASSET_ATTRIBUTE assAtt on ass.ASSET_ID=assAtt.ASSET_ID     "+
				"										left join TTRANSACTION_COMPONENT_BRANCH branch on  cmp.TRANSACTION_COMPONENT_ID = branch.TRANSACTION_COMPONENT_ID     "+
				"										left join TBRANCH_TYPE branchType on branch.BRANCH_TYPE_ID = branchType.BRANCH_TYPE_ID     "+
				"										left join TTRANSACTION_COMPONENT_PARTY cmpparty on  cmp.TRANSACTION_COMPONENT_ID = cmpparty.TRANSACTION_COMPONENT_ID AND cmpparty.DELETED_IN='N'    "+
				"										left join TROLE rolet on cmpparty.ROLE_ID = rolet.ROLE_ID     "+
				"										left join TPARTY party on cmpparty.PARTY_ID = party.PARTY_ID     "+
				"										left join TPARTY_TYPE cmptpartytype on party.PARTY_TYPE_ID = cmptpartytype.PARTY_TYPE_ID     "+
				"										LEFT JOIN TACCOUNT cmpAcc on cmpparty.PARTY_ID=cmpAcc.PARTY_ID     "+
				"										LEFT JOIN TSHELL_ACCOUNT cmpShellAcc on cmpparty.PARTY_ID=cmpShellAcc.PARTY_ID     "+
				"										left join TRELATED_PARTY cmpRelPty on cmpparty.PARTY_ID = cmpRelPty.PARTY_ID     "+
				"										left join TPARTY cmpUltPty on cmpRelPty.RELATED_PARTY_ID = cmpUltPty.PARTY_ID     "+
				"										left join TPARTY_RELATION_TYPE cmpUltRelType on cmpRelPty.RELATION_TYPE_ID = cmpUltRelType.RELATION_TYPE_ID     "+
				"										left join TTRANSACTION_COMPONENT_RLTN relation on  cmp.TRANSACTION_COMPONENT_ID = relation.TRANSACTION_COMPONENT_ID     "+
				"										left join TTRANSACTION_COMPONENT cmprelation on relation.RELATED_TRANSACTION_CMPNT_ID = cmprelation.TRANSACTION_COMPONENT_ID     "+
				"										left join TCOMPONENT_RELATION_TYPE cmprelationtype on relation.RELATION_TYPE_ID = cmprelationtype.RELATION_TYPE_ID     "+
				"										left join TTRANSACTION_COMPONENT_RLTN renewedRelation on  cmp.TRANSACTION_COMPONENT_ID = renewedRelation.RELATED_TRANSACTION_CMPNT_ID     "+
				"										left join TTRANSACTION_COMPONENT renewedPrdrelation on renewedRelation.TRANSACTION_COMPONENT_ID = renewedPrdrelation.TRANSACTION_COMPONENT_ID     "+
				"										left join TCOMPONENT_RELATION_TYPE renewedPrdrelationtype on renewedRelation.RELATION_TYPE_ID = renewedPrdrelationtype.RELATION_TYPE_ID     "+
				"										where cmp.TRANSACTION_COMPONENT_ID in (?1)   "+
				"										group by cmp.TRANSACTION_COMPONENT_ID   ",
				
				resultSetMapping="DataMapping")

public class TransactionComponentChildEntriesBO {
	
	//private static final Logger logger = LogManager.getLogger(TransactionComponentChildEntriesBO.class);
	
	@Id
	@Column(name="TRANSACTION_COMPONENT_ID")
	private Long transactionComponentId;
	
	/*@Column(name="EXPOSURE_GEOGRAPHIC_LOCATION_ID")
	private String exposureGeographicLocationId;*/
	
	@Lob
	@Column(name="STATUS_ID")
	private String statusId;
	
	@Lob
	@Column(name="STATUS_WITH_REASON")
	private String statusWithReason;
	
	@Lob
	@Column(name="STATUS_WITH_COMMENTS")
	private String statusWithComments;
	
	@Lob
	@Column(name="STATUS_ATTRIBUTES")
	private String statusAttributes;
	
	@Lob
	@Column(name="ATTRIBUTE_DETAILS")
	private String attributeDetails;
	
	@Lob
	@Column(name="ASSET_DETAILS")
	private String assetDetails;
	
	@Lob
	@Column(name="ASSET_ATTRIBUTE_DETAILS")
	private String assetAttributeDetails;
	
	@Lob
	@Column(name="BRANCH_ID")
	private String branchId;
	
	@Lob
	@Column(name="CMPNENT_ADNT_PRTY_DTLS")
	private String partyId;
	
	@Lob
	@Column(name="RELATED_TRANSACTION_ID")
	private String relatedTransactionId;
	
	@Lob
	@Column(name="SUBMISSION_NO")
	private String submissionNo;
	
	@Lob
	@Column(name="DNBNO")
	private String dnbNo;
	
	@Lob
	@Column(name="RELATED_PARTY_DETAILS")
	private String relatedParty;
	
	@Lob
	@Column(name="TXN_PARTY_NO")
	private String transactionParty;
	
	@Lob
	@Column(name="UNDERWRITER_ID")
	private String componentUnderwriterNo;
	
	@Lob
	@Column(name="ACCOUNT_DETAILS")
	private String dnbAccountName;
	
	@Lob
	@Column(name="CREDITED_BRANCH_ID")
	private String creditedBranchId;
	
	@Lob
	@Column(name="TRANSACTION_ID")
	private String transactionId;
	
	@Lob
	@Column(name="ATTACHMENT_AM")
	private String attachmentPoint;
	
	@Lob
	@Column(name="LIMIT_AM")
	private String limitAmt;
	
	@Lob
	@Column(name="PREMIUM_AM")
	private String premiumAmt;
	
	@Lob
	@Column(name="TECHNICAL_PRICE_AM")
	private String technicalPriceAmt;
	
	@Lob
	@Column(name="EXPIRING_PREMIUM_AM")
	private String expiringPremiumAmt;
	
	@Lob
	@Column(name="IS_RENEWED_CHECK")
	private String isRenewedCheck;
	
	/*@Column(name="POLICY_DETAILS")
	private String policyDetails;
	
	@Column(name="POLICY_ATTRIBUTES")
	private String policyAtrbt;*/
	
	

	/*private String wipQuoteDetails;
	private String wipQuoteSectionCd;
	private String wipQuoteProfitUnitCd;
	private String wipQuoteWinningCarrierNm;
	private String wipQuoteLossrsn;
	private String wipQuoteQuoteEffectiveDt;
	private String wipQuoteQuoteExpirationDt;
	private String wipQuoteReasonCd;
	private String wipQuotePolEventNo;
	private String wipQuotePolicyId;
	private String wipQuotePriorPolicyId;
	
	private String wipQuoteMasterContractNo;
	private String wipQuoteAccountLegalNm;
	private String wipQuoteAccountPolNo;
	private String wipQuoteAccountPolPrfxCd;
	private String wipQuoteNonRenewalReasonCd;
	private String wipQuotePolicyMailedDt;
	
	private String wipQuoteCurrencyId;
	private String wipQuoteCurrencyQuotedPremiumAmt;
	private String wipQuoteCurrencyQuotedLimitAmt;
	private String wipQuoteCurrencyQuotedAttachmentPointAmt;
	private String wipQuoteCurrencyPolicyAttachmentPointAmt;
	private String wipQuoteCurrencyPolicyLimitAmt;
	private String wipQuoteCurrencyPolicyPartOfAmt;*/
	
	/*public void setWipQuoteCurrencyPolicyAttachmentPointAmt(
			String wipQuoteCurrencyPolicyAttachmentPointAmt) {
		this.wipQuoteCurrencyPolicyAttachmentPointAmt = wipQuoteCurrencyPolicyAttachmentPointAmt;
	}


	public void setWipQuoteCurrencyPolicyLimitAmt(
			String wipQuoteCurrencyPolicyLimitAmt) {
		this.wipQuoteCurrencyPolicyLimitAmt = wipQuoteCurrencyPolicyLimitAmt;
	}


	public void setWipQuoteCurrencyPolicyPartOfAmt(
			String wipQuoteCurrencyPolicyPartOfAmt) {
		this.wipQuoteCurrencyPolicyPartOfAmt = wipQuoteCurrencyPolicyPartOfAmt;
	}


	public void setWipQuoteMasterContractNo(String wipQuoteMasterContractNo) {
		this.wipQuoteMasterContractNo = wipQuoteMasterContractNo;
	}


	public void setWipQuoteAccountLegalNm(String wipQuoteAccountLegalNm) {
		this.wipQuoteAccountLegalNm = wipQuoteAccountLegalNm;
	}


	public void setWipQuoteAccountPolNo(String wipQuoteAccountPolNo) {
		this.wipQuoteAccountPolNo = wipQuoteAccountPolNo;
	}


	public void setWipQuoteAccountPolPrfxCd(String wipQuoteAccountPolPrfxCd) {
		this.wipQuoteAccountPolPrfxCd = wipQuoteAccountPolPrfxCd;
	}


	public void setWipQuoteNonRenewalReasonCd(String wipQuoteNonRenewalReasonCd) {
		this.wipQuoteNonRenewalReasonCd = wipQuoteNonRenewalReasonCd;
	}


	public void setWipQuotePolicyMailedDt(String wipQuotePolicyMailedDt) {
		this.wipQuotePolicyMailedDt = wipQuotePolicyMailedDt;
	}


	public void setWipQuoteDetails(String wipQuoteDetails) {
		this.wipQuoteDetails = wipQuoteDetails;
	}


	public void setWipQuoteSectionCd(String wipQuoteSectionCd) {
		this.wipQuoteSectionCd = wipQuoteSectionCd;
	}


	public void setWipQuoteProfitUnitCd(String wipQuoteProfitUnitCd) {
		this.wipQuoteProfitUnitCd = wipQuoteProfitUnitCd;
	}


	public void setWipQuoteWinningCarrierNm(String wipQuoteWinningCarrierNm) {
		this.wipQuoteWinningCarrierNm = wipQuoteWinningCarrierNm;
	}


	public void setWipQuoteLossrsn(String wipQuoteLossrsn) {
		this.wipQuoteLossrsn = wipQuoteLossrsn;
	}


	public void setWipQuoteQuoteEffectiveDt(String wipQuoteQuoteEffectiveDt) {
		this.wipQuoteQuoteEffectiveDt = wipQuoteQuoteEffectiveDt;
	}


	public void setWipQuoteQuoteExpirationDt(String wipQuoteQuoteExpirationDt) {
		this.wipQuoteQuoteExpirationDt = wipQuoteQuoteExpirationDt;
	}


	public void setWipQuoteReasonCd(String wipQuoteReasonCd) {
		this.wipQuoteReasonCd = wipQuoteReasonCd;
	}


	public void setWipQuotePolEventNo(String wipQuotePolEventNo) {
		this.wipQuotePolEventNo = wipQuotePolEventNo;
	}


	public void setWipQuotePolicyId(String wipQuotePolicyId) {
		this.wipQuotePolicyId = wipQuotePolicyId;
	}


	public void setWipQuotePriorPolicyId(String wipQuotePriorPolicyId) {
		this.wipQuotePriorPolicyId = wipQuotePriorPolicyId;
	}


	public void setWipQuoteCurrencyId(String wipQuoteCurrencyId) {
		this.wipQuoteCurrencyId = wipQuoteCurrencyId;
	}


	public void setWipQuoteCurrencyQuotedPremiumAmt(
			String wipQuoteCurrencyQuotedPremiumAmt) {
		this.wipQuoteCurrencyQuotedPremiumAmt = wipQuoteCurrencyQuotedPremiumAmt;
	}


	public void setWipQuoteCurrencyQuotedLimitAmt(
			String wipQuoteCurrencyQuotedLimitAmt) {
		this.wipQuoteCurrencyQuotedLimitAmt = wipQuoteCurrencyQuotedLimitAmt;
	}


	public void setWipQuoteCurrencyQuotedAttachmentPointAmt(
			String wipQuoteCurrencyQuotedAttachmentPointAmt) {
		this.wipQuoteCurrencyQuotedAttachmentPointAmt = wipQuoteCurrencyQuotedAttachmentPointAmt;
	}*/


	public String getTransactionCcomponentId() {
		return String.valueOf(transactionComponentId);
	}


	public void setTransactionCcomponentId(Long transactionCcomponentId) {
		this.transactionComponentId = transactionCcomponentId;
	}


	/*public void setExposureGeographicLocationId(String exposureGeographicLocationId) {
		this.exposureGeographicLocationId = exposureGeographicLocationId;
	}*/


	public void setStatusId(String statusId) {
		this.statusId = statusId;
	}


	public void setStatusWithReason(String statusWithReason) {
		this.statusWithReason = statusWithReason;
	}

	public void setStatusWithComments(String statusWithComments) {
		this.statusWithComments = statusWithComments;
	}


	public String getStatusAttributes() {
		return statusAttributes;
	}


	public void setStatusAttributes(String statusAttributes) {
		this.statusAttributes = statusAttributes;
	}


	public void setAttributeDetails(String attributeDetails) {
		this.attributeDetails = attributeDetails;
	}


	

	public String getAssetAttributeDetails() {
		return assetAttributeDetails;
	}


	public void setAssetAttributeDetails(String assetAttributeDetails) {
		this.assetAttributeDetails = assetAttributeDetails;
	}


	public void setAssetDetails(String assetDetails) {
		this.assetDetails = assetDetails;
	}


	public void setBranchId(String branchId) {
		this.branchId = branchId;
	}


	public void setPartyId(String partyId) {
		this.partyId = partyId;
	}

	public void setRelatedTransactionId(String relatedTransactionId) {
		this.relatedTransactionId = relatedTransactionId;
	}


	public String getSubmissionNo() {
		String submission = null;
		for(String sub : getUniqueValues(this.submissionNo))
		{
			submission = sub;
		}
		return submission;
	}


	public void setSubmissionNo(String submissionNo) {
		this.submissionNo = submissionNo;
	}
	
	public String getDnbNo() {
		
		String dnb = ""; 
		
		for(String temp : getUniqueValues(dnbNo))
		{
			dnb = temp;
		}
		return dnb;
	}


	public void setDnbNo(String dnbNo) {
		this.dnbNo = dnbNo;
	}

	public String getRelatedParty() {
		return relatedParty;
	}


	public void setRelatedParty(String relatedParty) {
		this.relatedParty = relatedParty;
	}

	public String getTransactionParty() {
		return transactionParty;
	}


	public void setTransactionParty(
			String transactionParty) {
		this.transactionParty = transactionParty;
	}

	public String getComponentUnderwriterNo() {
		
		String componentUnderwriter = ""; 
		
		for(String temp : getUniqueValues(componentUnderwriterNo))
		{
			componentUnderwriter = temp;
		}
		return componentUnderwriter;
	}


	public void setComponentUnderwriterNo(String componentUnderwriterNo) {
		this.componentUnderwriterNo = componentUnderwriterNo;
	}

	public String getDnbAccountName() {
		
		String accountName = ""; 
		
		for(String temp : getUniqueValues(dnbAccountName))
		{
			accountName = temp;
		}
		return accountName;
	}


	public void setDnbAccountName(String dnbAccountName) {
		this.dnbAccountName = dnbAccountName;
	}

	public int getCreditedBranchId() {
		
		String creditedBranch = ""; 
		
		for(String temp : getUniqueValues(creditedBranchId))
		{
			creditedBranch = temp;
		}
		return Integer.valueOf(creditedBranch);
	}


	public void setCreditedBranchId(String creditedBranchId) {
		this.creditedBranchId = creditedBranchId;
	}

	public String getTransactionId() {
		
		String txnId = ""; 
		
		for(String temp : getUniqueValues(transactionId))
		{
			txnId = temp;
		}
		return txnId;
	}


	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}


	public String getAttachmentPoint() {
		return attachmentPoint;
	}


	public void setAttachmentPoint(String attachmentPoint) {
		this.attachmentPoint = attachmentPoint;
	}


	public String getLimitAmt() {
		return limitAmt;
	}


	public void setLimitAmt(String limitAmt) {
		this.limitAmt = limitAmt;
	}


	public String getPremiumAmt() {
		return premiumAmt;
	}


	public void setPremiumAmt(String premiumAmt) {
		this.premiumAmt = premiumAmt;
	}


	public String getTechnicalPriceAmt() {
		return technicalPriceAmt;
	}


	public void setTechnicalPriceAmt(String technicalPriceAmt) {
		this.technicalPriceAmt = technicalPriceAmt;
	}


	public String getExpiringPremiumAmt() {
		return expiringPremiumAmt;
	}


	public void setExpiringPremiumAmt(String expiringPremiumAmt) {
		this.expiringPremiumAmt = expiringPremiumAmt;
	}


/*	public void setPolicyDetails(String policyDetails) {
		this.policyDetails = policyDetails;
	}

	public void setPolicyAtrbt(String policyAtrbt) {
		this.policyAtrbt = policyAtrbt;
	}*/

	public class LimitDetails {
		
		private String currency;
		private BigDecimal limitAmount;
		private BigDecimal attachmentPointAm;
		private BigDecimal premiumAmount;
		private BigDecimal technicalPriceAmount;
		private BigDecimal expiringPremiumAmout;
		
		public String getCurrency() {
			return currency;
		}
		public void setCurrency(String currency) {
			this.currency = currency;
		}
		public BigDecimal getLimitAmt() {
			return limitAmount;
		}
		public void setLimitAmt(BigDecimal limitAmt) {
			this.limitAmount = limitAmt;
		}
		public BigDecimal getAttachmentPointAm() {
			return attachmentPointAm;
		}
		public void setAttachmentPointAm(BigDecimal attachmentPointAm) {
			this.attachmentPointAm = attachmentPointAm;
		}
		public BigDecimal getPremiumAmount() {
			return premiumAmount;
		}
		public void setPremiumAmount(BigDecimal premiumAmount) {
			this.premiumAmount = premiumAmount;
		}
		public BigDecimal getTechnicalPriceAmount() {
			return technicalPriceAmount;
		}
		public void setTechnicalPriceAmount(BigDecimal technicalPriceAmount) {
			this.technicalPriceAmount = technicalPriceAmount;
		}
		public BigDecimal getExpiringPremiumAmout() {
			return expiringPremiumAmout;
		}
		public void setExpiringPremiumAmout(BigDecimal expiringPremiumAmout) {
			this.expiringPremiumAmout = expiringPremiumAmout;
		}
	}

	public class DNBAccountDetails {
		
		private String dnbAccountNm;
		private String dnbAccountMultiNationalIn;
		
		public String getDnbAccountNm() {
			return dnbAccountNm;
		}
		public void setDnbAccountNm(String dnbAccountNm) {
			this.dnbAccountNm = dnbAccountNm;
		}
		public String getDnbAccountMultiNationalIn() {
			return dnbAccountMultiNationalIn;
		}
		public void setDnbAccountMultiNationalIn(String dnbAccountMultiNationalIn) {
			this.dnbAccountMultiNationalIn = dnbAccountMultiNationalIn;
		}
	}
	
	public class WIPQuoteCurrencyDetails {
		private Short currencyId;
		private BigDecimal quotedPremiumAmt;
		private BigDecimal quoteLimitAmt;
		private BigDecimal quoteAttachmentPointAmt;
		private BigDecimal policyAttachmentPointAmt;
		private BigDecimal policyLimitAmt;
		private BigDecimal policyPartOfAmt;
		
		public Short getCurrencyId() {
			return currencyId;
		}
		public void setCurrencyId(Short currencyId) {
			this.currencyId = currencyId;
		}
		public BigDecimal getQuotedPremiumAmt() {
			return quotedPremiumAmt;
		}
		public void setQuotedPremiumAmt(BigDecimal quotedPremiumAmt) {
			this.quotedPremiumAmt = quotedPremiumAmt;
		}
		public BigDecimal getQuoteLimitAmt() {
			return quoteLimitAmt;
		}
		public void setQuoteLimitAmt(BigDecimal quoteLimitAmt) {
			this.quoteLimitAmt = quoteLimitAmt;
		}
		public BigDecimal getQuoteAttachmentPointAmt() {
			return quoteAttachmentPointAmt;
		}
		public void setQuoteAttachmentPointAmt(BigDecimal quoteAttachmentPointAmt) {
			this.quoteAttachmentPointAmt = quoteAttachmentPointAmt;
		}
		public BigDecimal getPolicyAttachmentPointAmt() {
			return policyAttachmentPointAmt;
		}
		public void setPolicyAttachmentPointAmt(BigDecimal policyAttachmentPointAmt) {
			this.policyAttachmentPointAmt = policyAttachmentPointAmt;
		}
		public BigDecimal getPolicyLimitAmt() {
			return policyLimitAmt;
		}
		public void setPolicyLimitAmt(BigDecimal policyLimitAmt) {
			this.policyLimitAmt = policyLimitAmt;
		}
		public BigDecimal getPolicyPartOfAmt() {
			return policyPartOfAmt;
		}
		public void setPolicyPartOfAmt(BigDecimal policyPartOfAmt) {
			this.policyPartOfAmt = policyPartOfAmt;
		}
	}
	
	/*public class WIPQuoteDetails {
		
		private String wipId;
		private Short quoteSqn;
		private String wipStatusCd;
		private Date wipStatusEnteredDt;
		private String quoteAcceptedIn;
		private String nonRenewalIn;
		private String systemId;
		private Short sectionCd;
		private Short profitUnitCd;
		private String winningCarrierNm;
		private String lossrsn;
		private Date quoteEffectedDt;
		private Date quoteExpirationDt;
		private String reasonCd;
		private Short policyEventNo;
		private Integer policyId;
		private Integer priorPolicyId;
		private String masterContractNo;
		private String accountLegalNm;
		private Integer accountPolNo;
		private String accountPolPrfxCd;
		private String nonRenewalReasonCd;
		private Date policyMailedDt;
	
		private List<WIPQuoteCurrencyDetails> wipQuoteCurrencyDetailsList;
		
		public List<WIPQuoteCurrencyDetails> getWIPQuoteCurrencyDetailsList() {
	        if (wipQuoteCurrencyDetailsList == null) {
	        	wipQuoteCurrencyDetailsList = new ArrayList<WIPQuoteCurrencyDetails>();
	        }
	        return this.wipQuoteCurrencyDetailsList;
	    }
		
		public String getWipId() {
			return wipId;
		}
		public void setWipId(String wipId) {
			this.wipId = wipId;
		}
		public Short getQuoteSqn() {
			return quoteSqn;
		}
		public void setQuoteSqn(Short quoteSqn) {
			this.quoteSqn = quoteSqn;
		}
		public String getWipStatusCd() {
			return wipStatusCd;
		}
		public void setWipStatusCd(String wipStatusCd) {
			this.wipStatusCd = wipStatusCd;
		}
		public Date getWipStatusEnteredDt() {
			return wipStatusEnteredDt;
		}
		public void setWipStatusEnteredDt(Date wipStatusEnteredDt) {
			this.wipStatusEnteredDt = wipStatusEnteredDt;
		}
		public String getQuoteAcceptedIn() {
			return quoteAcceptedIn;
		}
		public void setQuoteAcceptedIn(String quoteAcceptedIn) {
			this.quoteAcceptedIn = quoteAcceptedIn;
		}
		public String getNonRenewalIn() {
			return nonRenewalIn;
		}
		public void setNonRenewalIn(String nonRenewalIn) {
			this.nonRenewalIn = nonRenewalIn;
		}
		public String getSystemId() {
			return systemId;
		}
		public void setSystemId(String systemId) {
			this.systemId = systemId;
		}
		
		public Short getSectionCd() {
			return sectionCd;
		}
		public void setSectionCd(Short sectionCd) {
			this.sectionCd = sectionCd;
		}
		public Short getProfitUnitCd() {
			return profitUnitCd;
		}
		public void setProfitUnitCd(Short profitUnitCd) {
			this.profitUnitCd = profitUnitCd;
		}
		public String getWinningCarrierNm() {
			return winningCarrierNm;
		}
		public void setWinningCarrierNm(String winningCarrierNm) {
			this.winningCarrierNm = winningCarrierNm;
		}
		public String getLossrsn() {
			return lossrsn;
		}
		public void setLossrsn(String lossrsn) {
			this.lossrsn = lossrsn;
		}
		public Date getQuoteEffectedDt() {
			return quoteEffectedDt;
		}
		public void setQuoteEffectedDt(Date quoteEffectedDt) {
			this.quoteEffectedDt = quoteEffectedDt;
		}
		public Date getQuoteExpirationDt() {
			return quoteExpirationDt;
		}
		public void setQuoteExpirationDt(Date quoteExpirationDt) {
			this.quoteExpirationDt = quoteExpirationDt;
		}
		public String getReasonCd() {
			return reasonCd;
		}
		public void setReasonCd(String reasonCd) {
			this.reasonCd = reasonCd;
		}
		public Short getPolicyEventNo() {
			return policyEventNo;
		}
		public void setPolicyEventNo(Short policyEventNo) {
			this.policyEventNo = policyEventNo;
		}
		public Integer getPolicyId() {
			return policyId;
		}

		public void setPolicyId(Integer policyId) {
			this.policyId = policyId;
		}

		public Integer getPriorPolicyId() {
			return priorPolicyId;
		}
		public void setPriorPolicyId(Integer priorPolicyId) {
			this.priorPolicyId = priorPolicyId;
		}

		public String getMasterContractNo() {
			return masterContractNo;
		}

		public void setMasterContractNo(String masterContractNo) {
			this.masterContractNo = masterContractNo;
		}

		public String getAccountLegalNm() {
			return accountLegalNm;
		}

		public void setAccountLegalNm(String accountLegalNm) {
			this.accountLegalNm = accountLegalNm;
		}

		public Integer getAccountPolNo() {
			return accountPolNo;
		}

		public void setAccountPolNo(Integer accountPolNo) {
			this.accountPolNo = accountPolNo;
		}

		public String getAccountPolPrfxCd() {
			return accountPolPrfxCd;
		}

		public void setAccountPolPrfxCd(String accountPolPrfxCd) {
			this.accountPolPrfxCd = accountPolPrfxCd;
		}

		public String getNonRenewalReasonCd() {
			return nonRenewalReasonCd;
		}

		public void setNonRenewalReasonCd(String nonRenewalReasonCd) {
			this.nonRenewalReasonCd = nonRenewalReasonCd;
		}

		public Date getPolicyMailedDt() {
			return policyMailedDt;
		}

		public void setPolicyMailedDt(Date policyMailedDt) {
			this.policyMailedDt = policyMailedDt;
		}
		
		
		
		
	}*/
	
	public class PolicyDetails {
		
		private String policyID;
		private String policyNo;
		private int issuingCompanyCd;
		private BigDecimal premiumAm;
		private String policyTypeNm;
		private String currencyCd;
		private BigDecimal localCurrencyPremiumAm;
		private Date effectiveDate;
		private Date expirationDate;
		
		public String getPolicyID() {
			return policyID;
		}
		public void setPolicyID(String policyID) {
			this.policyID = policyID;
		}
		public String getPolicyNo() {
			return policyNo;
		}
		public void setPolicyNo(String policyNo) {
			this.policyNo = policyNo;
		}
		public int getIssuingCompanyCd() {
			return issuingCompanyCd;
		}
		public void setIssuingCompanyCd(int issuingCompanyCd) {
			this.issuingCompanyCd = issuingCompanyCd;
		}
		public BigDecimal getPremiumAm() {
			return premiumAm;
		}
		public void setPremiumAm(BigDecimal premiumAm) {
			this.premiumAm = premiumAm;
		}
		public String getPolicyTypeNm() {
			return policyTypeNm;
		}
		public void setPolicyTypeNm(String policyTypeNm) {
			this.policyTypeNm = policyTypeNm;
		}
		public String getCurrencyCd() {
			return currencyCd;
		}
		public void setCurrencyCd(String currencyCd) {
			this.currencyCd = currencyCd;
		}
		public BigDecimal getLocalCurrencyPremiumAm() {
			return localCurrencyPremiumAm;
		}
		public void setLocalCurrencyPremiumAm(BigDecimal localCurrencyPremiumAm) {
			this.localCurrencyPremiumAm = localCurrencyPremiumAm;
		}
		public Date getEffectiveDate() {
			return effectiveDate;
		}
		public void setEffectiveDate(Date effectiveDate) {
			this.effectiveDate = effectiveDate;
		}
		public Date getExpirationDate() {
			return expirationDate;
		}
		public void setExpirationDate(Date expirationDate) {
			this.expirationDate = expirationDate;
		}
		
		private List<PolicyAttributeDetails> policyAttributeDetailsList;
		
		public List<PolicyAttributeDetails> getPolicyAttributeDetails() {
		        if (policyAttributeDetailsList == null) {
		        	policyAttributeDetailsList = new ArrayList<PolicyAttributeDetails>();
		        }
		        return this.policyAttributeDetailsList;
		    }
	}
	
	public class PolicyAttributeDetails {
		private Short attributeId;
		private String attributeVal;
		
		public Short getAttributeId() {
			return attributeId;
		}
		public void setAttributeId(Short attributeId) {
			this.attributeId = attributeId;
		}
		public String getAttributeVal() {
			return attributeVal;
		}
		public void setAttributeVal(String attributeVal) {
			this.attributeVal = attributeVal;
		}
	}
	
	public class BranchDetails {
		
		private String branchTypeNm;
		private Short branchID;
		
		public String getBranchTypeNm() {
			return branchTypeNm;
		}
		public void setBranchTypeNm(String branchTypeNm) {
			this.branchTypeNm = branchTypeNm;
		}
		public Short getBranchID() {
			return branchID;
		}
		public void setBranchID(Short branchID) {
			this.branchID = branchID;
		}
	}

	public class RelatedPartyDetails {
		
		private String relationTypeNm;
		private String relatedPartyNo;
		
		public String getRelationTypeNm() {
			return relationTypeNm;
		}
		public void setRelationTypeNm(String relationTypeNm) {
			this.relationTypeNm = relationTypeNm;
		}
		public String getRelatedPartyNo() {
			return relatedPartyNo;
		}
		public void setRelatedPartyNo(String relatedPartyNo) {
			this.relatedPartyNo = relatedPartyNo;
		}
	}
	
	public class TransactionPartyDetails {
		
		private String roleNm;
		private String partyNo;
		private String partyTypeNm;
		
		// To get transaction additional insured ultimate DUNS
		private String ultimatePartyNo;
		private String relatedPartyTypeNm;
						
		public String getUltimatePartyNo() {
			return ultimatePartyNo;
		}
		public void setUltimatePartyNo(String ultimatePartyNo) {
			this.ultimatePartyNo = ultimatePartyNo;
		}
		public String getRelatedPartyTypeNm() {
			return relatedPartyTypeNm;
		}
		public void setRelatedPartyTypeNm(String relatedPartyTypeNm) {
			this.relatedPartyTypeNm = relatedPartyTypeNm;
		}
		public String getRoleNm() {
			return roleNm;
		}
		public void setRoleNm(String roleNm) {
			this.roleNm = roleNm;
		}
		public String getPartyNo() {
			return partyNo;
		}
		public void setPartyNo(String partyNo) {
			this.partyNo = partyNo;
		}
		public String getPartyTypeNm() {
			return partyTypeNm;
		}
		public void setPartyTypeNm(String partyTypeNm) {
			this.partyTypeNm = partyTypeNm;
		}
	}
	
	public class StatusDetails {
		
		private String statusTypeNm;
		private Short statusID;
		private Short reasonID;
		private String commentTx;
		
		private List<StatusAttributeDetails> statusAttributeList;
		
		public List<StatusAttributeDetails> getStatusAttributeDetails() {
	        if (statusAttributeList == null) {
	        	statusAttributeList = new ArrayList<StatusAttributeDetails>();
	        }
	        return this.statusAttributeList;
	    }
		
		public String getStatusTypeNm() {
			return statusTypeNm;
		}
		public void setStatusTypeNm(String statusTypeNm) {
			this.statusTypeNm = statusTypeNm;
		}
		public Short getStatusId() {
			return statusID;
		}
		public void setStatusId(Short statusID) {
			this.statusID = statusID;
		}
		
		public Short getReasonID() {
			return reasonID;
		}
		public void setReasonID(Short reasonID) {
			this.reasonID = reasonID;
		}
		public String getCommentTx() {
			return commentTx;
		}
		public void setCommentTx(String commentTx) {
			this.commentTx = commentTx;
		}		
	}
	
	public class StatusAttributeDetails {
		private Short attributeId;
		private String attributeVal;
		
		public Short getAttributeId() {
			return attributeId;
		}
		public void setAttributeId(Short attributeId) {
			this.attributeId = attributeId;
		}
		public String getAttributeVal() {
			return attributeVal;
		}
		public void setAttributeVal(String attributeVal) {
			this.attributeVal = attributeVal;
		}
	}
	
	public class ComponentPartyDetails {
		
		private String roleNm;
		private String partyNo;
		private String partyTypeNm;
		private String accountNm;
		
		// To get component product additional insured ultimate DUNS
		private String ultimatePartyNo;
		private String relatedPartyTypeNm;
						
		public String getUltimatePartyNo() {
			return ultimatePartyNo;
		}
		public void setUltimatePartyNo(String ultimatePartyNo) {
			this.ultimatePartyNo = ultimatePartyNo;
		}
		public String getRelatedPartyTypeNm() {
			return relatedPartyTypeNm;
		}
		public void setRelatedPartyTypeNm(String relatedPartyTypeNm) {
			this.relatedPartyTypeNm = relatedPartyTypeNm;
		}
		
		public String getRoleNm() {
			return roleNm;
		}
		public void setRoleNm(String roleNm) {
			this.roleNm = roleNm;
		}
		public String getPartyNo() {
			return partyNo;
		}
		public void setPartyNo(String partyNo) {
			this.partyNo = partyNo;
		}
		public String getPartyTypeNm() {
			return partyTypeNm;
		}
		public void setPartyTypeNm(String partyTypeNm) {
			this.partyTypeNm = partyTypeNm;
		}
		public String getAccountNm() {
			return accountNm;
		}
		public void setAccountNm(String accountNm) {
			this.accountNm = accountNm;
		}
	}
	
	public class AttributeDetails {
		private Short attributeId;
		private String attributeVal;
		
		public Short getAttributeId() {
			return attributeId;
		}
		public void setAttributeId(Short attributeId) {
			this.attributeId = attributeId;
		}
		public String getAttributeVal() {
			return attributeVal;
		}
		public void setAttributeVal(String attributeVal) {
			this.attributeVal = attributeVal;
		}
	}
	
	public class AssetAttributeDetails {
		private Short attributeId;
		private String attributeVal;
		
		public Short getAttributeId() {
			return attributeId;
		}
		public void setAttributeId(Short attributeId) {
			this.attributeId = attributeId;
		}
		public String getAttributeVal() {
			return attributeVal;
		}
		public void setAttributeVal(String attributeVal) {
			this.attributeVal = attributeVal;
		}
	}


	public class AssetDetails {
		
		private String assetTypeNm;
		private String assetDs;
		private Integer assetID;
		


		private List<AssetAttributeDetails> assetAttributeDetailsList;
					
		public List<AssetAttributeDetails> getAssetAttributeDetails() {
		        if (assetAttributeDetailsList == null) {
		        	assetAttributeDetailsList = new ArrayList<AssetAttributeDetails>();
		        }
		        return this.assetAttributeDetailsList;
		    }
		
		
		public String getAssetTypeNm() {
			return assetTypeNm;
		}
		public void setAssetTypeNm(String assetTypeNm) {
			this.assetTypeNm = assetTypeNm;
		}
		
		
		
		public String getAssetDs() {
			return assetDs;
		}
		public void setAssetDs(String assetDs) {
			this.assetDs = assetDs;
		}
		public Integer getAssetId() {
			return assetID;
		}
		public void setAssetId(Integer assetID) {
			this.assetID = assetID;
		}
	}
	
	private Set<String> getUniqueValues(String stringContainingDuplicates) {
		if(null != stringContainingDuplicates)
		{
			//logger.debug("stringContainingDuplicates : "+stringContainingDuplicates);
			/*int index = stringContainingDuplicates.lastIndexOf(NGEConstants.RECORDDELIMITER);
			stringContainingDuplicates = stringContainingDuplicates.substring(0, index);*/
			//logger.debug("After stringContainingDuplicates : "+stringContainingDuplicates);
			Set<String> uniqueValueSet = new HashSet<String>(Arrays.asList(stringContainingDuplicates.split(NGEConstants.RECORDDELIMITER)));
			return uniqueValueSet;
		}
		return new HashSet<String>();
	}
	
/*	public Set<String> getExposureGeographicLocationId() {
		return getUniqueValues(this.exposureGeographicLocationId);
	}*/
	
	
	public List<AttributeDetails> getAttributeDetails() {
		
		String attributeId = null;
		String attributeVal = null;
		List<AttributeDetails> attributeDetailsList = new ArrayList<AttributeDetails>();
		//logger.debug("getUniqueAttributeDetails : "+this.attributeDetails);
		for(String temp : getUniqueValues(this.attributeDetails))
		{
		//	logger.debug("temp : "+temp);
			AttributeDetails attDetails = new AttributeDetails();
			StringTokenizer st = new StringTokenizer(temp,NGEConstants.GENERICDELIMITER);
										
			if(st.hasMoreTokens())
			{
				attributeId = st.nextToken();
				attDetails.setAttributeId(Short.valueOf(attributeId));
			}
			if(st.hasMoreTokens())
			{
				attributeVal = st.nextToken();
				attDetails.setAttributeVal(attributeVal);
			}
			 
			attributeDetailsList.add(attDetails);
		}
		
		return attributeDetailsList;
	}
	
	public List<AssetDetails> getAssetDetails() {
		
		String assetTypeNm = null;
		String attributeId = null;
		String attributeVal = null;
		String assetDs = null;
		String assetID = null;
		
		List<AssetDetails> assetDetailsList = new ArrayList<AssetDetails>();
		//logger.debug("assetId : "+this.assetDetails);
		
		for(String temp : getUniqueValues(this.assetDetails))
		{
			//logger.debug("temp : "+temp);
			
			
			AssetDetails assetDetail = new AssetDetails();
			
			StringTokenizer st = new StringTokenizer(temp,NGEConstants.GENERICDELIMITER);
				
			if(st.hasMoreTokens())
			{
				assetID = st.nextToken();
				assetDetail.setAssetId(Integer.valueOf(assetID));
			}
			if(st.hasMoreTokens())
			{
				assetDs = st.nextToken();
				assetDetail.setAssetDs(assetDs);
			}
			
			if(st.hasMoreTokens())
			{
				assetTypeNm = st.nextToken();
				assetDetail.setAssetTypeNm(assetTypeNm);
			}
			//logger.debug("this.assetAttributeDetails : "+this.assetAttributeDetails);
			for(String temp1 : getUniqueValues(this.assetAttributeDetails))
			{
				StringTokenizer st1 = new StringTokenizer(temp1,NGEConstants.GENERICDELIMITER);
				
				if(st1.hasMoreTokens())
				{
					assetID = st1.nextToken();
				}

				if(assetID.equalsIgnoreCase(String.valueOf(assetDetail.getAssetId())))
				{
					AssetAttributeDetails assetAttributeDetails1 = new AssetAttributeDetails();
					if(st1.hasMoreTokens())
					{
						attributeId = st1.nextToken();
						assetAttributeDetails1.setAttributeId(Short.valueOf(attributeId));
					}
					if(st1.hasMoreTokens())
					{
						attributeVal = st1.nextToken();
						assetAttributeDetails1.setAttributeVal(attributeVal);	
					}
					assetDetail.getAssetAttributeDetails().add(assetAttributeDetails1);
				}
			}
			
			
			assetDetailsList.add(assetDetail);
			
			
		}
		
		return assetDetailsList;
	}
	
	/*public List<PolicyDetails> getPolicyDetails() {
		
		String policyID = null;
		String policyNo = null;
		String issuingCompanyCd = null;
		BigDecimal premiumAm = null;
		String policyTypeNm = null;
		String currencyCd = null;
		BigDecimal localCurrencyPremiumAm = null;
		String effectiveDate = null;
		String expirationDate = null;
		String attributeId = null;
		String attributeVal = null;
		
		List<PolicyDetails> policyDetailsList = new ArrayList<PolicyDetails>();
		//logger.debug("policyDetails : "+this.policyDetails);
		
		for(String temp : getUniqueValues(this.policyDetails))
		{
			//logger.debug("temp : "+temp);
			
			
			PolicyDetails policyDetail = new PolicyDetails();
			
			StringTokenizer st = new StringTokenizer(temp,NGEConstants.GENERICDELIMITER);
			
			if(st.hasMoreTokens())
			{
				policyID = st.nextToken();
				policyDetail.setPolicyID(policyID);
			}
			
			if(st.hasMoreTokens())
			{
				policyNo = st.nextToken();
				policyDetail.setPolicyNo(policyNo);
			}
			if(st.hasMoreTokens())
			{
				issuingCompanyCd = st.nextToken();
				policyDetail.setIssuingCompanyCd(Integer.parseInt(issuingCompanyCd));
			}
			
			if(st.hasMoreTokens())
			{
				premiumAm = new BigDecimal(st.nextToken());
				policyDetail.setPremiumAm(premiumAm);
			}
			
			if(st.hasMoreTokens())
			{
				policyTypeNm = st.nextToken();
				policyDetail.setPolicyTypeNm(policyTypeNm);
			}
			
			if(st.hasMoreTokens())
			{
				currencyCd = st.nextToken();
				policyDetail.setCurrencyCd(currencyCd);
			}
			
			if(st.hasMoreTokens())
			{
				localCurrencyPremiumAm = new BigDecimal(st.nextToken());
				policyDetail.setLocalCurrencyPremiumAm(localCurrencyPremiumAm);
			}
			
			if(st.hasMoreTokens())
			{
				try {
					effectiveDate = st.nextToken();
					effectiveDate = effectiveDate.replace(NGEConstants.DATEREPLACER, NGEConstants.DATEDELIMITER);
					//logger.debug("effectiveDate : "+effectiveDate);
					policyDetail.setEffectiveDate(NGEDateUtil.convertStringToDate(effectiveDate));
				} catch (AIGCIExceptionMsg e) {
					// TODO Auto-generated catch block
					//logger.debug("Exception : " +e.getMessage());
				}
				
			}
			
			if(st.hasMoreTokens())
			{
				try {
					expirationDate = st.nextToken();
					expirationDate = expirationDate.replace(NGEConstants.DATEREPLACER, NGEConstants.DATEDELIMITER);
					policyDetail.setExpirationDate(NGEDateUtil.convertStringToDate(expirationDate));
				} catch (AIGCIExceptionMsg e) {
					// TODO Auto-generated catch block
					//logger.debug("Exception : " +e.getMessage());
				}
				
			}
			
			for(String temp1 : getUniqueValues(this.policyAtrbt))
			{
				StringTokenizer st1 = new StringTokenizer(temp1,NGEConstants.GENERICDELIMITER);
				
				if(st1.hasMoreTokens())
				{
					policyID = st1.nextToken();
				}

				if(policyID.equalsIgnoreCase(String.valueOf(policyDetail.getPolicyID())))
				{
					PolicyAttributeDetails policyAttributeDetails1 = new PolicyAttributeDetails();
					if(st1.hasMoreTokens())
					{
						attributeId = st1.nextToken();
						policyAttributeDetails1.setAttributeId(Short.valueOf(attributeId));
					}
					if(st1.hasMoreTokens())
					{
						attributeVal = st1.nextToken();
						policyAttributeDetails1.setAttributeVal(attributeVal);	
					}
					policyDetail.getPolicyAttributeDetails().add(policyAttributeDetails1);
				}
			}
			
			
			policyDetailsList.add(policyDetail);
			
			
		}
		
		return policyDetailsList;
	}*/

	public List<TransactionPartyDetails> getTransactionPartyDetails() {
		
		String roleNm = null;
		String partyNo = null;
		String partyTypeNm = null;
		
		String ultimatePartyNo = null;
		String relatedPartyTypeNm = null;

		List<TransactionPartyDetails> transactionPartyDetailsList = new ArrayList<TransactionPartyDetails>();
		//logger.debug("transactionParty : "+this.transactionParty);
		for(String temp : getUniqueValues(this.transactionParty))
		{
			//logger.debug("temp : "+temp);
			TransactionPartyDetails transactionPartyDetails = new TransactionPartyDetails();
			StringTokenizer st = new StringTokenizer(temp,NGEConstants.GENERICDELIMITER);
			
			if(st.hasMoreTokens())
			{
				roleNm = st.nextToken();
				transactionPartyDetails.setRoleNm(roleNm);
			}
			if(st.hasMoreTokens())
			{
				partyNo = st.nextToken();
				transactionPartyDetails.setPartyNo(partyNo);
			}
			if(st.hasMoreTokens())
			{
				partyTypeNm = st.nextToken();
				transactionPartyDetails.setPartyTypeNm(partyTypeNm);
			}
			
			// To get transaction additional insured ultimate DUNS
			if(st.hasMoreTokens()){
				
				ultimatePartyNo = st.nextToken();
				transactionPartyDetails.setUltimatePartyNo(ultimatePartyNo);
			}
			if(st.hasMoreTokens()){
				
				relatedPartyTypeNm = st.nextToken();
				transactionPartyDetails.setRelatedPartyTypeNm(relatedPartyTypeNm);
			}
				
			transactionPartyDetailsList.add(transactionPartyDetails);
		}
		
		return transactionPartyDetailsList;
	}
	
	public List<RelatedPartyDetails> getRelatedPartyDetails() {
		
		String relationTypeNm = null;
		String relatedPartyNo = null;
		
		List<RelatedPartyDetails> relatedPartyList = new ArrayList<RelatedPartyDetails>();
		//logger.debug("relatedParty : "+this.relatedParty);
		for(String temp : getUniqueValues(this.relatedParty))
		{
			//logger.debug("temp : "+temp);
			RelatedPartyDetails relatedPartyDetails = new RelatedPartyDetails();
			StringTokenizer st = new StringTokenizer(temp,NGEConstants.GENERICDELIMITER);
			
			if(st.hasMoreTokens())
			{
				relationTypeNm = st.nextToken();
				relatedPartyDetails.setRelationTypeNm(relationTypeNm);
			}
			if(st.hasMoreTokens())
			{
				relatedPartyNo = st.nextToken();
				relatedPartyDetails.setRelatedPartyNo(relatedPartyNo);
			}
			if(st.hasMoreTokens())
			{
				st.nextToken();
			}
			
			relatedPartyList.add(relatedPartyDetails);
		}
		
		return relatedPartyList;
	}

	public DNBAccountDetails getDNBAccountDetails() {
		
		String accountNm = null;
		String multiNationalIn = null;
		DNBAccountDetails dnbAccountDetails = new DNBAccountDetails();
		
		//logger.debug("dnbAccountName : "+this.dnbAccountName);
		for(String temp : getUniqueValues(this.dnbAccountName))
		{
			//logger.debug("temp : "+temp);
			
			StringTokenizer st = new StringTokenizer(temp,NGEConstants.GENERICDELIMITER);
			
				
			if(st.hasMoreTokens())
			{
				accountNm = st.nextToken();
				dnbAccountDetails.setDnbAccountNm(accountNm);
			}
			if(st.hasMoreTokens())
			{
				multiNationalIn = st.nextToken();
				dnbAccountDetails.setDnbAccountMultiNationalIn(multiNationalIn);
			}
			
			//logger.debug(accountNm+" - "+multiNationalIn);
				
		}
		
		return dnbAccountDetails;
	}
	
	public List<LimitDetails> getLimitDetails() {
		
		String currency = null;
		String limitAmount = null;
		String attachmentPointAm = null;
		String premiumAmount = null;
		String technicalPriceAmount = null;
		String expiringPremiumAmout = null;
		
		List<LimitDetails> limitDetailsList = new ArrayList<LimitDetails>();
		//logger.debug("basicLimits : "+this.attachmentPoint);
		for(String temp : getUniqueValues(this.attachmentPoint))
		{
			//logger.debug("temp : "+temp);
			LimitDetails limitDetails = new LimitDetails();
			StringTokenizer st = new StringTokenizer(temp,NGEConstants.GENERICDELIMITER);
				
			if(st.hasMoreTokens())
			{
				currency = st.nextToken();
				limitDetails.setCurrency(currency);
			}
			if(st.hasMoreTokens())
			{
				attachmentPointAm = st.nextToken();
				limitDetails.setAttachmentPointAm(new BigDecimal(attachmentPointAm));
			}
			
			//logger.debug("currency : "+currency);

		//	logger.debug("attachmentPointAm : "+attachmentPointAm);
			
			
			
			for(String temp1 : getUniqueValues(this.limitAmt))
			{
				StringTokenizer st1 = new StringTokenizer(temp1,NGEConstants.GENERICDELIMITER);
									
				if(st1.hasMoreTokens())
				{
					currency = st1.nextToken();
				}
				if(st1.hasMoreTokens())
				{
					limitAmount = st1.nextToken();
				}
				
				if(currency.equalsIgnoreCase(limitDetails.getCurrency()))
				{
					//logger.debug("limitAmount : "+limitAmount);
					limitDetails.setLimitAmt(new BigDecimal(limitAmount));
				}
				
			}
			
			for(String temp1 : getUniqueValues(this.premiumAmt))
			{
				StringTokenizer st1 = new StringTokenizer(temp1,NGEConstants.GENERICDELIMITER);
				
				if(st1.hasMoreTokens())
				{
					currency = st1.nextToken();
				}
				if(st1.hasMoreTokens())
				{
					premiumAmount = st1.nextToken();
				}
				
				if(currency.equalsIgnoreCase(limitDetails.getCurrency()))
				{
					//logger.debug("premiumAmount : "+premiumAmount);
					limitDetails.setPremiumAmount(new BigDecimal(premiumAmount));
				}
				
			}
			
			for(String temp1 : getUniqueValues(this.technicalPriceAmt))
			{
				StringTokenizer st1 = new StringTokenizer(temp1,NGEConstants.GENERICDELIMITER);
				
				if(st1.hasMoreTokens())
				{
					currency = st1.nextToken();
				}
				if(st1.hasMoreTokens())
				{
					technicalPriceAmount = st1.nextToken();
				}
				
				if(currency.equalsIgnoreCase(limitDetails.getCurrency()))
				{
					//logger.debug("technicalPriceAmount : "+technicalPriceAmount);
					limitDetails.setTechnicalPriceAmount(new BigDecimal(technicalPriceAmount));
				}
			}
			
			for(String temp1 : getUniqueValues(this.expiringPremiumAmt))
			{
				StringTokenizer st1 = new StringTokenizer(temp1,NGEConstants.GENERICDELIMITER);
									 
				if(st1.hasMoreTokens())
				{
					currency = st1.nextToken();
				}
				if(st1.hasMoreTokens())
				{
					expiringPremiumAmout = st1.nextToken();
				}
				
				if(currency.equalsIgnoreCase(limitDetails.getCurrency()))
				{
					//logger.debug("expiringPremiumAmout : "+expiringPremiumAmout);
					limitDetails.setExpiringPremiumAmout(new BigDecimal(expiringPremiumAmout));
				}					
			}
		     
			limitDetailsList.add(limitDetails);
		}
		
		return limitDetailsList;
	}


	public class RelatedTransactionAndComponentDetails {
		
		private String relatedTransactionID;
		private String relatedTransactionComponentId;
		private String relationTypeNm;
		
		public String getRelatedTransactionID() {
			return relatedTransactionID;
		}
		public void setRelatedTransactionID(String relatedTransactionID) {
			this.relatedTransactionID = relatedTransactionID;
		}
		public String getRelatedTransactionComponentId() {
			return relatedTransactionComponentId;
		}
		public void setRelatedTransactionComponentId(
				String relatedTransactionComponentId) {
			this.relatedTransactionComponentId = relatedTransactionComponentId;
		}
		public String getRelationTypeNm() {
			return relationTypeNm;
		}
		public void setRelationTypeNm(String relationTypeNm) {
			this.relationTypeNm = relationTypeNm;
		}
		
		
	}
	
	public List<RelatedTransactionAndComponentDetails> getRelatedTransactionAndComponentDetails() {
		
		String transactionID = null;
		String transactionComponentID = null;
		String relationTypeNm = null;

		List<RelatedTransactionAndComponentDetails> relatedTransactionAndComponentList = new ArrayList<RelatedTransactionAndComponentDetails>();
		//logger.debug("relatedTransactionId : "+this.relatedTransactionId);
		for(String temp : getUniqueValues(this.relatedTransactionId))
		{
			//logger.debug("temp : "+temp);
			RelatedTransactionAndComponentDetails relatedTransactionAndComponentDetails = new RelatedTransactionAndComponentDetails();
			StringTokenizer st = new StringTokenizer(temp,NGEConstants.GENERICDELIMITER);
			  
				if(st.hasMoreTokens())
	 			{
					transactionID = st.nextToken();
					relatedTransactionAndComponentDetails.setRelatedTransactionID(transactionID);
	 			}
				if(st.hasMoreTokens())
	 			{
					transactionComponentID = st.nextToken();
					relatedTransactionAndComponentDetails.setRelatedTransactionComponentId(transactionComponentID);
	 			}
				if(st.hasMoreTokens())
	 			{
					relationTypeNm = st.nextToken();
					relatedTransactionAndComponentDetails.setRelationTypeNm(relationTypeNm);
	 			}
				
				relatedTransactionAndComponentList.add(relatedTransactionAndComponentDetails);
		}
		
		return relatedTransactionAndComponentList;
	}
	
	//Added for getSubmission isRenewed Flag
	public List<RelatedTransactionAndComponentDetails> checkForRenewedProducts() {
		
		String transactionID = null;
		String transactionComponentID = null;
		String relationTypeNm = null;

		List<RelatedTransactionAndComponentDetails> relatedTransactionAndComponentList = new ArrayList<RelatedTransactionAndComponentDetails>();
		//logger.debug("relatedTransactionId : "+this.relatedTransactionId);
		for(String temp : getUniqueValues(this.isRenewedCheck))
		{
			//logger.debug("temp : "+temp);
			RelatedTransactionAndComponentDetails relatedTransactionAndComponentDetails = new RelatedTransactionAndComponentDetails();
			StringTokenizer st = new StringTokenizer(temp,NGEConstants.GENERICDELIMITER);
			  
				if(st.hasMoreTokens())
	 			{
					transactionID = st.nextToken();
					relatedTransactionAndComponentDetails.setRelatedTransactionID(transactionID);
	 			}
				if(st.hasMoreTokens())
	 			{
					transactionComponentID = st.nextToken();
					relatedTransactionAndComponentDetails.setRelatedTransactionComponentId(transactionComponentID);
	 			}
				if(st.hasMoreTokens())
	 			{
					relationTypeNm = st.nextToken();
					relatedTransactionAndComponentDetails.setRelationTypeNm(relationTypeNm);
	 			}
				
				relatedTransactionAndComponentList.add(relatedTransactionAndComponentDetails);
		}
		
		return relatedTransactionAndComponentList;
	}
	
	public List<BranchDetails> getBranchDetails() {
				
		String branchTypeNm = null;
		Short branchID = null;
		
		List<BranchDetails> branchDetailsList = new ArrayList<BranchDetails>();
		
		for(String branch : getUniqueValues(this.branchId))
		{
			StringTokenizer st = new StringTokenizer(branch,NGEConstants.GENERICDELIMITER);
			BranchDetails branchDetails = new BranchDetails();
			
			if(st.hasMoreTokens())
			{
				branchTypeNm = st.nextToken();
				branchDetails.setBranchTypeNm(branchTypeNm);
			}
			
			if(st.hasMoreTokens())
       	 	{
       		 	branchID = Short.valueOf(st.nextToken());
       		 	branchDetails.setBranchID(branchID);
			}
			
			branchDetailsList.add(branchDetails);
		}

		return branchDetailsList;
	}
	
	public List<StatusDetails> getStatusDetails() {
		
		String statusTypeNm = null;
		Short statusID = null;
		
		String attributeId = null;
		String attributeVal = null;
		
		List<StatusDetails> statusDetailsList = new ArrayList<StatusDetails>();
		
		for(String status : getUniqueValues(this.statusId))
		{
			StringTokenizer st = new StringTokenizer(status,NGEConstants.GENERICDELIMITER);
			StatusDetails statusDetails = new StatusDetails();
			  				
			if(st.hasMoreTokens())
			{
				statusTypeNm = st.nextToken();
				statusDetails.setStatusTypeNm(statusTypeNm);
			}
			if(st.hasMoreTokens())
			{
				statusID = Short.valueOf(st.nextToken());
				statusDetails.setStatusId(statusID);
			}
			
			for(String reason : getUniqueValues(this.statusWithReason))
			{
				StringTokenizer st1 = new StringTokenizer(reason,NGEConstants.GENERICDELIMITER);
				String reasonId = null;
				 
				if(st1.hasMoreTokens())
				{
					statusID = Short.valueOf(st1.nextToken());
				}
				if(st1.hasMoreTokens())
				{
					reasonId = st1.nextToken();
				}
				
				if(statusID == statusDetails.getStatusId())
				{
					//logger.debug("reasonId : "+reasonId);
					statusDetails.setReasonID(Short.valueOf(reasonId));
					break;
				}
			}
			
			for(String comments : getUniqueValues(this.statusWithComments))
			{
				StringTokenizer st1 = new StringTokenizer(comments,NGEConstants.GENERICDELIMITER);
				String commentTx = null;
				 
				if(st1.hasMoreTokens())
				{
					statusID = Short.valueOf(st1.nextToken());
				}
				if(st1.hasMoreTokens())
				{
					commentTx = st1.nextToken();
				}
				
				if(statusID == statusDetails.getStatusId())
				{
					//logger.debug("commentTx : "+commentTx);
					statusDetails.setCommentTx(commentTx);
					break;
				}
			}
			
			for(String temp1 : getUniqueValues(this.statusAttributes))
			{
				StringTokenizer st1 = new StringTokenizer(temp1,NGEConstants.GENERICDELIMITER);

				StatusAttributeDetails statusAttributeDetails = new StatusAttributeDetails();
				if(st1.hasMoreTokens())
				{
					attributeId = st1.nextToken();
					statusAttributeDetails.setAttributeId(Short.valueOf(attributeId));
				}
				if(st1.hasMoreTokens())
				{
					attributeVal = st1.nextToken();
					statusAttributeDetails.setAttributeVal(attributeVal);	
				}
				statusDetails.getStatusAttributeDetails().add(statusAttributeDetails);
			}
			statusDetailsList.add(statusDetails);	         
		}

		return statusDetailsList;
	}
	
	public List<ComponentPartyDetails> getComponentAdditionalPartyDetails() {
		
		String roleNm = null;
		String partyNo = null;
		String partyTypeNm = null;
		String accountNm = null;
		
		String ultimatePartyNo = null;
		String relatedPartyTypeNm = null;

		List<ComponentPartyDetails> transactionPartyDetailsList = new ArrayList<ComponentPartyDetails>();
		//logger.debug("getComponentAdditionalPartyDetails : "+this.partyId);
		//logger.debug("getUniqueValues(this.partyId) : "+getUniqueValues(this.partyId));
		for(String temp : getUniqueValues(this.partyId))
		{
			//logger.debug("temp : "+temp);
			ComponentPartyDetails transactionPartyDetails = new ComponentPartyDetails();
			StringTokenizer st = new StringTokenizer(temp,NGEConstants.GENERICDELIMITER);
			  
				if(st.hasMoreTokens())
	 			{
					roleNm = st.nextToken();
					transactionPartyDetails.setRoleNm(roleNm);
	 			}
				if(st.hasMoreTokens())
	 			{
					partyNo = st.nextToken();
					transactionPartyDetails.setPartyNo(partyNo);
	 			}
				if(st.hasMoreTokens())
	 			{
					partyTypeNm = st.nextToken();
					transactionPartyDetails.setPartyTypeNm(partyTypeNm);
	 			}
				if(st.hasMoreTokens())
	 			{
					accountNm = st.nextToken();
					transactionPartyDetails.setAccountNm(accountNm);
	 			}
				
				// To get transaction additional insured ultimate DUNS
				if(st.hasMoreTokens()){
					
					ultimatePartyNo = st.nextToken();
					transactionPartyDetails.setUltimatePartyNo(ultimatePartyNo);
				}
				if(st.hasMoreTokens()){
					
					relatedPartyTypeNm = st.nextToken();
					transactionPartyDetails.setRelatedPartyTypeNm(relatedPartyTypeNm);
				}
				
				
			transactionPartyDetailsList.add(transactionPartyDetails);
		}
		
		return transactionPartyDetailsList;
	}
	
	/*public List<WIPQuoteDetails> getWIPQuoteDetails() {
		
		String wipId = null;
		String quoteSqn = null;
		String wipStatusCd = null;
		String wipStatusEnteredDt = null;
		String quoteAcceptedIn = null;
		String nonRenewalIn = null;
		String systemId = null;
		String currencyId = null;
		String sectionCd = null;
		String profitUnitCd = null;
		String winningCarrierNm = null;
		String lossrsn = null;
		String quoteEffectedDt = null;
		String quoteExpirationDt = null;
		String reasonCd = null;
		String policyEventNo = null;
		String policyId = null;
		String priorPolicyId = null;
		String quotedPremiumAmt = null;
		String quoteLimitAmt = null;
		String quoteAttachmentPointAmt = null;
		
		String masterContractNo = null;
		String accountLegalNm = null;
		String accountPolNo = null;
		String accountPolPrfxCd = null;
		String nonRenewalReasonCd = null;
		String policyMailedDt = null;
		
		String policyAttachmentPointAmt = null;
		String policyLimitAmt = null;
		String policyPartOfAmt = null;
		
		
		List<WIPQuoteDetails> wipQuoteDetailsList = new ArrayList<WIPQuoteDetails>();
		
		for(String status : getUniqueValues(this.wipQuoteDetails))
		{
			StringTokenizer st = new StringTokenizer(status,NGEConstants.GENERICDELIMITER);
			WIPQuoteDetails wipQuote = new WIPQuoteDetails();
			  				
			if(st.hasMoreTokens())
			{
				wipId = st.nextToken();
				wipQuote.setWipId(wipId);
			}
			if(st.hasMoreTokens())
			{
				quoteSqn = st.nextToken();
				wipQuote.setQuoteSqn(Short.valueOf(quoteSqn));
			}
			if(st.hasMoreTokens())
			{
				wipStatusCd = st.nextToken();
				wipQuote.setWipStatusCd(wipStatusCd);
			}
			if(st.hasMoreTokens())
			{
				wipStatusEnteredDt = st.nextToken();
				
				wipStatusEnteredDt = wipStatusEnteredDt.replace(dateReplacer, dateDelimiter);
				try {
					wipQuote.setWipStatusEnteredDt(NGEDateUtil.convertStringToDate(wipStatusEnteredDt));
				} catch (AIGCIExceptionMsg e) {
					// TODO Auto-generated catch block
					logger.debug("Exception : " +e.getMessage());
				}
			}
			if(st.hasMoreTokens())
			{
				quoteAcceptedIn = st.nextToken();
				wipQuote.setQuoteAcceptedIn(quoteAcceptedIn);
			}
			if(st.hasMoreTokens())
			{
				nonRenewalIn = st.nextToken();
				wipQuote.setNonRenewalIn(nonRenewalIn);
			}
			if(st.hasMoreTokens())
			{
				systemId = st.nextToken();
				wipQuote.setSystemId(systemId);
			}
					
			
			for(String temp : getUniqueValues(this.wipQuoteSectionCd))
			{
				StringTokenizer st1 = new StringTokenizer(temp,NGEConstants.GENERICDELIMITER);
								 
				if(st1.hasMoreTokens())
				{
					wipId = st1.nextToken();
				}
				if(st1.hasMoreTokens())
				{
					quoteSqn = st1.nextToken();
				}
				if(st1.hasMoreTokens())
				{
					sectionCd = st1.nextToken();
				}
				
				if(wipQuote.getWipId().equalsIgnoreCase(wipId) && String.valueOf(wipQuote.getQuoteSqn()).equalsIgnoreCase(quoteSqn))
				{
					wipQuote.setSectionCd(Short.valueOf(sectionCd));
					break;
				}
			}
			
			for(String temp : getUniqueValues(this.wipQuoteProfitUnitCd))
			{
				StringTokenizer st1 = new StringTokenizer(temp,NGEConstants.GENERICDELIMITER);
								 
				if(st1.hasMoreTokens())
				{
					wipId = st1.nextToken();
				}
				if(st1.hasMoreTokens())
				{
					quoteSqn = st1.nextToken();
				}
				if(st1.hasMoreTokens())
				{
					profitUnitCd = st1.nextToken();
				}
				
				if(wipQuote.getWipId().equalsIgnoreCase(wipId) && String.valueOf(wipQuote.getQuoteSqn()).equalsIgnoreCase(quoteSqn))
				{
					wipQuote.setProfitUnitCd(Short.valueOf(profitUnitCd));
					break;
				}
			}
			
			for(String temp : getUniqueValues(this.wipQuoteWinningCarrierNm))
			{
				StringTokenizer st1 = new StringTokenizer(temp,NGEConstants.GENERICDELIMITER);
								 
				if(st1.hasMoreTokens())
				{
					wipId = st1.nextToken();
				}
				if(st1.hasMoreTokens())
				{
					quoteSqn = st1.nextToken();
				}
				if(st1.hasMoreTokens())
				{
					winningCarrierNm = st1.nextToken();
				}
				
				if(wipQuote.getWipId().equalsIgnoreCase(wipId) && String.valueOf(wipQuote.getQuoteSqn()).equalsIgnoreCase(quoteSqn))
				{
					wipQuote.setWinningCarrierNm(winningCarrierNm);
					break;
				}
			}
			
			for(String temp : getUniqueValues(this.wipQuoteLossrsn))
			{
				StringTokenizer st1 = new StringTokenizer(temp,NGEConstants.GENERICDELIMITER);
								 
				if(st1.hasMoreTokens())
				{
					wipId = st1.nextToken();
				}
				if(st1.hasMoreTokens())
				{
					quoteSqn = st1.nextToken();
				}
				if(st1.hasMoreTokens())
				{
					lossrsn = st1.nextToken();
				}
				
				if(wipQuote.getWipId().equalsIgnoreCase(wipId) && String.valueOf(wipQuote.getQuoteSqn()).equalsIgnoreCase(quoteSqn))
				{
					wipQuote.setLossrsn(lossrsn);
					break;
				}
			}
			
			for(String temp : getUniqueValues(this.wipQuoteQuoteEffectiveDt))
			{
				StringTokenizer st1 = new StringTokenizer(temp,NGEConstants.GENERICDELIMITER);
								 
				if(st1.hasMoreTokens())
				{
					wipId = st1.nextToken();
				}
				if(st1.hasMoreTokens())
				{
					quoteSqn = st1.nextToken();
				}
				if(st1.hasMoreTokens())
				{
					quoteEffectedDt = st1.nextToken();
				}
				
				if(wipQuote.getWipId().equalsIgnoreCase(wipId) && String.valueOf(wipQuote.getQuoteSqn()).equalsIgnoreCase(quoteSqn))
				{					
					quoteEffectedDt = quoteEffectedDt.replace(dateReplacer, dateDelimiter);
					try {
						wipQuote.setQuoteEffectedDt(NGEDateUtil.convertStringToDate(quoteEffectedDt));
					} catch (AIGCIExceptionMsg e) {
						// TODO Auto-generated catch block
						logger.debug("Exception : " +e.getMessage());
					}
					break;
				}
			}
			
			for(String temp : getUniqueValues(this.wipQuoteQuoteExpirationDt))
			{
				StringTokenizer st1 = new StringTokenizer(temp,NGEConstants.GENERICDELIMITER);
								 
				if(st1.hasMoreTokens())
				{
					wipId = st1.nextToken();
				}
				if(st1.hasMoreTokens())
				{
					quoteSqn = st1.nextToken();
				}
				if(st1.hasMoreTokens())
				{
					quoteExpirationDt = st1.nextToken();
				}
				
				if(wipQuote.getWipId().equalsIgnoreCase(wipId) && String.valueOf(wipQuote.getQuoteSqn()).equalsIgnoreCase(quoteSqn))
				{					
					quoteExpirationDt = quoteExpirationDt.replace(dateReplacer, dateDelimiter);
					try {
						wipQuote.setQuoteExpirationDt(NGEDateUtil.convertStringToDate(quoteExpirationDt));
					} catch (AIGCIExceptionMsg e) {
						// TODO Auto-generated catch block
						logger.debug("Exception : " +e.getMessage());
					}
					break;
				}
			}
			
			for(String temp : getUniqueValues(this.wipQuoteReasonCd))
			{
				StringTokenizer st1 = new StringTokenizer(temp,NGEConstants.GENERICDELIMITER);
								 
				if(st1.hasMoreTokens())
				{
					wipId = st1.nextToken();
				}
				if(st1.hasMoreTokens())
				{
					quoteSqn = st1.nextToken();
				}
				if(st1.hasMoreTokens())
				{
					reasonCd = st1.nextToken();
				}
				
				if(wipQuote.getWipId().equalsIgnoreCase(wipId) && String.valueOf(wipQuote.getQuoteSqn()).equalsIgnoreCase(quoteSqn))
				{
					wipQuote.setReasonCd(reasonCd);
					break;
				}
			}
			
			for(String temp : getUniqueValues(this.wipQuotePolEventNo))
			{
				StringTokenizer st1 = new StringTokenizer(temp,NGEConstants.GENERICDELIMITER);
								 
				if(st1.hasMoreTokens())
				{
					wipId = st1.nextToken();
				}
				if(st1.hasMoreTokens())
				{
					quoteSqn = st1.nextToken();
				}
				if(st1.hasMoreTokens())
				{
					policyEventNo = st1.nextToken();
				}
				
				if(wipQuote.getWipId().equalsIgnoreCase(wipId) && String.valueOf(wipQuote.getQuoteSqn()).equalsIgnoreCase(quoteSqn))
				{
					wipQuote.setPolicyEventNo(Short.valueOf(policyEventNo));
					break;
				}
			}
			
			for(String temp : getUniqueValues(this.wipQuotePolicyId))
			{
				StringTokenizer st1 = new StringTokenizer(temp,NGEConstants.GENERICDELIMITER);
								 
				if(st1.hasMoreTokens())
				{
					wipId = st1.nextToken();
				}
				if(st1.hasMoreTokens())
				{
					quoteSqn = st1.nextToken();
				}
				if(st1.hasMoreTokens())
				{
					policyId = st1.nextToken();
				}
				
				if(wipQuote.getWipId().equalsIgnoreCase(wipId) && String.valueOf(wipQuote.getQuoteSqn()).equalsIgnoreCase(quoteSqn))
				{
					wipQuote.setPolicyId(Integer.valueOf(policyId));
					break;
				}
			}
			
			for(String temp : getUniqueValues(this.wipQuotePriorPolicyId))
			{
				StringTokenizer st1 = new StringTokenizer(temp,NGEConstants.GENERICDELIMITER);
								 
				if(st1.hasMoreTokens())
				{
					wipId = st1.nextToken();
				}
				if(st1.hasMoreTokens())
				{
					quoteSqn = st1.nextToken();
				}
				if(st1.hasMoreTokens())
				{
					priorPolicyId = st1.nextToken();
				}
				
				if(wipQuote.getWipId().equalsIgnoreCase(wipId) && String.valueOf(wipQuote.getQuoteSqn()).equalsIgnoreCase(quoteSqn))
				{
					wipQuote.setPriorPolicyId(Integer.valueOf(priorPolicyId));
					break;
				}
			}
			
			for(String temp : getUniqueValues(this.wipQuoteMasterContractNo))
			{
				StringTokenizer st1 = new StringTokenizer(temp,NGEConstants.GENERICDELIMITER);
								 
				if(st1.hasMoreTokens())
				{
					wipId = st1.nextToken();
				}
				if(st1.hasMoreTokens())
				{
					quoteSqn = st1.nextToken();
				}
				if(st1.hasMoreTokens())
				{
					masterContractNo = st1.nextToken();
				}
				
				if(wipQuote.getWipId().equalsIgnoreCase(wipId) && String.valueOf(wipQuote.getQuoteSqn()).equalsIgnoreCase(quoteSqn))
				{
					wipQuote.setMasterContractNo(masterContractNo);
					break;
				}
			}
			
			for(String temp : getUniqueValues(this.wipQuoteAccountLegalNm))
			{
				StringTokenizer st1 = new StringTokenizer(temp,NGEConstants.GENERICDELIMITER);
								 
				if(st1.hasMoreTokens())
				{
					wipId = st1.nextToken();
				}
				if(st1.hasMoreTokens())
				{
					quoteSqn = st1.nextToken();
				}
				if(st1.hasMoreTokens())
				{
					accountLegalNm = st1.nextToken();
				}
				
				if(wipQuote.getWipId().equalsIgnoreCase(wipId) && String.valueOf(wipQuote.getQuoteSqn()).equalsIgnoreCase(quoteSqn))
				{
					wipQuote.setAccountLegalNm(accountLegalNm);
					break;
				}
			}
			
			for(String temp : getUniqueValues(this.wipQuoteAccountPolNo))
			{
				StringTokenizer st1 = new StringTokenizer(temp,NGEConstants.GENERICDELIMITER);
								 
				if(st1.hasMoreTokens())
				{
					wipId = st1.nextToken();
				}
				if(st1.hasMoreTokens())
				{
					quoteSqn = st1.nextToken();
				}
				if(st1.hasMoreTokens())
				{
					accountPolNo = st1.nextToken();
				}
				
				if(wipQuote.getWipId().equalsIgnoreCase(wipId) && String.valueOf(wipQuote.getQuoteSqn()).equalsIgnoreCase(quoteSqn))
				{
					wipQuote.setAccountPolNo(Integer.valueOf(accountPolNo));
					break;
				}
			}
			
			for(String temp : getUniqueValues(this.wipQuoteAccountPolPrfxCd))
			{
				StringTokenizer st1 = new StringTokenizer(temp,NGEConstants.GENERICDELIMITER);
								 
				if(st1.hasMoreTokens())
				{
					wipId = st1.nextToken();
				}
				if(st1.hasMoreTokens())
				{
					quoteSqn = st1.nextToken();
				}
				if(st1.hasMoreTokens())
				{
					accountPolPrfxCd = st1.nextToken();
				}
				
				if(wipQuote.getWipId().equalsIgnoreCase(wipId) && String.valueOf(wipQuote.getQuoteSqn()).equalsIgnoreCase(quoteSqn))
				{
					wipQuote.setAccountPolPrfxCd(accountPolPrfxCd);
					break;
				}
			}
			
			for(String temp : getUniqueValues(this.wipQuoteNonRenewalReasonCd))
			{
				StringTokenizer st1 = new StringTokenizer(temp,NGEConstants.GENERICDELIMITER);
								 
				if(st1.hasMoreTokens())
				{
					wipId = st1.nextToken();
				}
				if(st1.hasMoreTokens())
				{
					quoteSqn = st1.nextToken();
				}
				if(st1.hasMoreTokens())
				{
					nonRenewalReasonCd = st1.nextToken();
				}
				
				if(wipQuote.getWipId().equalsIgnoreCase(wipId) && String.valueOf(wipQuote.getQuoteSqn()).equalsIgnoreCase(quoteSqn))
				{
					wipQuote.setNonRenewalReasonCd(nonRenewalReasonCd);
					break;
				}
			}
			
			for(String temp : getUniqueValues(this.wipQuotePolicyMailedDt))
			{
				StringTokenizer st1 = new StringTokenizer(temp,NGEConstants.GENERICDELIMITER);
								 
				if(st1.hasMoreTokens())
				{
					wipId = st1.nextToken();
				}
				if(st1.hasMoreTokens())
				{
					quoteSqn = st1.nextToken();
				}
				if(st1.hasMoreTokens())
				{
					policyMailedDt = st1.nextToken();
				}
				
				if(wipQuote.getWipId().equalsIgnoreCase(wipId) && String.valueOf(wipQuote.getQuoteSqn()).equalsIgnoreCase(quoteSqn))
				{
					policyMailedDt = policyMailedDt.replace(dateReplacer, dateDelimiter);
					try {
						wipQuote.setPolicyMailedDt(NGEDateUtil.convertStringToDate(policyMailedDt));
					} catch (AIGCIExceptionMsg e) {
						// TODO Auto-generated catch block
						logger.debug("Exception : " +e.getMessage());
					}
					break;
				}
			}
			
			for(String temp : getUniqueValues(this.wipQuoteCurrencyId))
			{
				StringTokenizer st1 = new StringTokenizer(temp,NGEConstants.GENERICDELIMITER);
								 
				if(st1.hasMoreTokens())
				{
					wipId = st1.nextToken();
				}
				if(st1.hasMoreTokens())
				{
					quoteSqn = st1.nextToken();
				}
				if(st1.hasMoreTokens())
				{
					currencyId = st1.nextToken();
				}
				
				if(wipQuote.getWipId().equalsIgnoreCase(wipId) && String.valueOf(wipQuote.getQuoteSqn()).equalsIgnoreCase(quoteSqn))
				{
					WIPQuoteCurrencyDetails wipQuoteCurrencyDetails = new WIPQuoteCurrencyDetails();
					wipQuoteCurrencyDetails.setCurrencyId(Short.valueOf(currencyId));
					logger.debug("this.wipQuoteCurrencyQuotedPremiumAmt : "+this.wipQuoteCurrencyQuotedPremiumAmt);
					for(String temp1 : getUniqueValues(this.wipQuoteCurrencyQuotedPremiumAmt))
					{
						StringTokenizer st2 = new StringTokenizer(temp1,NGEConstants.GENERICDELIMITER);
										 
						if(st2.hasMoreTokens())
						{
							wipId = st2.nextToken();
						}
						if(st2.hasMoreTokens())
						{
							quoteSqn = st2.nextToken();
						}
						if(st2.hasMoreTokens())
						{
							currencyId = st2.nextToken();
						}
						if(st2.hasMoreTokens())
						{
							quotedPremiumAmt = st2.nextToken();
						}
						
						if(String.valueOf(wipQuoteCurrencyDetails.getCurrencyId()).equalsIgnoreCase(currencyId))
						{
							wipQuoteCurrencyDetails.setQuotedPremiumAmt(new BigDecimal(quotedPremiumAmt));
							break;
						}
					}
					logger.debug("this.wipQuoteCurrencyQuotedLimitAmt : "+this.wipQuoteCurrencyQuotedLimitAmt);
					for(String temp1 : getUniqueValues(this.wipQuoteCurrencyQuotedLimitAmt))
					{
						StringTokenizer st2 = new StringTokenizer(temp1,NGEConstants.GENERICDELIMITER);
										 
						if(st2.hasMoreTokens())
						{
							wipId = st2.nextToken();
						}
						if(st2.hasMoreTokens())
						{
							quoteSqn = st2.nextToken();
						}
						if(st2.hasMoreTokens())
						{
							currencyId = st2.nextToken();
						}
						if(st2.hasMoreTokens())
						{
							quoteLimitAmt = st2.nextToken();
						}
						
						if(String.valueOf(wipQuoteCurrencyDetails.getCurrencyId()).equalsIgnoreCase(currencyId))
						{
							wipQuoteCurrencyDetails.setQuoteLimitAmt(new BigDecimal(quoteLimitAmt));
							break;
						}
					}
					logger.debug("this.wipQuoteCurrencyQuotedAttachmentPointAmt : "+this.wipQuoteCurrencyQuotedAttachmentPointAmt);
					for(String temp1 : getUniqueValues(this.wipQuoteCurrencyQuotedAttachmentPointAmt))
					{
						StringTokenizer st2 = new StringTokenizer(temp1,NGEConstants.GENERICDELIMITER);
										 
						if(st2.hasMoreTokens())
						{
							wipId = st2.nextToken();
						}
						if(st2.hasMoreTokens())
						{
							quoteSqn = st2.nextToken();
						}
						if(st2.hasMoreTokens())
						{
							currencyId = st2.nextToken();
						}
						if(st2.hasMoreTokens())
						{
							quoteAttachmentPointAmt = st2.nextToken();
						}
						
						if(String.valueOf(wipQuoteCurrencyDetails.getCurrencyId()).equalsIgnoreCase(currencyId))
						{
							wipQuoteCurrencyDetails.setQuoteAttachmentPointAmt(new BigDecimal(quoteAttachmentPointAmt));
							break;
						}
					}
					logger.debug("this.wipQuoteCurrencyPolicyAttachmentPointAmt : "+this.wipQuoteCurrencyPolicyAttachmentPointAmt);
					for(String temp1 : getUniqueValues(this.wipQuoteCurrencyPolicyAttachmentPointAmt))
					{
						StringTokenizer st2 = new StringTokenizer(temp1,NGEConstants.GENERICDELIMITER);
										 
						if(st2.hasMoreTokens())
						{
							wipId = st2.nextToken();
						}
						if(st2.hasMoreTokens())
						{
							quoteSqn = st2.nextToken();
						}
						if(st2.hasMoreTokens())
						{
							currencyId = st2.nextToken();
						}
						if(st2.hasMoreTokens())
						{
							policyAttachmentPointAmt = st2.nextToken();
						}
						
						if(String.valueOf(wipQuoteCurrencyDetails.getCurrencyId()).equalsIgnoreCase(currencyId))
						{
							wipQuoteCurrencyDetails.setPolicyAttachmentPointAmt(new BigDecimal(policyAttachmentPointAmt));
							break;
						}
					}
					logger.debug("this.wipQuoteCurrencyPolicyLimitAmt : "+this.wipQuoteCurrencyPolicyLimitAmt);
					for(String temp1 : getUniqueValues(this.wipQuoteCurrencyPolicyLimitAmt))
					{
						StringTokenizer st2 = new StringTokenizer(temp1,NGEConstants.GENERICDELIMITER);
										 
						if(st2.hasMoreTokens())
						{
							wipId = st2.nextToken();
						}
						if(st2.hasMoreTokens())
						{
							quoteSqn = st2.nextToken();
						}
						if(st2.hasMoreTokens())
						{
							currencyId = st2.nextToken();
						}
						if(st2.hasMoreTokens())
						{
							policyLimitAmt = st2.nextToken();
						}
						logger.debug("policyLimitAmt : "+policyLimitAmt);
						if(String.valueOf(wipQuoteCurrencyDetails.getCurrencyId()).equalsIgnoreCase(currencyId))
						{
							wipQuoteCurrencyDetails.setPolicyLimitAmt(new BigDecimal(policyLimitAmt));
							break;
						}
					}
					logger.debug("this.wipQuoteCurrencyPolicyPartOfAmt : "+this.wipQuoteCurrencyPolicyPartOfAmt);
					for(String temp1 : getUniqueValues(this.wipQuoteCurrencyPolicyPartOfAmt))
					{
						StringTokenizer st2 = new StringTokenizer(temp1,NGEConstants.GENERICDELIMITER);
										 
						if(st2.hasMoreTokens())
						{
							wipId = st2.nextToken();
						}
						if(st2.hasMoreTokens())
						{
							quoteSqn = st2.nextToken();
						}
						if(st2.hasMoreTokens())
						{
							currencyId = st2.nextToken();
						}
						if(st2.hasMoreTokens())
						{
							policyPartOfAmt = st2.nextToken();
						}
						logger.debug("policyPartOfAmt : "+policyPartOfAmt);
						if(String.valueOf(wipQuoteCurrencyDetails.getCurrencyId()).equalsIgnoreCase(currencyId))
						{
							wipQuoteCurrencyDetails.setPolicyPartOfAmt(new BigDecimal(policyPartOfAmt));
							break;
						}
					}
					
					wipQuote.getWIPQuoteCurrencyDetailsList().add(wipQuoteCurrencyDetails);
				}
			}
			
			
			
			wipQuoteDetailsList.add(wipQuote);	         
		}

		return wipQuoteDetailsList;
	}*/
}
