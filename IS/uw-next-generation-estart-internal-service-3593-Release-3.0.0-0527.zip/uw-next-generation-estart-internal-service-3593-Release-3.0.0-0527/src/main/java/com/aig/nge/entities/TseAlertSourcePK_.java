package com.aig.nge.entities;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-09-11T14:03:54.041+0530")
@StaticMetamodel(TseAlertSourcePK.class)
public class TseAlertSourcePK_ {
	public static volatile SingularAttribute<TseAlertSourcePK, Integer> submissionEvaluationCd;
	public static volatile SingularAttribute<TseAlertSourcePK, String> sourceCd;
}
