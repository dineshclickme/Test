package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.text.DecimalFormat;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the TLEGACY_TRNSCTN_CMPNT_XTENSN database table.
 * 
 */
@Entity
@Table(name="TLEGACY_TRNSCTN_CMPNT_XTENSN")
public class TlegacyTrnsctnCmpntXtensn implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="TRANSACTION_COMPONENT_ID")
	private String transactionComponentId;

	@Column(name="CREATE_TS")
	private Timestamp createTs;

	@Column(name="CREATE_USER_ID")
	private String createUserId;
	@Column(name="CURRNT_BUS_TYP_CD")
	private String currntBusTypCd;
	@Column(name="DECLINE_REASON_CD")
	private String declineReasonCd;

	@Column(name="LEGACY_PRODCT_COVG_TYP_CD")
	private String legacyProdctCovgTypCd;

	@Column(name="LOCAL_PART_OF_AM")
	private BigDecimal localPartOfAm;

	@Column(name="PART_OF_AM")
	private BigDecimal partOfAm;

	@Column(name="PROFIT_CENTER_CD")
	private String profitCenterCd;

	@Column(name="PROFIT_UNIT_CD")
	private short profitUnitCd;

	@Column(name="RR_PRTCTV_CONT_NO")
	private int rrPrtctvContNo;

	@Column(name="SECTION_CD")
	private short sectionCd;

	@Column(name="SOURCE_CD")
	private String sourceCd;

	@Column(name="SPECIAL_EVENT_NM")
	private String specialEventNm;

    @Temporal( TemporalType.DATE)
	@Column(name="UNDERWRITING_DT")
	private Date underwritingDt;

	@Column(name="UPDATE_TS")
	private Timestamp updateTs;

	@Column(name="UPDATE_USER_ID")
	private String updateUserId;

	@Column(name="WORKING_BRANCH_CD")
	private String workingBranchCd;

    @Temporal( TemporalType.DATE)
	@Column(name="XCHANGE_RT_EFCTV_DT")
	private Date xchangeRtEfctvDt;

	@Column(name="LEGACY_PRODUCT_CD")
	private String legacyProductCd;

	//bi-directional many-to-one association to TlegacyProduct
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="LEGACY_PRODUCT_CD")
	private TlegacyProduct tlegacyProduct;

	//bi-directional many-to-one association to TlegacyProductBundling
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumns({
		@JoinColumn(name="LEGACY_BUNDLED_PRODUCT_CD", referencedColumnName="BUNDLED_PRODUCT_CD"),
		@JoinColumn(name="LEGACY_PRODUCT_CD", referencedColumnName="PRODUCT_CD")
		})
	private TlegacyProductBundling tlegacyProductBundling;

	//bi-directional one-to-one association to TtransactionComponent
	@OneToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="TRANSACTION_COMPONENT_ID")
	private TtransactionComponent ttransactionComponent;

    public TlegacyTrnsctnCmpntXtensn() {
    }

	public String getTransactionComponentId() {
		return this.transactionComponentId;
	}

	public void setTransactionComponentId(String transactionComponentId) {
		this.transactionComponentId = transactionComponentId;
	}

	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}
	public String getCurrntBusTypCd() {
		return this.currntBusTypCd;
	}

	public void setCurrntBusTypCd(String currntBusTypCd) {
		this.currntBusTypCd = currntBusTypCd;
	}
	public String getDeclineReasonCd() {
		return this.declineReasonCd;
	}

	public void setDeclineReasonCd(String declineReasonCd) {
		this.declineReasonCd = declineReasonCd;
	}

	public String getLegacyProdctCovgTypCd() {
		return this.legacyProdctCovgTypCd;
	}

	public void setLegacyProdctCovgTypCd(String legacyProdctCovgTypCd) {
		this.legacyProdctCovgTypCd = legacyProdctCovgTypCd;
	}

	public BigDecimal getLocalPartOfAm() {
		/* exadata changes - formatting the decimal field */
		if(this.localPartOfAm != null){
			DecimalFormat df = new DecimalFormat("0.000000");
	    	BigDecimal formattedPremAm = new BigDecimal(df.format(this.localPartOfAm));	
			return formattedPremAm;
		}else{
			return this.localPartOfAm;
		}
	}

	public void setLocalPartOfAm(BigDecimal localPartOfAm) {
		this.localPartOfAm = localPartOfAm;
	}

	public BigDecimal getPartOfAm() {
		/* exadata changes - formatting the decimal field */
		if(this.partOfAm != null){
			DecimalFormat df = new DecimalFormat("0.000000");
	    	BigDecimal formattedPremAm = new BigDecimal(df.format(this.partOfAm));	
			return formattedPremAm;
		}else{
			return this.partOfAm;
		}
	}

	public void setPartOfAm(BigDecimal partOfAm) {
		this.partOfAm = partOfAm;
	}

	public String getProfitCenterCd() {
		return this.profitCenterCd;
	}

	public void setProfitCenterCd(String profitCenterCd) {
		this.profitCenterCd = profitCenterCd;
	}

	public short getProfitUnitCd() {
		return this.profitUnitCd;
	}

	public void setProfitUnitCd(short profitUnitCd) {
		this.profitUnitCd = profitUnitCd;
	}

	public int getRrPrtctvContNo() {
		return this.rrPrtctvContNo;
	}

	public void setRrPrtctvContNo(int rrPrtctvContNo) {
		this.rrPrtctvContNo = rrPrtctvContNo;
	}

	public short getSectionCd() {
		return this.sectionCd;
	}

	public void setSectionCd(short sectionCd) {
		this.sectionCd = sectionCd;
	}

	public String getSourceCd() {
		return this.sourceCd;
	}

	public void setSourceCd(String sourceCd) {
		this.sourceCd = sourceCd;
	}

	public String getSpecialEventNm() {
		return this.specialEventNm;
	}

	public void setSpecialEventNm(String specialEventNm) {
		this.specialEventNm = specialEventNm;
	}

	public Date getUnderwritingDt() {
		return this.underwritingDt;
	}

	public void setUnderwritingDt(Date underwritingDt) {
		this.underwritingDt = underwritingDt;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public String getWorkingBranchCd() {
		return this.workingBranchCd;
	}

	public void setWorkingBranchCd(String workingBranchCd) {
		this.workingBranchCd = workingBranchCd;
	}

	public Date getXchangeRtEfctvDt() {
		return this.xchangeRtEfctvDt;
	}

	public void setXchangeRtEfctvDt(Date xchangeRtEfctvDt) {
		this.xchangeRtEfctvDt = xchangeRtEfctvDt;
	}

	public TlegacyProduct getTlegacyProduct() {
		return this.tlegacyProduct;
	}

	public void setTlegacyProduct(TlegacyProduct tlegacyProduct) {
		this.tlegacyProduct = tlegacyProduct;
	}
	
	public TlegacyProductBundling getTlegacyProductBundling() {
		return this.tlegacyProductBundling;
	}

	public void setTlegacyProductBundling(TlegacyProductBundling tlegacyProductBundling) {
		this.tlegacyProductBundling = tlegacyProductBundling;
	}
	
	public TtransactionComponent getTtransactionComponent() {
		return this.ttransactionComponent;
	}

	public void setTtransactionComponent(TtransactionComponent ttransactionComponent) {
		this.ttransactionComponent = ttransactionComponent;
	}
	
	public String getLegacyProductCd() {
		return legacyProductCd;
	}

	public void setLegacyProductCd(String legacyProductCd) {
		this.legacyProductCd = legacyProductCd;
	}
}