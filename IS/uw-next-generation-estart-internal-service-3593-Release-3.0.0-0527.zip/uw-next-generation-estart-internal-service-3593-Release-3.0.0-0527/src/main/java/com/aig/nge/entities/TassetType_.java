package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SetAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-02-19T16:13:02.910+0530")
@StaticMetamodel(TassetType.class)
public class TassetType_ {
	public static volatile SingularAttribute<TassetType, Integer> assetTypeId;
	public static volatile SingularAttribute<TassetType, String> assetTypeNm;
	public static volatile SingularAttribute<TassetType, Timestamp> createTs;
	public static volatile SingularAttribute<TassetType, String> createUserId;
	public static volatile SingularAttribute<TassetType, Timestamp> updateTs;
	public static volatile SingularAttribute<TassetType, String> updateUserId;
	public static volatile SetAttribute<TassetType, Tasset> tassets;
	public static volatile SetAttribute<TassetType, TassetTypeAttribute> tassetTypeAttributes;
	public static volatile SetAttribute<TassetType, TprdctTwrTuwSbprdctAstTyp> tprdctTwrTuwSbprdctAstTyps;
}
