package com.aig.nge.entities;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.StringTokenizer;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityResult;
import javax.persistence.FieldResult;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.NamedNativeQuery;
import javax.persistence.SqlResultSetMapping;

import com.aig.nge.utilities.NGEConstants;

@Entity
@SqlResultSetMapping(name = "TransactionComponentPolicyAttributesDataMapping", 
	entities = {
		@EntityResult(entityClass = TransactionComponentPolicyAttributesBO.class, fields = {
			@FieldResult(name = "transactionComponentId", column = "TRANSACTION_COMPONENT_ID")
			})})

@NamedNativeQuery(name="TransactionComponentPolicyAttributesBO.fetchTransactionComponentPolicyAttributes",
		query="SELECT cmp.TRANSACTION_COMPONENT_ID as TRANSACTION_COMPONENT_ID,  "+
				" fn_string_agg( "+
				"   CASE  "+
				"		WHEN policy.POLICY_ID is not NULL and policyattribute.ATTRIBUTE_ID is not NULL and policyattribute.ATTRIBUTE_VAL is not NULL THEN "+
				"		  policy.POLICY_ID || '|' || policyattribute.ATTRIBUTE_ID || '|' || policyattribute.ATTRIBUTE_VAL "+
				"		ELSE "+
				"		  NULL "+
				"		END) AS POLICY_ATTRIBUTES "+
				"            from TTRANSACTION_COMPONENT cmp  "+
				"            left join TTRANSACTION_COMPONENT_POLICY cmppolicy on cmp.TRANSACTION_COMPONENT_ID = cmppolicy.TRANSACTION_COMPONENT_ID AND cmppolicy.DELETED_IN='N'  "+
				"            left join TPOLICY policy on cmppolicy.POLICY_ID = policy.POLICY_ID  "+
				"            left join TPOLICY_TYPE policytype on policy.POLICY_TYPE_ID = policytype.POLICY_TYPE_ID  "+
				"            left join TCURRENCY policycurrency on policy.LOCAL_CURRENCY_ID = policycurrency.CURRENCY_ID  "+
				"            left join TPOLICY_ATTRIBUTE policyattribute on policy.POLICY_ID = policyattribute.POLICY_ID  "+
				"            where cmp.TRANSACTION_COMPONENT_ID in (?1)  "+
				"            group by cmp.TRANSACTION_COMPONENT_ID  ",
		resultSetMapping="TransactionComponentPolicyAttributesDataMapping")

public class TransactionComponentPolicyAttributesBO {
	
	@Id
	@Column(name="TRANSACTION_COMPONENT_ID")
	private Long transactionComponentId;
	
	@Lob
	@Column(name="POLICY_ATTRIBUTES")
	private String policyAtrbt;

	public Long getTransactionComponentId() {
		return transactionComponentId;
	}


	public void setTransactionComponentId(Long transactionComponentId) {
		this.transactionComponentId = transactionComponentId;
	}


	public void setPolicyAtrbt(String policyAtrbt) {
		this.policyAtrbt = policyAtrbt;
	}

	public class PolicyAttributeDetails {
		private Short attributeId;
		private String attributeVal;
		private String policyID = null;
		
		public String getPolicyID() {
			return policyID;
		}
		public void setPolicyID(String policyID) {
			this.policyID = policyID;
		}
		public Short getAttributeId() {
			return attributeId;
		}
		public void setAttributeId(Short attributeId) {
			this.attributeId = attributeId;
		}
		public String getAttributeVal() {
			return attributeVal;
		}
		public void setAttributeVal(String attributeVal) {
			this.attributeVal = attributeVal;
		}
	}
	
	private Set<String> getUniqueValues(String stringContainingDuplicates) {
		if(null != stringContainingDuplicates)
		{
			Set<String> uniqueValueSet = new HashSet<String>(Arrays.asList(stringContainingDuplicates.split(NGEConstants.RECORDDELIMITER)));
			return uniqueValueSet;
		}
		return new HashSet<String>();
	}
	
	public HashMap<String, List<PolicyAttributeDetails>> getPolicyDetails() {
		
		String policyID = null;
		String attributeId = null;
		String attributeVal = null;
		HashMap<String, List<PolicyAttributeDetails>> hm = new HashMap<String, List<PolicyAttributeDetails>>();
		
		
		for(String temp1 : getUniqueValues(this.policyAtrbt))
		{
			StringTokenizer st1 = new StringTokenizer(temp1,NGEConstants.GENERICDELIMITER);
			PolicyAttributeDetails policyAttributeDetails1 = new PolicyAttributeDetails();
			List<PolicyAttributeDetails> policyAttributeDetailsList = new ArrayList<PolicyAttributeDetails>();
			
			if(st1.hasMoreTokens())
			{
				policyID = st1.nextToken();
				policyAttributeDetails1.setPolicyID(policyID);
			}
			
			if(hm.get(policyID)!= null)
			{
				policyAttributeDetailsList = hm.get(policyID);
			}
			if(st1.hasMoreTokens())
			{
				attributeId = st1.nextToken();
				policyAttributeDetails1.setAttributeId(Short.valueOf(attributeId));
			}
			if(st1.hasMoreTokens())
			{
				attributeVal = st1.nextToken();
				policyAttributeDetails1.setAttributeVal(attributeVal);	
			}
			
			policyAttributeDetailsList.add(policyAttributeDetails1);
			
			hm.put(policyID, policyAttributeDetailsList);
		}
		
		return hm;
	}
}
