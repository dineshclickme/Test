package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the TLEGACY_SUBMISSION_XPSR database table.
 * 
 */
@Embeddable
public class TlegacySubmissionXpsrPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="SUBMISSION_NO")
	private String submissionNo;

	@Column(name="EXPOSURE_SOURCE_CD")
	private String exposureSourceCd;

    public TlegacySubmissionXpsrPK() {
    }
	public String getSubmissionNo() {
		return this.submissionNo;
	}
	public void setSubmissionNo(String submissionNo) {
		this.submissionNo = submissionNo;
	}
	public String getExposureSourceCd() {
		return this.exposureSourceCd;
	}
	public void setExposureSourceCd(String exposureSourceCd) {
		this.exposureSourceCd = exposureSourceCd;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof TlegacySubmissionXpsrPK)) {
			return false;
		}
		TlegacySubmissionXpsrPK castOther = (TlegacySubmissionXpsrPK)other;
		return 
			(this.submissionNo == castOther.submissionNo)
			&& this.exposureSourceCd.equals(castOther.exposureSourceCd);

    }
    
	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.submissionNo.hashCode();
		hash = hash * prime + this.exposureSourceCd.hashCode();
		
		return hash;
    }
}