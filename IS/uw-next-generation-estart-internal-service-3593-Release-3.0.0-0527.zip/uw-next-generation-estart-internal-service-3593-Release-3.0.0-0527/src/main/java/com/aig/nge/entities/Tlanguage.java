package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Set;


/**
 * The persistent class for the TLANGUAGE database table.
 * 
 */
@Entity
public class Tlanguage implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="LANGUAGE_ID")
	private short languageId;

	@Column(name="CREATE_TS")
	private Timestamp createTs;

	@Column(name="CREATE_USER_ID")
	private String createUserId;

	@Column(name="LANGUAGE_DS")
	private String languageDs;

	@Column(name="LANGUAGE_NM")
	private String languageNm;

	@Column(name="UPDATE_TS")
	private Timestamp updateTs;

	@Column(name="UPDATE_USER_ID")
	private String updateUserId;

	//bi-directional many-to-one association to ThelpLanguage
	@OneToMany(mappedBy="tlanguage")
	private Set<ThelpLanguage> thelpLanguages;

	//bi-directional many-to-one association to TuserPrefernce
	@OneToMany(mappedBy="tlanguage")
	private Set<TuserPrefernce> tuserPrefernces;

	//bi-directional many-to-one association to TerrorLanguage
	@OneToMany(mappedBy="tlanguage")
	private Set<TerrorLanguage> terrorLanguages;

	//bi-directional many-to-one association to TfieldLanguage
	@OneToMany(mappedBy="tlanguage")
	private Set<TfieldLanguage> tfieldLanguages;

    public Tlanguage() {
    }

	public short getLanguageId() {
		return this.languageId;
	}

	public void setLanguageId(short languageId) {
		this.languageId = languageId;
	}

	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public String getLanguageDs() {
		return this.languageDs;
	}

	public void setLanguageDs(String languageDs) {
		this.languageDs = languageDs;
	}

	public String getLanguageNm() {
		return this.languageNm;
	}

	public void setLanguageNm(String languageNm) {
		this.languageNm = languageNm;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public Set<ThelpLanguage> getThelpLanguages() {
		return this.thelpLanguages;
	}

	public void setThelpLanguages(Set<ThelpLanguage> thelpLanguages) {
		this.thelpLanguages = thelpLanguages;
	}
	
	public Set<TuserPrefernce> getTuserPrefernces() {
		return this.tuserPrefernces;
	}

	public void setTuserPrefernces(Set<TuserPrefernce> tuserPrefernces) {
		this.tuserPrefernces = tuserPrefernces;
	}
	
	public Set<TerrorLanguage> getTerrorLanguages() {
		return this.terrorLanguages;
	}

	public void setTerrorLanguages(Set<TerrorLanguage> terrorLanguages) {
		this.terrorLanguages = terrorLanguages;
	}
	
	public Set<TfieldLanguage> getTfieldLanguages() {
		return this.tfieldLanguages;
	}

	public void setTfieldLanguages(Set<TfieldLanguage> tfieldLanguages) {
		this.tfieldLanguages = tfieldLanguages;
	}
	
}