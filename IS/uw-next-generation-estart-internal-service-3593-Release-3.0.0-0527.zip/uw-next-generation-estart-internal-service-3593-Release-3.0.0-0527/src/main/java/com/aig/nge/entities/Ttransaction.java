package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;

import java.sql.Timestamp;
import java.util.Set;


/**
 * The persistent class for the TTRANSACTION database table.
 * 
 */
@Entity
public class Ttransaction implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "transaction_id_gen")
	@SequenceGenerator(name = "transaction_id_gen", sequenceName = "TRANSACTION_ID_SEQ", allocationSize = 1)
	@Column(name="TRANSACTION_ID")
	private String transactionId;

	@Column(name="CREATE_TS")
	private Timestamp createTs;

	@Column(name="CREATE_USER_ID")
	private String createUserId;

	@Column(name="SYSTEM_ID")
	private short systemId;

	@Column(name="UPDATE_TS")
	private Timestamp updateTs;

	@Column(name="UPDATE_USER_ID")
	private String updateUserId;

	//bi-directional many-to-one association to TproducerContact
	@OneToMany(mappedBy="ttransaction", cascade={CascadeType.ALL})
	private Set<TproducerContact> tproducerContacts;

	//bi-directional many-to-one association to Tbranch
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="CREDITED_BRANCH_ID")
	private Tbranch tbranch;

	//bi-directional many-to-one association to TmailingAddress
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="ADDRESS_ID")
	private TmailingAddress tmailingAddress;

	//bi-directional many-to-one association to Tparty
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="PRODUCER_ID")
	private Tparty tparty1;

	//bi-directional many-to-one association to Tparty
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="AGENT_ID")
	private Tparty tparty2;

	//bi-directional many-to-one association to Tparty
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="UNDERWRITER_ID")
	private Tparty tparty3;

	//bi-directional many-to-one association to Tsubmission
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="SUBMISSION_NO")
	private Tsubmission tsubmission;

	//bi-directional many-to-one association to TtransactionRelation
	@OneToMany(mappedBy="ttransaction1", cascade={CascadeType.ALL})
	private Set<TtransactionRelation> ttransactionRelations1;

	//bi-directional many-to-one association to TtransactionRelation
	@OneToMany(mappedBy="ttransaction2", cascade={CascadeType.ALL})
	private Set<TtransactionRelation> ttransactionRelations2;

	//bi-directional many-to-one association to TtransactionVersion
	@OneToMany(mappedBy="ttransaction", cascade={CascadeType.ALL})
	private Set<TtransactionVersion> ttransactionVersions;

    public Ttransaction() {
    }

	public String getTransactionId() {
		return this.transactionId;
	}

	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}

	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public short getSystemId() {
		return this.systemId;
	}

	public void setSystemId(short systemId) {
		this.systemId = systemId;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public Set<TproducerContact> getTproducerContacts() {
		return this.tproducerContacts;
	}

	public void setTproducerContacts(Set<TproducerContact> tproducerContacts) {
		this.tproducerContacts = tproducerContacts;
	}
	
	public Tbranch getTbranch() {
		return this.tbranch;
	}

	public void setTbranch(Tbranch tbranch) {
		this.tbranch = tbranch;
	}
	
	public TmailingAddress getTmailingAddress() {
		return this.tmailingAddress;
	}

	public void setTmailingAddress(TmailingAddress tmailingAddress) {
		this.tmailingAddress = tmailingAddress;
	}
	

	
	public Tparty getTparty1() {
		return this.tparty1;
	}

	public void setTparty1(Tparty tparty1) {
		this.tparty1 = tparty1;
	}
	
	public Tparty getTparty2() {
		return this.tparty2;
	}

	public void setTparty2(Tparty tparty2) {
		this.tparty2 = tparty2;
	}
	
	public Tparty getTparty3() {
		return this.tparty3;
	}

	public void setTparty3(Tparty tparty3) {
		this.tparty3 = tparty3;
	}
	
	public Tsubmission getTsubmission() {
		return this.tsubmission;
	}

	public void setTsubmission(Tsubmission tsubmission) {
		this.tsubmission = tsubmission;
	}
	
	public Set<TtransactionRelation> getTtransactionRelations1() {
		return this.ttransactionRelations1;
	}

	public void setTtransactionRelations1(Set<TtransactionRelation> ttransactionRelations1) {
		this.ttransactionRelations1 = ttransactionRelations1;
	}
	
	public Set<TtransactionRelation> getTtransactionRelations2() {
		return this.ttransactionRelations2;
	}

	public void setTtransactionRelations2(Set<TtransactionRelation> ttransactionRelations2) {
		this.ttransactionRelations2 = ttransactionRelations2;
	}
	
	public Set<TtransactionVersion> getTtransactionVersions() {
		return this.ttransactionVersions;
	}

	public void setTtransactionVersions(Set<TtransactionVersion> ttransactionVersions) {
		this.ttransactionVersions = ttransactionVersions;
	}
	
}