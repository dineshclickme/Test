package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;

import org.apache.openjpa.persistence.DataCache;
import java.sql.Timestamp;


/**
 * The persistent class for the TSYSTEM_METHOD database table.
 * 
 */
@Entity
@DataCache
@Table(name="TSYSTEM_METHOD")
public class TsystemMethod implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private TsystemMethodPK id;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="CREATE_TS")
	private Timestamp createTs;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="CREATE_USER_ID")
	private String createUserId;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="UPDATE_TS")
	private Timestamp updateTs;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="UPDATE_USER_ID")
	private String updateUserId;

	//bi-directional many-to-one association to Tmethod
	@ManyToOne
	@JoinColumn(name="METHOD_ID")
	private Tmethod tmethod;

	//bi-directional many-to-one association to Tsystem
	@ManyToOne
	@JoinColumn(name="SYSTEM_ID")
	private Tsystem tsystem;

    public TsystemMethod() {
    }

	public TsystemMethodPK getId() {
		return this.id;
	}

	public void setId(TsystemMethodPK id) {
		this.id = id;
	}
	
	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public Tmethod getTmethod() {
		return this.tmethod;
	}

	public void setTmethod(Tmethod tmethod) {
		this.tmethod = tmethod;
	}
	
	public Tsystem getTsystem() {
		return this.tsystem;
	}

	public void setTsystem(Tsystem tsystem) {
		this.tsystem = tsystem;
	}
	
}