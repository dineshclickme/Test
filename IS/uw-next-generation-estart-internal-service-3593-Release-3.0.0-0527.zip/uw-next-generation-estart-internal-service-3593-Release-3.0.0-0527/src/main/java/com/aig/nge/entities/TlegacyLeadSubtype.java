package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Set;


/**
 * The persistent class for the TLEGACY_LEAD_SUBTYPE database table.
 * 
 */
@Entity
@Table(name="TLEGACY_LEAD_SUBTYPE")
public class TlegacyLeadSubtype implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private TlegacyLeadSubtypePK id;

	@Column(name="CREATE_TS")
	private Timestamp createTs;

	@Column(name="CREATE_USER_ID")
	private String createUserId;

	@Column(name="LEAD_SUBTYPE_NM")
	private String leadSubtypeNm;

	@Column(name="UPDATE_TS")
	private Timestamp updateTs;

	@Column(name="UPDATE_USER_ID")
	private String updateUserId;

	//bi-directional many-to-one association to TlegacyLeadType
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumns({
		@JoinColumn(name="LEAD_TYPE_CD", referencedColumnName="LEAD_TYPE_CD"),
		@JoinColumn(name="SOURCE_CD", referencedColumnName="SOURCE_CD")
		})
	private TlegacyLeadType tlegacyLeadType;

	//bi-directional many-to-one association to TlegacyProductLeadType
	@OneToMany(mappedBy="tlegacyLeadSubtype")
	private Set<TlegacyProductLeadType> tlegacyProductLeadTypes;

    public TlegacyLeadSubtype() {
    }

	public TlegacyLeadSubtypePK getId() {
		return this.id;
	}

	public void setId(TlegacyLeadSubtypePK id) {
		this.id = id;
	}
	
	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public String getLeadSubtypeNm() {
		return this.leadSubtypeNm;
	}

	public void setLeadSubtypeNm(String leadSubtypeNm) {
		this.leadSubtypeNm = leadSubtypeNm;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public TlegacyLeadType getTlegacyLeadType() {
		return this.tlegacyLeadType;
	}

	public void setTlegacyLeadType(TlegacyLeadType tlegacyLeadType) {
		this.tlegacyLeadType = tlegacyLeadType;
	}
	
	public Set<TlegacyProductLeadType> getTlegacyProductLeadTypes() {
		return this.tlegacyProductLeadTypes;
	}

	public void setTlegacyProductLeadTypes(Set<TlegacyProductLeadType> tlegacyProductLeadTypes) {
		this.tlegacyProductLeadTypes = tlegacyProductLeadTypes;
	}
	
}