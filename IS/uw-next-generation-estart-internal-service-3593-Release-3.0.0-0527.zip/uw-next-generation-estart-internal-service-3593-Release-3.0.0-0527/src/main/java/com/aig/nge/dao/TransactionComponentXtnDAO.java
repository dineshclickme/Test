package com.aig.nge.dao;

import java.sql.Date;
import java.sql.Timestamp;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.aig.nge.entities.TlegacyProduct;
import com.aig.nge.entities.TlegacyTransactionExtension;
import com.aig.nge.entities.TlegacyTrnsctnCmpntXtensn;
import com.aig.nge.entities.TproductState;
import com.aig.nge.entities.TtransactionComponent;
import com.aig.nge.entities.TtransactionComponentBranch;
import com.aig.nge.entities.TtransactionComponentLimit;
import com.aig.nge.repository.TLegacyProductRepository;
import com.aig.nge.repository.TLegacyWipQuoteRepository;
import com.aig.nge.repository.TProductStateRepository;
import com.aig.nge.repository.TTransactionComponentBranchRepository;
import com.aig.nge.repository.TTransactionComponentLimitRepository;
import com.aig.nge.repository.TTransactionComponentRepository;
import com.aig.nge.repository.TlegacyTransactionExtensionRepository;
import com.aig.nge.repository.TlegacyTrnsctnCmpntXtensnRepository;
import com.aig.nge.utilities.NGECommonUtil;
import com.aig.nge.utilities.NGEConstants;
//import com.ibm.ObjectQuery.crud.util.PreOrderTreeIterator;


@Repository
public class TransactionComponentXtnDAO extends BaseDAO {

	@Autowired
	TlegacyTrnsctnCmpntXtensnRepository cmpntXtnRepository;
	@Autowired
	TTransactionComponentRepository componentRepository;
	@Autowired
	TTransactionComponentBranchRepository branchRepository;
	@Autowired
	TTransactionComponentLimitRepository componentLimitRepository;
	@Autowired
	TProductStateRepository productStateRepository;
	@Autowired
	TLegacyProductRepository legacyProductRepository;
	@Autowired
	TLegacyWipQuoteRepository wipquoteRepository;
	@Autowired
	TlegacyTransactionExtensionRepository legacyTransactionExtensionRepository;

	public TlegacyTrnsctnCmpntXtensn getTlegacyTransactioncmpntXtn(String productCd){
		
		TlegacyTrnsctnCmpntXtensn transactionCmpntXtn=cmpntXtnRepository.findOne(productCd);
		return transactionCmpntXtn;
	}
	
	public TlegacyProduct getLegacyProduct(String productCd){
		TlegacyProduct legacyProduct=legacyProductRepository.getProductDetails(NGECommonUtil.convertToString(productCd));
		return legacyProduct;
		
	}
	
	public List<TtransactionComponent> getTransactionComponentListByUWID(String partyNo,String partyType){
		List<TtransactionComponent> transcationComponentList=componentRepository.findByUnderWriterId(partyNo,partyType);
		return transcationComponentList;
	}
	
	public TtransactionComponentBranch getTTransactionComponentBranch(String componentId,String branchTypeNm){
		
		TtransactionComponentBranch componentBranch=branchRepository.getProductBranch(componentId, branchTypeNm);
		return componentBranch;
		
	}
public List<TtransactionComponentBranch> getTTransactionComponentBranchByComponentId(String componentId){
		
		List<TtransactionComponentBranch> componentBranch=branchRepository.getComponentBranch(componentId);
		return componentBranch;
		
	}
	public TproductState getProductState(int productStateId){
		TproductState productSt=productStateRepository.findOne((short) productStateId);
		return productSt;
		
	}
	public Set<Object[]> getResultSetByUpdatedTimeStamp(String underwriterId,Timestamp ts,String submissionStatus,int currencyId){
		Set<Object[]> resultSet=cmpntXtnRepository.findResultByUpdatedTs(underwriterId,ts,submissionStatus,currencyId);
		return resultSet;
		
	}
	
	
	public int getXtnCount(String productCd,String submissionNo){
		int count=cmpntXtnRepository.xtnCount(NGECommonUtil.convertToString(productCd),submissionNo);
		return count;
		
	}

	
	public List<Object[]> getResultSetByAcct(String submissionNo,String policyNo,String organizationNm,String accountState,String acctCountrt,Date effectiveDt,String productCd,String returnCount,String srcCd){
		List<Object[]> resultSet=cmpntXtnRepository.getSubmissionProductInfo(submissionNo,policyNo,organizationNm,accountState,acctCountrt,effectiveDt,NGECommonUtil.convertToString(productCd),returnCount,NGECommonUtil.convertToString(srcCd));
		return resultSet;
		
	}
	
	public List<Object[]> getResultSetBysubmissionNo(String submissionNo,String wipStatusCd,Object productStateId,Date effectiveDt,String productCd,String returnCount,String srcCd ){
		List<Object[]> resultSet=cmpntXtnRepository.getSubmissionProductInfoBySubmissionNo(submissionNo, wipStatusCd, productStateId,effectiveDt,NGECommonUtil.convertToString(productCd),returnCount,srcCd);
		if(productCd!=null)
			productCd = productCd.trim();
		//List<Object[]> resultSet=cmpntXtnRepository.getSubmissionProductInfo1(submissionNo,null,null,null,null,effectiveDt,productCd,returnCount,srcCd);
		return resultSet;
		
	}
	
	public List<TtransactionComponentLimit> getComponentLimit(String transactionComponentId){
		List<TtransactionComponentLimit> componentLmt=componentLimitRepository.getComponentLimit(transactionComponentId);
		return componentLmt;
		
	}
	public Set<Object[]> inquireBlockingSubmission(Integer blockedSubmissionNo,String blockedproductCd,String blockedCoverageType,int currencyId){
		Set<Object[]> resultSet=cmpntXtnRepository.inquireBlockingSubmission(blockedSubmissionNo, NGECommonUtil.convertToString(blockedproductCd), blockedCoverageType,currencyId);
		return resultSet;
	}
	public Set<Object[]> inquireBlockedSubmission(Integer blockingSubmissionNo,String blockingProductCd,String productCoverageType,int currencyId){
		Set<Object[]> resultSet=cmpntXtnRepository.inquireBlockedSubmission(blockingSubmissionNo, NGECommonUtil.convertToString(blockingProductCd), productCoverageType,currencyId);
		return resultSet;
	}
	public Set<Object[]> inquireBlockSubmissionBySoftBlocks(Integer blockedSubmissionNo,String blockedproductCd,String blockedCoverageType,int currencyId){
		Set<Object[]> resultSet=cmpntXtnRepository.inquireBlockSubmissionBySoftBlocks(blockedSubmissionNo,NGECommonUtil.convertToString(blockedproductCd),blockedCoverageType,currencyId);
		return resultSet;
	}
	public Set<Object[]> getLegacyProduct(Long transactioncomponentId){
		Set<Object[]> resultSet=cmpntXtnRepository.findLegacyProductCd(transactioncomponentId);
		return resultSet;
	}
	public Set<Object[]> getAlertBlockMessages(Integer alertSubmissionNo,String alertproductCd,String alertCoverageType,int currencyId){
		if(null==alertproductCd){
			alertproductCd="";
		}
		Set<Object[]> resultSet=cmpntXtnRepository.getAlertBlockMessagesRep(alertSubmissionNo, NGECommonUtil.convertToString(alertproductCd.trim()), alertCoverageType,currencyId);
		return resultSet;
	}
	public int checkWipCount(int priorPolicyId){
	int count=	wipquoteRepository.checkRenewalWipcount(priorPolicyId);
	return count;
	}
	
	public Set<Object[]> getAlternateContactDetails(Integer geoLocId,String div){
		Set<Object[]> resultSet = cmpntXtnRepository.getAlternateContactDetailsForBlock(geoLocId,div,NGEConstants.ALTCNT_ROLE,NGEConstants.ALTCNT_ACTION);
		return resultSet;
	}
	
	public String getGeographicLocIdFromSourceCd(String sourceCd){
		String geoLocId = cmpntXtnRepository.getGeographicLocIdFromSourceCdForBlock(sourceCd,NGEConstants.SOURCE_CODE);
		return geoLocId;
	}
	

	/**
	 * Feb 2019 Maintenance Release 2.14 - Alert block not displaying in estart UI
	 * @param submissionNo
	 * @param bundledProductCd
	 * @return
	 */
	public List<TlegacyTransactionExtension>  getTransactionExtenBysubmissionProduct(String submissionNo,String bundledProductCd){
		List<TlegacyTransactionExtension> trnExtn=legacyTransactionExtensionRepository.getTransactionExtenBysubmissionProduct(submissionNo,NGECommonUtil.convertToString(bundledProductCd));
		return trnExtn;
		
	}
}
