package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-02-25T15:44:17.701+0530")
@StaticMetamodel(TproductTowerAttributeUsage.class)
public class TproductTowerAttributeUsage_ {
	public static volatile SingularAttribute<TproductTowerAttributeUsage, TproductTowerAttributeUsagePK> id;
	public static volatile SingularAttribute<TproductTowerAttributeUsage, Timestamp> createTs;
	public static volatile SingularAttribute<TproductTowerAttributeUsage, String> createUserId;
	public static volatile SingularAttribute<TproductTowerAttributeUsage, Timestamp> updateTs;
	public static volatile SingularAttribute<TproductTowerAttributeUsage, String> updateUserId;
	public static volatile SingularAttribute<TproductTowerAttributeUsage, TproductTowerAttribute> tproductTowerAttribute;
	public static volatile SingularAttribute<TproductTowerAttributeUsage, TusageType> tusageType;
}
