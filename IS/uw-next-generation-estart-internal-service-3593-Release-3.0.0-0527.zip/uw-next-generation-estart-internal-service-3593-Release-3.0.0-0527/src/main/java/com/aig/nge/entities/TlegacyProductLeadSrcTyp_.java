package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-04-15T15:31:47.057+0530")
@StaticMetamodel(TlegacyProductLeadSrcTyp.class)
public class TlegacyProductLeadSrcTyp_ {
	public static volatile SingularAttribute<TlegacyProductLeadSrcTyp, TlegacyProductLeadSrcTypPK> id;
	public static volatile SingularAttribute<TlegacyProductLeadSrcTyp, String> branchNo;
	public static volatile SingularAttribute<TlegacyProductLeadSrcTyp, Timestamp> createTs;
	public static volatile SingularAttribute<TlegacyProductLeadSrcTyp, String> createUserId;
	public static volatile SingularAttribute<TlegacyProductLeadSrcTyp, String> leadSourceId;
	public static volatile SingularAttribute<TlegacyProductLeadSrcTyp, String> operatingCoCd;
	public static volatile SingularAttribute<TlegacyProductLeadSrcTyp, Timestamp> updateTs;
	public static volatile SingularAttribute<TlegacyProductLeadSrcTyp, String> updateUserId;
	public static volatile SingularAttribute<TlegacyProductLeadSrcTyp, TtransactionComponent> ttransactionComponent;
	public static volatile SingularAttribute<TlegacyProductLeadSrcTyp, TlegacyLeadSourceType> tlegacyLeadSourceType;
}
