package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the TLEGACY_SUBMISSION_ADDL_INFO database table.
 * 
 */
@Embeddable
public class TlegacySubmissionAddlInfoPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="SUBMISSION_NO")
	private String submissionNo;

	@Column(name="ACCOUNT_NO")
	private int accountNo;

    public TlegacySubmissionAddlInfoPK() {
    }
	public String getSubmissionNo() {
		return this.submissionNo;
	}
	public void setSubmissionNo(String submissionNo) {
		this.submissionNo = submissionNo;
	}
	public int getAccountNo() {
		return this.accountNo;
	}
	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof TlegacySubmissionAddlInfoPK)) {
			return false;
		}
		TlegacySubmissionAddlInfoPK castOther = (TlegacySubmissionAddlInfoPK)other;
		return 
			this.submissionNo.equals(castOther.submissionNo)
			&& (this.accountNo == castOther.accountNo);

    }
    
	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.submissionNo.hashCode();
		hash = hash * prime + this.accountNo;
		
		return hash;
    }
}