package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;

import org.apache.openjpa.persistence.DataCache;
import java.sql.Timestamp;
import java.util.Set;


/**
 * The persistent class for the TPRODUCT_TOWER database table.
 * 
 */
@Entity
@DataCache
@Table(name="TPRODUCT_TOWER")
public class TproductTower implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="PRODUCT_TOWER_ID")
	private short productTowerId;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="CREATE_TS")
	private Timestamp createTs;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="CREATE_USER_ID")
	private String createUserId;

	@Column(name="DELETED_IN")
	private String deletedIn;

	@Column(name="PRODUCT_TOWER_NM")
	private String productTowerNm;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="UPDATE_TS")
	private Timestamp updateTs;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="UPDATE_USER_ID")
	private String updateUserId;

	//bi-directional many-to-one association to TlegacyProductMapping
	@OneToMany(mappedBy="tproductTower")
	private Set<TlegacyProductMapping> tlegacyProductMappings;

	//bi-directional many-to-one association to TmarketableProduct
	@OneToMany(mappedBy="tproductTower", cascade={CascadeType.ALL})
	private Set<TmarketableProduct> tmarketableProducts;

	//bi-directional many-to-one association to TpartyAction
	@OneToMany(mappedBy="tproductTower", cascade={CascadeType.ALL})
	private Set<TpartyAction> tpartyActions;

	//bi-directional many-to-one association to Tsegment
	@ManyToOne
	@JoinColumn(name="SEGMENT_CD")
	private Tsegment tsegment1;

	//bi-directional many-to-one association to Tsegment
	@ManyToOne
	@JoinColumn(name="SUB_SEGMENT_CD")
	private Tsegment tsegment2;

	//bi-directional many-to-one association to TproductTowerAttribute
	@OneToMany(mappedBy="tproductTower", cascade={CascadeType.ALL})
	private Set<TproductTowerAttribute> tproductTowerAttributes;

	//bi-directional many-to-one association to TproductTowerAutoCloseRule
	@OneToMany(mappedBy="tproductTower", cascade={CascadeType.ALL})
	private Set<TproductTowerAutoCloseRule> tproductTowerAutoCloseRules;

	//bi-directional many-to-one association to TproductTowerConfiguration
	@OneToMany(mappedBy="tproductTower", cascade={CascadeType.ALL})
	private Set<TproductTowerConfiguration> tproductTowerConfigurations;

	//bi-directional many-to-one association to TproductTowerDivision
	@OneToMany(mappedBy="tproductTower", cascade={CascadeType.ALL})
	private Set<TproductTowerDivision> tproductTowerDivisions;

	//bi-directional many-to-one association to TproductTowerParty
	@OneToMany(mappedBy="tproductTower", cascade={CascadeType.ALL})
	private Set<TproductTowerParty> tproductTowerParties;

	//bi-directional many-to-one association to TproductTowerReason
	@OneToMany(mappedBy="tproductTower", cascade={CascadeType.ALL})
	private Set<TproductTowerReason> tproductTowerReasons;

	//bi-directional many-to-one association to TproductTowerTuwProuduct
	@OneToMany(mappedBy="tproductTower", cascade={CascadeType.ALL})
	private Set<TproductTowerTuwSubProduct> tproductTowerTuwSubProdcts;

	//bi-directional many-to-one association to TtowerEvent
	@OneToMany(mappedBy="tproductTower", cascade={CascadeType.ALL})
	private Set<TtowerEvent> ttowerEvents;

    public TproductTower() {
    }

	public short getProductTowerId() {
		return this.productTowerId;
	}

	public void setProductTowerId(short productTowerId) {
		this.productTowerId = productTowerId;
	}

	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public String getDeletedIn() {
		return this.deletedIn;
	}

	public void setDeletedIn(String deletedIn) {
		this.deletedIn = deletedIn;
	}

	public String getProductTowerNm() {
		return this.productTowerNm;
	}

	public void setProductTowerNm(String productTowerNm) {
		this.productTowerNm = productTowerNm;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public Set<TlegacyProductMapping> getTlegacyProductMappings() {
		return this.tlegacyProductMappings;
	}

	public void setTlegacyProductMappings(Set<TlegacyProductMapping> tlegacyProductMappings) {
		this.tlegacyProductMappings = tlegacyProductMappings;
	}
	
	public Set<TmarketableProduct> getTmarketableProducts() {
		return this.tmarketableProducts;
	}

	public void setTmarketableProducts(Set<TmarketableProduct> tmarketableProducts) {
		this.tmarketableProducts = tmarketableProducts;
	}
	
	public Set<TpartyAction> getTpartyActions() {
		return this.tpartyActions;
	}

	public void setTpartyActions(Set<TpartyAction> tpartyActions) {
		this.tpartyActions = tpartyActions;
	}
	
	public Tsegment getTsegment1() {
		return this.tsegment1;
	}

	public void setTsegment1(Tsegment tsegment1) {
		this.tsegment1 = tsegment1;
	}
	
	public Tsegment getTsegment2() {
		return this.tsegment2;
	}

	public void setTsegment2(Tsegment tsegment2) {
		this.tsegment2 = tsegment2;
	}
	
	public Set<TproductTowerAttribute> getTproductTowerAttributes() {
		return this.tproductTowerAttributes;
	}

	public void setTproductTowerAttributes(Set<TproductTowerAttribute> tproductTowerAttributes) {
		this.tproductTowerAttributes = tproductTowerAttributes;
	}
	
	public Set<TproductTowerAutoCloseRule> getTproductTowerAutoCloseRules() {
		return this.tproductTowerAutoCloseRules;
	}

	public void setTproductTowerAutoCloseRules(Set<TproductTowerAutoCloseRule> tproductTowerAutoCloseRules) {
		this.tproductTowerAutoCloseRules = tproductTowerAutoCloseRules;
	}
	
	public Set<TproductTowerDivision> getTproductTowerDivisions() {
		return this.tproductTowerDivisions;
	}

	public void setTproductTowerDivisions(Set<TproductTowerDivision> tproductTowerDivisions) {
		this.tproductTowerDivisions = tproductTowerDivisions;
	}
	
	public Set<TproductTowerParty> getTproductTowerParties() {
		return this.tproductTowerParties;
	}

	public void setTproductTowerParties(Set<TproductTowerParty> tproductTowerParties) {
		this.tproductTowerParties = tproductTowerParties;
	}
	
	public Set<TproductTowerReason> getTproductTowerReasons() {
		return this.tproductTowerReasons;
	}

	public void setTproductTowerReasons(Set<TproductTowerReason> tproductTowerReasons) {
		this.tproductTowerReasons = tproductTowerReasons;
	}
	
	public Set<TproductTowerTuwSubProduct> getTproductTowerTuwSubProdcts() {
		return this.tproductTowerTuwSubProdcts;
	}

	public void setTproductTowerTuwSubProdcts(Set<TproductTowerTuwSubProduct> tproductTowerTuwSubProdcts) {
		this.tproductTowerTuwSubProdcts = tproductTowerTuwSubProdcts;
	}
	
	public Set<TtowerEvent> getTtowerEvents() {
		return this.ttowerEvents;
	}

	public void setTtowerEvents(Set<TtowerEvent> ttowerEvents) {
		this.ttowerEvents = ttowerEvents;
	}
	
	public Set<TproductTowerConfiguration> getTproductTowerConfigurations() {
		return this.tproductTowerConfigurations;
	}

	public void setTproductTowerConfigurations(Set<TproductTowerConfiguration> tproductTowerConfigurations) {
		this.tproductTowerConfigurations = tproductTowerConfigurations;
	}
	
}