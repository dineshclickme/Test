package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the TLEGACY_USER_TYPE_CNVRSN database table.
 * 
 */
@Entity
@Table(name="TLEGACY_USER_TYPE_CNVRSN")
public class TlegacyUserTypeCnvrsn implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="ADBUSER_EMPLTYP_CD")
	private String adbuserEmpltypCd;

	@Column(name="CREATE_TS")
	private Timestamp createTs;

	@Column(name="CREATE_USER_ID")
	private String createUserId;

	@Column(name="UPDATE_TS")
	private Timestamp updateTs;

	@Column(name="UPDATE_USER_ID")
	private String updateUserId;

	@Column(name="USER_TYPE_CD")
	private String userTypeCd;

    public TlegacyUserTypeCnvrsn() {
    }

	public String getAdbuserEmpltypCd() {
		return this.adbuserEmpltypCd;
	}

	public void setAdbuserEmpltypCd(String adbuserEmpltypCd) {
		this.adbuserEmpltypCd = adbuserEmpltypCd;
	}

	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public String getUserTypeCd() {
		return this.userTypeCd;
	}

	public void setUserTypeCd(String userTypeCd) {
		this.userTypeCd = userTypeCd;
	}

}