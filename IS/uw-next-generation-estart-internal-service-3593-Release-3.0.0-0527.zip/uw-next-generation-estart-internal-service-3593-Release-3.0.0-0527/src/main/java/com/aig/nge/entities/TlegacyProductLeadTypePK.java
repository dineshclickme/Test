package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the TLEGACY_PRODUCT_LEAD_TYPE database table.
 * 
 */
@Embeddable
public class TlegacyProductLeadTypePK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="TRANSACTION_COMPONENT_ID")
	private String transactionComponentId;

	@Column(name="SOURCE_CD")
	private String sourceCd;

	@Column(name="LEAD_TYPE_CD")
	private String leadTypeCd;

	@Column(name="LEAD_SUBTYPE_CD")
	private String leadSubtypeCd;

    public TlegacyProductLeadTypePK() {
    }
	public String getTransactionComponentId() {
		return this.transactionComponentId;
	}
	public void setTransactionComponentId(String transactionComponentId) {
		this.transactionComponentId = transactionComponentId;
	}
	public String getSourceCd() {
		return this.sourceCd;
	}
	public void setSourceCd(String sourceCd) {
		this.sourceCd = sourceCd;
	}
	public String getLeadTypeCd() {
		return this.leadTypeCd;
	}
	public void setLeadTypeCd(String leadTypeCd) {
		this.leadTypeCd = leadTypeCd;
	}
	public String getLeadSubtypeCd() {
		return this.leadSubtypeCd;
	}
	public void setLeadSubtypeCd(String leadSubtypeCd) {
		this.leadSubtypeCd = leadSubtypeCd;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof TlegacyProductLeadTypePK)) {
			return false;
		}
		TlegacyProductLeadTypePK castOther = (TlegacyProductLeadTypePK)other;
		return 
			this.transactionComponentId.equals(castOther.transactionComponentId)
			&& this.sourceCd.equals(castOther.sourceCd)
			&& this.leadTypeCd.equals(castOther.leadTypeCd)
			&& this.leadSubtypeCd.equals(castOther.leadSubtypeCd);

    }
    
	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.transactionComponentId.hashCode();
		hash = hash * prime + this.sourceCd.hashCode();
		hash = hash * prime + this.leadTypeCd.hashCode();
		hash = hash * prime + this.leadSubtypeCd.hashCode();
		
		return hash;
    }
}