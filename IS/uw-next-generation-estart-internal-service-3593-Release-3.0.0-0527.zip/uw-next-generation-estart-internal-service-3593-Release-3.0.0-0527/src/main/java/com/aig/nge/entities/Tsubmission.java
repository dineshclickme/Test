package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Set;


/**
 * The persistent class for the TSUBMISSION database table.
 * 
 */
@Entity
public class Tsubmission implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="SUBMISSION_NO")
	private String submissionNo;

	@Column(name="CREATE_TS")
	private Timestamp createTs;

	@Column(name="CREATE_USER_ID")
	private String createUserId;

	@Column(name="SUBMISSION_TS")
	private Timestamp submissionTs;

	@Column(name="UPDATE_TS")
	private Timestamp updateTs;

	@Column(name="UPDATE_USER_ID")
	private String updateUserId;

	//bi-directional many-to-one association to Tparty
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="INITIATING_PRODUCER_ID")
	private Tparty tparty1;

	//bi-directional many-to-one association to Tparty
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="ACCOUNT_ID")
	private Tparty tparty2;

	//bi-directional many-to-one association to Tsystem
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="SYSTEM_ID")
	private Tsystem tsystem;

	//bi-directional many-to-one association to Ttransaction
	@OneToMany(mappedBy="tsubmission", cascade={CascadeType.ALL})
	private Set<Ttransaction> ttransactions;

	//bi-directional one-to-one association to TlegacySubmissionExtension
	@OneToOne(mappedBy="tsubmission", fetch=FetchType.LAZY)
	private TlegacySubmissionExtension tlegacySubmissionExtension;

	//bi-directional many-to-one association to TofacAlertNotification
	@OneToMany(mappedBy="tsubmission")
	private Set<TofacAlertNotification> tofacAlertNotifications;

    public Tsubmission() {
    }

	public String getSubmissionNo() {
		return this.submissionNo;
	}

	public void setSubmissionNo(String submissionNo) {
		this.submissionNo = submissionNo;
	}

	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public Timestamp getSubmissionTs() {
		return this.submissionTs;
	}

	public void setSubmissionTs(Timestamp submissionTs) {
		this.submissionTs = submissionTs;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public Tparty getTparty1() {
		return this.tparty1;
	}

	public void setTparty1(Tparty tparty1) {
		this.tparty1 = tparty1;
	}
	
	public Tparty getTparty2() {
		return this.tparty2;
	}

	public void setTparty2(Tparty tparty2) {
		this.tparty2 = tparty2;
	}
	
	public Tsystem getTsystem() {
		return this.tsystem;
	}

	public void setTsystem(Tsystem tsystem) {
		this.tsystem = tsystem;
	}
	
	public Set<Ttransaction> getTtransactions() {
		return this.ttransactions;
	}

	public void setTtransactions(Set<Ttransaction> ttransactions) {
		this.ttransactions = ttransactions;
	}
	
	public TlegacySubmissionExtension getTlegacySubmissionExtension() {
		return this.tlegacySubmissionExtension;
	}

	public void setTlegacySubmissionExtension(TlegacySubmissionExtension tlegacySubmissionExtension) {
		this.tlegacySubmissionExtension = tlegacySubmissionExtension;
	}
	
	public Set<TofacAlertNotification> getTofacAlertNotifications() {
		return this.tofacAlertNotifications;
	}

	public void setTofacAlertNotifications(Set<TofacAlertNotification> tofacAlertNotifications) {
		this.tofacAlertNotifications = tofacAlertNotifications;
	}
	
}