package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the TSTATUS_REASON_TYPE database table.
 * 
 */
@Embeddable
public class TstatusReasonTypePK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="STATUS_ID")
	private short statusId;

	@Column(name="REASON_TYPE_ID")
	private short reasonTypeId;

    public TstatusReasonTypePK() {
    }
	public short getStatusId() {
		return this.statusId;
	}
	public void setStatusId(short statusId) {
		this.statusId = statusId;
	}
	public short getReasonTypeId() {
		return this.reasonTypeId;
	}
	public void setReasonTypeId(short reasonTypeId) {
		this.reasonTypeId = reasonTypeId;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof TstatusReasonTypePK)) {
			return false;
		}
		TstatusReasonTypePK castOther = (TstatusReasonTypePK)other;
		return 
			(this.statusId == castOther.statusId)
			&& (this.reasonTypeId == castOther.reasonTypeId);

    }
    
	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + ((int) this.statusId);
		hash = hash * prime + ((int) this.reasonTypeId);
		
		return hash;
    }
}