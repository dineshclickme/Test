package com.aig.nge.dao;

public class ProductMappingDAO {

}
