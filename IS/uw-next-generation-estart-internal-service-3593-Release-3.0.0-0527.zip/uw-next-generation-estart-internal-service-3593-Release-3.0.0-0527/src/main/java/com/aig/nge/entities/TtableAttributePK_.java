package com.aig.nge.entities;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-02-19T16:13:04.670+0530")
@StaticMetamodel(TtableAttributePK.class)
public class TtableAttributePK_ {
	public static volatile SingularAttribute<TtableAttributePK, Short> tableId;
	public static volatile SingularAttribute<TtableAttributePK, Short> attributeId;
}
