package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2016-01-30T17:32:13.511+0530")
@StaticMetamodel(TlegacyUserTypeFnctn.class)
public class TlegacyUserTypeFnctn_ {
	public static volatile SingularAttribute<TlegacyUserTypeFnctn, TlegacyUserTypeFnctnPK> id;
	public static volatile SingularAttribute<TlegacyUserTypeFnctn, Timestamp> createTs;
	public static volatile SingularAttribute<TlegacyUserTypeFnctn, String> createUserId;
	public static volatile SingularAttribute<TlegacyUserTypeFnctn, Timestamp> updateTs;
	public static volatile SingularAttribute<TlegacyUserTypeFnctn, String> updateUserId;
}
