package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;

import org.apache.openjpa.persistence.DataCache;
import java.sql.Timestamp;
import java.util.Set;


/**
 * The persistent class for the TPRODUCT database table.
 * 
 */
@Entity
@DataCache
public class Tproduct implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="PRODUCT_ID")
	private int productId;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="CREATE_TS")
	private Timestamp createTs;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="CREATE_USER_ID")
	private String createUserId;

	@Column(name="DELETED_IN")
	private String deletedIn;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="UPDATE_TS")
	private Timestamp updateTs;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="UPDATE_USER_ID")
	private String updateUserId;

	//bi-directional many-to-one association to TlegacyProductMapping
	@OneToMany(mappedBy="tproduct1")
	private Set<TlegacyProductMapping> tlegacyProductMappings1;

	//bi-directional many-to-one association to TlegacyProductMapping
	@OneToMany(mappedBy="tproduct2")
	private Set<TlegacyProductMapping> tlegacyProductMappings2;

	//bi-directional many-to-one association to TlegacyProductMapping
	@OneToMany(mappedBy="tproduct3")
	private Set<TlegacyProductMapping> tlegacyProductMappings3;

	//bi-directional many-to-one association to TlegacyProductMapping
	@OneToMany(mappedBy="tproduct4")
	private Set<TlegacyProductMapping> tlegacyProductMappings4;

	//bi-directional many-to-one association to TlegacyProductMapping
	@OneToMany(mappedBy="tproduct5")
	private Set<TlegacyProductMapping> tlegacyProductMappings5;

	//bi-directional one-to-one association to TmarketableProduct
	@OneToOne(mappedBy="tproduct", cascade={CascadeType.ALL}, fetch=FetchType.LAZY)
	private TmarketableProduct tmarketableProduct;

	//bi-directional one-to-one association to TmarketableProductComponent
	@OneToOne(mappedBy="tproduct", cascade={CascadeType.ALL}, fetch=FetchType.LAZY)
	private TmarketableProductComponent tmarketableProductComponent;

	//bi-directional many-to-one association to TproductType
    @ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="PRODUCT_TYPE_ID")
	private TproductType tproductType;

	//bi-directional one-to-one association to TproductDsp
	@OneToOne(mappedBy="tproduct", cascade={CascadeType.ALL}, fetch=FetchType.LAZY)
	private TproductDsp tproductDsp;

	//bi-directional one-to-one association to TproductMmcp
	@OneToOne(mappedBy="tproduct", cascade={CascadeType.ALL}, fetch=FetchType.LAZY)
	private TproductMmcp tproductMmcp;

	//bi-directional many-to-one association to TtickerDivisionProduct
	@OneToMany(mappedBy="tproduct")
	private Set<TtickerDivisionProduct> ttickerDivisionProducts;
	//bi-directional many-to-one association to TtransactionProductAttribute
	@OneToMany(mappedBy="tproduct", cascade={CascadeType.ALL})
	private Set<TtransactionProductAttribute> ttransactionProductAttributes;

	//bi-directional one-to-one association to TtuwProduct
	@OneToOne(mappedBy="tproduct", cascade={CascadeType.ALL}, fetch=FetchType.LAZY)
	private TtuwProduct ttuwProduct;

	//bi-directional one-to-one association to TtuwSubProduct
	@OneToOne(mappedBy="tproduct", cascade={CascadeType.ALL}, fetch=FetchType.LAZY)
	private TtuwSubProduct ttuwSubProduct;
	
	//bi-directional one-to-one association to TproductTowerTuwSubProdct
	@OneToOne(mappedBy="tproduct", fetch=FetchType.LAZY)
	private TproductTowerTuwSubProduct tproductTowerTuwSubProdct;

    public Tproduct() {
    }

	public int getProductId() {
		return this.productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public String getDeletedIn() {
		return this.deletedIn;
	}

	public void setDeletedIn(String deletedIn) {
		this.deletedIn = deletedIn;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public Set<TlegacyProductMapping> getTlegacyProductMappings1() {
		return this.tlegacyProductMappings1;
	}

	public void setTlegacyProductMappings1(Set<TlegacyProductMapping> tlegacyProductMappings1) {
		this.tlegacyProductMappings1 = tlegacyProductMappings1;
	}
	
	public Set<TlegacyProductMapping> getTlegacyProductMappings2() {
		return this.tlegacyProductMappings2;
	}

	public void setTlegacyProductMappings2(Set<TlegacyProductMapping> tlegacyProductMappings2) {
		this.tlegacyProductMappings2 = tlegacyProductMappings2;
	}
	
	public Set<TlegacyProductMapping> getTlegacyProductMappings3() {
		return this.tlegacyProductMappings3;
	}

	public void setTlegacyProductMappings3(Set<TlegacyProductMapping> tlegacyProductMappings3) {
		this.tlegacyProductMappings3 = tlegacyProductMappings3;
	}
	
	public Set<TlegacyProductMapping> getTlegacyProductMappings4() {
		return this.tlegacyProductMappings4;
	}

	public void setTlegacyProductMappings4(Set<TlegacyProductMapping> tlegacyProductMappings4) {
		this.tlegacyProductMappings4 = tlegacyProductMappings4;
	}
	
	public Set<TlegacyProductMapping> getTlegacyProductMappings5() {
		return this.tlegacyProductMappings5;
	}

	public void setTlegacyProductMappings5(Set<TlegacyProductMapping> tlegacyProductMappings5) {
		this.tlegacyProductMappings5 = tlegacyProductMappings5;
	}
	
	public TmarketableProduct getTmarketableProduct() {
		return this.tmarketableProduct;
	}

	public void setTmarketableProduct(TmarketableProduct tmarketableProduct) {
		this.tmarketableProduct = tmarketableProduct;
	}
	
	public TmarketableProductComponent getTmarketableProductComponent() {
		return this.tmarketableProductComponent;
	}

	public void setTmarketableProductComponent(TmarketableProductComponent tmarketableProductComponent) {
		this.tmarketableProductComponent = tmarketableProductComponent;
	}
	
	public TproductType getTproductType() {
		return this.tproductType;
	}

	public void setTproductType(TproductType tproductType) {
		this.tproductType = tproductType;
	}
	
	public TproductDsp getTproductDsp() {
		return this.tproductDsp;
	}

	public void setTproductDsp(TproductDsp tproductDsp) {
		this.tproductDsp = tproductDsp;
	}
	
	public TproductMmcp getTproductMmcp() {
		return this.tproductMmcp;
	}

	public void setTproductMmcp(TproductMmcp tproductMmcp) {
		this.tproductMmcp = tproductMmcp;
	}
	
	public Set<TtickerDivisionProduct> getTtickerDivisionProducts() {
		return this.ttickerDivisionProducts;
	}

	public void setTtickerDivisionProducts(Set<TtickerDivisionProduct> ttickerDivisionProducts) {
		this.ttickerDivisionProducts = ttickerDivisionProducts;
	}
	public Set<TtransactionProductAttribute> getTtransactionProductAttributes() {
		return this.ttransactionProductAttributes;
	}

	public void setTtransactionProductAttributes(Set<TtransactionProductAttribute> ttransactionProductAttributes) {
		this.ttransactionProductAttributes = ttransactionProductAttributes;
	}
	
	public TtuwProduct getTtuwProduct() {
		return this.ttuwProduct;
	}

	public void setTtuwProduct(TtuwProduct ttuwProduct) {
		this.ttuwProduct = ttuwProduct;
	}
	
	public TtuwSubProduct getTtuwSubProduct() {
		return this.ttuwSubProduct;
	}

	public void setTtuwSubProduct(TtuwSubProduct ttuwSubProduct) {
		this.ttuwSubProduct = ttuwSubProduct;
	}
	
	public TproductTowerTuwSubProduct getTproductTowerTuwSubProdct() {
		return this.tproductTowerTuwSubProdct;
	}

	public void setTproductTowerTuwSubProdct(TproductTowerTuwSubProduct tproductTowerTuwSubProdct) {
		this.tproductTowerTuwSubProdct = tproductTowerTuwSubProdct;
	}		

}