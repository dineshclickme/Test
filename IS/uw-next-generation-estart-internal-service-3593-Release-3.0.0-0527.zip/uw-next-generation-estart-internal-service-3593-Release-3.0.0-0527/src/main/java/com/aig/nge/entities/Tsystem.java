package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;

import org.apache.openjpa.persistence.DataCache;

import java.sql.Timestamp;
import java.util.Date;
import java.util.Set;


/**
 * The persistent class for the TSYSTEM database table.
 * 
 */
@Entity
@DataCache
public class Tsystem implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="SYSTEM_ID")
	private short systemId;

    @Temporal( TemporalType.DATE)
	@Column(name="CERTIFICATE_EXPIRATION_DT")
	private Date certificateExpirationDt;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="CREATE_TS")
	private Timestamp createTs;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="CREATE_USER_ID")
	private String createUserId;

	@Column(name="SYSTEM_NM")
	private String systemNm;

	@Column(name="SYSTEM_SHORT_NM")
	private String systemShortNm;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="UPDATE_TS")
	private Timestamp updateTs;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="UPDATE_USER_ID")
	private String updateUserId;

	//bi-directional many-to-one association to Terror
	@OneToMany(mappedBy="tsystem", cascade={CascadeType.ALL})
	private Set<Terror> terrors;

	//bi-directional many-to-one association to TlegacyRulesViolation
	@OneToMany(mappedBy="tsystem")
	private Set<TlegacyRulesViolation> tlegacyRulesViolations;


	//bi-directional many-to-one association to TpartyAction
	@OneToMany(mappedBy="tsystem", cascade={CascadeType.ALL})
	private Set<TpartyAction> tpartyActions;

	//bi-directional many-to-one association to Tproperty
	@OneToMany(mappedBy="tsystem", cascade={CascadeType.ALL})
	private Set<Tproperty> tproperties;

	//bi-directional many-to-one association to Tsubmission
	@OneToMany(mappedBy="tsystem", cascade={CascadeType.ALL})
	private Set<Tsubmission> tsubmissions;

	//bi-directional many-to-one association to TsystemMethod
	@OneToMany(mappedBy="tsystem", cascade={CascadeType.ALL})
	private Set<TsystemMethod> tsystemMethods;

	//bi-directional many-to-one association to TlegacyPolicySplitRule
	@OneToMany(mappedBy="tsystem", cascade={CascadeType.ALL})
	private Set<TlegacyPolicySplitRule> tlegacyPolicySplitRules;

    public Tsystem() {
    }

	public short getSystemId() {
		return this.systemId;
	}

	public void setSystemId(short systemId) {
		this.systemId = systemId;
	}

	public Date getCertificateExpirationDt() {
		return this.certificateExpirationDt;
	}

	public void setCertificateExpirationDt(Date certificateExpirationDt) {
		this.certificateExpirationDt = certificateExpirationDt;
	}

	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public String getSystemNm() {
		return this.systemNm;
	}

	public void setSystemNm(String systemNm) {
		this.systemNm = systemNm;
	}

	public String getSystemShortNm() {
		return this.systemShortNm;
	}

	public void setSystemShortNm(String systemShortNm) {
		this.systemShortNm = systemShortNm;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public Set<Terror> getTerrors() {
		return this.terrors;
	}

	public void setTerrors(Set<Terror> terrors) {
		this.terrors = terrors;
	}
	
	
	public Set<TlegacyRulesViolation> getTlegacyRulesViolations() {
		return this.tlegacyRulesViolations;
	}

	public void setTlegacyRulesViolations(Set<TlegacyRulesViolation> tlegacyRulesViolations) {
		this.tlegacyRulesViolations = tlegacyRulesViolations;
	}
	
	public Set<TpartyAction> getTpartyActions() {
		return this.tpartyActions;
	}

	public void setTpartyActions(Set<TpartyAction> tpartyActions) {
		this.tpartyActions = tpartyActions;
	}
	
	public Set<Tproperty> getTproperties() {
		return this.tproperties;
	}

	public void setTproperties(Set<Tproperty> tproperties) {
		this.tproperties = tproperties;
	}
	
	public Set<Tsubmission> getTsubmissions() {
		return this.tsubmissions;
	}

	public void setTsubmissions(Set<Tsubmission> tsubmissions) {
		this.tsubmissions = tsubmissions;
	}
	
	public Set<TsystemMethod> getTsystemMethods() {
		return this.tsystemMethods;
	}

	public void setTsystemMethods(Set<TsystemMethod> tsystemMethods) {
		this.tsystemMethods = tsystemMethods;
	}
	
	public Set<TlegacyPolicySplitRule> getTlegacyPolicySplitRules() {
		return this.tlegacyPolicySplitRules;
	}

	public void setTlegacyPolicySplitRules(Set<TlegacyPolicySplitRule> tlegacyPolicySplitRules) {
		this.tlegacyPolicySplitRules = tlegacyPolicySplitRules;
	}
	
}