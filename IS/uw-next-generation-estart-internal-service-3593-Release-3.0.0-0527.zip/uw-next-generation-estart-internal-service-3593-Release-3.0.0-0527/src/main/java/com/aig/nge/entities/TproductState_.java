package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SetAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-02-19T16:13:03.937+0530")
@StaticMetamodel(TproductState.class)
public class TproductState_ {
	public static volatile SingularAttribute<TproductState, Short> productStateId;
	public static volatile SingularAttribute<TproductState, Timestamp> createTs;
	public static volatile SingularAttribute<TproductState, String> createUserId;
	public static volatile SingularAttribute<TproductState, String> productStateDs;
	public static volatile SingularAttribute<TproductState, String> productStateNm;
	public static volatile SingularAttribute<TproductState, Timestamp> updateTs;
	public static volatile SingularAttribute<TproductState, String> updateUserId;
	public static volatile SetAttribute<TproductState, TtransactionComponent> ttransactionComponents;
}
