package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SetAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-02-19T16:13:04.458+0530")
@StaticMetamodel(Tstatus.class)
public class Tstatus_ {
	public static volatile SingularAttribute<Tstatus, Short> statusId;
	public static volatile SingularAttribute<Tstatus, Timestamp> createTs;
	public static volatile SingularAttribute<Tstatus, String> createUserId;
	public static volatile SingularAttribute<Tstatus, String> statusDs;
	public static volatile SingularAttribute<Tstatus, String> statusNm;
	public static volatile SingularAttribute<Tstatus, Timestamp> updateTs;
	public static volatile SingularAttribute<Tstatus, String> updateUserId;
	public static volatile SetAttribute<Tstatus, Tblock> tblocks;
	public static volatile SetAttribute<Tstatus, Tevent> tevents1;
	public static volatile SetAttribute<Tstatus, Tevent> tevents2;
	public static volatile SetAttribute<Tstatus, TproductTowerAutoCloseRule> tproductTowerAutoCloseRules1;
	public static volatile SetAttribute<Tstatus, TproductTowerAutoCloseRule> tproductTowerAutoCloseRules2;
	public static volatile SetAttribute<Tstatus, TproductTowerAutoCloseRule> tproductTowerAutoCloseRules3;
	public static volatile SetAttribute<Tstatus, TproductTowerAutoCloseRule> tproductTowerAutoCloseRules4;
	public static volatile SingularAttribute<Tstatus, TstatusType> tstatusType;
	public static volatile SetAttribute<Tstatus, TstatusCondition> tstatusConditions1;
	public static volatile SetAttribute<Tstatus, TstatusCondition> tstatusConditions2;
	public static volatile SetAttribute<Tstatus, TstatusReasonType> tstatusReasonTypes;
	public static volatile SetAttribute<Tstatus, TstatusTransition> tstatusTransitions;
	public static volatile SetAttribute<Tstatus, TtransactionComponentStatus> ttransactionComponentStatuses;
	public static volatile SetAttribute<Tstatus, Tbranch> tbranches;
}
