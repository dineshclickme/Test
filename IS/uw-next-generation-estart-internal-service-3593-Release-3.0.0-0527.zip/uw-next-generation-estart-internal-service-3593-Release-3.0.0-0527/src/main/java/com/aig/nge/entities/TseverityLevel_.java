package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SetAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-06-19T14:59:45.994+0530")
@StaticMetamodel(TseverityLevel.class)
public class TseverityLevel_ {
	public static volatile SingularAttribute<TseverityLevel, String> severityLevelCd;
	public static volatile SingularAttribute<TseverityLevel, Timestamp> createTs;
	public static volatile SingularAttribute<TseverityLevel, String> createUserId;
	public static volatile SingularAttribute<TseverityLevel, String> severityLevelDs;
	public static volatile SingularAttribute<TseverityLevel, Timestamp> updateTs;
	public static volatile SingularAttribute<TseverityLevel, String> updateUserId;
	public static volatile SetAttribute<TseverityLevel, Terror> terrors;
	public static volatile SetAttribute<TseverityLevel, TlegacyError> tlegacyErrors;
}
