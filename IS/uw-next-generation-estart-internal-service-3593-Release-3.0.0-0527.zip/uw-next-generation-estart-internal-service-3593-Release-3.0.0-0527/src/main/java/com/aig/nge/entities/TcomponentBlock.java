package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the TCOMPONENT_BLOCK database table.
 * 
 */
@Entity
@Table(name="TCOMPONENT_BLOCK")
public class TcomponentBlock implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="BLOCK_NO")
	private int blockNo;

	@Column(name="CREATE_TS")
	private Timestamp createTs;

	@Column(name="CREATE_USER_ID")
	private String createUserId;

	@Column(name="SYSTEM_ID")
	private short systemId;

	@Column(name="UPDATE_TS")
	private Timestamp updateTs;

	@Column(name="UPDATE_USER_ID")
	private String updateUserId;

	//bi-directional one-to-one association to Tblock
	@OneToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="BLOCK_NO")
	private Tblock tblock;

	//bi-directional many-to-one association to TtransactionComponent
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="BLOCKING_COMPONENT_ID")
	private TtransactionComponent ttransactionComponent;

    public TcomponentBlock() {
    }

	public int getBlockNo() {
		return this.blockNo;
	}

	public void setBlockNo(int blockNo) {
		this.blockNo = blockNo;
	}

	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public short getSystemId() {
		return this.systemId;
	}

	public void setSystemId(short systemId) {
		this.systemId = systemId;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public Tblock getTblock() {
		return this.tblock;
	}

	public void setTblock(Tblock tblock) {
		this.tblock = tblock;
	}
	
	public TtransactionComponent getTtransactionComponent() {
		return this.ttransactionComponent;
	}

	public void setTtransactionComponent(TtransactionComponent ttransactionComponent) {
		this.ttransactionComponent = ttransactionComponent;
	}
	
}