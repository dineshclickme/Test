package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SetAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-02-19T16:13:03.696+0530")
@StaticMetamodel(TpartyRelationType.class)
public class TpartyRelationType_ {
	public static volatile SingularAttribute<TpartyRelationType, Short> relationTypeId;
	public static volatile SingularAttribute<TpartyRelationType, Timestamp> createTs;
	public static volatile SingularAttribute<TpartyRelationType, String> createUserId;
	public static volatile SingularAttribute<TpartyRelationType, String> relationTypeNm;
	public static volatile SingularAttribute<TpartyRelationType, Timestamp> updateTs;
	public static volatile SingularAttribute<TpartyRelationType, String> updateUserId;
	public static volatile SetAttribute<TpartyRelationType, TrelatedParty> trelatedParties;
}
