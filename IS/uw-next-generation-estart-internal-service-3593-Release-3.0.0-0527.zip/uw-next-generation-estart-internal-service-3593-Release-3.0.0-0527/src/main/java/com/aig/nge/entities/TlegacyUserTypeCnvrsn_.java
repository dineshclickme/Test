package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2016-01-30T17:32:13.510+0530")
@StaticMetamodel(TlegacyUserTypeCnvrsn.class)
public class TlegacyUserTypeCnvrsn_ {
	public static volatile SingularAttribute<TlegacyUserTypeCnvrsn, String> adbuserEmpltypCd;
	public static volatile SingularAttribute<TlegacyUserTypeCnvrsn, Timestamp> createTs;
	public static volatile SingularAttribute<TlegacyUserTypeCnvrsn, String> createUserId;
	public static volatile SingularAttribute<TlegacyUserTypeCnvrsn, Timestamp> updateTs;
	public static volatile SingularAttribute<TlegacyUserTypeCnvrsn, String> updateUserId;
	public static volatile SingularAttribute<TlegacyUserTypeCnvrsn, String> userTypeCd;
}
