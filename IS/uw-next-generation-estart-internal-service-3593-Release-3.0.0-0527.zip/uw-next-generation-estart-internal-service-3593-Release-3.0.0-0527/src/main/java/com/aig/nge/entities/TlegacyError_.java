package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SetAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-06-19T14:59:45.691+0530")
@StaticMetamodel(TlegacyError.class)
public class TlegacyError_ {
	public static volatile SingularAttribute<TlegacyError, Short> legacyErrorId;
	public static volatile SingularAttribute<TlegacyError, Timestamp> createTs;
	public static volatile SingularAttribute<TlegacyError, String> createUserId;
	public static volatile SingularAttribute<TlegacyError, String> legacyErrorCd;
	public static volatile SingularAttribute<TlegacyError, String> legacyErrorMesageTx;
	public static volatile SingularAttribute<TlegacyError, Timestamp> updateTs;
	public static volatile SingularAttribute<TlegacyError, String> updateUserId;
	public static volatile SingularAttribute<TlegacyError, String> uwSystemId;
	public static volatile SetAttribute<TlegacyError, TerrorMapping> terrorMappings;
	public static volatile SingularAttribute<TlegacyError, TseverityLevel> tseverityLevel;
	public static volatile SingularAttribute<TlegacyError, TerrorType> terrorType;
	public static volatile SetAttribute<TlegacyError, TlegacyRulesViolation> tlegacyRulesViolations;
}
