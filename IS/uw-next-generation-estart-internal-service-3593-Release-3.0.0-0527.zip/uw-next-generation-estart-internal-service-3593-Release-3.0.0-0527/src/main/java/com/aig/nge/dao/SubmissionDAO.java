package com.aig.nge.dao;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.orm.jpa.JpaSystemException;
import org.springframework.stereotype.Repository;

import com.aig.nge.entities.Tparty;
import com.aig.nge.entities.TrelatedParty;
import com.aig.nge.entities.Tsubmission;
import com.aig.nge.entities.TsubmissionPool;
import com.aig.nge.helper.CommonServiceHelper;
import com.aig.nge.repository.TRelatedPartyRepository;
import com.aig.nge.repository.TSubmissionPoolRepository;
import com.aig.nge.repository.TSubmissionRepository;
import com.aig.nge.utilities.AIGCIExceptionMsg;
import com.aig.nge.utilities.NGEConstants;
import com.aig.nge.utilities.NGEDateUtil;
import com.aig.nge.utilities.NGEErrorCodes;
import com.aig.nge.utilities.NGEProperties;
import com.aig.nge.utilities.NGESession;
import com.aig.nge.utilities.SequenceNumberGeneration;

/**
 * @author DineshKumar This DAO class is used for accessing the Submission
 *         related repositories Used repositories are : TSubmissionRepository
 * 
 */
@Repository
public class SubmissionDAO extends BaseDAO {
	private static final Logger logger = LogManager.getLogger(SubmissionDAO.class);
	
	@Autowired
	TSubmissionRepository submissionRepository;

	@Autowired
	TRelatedPartyRepository relatedPartyRepository;
	
	@Autowired
	TSubmissionPoolRepository submissionPoolRepository;
	
	@Autowired
	private SequenceNumberGeneration sequenceNumberGeneration;
	
	@Autowired
	private NGEProperties ngeProperties;
	
	/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
	@Autowired
	private CommonServiceHelper commonServiceHelper;
	/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
	/**
	 * @param accountData
	 * @param producerData
	 * @param systemData
	 * @param userId
	 * @return
	 * @throws JpaSystemException
	 *             This method is used for creating a new Submission
	 * @throws AIGCIExceptionMsg 
	 */
	public Tsubmission createSubmission(Tparty accountData,
			Tparty producerData)
			throws JpaSystemException, AIGCIExceptionMsg {
		Tsubmission submissionData = populateSubmission(accountData,
				producerData);
		submissionData = submissionRepository.save(submissionData);
		return submissionData;
	}

	/**
	 * @return This method used to get the submission number. 
	 * Submission number will be fetched from TSUBMISSION_POOL table. It will be fetched based on SUBMISSION_POOL_ID & USED_IN.
	 * If no records are available, then it will re-attempt based on the configurable parameter. 
	 * Even after re-attempts, if it fails, then it will throw error. 
	 * @throws AIGCIExceptionMsg 
	 */
	public String getSubmissionNo() throws AIGCIExceptionMsg {

		TsubmissionPool submissionPoolData = null;
		boolean retriedToGetSubmission = false;
		
		submissionPoolData = submissionPoolRepository.findBySubmissionPoolId(String.valueOf(getSubmissionPoolId()), NGEConstants.NO);
		
		String submissionNo = NGEConstants.EMPTY_STRING;
		Tsubmission existingSubmissionRecord = null;
		
		if(submissionPoolData == null)
		{
			logger.error("SubmissionPoolData is NULL in first try");			
			submissionPoolData = retryToGetEligibleSubmission();
			retriedToGetSubmission = true;
		}
		if(submissionPoolData != null)
		{
			if(!retriedToGetSubmission){
				
				/* December 2017 Maintenance Release 2.8 - Resolve issue with submission number pool (1603) - Starts */
				existingSubmissionRecord = submissionRepository.findOne(submissionPoolData.getSubmissionNo());
				/* December 2017 Maintenance Release 2.8 - Resolve issue with submission number pool (1603) - Ends */
				
				if(existingSubmissionRecord == null){
					
					submissionPoolData.setUsedIn(NGEConstants.YES);
					submissionPoolData.setUpdateTs(NGEDateUtil.getTodayDate());
					submissionPoolData.setUpdateUserId(NGESession.getSessionData().getUserId());
					submissionPoolData = submissionPoolRepository.save(submissionPoolData);
					
					/* December 2017 Maintenance Release 2.8 - Resolve issue with submission number pool (1603) - Starts */
					submissionNo = submissionPoolData.getSubmissionNo();
					/* December 2017 Maintenance Release 2.8 - Resolve issue with submission number pool (1603) - Ends */
				}
				else{
					
					submissionPoolData = retryToGetEligibleSubmission();
					
					if(submissionPoolData != null){
						
						submissionPoolData.setUsedIn(NGEConstants.YES);
						submissionPoolData.setUpdateTs(NGEDateUtil.getTodayDate());
						submissionPoolData.setUpdateUserId(NGESession.getSessionData().getUserId());
						submissionPoolData = submissionPoolRepository.save(submissionPoolData);
						
						/* December 2017 Maintenance Release 2.8 - Resolve issue with submission number pool (1603) - Starts */
						submissionNo = submissionPoolData.getSubmissionNo();
						/* December 2017 Maintenance Release 2.8 - Resolve issue with submission number pool (1603) - Ends */
					}
				}
			}
			else{
				
				submissionPoolData.setUsedIn(NGEConstants.YES);
				submissionPoolData.setUpdateTs(NGEDateUtil.getTodayDate());
				submissionPoolData.setUpdateUserId(NGESession.getSessionData().getUserId());
				submissionPoolData = submissionPoolRepository.save(submissionPoolData);
				
				/* December 2017 Maintenance Release 2.8 - Resolve issue with submission number pool (1603) - Starts */
				submissionNo = submissionPoolData.getSubmissionNo();
				/* December 2017 Maintenance Release 2.8 - Resolve issue with submission number pool (1603) - Ends */
			}
		}
		return submissionNo;
	}

	public Long getSubmissionPoolId() throws AIGCIExceptionMsg {
		HashMap<String, String> sequenceNames = new HashMap<>();
		sequenceNames.put(NGEConstants.Sequence.SUBMISSION_SEQ, "INT");
		HashMap<String, Object> outputSequenceMap = sequenceNumberGeneration.getNextSequenceNumber(sequenceNames);
		Long submissionPoolId = Long.parseLong(outputSequenceMap.get(NGEConstants.Sequence.SUBMISSION_SEQ).toString());
		
		return submissionPoolId;
	}
	
	
	public TsubmissionPool retryToGetEligibleSubmission() throws AIGCIExceptionMsg{
		
		TsubmissionPool submissionPoolData = null; 
		int submissionNumberRetries = 0;
		String submissionNo = NGEConstants.EMPTY_STRING;
		Tsubmission existingSubmissionRecord = null;
		
		try{
			submissionNumberRetries = Integer.parseInt(ngeProperties.readMessageFromFile(NGEConstants.FETCH_SUBMISSION_NUMBER_RETRIES,NGEConstants.CONFIG_FILE_NAME,true));
			logger.debug("submissionNumberRetries : "+submissionNumberRetries);
		}
		catch(Exception e)
		{
			/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
			if(commonServiceHelper.checkForRetryExceptions(e, 114, NGEConstants.CatchExceptionTypes.THROW_HANDLED_EXCEPTION))
			{
				logger.error("checkForRetryExceptions returned true");
			}
			/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
			ngeException.throwException(NGEErrorCodes.NO_SUBMISSION_NUMBERS_AVAILABLE,NGEErrorCodes.ERROR_TYPE, "FETCH_SUBMISSION_NUMBER_RETRIES IS NOT AVAILABLE / NOT NUMERIC", null);
		}
		for(int i=0; i<submissionNumberRetries; i++)
		{
			submissionPoolData = submissionPoolRepository.findBySubmissionPoolId(String.valueOf(getSubmissionPoolId()), NGEConstants.NO);
			if(submissionPoolData != null)
			{
				/* December 2017 Maintenance Release 2.8 - Resolve issue with submission number pool (1603) - Starts */
				// During every fetch of a new submission number, need to check whether it is already consumed in eStart or not
				submissionNo = submissionPoolData.getSubmissionNo();			
				existingSubmissionRecord = submissionRepository.findOne(submissionNo);
				if(existingSubmissionRecord == null){					
					logger.debug("submissionPoolData fetch - breaking the loop");
					break;
				}		
				/* December 2017 Maintenance Release 2.8 - Resolve issue with submission number pool (1603) - Ends */
			}
		}
		if(submissionPoolData == null)
		{
			ngeException.throwException(NGEErrorCodes.NO_SUBMISSION_NUMBERS_AVAILABLE,NGEErrorCodes.ERROR_TYPE, null, null);
		}
		/* December 2017 Maintenance Release 2.8 - Resolve issue with submission number pool (1603) - Starts */
		/*else{
			
				submissionNo = submissionPoolData.getSubmissionNo();			
				existingSubmissionRecord = submissionRepository.findOne(submissionNo);
				if(existingSubmissionRecord != null){
					
					logger.info("SubmissionPoolData is NULL in Last try");
					ngeException.throwException(NGEErrorCodes.NO_SUBMISSION_NUMBERS_AVAILABLE,NGEErrorCodes.ERROR_TYPE, null, null);
				}
			}*/
		/* December 2017 Maintenance Release 2.8 - Resolve issue with submission number pool (1603) - Ends */
		
		return submissionPoolData;
	}
	
	
	/**
	 * @param accountData
	 * @param producerData
	 * @param systemData
	 * @param userId
	 * @return This method is used to populate the Tsubmission entity with the
	 *         given parameters
	 * @throws AIGCIExceptionMsg 
	 */
	public Tsubmission populateSubmission(Tparty accountData,
			Tparty producerData) throws AIGCIExceptionMsg {
		Tsubmission submissionData = new Tsubmission();
		submissionData.setSubmissionNo(String.valueOf(getSubmissionNo()));
		submissionData.setTparty2(accountData);
		submissionData.setTparty1(producerData);
		submissionData.setSubmissionTs(NGEDateUtil.getTodayDate());
		submissionData.setTsystem(NGESession.getSessionData().getSystem());
		submissionData.setCreateUserId(NGESession.getSessionData().getUserId());
		submissionData.setCreateTs(NGEDateUtil.getTodayDate());
		return submissionData;
	}
	
	public List<TrelatedParty> findRelatedParty(int partyId){
		
		List<TrelatedParty> relatedDNBList = null;
		relatedDNBList = relatedPartyRepository.findRelatedParty(partyId);
		return relatedDNBList;		
	}
	
	public Tsubmission findSubmissionNo(Long submissionNo) throws AIGCIExceptionMsg{		
		Tsubmission submissionData = null;
		String submissionNoVal = "";
		submissionNoVal = submissionNo.toString();
		submissionData=submissionRepository.findOne(submissionNoVal);		
		if(submissionData == null){
			ngeException.throwException( NGEErrorCodes.INVALID_SUBMISSION_NO_VALUE, NGEErrorCodes.ERROR_TYPE, "Invalid Submission Number. Given Submission Number is either blank or does not exist in NGE",null);
		}
		
		return submissionData;
	}
	
	public Tsubmission findSubmissionNoForGetSubmission(Long submissionNo) throws AIGCIExceptionMsg{		
		Tsubmission submissionData = null;
		String submissionNoVal = "";
		submissionNoVal = submissionNo.toString();
		submissionData=submissionRepository.getSubmissionForGetSubmission(String.valueOf(submissionNoVal));		
		if(submissionData == null){
			ngeException.throwException( NGEErrorCodes.INVALID_SUBMISSION_NO_VALUE, NGEErrorCodes.ERROR_TYPE, "Invalid Submission Number. Given Submission Number is either blank or does not exist in NGE",null);
		}
		
		return submissionData;
	}
	
	public boolean findLegacySubmissionNo(String submissionNo) throws AIGCIExceptionMsg{		
		//Tsubmission submissionData = null;
		String submissionCount =null;
		boolean isFound=true;
        submissionCount=submissionRepository.checkSubmission(submissionNo);	
        if(submissionCount==null){
        	isFound=false;
			ngeException.throwException( NGEErrorCodes.INVALID_SUBMISSION, NGEErrorCodes.ERROR_TYPE_LOGICAL, "Input Submission number is invalid",null);
		}
		
		return isFound;
	}

		public List<Tsubmission> findSubmission(String policyNo,Date effectiveDt,short issuingCm) throws AIGCIExceptionMsg{
			List<Tsubmission> submissionsList = submissionRepository.getSubmission(policyNo, NGEConstants.NO,effectiveDt,issuingCm);
			
			if(submissionsList.isEmpty()){
				ngeException.throwException("ERRPR001", NGEErrorCodes.ERROR_TYPE, "Invalid Prior Policy Number. Given Prior Policy Number is either blank or does not exist in NGE",null);
			}
			return submissionsList;
		}	
		
		public List<Tsubmission> findSubmissions(String policyNo) throws AIGCIExceptionMsg{
			List<Tsubmission> submissionsList = submissionRepository.getSubmissions(policyNo, NGEConstants.NO);
			
			if(submissionsList.isEmpty()){
				ngeException.throwException(NGEErrorCodes.NO_SUBMISSIONS,
						NGEErrorCodes.ERROR_TYPE, "No Submissions for the given request", null);
			}
			return submissionsList;
		}
			
		public List<Object[]> getSubmissionResponseByDUNSAccountNm(String organizationNm, String limitCount) throws AIGCIExceptionMsg{
			
			List<Object[]> submissionDataList = null;
										
			submissionDataList = submissionRepository.getSubmissionsResponseByDUNSAccountName(organizationNm.toUpperCase(), new PageRequest(0, Integer.parseInt(limitCount)));
			
			return submissionDataList;
		}
		
		public List<Object[]> getSubmissionResponseByShellAccountNm(String organizationNm, String limitCount, int recordFetchedCount) throws AIGCIExceptionMsg{
			
			List<Object[]> submissionDataList = null;
			int finalFetchCount = 0;
			
			finalFetchCount = Integer.parseInt(limitCount) - recordFetchedCount;
			
			submissionDataList = submissionRepository.getSubmissionsResponseByShellAccountName(organizationNm.toUpperCase(), new PageRequest(0, finalFetchCount));
			
			return submissionDataList;
		}
		
		/* Q1 2018 Maintenance Release - Validate System Authorization Service - Starts */
		public Tsubmission getSubmissionDetailsUsingSubmissionNo(String submissionNo){
			
			Tsubmission submissionData = null;
			submissionData = submissionRepository.getSubmissionDetailsUsingSubmissionNo(submissionNo);
			
			return submissionData;			
		}		
		
		public Tsubmission getSubmissionDetailsUsingTransactionId(String transactionId){
			
			Tsubmission submissionData = null;
			submissionData = submissionRepository.getSubmissionDetailsUsingTransactionId(transactionId);
			
			return submissionData;			
		}
		
		public Tsubmission getSubmissionDetailsUsingSubmissionNoAndTransactionId(String submissionNo, String transactionId){
			
			Tsubmission submissionData = null;
			submissionData = submissionRepository.getSubmissionDetailsUsingSubmissionNoAndTransactionId(submissionNo, transactionId);
			
			return submissionData;			
		}
		/* Q1 2018 Maintenance Release - Validate System Authorization Service - Ends */
	
		/*MDM Release. Changes to replace SOLR - Starts*/
		public List<Object[]> getSubmissionCount(List<String> accountNumbers){
				
			List<Object[]> submissionCountObject = submissionRepository.getSubmissionCount(accountNumbers);
			return submissionCountObject;			
		}
		
		public List<Object[]> getSubmissionCollection(String accountNumber){
					
			List<Object[]> submissionCollectionObject = submissionRepository.getSubmissionCollection(accountNumber);
			return submissionCollectionObject;			
		}
		/*MDM Release. Changes to replace SOLR - Ends*/

}
