package com.aig.nge.entities;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-02-19T16:13:04.765+0530")
@StaticMetamodel(TtransactionAttributePK.class)
public class TtransactionAttributePK_ {
	public static volatile SingularAttribute<TtransactionAttributePK, String> transactionId;
	public static volatile SingularAttribute<TtransactionAttributePK, Short> versionSqn;
	public static volatile SingularAttribute<TtransactionAttributePK, Short> attributeId;
	public static volatile SingularAttribute<TtransactionAttributePK, Short> attributeSqn;
}
