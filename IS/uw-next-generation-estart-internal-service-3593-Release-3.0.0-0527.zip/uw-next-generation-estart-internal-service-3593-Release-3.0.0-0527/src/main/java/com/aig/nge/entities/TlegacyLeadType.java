package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Set;


/**
 * The persistent class for the TLEGACY_LEAD_TYPE database table.
 * 
 */
@Entity
@Table(name="TLEGACY_LEAD_TYPE")
public class TlegacyLeadType implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private TlegacyLeadTypePK id;

	@Column(name="CREATE_TS")
	private Timestamp createTs;

	@Column(name="CREATE_USER_ID")
	private String createUserId;

	@Column(name="LEAD_TYPE_NM")
	private String leadTypeNm;

	@Column(name="UPDATE_TS")
	private Timestamp updateTs;

	@Column(name="UPDATE_USER_ID")
	private String updateUserId;

	//bi-directional many-to-one association to TlegacyLeadSubtype
	@OneToMany(mappedBy="tlegacyLeadType")
	private Set<TlegacyLeadSubtype> tlegacyLeadSubtypes;

	//bi-directional many-to-one association to Tsource
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="SOURCE_CD")
	private Tsource tsource;

    public TlegacyLeadType() {
    }

	public TlegacyLeadTypePK getId() {
		return this.id;
	}

	public void setId(TlegacyLeadTypePK id) {
		this.id = id;
	}
	
	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public String getLeadTypeNm() {
		return this.leadTypeNm;
	}

	public void setLeadTypeNm(String leadTypeNm) {
		this.leadTypeNm = leadTypeNm;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public Set<TlegacyLeadSubtype> getTlegacyLeadSubtypes() {
		return this.tlegacyLeadSubtypes;
	}

	public void setTlegacyLeadSubtypes(Set<TlegacyLeadSubtype> tlegacyLeadSubtypes) {
		this.tlegacyLeadSubtypes = tlegacyLeadSubtypes;
	}
	
	public Tsource getTsource() {
		return this.tsource;
	}

	public void setTsource(Tsource tsource) {
		this.tsource = tsource;
	}
	
}