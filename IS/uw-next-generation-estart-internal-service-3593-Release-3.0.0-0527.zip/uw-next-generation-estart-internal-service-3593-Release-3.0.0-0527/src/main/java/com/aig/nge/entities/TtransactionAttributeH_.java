package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-03-02T12:10:25.000+0530")
@StaticMetamodel(TtransactionAttributeH.class)
public class TtransactionAttributeH_ {
	public static volatile SingularAttribute<TtransactionAttributeH, TtransactionAttributeHPK> id;
	public static volatile SingularAttribute<TtransactionAttributeH, String> attributeVal;
	public static volatile SingularAttribute<TtransactionAttributeH, Timestamp> createTs;
	public static volatile SingularAttribute<TtransactionAttributeH, String> createUserId;
	public static volatile SingularAttribute<TtransactionAttributeH, Short> systemId;
	public static volatile SingularAttribute<TtransactionAttributeH, String> updateUserId;
	public static volatile SingularAttribute<TtransactionAttributeH, Timestamp> updateTs;
}
