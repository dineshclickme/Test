package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the TATTRIBUTE_GROUP database table.
 * 
 */
@Entity
@Table(name="TATTRIBUTE_GROUP")
public class TattributeGroup implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private TattributeGroupPK id;

	@Column(name="COMMENT_TX")
	private String commentTx;

	@Column(name="CREATE_TS")
	private Timestamp createTs;

	@Column(name="CREATE_USER_ID")
	private String createUserId;

	@Column(name="ORDER_SQN")
	private short orderSqn;

	@Column(name="UPDATE_TS")
	private Timestamp updateTs;

	@Column(name="UPDATE_USER_ID")
	private String updateUserId;

	//bi-directional many-to-one association to Tattribute
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="ATTRIBUTE_ID")
	private Tattribute tattribute;

	//bi-directional many-to-one association to Tgroup
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="GROUP_ID")
	private Tgroup tgroup;

    public TattributeGroup() {
    }

	public TattributeGroupPK getId() {
		return this.id;
	}

	public void setId(TattributeGroupPK id) {
		this.id = id;
	}
	
	public String getCommentTx() {
		return this.commentTx;
	}

	public void setCommentTx(String commentTx) {
		this.commentTx = commentTx;
	}

	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public short getOrderSqn() {
		return this.orderSqn;
	}

	public void setOrderSqn(short orderSqn) {
		this.orderSqn = orderSqn;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public Tattribute getTattribute() {
		return this.tattribute;
	}

	public void setTattribute(Tattribute tattribute) {
		this.tattribute = tattribute;
	}
	
	public Tgroup getTgroup() {
		return this.tgroup;
	}

	public void setTgroup(Tgroup tgroup) {
		this.tgroup = tgroup;
	}
	
}