package com.aig.nge.entities;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-04-15T15:31:46.838+0530")
@StaticMetamodel(TlegacyLeadSourceTypePK.class)
public class TlegacyLeadSourceTypePK_ {
	public static volatile SingularAttribute<TlegacyLeadSourceTypePK, String> sourceCd;
	public static volatile SingularAttribute<TlegacyLeadSourceTypePK, String> leadSourceTypeCd;
}
