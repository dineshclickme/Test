package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SetAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-02-19T16:13:04.312+0530")
@StaticMetamodel(TreferenceGroup.class)
public class TreferenceGroup_ {
	public static volatile SingularAttribute<TreferenceGroup, Short> referenceGroupId;
	public static volatile SingularAttribute<TreferenceGroup, Timestamp> createTs;
	public static volatile SingularAttribute<TreferenceGroup, String> createUserId;
	public static volatile SingularAttribute<TreferenceGroup, String> groupDs;
	public static volatile SingularAttribute<TreferenceGroup, Timestamp> updateTs;
	public static volatile SingularAttribute<TreferenceGroup, String> updateUserId;
	public static volatile SetAttribute<TreferenceGroup, TattributeReference> tattributeReferences;
}
