package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SetAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-02-24T11:59:50.386+0530")
@StaticMetamodel(TtableAttribute.class)
public class TtableAttribute_ {
	public static volatile SingularAttribute<TtableAttribute, TtableAttributePK> id;
	public static volatile SingularAttribute<TtableAttribute, Timestamp> createTs;
	public static volatile SingularAttribute<TtableAttribute, String> createUserId;
	public static volatile SingularAttribute<TtableAttribute, Timestamp> updateTs;
	public static volatile SingularAttribute<TtableAttribute, String> updateUserId;
	public static volatile SetAttribute<TtableAttribute, TproductTowerAttribute> tproductTowerAttributes;
	public static volatile SingularAttribute<TtableAttribute, Tattribute> tattribute;
	public static volatile SingularAttribute<TtableAttribute, Ttable> ttable;
	public static volatile SetAttribute<TtableAttribute, TtableAttributeReference> ttableAttributeReferences;
}
