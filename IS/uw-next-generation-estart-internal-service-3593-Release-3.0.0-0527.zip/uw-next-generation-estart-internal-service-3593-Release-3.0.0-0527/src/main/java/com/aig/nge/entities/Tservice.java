package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;

import org.apache.openjpa.persistence.DataCache;
import java.sql.Timestamp;
import java.util.Set;


/**
 * The persistent class for the TSERVICE database table.
 * 
 */
@Entity
@DataCache
public class Tservice implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="SERVICE_ID")
	private short serviceId;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="CREATE_TS")
	private Timestamp createTs;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="CREATE_USER_ID")
	private String createUserId;

	@Column(name="SERVICE_NM")
	private String serviceNm;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="UPDATE_TS")
	private Timestamp updateTs;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="UPDATE_USER_ID")
	private String updateUserId;

	//bi-directional many-to-one association to Tmethod
	@OneToMany(mappedBy="tservice", cascade={CascadeType.ALL})
	private Set<Tmethod> tmethods;

    public Tservice() {
    }

	public short getServiceId() {
		return this.serviceId;
	}

	public void setServiceId(short serviceId) {
		this.serviceId = serviceId;
	}

	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public String getServiceNm() {
		return this.serviceNm;
	}

	public void setServiceNm(String serviceNm) {
		this.serviceNm = serviceNm;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public Set<Tmethod> getTmethods() {
		return this.tmethods;
	}

	public void setTmethods(Set<Tmethod> tmethods) {
		this.tmethods = tmethods;
	}
	
}