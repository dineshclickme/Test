package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SetAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-09-11T14:03:54.110+0530")
@StaticMetamodel(TsubmissionEvaluationAlert.class)
public class TsubmissionEvaluationAlert_ {
	public static volatile SingularAttribute<TsubmissionEvaluationAlert, Integer> submissionEvaluationCd;
	public static volatile SingularAttribute<TsubmissionEvaluationAlert, String> alertTypeNm;
	public static volatile SingularAttribute<TsubmissionEvaluationAlert, Timestamp> createTs;
	public static volatile SingularAttribute<TsubmissionEvaluationAlert, String> createUserId;
	public static volatile SingularAttribute<TsubmissionEvaluationAlert, Timestamp> updateTs;
	public static volatile SingularAttribute<TsubmissionEvaluationAlert, String> updateUserId;
	public static volatile SetAttribute<TsubmissionEvaluationAlert, TofacAlertNotification> tofacAlertNotifications;
	public static volatile SetAttribute<TsubmissionEvaluationAlert, TseAlertSource> tseAlertSources;
}
