package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;

import org.springframework.data.domain.Persistable;

import java.sql.Timestamp;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the TLEGACY_SUBMISSION_XTENSN_HS database table.
 * 
 */
@Entity
@Table(name="TLEGACY_SUBMISSION_XTENSN_HS")
public class TlegacySubmissionXtensnH implements Persistable<Serializable> {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private TlegacySubmissionXtensnHPK id;

	@Column(name="AIG_PC")
	private BigDecimal aigPc;

	@Column(name="BROKER_PC")
	private BigDecimal brokerPc;

	@Column(name="COINSURANCE_CD")
	private BigDecimal coinsuranceCd;

	@Column(name="COMMENT_TX")
	private String commentTx;

	@Column(name="CREATE_TS")
	private Timestamp createTs;

	@Column(name="CREATE_USER_ID")
	private String createUserId;

	@Column(name="CREDITED_BRANCH_CD")
	private String creditedBranchCd;

	@Column(name="DISPLAY_CURRENCY_CD")
	private String displayCurrencyCd;

	@Column(name="DOMESTIC_XPSR_IN")
	private String domesticXpsrIn;

	@Column(name="FEDRL_EMPLR_ID_NO")
	private String fedrlEmplrIdNo;

	@Column(name="FOREIGN_XPSR_IN")
	private String foreignXpsrIn;

	@Column(name="GEO_TEAM_IN")
	private String geoTeamIn;

	@Column(name="HERON_PC")
	private BigDecimal heronPc;

	@Column(name="PROFORMA_CREDIT_CD")
	private String proformaCreditCd;

	@Column(name="PUBLIC_ENTITY_IN")
	private String publicEntityIn;

	@Column(name="SBMN_CNTRY_CD")
	private String sbmnCntryCd;

    @Temporal( TemporalType.DATE)
	@Column(name="SBMN_RECEIVED_DT")
	private Date sbmnReceivedDt;

	@Column(name="UPDATE_TS")
	private Timestamp updateTs;

	@Column(name="UPDATE_USER_ID")
	private String updateUserId;

    public TlegacySubmissionXtensnH() {
    }

	public TlegacySubmissionXtensnHPK getId() {
		return this.id;
	}

	public void setId(TlegacySubmissionXtensnHPK id) {
		this.id = id;
	}
	
	public BigDecimal getAigPc() {
		return this.aigPc;
	}

	public void setAigPc(BigDecimal aigPc) {
		this.aigPc = aigPc;
	}

	public BigDecimal getBrokerPc() {
		return this.brokerPc;
	}

	public void setBrokerPc(BigDecimal brokerPc) {
		this.brokerPc = brokerPc;
	}

	public BigDecimal getCoinsuranceCd() {
		return this.coinsuranceCd;
	}

	public void setCoinsuranceCd(BigDecimal coinsuranceCd) {
		this.coinsuranceCd = coinsuranceCd;
	}

	public String getCommentTx() {
		return this.commentTx;
	}

	public void setCommentTx(String commentTx) {
		this.commentTx = commentTx;
	}

	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public String getCreditedBranchCd() {
		return this.creditedBranchCd;
	}

	public void setCreditedBranchCd(String creditedBranchCd) {
		this.creditedBranchCd = creditedBranchCd;
	}

	public String getDisplayCurrencyCd() {
		return this.displayCurrencyCd;
	}

	public void setDisplayCurrencyCd(String displayCurrencyCd) {
		this.displayCurrencyCd = displayCurrencyCd;
	}

	public String getDomesticXpsrIn() {
		return this.domesticXpsrIn;
	}

	public void setDomesticXpsrIn(String domesticXpsrIn) {
		this.domesticXpsrIn = domesticXpsrIn;
	}

	public String getFedrlEmplrIdNo() {
		if(this.fedrlEmplrIdNo != null)
			return this.fedrlEmplrIdNo.trim();
		else
			return this.fedrlEmplrIdNo;
	}

	public void setFedrlEmplrIdNo(String fedrlEmplrIdNo) {
		this.fedrlEmplrIdNo = fedrlEmplrIdNo;
	}

	public String getForeignXpsrIn() {
		return this.foreignXpsrIn;
	}

	public void setForeignXpsrIn(String foreignXpsrIn) {
		this.foreignXpsrIn = foreignXpsrIn;
	}

	public String getGeoTeamIn() {
		return this.geoTeamIn;
	}

	public void setGeoTeamIn(String geoTeamIn) {
		this.geoTeamIn = geoTeamIn;
	}

	public BigDecimal getHeronPc() {
		return this.heronPc;
	}

	public void setHeronPc(BigDecimal heronPc) {
		this.heronPc = heronPc;
	}

	public String getProformaCreditCd() {
		return this.proformaCreditCd;
	}

	public void setProformaCreditCd(String proformaCreditCd) {
		this.proformaCreditCd = proformaCreditCd;
	}

	public String getPublicEntityIn() {
		return this.publicEntityIn;
	}

	public void setPublicEntityIn(String publicEntityIn) {
		this.publicEntityIn = publicEntityIn;
	}

	public String getSbmnCntryCd() {
		return this.sbmnCntryCd;
	}

	public void setSbmnCntryCd(String sbmnCntryCd) {
		this.sbmnCntryCd = sbmnCntryCd;
	}

	public Date getSbmnReceivedDt() {
		return this.sbmnReceivedDt;
	}

	public void setSbmnReceivedDt(Date sbmnReceivedDt) {
		this.sbmnReceivedDt = sbmnReceivedDt;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	@Override
	public boolean isNew() {
		// TODO Auto-generated method stub
		return true;
	}
}