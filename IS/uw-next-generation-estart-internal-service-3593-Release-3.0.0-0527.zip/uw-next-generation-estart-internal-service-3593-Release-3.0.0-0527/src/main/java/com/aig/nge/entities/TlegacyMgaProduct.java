package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Date;


/**
 * The persistent class for the TLEGACY_MGA_PRODUCT database table.
 * 
 */
@Entity
@Table(name="TLEGACY_MGA_PRODUCT")
public class TlegacyMgaProduct implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private TlegacyMgaProductPK id;

	@Column(name="LAST_UPDT_TS")
	private Timestamp lastUpdtTs;

	@Column(name="LAST_UPDT_USER_ID")
	private String lastUpdtUserId;

    @Temporal( TemporalType.DATE)
	@Column(name="MGA_PRDCT_EFCTV_DT")
	private Date mgaPrdctEfctvDt;

    @Temporal( TemporalType.DATE)
	@Column(name="MGA_PRDCT_XPRTN_DT")
	private Date mgaPrdctXprtnDt;

	@Column(name="WORKING_BRANCH_CD")
	private String workingBranchCd;

	//bi-directional many-to-one association to TlegacyProfitCenterProduct
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumns({
		@JoinColumn(name="PRODUCT_CD", referencedColumnName="PRODUCT_CD"),
		@JoinColumn(name="PROFIT_CENTER_CD", referencedColumnName="PROFIT_CENTER_CD"),
		@JoinColumn(name="SOURCE_CD", referencedColumnName="SOURCE_CD")
		})
	private TlegacyProfitCenterProduct tlegacyProfitCenterProduct;

    public TlegacyMgaProduct() {
    }

	public TlegacyMgaProductPK getId() {
		return this.id;
	}

	public void setId(TlegacyMgaProductPK id) {
		this.id = id;
	}
	
	public Timestamp getLastUpdtTs() {
		return this.lastUpdtTs;
	}

	public void setLastUpdtTs(Timestamp lastUpdtTs) {
		this.lastUpdtTs = lastUpdtTs;
	}

	public String getLastUpdtUserId() {
		return this.lastUpdtUserId;
	}

	public void setLastUpdtUserId(String lastUpdtUserId) {
		this.lastUpdtUserId = lastUpdtUserId;
	}

	public Date getMgaPrdctEfctvDt() {
		return this.mgaPrdctEfctvDt;
	}

	public void setMgaPrdctEfctvDt(Date mgaPrdctEfctvDt) {
		this.mgaPrdctEfctvDt = mgaPrdctEfctvDt;
	}

	public Date getMgaPrdctXprtnDt() {
		return this.mgaPrdctXprtnDt;
	}

	public void setMgaPrdctXprtnDt(Date mgaPrdctXprtnDt) {
		this.mgaPrdctXprtnDt = mgaPrdctXprtnDt;
	}

	public String getWorkingBranchCd() {
		return this.workingBranchCd;
	}

	public void setWorkingBranchCd(String workingBranchCd) {
		this.workingBranchCd = workingBranchCd;
	}

	public TlegacyProfitCenterProduct getTlegacyProfitCenterProduct() {
		return this.tlegacyProfitCenterProduct;
	}

	public void setTlegacyProfitCenterProduct(TlegacyProfitCenterProduct tlegacyProfitCenterProduct) {
		this.tlegacyProfitCenterProduct = tlegacyProfitCenterProduct;
	}
	
}