package com.aig.nge.dao;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.aig.nge.entities.Tbranch;
import com.aig.nge.entities.TbranchType;
import com.aig.nge.entities.Tlocation;
import com.aig.nge.entities.TreftabMis780;
import com.aig.nge.entities.TtransactionCmpntXpsrLoc;
import com.aig.nge.entities.TtransactionCmpntXpsrLocPK;
import com.aig.nge.entities.TtransactionComponent;
import com.aig.nge.entities.TtransactionComponentBranch;
import com.aig.nge.entities.TtransactionComponentBranchPK;
import com.aig.nge.repository.TBranchRepository;
import com.aig.nge.repository.TBranchTypeRepository;
import com.aig.nge.repository.TLocationRepository;
import com.aig.nge.repository.TReftabRepository;
import com.aig.nge.repository.TTransactionCmpntXpsrLocRepository;
import com.aig.nge.repository.TTransactionComponentBranchRepository;
import com.aig.nge.utilities.AIGCIExceptionMsg;
import com.aig.nge.utilities.NGEConstants;
import com.aig.nge.utilities.NGEErrorCodes;
import com.aig.nge.utilities.NGESession;


@Repository
public class LocationDAO extends BaseDAO{

	
	@Autowired
	private TLocationRepository locationRepository;
	
	@Autowired
	private TBranchRepository branchRepository;

	@Autowired
	private TBranchTypeRepository branchTypeRepository; 
	
	@Autowired
	private TBranchTypeRepository tBranchTypeRepository;

	@Autowired
	private TTransactionComponentBranchRepository componentBranchRepository;
	
	@Autowired
	private TTransactionCmpntXpsrLocRepository componentExposureRepository;
	
	@Autowired
	private TLocationRepository tlocationRepository;
	
	@Autowired
	private TReftabRepository tReftabRepository;
	
	public Tbranch getByBranchCdAndLocationCd(String creditedBranchCd, String creditedCountryCd){
		
		Tbranch creditedBranchData = branchRepository.findByBranchCdAndLocationCd(creditedBranchCd.toUpperCase().trim(), creditedCountryCd.toUpperCase(), NGEConstants.LocationType.COUNTRY);
		return creditedBranchData;
	}
	
	
	public Tbranch getCreditedBranchData(int branchId){
	
		Tbranch creditedBranchData= branchRepository.findOne(branchId);
		return creditedBranchData;
	}

	public List<Tlocation> getByCountryCdAndCountry(String mailingCountryCd) throws AIGCIExceptionMsg{
		
		List<Tlocation> locationList = locationRepository.findByCountryCdAndCountry(mailingCountryCd.toUpperCase(),NGEConstants.LocationType.COUNTRY);
		if(locationList==null || locationList.isEmpty()){
			ngeException.throwException(NGEErrorCodes.INVALID_COUNTRY_DETAILS, NGEErrorCodes.ERROR_TYPE, "Invalid Country Details.  Given Country Details does not exist in NGE",null);
		}
		else{
			
			for(Tlocation locationData : locationList){
				
				if(locationData.getDeletedIn().equalsIgnoreCase(NGEConstants.YES)){
					
					// Exception validation need to be bypassed for legacy consumers alone to support legacy behavior
					if(NGESession.getSessionData().getClientId() != null){
						if(!NGESession.getSessionData().getClientId().equalsIgnoreCase(NGEConstants.LEGACY_CONSUMERS)){
						
							ngeException.throwException(NGEErrorCodes.INVALID_COUNTRY_DETAILS, NGEErrorCodes.ERROR_TYPE, "Invalid Country Details.Given Country Details does not exist in NGE", null);
						}
					}
					else{
						ngeException.throwException(NGEErrorCodes.INVALID_COUNTRY_DETAILS, NGEErrorCodes.ERROR_TYPE, "Invalid Country Details.Given Country Details does not exist in NGE", null);
					}
				}
			}
		}
		return  locationList;
	}
	
/*	public String getISOCountryCd(String aigCountryCd){
		String locCd=NGEConstants.EMPTY_STRING;
		Tlocation loc=locationRepository.getISOCountryCd(aigCountryCd.toUpperCase(),NGEConstants.LocationType.COUNTRY_AIG);
		if(null!=loc){
		locCd=loc.getLocationCd();
	    }
		return locCd;
	}*/
	
	/**
	 * @author Dinesh Selvaraj
	 * @param locationCd
	 * @param locationTypeCd
	 * @param tTransactionComponentData
	 * @param systemID
	 * @param createUserId
	 * @return
	 * @throws AIGCIExceptionMsg
	 * This method is used to insert exposure details
	 * into the TTRANSACTION_CMPNT_XPSR_LOC  Table 
	 */
	public Set<TtransactionCmpntXpsrLoc> insertTransactionComponentExposureData(String locationCd, String locationTypeCd, String isExcluded,Set<TtransactionCmpntXpsrLoc> tTransactionCmpntXpsrLocSet,TtransactionComponent tTransactionComponentData) throws AIGCIExceptionMsg {
		java.util.Date date= new java.util.Date();
		
		Tlocation tLocationData = null;
		tLocationData = getLocationAndLocationTypeCombination(locationCd, locationTypeCd);
		TtransactionCmpntXpsrLocPK tTransactionCmpntXpsrLocPKData=new TtransactionCmpntXpsrLocPK();
		if(tLocationData != null){
			
			// Exposure Country CR Implementation
			if(isExcluded == null){
				isExcluded = NGEConstants.NO;
			}
			
			TtransactionCmpntXpsrLoc tranCmpntExposureLocData=new TtransactionCmpntXpsrLoc();
			tTransactionCmpntXpsrLocPKData.setTransactionComponentId(tTransactionComponentData.getTransactionComponentId());
			tTransactionCmpntXpsrLocPKData.setGeographicLocationId(tLocationData.getGeographicLocationId());
			tranCmpntExposureLocData.setId(tTransactionCmpntXpsrLocPKData);
			tranCmpntExposureLocData.setTlocation(tLocationData);
			tranCmpntExposureLocData.setSystemId(NGESession.getSessionData().getSystem().getSystemId());
			tranCmpntExposureLocData.setDeletedIn(NGEConstants.NO);
			tranCmpntExposureLocData.setCreateUserId(NGESession.getSessionData().getUserId());
			tranCmpntExposureLocData.setCreateTs(new Timestamp(date.getTime()));
			
			tranCmpntExposureLocData.setExcludeIn(isExcluded);
			
			tTransactionCmpntXpsrLocSet.add(tranCmpntExposureLocData);
			
		}
		return tTransactionCmpntXpsrLocSet;
	}
	
	/**
	 * @author Dinesh Selvaraj
	 * @param branchCd
	 * @param locationCd
	 * @param branchTypeCd
	 * @param tTransactionComponentData
	 * @param systemID
	 * @param createUserId
	 * @return
	 * @throws AIGCIExceptionMsg 
	 * This method is used to fetch the branch Data using Branch and BranchType Table
	 * and insert the branch data into TTRANSACTION_COMPONENT_BRANCH  Table
	 */
	public Set<TtransactionComponentBranch> insertTransactionComponentBranchData(String branchCd,String locationCd,String branchTypeCd,Set<TtransactionComponentBranch> tTransactionComponentBranchSet,TtransactionComponent tTransactionComponentData) throws AIGCIExceptionMsg 
	{
		java.util.Date date= new java.util.Date();
		TtransactionComponentBranch tTransactionComponentBranchData=new TtransactionComponentBranch();
		TtransactionComponentBranchPK tTtransactionComponentBranchPKData=new TtransactionComponentBranchPK();
		Tbranch tBranch=branchRepository.findByBranchCdAndLocationCd(branchCd.toUpperCase().trim(), locationCd.toUpperCase(), NGEConstants.LocationType.COUNTRY);
					
		if(tBranch == null){
			ngeException.throwException(NGEErrorCodes.INVALID_BRANCH_ID_LOC_CD, NGEErrorCodes.ERROR_TYPE, "Branch Details not available for the given country code and branch code",null);
		}
		
		TbranchType tBranchType=branchTypeRepository.findByBranchTypeCd(branchTypeCd.toUpperCase());
		
		if(tBranchType == null){
			ngeException.throwException(NGEErrorCodes.INVALID_BRANCHTYPE, NGEErrorCodes.ERROR_TYPE, "Invalid Branch Type Code.  Given Branch Type Code  is either blank or does not exist in NGE",null);
		}
		else
		{
			tTtransactionComponentBranchPKData.setBranchTypeId(tBranchType.getBranchTypeId());
			tTtransactionComponentBranchPKData.setTransactionComponentId(tTransactionComponentData.getTransactionComponentId());
			tTransactionComponentBranchData.setId(tTtransactionComponentBranchPKData);
			tTransactionComponentBranchData.setTbranchType(tBranchType);
			tTransactionComponentBranchData.setTbranch(tBranch);
			tTransactionComponentBranchData.setSystemId(NGESession.getSessionData().getSystem().getSystemId());
			tTransactionComponentBranchData.setCreateUserId(NGESession.getSessionData().getUserId());
			tTransactionComponentBranchData.setCreateTs(new Timestamp(date.getTime()));
			tTransactionComponentBranchSet.add(tTransactionComponentBranchData);
		}
			
		
		return tTransactionComponentBranchSet;
	}

	public Tlocation findLocationByCountryCd( String locationCd, String locationTypeCd) throws AIGCIExceptionMsg
	{
		Tlocation locationRecord = null;
		List<Tlocation> locationList = locationRepository.findByCountryCdAndCountry(locationCd.toUpperCase(), locationTypeCd.toUpperCase());
		if(locationList==null || locationList.isEmpty()) 	{
			ngeException.throwException(NGEErrorCodes.INVALID_COUNTRY_DETAILS, NGEErrorCodes.ERROR_TYPE, "Invalid Country Details.Given Country Details does not exist in NGE", null);
							
		}
		else{
			
			for(Tlocation locationData : locationList){
				
				if(locationData.getDeletedIn().equalsIgnoreCase(NGEConstants.YES)){
					
					// Exception validation need to be bypassed for legacy consumers alone to support legacy behavior
					if(NGESession.getSessionData().getClientId() != null){
						if(!NGESession.getSessionData().getClientId().equalsIgnoreCase(NGEConstants.LEGACY_CONSUMERS)){
						
							ngeException.throwException(NGEErrorCodes.INVALID_COUNTRY_DETAILS, NGEErrorCodes.ERROR_TYPE, "Invalid Country Details.Given Country Details does not exist in NGE", null);
						}
					}
					else{
						ngeException.throwException(NGEErrorCodes.INVALID_COUNTRY_DETAILS, NGEErrorCodes.ERROR_TYPE, "Invalid Country Details.Given Country Details does not exist in NGE", null);
					}
				}
			}
			
			locationRecord = locationList.get(0);
		}
		return locationRecord;
	}
	
	/**
	 * @Autohr Nandhakumar
	 * @param countryCd
	 * @param branchCd
	 * @return
	 * @throws AIGCIExceptionMsg 
	 */
	public Tbranch findByBranchCdAndLocationCd(String countryCd, String branchCd) throws AIGCIExceptionMsg{
		Tbranch branch = new Tbranch();
		branch = branchRepository.findByBranchCdAndLocationCd(branchCd.toUpperCase().trim(), countryCd.toUpperCase(), NGEConstants.LocationType.COUNTRY);
		if(branch == null){
			ngeException.throwException(NGEErrorCodes.INVALID_BRANCH_ID_LOC_CD,NGEErrorCodes.ERROR_TYPE, "Branch Details not available for the given country code and branch code",null);
		}
		return branch;
	}
	public TbranchType findBranchType(String branchTpeCd) throws AIGCIExceptionMsg{
		TbranchType branchType = new TbranchType();
		branchType = tBranchTypeRepository.findByBranchTypeCd(branchTpeCd.toUpperCase());
		if(null == branchType){
			ngeException.throwException(NGEErrorCodes.INVALID_BRANCHTYPE,NGEErrorCodes.ERROR_TYPE, "Invalid Branch Type Code.  Given Branch Type Code  is either blank or does not exist in NGE",null);
		}
		return branchType;
		
	}
	public List<TtransactionComponentBranch> updateBranch(List<TtransactionComponentBranch> branchList) throws AIGCIExceptionMsg{
		List<TtransactionComponentBranch> componentBranchList = new ArrayList<TtransactionComponentBranch>();
		componentBranchList = componentBranchRepository.save(branchList);
		if(componentBranchList.size() ==0){
			ngeException.throwException(NGEErrorCodes.SERVICE_FAILED,NGEErrorCodes.ERROR_TYPE, null,null);
		}
		return componentBranchList;
	}
	public Tlocation findGeographicLocationIDByLocationTypeCdAndLcoationCd(String locationCd, String locationTypeNm) throws AIGCIExceptionMsg{
		List<Tlocation> location = new ArrayList<Tlocation>();
		Tlocation locationRecord = null;
		location = tlocationRepository.findByCountryCdAndCountry(locationCd.toUpperCase(),locationTypeNm);
		if(location.isEmpty()){
			ngeException.throwException(NGEErrorCodes.LOCATION_DATA_NOT_AVAILABLE,NGEErrorCodes.ERROR_TYPE, "Unable to determine location. Please verify the inputs",null);
		}
		else{
			
			for(Tlocation locationData : location){
				
				if(locationData.getDeletedIn().equalsIgnoreCase(NGEConstants.YES)){
					
					// Exception validation need to be bypassed for legacy consumers alone to support legacy behavior
					if(NGESession.getSessionData().getClientId() != null){
						if(!NGESession.getSessionData().getClientId().equalsIgnoreCase(NGEConstants.LEGACY_CONSUMERS)){
							
							ngeException.throwException(NGEErrorCodes.LOCATION_DATA_NOT_AVAILABLE,NGEErrorCodes.ERROR_TYPE, "Unable to determine location. Please verify the inputs",null);
						}
					}
					else{
						
						ngeException.throwException(NGEErrorCodes.LOCATION_DATA_NOT_AVAILABLE,NGEErrorCodes.ERROR_TYPE, "Unable to determine location. Please verify the inputs",null);
					}
				}
			}			
		}
		locationRecord = location.get(0);
		
		return locationRecord;
	}
	
	/**
	 * @author Nandhakumarm
	 * @param tTransactionExposureList
	 * @return
	 * @throws AIGCIExceptionMsg
	 */
	public List<TtransactionCmpntXpsrLoc> updateExposure(List<TtransactionCmpntXpsrLoc> tTransactionExposureList) throws AIGCIExceptionMsg{
		List<TtransactionCmpntXpsrLoc> exposureList = null;
		exposureList = componentExposureRepository.save(tTransactionExposureList);
		return exposureList;
		
	}
	
	public Tlocation getByLocationCode(String locationCode, String locationTypeNm) throws AIGCIExceptionMsg{
		
		Tlocation locationData = tlocationRepository.getByLocationCode(locationCode.toUpperCase(), locationTypeNm);
		return locationData;
		
	}
	
public Tlocation getByLocationName(String locationName) throws AIGCIExceptionMsg{
		
		Tlocation locationData = tlocationRepository.getByLocationName(locationName, NGEConstants.LocationType.COUNTRY);
		return locationData;
		
	}
	
	public TreftabMis780 validateIssueCompanyCd (int companyCd) throws AIGCIExceptionMsg{
		
		TreftabMis780 companyData = null;
		
		companyData = tReftabRepository.validateIssueCompanyCd(companyCd);
		
		if(companyData != null){
			
			if(companyData.getDeletedIn().equalsIgnoreCase(NGEConstants.YES)){
				
				if(NGESession.getSessionData().getClientId() != null){
					
					if(!NGESession.getSessionData().getClientId().equalsIgnoreCase(NGEConstants.LEGACY_CONSUMERS)){
						
						ngeException.throwException(NGEErrorCodes.INVALID_POLICY_ISS_COMP_CD,
								NGEErrorCodes.ERROR_TYPE, "Invalid Issuing Company Code. Given Issuing Company Code is either blank or does not exist in NGE", null);
					}			
				}
				else{
					
					ngeException.throwException(NGEErrorCodes.INVALID_POLICY_ISS_COMP_CD,
							NGEErrorCodes.ERROR_TYPE, "Invalid Issuing Company Code. Given Issuing Company Code is either blank or does not exist in NGE", null);
				}
			}			
			
		}		
		return companyData;
	}
	
	// Exposure Country CR Implementation
	public Tlocation getLocationAndLocationTypeCombination( String locationCd, String locationTypeNm) throws AIGCIExceptionMsg
	{
		Tlocation locationData = null;
		locationData = locationRepository.getLocationAndLocationTypeCombination(locationCd.toUpperCase(), locationTypeNm.toUpperCase());
		
		if(locationData == null) {
			
			if(locationTypeNm.equalsIgnoreCase(NGEConstants.LocationType.COUNTRY)){
				ngeException.throwException(NGEErrorCodes.INVALID_COUNTRY_DETAILS_FOR_EXPOSURE, NGEErrorCodes.ERROR_TYPE, "Invalid Country details provided for Exposures", null);
			}
			else if(locationTypeNm.equalsIgnoreCase(NGEConstants.LocationType.SUB_REGION_TYPE)){
				ngeException.throwException(NGEErrorCodes.INVALID_SUB_REGION_DETAILS_FOR_EXPOSURE, NGEErrorCodes.ERROR_TYPE, "Invalid Sub Region details provided for Exposures", null);
			}
			else if(locationTypeNm.equalsIgnoreCase(NGEConstants.LocationType.REGION_TYPE)){
				ngeException.throwException(NGEErrorCodes.INVALID_REGION_DETAILS_FOR_EXPOSURE, NGEErrorCodes.ERROR_TYPE, "Invalid Region details provided for Exposures", null);			
			}
			else if(locationTypeNm.equalsIgnoreCase(NGEConstants.LocationType.GEO_CLUSTER_TYPE)){
				ngeException.throwException(NGEErrorCodes.INVALID_GEO_CLUSTER_DETAILS_FOR_EXPOSURE, NGEErrorCodes.ERROR_TYPE, "Invalid Geo Cluster details provided for Exposures", null);
			}
			else if(locationTypeNm.equalsIgnoreCase(NGEConstants.LocationType.WORLD_WIDE_TYPE)){
				ngeException.throwException(NGEErrorCodes.INVALID_WORLD_WIDE_DETAILS_FOR_EXPOSURE, NGEErrorCodes.ERROR_TYPE, "Invalid World Wide details provided for Exposures", null);
			}						
		}
		else{
			
			if(locationData.getDeletedIn().equalsIgnoreCase(NGEConstants.YES)){
				
				// Exception validation need to be bypassed for legacy consumers alone to support legacy behavior
				if(NGESession.getSessionData().getClientId() != null){
					if(!NGESession.getSessionData().getClientId().equalsIgnoreCase(NGEConstants.LEGACY_CONSUMERS)){
						
						if(locationTypeNm.equalsIgnoreCase(NGEConstants.LocationType.COUNTRY)){
							ngeException.throwException(NGEErrorCodes.INVALID_COUNTRY_DETAILS_FOR_EXPOSURE, NGEErrorCodes.ERROR_TYPE, "Invalid Country details provided for Exposures", null);
						}
						else if(locationTypeNm.equalsIgnoreCase(NGEConstants.LocationType.SUB_REGION_TYPE)){
							ngeException.throwException(NGEErrorCodes.INVALID_SUB_REGION_DETAILS_FOR_EXPOSURE, NGEErrorCodes.ERROR_TYPE, "Invalid Sub Region details provided for Exposures", null);
						}
						else if(locationTypeNm.equalsIgnoreCase(NGEConstants.LocationType.REGION_TYPE)){
							ngeException.throwException(NGEErrorCodes.INVALID_REGION_DETAILS_FOR_EXPOSURE, NGEErrorCodes.ERROR_TYPE, "Invalid Region details provided for Exposures", null);			
						}
						else if(locationTypeNm.equalsIgnoreCase(NGEConstants.LocationType.GEO_CLUSTER_TYPE)){
							ngeException.throwException(NGEErrorCodes.INVALID_GEO_CLUSTER_DETAILS_FOR_EXPOSURE, NGEErrorCodes.ERROR_TYPE, "Invalid Geo Cluster details provided for Exposures", null);
						}
						else if(locationTypeNm.equalsIgnoreCase(NGEConstants.LocationType.WORLD_WIDE_TYPE)){
							ngeException.throwException(NGEErrorCodes.INVALID_WORLD_WIDE_DETAILS_FOR_EXPOSURE, NGEErrorCodes.ERROR_TYPE, "Invalid World Wide details provided for Exposures", null);
						}						
					}
				}
				else{
					
					if(locationTypeNm.equalsIgnoreCase(NGEConstants.LocationType.COUNTRY)){
						ngeException.throwException(NGEErrorCodes.INVALID_COUNTRY_DETAILS_FOR_EXPOSURE, NGEErrorCodes.ERROR_TYPE, "Invalid Country details provided for Exposures", null);
					}
					else if(locationTypeNm.equalsIgnoreCase(NGEConstants.LocationType.SUB_REGION_TYPE)){
						ngeException.throwException(NGEErrorCodes.INVALID_SUB_REGION_DETAILS_FOR_EXPOSURE, NGEErrorCodes.ERROR_TYPE, "Invalid Sub Region details provided for Exposures", null);
					}
					else if(locationTypeNm.equalsIgnoreCase(NGEConstants.LocationType.REGION_TYPE)){
						ngeException.throwException(NGEErrorCodes.INVALID_REGION_DETAILS_FOR_EXPOSURE, NGEErrorCodes.ERROR_TYPE, "Invalid Region details provided for Exposures", null);			
					}
					else if(locationTypeNm.equalsIgnoreCase(NGEConstants.LocationType.GEO_CLUSTER_TYPE)){
						ngeException.throwException(NGEErrorCodes.INVALID_GEO_CLUSTER_DETAILS_FOR_EXPOSURE, NGEErrorCodes.ERROR_TYPE, "Invalid Geo Cluster details provided for Exposures", null);
					}
					else if(locationTypeNm.equalsIgnoreCase(NGEConstants.LocationType.WORLD_WIDE_TYPE)){
						ngeException.throwException(NGEErrorCodes.INVALID_WORLD_WIDE_DETAILS_FOR_EXPOSURE, NGEErrorCodes.ERROR_TYPE, "Invalid World Wide details provided for Exposures", null);
					}
				}
			}
		}
		
		return locationData;
	}

}
