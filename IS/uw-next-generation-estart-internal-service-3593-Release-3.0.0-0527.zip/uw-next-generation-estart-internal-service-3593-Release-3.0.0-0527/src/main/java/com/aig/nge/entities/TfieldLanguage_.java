package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-08-04T13:12:21.210+0530")
@StaticMetamodel(TfieldLanguage.class)
public class TfieldLanguage_ {
	public static volatile SingularAttribute<TfieldLanguage, TfieldLanguagePK> id;
	public static volatile SingularAttribute<TfieldLanguage, Timestamp> createTs;
	public static volatile SingularAttribute<TfieldLanguage, String> createUserId;
	public static volatile SingularAttribute<TfieldLanguage, String> fieldInLanguageNm;
	public static volatile SingularAttribute<TfieldLanguage, Timestamp> updateTs;
	public static volatile SingularAttribute<TfieldLanguage, String> updateUserId;
	public static volatile SingularAttribute<TfieldLanguage, Tfield> tfield;
	public static volatile SingularAttribute<TfieldLanguage, Tlanguage> tlanguage;
}
