package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;

import org.apache.openjpa.persistence.DataCache;
import java.sql.Timestamp;
import java.util.Set;


/**
 * The persistent class for the TTABLE database table.
 * 
 */
@Entity
@DataCache
public class Ttable implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="TABLE_ID")
	private short tableId;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="CREATE_TS")
	private Timestamp createTs;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="CREATE_USER_ID")
	private String createUserId;

	@Column(name="TABLE_NM")
	private String tableNm;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="UPDATE_TS")
	private Timestamp updateTs;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="UPDATE_USER_ID")
	private String updateUserId;

	//bi-directional many-to-one association to TtableAttribute
	@OneToMany(mappedBy="ttable", cascade={CascadeType.ALL})
	private Set<TtableAttribute> ttableAttributes;

    public Ttable() {
    }

	public short getTableId() {
		return this.tableId;
	}

	public void setTableId(short tableId) {
		this.tableId = tableId;
	}

	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public String getTableNm() {
		return this.tableNm;
	}

	public void setTableNm(String tableNm) {
		this.tableNm = tableNm;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public Set<TtableAttribute> getTtableAttributes() {
		return this.ttableAttributes;
	}

	public void setTtableAttributes(Set<TtableAttribute> ttableAttributes) {
		this.ttableAttributes = ttableAttributes;
	}
	
}