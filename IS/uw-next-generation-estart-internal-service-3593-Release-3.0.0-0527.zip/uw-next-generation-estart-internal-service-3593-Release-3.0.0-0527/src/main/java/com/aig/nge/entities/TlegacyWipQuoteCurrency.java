package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.text.DecimalFormat;
import java.math.BigDecimal;


/**
 * The persistent class for the TLEGACY_WIP_QUOTE_CURRENCY database table.
 * 
 */
@Entity
@Table(name="TLEGACY_WIP_QUOTE_CURRENCY")
public class TlegacyWipQuoteCurrency implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private TlegacyWipQuoteCurrencyPK id;

	@Column(name="BOUND_PREMIUM_AM")
	private BigDecimal boundPremiumAm;

	@Column(name="CREATE_TS")
	private Timestamp createTs;

	@Column(name="CREATE_USER_ID")
	private String createUserId;

	@Column(name="POLICY_ATCHMT_POINT_AM")
	private BigDecimal policyAtchmtPointAm;

	@Column(name="POLICY_LIMIT_AM")
	private BigDecimal policyLimitAm;

	@Column(name="POLICY_PART_OF_AM")
	private BigDecimal policyPartOfAm;

	@Column(name="QUOTED_ATCHMT_POINT_AM")
	private BigDecimal quotedAtchmtPointAm;

	@Column(name="QUOTED_LIMIT_AM")
	private BigDecimal quotedLimitAm;

	@Column(name="QUOTED_PREMIUM_AM")
	private BigDecimal quotedPremiumAm;

	@Column(name="UPDATE_TS")
	private Timestamp updateTs;

	@Column(name="UPDATE_USER_ID")
	private String updateUserId;

	//bi-directional many-to-one association to Tcurrency
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="CURRENCY_ID")
	private Tcurrency tcurrency;

	//bi-directional many-to-one association to TlegacyWipQuote
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumns({
		@JoinColumn(name="QUOTE_SQN", referencedColumnName="QUOTE_SQN"),
		@JoinColumn(name="TRANSACTION_COMPONENT_ID", referencedColumnName="TRANSACTION_COMPONENT_ID"),
		@JoinColumn(name="WIP_ID", referencedColumnName="WIP_ID")
		})
	private TlegacyWipQuote tlegacyWipQuote;

    public TlegacyWipQuoteCurrency() {
    }

	public TlegacyWipQuoteCurrencyPK getId() {
		return this.id;
	}

	public void setId(TlegacyWipQuoteCurrencyPK id) {
		this.id = id;
	}
	
	public BigDecimal getBoundPremiumAm() {
		/* exadata changes - formatting the decimal field */
		if(this.boundPremiumAm != null){
			DecimalFormat df = new DecimalFormat("0.000000");
	    	BigDecimal formattedPremAm = new BigDecimal(df.format(this.boundPremiumAm));	
			return formattedPremAm;
		}else{
			return this.boundPremiumAm;
		}
	}

	public void setBoundPremiumAm(BigDecimal boundPremiumAm) {
		this.boundPremiumAm = boundPremiumAm;
	}

	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public BigDecimal getPolicyAtchmtPointAm() {
		/* exadata changes - formatting the decimal field */
		if(this.policyAtchmtPointAm != null){
			DecimalFormat df = new DecimalFormat("0.000000");
	    	BigDecimal formattedPremAm = new BigDecimal(df.format(this.policyAtchmtPointAm));	
			return formattedPremAm;
		}else{
			return this.policyAtchmtPointAm;
		}
	}

	public void setPolicyAtchmtPointAm(BigDecimal policyAtchmtPointAm) {
		this.policyAtchmtPointAm = policyAtchmtPointAm;
	}

	public BigDecimal getPolicyLimitAm() {
		/* exadata changes - formatting the decimal field */
		if(this.policyLimitAm != null){
			DecimalFormat df = new DecimalFormat("0.000000");
	    	BigDecimal formattedPremAm = new BigDecimal(df.format(this.policyLimitAm));	
			return formattedPremAm;
		}else{
			return this.policyLimitAm;
		}
	}

	public void setPolicyLimitAm(BigDecimal policyLimitAm) {
		this.policyLimitAm = policyLimitAm;
	}

	public BigDecimal getPolicyPartOfAm() {
		/* exadata changes - formatting the decimal field */
		if(this.policyPartOfAm != null){
			DecimalFormat df = new DecimalFormat("0.000000");
	    	BigDecimal formattedPremAm = new BigDecimal(df.format(this.policyPartOfAm));	
			return formattedPremAm;
		}else{
			return this.policyPartOfAm;
		}
	}

	public void setPolicyPartOfAm(BigDecimal policyPartOfAm) {
		this.policyPartOfAm = policyPartOfAm;
	}

	public BigDecimal getQuotedAtchmtPointAm() {
		/* exadata changes - formatting the decimal field */
		if(this.quotedAtchmtPointAm != null){
			DecimalFormat df = new DecimalFormat("0.000000");
	    	BigDecimal formattedPremAm = new BigDecimal(df.format(this.quotedAtchmtPointAm));	
			return formattedPremAm;
		}else{
			return this.quotedAtchmtPointAm;
		}
	}

	public void setQuotedAtchmtPointAm(BigDecimal quotedAtchmtPointAm) {
		this.quotedAtchmtPointAm = quotedAtchmtPointAm;
	}

	public BigDecimal getQuotedLimitAm() {
		/* exadata changes - formatting the decimal field */
		if(this.quotedLimitAm != null){
			DecimalFormat df = new DecimalFormat("0.000000");
	    	BigDecimal formattedPremAm = new BigDecimal(df.format(this.quotedLimitAm));	
			return formattedPremAm;
		}else{
			return this.quotedLimitAm;
		}
	}

	public void setQuotedLimitAm(BigDecimal quotedLimitAm) {
		this.quotedLimitAm = quotedLimitAm;
	}

	public BigDecimal getQuotedPremiumAm() {
		/* exadata changes - formatting the decimal field */
		if(this.quotedPremiumAm != null){
			DecimalFormat df = new DecimalFormat("0.000000");
	    	BigDecimal formattedPremAm = new BigDecimal(df.format(this.quotedPremiumAm));	
			return formattedPremAm;
		}else{
			return this.quotedPremiumAm;
		}
	}

	public void setQuotedPremiumAm(BigDecimal quotedPremiumAm) {
		this.quotedPremiumAm = quotedPremiumAm;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public Tcurrency getTcurrency() {
		return this.tcurrency;
	}

	public void setTcurrency(Tcurrency tcurrency) {
		this.tcurrency = tcurrency;
	}
	
	public TlegacyWipQuote getTlegacyWipQuote() {
		return this.tlegacyWipQuote;
	}

	public void setTlegacyWipQuote(TlegacyWipQuote tlegacyWipQuote) {
		this.tlegacyWipQuote = tlegacyWipQuote;
	}
	
}