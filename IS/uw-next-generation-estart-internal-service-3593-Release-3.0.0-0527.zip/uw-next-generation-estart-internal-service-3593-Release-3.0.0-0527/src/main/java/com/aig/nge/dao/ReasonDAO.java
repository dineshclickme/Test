package com.aig.nge.dao;

import org.springframework.stereotype.Repository;
import org.springframework.beans.factory.annotation.Autowired;

import com.aig.nge.entities.Treason;
import com.aig.nge.repository.TReasonRepository;
import com.aig.nge.utilities.NGEConstants;

/**
 * 
 * @author Manasaj This DAO class is used for accessing the Reason related
 *         repositories Used repositories are TReasonRepository
 * 
 */
@Repository
public class ReasonDAO extends BaseDAO{

	@Autowired
	private TReasonRepository reasonRepository;

	/**
	 * @author Manasaj
	 * @param reasonId
	 * @return
	 */
	public Treason findByReasonId(short reasonId) {
		Treason reason = reasonRepository.findOne(reasonId);
		return reason;
	}
	public Treason findByReasonNm(String reasonNm) {
		
		/*
		* EXADATA Migration Changes
		* 		Adding space for reason name 
		*/

		if(reasonNm.equals(NGEConstants.EMPTY_STRING))
			reasonNm = NGEConstants.EMPTY_SPACE;
		else
			reasonNm = reasonNm.trim();
		
		Treason reason = reasonRepository.findByReasonNm(reasonNm);
		return reason;
	}
	public Treason findByReasonTypeIdAndReasonNm(String reasonTypeId,
			String reasonCd) {
		
		/*
		* EXADATA Migration Changes
		* 		Adding space for reason name 
		*/

		if(reasonCd.equals(NGEConstants.EMPTY_STRING))
			reasonCd = NGEConstants.EMPTY_SPACE;
		else
			reasonCd = reasonCd.trim();
		Treason treason = reasonRepository.findByReasonTypeIdAndReasonNm(reasonTypeId.toUpperCase(), reasonCd.toUpperCase());
		return treason;
	}
	
	public Treason findByReasonTypeNmAndReasonNm(String reasonTypeNm,
			String reasonCd) {
		
		/*
		* EXADATA Migration Changes
		* 		Adding space for reason name 
		*/

		if(reasonCd.equals(NGEConstants.EMPTY_STRING))
			reasonCd = NGEConstants.EMPTY_SPACE;
		else
			reasonCd = reasonCd.trim();
		
		Treason treason = reasonRepository.findByReasonTypeIdAndReasonNm(reasonTypeNm.toUpperCase(), reasonCd.toUpperCase());
		return treason;
	}

}
