package com.aig.nge.entities;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;
import javax.annotation.Generated;
import javax.persistence.metamodel.SetAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-02-24T11:59:49.915+0530")
@StaticMetamodel(Tpolicy.class)
public class Tpolicy_ {
	public static volatile SingularAttribute<Tpolicy, Integer> policyId;
	public static volatile SingularAttribute<Tpolicy, Short> companyCd;
	public static volatile SingularAttribute<Tpolicy, Timestamp> createTs;
	public static volatile SingularAttribute<Tpolicy, String> createUserId;
	public static volatile SingularAttribute<Tpolicy, Date> effectiveDt;
	public static volatile SingularAttribute<Tpolicy, Date> expirationDt;
	public static volatile SingularAttribute<Tpolicy, BigDecimal> localCurrencyPremiumAm;
	public static volatile SingularAttribute<Tpolicy, String> policyNo;
	public static volatile SingularAttribute<Tpolicy, BigDecimal> premiumAm;
	public static volatile SingularAttribute<Tpolicy, Short> systemId;
	public static volatile SingularAttribute<Tpolicy, Timestamp> updateTs;
	public static volatile SingularAttribute<Tpolicy, String> updateUserId;
	public static volatile SingularAttribute<Tpolicy, Tcurrency> tcurrency;
	public static volatile SingularAttribute<Tpolicy, TpolicyType> tpolicyType;
	public static volatile SetAttribute<Tpolicy, TpolicyAttribute> tpolicyAttributes;
	public static volatile SetAttribute<Tpolicy, TtransactionComponentPolicy> ttransactionComponentPolicies;
}
