package com.aig.nge.entities;

import java.sql.Timestamp;
import java.util.Date;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-08-04T13:12:21.296+0530")
@StaticMetamodel(TlegacyProductDsp.class)
public class TlegacyProductDsp_ {
	public static volatile SingularAttribute<TlegacyProductDsp, TlegacyProductDspPK> id;
	public static volatile SingularAttribute<TlegacyProductDsp, String> createdById;
	public static volatile SingularAttribute<TlegacyProductDsp, Date> enteredDt;
	public static volatile SingularAttribute<TlegacyProductDsp, Timestamp> lastUpdtTs;
	public static volatile SingularAttribute<TlegacyProductDsp, String> lastUpdtUserId;
	public static volatile SingularAttribute<TlegacyProductDsp, Date> prdctDspEfctvDt;
	public static volatile SingularAttribute<TlegacyProductDsp, Date> prdctDspXprtnDt;
	public static volatile SingularAttribute<TlegacyProductDsp, String> productionIn;
}
