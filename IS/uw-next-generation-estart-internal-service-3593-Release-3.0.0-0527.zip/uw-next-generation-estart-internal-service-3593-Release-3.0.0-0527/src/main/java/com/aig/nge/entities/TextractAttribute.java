package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the TEXTRACT_ATTRIBUTE database table.
 * 
 */
@Entity
@Table(name="TEXTRACT_ATTRIBUTE")
public class TextractAttribute implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private TextractAttributePK id;

	@Column(name="CREATE_TS")
	private Timestamp createTs;

	@Column(name="CREATE_USER_ID")
	private String createUserId;

	@Column(name="LABEL_NM")
	private String labelNm;

	@Column(name="UPDATE_TS")
	private Timestamp updateTs;

	@Column(name="UPDATE_USER_ID")
	private String updateUserId;

	//bi-directional many-to-one association to Tattribute
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="ATTRIBUTE_ID")
	private Tattribute tattribute;

	//bi-directional many-to-one association to Textract
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="EXTRACT_NM")
	private Textract textract;

    public TextractAttribute() {
    }

	public TextractAttributePK getId() {
		return this.id;
	}

	public void setId(TextractAttributePK id) {
		this.id = id;
	}
	
	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public String getLabelNm() {
		return this.labelNm;
	}

	public void setLabelNm(String labelNm) {
		this.labelNm = labelNm;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public Tattribute getTattribute() {
		return this.tattribute;
	}

	public void setTattribute(Tattribute tattribute) {
		this.tattribute = tattribute;
	}
	
	public Textract getTextract() {
		return this.textract;
	}

	public void setTextract(Textract textract) {
		this.textract = textract;
	}
	
}