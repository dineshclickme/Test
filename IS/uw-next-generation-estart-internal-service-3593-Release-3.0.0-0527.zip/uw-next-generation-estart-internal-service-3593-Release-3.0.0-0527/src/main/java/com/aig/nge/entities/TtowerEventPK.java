package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the TTOWER_EVENT database table.
 * 
 */
@Embeddable
public class TtowerEventPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="EVENT_ID")
	private short eventId;

	@Column(name="PRODUCT_TOWER_ID")
	private short productTowerId;

	@Column(name="ATTRIBUTE_ID")
	private short attributeId;

    public TtowerEventPK() {
    }
	public short getEventId() {
		return this.eventId;
	}
	public void setEventId(short eventId) {
		this.eventId = eventId;
	}
	public short getProductTowerId() {
		return this.productTowerId;
	}
	public void setProductTowerId(short productTowerId) {
		this.productTowerId = productTowerId;
	}
	public short getAttributeId() {
		return this.attributeId;
	}
	public void setAttributeId(short attributeId) {
		this.attributeId = attributeId;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof TtowerEventPK)) {
			return false;
		}
		TtowerEventPK castOther = (TtowerEventPK)other;
		return 
			(this.eventId == castOther.eventId)
			&& (this.productTowerId == castOther.productTowerId)
			&& (this.attributeId == castOther.attributeId);

    }
    
	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + ((int) this.eventId);
		hash = hash * prime + ((int) this.productTowerId);
		hash = hash * prime + ((int) this.attributeId);
		
		return hash;
    }
}