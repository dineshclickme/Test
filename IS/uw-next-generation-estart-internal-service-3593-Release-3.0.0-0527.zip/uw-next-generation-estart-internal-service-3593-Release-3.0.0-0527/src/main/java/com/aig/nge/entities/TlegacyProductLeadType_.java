package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-04-15T15:31:47.103+0530")
@StaticMetamodel(TlegacyProductLeadType.class)
public class TlegacyProductLeadType_ {
	public static volatile SingularAttribute<TlegacyProductLeadType, TlegacyProductLeadTypePK> id;
	public static volatile SingularAttribute<TlegacyProductLeadType, Timestamp> createTs;
	public static volatile SingularAttribute<TlegacyProductLeadType, String> createUserId;
	public static volatile SingularAttribute<TlegacyProductLeadType, Timestamp> updateTs;
	public static volatile SingularAttribute<TlegacyProductLeadType, String> updateUserId;
	public static volatile SingularAttribute<TlegacyProductLeadType, TtransactionComponent> ttransactionComponent;
	public static volatile SingularAttribute<TlegacyProductLeadType, TlegacyLeadSubtype> tlegacyLeadSubtype;
}
