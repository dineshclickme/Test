package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SetAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-04-15T15:31:47.821+0530")
@StaticMetamodel(Tsource.class)
public class Tsource_ {
	public static volatile SingularAttribute<Tsource, String> sourceCd;
	public static volatile SingularAttribute<Tsource, Timestamp> createTs;
	public static volatile SingularAttribute<Tsource, String> createUserId;
	public static volatile SingularAttribute<Tsource, String> sourceAbrCd;
	public static volatile SingularAttribute<Tsource, String> sourceNm;
	public static volatile SingularAttribute<Tsource, Timestamp> updateTs;
	public static volatile SingularAttribute<Tsource, String> updateUserId;
	public static volatile SetAttribute<Tsource, TlegacyLeadSourceType> tlegacyLeadSourceTypes;
	public static volatile SetAttribute<Tsource, TlegacyLeadType> tlegacyLeadTypes;
	public static volatile SetAttribute<Tsource, TlegacyProfitCenterProduct> tlegacyProfitCenterProducts;
	public static volatile SetAttribute<Tsource, TlegacySourceMapping> tlegacySourceMappings;
	public static volatile SetAttribute<Tsource, TseAlertSource> tseAlertSources;
}
