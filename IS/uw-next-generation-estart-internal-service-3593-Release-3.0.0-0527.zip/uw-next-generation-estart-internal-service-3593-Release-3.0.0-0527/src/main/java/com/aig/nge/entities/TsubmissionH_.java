package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-03-02T12:10:24.922+0530")
@StaticMetamodel(TsubmissionH.class)
public class TsubmissionH_ {
	public static volatile SingularAttribute<TsubmissionH, TsubmissionHPK> id;
	public static volatile SingularAttribute<TsubmissionH, Integer> accountId;
	public static volatile SingularAttribute<TsubmissionH, Timestamp> createTs;
	public static volatile SingularAttribute<TsubmissionH, String> createUserId;
	public static volatile SingularAttribute<TsubmissionH, Integer> initiatingProducerId;
	public static volatile SingularAttribute<TsubmissionH, Timestamp> submissionTs;
	public static volatile SingularAttribute<TsubmissionH, Short> systemId;
	public static volatile SingularAttribute<TsubmissionH, String> updateUserId;
	public static volatile SingularAttribute<TsubmissionH, Timestamp> updateTs;
}
