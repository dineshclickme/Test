package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SetAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-02-25T15:44:17.764+0530")
@StaticMetamodel(Tsubmission.class)
public class Tsubmission_ {
	public static volatile SingularAttribute<Tsubmission, String> submissionNo;
	public static volatile SingularAttribute<Tsubmission, Timestamp> createTs;
	public static volatile SingularAttribute<Tsubmission, String> createUserId;
	public static volatile SingularAttribute<Tsubmission, Timestamp> submissionTs;
	public static volatile SingularAttribute<Tsubmission, Timestamp> updateTs;
	public static volatile SingularAttribute<Tsubmission, String> updateUserId;
	public static volatile SingularAttribute<Tsubmission, Tparty> tparty1;
	public static volatile SingularAttribute<Tsubmission, Tparty> tparty2;
	public static volatile SingularAttribute<Tsubmission, Tsystem> tsystem;
	public static volatile SetAttribute<Tsubmission, Ttransaction> ttransactions;
	public static volatile SingularAttribute<Tsubmission, TlegacySubmissionExtension> tlegacySubmissionExtension;
	public static volatile SetAttribute<Tsubmission, TofacAlertNotification> tofacAlertNotifications;
}
