package com.aig.nge.entities;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2016-08-23T15:31:46.838+0530")
@StaticMetamodel(TprdctTwrTuwSubPrdctDivPK.class)
public class TprdctTwrTuwSubPrdctDivPK_ {

	public static volatile SingularAttribute<TprdctTwrTuwSubPrdctDivPK, String> productTowerTuwSubprodctId;
	public static volatile SingularAttribute<TprdctTwrTuwSubPrdctDivPK, String> divisionNo;
}
