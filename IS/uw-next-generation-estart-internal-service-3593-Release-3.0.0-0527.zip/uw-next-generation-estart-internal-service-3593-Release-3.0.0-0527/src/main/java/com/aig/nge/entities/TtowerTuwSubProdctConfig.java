package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the TTOWER_TUW_SUB_PRODCT_CONFIG database table.
 * 
 */
@Entity
@Table(name="TTOWER_TUW_SUB_PRODCT_CONFIG")
public class TtowerTuwSubProdctConfig implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private TtowerTuwSubProdctConfigPK id;

	@Column(name="CREATE_TS")
	private Timestamp createTs;

	@Column(name="CREATE_USER_ID")
	private String createUserId;

	@Column(name="UPDATE_TS")
	private Timestamp updateTs;

	@Column(name="UPDATE_USER_ID")
	private String updateUserId;

	//bi-directional many-to-one association to TproductTowerConfiguration
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="CONFIGURATION_ID")
	private TproductTowerConfiguration tproductTowerConfiguration;

	//bi-directional many-to-one association to TtuwSubProduct
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="TUW_SUB_PRODUCT_ID")
	private TtuwSubProduct ttuwSubProduct;

    public TtowerTuwSubProdctConfig() {
    }

	public TtowerTuwSubProdctConfigPK getId() {
		return this.id;
	}

	public void setId(TtowerTuwSubProdctConfigPK id) {
		this.id = id;
	}
	
	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public TproductTowerConfiguration getTproductTowerConfiguration() {
		return this.tproductTowerConfiguration;
	}

	public void setTproductTowerConfiguration(TproductTowerConfiguration tproductTowerConfiguration) {
		this.tproductTowerConfiguration = tproductTowerConfiguration;
	}
	
	public TtuwSubProduct getTtuwSubProduct() {
		return this.ttuwSubProduct;
	}

	public void setTtuwSubProduct(TtuwSubProduct ttuwSubProduct) {
		this.ttuwSubProduct = ttuwSubProduct;
	}
	
}