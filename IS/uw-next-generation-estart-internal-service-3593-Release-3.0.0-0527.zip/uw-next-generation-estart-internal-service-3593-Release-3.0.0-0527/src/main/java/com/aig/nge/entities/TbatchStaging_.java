package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-09-11T14:03:53.518+0530")
@StaticMetamodel(TbatchStaging.class)
public class TbatchStaging_ {
	public static volatile SingularAttribute<TbatchStaging, Integer> taskId;
	public static volatile SingularAttribute<TbatchStaging, Timestamp> createTs;
	public static volatile SingularAttribute<TbatchStaging, String> createUserId;
	public static volatile SingularAttribute<TbatchStaging, String> originatedComponentNm;
	public static volatile SingularAttribute<TbatchStaging, String> originatedMethodNm;
	public static volatile SingularAttribute<TbatchStaging, String> requestMsgId;
	public static volatile SingularAttribute<TbatchStaging, Integer> requestMsgSqn;
	public static volatile SingularAttribute<TbatchStaging, String> requestXml;
	public static volatile SingularAttribute<TbatchStaging, String> responseXml;
	public static volatile SingularAttribute<TbatchStaging, String> statusCd;
	public static volatile SingularAttribute<TbatchStaging, Short> systemId;
	public static volatile SingularAttribute<TbatchStaging, String> targetComponentNm;
	public static volatile SingularAttribute<TbatchStaging, String> targetMethodNm;
	public static volatile SingularAttribute<TbatchStaging, String> targetServiceNm;
	public static volatile SingularAttribute<TbatchStaging, Timestamp> updateTs;
	public static volatile SingularAttribute<TbatchStaging, String> updateUserId;
}
