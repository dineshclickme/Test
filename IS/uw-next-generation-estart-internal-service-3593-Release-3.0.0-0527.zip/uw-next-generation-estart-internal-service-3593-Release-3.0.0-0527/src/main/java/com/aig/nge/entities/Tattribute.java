package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;
import org.apache.openjpa.persistence.DataCache;
import java.sql.Timestamp;
import java.util.Set;


/**
 * The persistent class for the TATTRIBUTE database table.
 * 
 */
@Entity
@DataCache
public class Tattribute implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="ATTRIBUTE_ID")
	private short attributeId;

	@Column(name="ATTRIBUTE_NM")
	private String attributeNm;
	@Basic(fetch=FetchType.LAZY)
	@Column(name="CREATE_TS")
	private Timestamp createTs;
	@Basic(fetch=FetchType.LAZY)
	@Column(name="CREATE_USER_ID")
	private String createUserId;

	@Column(name="DATA_LENGTH_QT")
	private short dataLengthQt;

	@Column(name="DELETED_IN")
	private String deletedIn;
	@Basic(fetch=FetchType.LAZY)
	@Column(name="UPDATE_TS")
	private Timestamp updateTs;
	@Basic(fetch=FetchType.LAZY)
	@Column(name="UPDATE_USER_ID")
	private String updateUserId;

	//bi-directional many-to-one association to TassetAttribute
	@OneToMany(mappedBy="tattribute", cascade={CascadeType.ALL})
	private Set<TassetAttribute> tassetAttributes;

	//bi-directional many-to-one association to TdataType
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="DATA_TYPE_ID")
	private TdataType tdataType;

	//bi-directional many-to-one association to TattributeGroup
	@OneToMany(mappedBy="tattribute", cascade={CascadeType.ALL})
	private Set<TattributeGroup> tattributeGroups;

	//bi-directional many-to-one association to TcompnentStatusAttribute
	@OneToMany(mappedBy="tattribute", cascade={CascadeType.ALL})
	private Set<TcompnentStatusAttribute> tcompnentStatusAttributes;

	//bi-directional many-to-one association to TextractAttribute
	@OneToMany(mappedBy="tattribute", cascade={CascadeType.ALL})
	private Set<TextractAttribute> textractAttributes;

	//bi-directional many-to-one association to TpolicyAttribute
	@OneToMany(mappedBy="tattribute", cascade={CascadeType.ALL})
	private Set<TpolicyAttribute> tpolicyAttributes;

	//bi-directional many-to-one association to TproductTowerAttribute
	@OneToMany(mappedBy="tattribute", cascade={CascadeType.ALL})
	private Set<TproductTowerAttribute> tproductTowerAttributes;

	//bi-directional many-to-one association to TtableAttribute
	@OneToMany(mappedBy="tattribute", cascade={CascadeType.ALL})
	private Set<TtableAttribute> ttableAttributes;

	//bi-directional many-to-one association to TtowerEvent
	@OneToMany(mappedBy="tattribute", cascade={CascadeType.ALL})
	private Set<TtowerEvent> ttowerEvents;

	//bi-directional many-to-one association to TtransactionAttribute
	@OneToMany(mappedBy="tattribute", cascade={CascadeType.ALL})
	private Set<TtransactionAttribute> ttransactionAttributes;

	//bi-directional many-to-one association to TtransactionComponentAtrbt
	@OneToMany(mappedBy="tattribute", cascade={CascadeType.ALL})
	private Set<TtransactionComponentAtrbt> ttransactionComponentAtrbts;

	//bi-directional many-to-one association to TtransactionProductAttribute
	@OneToMany(mappedBy="tattribute", cascade={CascadeType.ALL})
	private Set<TtransactionProductAttribute> ttransactionProductAttributes;

	//bi-directional many-to-one association to TassetTypeAttribute
	@OneToMany(mappedBy="tattribute")
	private Set<TassetTypeAttribute> tassetTypeAttributes;

    public Tattribute() {
    }

	public short getAttributeId() {
		return this.attributeId;
	}

	public void setAttributeId(short attributeId) {
		this.attributeId = attributeId;
	}

	public String getAttributeNm() {
		return this.attributeNm;
	}

	public void setAttributeNm(String attributeNm) {
		this.attributeNm = attributeNm;
	}

	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public short getDataLengthQt() {
		return this.dataLengthQt;
	}

	public void setDataLengthQt(short dataLengthQt) {
		this.dataLengthQt = dataLengthQt;
	}

	public String getDeletedIn() {
		return this.deletedIn;
	}

	public void setDeletedIn(String deletedIn) {
		this.deletedIn = deletedIn;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public Set<TassetAttribute> getTassetAttributes() {
		return this.tassetAttributes;
	}

	public void setTassetAttributes(Set<TassetAttribute> tassetAttributes) {
		this.tassetAttributes = tassetAttributes;
	}
	
	public TdataType getTdataType() {
		return this.tdataType;
	}

	public void setTdataType(TdataType tdataType) {
		this.tdataType = tdataType;
	}
	
	public Set<TattributeGroup> getTattributeGroups() {
		return this.tattributeGroups;
	}

	public void setTattributeGroups(Set<TattributeGroup> tattributeGroups) {
		this.tattributeGroups = tattributeGroups;
	}
	
	public Set<TcompnentStatusAttribute> getTcompnentStatusAttributes() {
		return this.tcompnentStatusAttributes;
	}

	public void setTcompnentStatusAttributes(Set<TcompnentStatusAttribute> tcompnentStatusAttributes) {
		this.tcompnentStatusAttributes = tcompnentStatusAttributes;
	}
	
	public Set<TextractAttribute> getTextractAttributes() {
		return this.textractAttributes;
	}

	public void setTextractAttributes(Set<TextractAttribute> textractAttributes) {
		this.textractAttributes = textractAttributes;
	}
	
	public Set<TpolicyAttribute> getTpolicyAttributes() {
		return this.tpolicyAttributes;
	}

	public void setTpolicyAttributes(Set<TpolicyAttribute> tpolicyAttributes) {
		this.tpolicyAttributes = tpolicyAttributes;
	}
	
	public Set<TproductTowerAttribute> getTproductTowerAttributes() {
		return this.tproductTowerAttributes;
	}

	public void setTproductTowerAttributes(Set<TproductTowerAttribute> tproductTowerAttributes) {
		this.tproductTowerAttributes = tproductTowerAttributes;
	}
	
	public Set<TtableAttribute> getTtableAttributes() {
		return this.ttableAttributes;
	}

	public void setTtableAttributes(Set<TtableAttribute> ttableAttributes) {
		this.ttableAttributes = ttableAttributes;
	}
	
	public Set<TtowerEvent> getTtowerEvents() {
		return this.ttowerEvents;
	}

	public void setTtowerEvents(Set<TtowerEvent> ttowerEvents) {
		this.ttowerEvents = ttowerEvents;
	}
	
	public Set<TtransactionAttribute> getTtransactionAttributes() {
		return this.ttransactionAttributes;
	}

	public void setTtransactionAttributes(Set<TtransactionAttribute> ttransactionAttributes) {
		this.ttransactionAttributes = ttransactionAttributes;
	}
	
	public Set<TtransactionComponentAtrbt> getTtransactionComponentAtrbts() {
		return this.ttransactionComponentAtrbts;
	}

	public void setTtransactionComponentAtrbts(Set<TtransactionComponentAtrbt> ttransactionComponentAtrbts) {
		this.ttransactionComponentAtrbts = ttransactionComponentAtrbts;
	}
	
	public Set<TtransactionProductAttribute> getTtransactionProductAttributes() {
		return this.ttransactionProductAttributes;
	}

	public void setTtransactionProductAttributes(Set<TtransactionProductAttribute> ttransactionProductAttributes) {
		this.ttransactionProductAttributes = ttransactionProductAttributes;
	}
	
	public Set<TassetTypeAttribute> getTassetTypeAttributes() {
		return this.tassetTypeAttributes;
	}

	public void setTassetTypeAttributes(Set<TassetTypeAttribute> tassetTypeAttributes) {
		this.tassetTypeAttributes = tassetTypeAttributes;
	}
	
}