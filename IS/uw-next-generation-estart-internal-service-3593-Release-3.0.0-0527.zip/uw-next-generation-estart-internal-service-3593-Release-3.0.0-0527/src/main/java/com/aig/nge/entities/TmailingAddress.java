package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;

import java.sql.Timestamp;
import java.util.Set;


/**
 * The persistent class for the TMAILING_ADDRESS database table.
 * 
 */
@Entity
@Table(name="TMAILING_ADDRESS")
public class TmailingAddress implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "address_id_gen")
	@SequenceGenerator(name = "address_id_gen", sequenceName = "ADDRESS_ID_SEQ", allocationSize=1)
	@Column(name="ADDRESS_ID")
	private Integer addressId;

	@Column(name="ADDRESS_1_TX")
	private String address1Tx;

	@Column(name="ADDRESS_2_TX")
	private String address2Tx;

	@Column(name="ADDRESS_3_TX")
	private String address3Tx;

	@Column(name="CITY_NM")
	private String cityNm;

	@Column(name="CREATE_TS")
	private Timestamp createTs;

	@Column(name="CREATE_USER_ID")
	private String createUserId;

	@Column(name="POSTAL_CD")
	private String postalCd;

	@Column(name="STATE_CD")
	private String stateCd;

	@Column(name="UPDATE_TS")
	private Timestamp updateTs;

	@Column(name="UPDATE_USER_ID")
	private String updateUserId;

	//bi-directional many-to-one association to Tlocation
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="COUNTRY_ID")
	private Tlocation tlocation;

	//bi-directional many-to-one association to Ttransaction
	@OneToMany(mappedBy="tmailingAddress", cascade={CascadeType.ALL})
	private Set<Ttransaction> ttransactions;

    public TmailingAddress() {
    }

	public Integer getAddressId() {
		return this.addressId;
	}

	public void setAddressId(Integer addressId) {
		this.addressId = addressId;
	}

	public String getAddress1Tx() {
		return this.address1Tx;
	}

	public void setAddress1Tx(String address1Tx) {
		this.address1Tx = address1Tx;
	}

	public String getAddress2Tx() {
		return this.address2Tx;
	}

	public void setAddress2Tx(String address2Tx) {
		this.address2Tx = address2Tx;
	}

	public String getAddress3Tx() {
		return this.address3Tx;
	}

	public void setAddress3Tx(String address3Tx) {
		this.address3Tx = address3Tx;
	}

	public String getCityNm() {
		return this.cityNm;
	}

	public void setCityNm(String cityNm) {
		this.cityNm = cityNm;
	}

	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public String getPostalCd() {
		return this.postalCd;
	}

	public void setPostalCd(String postalCd) {
		this.postalCd = postalCd;
	}

	public String getStateCd() {
		return this.stateCd;
	}

	public void setStateCd(String stateCd) {
		this.stateCd = stateCd;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public Tlocation getTlocation() {
		return this.tlocation;
	}

	public void setTlocation(Tlocation tlocation) {
		this.tlocation = tlocation;
	}
	
	public Set<Ttransaction> getTtransactions() {
		return this.ttransactions;
	}

	public void setTtransactions(Set<Ttransaction> ttransactions) {
		this.ttransactions = ttransactions;
	}
	
}