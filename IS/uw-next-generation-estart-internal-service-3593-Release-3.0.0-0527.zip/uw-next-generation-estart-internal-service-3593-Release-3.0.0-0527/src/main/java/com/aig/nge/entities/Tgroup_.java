package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SetAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-02-19T16:13:03.470+0530")
@StaticMetamodel(Tgroup.class)
public class Tgroup_ {
	public static volatile SingularAttribute<Tgroup, Short> groupId;
	public static volatile SingularAttribute<Tgroup, Timestamp> createTs;
	public static volatile SingularAttribute<Tgroup, String> createUserId;
	public static volatile SingularAttribute<Tgroup, String> groupDs;
	public static volatile SingularAttribute<Tgroup, Timestamp> updateTs;
	public static volatile SingularAttribute<Tgroup, String> updateUserId;
	public static volatile SetAttribute<Tgroup, TattributeGroup> tattributeGroups;
}
