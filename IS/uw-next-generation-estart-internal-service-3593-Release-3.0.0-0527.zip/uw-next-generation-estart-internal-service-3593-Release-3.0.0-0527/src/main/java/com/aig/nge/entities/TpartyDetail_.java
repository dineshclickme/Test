package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-02-24T11:59:49.869+0530")
@StaticMetamodel(TpartyDetail.class)
public class TpartyDetail_ {
	public static volatile SingularAttribute<TpartyDetail, Integer> partyId;
	public static volatile SingularAttribute<TpartyDetail, String> address1Tx;
	public static volatile SingularAttribute<TpartyDetail, String> address2Tx;
	public static volatile SingularAttribute<TpartyDetail, String> address3Tx;
	public static volatile SingularAttribute<TpartyDetail, String> cityNm;
	public static volatile SingularAttribute<TpartyDetail, String> countyNm;
	public static volatile SingularAttribute<TpartyDetail, Timestamp> createTs;
	public static volatile SingularAttribute<TpartyDetail, String> createUserId;
	public static volatile SingularAttribute<TpartyDetail, String> postalCd;
	public static volatile SingularAttribute<TpartyDetail, String> stateCd;
	public static volatile SingularAttribute<TpartyDetail, Timestamp> updateTs;
	public static volatile SingularAttribute<TpartyDetail, String> updateUserId;
	public static volatile SingularAttribute<TpartyDetail, Tlocation> tlocation;
	public static volatile SingularAttribute<TpartyDetail, Tparty> tparty;
}
