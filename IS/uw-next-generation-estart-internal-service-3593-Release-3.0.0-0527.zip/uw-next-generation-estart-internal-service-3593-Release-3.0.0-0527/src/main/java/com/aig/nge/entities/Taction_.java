package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SetAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-02-19T16:13:02.762+0530")
@StaticMetamodel(Taction.class)
public class Taction_ {
	public static volatile SingularAttribute<Taction, Short> actionId;
	public static volatile SingularAttribute<Taction, String> actionDs;
	public static volatile SingularAttribute<Taction, Timestamp> createTs;
	public static volatile SingularAttribute<Taction, String> createUserId;
	public static volatile SingularAttribute<Taction, Timestamp> updateTs;
	public static volatile SingularAttribute<Taction, String> updateUserId;
	public static volatile SetAttribute<Taction, TpartyAction> tpartyActions;
}
