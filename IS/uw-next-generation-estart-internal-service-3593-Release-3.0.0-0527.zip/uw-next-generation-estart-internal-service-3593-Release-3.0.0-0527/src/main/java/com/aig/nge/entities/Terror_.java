package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SetAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-06-19T14:59:45.624+0530")
@StaticMetamodel(Terror.class)
public class Terror_ {
	public static volatile SingularAttribute<Terror, Short> errorId;
	public static volatile SingularAttribute<Terror, Timestamp> createTs;
	public static volatile SingularAttribute<Terror, String> createUserId;
	public static volatile SingularAttribute<Terror, String> errorCd;
	public static volatile SingularAttribute<Terror, String> errorMesageTx;
	public static volatile SingularAttribute<Terror, Timestamp> updateTs;
	public static volatile SingularAttribute<Terror, String> updateUserId;
	public static volatile SingularAttribute<Terror, TerrorType> terrorType;
	public static volatile SingularAttribute<Terror, TseverityLevel> tseverityLevel;
	public static volatile SingularAttribute<Terror, Tsystem> tsystem;
	public static volatile SetAttribute<Terror, TerrorMapping> terrorMappings;
	public static volatile SetAttribute<Terror, TerrorLanguage> terrorLanguages;
}
