package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the TTRANSACTION_ATTRIBUTE database table.
 * 
 */
@Entity
@Table(name="TTRANSACTION_ATTRIBUTE")
public class TtransactionAttribute implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private TtransactionAttributePK id;

	@Column(name="ATTRIBUTE_VAL")
	private String attributeVal;

	@Column(name="CREATE_TS")
	private Timestamp createTs;

	@Column(name="CREATE_USER_ID")
	private String createUserId;

	@Column(name="SYSTEM_ID")
	private short systemId;

	@Column(name="UPDATE_TS")
	private Timestamp updateTs;

	@Column(name="UPDATE_USER_ID")
	private String updateUserId;

	//bi-directional many-to-one association to Tattribute
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="ATTRIBUTE_ID")
	private Tattribute tattribute;

	//bi-directional many-to-one association to TtransactionVersion
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumns({
		@JoinColumn(name="TRANSACTION_ID", referencedColumnName="TRANSACTION_ID"),
		@JoinColumn(name="VERSION_SQN", referencedColumnName="VERSION_SQN")
		})
	private TtransactionVersion ttransactionVersion;

    public TtransactionAttribute() {
    }

	public TtransactionAttributePK getId() {
		return this.id;
	}

	public void setId(TtransactionAttributePK id) {
		this.id = id;
	}
	
	public String getAttributeVal() {
		return this.attributeVal;
	}

	public void setAttributeVal(String attributeVal) {
		this.attributeVal = attributeVal;
	}

	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public short getSystemId() {
		return this.systemId;
	}

	public void setSystemId(short systemId) {
		this.systemId = systemId;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public Tattribute getTattribute() {
		return this.tattribute;
	}

	public void setTattribute(Tattribute tattribute) {
		this.tattribute = tattribute;
	}
	
	public TtransactionVersion getTtransactionVersion() {
		return this.ttransactionVersion;
	}

	public void setTtransactionVersion(TtransactionVersion ttransactionVersion) {
		this.ttransactionVersion = ttransactionVersion;
	}
	
}