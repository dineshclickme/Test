package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-02-24T11:59:49.932+0530")
@StaticMetamodel(TpolicyAttribute.class)
public class TpolicyAttribute_ {
	public static volatile SingularAttribute<TpolicyAttribute, TpolicyAttributePK> id;
	public static volatile SingularAttribute<TpolicyAttribute, String> attributeVal;
	public static volatile SingularAttribute<TpolicyAttribute, Timestamp> createTs;
	public static volatile SingularAttribute<TpolicyAttribute, String> createUserId;
	public static volatile SingularAttribute<TpolicyAttribute, Short> systemId;
	public static volatile SingularAttribute<TpolicyAttribute, Timestamp> updateTs;
	public static volatile SingularAttribute<TpolicyAttribute, String> updateUserId;
	public static volatile SingularAttribute<TpolicyAttribute, Tattribute> tattribute;
	public static volatile SingularAttribute<TpolicyAttribute, Tpolicy> tpolicy;
}
