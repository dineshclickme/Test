package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-03-02T12:10:24.645+0530")
@StaticMetamodel(TassetH.class)
public class TassetH_ {
	public static volatile SingularAttribute<TassetH, TassetHPK> id;
	public static volatile SingularAttribute<TassetH, String> assetDs;
	public static volatile SingularAttribute<TassetH, Integer> assetTypeId;
	public static volatile SingularAttribute<TassetH, Timestamp> createTs;
	public static volatile SingularAttribute<TassetH, String> createUserId;
	public static volatile SingularAttribute<TassetH, Short> systemId;
	public static volatile SingularAttribute<TassetH, String> updateUserId;
	public static volatile SingularAttribute<TassetH, Timestamp> updateTs;
}
