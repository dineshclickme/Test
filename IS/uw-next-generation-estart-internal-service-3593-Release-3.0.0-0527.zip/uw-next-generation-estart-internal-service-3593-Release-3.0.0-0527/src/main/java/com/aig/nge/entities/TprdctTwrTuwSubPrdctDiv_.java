package com.aig.nge.entities;

import java.sql.Timestamp;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2016-08-23T15:31:46.838+0530")
@StaticMetamodel(TprdctTwrTuwSubPrdctDiv.class)
public class TprdctTwrTuwSubPrdctDiv_ {
	public static volatile SingularAttribute<TprdctTwrTuwSubPrdctDiv, TprdctTwrTuwSubPrdctDivPK> id;
	public static volatile SingularAttribute<TprdctTwrTuwSubPrdctDiv, Timestamp> createTs;
	public static volatile SingularAttribute<TprdctTwrTuwSubPrdctDiv, String> deletedIn;
	public static volatile SingularAttribute<TprdctTwrTuwSubPrdctDiv, Timestamp> updateTs;
	public static volatile SingularAttribute<TprdctTwrTuwSubPrdctDiv, String> updateUserId;
	public static volatile SingularAttribute<TprdctTwrTuwSubPrdctDiv, TproductTowerTuwSubProduct> tproductTowerTuwSubProdct;
	public static volatile SingularAttribute<TprdctTwrTuwSubPrdctDiv, Tdivision> tdivision;
}
