package com.aig.nge.entities;

import java.sql.Timestamp;
import java.util.Date;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-04-15T15:31:46.916+0530")
@StaticMetamodel(TlegacyMgaProduct.class)
public class TlegacyMgaProduct_ {
	public static volatile SingularAttribute<TlegacyMgaProduct, TlegacyMgaProductPK> id;
	public static volatile SingularAttribute<TlegacyMgaProduct, Timestamp> lastUpdtTs;
	public static volatile SingularAttribute<TlegacyMgaProduct, String> lastUpdtUserId;
	public static volatile SingularAttribute<TlegacyMgaProduct, Date> mgaPrdctEfctvDt;
	public static volatile SingularAttribute<TlegacyMgaProduct, Date> mgaPrdctXprtnDt;
	public static volatile SingularAttribute<TlegacyMgaProduct, String> workingBranchCd;
	public static volatile SingularAttribute<TlegacyMgaProduct, TlegacyProfitCenterProduct> tlegacyProfitCenterProduct;
}
