package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SetAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-02-19T16:13:03.327+0530")
@StaticMetamodel(Tevent.class)
public class Tevent_ {
	public static volatile SingularAttribute<Tevent, Short> eventId;
	public static volatile SingularAttribute<Tevent, Timestamp> createTs;
	public static volatile SingularAttribute<Tevent, String> createUserId;
	public static volatile SingularAttribute<Tevent, Timestamp> updateTs;
	public static volatile SingularAttribute<Tevent, String> updateUserId;
	public static volatile SingularAttribute<Tevent, Tstatus> tstatus1;
	public static volatile SingularAttribute<Tevent, Tstatus> tstatus2;
	public static volatile SetAttribute<Tevent, TtowerEvent> ttowerEvents;
}
