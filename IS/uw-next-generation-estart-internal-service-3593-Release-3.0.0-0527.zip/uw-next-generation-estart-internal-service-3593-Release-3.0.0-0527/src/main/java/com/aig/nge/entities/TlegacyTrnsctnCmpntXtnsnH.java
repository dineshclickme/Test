package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;

import org.springframework.data.domain.Persistable;

import java.sql.Timestamp;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the TLEGACY_TRNSCTN_CMPNT_XTNSN_HS database table.
 * 
 */
@Entity
@Table(name="TLEGACY_TRNSCTN_CMPNT_XTNSN_HS")
public class TlegacyTrnsctnCmpntXtnsnH implements Persistable<Serializable> {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private TlegacyTrnsctnCmpntXtnsnHPK id;

	@Column(name="CREATE_TS")
	private Timestamp createTs;

	@Column(name="CREATE_USER_ID")
	private String createUserId;

	@Column(name="CURRNT_BUS_TYP_CD")
	private String currntBusTypCd;

	@Column(name="DECLINE_REASON_CD")
	private String declineReasonCd;

	@Column(name="LEGACY_BUNDLED_PRODUCT_CD")
	private String legacyBundledProductCd;

	@Column(name="LEGACY_PRODCT_COVG_TYP_CD")
	private String legacyProdctCovgTypCd;

	@Column(name="LEGACY_PRODUCT_CD")
	private String legacyProductCd;

	@Column(name="LOCAL_PART_OF_AM")
	private BigDecimal localPartOfAm;

	@Column(name="PART_OF_AM")
	private BigDecimal partOfAm;

	@Column(name="PROFIT_CENTER_CD")
	private String profitCenterCd;

	@Column(name="PROFIT_UNIT_CD")
	private short profitUnitCd;

	@Column(name="RR_PRTCTV_CONT_NO")
	private int rrPrtctvContNo;

	@Column(name="SECTION_CD")
	private short sectionCd;

	@Column(name="SOURCE_CD")
	private String sourceCd;

	@Column(name="SPECIAL_EVENT_NM")
	private String specialEventNm;

    @Temporal( TemporalType.DATE)
	@Column(name="UNDERWRITING_DT")
	private Date underwritingDt;

	@Column(name="UPDATE_TS")
	private Timestamp updateTs;

	@Column(name="UPDATE_USER_ID")
	private String updateUserId;

	@Column(name="WORKING_BRANCH_CD")
	private String workingBranchCd;

    @Temporal( TemporalType.DATE)
	@Column(name="XCHANGE_RT_EFCTV_DT")
	private Date xchangeRtEfctvDt;

    public TlegacyTrnsctnCmpntXtnsnH() {
    }

	public TlegacyTrnsctnCmpntXtnsnHPK getId() {
		return this.id;
	}

	public void setId(TlegacyTrnsctnCmpntXtnsnHPK id) {
		this.id = id;
	}
	
	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public String getCurrntBusTypCd() {
		return this.currntBusTypCd;
	}

	public void setCurrntBusTypCd(String currntBusTypCd) {
		this.currntBusTypCd = currntBusTypCd;
	}

	public String getDeclineReasonCd() {
		return this.declineReasonCd;
	}

	public void setDeclineReasonCd(String declineReasonCd) {
		this.declineReasonCd = declineReasonCd;
	}

	public String getLegacyBundledProductCd() {
		return this.legacyBundledProductCd;
	}

	public void setLegacyBundledProductCd(String legacyBundledProductCd) {
		this.legacyBundledProductCd = legacyBundledProductCd;
	}

	public String getLegacyProdctCovgTypCd() {
		return this.legacyProdctCovgTypCd;
	}

	public void setLegacyProdctCovgTypCd(String legacyProdctCovgTypCd) {
		this.legacyProdctCovgTypCd = legacyProdctCovgTypCd;
	}

	public String getLegacyProductCd() {
		return this.legacyProductCd;
	}

	public void setLegacyProductCd(String legacyProductCd) {
		this.legacyProductCd = legacyProductCd;
	}

	public BigDecimal getLocalPartOfAm() {
		return this.localPartOfAm;
	}

	public void setLocalPartOfAm(BigDecimal localPartOfAm) {
		this.localPartOfAm = localPartOfAm;
	}

	public BigDecimal getPartOfAm() {
		return this.partOfAm;
	}

	public void setPartOfAm(BigDecimal partOfAm) {
		this.partOfAm = partOfAm;
	}

	public String getProfitCenterCd() {
		return this.profitCenterCd;
	}

	public void setProfitCenterCd(String profitCenterCd) {
		this.profitCenterCd = profitCenterCd;
	}

	public short getProfitUnitCd() {
		return this.profitUnitCd;
	}

	public void setProfitUnitCd(short profitUnitCd) {
		this.profitUnitCd = profitUnitCd;
	}

	public int getRrPrtctvContNo() {
		return this.rrPrtctvContNo;
	}

	public void setRrPrtctvContNo(int rrPrtctvContNo) {
		this.rrPrtctvContNo = rrPrtctvContNo;
	}

	public short getSectionCd() {
		return this.sectionCd;
	}

	public void setSectionCd(short sectionCd) {
		this.sectionCd = sectionCd;
	}

	public String getSourceCd() {
		return this.sourceCd;
	}

	public void setSourceCd(String sourceCd) {
		this.sourceCd = sourceCd;
	}

	public String getSpecialEventNm() {
		return this.specialEventNm;
	}

	public void setSpecialEventNm(String specialEventNm) {
		this.specialEventNm = specialEventNm;
	}

	public Date getUnderwritingDt() {
		return this.underwritingDt;
	}

	public void setUnderwritingDt(Date underwritingDt) {
		this.underwritingDt = underwritingDt;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public String getWorkingBranchCd() {
		return this.workingBranchCd;
	}

	public void setWorkingBranchCd(String workingBranchCd) {
		this.workingBranchCd = workingBranchCd;
	}

	public Date getXchangeRtEfctvDt() {
		return this.xchangeRtEfctvDt;
	}

	public void setXchangeRtEfctvDt(Date xchangeRtEfctvDt) {
		this.xchangeRtEfctvDt = xchangeRtEfctvDt;
	}

	@Override
	public boolean isNew() {
		// TODO Auto-generated method stub
		return true;
	}
}