package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;

import org.apache.openjpa.persistence.DataCache;
import java.sql.Timestamp;
import java.util.Set;


/**
 * The persistent class for the TPRODUCT_TOWER_ATTRIBUTE database table.
 * 
 */
@Entity
@DataCache
@Table(name="TPRODUCT_TOWER_ATTRIBUTE")
public class TproductTowerAttribute implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private TproductTowerAttributePK id;

	@Column(name="ALLOW_MULTIPLE_IN")
	private String allowMultipleIn;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="CREATE_TS")
	private Timestamp createTs;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="CREATE_USER_ID")
	private String createUserId;

	@Column(name="DELETED_IN")
	private String deletedIn;

	@Column(name="LABEL_NM")
	private String labelNm;

	@Column(name="MANDATORY_IN")
	private String mandatoryIn;

	@Column(name="ORDER_SQN")
	private short orderSqn;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="UPDATE_TS")
	private Timestamp updateTs;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="UPDATE_USER_ID")
	private String updateUserId;

	//bi-directional many-to-one association to Tattribute
	@ManyToOne
	@JoinColumn(name="ATTRIBUTE_ID")
	private Tattribute tattribute;

	//bi-directional many-to-one association to TproductTower
	@ManyToOne
	@JoinColumn(name="PRODUCT_TOWER_ID")
	private TproductTower tproductTower;

	//bi-directional many-to-one association to TtableAttribute
	@ManyToOne
	@JoinColumns({
		@JoinColumn(name="ATTRIBUTE_ID", referencedColumnName="ATTRIBUTE_ID"),
		@JoinColumn(name="TABLE_ID", referencedColumnName="TABLE_ID")
		})
	private TtableAttribute ttableAttribute;

	//bi-directional many-to-one association to TproductTowerAttributeUsage
	@OneToMany(mappedBy="tproductTowerAttribute", cascade={CascadeType.ALL})
	private Set<TproductTowerAttributeUsage> tproductTowerAttributeUsages;

    public TproductTowerAttribute() {
    }

	public TproductTowerAttributePK getId() {
		return this.id;
	}

	public void setId(TproductTowerAttributePK id) {
		this.id = id;
	}
	
	public String getAllowMultipleIn() {
		return this.allowMultipleIn;
	}

	public void setAllowMultipleIn(String allowMultipleIn) {
		this.allowMultipleIn = allowMultipleIn;
	}

	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public String getDeletedIn() {
		return this.deletedIn;
	}

	public void setDeletedIn(String deletedIn) {
		this.deletedIn = deletedIn;
	}

	public String getLabelNm() {
		return this.labelNm;
	}

	public void setLabelNm(String labelNm) {
		this.labelNm = labelNm;
	}

	public String getMandatoryIn() {
		return this.mandatoryIn;
	}

	public void setMandatoryIn(String mandatoryIn) {
		this.mandatoryIn = mandatoryIn;
	}

	public short getOrderSqn() {
		return this.orderSqn;
	}

	public void setOrderSqn(short orderSqn) {
		this.orderSqn = orderSqn;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public Tattribute getTattribute() {
		return this.tattribute;
	}

	public void setTattribute(Tattribute tattribute) {
		this.tattribute = tattribute;
	}
	
	public TproductTower getTproductTower() {
		return this.tproductTower;
	}

	public void setTproductTower(TproductTower tproductTower) {
		this.tproductTower = tproductTower;
	}
	
	public TtableAttribute getTtableAttribute() {
		return this.ttableAttribute;
	}

	public void setTtableAttribute(TtableAttribute ttableAttribute) {
		this.ttableAttribute = ttableAttribute;
	}
	
	public Set<TproductTowerAttributeUsage> getTproductTowerAttributeUsages() {
		return this.tproductTowerAttributeUsages;
	}

	public void setTproductTowerAttributeUsages(Set<TproductTowerAttributeUsage> tproductTowerAttributeUsages) {
		this.tproductTowerAttributeUsages = tproductTowerAttributeUsages;
	}
	
}