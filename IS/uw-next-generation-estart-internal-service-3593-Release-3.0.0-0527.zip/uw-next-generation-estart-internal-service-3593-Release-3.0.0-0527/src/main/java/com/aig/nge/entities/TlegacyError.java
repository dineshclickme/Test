package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Set;


/**
 * The persistent class for the TLEGACY_ERROR database table.
 * 
 */
@Entity
@Table(name="TLEGACY_ERROR")
public class TlegacyError implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="LEGACY_ERROR_ID")
	private short legacyErrorId;

	@Column(name="CREATE_TS")
	private Timestamp createTs;

	@Column(name="CREATE_USER_ID")
	private String createUserId;

	@Column(name="LEGACY_ERROR_CD")
	private String legacyErrorCd;

	@Column(name="LEGACY_ERROR_MESAGE_TX")
	private String legacyErrorMesageTx;

	@Column(name="UPDATE_TS")
	private Timestamp updateTs;

	@Column(name="UPDATE_USER_ID")
	private String updateUserId;

	@Column(name="UW_SYSTEM_ID")
	private String uwSystemId;

	//bi-directional many-to-one association to TerrorMapping
	@OneToMany(mappedBy="tlegacyError")
	private Set<TerrorMapping> terrorMappings;

	//bi-directional many-to-one association to TerrorType
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="ERROR_TYPE_CD")
	private TerrorType terrorType;

	//bi-directional many-to-one association to TseverityLevel
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="SEVERITY_LEVEL_CD")
	private TseverityLevel tseverityLevel;

	//bi-directional many-to-one association to TlegacyRulesViolation
	@OneToMany(mappedBy="tlegacyError")
	private Set<TlegacyRulesViolation> tlegacyRulesViolations;

    public TlegacyError() {
    }

	public short getLegacyErrorId() {
		return this.legacyErrorId;
	}

	public void setLegacyErrorId(short legacyErrorId) {
		this.legacyErrorId = legacyErrorId;
	}

	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public String getLegacyErrorCd() {
		return this.legacyErrorCd;
	}

	public void setLegacyErrorCd(String legacyErrorCd) {
		this.legacyErrorCd = legacyErrorCd;
	}

	public String getLegacyErrorMesageTx() {
		return this.legacyErrorMesageTx;
	}

	public void setLegacyErrorMesageTx(String legacyErrorMesageTx) {
		this.legacyErrorMesageTx = legacyErrorMesageTx;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public String getUwSystemId() {
		return this.uwSystemId;
	}

	public void setUwSystemId(String uwSystemId) {
		this.uwSystemId = uwSystemId;
	}

	public Set<TerrorMapping> getTerrorMappings() {
		return this.terrorMappings;
	}

	public void setTerrorMappings(Set<TerrorMapping> terrorMappings) {
		this.terrorMappings = terrorMappings;
	}
	
	public TerrorType getTerrorType() {
		return this.terrorType;
	}

	public void setTerrorType(TerrorType terrorType) {
		this.terrorType = terrorType;
	}
	
	public TseverityLevel getTseverityLevel() {
		return this.tseverityLevel;
	}

	public void setTseverityLevel(TseverityLevel tseverityLevel) {
		this.tseverityLevel = tseverityLevel;
	}
	
	public Set<TlegacyRulesViolation> getTlegacyRulesViolations() {
		return this.tlegacyRulesViolations;
	}

	public void setTlegacyRulesViolations(Set<TlegacyRulesViolation> tlegacyRulesViolations) {
		this.tlegacyRulesViolations = tlegacyRulesViolations;
	}
	
}