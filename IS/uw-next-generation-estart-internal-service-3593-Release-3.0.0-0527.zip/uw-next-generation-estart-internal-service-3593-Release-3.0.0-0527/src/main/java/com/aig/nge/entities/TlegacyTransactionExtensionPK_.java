package com.aig.nge.entities;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-04-15T15:31:47.197+0530")
@StaticMetamodel(TlegacyTransactionExtensionPK.class)
public class TlegacyTransactionExtensionPK_ {
	public static volatile SingularAttribute<TlegacyTransactionExtensionPK, String> transactionId;
	public static volatile SingularAttribute<TlegacyTransactionExtensionPK, Short> versionSqn;
	public static volatile SingularAttribute<TlegacyTransactionExtensionPK, String> legacyBundledProductCd;
}
