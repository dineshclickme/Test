package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;

import org.springframework.data.domain.Persistable;

import java.sql.Timestamp;
import java.util.Date;


/**
 * The persistent class for the TLEGACY_WIP_QUOTE_HS database table.
 * 
 */
@Entity
@Table(name="TLEGACY_WIP_QUOTE_HS")
public class TlegacyWipQuoteH implements Persistable<Serializable> {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private TlegacyWipQuoteHPK id;

	@Column(name="ACCOUNT_LEGAL_NM")
	private String accountLegalNm;

	@Column(name="ACCOUNTING_POL_NO")
	private int accountingPolNo;

	@Column(name="ACCTNG_POL_PRFX_CD")
	private String acctngPolPrfxCd;

	@Column(name="BUSINESS_TYPE_CD")
	private String businessTypeCd;

	@Column(name="CREATE_TS")
	private Timestamp createTs;

	@Column(name="CREATE_USER_ID")
	private String createUserId;

	@Column(name="DELETED_IN")
	private String deletedIn;

	@Column(name="LOSSRSN_ADLCMTS_TX")
	private String lossrsnAdlcmtsTx;

	@Column(name="MASTER_CONTRACT_NO")
	private String masterContractNo;

	@Column(name="NON_RENEWAL_IN")
	private String nonRenewalIn;

	@Column(name="NON_RENEWAL_REASON_CD")
	private String nonRenewalReasonCd;

	@Column(name="POL_EVENT_NO")
	private Short polEventNo;

	@Column(name="POLICY_ID")
	private Integer policyId;

    @Temporal( TemporalType.DATE)
	@Column(name="POLICY_MAILED_DT")
	private Date policyMailedDt;

    @Temporal( TemporalType.DATE)
	@Column(name="POLICY_XPRTN_DT")
	private Date policyXprtnDt;

	@Column(name="PRIOR_POLICY_ID")
	private Integer priorPolicyId;

	@Column(name="PROFIT_UNIT_CD")
	private short profitUnitCd;

	@Column(name="QUOTE_ACCEPTED_IN")
	private String quoteAcceptedIn;

    @Temporal( TemporalType.DATE)
	@Column(name="QUOTE_EFCTV_DT")
	private Date quoteEfctvDt;

    @Temporal( TemporalType.DATE)
	@Column(name="QUOTE_XPRTN_DT")
	private Date quoteXprtnDt;

	@Column(name="REASON_CD")
	private String reasonCd;

	@Column(name="SECTION_CD")
	private short sectionCd;

    @Temporal( TemporalType.DATE)
	@Column(name="STATUS_ENTERED_DT")
	private Date statusEnteredDt;

	@Column(name="UPDATE_TS")
	private Timestamp updateTs;

	@Column(name="UPDATE_USER_ID")
	private String updateUserId;

	@Column(name="UW_SYSTEM_ID")
	private Short uwSystemId;

	@Column(name="WINNING_CARRIER_NM")
	private String winningCarrierNm;

	@Column(name="WIP_STATUS_CD")
	private String wipStatusCd;

    public TlegacyWipQuoteH() {
    }

	public TlegacyWipQuoteHPK getId() {
		return this.id;
	}

	public void setId(TlegacyWipQuoteHPK id) {
		this.id = id;
	}
	
	public String getAccountLegalNm() {
		return this.accountLegalNm;
	}

	public void setAccountLegalNm(String accountLegalNm) {
		this.accountLegalNm = accountLegalNm;
	}

	public int getAccountingPolNo() {
		return this.accountingPolNo;
	}

	public void setAccountingPolNo(int accountingPolNo) {
		this.accountingPolNo = accountingPolNo;
	}

	public String getAcctngPolPrfxCd() {
		return this.acctngPolPrfxCd;
	}

	public void setAcctngPolPrfxCd(String acctngPolPrfxCd) {
		this.acctngPolPrfxCd = acctngPolPrfxCd;
	}

	public String getBusinessTypeCd() {
		return this.businessTypeCd;
	}

	public void setBusinessTypeCd(String businessTypeCd) {
		this.businessTypeCd = businessTypeCd;
	}

	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public String getDeletedIn() {
		return this.deletedIn;
	}

	public void setDeletedIn(String deletedIn) {
		this.deletedIn = deletedIn;
	}

	public String getLossrsnAdlcmtsTx() {
		return this.lossrsnAdlcmtsTx;
	}

	public void setLossrsnAdlcmtsTx(String lossrsnAdlcmtsTx) {
		this.lossrsnAdlcmtsTx = lossrsnAdlcmtsTx;
	}

	public String getMasterContractNo() {
		return this.masterContractNo;
	}

	public void setMasterContractNo(String masterContractNo) {
		this.masterContractNo = masterContractNo;
	}

	public String getNonRenewalIn() {
		return this.nonRenewalIn;
	}

	public void setNonRenewalIn(String nonRenewalIn) {
		this.nonRenewalIn = nonRenewalIn;
	}

	public String getNonRenewalReasonCd() {
		return this.nonRenewalReasonCd;
	}

	public void setNonRenewalReasonCd(String nonRenewalReasonCd) {
		this.nonRenewalReasonCd = nonRenewalReasonCd;
	}

	public Short getPolEventNo() {
		return this.polEventNo;
	}

	public void setPolEventNo(Short polEventNo) {
		this.polEventNo = polEventNo;
	}

	public Integer getPolicyId() {
		return this.policyId;
	}

	public void setPolicyId(Integer policyId) {
		this.policyId = policyId;
	}

	public Date getPolicyMailedDt() {
		return this.policyMailedDt;
	}

	public void setPolicyMailedDt(Date policyMailedDt) {
		this.policyMailedDt = policyMailedDt;
	}

	public Date getPolicyXprtnDt() {
		return this.policyXprtnDt;
	}

	public void setPolicyXprtnDt(Date policyXprtnDt) {
		this.policyXprtnDt = policyXprtnDt;
	}

	public Integer getPriorPolicyId() {
		return this.priorPolicyId;
	}

	public void setPriorPolicyId(Integer priorPolicyId) {
		this.priorPolicyId = priorPolicyId;
	}

	public short getProfitUnitCd() {
		return this.profitUnitCd;
	}

	public void setProfitUnitCd(short profitUnitCd) {
		this.profitUnitCd = profitUnitCd;
	}

	public String getQuoteAcceptedIn() {
		return this.quoteAcceptedIn;
	}

	public void setQuoteAcceptedIn(String quoteAcceptedIn) {
		this.quoteAcceptedIn = quoteAcceptedIn;
	}

	public Date getQuoteEfctvDt() {
		return this.quoteEfctvDt;
	}

	public void setQuoteEfctvDt(Date quoteEfctvDt) {
		this.quoteEfctvDt = quoteEfctvDt;
	}

	public Date getQuoteXprtnDt() {
		return this.quoteXprtnDt;
	}

	public void setQuoteXprtnDt(Date quoteXprtnDt) {
		this.quoteXprtnDt = quoteXprtnDt;
	}

	public String getReasonCd() {
		return this.reasonCd;
	}

	public void setReasonCd(String reasonCd) {
		this.reasonCd = reasonCd;
	}

	public short getSectionCd() {
		return this.sectionCd;
	}

	public void setSectionCd(short sectionCd) {
		this.sectionCd = sectionCd;
	}

	public Date getStatusEnteredDt() {
		return this.statusEnteredDt;
	}

	public void setStatusEnteredDt(Date statusEnteredDt) {
		this.statusEnteredDt = statusEnteredDt;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public Short getUwSystemId() {
		return this.uwSystemId;
	}

	public void setUwSystemId(Short uwSystemId) {
		this.uwSystemId = uwSystemId;
	}

	public String getWinningCarrierNm() {
		return this.winningCarrierNm;
	}

	public void setWinningCarrierNm(String winningCarrierNm) {
		this.winningCarrierNm = winningCarrierNm;
	}

	public String getWipStatusCd() {
		return this.wipStatusCd;
	}

	public void setWipStatusCd(String wipStatusCd) {
		this.wipStatusCd = wipStatusCd;
	}

	@Override
	public boolean isNew() {
		// TODO Auto-generated method stub
		return true;
	}
}