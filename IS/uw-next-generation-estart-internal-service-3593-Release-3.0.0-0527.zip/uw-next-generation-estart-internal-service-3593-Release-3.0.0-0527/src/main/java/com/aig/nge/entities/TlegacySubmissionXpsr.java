package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the TLEGACY_SUBMISSION_XPSR database table.
 * 
 */
@Entity
@Table(name="TLEGACY_SUBMISSION_XPSR")
public class TlegacySubmissionXpsr implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private TlegacySubmissionXpsrPK id;

	@Column(name="CREATE_TS")
	private Timestamp createTs;

	@Column(name="CREATE_USER_ID")
	private String createUserId;

	@Column(name="UPDATE_TS")
	private Timestamp updateTs;

	@Column(name="UPDATE_USER_ID")
	private String updateUserId;

	//bi-directional many-to-one association to Tsubmission
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="SUBMISSION_NO")
	private Tsubmission tsubmission;

	//bi-directional many-to-one association to Tsource
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="EXPOSURE_SOURCE_CD")
	private Tsource tsource;

    public TlegacySubmissionXpsr() {
    }

	public TlegacySubmissionXpsrPK getId() {
		return this.id;
	}

	public void setId(TlegacySubmissionXpsrPK id) {
		this.id = id;
	}
	
	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public Tsubmission getTsubmission() {
		return this.tsubmission;
	}

	public void setTsubmission(Tsubmission tsubmission) {
		this.tsubmission = tsubmission;
	}
	
	public Tsource getTsource() {
		return this.tsource;
	}

	public void setTsource(Tsource tsource) {
		this.tsource = tsource;
	}
	
}