package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the TSCREEN_FIELD database table.
 * 
 */
@Entity
@Table(name="TSCREEN_FIELD")
public class TscreenField implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private TscreenFieldPK id;

	@Column(name="CREATE_TS")
	private Timestamp createTs;

	@Column(name="CREATE_USER_ID")
	private String createUserId;

	@Column(name="DISPLAY_NM")
	private String displayNm;

	@Column(name="UPDATE_TS")
	private Timestamp updateTs;

	@Column(name="UPDATE_USER_ID")
	private String updateUserId;

	//bi-directional many-to-one association to Tfield
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="FIELD_ID")
	private Tfield tfield;

	//bi-directional many-to-one association to Thelp
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="HELP_ID")
	private Thelp thelp;

	//bi-directional many-to-one association to Tscreen
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="SCREEN_ID")
	private Tscreen tscreen;

    public TscreenField() {
    }

	public TscreenFieldPK getId() {
		return this.id;
	}

	public void setId(TscreenFieldPK id) {
		this.id = id;
	}
	
	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public String getDisplayNm() {
		return this.displayNm;
	}

	public void setDisplayNm(String displayNm) {
		this.displayNm = displayNm;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public Tfield getTfield() {
		return this.tfield;
	}

	public void setTfield(Tfield tfield) {
		this.tfield = tfield;
	}
	
	public Thelp getThelp() {
		return this.thelp;
	}

	public void setThelp(Thelp thelp) {
		this.thelp = thelp;
	}
	
	public Tscreen getTscreen() {
		return this.tscreen;
	}

	public void setTscreen(Tscreen tscreen) {
		this.tscreen = tscreen;
	}
	
}