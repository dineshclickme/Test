package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the TRELATED_PARTY database table.
 * 
 */
@Embeddable
public class TrelatedPartyPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="PARTY_ID")
	private int partyId;

	@Column(name="RELATED_PARTY_ID")
	private int relatedPartyId;

	@Column(name="RELATION_TYPE_ID")
	private short relationTypeId;

    public TrelatedPartyPK() {
    }
	public int getPartyId() {
		return this.partyId;
	}
	public void setPartyId(int partyId) {
		this.partyId = partyId;
	}
	public int getRelatedPartyId() {
		return this.relatedPartyId;
	}
	public void setRelatedPartyId(int relatedPartyId) {
		this.relatedPartyId = relatedPartyId;
	}
	public short getRelationTypeId() {
		return this.relationTypeId;
	}
	public void setRelationTypeId(short relationTypeId) {
		this.relationTypeId = relationTypeId;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof TrelatedPartyPK)) {
			return false;
		}
		TrelatedPartyPK castOther = (TrelatedPartyPK)other;
		return 
			(this.partyId == castOther.partyId)
			&& (this.relatedPartyId == castOther.relatedPartyId)
			&& (this.relationTypeId == castOther.relationTypeId);

    }
    
	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.partyId;
		hash = hash * prime + this.relatedPartyId;
		hash = hash * prime + ((int) this.relationTypeId);
		
		return hash;
    }
}