package com.aig.nge.entities;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2016-01-30T17:32:13.512+0530")
@StaticMetamodel(TlegacyUserTypeFnctnPK.class)
public class TlegacyUserTypeFnctnPK_ {
	public static volatile SingularAttribute<TlegacyUserTypeFnctnPK, String> userTypeCd;
	public static volatile SingularAttribute<TlegacyUserTypeFnctnPK, String> functionTypeCd;
	public static volatile SingularAttribute<TlegacyUserTypeFnctnPK, String> functionCd;
}
