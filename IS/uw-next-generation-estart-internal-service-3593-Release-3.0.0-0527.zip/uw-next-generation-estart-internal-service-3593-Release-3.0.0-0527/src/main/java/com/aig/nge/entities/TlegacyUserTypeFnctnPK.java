package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the TLEGACY_USER_TYPE_FNCTN database table.
 * 
 */
@Embeddable
public class TlegacyUserTypeFnctnPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="USER_TYPE_CD")
	private String userTypeCd;

	@Column(name="FUNCTION_TYPE_CD")
	private String functionTypeCd;

	@Column(name="FUNCTION_CD")
	private String functionCd;

    public TlegacyUserTypeFnctnPK() {
    }
	public String getUserTypeCd() {
		return this.userTypeCd;
	}
	public void setUserTypeCd(String userTypeCd) {
		this.userTypeCd = userTypeCd;
	}
	public String getFunctionTypeCd() {
		return this.functionTypeCd;
	}
	public void setFunctionTypeCd(String functionTypeCd) {
		this.functionTypeCd = functionTypeCd;
	}
	public String getFunctionCd() {
		return this.functionCd;
	}
	public void setFunctionCd(String functionCd) {
		this.functionCd = functionCd;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof TlegacyUserTypeFnctnPK)) {
			return false;
		}
		TlegacyUserTypeFnctnPK castOther = (TlegacyUserTypeFnctnPK)other;
		return 
			this.userTypeCd.equals(castOther.userTypeCd)
			&& this.functionTypeCd.equals(castOther.functionTypeCd)
			&& this.functionCd.equals(castOther.functionCd);

    }
    
	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.userTypeCd.hashCode();
		hash = hash * prime + this.functionTypeCd.hashCode();
		hash = hash * prime + this.functionCd.hashCode();
		
		return hash;
    }
}