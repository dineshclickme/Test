package com.aig.nge.entities;

import java.math.BigDecimal;
import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SetAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-06-19T14:59:46.096+0530")
@StaticMetamodel(TtickerFeed.class)
public class TtickerFeed_ {
	public static volatile SingularAttribute<TtickerFeed, Short> feedId;
	public static volatile SingularAttribute<TtickerFeed, Timestamp> createTs;
	public static volatile SingularAttribute<TtickerFeed, String> createUserId;
	public static volatile SingularAttribute<TtickerFeed, String> deletedIn;
	public static volatile SingularAttribute<TtickerFeed, String> feedDs;
	public static volatile SingularAttribute<TtickerFeed, String> feedNm;
	public static volatile SingularAttribute<TtickerFeed, BigDecimal> minimumPremiumAm;
	public static volatile SingularAttribute<TtickerFeed, Timestamp> updateTs;
	public static volatile SingularAttribute<TtickerFeed, String> updateUserId;
	public static volatile SetAttribute<TtickerFeed, TtickerDivisionProduct> ttickerDivisionProducts;
	public static volatile SingularAttribute<TtickerFeed, String> segmentCd;
}
