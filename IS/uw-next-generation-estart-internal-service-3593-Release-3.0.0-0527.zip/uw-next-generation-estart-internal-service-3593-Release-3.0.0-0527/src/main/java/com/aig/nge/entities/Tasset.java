package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Set;


/**
 * The persistent class for the TASSET database table.
 * 
 */
@Entity
public class Tasset implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "asset_id_gen")
	@SequenceGenerator(name = "asset_id_gen", sequenceName = "ASSET_ID_SEQ", allocationSize = 1)
	@Column(name="ASSET_ID")
	private int assetId;

	@Column(name="ASSET_DS")
	private String assetDs;

	@Column(name="CREATE_TS")
	private Timestamp createTs;

	@Column(name="CREATE_USER_ID")
	private String createUserId;

	@Column(name="SYSTEM_ID")
	private short systemId;

	@Column(name="UPDATE_TS")
	private Timestamp updateTs;

	@Column(name="UPDATE_USER_ID")
	private String updateUserId;

	//bi-directional many-to-one association to TassetType
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="ASSET_TYPE_ID")
	private TassetType tassetType;

	//bi-directional many-to-one association to TassetAttribute
	@OneToMany(mappedBy="tasset", cascade={CascadeType.ALL})
	private Set<TassetAttribute> tassetAttributes;

	//bi-directional many-to-one association to TtransactionComponentAsset
	@OneToMany(mappedBy="tasset", cascade={CascadeType.ALL})
	private Set<TtransactionComponentAsset> ttransactionComponentAssets;

    public Tasset() {
    }

	public int getAssetId() {
		return this.assetId;
	}

	public void setAssetId(int assetId) {
		this.assetId = assetId;
	}

	public String getAssetDs() {
		return this.assetDs;
	}

	public void setAssetDs(String assetDs) {
		this.assetDs = assetDs;
	}

	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public short getSystemId() {
		return this.systemId;
	}

	public void setSystemId(short systemId) {
		this.systemId = systemId;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public TassetType getTassetType() {
		return this.tassetType;
	}

	public void setTassetType(TassetType tassetType) {
		this.tassetType = tassetType;
	}
	
	public Set<TassetAttribute> getTassetAttributes() {
		return this.tassetAttributes;
	}

	public void setTassetAttributes(Set<TassetAttribute> tassetAttributes) {
		this.tassetAttributes = tassetAttributes;
	}
	
	public Set<TtransactionComponentAsset> getTtransactionComponentAssets() {
		return this.ttransactionComponentAssets;
	}

	public void setTtransactionComponentAssets(Set<TtransactionComponentAsset> ttransactionComponentAssets) {
		this.ttransactionComponentAssets = ttransactionComponentAssets;
	}
	
}