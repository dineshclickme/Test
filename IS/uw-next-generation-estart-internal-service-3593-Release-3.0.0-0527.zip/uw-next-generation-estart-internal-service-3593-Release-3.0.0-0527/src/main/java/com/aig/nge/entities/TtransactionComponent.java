package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;

import com.aig.nge.utilities.NGEConstants;

import java.sql.Timestamp;
import java.util.Date;
import java.util.Set;


/**
 * The persistent class for the TTRANSACTION_COMPONENT database table.
 * 
 */
@Entity
@Table(name="TTRANSACTION_COMPONENT")
public class TtransactionComponent implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "transaction_component_id_gen")
	@SequenceGenerator(name = "transaction_component_id_gen", sequenceName = "TRANSACTION_COMPONENT_ID_SEQ", allocationSize = 1)
	@Column(name="TRANSACTION_COMPONENT_ID")
	private String transactionComponentId;

    @Temporal( TemporalType.DATE)
	@Column(name="AUTO_CLOSE_DT")
	private Date autoCloseDt;

    @Temporal( TemporalType.DATE)
	@Column(name="BLOCKING_EXTENSION_DT")
	private Date blockingExtensionDt;

	@Column(name="CREATE_TS")
	private Timestamp createTs;

	@Column(name="CREATE_USER_ID")
	private String createUserId;

	@Column(name="DELETED_IN")
	private String deletedIn;

    @Temporal( TemporalType.DATE)
	@Column(name="EFFECTIVE_DT")
	private Date effectiveDt;

    @Temporal( TemporalType.DATE)
	@Column(name="EXPIRATION_DT")
	private Date expirationDt;

	@Column(name="LEGACY_IN")
	private String legacyIn;

	@Column(name="LOCK_IN")
	private String lockIn;

	@Column(name="SYSTEM_ID")
	private short systemId;

	@Column(name="UPDATE_TS")
	private Timestamp updateTs;

	@Column(name="UPDATE_USER_ID")
	private String updateUserId;
	
	@Column(name="MASTER_LOB_CD")
	private String masterLobCd;
	
	@Column(name="COVERAGE_LINE_CD")
	private String coverageLineCd;
	
	@Column(name="COVERAGE_SUB_LINE_CD")
	private String coverageSubLineCd;
	
	@Column(name="MLOB_IN")
	private String mlobIn;

	//bi-directional many-to-one association to Tblock
	@OneToMany(mappedBy="ttransactionComponent", cascade={CascadeType.ALL})
	private Set<Tblock> tblocks;

	//bi-directional many-to-one association to TcomponentBlock
	@OneToMany(mappedBy="ttransactionComponent", cascade={CascadeType.ALL})
	private Set<TcomponentBlock> tcomponentBlocks;

	//bi-directional one-to-one association to TlegacyRulesViolation
	@OneToOne(mappedBy="ttransactionComponent", fetch=FetchType.LAZY, cascade={CascadeType.ALL})
	private TlegacyRulesViolation tlegacyRulesViolation;
	//bi-directional many-to-one association to TtransactionCmpntXpsrLoc
	@OneToMany(mappedBy="ttransactionComponent", cascade={CascadeType.ALL})
	private Set<TtransactionCmpntXpsrLoc> ttransactionCmpntXpsrLocs;

	//bi-directional many-to-one association to Tparty
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="UNDERWRITER_ID")
	private Tparty tparty;

	//bi-directional many-to-one association to TpartyProcessing
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="PARTY_PROCESSING_ID")
	private TpartyProcessing tpartyProcessing;

	//bi-directional many-to-one association to TproductState
    @ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="PRODUCT_STATE_ID")
	private TproductState tproductState;

	//bi-directional many-to-one association to TproductTowerDivision
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="PRODUCT_TOWER_DIVISION_ID")
	private TproductTowerDivision tproductTowerDivision;

	//bi-directional many-to-one association to TtransactionVersion
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumns({
		@JoinColumn(name="TRANSACTION_ID", referencedColumnName="TRANSACTION_ID"),
		@JoinColumn(name="VERSION_SQN", referencedColumnName="VERSION_SQN")
		})
	private TtransactionVersion ttransactionVersion;

	//bi-directional many-to-one association to VcomponentProduct
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumns({
		@JoinColumn(name="COMPONENT_PRODUCT_ID", referencedColumnName="COMPONENT_PRODUCT_ID"),
		@JoinColumn(name="PRODUCT_DETAIL_ID", referencedColumnName="PRODUCT_DETAIL_ID")
		})
	private VcomponentProduct vcomponentProduct;

	//bi-directional many-to-one association to TtransactionComponentAsset
	@OneToMany(mappedBy="ttransactionComponent", cascade={CascadeType.ALL})
	private Set<TtransactionComponentAsset> ttransactionComponentAssets;

	//bi-directional many-to-one association to TtransactionComponentAtrbt
	@OneToMany(mappedBy="ttransactionComponent", cascade={CascadeType.ALL})
	private Set<TtransactionComponentAtrbt> ttransactionComponentAtrbts;

	//bi-directional many-to-one association to TtransactionComponentBranch
	@OneToMany(mappedBy="ttransactionComponent", cascade={CascadeType.ALL})
	private Set<TtransactionComponentBranch> ttransactionComponentBranches;

	//bi-directional many-to-one association to TtransactionComponentLimit
	@OneToMany(mappedBy="ttransactionComponent", cascade={CascadeType.ALL})
	private Set<TtransactionComponentLimit> ttransactionComponentLimits;

	//bi-directional many-to-one association to TtransactionComponentParty
	@OneToMany(mappedBy="ttransactionComponent", cascade={CascadeType.ALL})
	private Set<TtransactionComponentParty> ttransactionComponentParties;

	//bi-directional many-to-one association to TtransactionComponentPolicy
	@OneToMany(mappedBy="ttransactionComponent", cascade={CascadeType.ALL})
	private Set<TtransactionComponentPolicy> ttransactionComponentPolicies;

	//bi-directional many-to-one association to TtransactionComponentRltn
	@OneToMany(mappedBy="ttransactionComponent1", cascade={CascadeType.ALL})
	private Set<TtransactionComponentRltn> ttransactionComponentRltns1;

	//bi-directional many-to-one association to TtransactionComponentRltn
	@OneToMany(mappedBy="ttransactionComponent2", cascade={CascadeType.ALL})
	private Set<TtransactionComponentRltn> ttransactionComponentRltns2;

	//bi-directional many-to-one association to TtransactionComponentStatus
	@OneToMany(mappedBy="ttransactionComponent", cascade={CascadeType.ALL})
	private Set<TtransactionComponentStatus> ttransactionComponentStatuses;

	//bi-directional many-to-one association to TlegacyProductLeadSrcTyp
	/* April 2017 Maintenance Release 2.4 - Delete Transaction Cascade Issue - Lead Information - Starts */
	@OneToMany(mappedBy="ttransactionComponent",fetch=FetchType.LAZY, cascade={CascadeType.ALL})
	private Set<TlegacyProductLeadSrcTyp> tlegacyProductLeadSrcTyps;
	/* April 2017 Maintenance Release 2.4 - Delete Transaction Cascade Issue - Lead Information - Ends */
	
	/* April 2017 Maintenance Release 2.4 - Delete Transaction Cascade Issue - Lead Information - Starts */
	//bi-directional many-to-one association to TlegacyProductLeadType
	@OneToMany(mappedBy="ttransactionComponent",fetch=FetchType.LAZY, cascade={CascadeType.ALL})
	private Set<TlegacyProductLeadType> tlegacyProductLeadTypes;
	/* April 2017 Maintenance Release 2.4 - Delete Transaction Cascade Issue - Lead Information - Ends */

	//bi-directional one-to-one association to TlegacyTrnsctnCmpntXtensn
	@OneToOne(mappedBy="ttransactionComponent",fetch=FetchType.LAZY, cascade={CascadeType.ALL})
	private TlegacyTrnsctnCmpntXtensn tlegacyTrnsctnCmpntXtensn;

	//bi-directional many-to-one association to TlegacyWipQuote
	@OneToMany(mappedBy="ttransactionComponent",cascade={CascadeType.ALL})
	private Set<TlegacyWipQuote> tlegacyWipQuotes;
	
	
	//2020 SCUP Release - MLOB change - US152343
    @ManyToOne(fetch=FetchType.LAZY)
    @JoinColumns({
    @JoinColumn(name="MASTER_LOB_CD", referencedColumnName="MASTER_LOB_CD"),
    @JoinColumn(name="COVERAGE_LINE_CD", referencedColumnName="COVERAGE_LINE_CD")})
	private TmlobBlockLevel tmlobBlockLevel;

    public TtransactionComponent() {
    }

	public String getTransactionComponentId() {
		return this.transactionComponentId;
	}

	public void setTransactionComponentId(String transactionComponentId) {
		this.transactionComponentId = transactionComponentId;
	}

	public Date getAutoCloseDt() {
		return this.autoCloseDt;
	}

	public void setAutoCloseDt(Date autoCloseDt) {
		this.autoCloseDt = autoCloseDt;
	}

	public Date getBlockingExtensionDt() {
		return this.blockingExtensionDt;
	}

	public void setBlockingExtensionDt(Date blockingExtensionDt) {
		this.blockingExtensionDt = blockingExtensionDt;
	}

	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public String getDeletedIn() {
		return this.deletedIn;
	}

	public void setDeletedIn(String deletedIn) {
		this.deletedIn = deletedIn;
	}

	public Date getEffectiveDt() {
		return this.effectiveDt;
	}

	public void setEffectiveDt(Date effectiveDt) {
		this.effectiveDt = effectiveDt;
	}

	public Date getExpirationDt() {
		return this.expirationDt;
	}

	public void setExpirationDt(Date expirationDt) {
		this.expirationDt = expirationDt;
	}

	public String getLegacyIn() {
		return this.legacyIn;
	}

	public void setLegacyIn(String legacyIn) {
		this.legacyIn = legacyIn;
	}

	public String getLockIn() {
		return this.lockIn;
	}

	public void setLockIn(String lockIn) {
		this.lockIn = lockIn;
	}

	public short getSystemId() {
		return this.systemId;
	}

	public void setSystemId(short systemId) {
		this.systemId = systemId;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}
	

	public String getMasterLobCd() {
		return masterLobCd;
	}

	public void setMasterLobCd(String masterLobCd) {
		this.masterLobCd = masterLobCd;
	}

	public String getCoverageLineCd() {
		return coverageLineCd;
	}

	public void setCoverageLineCd(String coverageLineCd) {
		this.coverageLineCd = coverageLineCd;
	}

	public String getCoverageSubLineCd() {
		return coverageSubLineCd;
	}

	public void setCoverageSubLineCd(String coverageSubLineCd) {
		this.coverageSubLineCd = coverageSubLineCd;
	}

	public String getMlobIn() {
		if(mlobIn == null){
			mlobIn=NGEConstants.NO;
		}
		return mlobIn;
	}

	public void setMlobIn(String mlobIn) {
		this.mlobIn = mlobIn;
	}

	public Set<Tblock> getTblocks() {
		return this.tblocks;
	}

	public void setTblocks(Set<Tblock> tblocks) {
		this.tblocks = tblocks;
	}
	
	public Set<TcomponentBlock> getTcomponentBlocks() {
		return this.tcomponentBlocks;
	}

	public void setTcomponentBlocks(Set<TcomponentBlock> tcomponentBlocks) {
		this.tcomponentBlocks = tcomponentBlocks;
	}
	
	public TlegacyRulesViolation getTlegacyRulesViolation() {
		return this.tlegacyRulesViolation;
	}

	public void setTlegacyRulesViolation(TlegacyRulesViolation tlegacyRulesViolation) {
		this.tlegacyRulesViolation = tlegacyRulesViolation;
	}
	public Set<TtransactionCmpntXpsrLoc> getTtransactionCmpntXpsrLocs() {
		return this.ttransactionCmpntXpsrLocs;
	}

	public void setTtransactionCmpntXpsrLocs(Set<TtransactionCmpntXpsrLoc> ttransactionCmpntXpsrLocs) {
		this.ttransactionCmpntXpsrLocs = ttransactionCmpntXpsrLocs;
	}
	
	public Tparty getTparty() {
		return this.tparty;
	}

	public void setTparty(Tparty tparty) {
		this.tparty = tparty;
	}
	
	public TpartyProcessing getTpartyProcessing() {
		return this.tpartyProcessing;
	}

	public void setTpartyProcessing(TpartyProcessing tpartyProcessing) {
		this.tpartyProcessing = tpartyProcessing;
	}
	
	public TproductState getTproductState() {
		return this.tproductState;
	}

	public void setTproductState(TproductState tproductState) {
		this.tproductState = tproductState;
	}
	
	public TproductTowerDivision getTproductTowerDivision() {
		return this.tproductTowerDivision;
	}

	public void setTproductTowerDivision(TproductTowerDivision tproductTowerDivision) {
		this.tproductTowerDivision = tproductTowerDivision;
	}
	
	public TtransactionVersion getTtransactionVersion() {
		return this.ttransactionVersion;
	}

	public void setTtransactionVersion(TtransactionVersion ttransactionVersion) {
		this.ttransactionVersion = ttransactionVersion;
	}
	
	public VcomponentProduct getVcomponentProduct() {
		return this.vcomponentProduct;
	}

	public void setVcomponentProduct(VcomponentProduct vcomponentProduct) {
		this.vcomponentProduct = vcomponentProduct;
	}
	
	public Set<TtransactionComponentAsset> getTtransactionComponentAssets() {
		return this.ttransactionComponentAssets;
	}

	public void setTtransactionComponentAssets(Set<TtransactionComponentAsset> ttransactionComponentAssets) {
		this.ttransactionComponentAssets = ttransactionComponentAssets;
	}
	
	public Set<TtransactionComponentAtrbt> getTtransactionComponentAtrbts() {
		return this.ttransactionComponentAtrbts;
	}

	public void setTtransactionComponentAtrbts(Set<TtransactionComponentAtrbt> ttransactionComponentAtrbts) {
		this.ttransactionComponentAtrbts = ttransactionComponentAtrbts;
	}
	
	public Set<TtransactionComponentBranch> getTtransactionComponentBranches() {
		return this.ttransactionComponentBranches;
	}

	public void setTtransactionComponentBranches(Set<TtransactionComponentBranch> ttransactionComponentBranches) {
		this.ttransactionComponentBranches = ttransactionComponentBranches;
	}
	
	public Set<TtransactionComponentLimit> getTtransactionComponentLimits() {
		return this.ttransactionComponentLimits;
	}

	public void setTtransactionComponentLimits(Set<TtransactionComponentLimit> ttransactionComponentLimits) {
		this.ttransactionComponentLimits = ttransactionComponentLimits;
	}
	
	public Set<TtransactionComponentParty> getTtransactionComponentParties() {
		return this.ttransactionComponentParties;
	}

	public void setTtransactionComponentParties(Set<TtransactionComponentParty> ttransactionComponentParties) {
		this.ttransactionComponentParties = ttransactionComponentParties;
	}
	
	public Set<TtransactionComponentPolicy> getTtransactionComponentPolicies() {
		return this.ttransactionComponentPolicies;
	}

	public void setTtransactionComponentPolicies(Set<TtransactionComponentPolicy> ttransactionComponentPolicies) {
		this.ttransactionComponentPolicies = ttransactionComponentPolicies;
	}
	
	public Set<TtransactionComponentRltn> getTtransactionComponentRltns1() {
		return this.ttransactionComponentRltns1;
	}

	public void setTtransactionComponentRltns1(Set<TtransactionComponentRltn> ttransactionComponentRltns1) {
		this.ttransactionComponentRltns1 = ttransactionComponentRltns1;
	}
	
	public Set<TtransactionComponentRltn> getTtransactionComponentRltns2() {
		return this.ttransactionComponentRltns2;
	}

	public void setTtransactionComponentRltns2(Set<TtransactionComponentRltn> ttransactionComponentRltns2) {
		this.ttransactionComponentRltns2 = ttransactionComponentRltns2;
	}
	
	public Set<TtransactionComponentStatus> getTtransactionComponentStatuses() {
		return this.ttransactionComponentStatuses;
	}

	public void setTtransactionComponentStatuses(Set<TtransactionComponentStatus> ttransactionComponentStatuses) {
		this.ttransactionComponentStatuses = ttransactionComponentStatuses;
	}
	
	public Set<TlegacyProductLeadSrcTyp> getTlegacyProductLeadSrcTyps() {
		return this.tlegacyProductLeadSrcTyps;
	}

	public void setTlegacyProductLeadSrcTyps(Set<TlegacyProductLeadSrcTyp> tlegacyProductLeadSrcTyps) {
		this.tlegacyProductLeadSrcTyps = tlegacyProductLeadSrcTyps;
	}
	
	public Set<TlegacyProductLeadType> getTlegacyProductLeadTypes() {
		return this.tlegacyProductLeadTypes;
	}

	public void setTlegacyProductLeadTypes(Set<TlegacyProductLeadType> tlegacyProductLeadTypes) {
		this.tlegacyProductLeadTypes = tlegacyProductLeadTypes;
	}
	
	public TlegacyTrnsctnCmpntXtensn getTlegacyTrnsctnCmpntXtensn() {
		return this.tlegacyTrnsctnCmpntXtensn;
	}

	public void setTlegacyTrnsctnCmpntXtensn(TlegacyTrnsctnCmpntXtensn tlegacyTrnsctnCmpntXtensn) {
		this.tlegacyTrnsctnCmpntXtensn = tlegacyTrnsctnCmpntXtensn;
	}
	
	public Set<TlegacyWipQuote> getTlegacyWipQuotes() {
		return this.tlegacyWipQuotes;
	}

	public void setTlegacyWipQuotes(Set<TlegacyWipQuote> tlegacyWipQuotes) {
		this.tlegacyWipQuotes = tlegacyWipQuotes;
	}

	public TmlobBlockLevel getTmlobBlockLevel() {
		return this.tmlobBlockLevel;
	}

	public void setTmlobBlockLevel(TmlobBlockLevel tmlobBlockLevel) {
		this.tmlobBlockLevel = tmlobBlockLevel;
	}	
	
}