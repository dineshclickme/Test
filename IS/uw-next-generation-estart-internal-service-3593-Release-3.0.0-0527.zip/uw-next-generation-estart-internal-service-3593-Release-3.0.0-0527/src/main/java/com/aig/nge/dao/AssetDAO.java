package com.aig.nge.dao;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.jpa.JpaSystemException;
import org.springframework.stereotype.Repository;

import com.aig.nge.entities.Tasset;
import com.aig.nge.entities.TassetAttribute;
import com.aig.nge.entities.TassetAttributePK;
import com.aig.nge.entities.TassetType;
import com.aig.nge.entities.TassetTypeAttribute;
import com.aig.nge.entities.Tattribute;
import com.aig.nge.entities.TprdctTwrTuwSbprdctAstTyp;
import com.aig.nge.entities.TproductTower;
import com.aig.nge.entities.TtransactionComponent;
import com.aig.nge.entities.TtransactionComponentAsset;
import com.aig.nge.entities.TtransactionComponentAssetPK;
import com.aig.nge.entities.VcomponentProduct;
import com.aig.nge.model.AssetModel;
import com.aig.nge.repository.TAssetRepository;
import com.aig.nge.repository.TAssetTypeRepository;
import com.aig.nge.repository.TAttributeRepository;
import com.aig.nge.repository.TProductTowerTUWSubProductAssetTypeRepository;
import com.aig.nge.repository.TassetTypeAttributeRepository;
import com.aig.nge.utilities.AIGCIExceptionMsg;
import com.aig.nge.utilities.NGEConstants;
import com.aig.nge.utilities.NGEErrorCodes;
import com.aig.nge.utilities.NGESession;
import com.aig.nge.wsdl.skeleton.Asset;
import com.aig.nge.wsdl.skeleton.Attribute;
import com.aig.nge.wsdl.skeleton.Attributes;

/**
 * @author DineshSelvaraj
 * This DAO class is used accessing the asset related repositories 
 * Used repositories are :
 * 	TPartyRepository,TaccountRepository,TproducerRepository, TPartyTypeRepository
 * 	TshellAccountRepository, TrelatedPartyRepository
 */
@Repository
public class AssetDAO extends BaseDAO{

	@Autowired
	private TAssetRepository tAssetRepository;
	
	@Autowired
	private TAssetTypeRepository tAssetTypeRepository;
	
	/*@Autowired
	private TAssetAttributeRepository tAssetAttributeRepository; */
	
	@Autowired
	private TAttributeRepository tAttributeRepository;
	
/*	@Autowired
	private SequenceNumberGeneration sequenceNumberGeneration;*/
	
	@Autowired
	private ProductDAO productDAO;
	
	@Autowired
	private TProductTowerTUWSubProductAssetTypeRepository tProductTowerTUWSubProductAssetTypeRepository;
	
	@Autowired
	private TassetTypeAttributeRepository tassetTypeAttributeRepository;
	
	
	/**
	 * @author Dinesh Selvaraj
	 * @param assetType
	 * @param assetValue
	 * @return
	 * @throws JpaSystemException
	 * @throws AIGCIExceptionMsg
	 * This method is used to get assets for products
	 */
	public List<Tasset> getAssets(String assetType,String assetValue) throws JpaSystemException, AIGCIExceptionMsg
	{
		List<Tasset> tAssetData=null;
		
		tAssetData=tAssetRepository.findByAssetTypeAndValue(assetType.toUpperCase(), assetValue);
		if(tAssetData==null){
			ngeException.throwException("ERR30016", NGEErrorCodes.ERROR_TYPE, null,null); /*EXC Assets not available for the given Asset Type */
		}
		return tAssetData;
	}
	
	public void validateAssetandAssetType(List<TassetType> tAssetTypeData, short productTowerId, int componentProductId) throws AIGCIExceptionMsg{
		
		TprdctTwrTuwSbprdctAstTyp tPrdctTwrTuwSbprdctAstTypData = null;		
		int subProductId = 0;	
		int assetTypeId = 0;	
		
		if(tAssetTypeData != null && tAssetTypeData.size() > 0){
			assetTypeId = tAssetTypeData.get(0).getAssetTypeId();		
			
			subProductId = productDAO.getSubProductIdFromVComponentProduct(componentProductId);
			tPrdctTwrTuwSbprdctAstTypData = tProductTowerTUWSubProductAssetTypeRepository.validatePrdTwrSubPrdAstType(productTowerId, subProductId, assetTypeId);
			
			if(tPrdctTwrTuwSbprdctAstTypData == null){
				ngeException.throwException(NGEErrorCodes.INVALID_PRD_TWR_SUB_PRD_AST_TYPE, NGEErrorCodes.ERROR_TYPE,"Invalid Product Tower and Asset Type combination for the given Product",null);
				
			}			
		}		
	}
	
	public void validateAssetAndAttributeData(Tasset tAssetData,List<Attribute> assetAttribute, short productTowerId, boolean isUpdateFlag) throws AIGCIExceptionMsg{
		
		short assetAttributeId = 0;
		int assetTypeId = 0;
		List<TassetTypeAttribute> tassetTypeAttributedata = null;		
		AssetModel assetModel=null;
				
		for(int j=0;j<assetAttribute.size();j++){
			if(assetAttribute.get(j).getName().trim().length()!=0 || (assetAttribute.get(j).getName() != null)){
				String assetAttributeName=assetAttribute.get(j).getName();
				Tattribute TAttributeData= tAttributeRepository.findByAttributeName(assetAttributeName.toUpperCase());
				
				// Validation of Asset Type		
				assetAttributeId = TAttributeData.getAttributeId();
				assetTypeId = tAssetData.getTassetType().getAssetTypeId();
				tassetTypeAttributedata = tassetTypeAttributeRepository.validateAstTypeandAttribute(assetTypeId, assetAttributeId);
				
				if(tassetTypeAttributedata == null){
					List<Object> errorFieldList=new ArrayList<Object>();
		            errorFieldList.add(TAttributeData.getAttributeNm());
		            errorFieldList.add(tAssetData.getTassetType().getAssetTypeNm());
					ngeException.throwException(NGEErrorCodes.INVALID_ASSET_TYPE_AND_ATTRIBUTE, NGEErrorCodes.ERROR_TYPE,"Invalid Asset Type and Attribute combination", null);
		    	} 
		/*Aug 2018  Q3 Maintenance Release 2.12 -	To modify Asset screen to populate the relation between Make and Model attributes starts */	
				if(assetAttribute.get(j).getAction() != null && assetAttribute.get(j).getAction().value().equals(NGEConstants.ACTION_CREATE)){	
					if(assetAttributeName.toUpperCase().endsWith(NGEConstants.AssetAttributes.MAKE.toUpperCase())){
						if(assetModel == null){
							assetModel=new AssetModel();
						}
						assetModel.setMake(((assetAttribute.get(j).getAttributeValue() != null && assetAttribute.get(j).getAttributeValue().trim().length() != 0) ? assetAttribute.get(j).getAttributeValue().trim() :null));
					}else if(assetAttributeName.toUpperCase().endsWith(NGEConstants.AssetAttributes.MODEL.toUpperCase())){
						if(assetModel == null){
							assetModel=new AssetModel();
						}
						assetModel.setModel(((assetAttribute.get(j).getAttributeValue() != null && assetAttribute.get(j).getAttributeValue().trim().length() != 0) ? assetAttribute.get(j).getAttributeValue().trim() :null));
					}
				}
			}
		}		
    		
		if(assetModel != null && (assetModel.getMake() == null || assetModel.getModel() ==null )){
			ngeException.throwException(NGEErrorCodes.MAKE_MODEL_MANDATORY, NGEErrorCodes.ERROR_TYPE,"Both Make and Model are mandatory if either make or model are selected.", null);
		}
		/*Aug 2018  Q3 Maintenance Release 2.12 -	To modify Asset screen to populate the relation between Make and Model attributes ends */   
    }
	
	/**
	 * @author Dinesh Selvaraj
	 * @param assetType
	 * @param assetValue
	 * @param assetAttributeName
	 * @param assetAttributeValue
	 * @param tTransactionComponentData
	 * @param systemID
	 * @param createUserID
	 * @return
	 * @throws AIGCIExceptionMsg
	 * This method is used to insert component assets into TTRANSACTION_COMPONENT_ASSET Table. 
	 */
	public TtransactionComponentAsset insertTransactionComponentAssetData(Asset assetsData,Attributes assetAttributes,TtransactionComponent tTransactionComponentData, List<VcomponentProduct> vComponentProductData) throws AIGCIExceptionMsg {
		java.util.Date date= new java.util.Date();
		
		/*Sequencer Call*/
		String assetType=null;
		String assetValue=null;
		//int assetId=getAssetIdSequence();
		Set<TassetAttribute> tAssetAttributeSet = null;
		Tasset tAssetData = new Tasset();
		String segmentCode = NGEConstants.EMPTY_STRING;
		String subSegmentCode = NGEConstants.EMPTY_STRING;
		TproductTower productTowerData = null;	
		int componentProductId = 0;
		short productTowerId = 0;
		//List<Tasset> tAsset=tAssetRepository.findByAssetTypeAndValue(assetType, assetValue);
		TtransactionComponentAsset tTransactionComponentAssetData = new TtransactionComponentAsset();
		
		TtransactionComponentAssetPK tTransactionComponentAssetPKData=new TtransactionComponentAssetPK(); 
		
		assetType=assetsData.getType();
		assetValue=assetsData.getValue();
		
		segmentCode = vComponentProductData.get(0).getComponentSegmentCd();
		subSegmentCode = vComponentProductData.get(0).getComponentSubSegmentCd();
		productTowerData = productDAO.getProductTowerBySegmentandSubSegmentCd(segmentCode, subSegmentCode);
		productTowerId = productTowerData.getProductTowerId();
		componentProductId = vComponentProductData.get(0).getId().getComponentProductId();
		
			/*Set TASSET data using TASET_TYPE Table for the given asset type*/
			List<TassetType> tAssetTypeData=tAssetTypeRepository.findByAssetTypeNmIgnoreCase(assetType);
			
			if(tAssetTypeData != null && tAssetTypeData.size() > 0){
			validateAssetandAssetType(tAssetTypeData, productTowerId, componentProductId);		
			
				for(int i=0;i<tAssetTypeData.size();i++){
					TassetType assetTypes= tAssetTypeData.get(i);
					tAssetData=new Tasset();
					tAssetData.setAssetDs(assetValue);
					//tAssetData.setAssetId(assetId);
					tAssetData.setSystemId(NGESession.getSessionData().getSystem().getSystemId());
					tAssetData.setCreateTs(new Timestamp(date.getTime()));
					tAssetData.setCreateUserId(NGESession.getSessionData().getUserId());
					tAssetData.setTassetType(assetTypes);
					tAssetData=tAssetRepository.save(tAssetData);
					
					/*Set TTRANSACTION_COMPOENT_ASSET object */
					tTransactionComponentAssetPKData.setAssetId(tAssetData.getAssetId());
					tTransactionComponentAssetPKData.setTransactionComponentId(tTransactionComponentData.getTransactionComponentId());
					tTransactionComponentAssetData.setId(tTransactionComponentAssetPKData);
					tTransactionComponentAssetData.setSystemId(NGESession.getSessionData().getSystem().getSystemId());
					tTransactionComponentAssetData.setDeletedIn(NGEConstants.NO);
					tTransactionComponentAssetData.setCreateUserId(NGESession.getSessionData().getUserId());
					tTransactionComponentAssetData.setCreateTs(new Timestamp(date.getTime()));
					tTransactionComponentAssetData.setTasset(tAssetData);
					
					if(assetAttributes!=null){
						
						/*Insert every asset level attributes in the request*/
						tAssetAttributeSet=checkAndInsertAssetAttribute(tAssetData,assetAttributes, productTowerData);
						tAssetData.setTassetAttributes(tAssetAttributeSet);
					}
					tTransactionComponentAssetData.setTasset(tAssetData);													
				}
			}else{
				ngeException.throwException(NGEErrorCodes.ASSET_TYPE_REQUIRED, NGEErrorCodes.ERROR_TYPE,"Invalid Asset Type.  Given Asset Type is either blank or does not exist in NGE",null);
			}
		
		return tTransactionComponentAssetData;
	}
	
	/**
	 * @author Dinesh Selvaraj
	 * @param tAssetData
	 * @param assetAttributeName
	 * @param assetAttributeValue
	 * @param systemID
	 * @param createUserID
	 * @return
	 * @throws AIGCIExceptionMsg 
	 * This method is used to insert asset level attributes into TASSET_ATTRIBUTE
	 */
	public Set<TassetAttribute>  checkAndInsertAssetAttribute(Tasset tAssetData,Attributes assetAttributes, TproductTower productTowerData) throws AIGCIExceptionMsg
	{
		java.util.Date date= new java.util.Date();
		List<Attribute> assetAttribute=assetAttributes.getAttribute();
		TassetAttribute tAssetAttributeData=new TassetAttribute();
		TassetAttributePK tAssetAttributePKData=new TassetAttributePK(); 
		Set<TassetAttribute> tAssetAttributeSet=new HashSet<TassetAttribute>();
		short productTowerId = 0;
		productTowerId = productTowerData.getProductTowerId();
		boolean isUpdateFlag = false;
		HashMap<Short,Short> attributeSequenceMap = new HashMap<Short,Short>();
		
		validateAssetAndAttributeData(tAssetData, assetAttribute, productTowerId, isUpdateFlag);   
		
		/*Loops for every asset attribute names */
		for(int j=0;j<assetAttribute.size();j++){
			if(assetAttribute.get(j).getName().trim().length()!=0 || (assetAttribute.get(j).getName() != null)){
				String assetAttributeName=assetAttribute.get(j).getName();
				if(assetAttribute.get(j).getAttributeValue()==null){
	    			ngeException.throwException(NGEErrorCodes.ASSET_ATTRIB_VALUE_REQUIRED, NGEErrorCodes.ERROR_TYPE,"Invalid Asset Attribute value. Given Asset Attribute value  is either blank or does not exist in NGE", null);
	    		}else{
	    			Tattribute attributeData= tAttributeRepository.findByAttributeName(assetAttributeName.toUpperCase());
	    			
	    			    			
	    			short attributeIdSequence = 1;
					if(attributeSequenceMap.get(attributeData.getAttributeId()) != null)
					{
						attributeIdSequence = (short) (attributeSequenceMap.get(attributeData.getAttributeId()) + 1);
					}
					else
					{
						/*attributeIdSequence = tAssetAttributeRepository.findMaxAttributeSequence(tAssetData.getAssetId(),attributeData.getAttributeId());
						if(attributeIdSequence > 0)
						{
							attributeIdSequence = (short) (attributeIdSequence+1);
						}
						else{
							attributeIdSequence = 1;
						}*/
						attributeIdSequence = 1;
					}
					attributeSequenceMap.put(attributeData.getAttributeId(), attributeIdSequence);
					
	        			        		
	        			/*List<TassetAttribute> TAssetAttributeData=tAssetAttributeRepository.findByAssetAttributeIDandName(assetAttributeName,assetAttributeValue);*/
	        			tAssetAttributeData=new TassetAttribute();
	        			tAssetAttributePKData=new TassetAttributePK();
	        			tAssetAttributePKData.setAssetId(tAssetData.getAssetId());
	    				tAssetAttributePKData.setAttributeId(attributeData.getAttributeId());
	    				tAssetAttributePKData.setAttributeSqn(attributeIdSequence);
	    				tAssetAttributeData.setId(tAssetAttributePKData);
	    				tAssetAttributeData.setAttributeVal(assetAttribute.get(j).getAttributeValue());
	    				tAssetAttributeData.setTattribute(attributeData);
	    				tAssetAttributeData.setCreateTs(new Timestamp(date.getTime()));
	    				tAssetAttributeData.setCreateUserId(NGESession.getSessionData().getUserId());
	    				tAssetAttributeData.setSystemId(NGESession.getSessionData().getSystem().getSystemId());
	    				
	    				tAssetAttributeSet.add(tAssetAttributeData);
	    		}
			 }
	   }
		return  tAssetAttributeSet;
	}
	/**
	 * @author Dinesh Selvaraj
	 * @return
	 * This method is used to get max sequence for asset id
	 * @throws AIGCIExceptionMsg 
	 */
	/*public int getAssetIdSequence() throws AIGCIExceptionMsg{
        Integer assetIdSequenceValue = 0;
        int assetId =0;
	    HashMap<String, String> sequenceRequestMap = new HashMap<String, String>();
	    HashMap<String, Object> sequenceValueMap = new HashMap<String, Object>();
        sequenceRequestMap.put(NGEConstants.Sequence.ASSET_ID, "int");
        sequenceValueMap = sequenceNumberGeneration.getNextSequenceNumber(sequenceRequestMap);
        assetIdSequenceValue = Integer.parseInt(sequenceValueMap.get(NGEConstants.Sequence.ASSET_ID).toString());

        assetId=(Integer) sequenceValueMap.get(NGEConstants.Sequence.ASSET_ID);
        return assetId;
	}*/
		
}
