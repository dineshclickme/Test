package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-04-15T15:31:47.587+0530")
@StaticMetamodel(TprdctTwrTuwSbprdctAstTyp.class)
public class TprdctTwrTuwSbprdctAstTyp_ {
	public static volatile SingularAttribute<TprdctTwrTuwSbprdctAstTyp, TprdctTwrTuwSbprdctAstTypPK> id;
	public static volatile SingularAttribute<TprdctTwrTuwSbprdctAstTyp, Timestamp> createTs;
	public static volatile SingularAttribute<TprdctTwrTuwSbprdctAstTyp, String> createUserId;
	public static volatile SingularAttribute<TprdctTwrTuwSbprdctAstTyp, Timestamp> updateTs;
	public static volatile SingularAttribute<TprdctTwrTuwSbprdctAstTyp, String> updateUserId;
	public static volatile SingularAttribute<TprdctTwrTuwSbprdctAstTyp, TassetType> tassetType;
}
