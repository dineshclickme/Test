package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the TLEGACY_POLICY_SPLIT_RULE database table.
 * 
 */
@Embeddable
public class TlegacyPolicySplitRulePK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="SYSTEM_ID")
	private short systemId;

	@Column(name="DIVISION_NO")
	private short divisionNo;

    public TlegacyPolicySplitRulePK() {
    }
	public short getSystemId() {
		return this.systemId;
	}
	public void setSystemId(short systemId) {
		this.systemId = systemId;
	}
	public short getDivisionNo() {
		return this.divisionNo;
	}
	public void setDivisionNo(short divisionNo) {
		this.divisionNo = divisionNo;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof TlegacyPolicySplitRulePK)) {
			return false;
		}
		TlegacyPolicySplitRulePK castOther = (TlegacyPolicySplitRulePK)other;
		return 
			(this.systemId == castOther.systemId)
			&& (this.divisionNo == castOther.divisionNo);

    }
    
	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + ((int) this.systemId);
		hash = hash * prime + ((int) this.divisionNo);
		
		return hash;
    }
}