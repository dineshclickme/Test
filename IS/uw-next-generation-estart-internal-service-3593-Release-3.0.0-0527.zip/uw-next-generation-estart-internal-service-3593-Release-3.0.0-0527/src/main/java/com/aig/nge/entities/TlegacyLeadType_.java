package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SetAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-04-15T15:31:46.885+0530")
@StaticMetamodel(TlegacyLeadType.class)
public class TlegacyLeadType_ {
	public static volatile SingularAttribute<TlegacyLeadType, TlegacyLeadTypePK> id;
	public static volatile SingularAttribute<TlegacyLeadType, Timestamp> createTs;
	public static volatile SingularAttribute<TlegacyLeadType, String> createUserId;
	public static volatile SingularAttribute<TlegacyLeadType, String> leadTypeNm;
	public static volatile SingularAttribute<TlegacyLeadType, Timestamp> updateTs;
	public static volatile SingularAttribute<TlegacyLeadType, String> updateUserId;
	public static volatile SetAttribute<TlegacyLeadType, TlegacyLeadSubtype> tlegacyLeadSubtypes;
	public static volatile SingularAttribute<TlegacyLeadType, Tsource> tsource;
}
