package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the TLEGACY_PRODUCT_BUNDLING database table.
 * 
 */
@Embeddable
public class TlegacyProductBundlingPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="PRODUCT_CD")
	private String productCd;

	@Column(name="BUNDLED_PRODUCT_CD")
	private String bundledProductCd;

    public TlegacyProductBundlingPK() {
    }
	public String getProductCd() {
		return this.productCd;
	}
	public void setProductCd(String productCd) {
		this.productCd = productCd;
	}
	public String getBundledProductCd() {
		return this.bundledProductCd;
	}
	public void setBundledProductCd(String bundledProductCd) {
		this.bundledProductCd = bundledProductCd;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof TlegacyProductBundlingPK)) {
			return false;
		}
		TlegacyProductBundlingPK castOther = (TlegacyProductBundlingPK)other;
		return 
			this.productCd.equals(castOther.productCd)
			&& this.bundledProductCd.equals(castOther.bundledProductCd);

    }
    
	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.productCd.hashCode();
		if(null != this.bundledProductCd)
		hash = hash * prime + this.bundledProductCd.hashCode();
		
		return hash;
    }
}