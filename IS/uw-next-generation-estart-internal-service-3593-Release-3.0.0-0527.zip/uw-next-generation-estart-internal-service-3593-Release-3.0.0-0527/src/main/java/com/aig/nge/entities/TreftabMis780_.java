package com.aig.nge.entities;

import java.sql.Timestamp;
import java.util.Date;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-05-27T15:19:13.381+0530")
@StaticMetamodel(TreftabMis780.class)
public class TreftabMis780_ {
	public static volatile SingularAttribute<TreftabMis780, Short> mis780ArtsCoInd;
	public static volatile SingularAttribute<TreftabMis780, String> mis780AscoCode;
	public static volatile SingularAttribute<TreftabMis780, String> mis780AscoName;
	public static volatile SingularAttribute<TreftabMis780, Short> mis780CompCode;
	public static volatile SingularAttribute<TreftabMis780, String> mis780CompName;
	public static volatile SingularAttribute<TreftabMis780, Date> mis780EffDt;
	public static volatile SingularAttribute<TreftabMis780, Date> mis780ExpDt;
	public static volatile SingularAttribute<TreftabMis780, String> mis780Source;
	public static volatile SingularAttribute<TreftabMis780, String> mis780StateNm;
	public static volatile SingularAttribute<TreftabMis780, Timestamp> mis780UpdTmp;
	public static volatile SingularAttribute<TreftabMis780, String> mis780UpdUser;
	public static volatile SingularAttribute<TreftabMis780, Short> mis780ValidInd;
	public static volatile SingularAttribute<TreftabMis780, String> deletedIn;
}
