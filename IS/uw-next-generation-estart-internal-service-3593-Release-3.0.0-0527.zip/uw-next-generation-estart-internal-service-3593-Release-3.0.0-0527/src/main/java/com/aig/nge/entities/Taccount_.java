package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-02-19T16:13:02.749+0530")
@StaticMetamodel(Taccount.class)
public class Taccount_ {
	public static volatile SingularAttribute<Taccount, Integer> partyId;
	public static volatile SingularAttribute<Taccount, Timestamp> createTs;
	public static volatile SingularAttribute<Taccount, String> createUserId;
	public static volatile SingularAttribute<Taccount, String> organizationNm;
	public static volatile SingularAttribute<Taccount, Timestamp> updateTs;
	public static volatile SingularAttribute<Taccount, String> updateUserId;
	public static volatile SingularAttribute<Taccount, Tparty> tparty;
	public static volatile SingularAttribute<Taccount, String> multinationalIn;
}
