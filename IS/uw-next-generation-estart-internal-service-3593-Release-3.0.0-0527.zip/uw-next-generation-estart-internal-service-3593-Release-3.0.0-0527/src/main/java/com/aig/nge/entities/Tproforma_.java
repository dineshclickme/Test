package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SetAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-04-15T15:31:47.681+0530")
@StaticMetamodel(Tproforma.class)
public class Tproforma_ {
	public static volatile SingularAttribute<Tproforma, String> proformaCreditCd;
	public static volatile SingularAttribute<Tproforma, Timestamp> createTs;
	public static volatile SingularAttribute<Tproforma, String> createUserId;
	public static volatile SingularAttribute<Tproforma, String> proformaCreditDs;
	public static volatile SingularAttribute<Tproforma, Timestamp> updateTs;
	public static volatile SingularAttribute<Tproforma, String> updateUserId;
	public static volatile SetAttribute<Tproforma, TlegacySubmissionExtension> tlegacySubmissionExtensions;
}
