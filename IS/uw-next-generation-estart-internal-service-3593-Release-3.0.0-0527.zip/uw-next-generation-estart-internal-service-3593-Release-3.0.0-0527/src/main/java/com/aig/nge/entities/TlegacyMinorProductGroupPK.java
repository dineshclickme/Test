package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the TLEGACY_MINOR_PRODUCT_GROUP database table.
 * 
 */
@Embeddable
public class TlegacyMinorProductGroupPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="MJR_PRODUCT_GRP_CD")
	private short mjrProductGrpCd;

	@Column(name="MNR_PRODUCT_GRP_CD")
	private short mnrProductGrpCd;

    public TlegacyMinorProductGroupPK() {
    }
	public short getMjrProductGrpCd() {
		return this.mjrProductGrpCd;
	}
	public void setMjrProductGrpCd(short mjrProductGrpCd) {
		this.mjrProductGrpCd = mjrProductGrpCd;
	}
	public short getMnrProductGrpCd() {
		return this.mnrProductGrpCd;
	}
	public void setMnrProductGrpCd(short mnrProductGrpCd) {
		this.mnrProductGrpCd = mnrProductGrpCd;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof TlegacyMinorProductGroupPK)) {
			return false;
		}
		TlegacyMinorProductGroupPK castOther = (TlegacyMinorProductGroupPK)other;
		return 
			(this.mjrProductGrpCd == castOther.mjrProductGrpCd)
			&& (this.mnrProductGrpCd == castOther.mnrProductGrpCd);

    }
    
	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + ((int) this.mjrProductGrpCd);
		hash = hash * prime + ((int) this.mnrProductGrpCd);
		
		return hash;
    }
}