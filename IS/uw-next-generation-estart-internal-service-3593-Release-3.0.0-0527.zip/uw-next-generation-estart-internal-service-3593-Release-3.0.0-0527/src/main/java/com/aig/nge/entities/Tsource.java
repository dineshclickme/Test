package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Set;


/**
 * The persistent class for the TSOURCE database table.
 * 
 */
@Entity
public class Tsource implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="SOURCE_CD")
	private String sourceCd;

	@Column(name="CREATE_TS")
	private Timestamp createTs;

	@Column(name="CREATE_USER_ID")
	private String createUserId;

	@Column(name="SOURCE_ABR_CD")
	private String sourceAbrCd;

	@Column(name="SOURCE_NM")
	private String sourceNm;

	@Column(name="UPDATE_TS")
	private Timestamp updateTs;

	@Column(name="UPDATE_USER_ID")
	private String updateUserId;

	//bi-directional many-to-one association to TlegacyLeadSourceType
	@OneToMany(mappedBy="tsource")
	private Set<TlegacyLeadSourceType> tlegacyLeadSourceTypes;

	//bi-directional many-to-one association to TlegacyLeadType
	@OneToMany(mappedBy="tsource")
	private Set<TlegacyLeadType> tlegacyLeadTypes;

	//bi-directional many-to-one association to TlegacyProfitCenterProduct
	@OneToMany(mappedBy="tsource")
	private Set<TlegacyProfitCenterProduct> tlegacyProfitCenterProducts;

	//bi-directional many-to-one association to TlegacySourceMapping
	@OneToMany(mappedBy="tsource")
	private Set<TlegacySourceMapping> tlegacySourceMappings;

	//bi-directional many-to-one association to TseAlertSource
	@OneToMany(mappedBy="tsource")
	private Set<TseAlertSource> tseAlertSources;

    public Tsource() {
    }

	public String getSourceCd() {
		return this.sourceCd;
	}

	public void setSourceCd(String sourceCd) {
		this.sourceCd = sourceCd;
	}

	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public String getSourceAbrCd() {
		return this.sourceAbrCd;
	}

	public void setSourceAbrCd(String sourceAbrCd) {
		this.sourceAbrCd = sourceAbrCd;
	}

	public String getSourceNm() {
		return this.sourceNm;
	}

	public void setSourceNm(String sourceNm) {
		this.sourceNm = sourceNm;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public Set<TlegacyLeadSourceType> getTlegacyLeadSourceTypes() {
		return this.tlegacyLeadSourceTypes;
	}

	public void setTlegacyLeadSourceTypes(Set<TlegacyLeadSourceType> tlegacyLeadSourceTypes) {
		this.tlegacyLeadSourceTypes = tlegacyLeadSourceTypes;
	}
	
	public Set<TlegacyLeadType> getTlegacyLeadTypes() {
		return this.tlegacyLeadTypes;
	}

	public void setTlegacyLeadTypes(Set<TlegacyLeadType> tlegacyLeadTypes) {
		this.tlegacyLeadTypes = tlegacyLeadTypes;
	}
	
	public Set<TlegacyProfitCenterProduct> getTlegacyProfitCenterProducts() {
		return this.tlegacyProfitCenterProducts;
	}

	public void setTlegacyProfitCenterProducts(Set<TlegacyProfitCenterProduct> tlegacyProfitCenterProducts) {
		this.tlegacyProfitCenterProducts = tlegacyProfitCenterProducts;
	}
	
	public Set<TlegacySourceMapping> getTlegacySourceMappings() {
		return this.tlegacySourceMappings;
	}

	public void setTlegacySourceMappings(Set<TlegacySourceMapping> tlegacySourceMappings) {
		this.tlegacySourceMappings = tlegacySourceMappings;
	}
	
	public Set<TseAlertSource> getTseAlertSources() {
		return this.tseAlertSources;
	}

	public void setTseAlertSources(Set<TseAlertSource> tseAlertSources) {
		this.tseAlertSources = tseAlertSources;
	}
	
}