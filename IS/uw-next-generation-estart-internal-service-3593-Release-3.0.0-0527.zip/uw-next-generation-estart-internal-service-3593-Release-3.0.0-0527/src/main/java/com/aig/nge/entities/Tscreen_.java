package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SetAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-02-19T16:13:04.376+0530")
@StaticMetamodel(Tscreen.class)
public class Tscreen_ {
	public static volatile SingularAttribute<Tscreen, Short> screenId;
	public static volatile SingularAttribute<Tscreen, Timestamp> createTs;
	public static volatile SingularAttribute<Tscreen, String> createUserId;
	public static volatile SingularAttribute<Tscreen, String> screenDs;
	public static volatile SingularAttribute<Tscreen, String> screenNm;
	public static volatile SingularAttribute<Tscreen, Timestamp> updateTs;
	public static volatile SingularAttribute<Tscreen, String> updateUserId;
	public static volatile SetAttribute<Tscreen, TscreenField> tscreenFields;
}
