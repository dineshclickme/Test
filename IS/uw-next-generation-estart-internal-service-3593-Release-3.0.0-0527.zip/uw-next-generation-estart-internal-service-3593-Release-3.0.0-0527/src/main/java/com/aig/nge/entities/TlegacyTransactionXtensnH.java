package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;

import org.springframework.data.domain.Persistable;

import java.sql.Timestamp;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the TLEGACY_TRANSACTION_XTENSN_HS database table.
 * 
 */
@Entity
@Table(name="TLEGACY_TRANSACTION_XTENSN_HS")
public class TlegacyTransactionXtensnH implements Persistable<Serializable> {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private TlegacyTransactionXtensnHPK id;

	@Column(name="BUNDLE_ATTACHMENT_AM")
	private BigDecimal bundleAttachmentAm;

	@Column(name="BUNDLE_LIMIT_AM")
	private BigDecimal bundleLimitAm;

	@Column(name="BUNDLE_PART_OF_AM")
	private BigDecimal bundlePartOfAm;

	@Column(name="BUNDLE_PREMIUM_AM")
	private BigDecimal bundlePremiumAm;

	@Column(name="CARRIER_ID")
	private int carrierId;

	@Column(name="CREATE_TS")
	private Timestamp createTs;

	@Column(name="CREATE_USER_ID")
	private String createUserId;

	@Column(name="LEGACY_BUNDLED_COVG_TYPE_CD")
	private String legacyBundledCovgTypeCd;

	@Column(name="LOCAL_BUNDLE_ATTACHMENT_AM")
	private BigDecimal localBundleAttachmentAm;

	@Column(name="LOCAL_BUNDLE_LIMIT_AM")
	private BigDecimal localBundleLimitAm;

	@Column(name="LOCAL_BUNDLE_PART_OF_AM")
	private BigDecimal localBundlePartOfAm;

	@Column(name="LOCAL_BUNDLE_PREMIUM_AM")
	private BigDecimal localBundlePremiumAm;

	@Column(name="NON_RECURRING_IN")
	private String nonRecurringIn;

	@Column(name="PROFIT_CENTER_CD")
	private String profitCenterCd;

	@Column(name="PROFIT_UNIT_CD")
	private short profitUnitCd;

	@Column(name="RR_PRTCTV_CONT_NO")
	private int rrPrtctvContNo;

	@Column(name="SECTION_CD")
	private short sectionCd;

	@Column(name="SPECIAL_EVENT_NM")
	private String specialEventNm;

    @Temporal( TemporalType.DATE)
	@Column(name="UNDERWRITING_DT")
	private Date underwritingDt;

	@Column(name="UPDATE_TS")
	private Timestamp updateTs;

	@Column(name="UPDATE_USER_ID")
	private String updateUserId;

    public TlegacyTransactionXtensnH() {
    }

	public TlegacyTransactionXtensnHPK getId() {
		return this.id;
	}

	public void setId(TlegacyTransactionXtensnHPK id) {
		this.id = id;
	}
	
	public BigDecimal getBundleAttachmentAm() {
		return this.bundleAttachmentAm;
	}

	public void setBundleAttachmentAm(BigDecimal bundleAttachmentAm) {
		this.bundleAttachmentAm = bundleAttachmentAm;
	}

	public BigDecimal getBundleLimitAm() {
		return this.bundleLimitAm;
	}

	public void setBundleLimitAm(BigDecimal bundleLimitAm) {
		this.bundleLimitAm = bundleLimitAm;
	}

	public BigDecimal getBundlePartOfAm() {
		return this.bundlePartOfAm;
	}

	public void setBundlePartOfAm(BigDecimal bundlePartOfAm) {
		this.bundlePartOfAm = bundlePartOfAm;
	}

	public BigDecimal getBundlePremiumAm() {
		return this.bundlePremiumAm;
	}

	public void setBundlePremiumAm(BigDecimal bundlePremiumAm) {
		this.bundlePremiumAm = bundlePremiumAm;
	}

	public int getCarrierId() {
		return this.carrierId;
	}

	public void setCarrierId(int carrierId) {
		this.carrierId = carrierId;
	}

	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public String getLegacyBundledCovgTypeCd() {
		return this.legacyBundledCovgTypeCd;
	}

	public void setLegacyBundledCovgTypeCd(String legacyBundledCovgTypeCd) {
		this.legacyBundledCovgTypeCd = legacyBundledCovgTypeCd;
	}

	public BigDecimal getLocalBundleAttachmentAm() {
		return this.localBundleAttachmentAm;
	}

	public void setLocalBundleAttachmentAm(BigDecimal localBundleAttachmentAm) {
		this.localBundleAttachmentAm = localBundleAttachmentAm;
	}

	public BigDecimal getLocalBundleLimitAm() {
		return this.localBundleLimitAm;
	}

	public void setLocalBundleLimitAm(BigDecimal localBundleLimitAm) {
		this.localBundleLimitAm = localBundleLimitAm;
	}

	public BigDecimal getLocalBundlePartOfAm() {
		return this.localBundlePartOfAm;
	}

	public void setLocalBundlePartOfAm(BigDecimal localBundlePartOfAm) {
		this.localBundlePartOfAm = localBundlePartOfAm;
	}

	public BigDecimal getLocalBundlePremiumAm() {
		return this.localBundlePremiumAm;
	}

	public void setLocalBundlePremiumAm(BigDecimal localBundlePremiumAm) {
		this.localBundlePremiumAm = localBundlePremiumAm;
	}

	public String getNonRecurringIn() {
		return this.nonRecurringIn;
	}

	public void setNonRecurringIn(String nonRecurringIn) {
		this.nonRecurringIn = nonRecurringIn;
	}

	public String getProfitCenterCd() {
		return this.profitCenterCd;
	}

	public void setProfitCenterCd(String profitCenterCd) {
		this.profitCenterCd = profitCenterCd;
	}

	public short getProfitUnitCd() {
		return this.profitUnitCd;
	}

	public void setProfitUnitCd(short profitUnitCd) {
		this.profitUnitCd = profitUnitCd;
	}

	public int getRrPrtctvContNo() {
		return this.rrPrtctvContNo;
	}

	public void setRrPrtctvContNo(int rrPrtctvContNo) {
		this.rrPrtctvContNo = rrPrtctvContNo;
	}

	public short getSectionCd() {
		return this.sectionCd;
	}

	public void setSectionCd(short sectionCd) {
		this.sectionCd = sectionCd;
	}

	public String getSpecialEventNm() {
		return this.specialEventNm;
	}

	public void setSpecialEventNm(String specialEventNm) {
		this.specialEventNm = specialEventNm;
	}

	public Date getUnderwritingDt() {
		return this.underwritingDt;
	}

	public void setUnderwritingDt(Date underwritingDt) {
		this.underwritingDt = underwritingDt;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	@Override
	public boolean isNew() {
		// TODO Auto-generated method stub
		return true;
	}
}