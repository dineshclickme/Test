package com.aig.nge.entities;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-02-19T16:13:04.891+0530")
@StaticMetamodel(TtransactionCmpntXpsrLocPK.class)
public class TtransactionCmpntXpsrLocPK_ {
	public static volatile SingularAttribute<TtransactionCmpntXpsrLocPK, String> transactionComponentId;
	public static volatile SingularAttribute<TtransactionCmpntXpsrLocPK, Integer> geographicLocationId;
}
