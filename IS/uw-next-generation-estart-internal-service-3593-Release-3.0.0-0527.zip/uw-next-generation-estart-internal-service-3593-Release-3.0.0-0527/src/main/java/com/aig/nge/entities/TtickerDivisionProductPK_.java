package com.aig.nge.entities;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-09-11T14:03:54.145+0530")
@StaticMetamodel(TtickerDivisionProductPK.class)
public class TtickerDivisionProductPK_ {
	public static volatile SingularAttribute<TtickerDivisionProductPK, Short> feedId;
	public static volatile SingularAttribute<TtickerDivisionProductPK, Short> feedSqn;
}
