package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SetAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-04-15T15:31:46.854+0530")
@StaticMetamodel(TlegacyLeadSubtype.class)
public class TlegacyLeadSubtype_ {
	public static volatile SingularAttribute<TlegacyLeadSubtype, TlegacyLeadSubtypePK> id;
	public static volatile SingularAttribute<TlegacyLeadSubtype, Timestamp> createTs;
	public static volatile SingularAttribute<TlegacyLeadSubtype, String> createUserId;
	public static volatile SingularAttribute<TlegacyLeadSubtype, String> leadSubtypeNm;
	public static volatile SingularAttribute<TlegacyLeadSubtype, Timestamp> updateTs;
	public static volatile SingularAttribute<TlegacyLeadSubtype, String> updateUserId;
	public static volatile SingularAttribute<TlegacyLeadSubtype, TlegacyLeadType> tlegacyLeadType;
	public static volatile SetAttribute<TlegacyLeadSubtype, TlegacyProductLeadType> tlegacyProductLeadTypes;
}
