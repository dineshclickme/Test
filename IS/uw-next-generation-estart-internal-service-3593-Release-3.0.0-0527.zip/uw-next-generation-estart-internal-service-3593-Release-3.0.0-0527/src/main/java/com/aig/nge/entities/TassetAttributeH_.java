package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-03-02T12:10:24.561+0530")
@StaticMetamodel(TassetAttributeH.class)
public class TassetAttributeH_ {
	public static volatile SingularAttribute<TassetAttributeH, TassetAttributeHPK> id;
	public static volatile SingularAttribute<TassetAttributeH, String> attributeVal;
	public static volatile SingularAttribute<TassetAttributeH, Timestamp> createTs;
	public static volatile SingularAttribute<TassetAttributeH, String> createUserId;
	public static volatile SingularAttribute<TassetAttributeH, Short> systemId;
	public static volatile SingularAttribute<TassetAttributeH, String> updateUserId;
	public static volatile SingularAttribute<TassetAttributeH, Timestamp> updateTs;
}
