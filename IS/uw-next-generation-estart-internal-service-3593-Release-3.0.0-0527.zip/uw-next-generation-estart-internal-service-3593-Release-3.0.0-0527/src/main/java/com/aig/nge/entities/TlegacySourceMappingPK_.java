package com.aig.nge.entities;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-06-19T14:59:45.751+0530")
@StaticMetamodel(TlegacySourceMappingPK.class)
public class TlegacySourceMappingPK_ {
	public static volatile SingularAttribute<TlegacySourceMappingPK, String> sourceCd;
	public static volatile SingularAttribute<TlegacySourceMappingPK, String> legacyBranchNo;
}
