package com.aig.nge.entities;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-02-19T16:13:04.642+0530")
@StaticMetamodel(TsystemMethodPK.class)
public class TsystemMethodPK_ {
	public static volatile SingularAttribute<TsystemMethodPK, Short> systemId;
	public static volatile SingularAttribute<TsystemMethodPK, Short> methodId;
}
