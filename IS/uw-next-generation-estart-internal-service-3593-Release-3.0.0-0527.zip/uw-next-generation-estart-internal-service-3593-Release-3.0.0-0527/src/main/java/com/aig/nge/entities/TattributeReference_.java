package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SetAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-02-19T16:13:02.953+0530")
@StaticMetamodel(TattributeReference.class)
public class TattributeReference_ {
	public static volatile SingularAttribute<TattributeReference, Short> referenceId;
	public static volatile SingularAttribute<TattributeReference, Timestamp> createTs;
	public static volatile SingularAttribute<TattributeReference, String> createUserId;
	public static volatile SingularAttribute<TattributeReference, String> referenceNm;
	public static volatile SingularAttribute<TattributeReference, String> referenceVal;
	public static volatile SingularAttribute<TattributeReference, Timestamp> updateTs;
	public static volatile SingularAttribute<TattributeReference, String> updateUserId;
	public static volatile SingularAttribute<TattributeReference, TreferenceGroup> treferenceGroup;
	public static volatile SetAttribute<TattributeReference, TtableAttributeReference> ttableAttributeReferences;
	public static volatile SingularAttribute<TattributeReference, String> deletedIn;
	public static volatile SingularAttribute<TattributeReference, String> relatedReferenceNm;
}
