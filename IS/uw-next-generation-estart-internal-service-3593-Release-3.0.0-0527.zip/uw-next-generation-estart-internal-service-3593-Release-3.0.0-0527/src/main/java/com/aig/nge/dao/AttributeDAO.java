package com.aig.nge.dao;


import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.aig.nge.entities.Tattribute;
import com.aig.nge.entities.Tparty;
import com.aig.nge.entities.TpolicyAttribute;
import com.aig.nge.entities.TproductTowerAttribute;
import com.aig.nge.entities.TtableAttributeReference;
import com.aig.nge.entities.TtransactionProductAttribute;
import com.aig.nge.entities.TtransactionProductAttributePK;
import com.aig.nge.repository.TAttributeRepository;
import com.aig.nge.repository.TPolicyAttributeRepository;
import com.aig.nge.repository.TProductTowerAttributeRepository;
import com.aig.nge.repository.TTableAttributeReferenceRepository;
import com.aig.nge.repository.TTransactionProductAttributeRepository;
import com.aig.nge.utilities.AIGCIExceptionMsg;
import com.aig.nge.utilities.NGEConstants;
import com.aig.nge.utilities.NGEErrorCodes;
import com.aig.nge.utilities.NGESession;
import com.aig.nge.utilities.NGEValidations;



/**
 * @author Dinesh Selvaraj
 * This DAO class is used for attributes realted entries
 */
@Repository
public class AttributeDAO extends BaseDAO{
	
	
	@Autowired
	private TAttributeRepository attributeRepository; 
	
	
	
	@Autowired
	private TProductTowerAttributeRepository tProductTowerAttributeRepository; 
	
	@Autowired
	private TTransactionProductAttributeRepository tTransactionProductAttributeRepository; 
	
	@Autowired
	private TTableAttributeReferenceRepository tTableAttributeReferenceRepository; 
		
	@Autowired
	private TPolicyAttributeRepository policyAttributeRepository;
	@Autowired
	private PartyDAO partyDao;
	
	@Autowired
	private NGEValidations ngeValidations;
	
	
	
	/** 
	 * @author Dinesh Selvaraj
	 * @param attributeName
	 * @param tableName
	 * @return
	 * This method is used to get attributes by atribute name and Table name
	 */
	public Tattribute getAttributeIDByAttributeNameAndTableName(String attributeName, String tableName) {
	
	Tattribute tAttributeData=attributeRepository.findByAttributeName(attributeName.toUpperCase());
	
	return tAttributeData;
	}
	
	/**
	 * @author Dinesh Selvaraj
	 * @param componentProductID
	 * @param attribValue 
	 * @param tPartyData
	 * @param attributeID
	 * @param transactionId
	 * @param transactionVersionSqnShrt
	 * @param systemID
	 * @param createUserID
	 * This methos is used to save marketable product underwriterID
	 * @return 
	 * @throws AIGCIExceptionMsg 
	 */
	public TtransactionProductAttribute insertMarketableProductAttributes(String attributeName,int componentProductID,String attribValue, Tattribute tAttributeData, String transactionId,short transactionVersionSqnShrt, short attributeIdSequence) throws AIGCIExceptionMsg {
	
		java.util.Date date= new java.util.Date();
		/*To-DO check or validate underwriters(attributeValue) using CASL Tables MARKETABLE_PRODUCT_ATTRIBUTE_NOT_FOUND*/
		
		Tparty tPartyData = new Tparty();
		TtransactionProductAttributePK tTransactionProductAttributePKData=new TtransactionProductAttributePK();
		TtransactionProductAttribute tTransactionProductAttributeData=new TtransactionProductAttribute();
		
		List<TtransactionProductAttribute> marketableProductAttributes=null;
		
		/*Get max attribute sequence using getMaxAttributeSqn TTRANSACTION_PRODUCT_ATTRIBUTE Table for Marketable Product Attributes*/
		marketableProductAttributes=tTransactionProductAttributeRepository.getMarketableProductAttributes(transactionId, transactionVersionSqnShrt, tAttributeData.getAttributeId(),componentProductID);
		
		/*If attribute name equals to Underwriter*/
		if(NGEConstants.PartyType.UNDERWRITER.equalsIgnoreCase(attributeName)){
			
			// Validate the underwriter
			ngeValidations.validateUnderwriterId(attribValue);
			
			tPartyData=partyDao.getUnderwriterParty(attribValue,attributeName);
			
			if(tPartyData==null){
				/*tPartyData=partyDao.createParty(attribValue,atributeName,createUserID);*/
				ngeException.throwException(NGEErrorCodes.NO_MKT_UNDERWRITERS_FOUND,NGEErrorCodes.ERROR_TYPE , "Underwriters not found for marketable product", null);
			 }
			
			if(marketableProductAttributes !=null && marketableProductAttributes.size()>0){
				 if(marketableProductAttributes.get(0).getAttributeVal()!=null){
					 
					 if(tPartyData != null && (tPartyData.getPartyId())!= (Integer.parseInt(marketableProductAttributes.get(0).getAttributeVal()))){
						 
						 // Exception validation need to be bypassed for legacy consumers alone to support legacy behavior
						if(NGESession.getSessionData().getClientId() != null){
							if(!NGESession.getSessionData().getClientId().equalsIgnoreCase(NGEConstants.LEGACY_CONSUMERS)){
								ngeException.throwException(NGEErrorCodes.UNDERWRITER_ALREADY_EXISTS,NGEErrorCodes.ERROR_TYPE, "Given Underwriter already available  in NGE", null);
							}
						}
						else{
							ngeException.throwException(NGEErrorCodes.UNDERWRITER_ALREADY_EXISTS,NGEErrorCodes.ERROR_TYPE, "Given Underwriter already available  in NGE", null);
						}							 
					 }
				 }
			 }
			 
			 
				 tTransactionProductAttributePKData.setAttributeSqn((short)1);
				 tTransactionProductAttributeData.setAttributeVal(String.valueOf(tPartyData.getPartyId()));
			 
			 
		}
		/*If attribute name other than underwriter*/
		else{
			
			tTransactionProductAttributePKData.setAttributeSqn(attributeIdSequence);
			tTransactionProductAttributeData.setAttributeVal(attribValue);
		}
	
		tTransactionProductAttributePKData.setTransactionId(transactionId);
		tTransactionProductAttributePKData.setVersionSqn(transactionVersionSqnShrt);
		tTransactionProductAttributePKData.setProductId(componentProductID);
		tTransactionProductAttributePKData.setAttributeId(tAttributeData.getAttributeId());
		tTransactionProductAttributeData.setId(tTransactionProductAttributePKData);
		tTransactionProductAttributeData.setTattribute(tAttributeData);
		tTransactionProductAttributeData.setSystemId(NGESession.getSessionData().getSystem().getSystemId());
		tTransactionProductAttributeData.setDeletedIn(NGEConstants.NO);
		tTransactionProductAttributeData.setCreateUserId(NGESession.getSessionData().getUserId());
		tTransactionProductAttributeData.setCreateTs(new Timestamp(date.getTime()));
		return tTransactionProductAttributeData;
	}
	
	/**
	 * @author Dinesh Selvaraj
	 * @param attributeName
	 * @param attributeValue
	 * @param towerID
	 * @param attributesCount
	 * @throws AIGCIExceptionMsg
	 * This method is used to check the attributes mandatory or not , 
	 * having list of values or not comparing TProduct Tower Attribute Table 
	 */
	public void checkAttributes(String attributeName,String attributeValue,short towerID) throws AIGCIExceptionMsg {
		 List<TproductTowerAttribute>  tProductTowerAttributeData;
		 Tattribute tAttributeData=null;
		 short attributeID=0;
		 tAttributeData =attributeRepository.findByAttributeName(attributeName.toUpperCase());
		 if(tAttributeData!=null){
		 attributeID=tAttributeData.getAttributeId(); 
		 }
		 tProductTowerAttributeData=tProductTowerAttributeRepository.findByAttributeNameAndProdTowerID(attributeID,towerID);
		if(tProductTowerAttributeData!=null){
		 if(tProductTowerAttributeData.get(0).getMandatoryIn().equalsIgnoreCase(NGEConstants.YES))
		 {
			 if(attributeValue==null ||  attributeValue.trim().length()==0){
				 List<Object> errorFieldList=new ArrayList<Object>();		           
				 errorFieldList.add(attributeName);
				 ngeException.throwException(NGEErrorCodes.ATTRIBUTE_VALUES_LIST_REQUIRED,NGEErrorCodes.ERROR_TYPE, "Attribute value is either Blank or Invalid", errorFieldList);
			 }
		 }
		 if(tProductTowerAttributeData.get(0).getAllowMultipleIn().equalsIgnoreCase(NGEConstants.YES)){
			/*if(attributesCount < 1){
				List<Object> errorFieldList=new ArrayList<Object>();		           
				errorFieldList.add(attributeName);
				ngeException.throwException(NGEErrorCodes.ATTRIBUTE_VALUES_LIST_REQUIRED,NGEErrorCodes.ERROR_TYPE, "Attribute values must be list", errorFieldList);
			}*/
		 }
		}
		else{
			List<Object> errorFieldList=new ArrayList<Object>();		           
			errorFieldList.add(attributeName);
			ngeException.throwException(NGEErrorCodes.INVALID_ATTRIBUTEID_PRODUCT_TOWER, NGEErrorCodes.ERROR_TYPE, "Attributes not found ", errorFieldList);
		}
	}
	/**
	 * @author Dinesh Selvaraj
	 * @param attributeName
	 * @return
	 * @throws AIGCIExceptionMsg
	 * This method is used to get attribute data through attribute name
	 */
	public Tattribute findByAttributeName(String attributeName) throws AIGCIExceptionMsg{
		 Tattribute tAttributeData=null;
		 tAttributeData =attributeRepository.findByAttributeName(attributeName.toUpperCase());
		 if(tAttributeData==null){
			 List<Object> errorFieldList=new ArrayList<Object>();		           
			 errorFieldList.add(attributeName);
			 ngeException.throwException(NGEErrorCodes.INVALID_ATTRIBUTEID, NGEErrorCodes.ERROR_TYPE, "Attributes not found ", errorFieldList);
		 }
		 return tAttributeData;
	}

	/**
	 * @author Dinesh Selvaraj
	 * @param productTowerID
	 * @return
	 * @throws AIGCIExceptionMsg
	 * This methosis used to find mandatory attributes
	 */
	public 	List<TproductTowerAttribute>  findMandatoryAttributesByAttributeNameAndProdTowerID(short productTowerID) throws AIGCIExceptionMsg{
		List<TproductTowerAttribute>  tProductTowerAttributeData=null; 
		tProductTowerAttributeData =tProductTowerAttributeRepository.findMandatoryAttributesByAttributeNameAndProdTowerID(productTowerID);
		/* if(tProductTowerAttributeData==null || tProductTowerAttributeData.size()==0 ){
			 ngeException.throwException(NGEErrorCodes.ATTRIBUTES_NOT_FOUND, NGEErrorCodes.ERROR_TYPE, "Attributes not found ", null);
		 }*/
		 return tProductTowerAttributeData;
	}
	/**
	 * @author Dinesh Selvaraj
	 * @param transactionId
	 * @param versionSqn
	 * @param attributeID
	 * @param marketableProductDetailID
	 * @return
	 * @throws AIGCIExceptionMsg
	 * This method is used to get transaction product attribute data
	 */
	public 	TtransactionProductAttribute  getTransactionProductAttributeData(String transactionId, short versionSqn, short attributeID, int marketableProductDetailID) throws AIGCIExceptionMsg{
		TtransactionProductAttribute  tTransactionProductAttributeData=null; 
		tTransactionProductAttributeData =tTransactionProductAttributeRepository.getTransactionProductAttributes(transactionId, versionSqn, attributeID, marketableProductDetailID);
		 if(tTransactionProductAttributeData==null){
			 String atributesName = "";
			 Tattribute attribute = attributeRepository.findOne(attributeID);
			 if(attribute !=null)
			 {
				 atributesName = attribute.getAttributeNm();
			 }
			 else
			 {
				 atributesName = String.valueOf(attributeID);
			 }
			 List<Object> errorFieldList=new ArrayList<Object>();		           
			 errorFieldList.add(atributesName);
			 ngeException.throwException(NGEErrorCodes.INVALID_ATTRIBUTEID_TXNID_VERSION_MKTPRD, NGEErrorCodes.ERROR_TYPE, "Attributes not found ", null);
		 }
		 return tTransactionProductAttributeData;
	}
	
	/* PI5 2020 - Marketable product attribute copy to renewal transaction start */
	public 	TtransactionProductAttribute  checkTransactionProductAttributeData(String transactionId, short versionSqn, short attributeID, int marketableProductDetailID) throws AIGCIExceptionMsg{
		return tTransactionProductAttributeRepository.getTransactionProductAttributes(transactionId, versionSqn, attributeID, marketableProductDetailID);
	}
	/* PI5 2020 - Marketable product attribute copy to renewal transaction end */
	
	public int updateUwInTransactionProductAtrbt(String fromUwId, String toUwId, short attributeID, String userId, Timestamp currentTs) {		
		int productCount = tTransactionProductAttributeRepository.changeUwInTransactionProductAtrbt(fromUwId, toUwId, attributeID, userId, currentTs);
		return productCount;		
	}
	
	/**
	 * @author Dinesh Selvaraj
	 * @param tTransactionProductAttributeList
	 * @return
	 * This method is used to save transaction product attribute data
	 */
	public void savetTransactionProductAttribute(List<TtransactionProductAttribute> tTransactionProductAttributeList){
		for(TtransactionProductAttribute transactionProductAttributeData : tTransactionProductAttributeList){
			List<TtransactionProductAttribute> existingTransactionProductAttributeList=tTransactionProductAttributeRepository.getMarketableProductAttributes(transactionProductAttributeData.getId().getTransactionId(),transactionProductAttributeData.getId().getVersionSqn(),transactionProductAttributeData.getId().getAttributeId(),transactionProductAttributeData.getId().getProductId());
			if( existingTransactionProductAttributeList!=null && existingTransactionProductAttributeList.size()!=0){
				for(int i=0;i<existingTransactionProductAttributeList.size();i++){//medium low issue fixes-2020 starts
//						if(existingTransactionProductAttributeList.get(i).getAttributeVal().equalsIgnoreCase(transactionProductAttributeData.getAttributeVal()) && existingTransactionProductAttributeList.get(i).getId().getTransactionId()== transactionProductAttributeData.getId().getTransactionId() &&
//						existingTransactionProductAttributeList.get(i).getId().getVersionSqn()==transactionProductAttributeData.getId().getVersionSqn() && existingTransactionProductAttributeList.get(i).getId().getProductId()==transactionProductAttributeData.getId().getProductId()){
							if(existingTransactionProductAttributeList.get(i).getAttributeVal().equalsIgnoreCase(transactionProductAttributeData.getAttributeVal()) && existingTransactionProductAttributeList.get(i).getId().getTransactionId().equals(transactionProductAttributeData.getId().getTransactionId()) &&
									existingTransactionProductAttributeList.get(i).getId().getVersionSqn()==transactionProductAttributeData.getId().getVersionSqn() && existingTransactionProductAttributeList.get(i).getId().getProductId()==transactionProductAttributeData.getId().getProductId()){//medium low issue fixes-2020 ends
										break;

					}
					tTransactionProductAttributeRepository.saveAndFlush(transactionProductAttributeData);
				}
			}
			else{
				tTransactionProductAttributeRepository.saveAndFlush(transactionProductAttributeData);
			}
		}
	}
	
	public void deletePolicyAttribute(List<TpolicyAttribute> policyAttrToDelete)
	{
		policyAttributeRepository.deleteInBatch(policyAttrToDelete);
	}
	
	public short getMaxAttributeSqn(short attributeId, int policyId)
	{
		Short maxVal = 0;
		maxVal = policyAttributeRepository.findMaxAttributeSequence(policyId, attributeId);
		if(maxVal == null)
		{
			maxVal=0;
		}
		return maxVal;
	}

	public TpolicyAttribute savePolicyAttribute(TpolicyAttribute policyAttribute)
	{
		TpolicyAttribute policyAttributeResult = null;
		policyAttributeResult = policyAttributeRepository.save(policyAttribute);
		return policyAttributeResult;
	}
	
	public Tattribute getAttribute(String attributeName) throws AIGCIExceptionMsg{
		Tattribute attribute = null;
		attribute = attributeRepository.findByAttributeName(attributeName.toUpperCase());
		return attribute;
	}

	/**
	 * @author Padma E
	 * @param attributeId
	 * @param policyId
	 * @return
	 * this methos is used to get policy attribute list in tpolicy_attribute
	 */
	public List<TpolicyAttribute> getPolicyAttribute(short attributeId, int policyId) {
		// TODO Auto-generated method stub
		List<TpolicyAttribute> policyAttributes = null;
		policyAttributes = policyAttributeRepository.findByPolicyIdAndAttributeId(policyId, attributeId);
		return policyAttributes;
	}

		
	public List<TtableAttributeReference> getReferenceDataByTabeIdAndAttributeName(short tableId,String attributeName) {
		List<TtableAttributeReference> tTableAttributeReferenceList = null;
		tTableAttributeReferenceList = tTableAttributeReferenceRepository.getReferenceDataByTabeIdAndAttributeName(tableId, attributeName);
		return tTableAttributeReferenceList;
	}
	
	public List<TtableAttributeReference> getReferenceDataByReferenceValue(short tableId,String attributeName,String attributeValue) {
		List<TtableAttributeReference> tTableAttributeReferenceValueList = null;
		tTableAttributeReferenceValueList = tTableAttributeReferenceRepository.getReferenceDataByReferenceValue(tableId, attributeName , attributeValue);
		return tTableAttributeReferenceValueList;
	}

	public void savetTransactionProductAttribute(
			TtransactionProductAttribute tTransactionProductAttributeData) {
		tTransactionProductAttributeRepository.save(tTransactionProductAttributeData);
		
	}
	
	public List<Tattribute> findByAttributeNames (List<String> attributeNmList) throws AIGCIExceptionMsg{
		List<Tattribute> attributeList = new ArrayList<Tattribute>();
		Tattribute attribute = null;
		
		for(String attributeNm : attributeNmList)
		{
			attribute = attributeRepository.findByAttributeName(attributeNm.toUpperCase());
			if(attribute == null){
				ngeException.throwException(NGEErrorCodes.ATTRIBUTE_DATA_NOT_AVAIL, NGEErrorCodes.ERROR_TYPE, null, null);
			}
			attributeList.add(attribute);
		}
		
		if(attributeList.isEmpty()){
			ngeException.throwException(NGEErrorCodes.ATTRIBUTE_DATA_NOT_AVAIL, NGEErrorCodes.ERROR_TYPE, null, null);
		}
		else if(attributeNmList.size() != attributeList.size()){
			ngeException.throwException(NGEErrorCodes.ATTRIBUTE_DATA_NOT_AVAIL, NGEErrorCodes.ERROR_TYPE, null, null);
		}
		return attributeList;
	}
}