package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-02-24T11:59:49.836+0530")
@StaticMetamodel(TpartyAction.class)
public class TpartyAction_ {
	public static volatile SingularAttribute<TpartyAction, TpartyActionPK> id;
	public static volatile SingularAttribute<TpartyAction, Timestamp> createTs;
	public static volatile SingularAttribute<TpartyAction, String> createUserId;
	public static volatile SingularAttribute<TpartyAction, String> deletedIn;
	public static volatile SingularAttribute<TpartyAction, Timestamp> updateTs;
	public static volatile SingularAttribute<TpartyAction, String> updateUserId;
	public static volatile SingularAttribute<TpartyAction, Taction> taction;
	public static volatile SingularAttribute<TpartyAction, Tlocation> tlocation;
	public static volatile SingularAttribute<TpartyAction, Tparty> tparty;
	public static volatile SingularAttribute<TpartyAction, Trole> trole;
	public static volatile SingularAttribute<TpartyAction, Tsystem> tsystem;
	public static volatile SingularAttribute<TpartyAction, TproductTower> tproductTower;
	public static volatile SingularAttribute<TpartyAction, String> priorityNo;

}
