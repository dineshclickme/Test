package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SetAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-02-19T16:13:03.524+0530")
@StaticMetamodel(Tlanguage.class)
public class Tlanguage_ {
	public static volatile SingularAttribute<Tlanguage, Short> languageId;
	public static volatile SingularAttribute<Tlanguage, Timestamp> createTs;
	public static volatile SingularAttribute<Tlanguage, String> createUserId;
	public static volatile SingularAttribute<Tlanguage, String> languageDs;
	public static volatile SingularAttribute<Tlanguage, String> languageNm;
	public static volatile SingularAttribute<Tlanguage, Timestamp> updateTs;
	public static volatile SingularAttribute<Tlanguage, String> updateUserId;
	public static volatile SetAttribute<Tlanguage, ThelpLanguage> thelpLanguages;
	public static volatile SetAttribute<Tlanguage, TuserPrefernce> tuserPrefernces;
	public static volatile SetAttribute<Tlanguage, TerrorLanguage> terrorLanguages;
	public static volatile SetAttribute<Tlanguage, TfieldLanguage> tfieldLanguages;
}
