package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the TMARKETABLE_PRODUCT_LOCATION database table.
 * 
 */
@Embeddable
public class TmarketableProductLocationPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="MARKETABLE_PRODUCT_ID")
	private int marketableProductId;

	@Column(name="GEOGRAPHIC_LOCATION_ID")
	private int geographicLocationId;

    public TmarketableProductLocationPK() {
    }
	public int getMarketableProductId() {
		return this.marketableProductId;
	}
	public void setMarketableProductId(int marketableProductId) {
		this.marketableProductId = marketableProductId;
	}
	public int getGeographicLocationId() {
		return this.geographicLocationId;
	}
	public void setGeographicLocationId(int geographicLocationId) {
		this.geographicLocationId = geographicLocationId;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof TmarketableProductLocationPK)) {
			return false;
		}
		TmarketableProductLocationPK castOther = (TmarketableProductLocationPK)other;
		return 
			(this.marketableProductId == castOther.marketableProductId)
			&& (this.geographicLocationId == castOther.geographicLocationId);

    }
    
	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.marketableProductId;
		hash = hash * prime + this.geographicLocationId;
		
		return hash;
    }
}