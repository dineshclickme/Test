package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the TLEGACY_WIP_QUOTE database table.
 * 
 */
@Embeddable
public class TlegacyWipQuotePK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="TRANSACTION_COMPONENT_ID")
	private String transactionComponentId;

	@Column(name="WIP_ID")
	private String wipId;

	@Column(name="QUOTE_SQN")
	private short quoteSqn;

    public TlegacyWipQuotePK() {
    }
	public String getTransactionComponentId() {
		return this.transactionComponentId;
	}
	public void setTransactionComponentId(String transactionComponentId) {
		this.transactionComponentId = transactionComponentId;
	}
	public String getWipId() {
		return this.wipId;
	}
	public void setWipId(String wipId) {
		this.wipId = wipId;
	}
	public short getQuoteSqn() {
		return this.quoteSqn;
	}
	public void setQuoteSqn(short quoteSqn) {
		this.quoteSqn = quoteSqn;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof TlegacyWipQuotePK)) {
			return false;
		}
		TlegacyWipQuotePK castOther = (TlegacyWipQuotePK)other;
		return 
			this.transactionComponentId.equals(castOther.transactionComponentId)
			&& this.wipId.equals(castOther.wipId)
			&& (this.quoteSqn == castOther.quoteSqn);

    }
    
	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.transactionComponentId.hashCode();
		hash = hash * prime + this.wipId.hashCode();
		hash = hash * prime + ((int) this.quoteSqn);
		
		return hash;
    }
}