package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SetAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-04-15T15:31:46.823+0530")
@StaticMetamodel(TlegacyLeadSourceType.class)
public class TlegacyLeadSourceType_ {
	public static volatile SingularAttribute<TlegacyLeadSourceType, TlegacyLeadSourceTypePK> id;
	public static volatile SingularAttribute<TlegacyLeadSourceType, Timestamp> createTs;
	public static volatile SingularAttribute<TlegacyLeadSourceType, String> createUserId;
	public static volatile SingularAttribute<TlegacyLeadSourceType, String> leadSourceTypeNm;
	public static volatile SingularAttribute<TlegacyLeadSourceType, Timestamp> updateTs;
	public static volatile SingularAttribute<TlegacyLeadSourceType, String> updateUserId;
	public static volatile SingularAttribute<TlegacyLeadSourceType, Tsource> tsource;
	public static volatile SetAttribute<TlegacyLeadSourceType, TlegacyProductLeadSrcTyp> tlegacyProductLeadSrcTyps;
}
