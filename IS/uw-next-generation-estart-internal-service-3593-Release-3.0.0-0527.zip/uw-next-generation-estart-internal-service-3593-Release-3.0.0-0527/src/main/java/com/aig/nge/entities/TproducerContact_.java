package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-02-19T16:13:03.860+0530")
@StaticMetamodel(TproducerContact.class)
public class TproducerContact_ {
	public static volatile SingularAttribute<TproducerContact, TproducerContactPK> id;
	public static volatile SingularAttribute<TproducerContact, String> contactTx;
	public static volatile SingularAttribute<TproducerContact, Timestamp> createTs;
	public static volatile SingularAttribute<TproducerContact, String> createUserId;
	public static volatile SingularAttribute<TproducerContact, String> emailAddressTx;
	public static volatile SingularAttribute<TproducerContact, String> firstNm;
	public static volatile SingularAttribute<TproducerContact, String> lastNm;
	public static volatile SingularAttribute<TproducerContact, String> phoneNo;
	public static volatile SingularAttribute<TproducerContact, Timestamp> updateTs;
	public static volatile SingularAttribute<TproducerContact, String> updateUserId;
	public static volatile SingularAttribute<TproducerContact, Ttransaction> ttransaction;
}
