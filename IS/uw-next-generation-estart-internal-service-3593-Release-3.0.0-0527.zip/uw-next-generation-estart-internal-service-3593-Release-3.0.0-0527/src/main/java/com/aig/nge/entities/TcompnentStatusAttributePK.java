package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the TCOMPNENT_STATUS_ATTRIBUTE database table.
 * 
 */
@Embeddable
public class TcompnentStatusAttributePK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="TRANSACTION_COMPONENT_ID")
	private String transactionComponentId;

	@Column(name="STATUS_ID")
	private short statusId;

	@Column(name="ATTRIBUTE_ID")
	private short attributeId;

	@Column(name="ATTRIBUTE_SQN")
	private short attributeSqn;

    public TcompnentStatusAttributePK() {
    }
	public String getTransactionComponentId() {
		return this.transactionComponentId;
	}
	public void setTransactionComponentId(String transactionComponentId) {
		this.transactionComponentId = transactionComponentId;
	}
	public short getStatusId() {
		return this.statusId;
	}
	public void setStatusId(short statusId) {
		this.statusId = statusId;
	}
	public short getAttributeId() {
		return this.attributeId;
	}
	public void setAttributeId(short attributeId) {
		this.attributeId = attributeId;
	}
	public short getAttributeSqn() {
		return this.attributeSqn;
	}
	public void setAttributeSqn(short attributeSqn) {
		this.attributeSqn = attributeSqn;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof TcompnentStatusAttributePK)) {
			return false;
		}
		TcompnentStatusAttributePK castOther = (TcompnentStatusAttributePK)other;
		return 
			this.transactionComponentId.equals(castOther.transactionComponentId)
			&& (this.statusId == castOther.statusId)
			&& (this.attributeId == castOther.attributeId)
			&& (this.attributeSqn == castOther.attributeSqn);

    }
    
	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.transactionComponentId.hashCode();
		hash = hash * prime + ((int) this.statusId);
		hash = hash * prime + ((int) this.attributeId);
		hash = hash * prime + ((int) this.attributeSqn);
		
		return hash;
    }
}