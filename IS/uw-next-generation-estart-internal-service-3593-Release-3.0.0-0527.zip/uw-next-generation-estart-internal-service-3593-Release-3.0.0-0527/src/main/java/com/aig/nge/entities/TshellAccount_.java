package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-02-19T16:13:04.442+0530")
@StaticMetamodel(TshellAccount.class)
public class TshellAccount_ {
	public static volatile SingularAttribute<TshellAccount, Integer> partyId;
	public static volatile SingularAttribute<TshellAccount, Timestamp> createTs;
	public static volatile SingularAttribute<TshellAccount, String> createUserId;
	public static volatile SingularAttribute<TshellAccount, String> organizationNm;
	public static volatile SingularAttribute<TshellAccount, Timestamp> updateTs;
	public static volatile SingularAttribute<TshellAccount, String> updateUserId;
	public static volatile SingularAttribute<TshellAccount, Tparty> tparty;
	public static volatile SingularAttribute<TshellAccount, String> multinationalIn;
}
