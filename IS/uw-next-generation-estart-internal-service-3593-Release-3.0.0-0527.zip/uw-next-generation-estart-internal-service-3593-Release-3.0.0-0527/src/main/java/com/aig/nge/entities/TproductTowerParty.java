package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the TPRODUCT_TOWER_PARTY database table.
 * 
 */
@Entity
@Table(name="TPRODUCT_TOWER_PARTY")
public class TproductTowerParty implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private TproductTowerPartyPK id;

	@Column(name="CREATE_TS")
	private Timestamp createTs;

	@Column(name="CREATE_USER_ID")
	private String createUserId;

	@Column(name="UPDATE_TS")
	private Timestamp updateTs;

	@Column(name="UPDATE_USER_ID")
	private String updateUserId;

	//bi-directional many-to-one association to Tparty
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="PARTY_ID")
	private Tparty tparty;

	//bi-directional many-to-one association to TproductTower
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="PRODUCT_TOWER_ID")
	private TproductTower tproductTower;

	//bi-directional many-to-one association to Trole
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="ROLE_ID")
	private Trole trole;

    public TproductTowerParty() {
    }

	public TproductTowerPartyPK getId() {
		return this.id;
	}

	public void setId(TproductTowerPartyPK id) {
		this.id = id;
	}
	
	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public Tparty getTparty() {
		return this.tparty;
	}

	public void setTparty(Tparty tparty) {
		this.tparty = tparty;
	}
	
	public TproductTower getTproductTower() {
		return this.tproductTower;
	}

	public void setTproductTower(TproductTower tproductTower) {
		this.tproductTower = tproductTower;
	}
	
	public Trole getTrole() {
		return this.trole;
	}

	public void setTrole(Trole trole) {
		this.trole = trole;
	}
	
}