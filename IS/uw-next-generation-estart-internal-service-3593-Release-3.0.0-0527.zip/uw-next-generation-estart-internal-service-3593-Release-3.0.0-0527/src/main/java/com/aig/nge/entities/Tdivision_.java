package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SetAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-02-19T16:13:03.297+0530")
@StaticMetamodel(Tdivision.class)
public class Tdivision_ {
	public static volatile SingularAttribute<Tdivision, Short> divisionNo;
	public static volatile SingularAttribute<Tdivision, Timestamp> createTs;
	public static volatile SingularAttribute<Tdivision, String> createUserId;
	public static volatile SingularAttribute<Tdivision, String> divisionNm;
	public static volatile SingularAttribute<Tdivision, Timestamp> updateTs;
	public static volatile SingularAttribute<Tdivision, String> updateUserId;
	public static volatile SetAttribute<Tdivision, TprdctTwrTuwSubPrdctDiv> tprdctTwrTuwSubPrdctDivs;
	public static volatile SetAttribute<Tdivision, TproductDsp> tproductDsps;

	public static volatile SetAttribute<Tdivision, TproductTowerDivision> tproductTowerDivisions;
	public static volatile SetAttribute<Tdivision, TtickerDivisionProduct> ttickerDivisionProducts;
	public static volatile SetAttribute<Tdivision, TlegacyPolicySplitRule> tlegacyPolicySplitRules;
}
