package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-02-19T16:13:02.801+0530")
@StaticMetamodel(TassetAttribute.class)
public class TassetAttribute_ {
	public static volatile SingularAttribute<TassetAttribute, TassetAttributePK> id;
	public static volatile SingularAttribute<TassetAttribute, String> attributeVal;
	public static volatile SingularAttribute<TassetAttribute, Timestamp> createTs;
	public static volatile SingularAttribute<TassetAttribute, String> createUserId;
	public static volatile SingularAttribute<TassetAttribute, Short> systemId;
	public static volatile SingularAttribute<TassetAttribute, Timestamp> updateTs;
	public static volatile SingularAttribute<TassetAttribute, String> updateUserId;
	public static volatile SingularAttribute<TassetAttribute, Tasset> tasset;
	public static volatile SingularAttribute<TassetAttribute, Tattribute> tattribute;
}
