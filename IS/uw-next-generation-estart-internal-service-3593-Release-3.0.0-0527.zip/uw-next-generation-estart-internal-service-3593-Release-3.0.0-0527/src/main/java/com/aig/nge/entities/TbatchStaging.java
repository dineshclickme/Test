package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the TBATCH_STAGING database table.
 * 
 */
@Entity
@Table(name="TBATCH_STAGING")
public class TbatchStaging implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="TASK_ID")
	private int taskId;

	@Column(name="CREATE_TS")
	private Timestamp createTs;

	@Column(name="CREATE_USER_ID")
	private String createUserId;

	@Column(name="ORIGINATED_COMPONENT_NM")
	private String originatedComponentNm;

	@Column(name="ORIGINATED_METHOD_NM")
	private String originatedMethodNm;

	@Column(name="REQUEST_MSG_ID")
	private String requestMsgId;

	@Column(name="REQUEST_MSG_SQN")
	private int requestMsgSqn;

    @Lob()
	@Column(name="REQUEST_XML")
	private String requestXml;

    @Lob()
	@Column(name="RESPONSE_XML")
	private String responseXml;

	@Column(name="STATUS_CD")
	private String statusCd;

	@Column(name="SUBMISSION_NO")
	private Object submissionNo;

	@Column(name="SYSTEM_ID")
	private short systemId;

	@Column(name="TARGET_COMPONENT_NM")
	private String targetComponentNm;

	@Column(name="TARGET_METHOD_NM")
	private String targetMethodNm;

	@Column(name="TARGET_SERVICE_NM")
	private String targetServiceNm;

	@Column(name="TRANSACTION_COMPONENT_ID")
	private Object transactionComponentId;

	@Column(name="TRANSACTION_ID")
	private Object transactionId;

	@Column(name="UPDATE_TS")
	private Timestamp updateTs;

	@Column(name="UPDATE_USER_ID")
	private String updateUserId;

    public TbatchStaging() {
    }

	public int getTaskId() {
		return this.taskId;
	}

	public void setTaskId(int taskId) {
		this.taskId = taskId;
	}

	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public String getOriginatedComponentNm() {
		return this.originatedComponentNm;
	}

	public void setOriginatedComponentNm(String originatedComponentNm) {
		this.originatedComponentNm = originatedComponentNm;
	}

	public String getOriginatedMethodNm() {
		return this.originatedMethodNm;
	}

	public void setOriginatedMethodNm(String originatedMethodNm) {
		this.originatedMethodNm = originatedMethodNm;
	}

	public String getRequestMsgId() {
		return this.requestMsgId;
	}

	public void setRequestMsgId(String requestMsgId) {
		this.requestMsgId = requestMsgId;
	}

	public int getRequestMsgSqn() {
		return this.requestMsgSqn;
	}

	public void setRequestMsgSqn(int requestMsgSqn) {
		this.requestMsgSqn = requestMsgSqn;
	}

	public String getRequestXml() {
		return this.requestXml;
	}

	public void setRequestXml(String requestXml) {
		this.requestXml = requestXml;
	}

	public String getResponseXml() {
		return this.responseXml;
	}

	public void setResponseXml(String responseXml) {
		this.responseXml = responseXml;
	}

	public String getStatusCd() {
		return this.statusCd;
	}

	public void setStatusCd(String statusCd) {
		this.statusCd = statusCd;
	}

	public Object getSubmissionNo() {
		return this.submissionNo;
	}

	public void setSubmissionNo(Object submissionNo) {
		this.submissionNo = submissionNo;
	}

	public short getSystemId() {
		return this.systemId;
	}

	public void setSystemId(short systemId) {
		this.systemId = systemId;
	}

	public String getTargetComponentNm() {
		return this.targetComponentNm;
	}

	public void setTargetComponentNm(String targetComponentNm) {
		this.targetComponentNm = targetComponentNm;
	}

	public String getTargetMethodNm() {
		return this.targetMethodNm;
	}

	public void setTargetMethodNm(String targetMethodNm) {
		this.targetMethodNm = targetMethodNm;
	}

	public String getTargetServiceNm() {
		return this.targetServiceNm;
	}

	public void setTargetServiceNm(String targetServiceNm) {
		this.targetServiceNm = targetServiceNm;
	}

	public Object getTransactionComponentId() {
		return this.transactionComponentId;
	}

	public void setTransactionComponentId(Object transactionComponentId) {
		this.transactionComponentId = transactionComponentId;
	}

	public Object getTransactionId() {
		return this.transactionId;
	}

	public void setTransactionId(Object transactionId) {
		this.transactionId = transactionId;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

}