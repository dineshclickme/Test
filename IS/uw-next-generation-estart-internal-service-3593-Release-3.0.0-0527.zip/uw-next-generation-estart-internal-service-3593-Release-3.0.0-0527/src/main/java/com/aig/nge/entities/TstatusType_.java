package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SetAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-02-19T16:13:04.530+0530")
@StaticMetamodel(TstatusType.class)
public class TstatusType_ {
	public static volatile SingularAttribute<TstatusType, Short> statusTypeId;
	public static volatile SingularAttribute<TstatusType, Timestamp> createTs;
	public static volatile SingularAttribute<TstatusType, String> createUserId;
	public static volatile SingularAttribute<TstatusType, String> statusTypeNm;
	public static volatile SingularAttribute<TstatusType, Timestamp> updateTs;
	public static volatile SingularAttribute<TstatusType, String> updateUserId;
	public static volatile SetAttribute<TstatusType, Tstatus> tstatuses;
}
