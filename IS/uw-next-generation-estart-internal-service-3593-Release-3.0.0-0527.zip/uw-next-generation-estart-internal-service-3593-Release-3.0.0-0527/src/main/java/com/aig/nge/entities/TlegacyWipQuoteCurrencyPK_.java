package com.aig.nge.entities;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-04-15T15:31:47.369+0530")
@StaticMetamodel(TlegacyWipQuoteCurrencyPK.class)
public class TlegacyWipQuoteCurrencyPK_ {
	public static volatile SingularAttribute<TlegacyWipQuoteCurrencyPK, String> transactionComponentId;
	public static volatile SingularAttribute<TlegacyWipQuoteCurrencyPK, String> wipId;
	public static volatile SingularAttribute<TlegacyWipQuoteCurrencyPK, Short> quoteSqn;
	public static volatile SingularAttribute<TlegacyWipQuoteCurrencyPK, Short> currencyId;
}
