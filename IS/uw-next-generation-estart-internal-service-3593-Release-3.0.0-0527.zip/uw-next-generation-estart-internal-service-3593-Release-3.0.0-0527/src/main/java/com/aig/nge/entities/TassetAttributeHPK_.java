package com.aig.nge.entities;

import java.util.Date;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-03-02T12:10:24.601+0530")
@StaticMetamodel(TassetAttributeHPK.class)
public class TassetAttributeHPK_ {
	public static volatile SingularAttribute<TassetAttributeHPK, Integer> assetId;
	public static volatile SingularAttribute<TassetAttributeHPK, Short> attributeId;
	public static volatile SingularAttribute<TassetAttributeHPK, Short> attributeSqn;
	public static volatile SingularAttribute<TassetAttributeHPK, Date> createHistoryTs;
}
