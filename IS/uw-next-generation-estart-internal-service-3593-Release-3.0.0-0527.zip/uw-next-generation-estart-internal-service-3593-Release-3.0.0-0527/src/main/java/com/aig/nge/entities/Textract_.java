package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SetAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-02-19T16:13:03.343+0530")
@StaticMetamodel(Textract.class)
public class Textract_ {
	public static volatile SingularAttribute<Textract, String> extractNm;
	public static volatile SingularAttribute<Textract, Timestamp> createTs;
	public static volatile SingularAttribute<Textract, String> createUserId;
	public static volatile SingularAttribute<Textract, String> extractDs;
	public static volatile SingularAttribute<Textract, Timestamp> updateTs;
	public static volatile SingularAttribute<Textract, String> updateUserId;
	public static volatile SetAttribute<Textract, TextractAttribute> textractAttributes;
}
