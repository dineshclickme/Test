package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the TSTATUS_TRANSITION database table.
 * 
 */
@Embeddable
public class TstatusTransitionPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="STATUS_CONDITION_ID")
	private short statusConditionId;

	@Column(name="LIFE_CYCLE_STATUS_ID")
	private short lifeCycleStatusId;

    public TstatusTransitionPK() {
    }
	public short getStatusConditionId() {
		return this.statusConditionId;
	}
	public void setStatusConditionId(short statusConditionId) {
		this.statusConditionId = statusConditionId;
	}
	public short getLifeCycleStatusId() {
		return this.lifeCycleStatusId;
	}
	public void setLifeCycleStatusId(short lifeCycleStatusId) {
		this.lifeCycleStatusId = lifeCycleStatusId;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof TstatusTransitionPK)) {
			return false;
		}
		TstatusTransitionPK castOther = (TstatusTransitionPK)other;
		return 
			(this.statusConditionId == castOther.statusConditionId)
			&& (this.lifeCycleStatusId == castOther.lifeCycleStatusId);

    }
    
	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + ((int) this.statusConditionId);
		hash = hash * prime + ((int) this.lifeCycleStatusId);
		
		return hash;
    }
}