package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the TRELATED_PARTY database table.
 * 
 */
@Entity
@Table(name="TRELATED_PARTY")
public class TrelatedParty implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private TrelatedPartyPK id;

	@Column(name="CREATE_TS")
	private Timestamp createTs;

	@Column(name="CREATE_USER_ID")
	private String createUserId;

	@Column(name="UPDATE_TS")
	private Timestamp updateTs;

	@Column(name="UPDATE_USER_ID")
	private String updateUserId;

	//bi-directional many-to-one association to Tparty
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="PARTY_ID")
	private Tparty tparty1;

	//bi-directional many-to-one association to Tparty
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="RELATED_PARTY_ID")
	private Tparty tparty2;

	//bi-directional many-to-one association to TpartyRelationType
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="RELATION_TYPE_ID")
	private TpartyRelationType tpartyRelationType;

    public TrelatedParty() {
    }

	public TrelatedPartyPK getId() {
		return this.id;
	}

	public void setId(TrelatedPartyPK id) {
		this.id = id;
	}
	
	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public Tparty getTparty1() {
		return this.tparty1;
	}

	public void setTparty1(Tparty tparty1) {
		this.tparty1 = tparty1;
	}
	
	public Tparty getTparty2() {
		return this.tparty2;
	}

	public void setTparty2(Tparty tparty2) {
		this.tparty2 = tparty2;
	}
	
	public TpartyRelationType getTpartyRelationType() {
		return this.tpartyRelationType;
	}

	public void setTpartyRelationType(TpartyRelationType tpartyRelationType) {
		this.tpartyRelationType = tpartyRelationType;
	}
	
}