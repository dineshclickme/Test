package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-08-04T13:12:21.326+0530")
@StaticMetamodel(TlegacySubmissionAddlInfo.class)
public class TlegacySubmissionAddlInfo_ {
	public static volatile SingularAttribute<TlegacySubmissionAddlInfo, TlegacySubmissionAddlInfoPK> id;
	public static volatile SingularAttribute<TlegacySubmissionAddlInfo, String> address1Tx;
	public static volatile SingularAttribute<TlegacySubmissionAddlInfo, String> address2Tx;
	public static volatile SingularAttribute<TlegacySubmissionAddlInfo, String> cityNm;
	public static volatile SingularAttribute<TlegacySubmissionAddlInfo, String> countryCd;
	public static volatile SingularAttribute<TlegacySubmissionAddlInfo, Timestamp> createTs;
	public static volatile SingularAttribute<TlegacySubmissionAddlInfo, String> createUserId;
	public static volatile SingularAttribute<TlegacySubmissionAddlInfo, String> postalCd;
	public static volatile SingularAttribute<TlegacySubmissionAddlInfo, String> stateCd;
	public static volatile SingularAttribute<TlegacySubmissionAddlInfo, Timestamp> updateTs;
	public static volatile SingularAttribute<TlegacySubmissionAddlInfo, String> updateUserId;
	public static volatile SingularAttribute<TlegacySubmissionAddlInfo, TlegacySubmissionExtension> tlegacySubmissionExtension;
}
