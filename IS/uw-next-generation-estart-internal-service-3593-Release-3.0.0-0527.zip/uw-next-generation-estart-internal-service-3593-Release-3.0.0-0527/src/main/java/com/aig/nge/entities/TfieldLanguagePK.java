package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the TFIELD_LANGUAGE database table.
 * 
 */
@Embeddable
public class TfieldLanguagePK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="FIELD_ID")
	private short fieldId;

	@Column(name="LANGUAGE_ID")
	private short languageId;

    public TfieldLanguagePK() {
    }
	public short getFieldId() {
		return this.fieldId;
	}
	public void setFieldId(short fieldId) {
		this.fieldId = fieldId;
	}
	public short getLanguageId() {
		return this.languageId;
	}
	public void setLanguageId(short languageId) {
		this.languageId = languageId;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof TfieldLanguagePK)) {
			return false;
		}
		TfieldLanguagePK castOther = (TfieldLanguagePK)other;
		return 
			(this.fieldId == castOther.fieldId)
			&& (this.languageId == castOther.languageId);

    }
    
	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + ((int) this.fieldId);
		hash = hash * prime + ((int) this.languageId);
		
		return hash;
    }
}