package com.aig.nge.entities;

import java.sql.Timestamp;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;


@Generated(value="Dali", date="2015-02-19T16:13:03.705+0530")
@StaticMetamodel(TmlobBlockLevel.class)
public class TmlobBlockLevel_ {
	public static volatile SingularAttribute<TmlobBlockLevel, String> blockLevelId;
	public static volatile SingularAttribute<TmlobBlockLevel, String> masterLobCd;
	public static volatile SingularAttribute<TmlobBlockLevel, String> masterLobNm;
	public static volatile SingularAttribute<TmlobBlockLevel, String> coverageLineCd;
	public static volatile SingularAttribute<TmlobBlockLevel, String> coverageLineNm;
	public static volatile SingularAttribute<TmlobBlockLevel, String> coverageSubLineCd;
	public static volatile SingularAttribute<TmlobBlockLevel, String> coverageSubLineNm;
	public static volatile SingularAttribute<TmlobBlockLevel, String> blockLevelNo;
	public static volatile SingularAttribute<TmlobBlockLevel, Timestamp> createTs;
	public static volatile SingularAttribute<TmlobBlockLevel, String> createUserId;
	public static volatile SingularAttribute<TmlobBlockLevel, Timestamp> updateTs;
	public static volatile SingularAttribute<TmlobBlockLevel, String> updateUserId;
}