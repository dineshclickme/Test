package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Set;


/**
 * The persistent class for the TSEVERITY_LEVEL database table.
 * 
 */
@Entity
@Table(name="TSEVERITY_LEVEL")
public class TseverityLevel implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="SEVERITY_LEVEL_CD")
	private String severityLevelCd;

	@Column(name="CREATE_TS")
	private Timestamp createTs;

	@Column(name="CREATE_USER_ID")
	private String createUserId;

	@Column(name="SEVERITY_LEVEL_DS")
	private String severityLevelDs;

	@Column(name="UPDATE_TS")
	private Timestamp updateTs;

	@Column(name="UPDATE_USER_ID")
	private String updateUserId;

	//bi-directional many-to-one association to Terror
	@OneToMany(mappedBy="tseverityLevel")
	private Set<Terror> terrors;

	//bi-directional many-to-one association to TlegacyError
	@OneToMany(mappedBy="tseverityLevel")
	private Set<TlegacyError> tlegacyErrors;

    public TseverityLevel() {
    }

	public String getSeverityLevelCd() {
		return this.severityLevelCd;
	}

	public void setSeverityLevelCd(String severityLevelCd) {
		this.severityLevelCd = severityLevelCd;
	}

	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public String getSeverityLevelDs() {
		return this.severityLevelDs;
	}

	public void setSeverityLevelDs(String severityLevelDs) {
		this.severityLevelDs = severityLevelDs;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public Set<Terror> getTerrors() {
		return this.terrors;
	}

	public void setTerrors(Set<Terror> terrors) {
		this.terrors = terrors;
	}
	
	public Set<TlegacyError> getTlegacyErrors() {
		return this.tlegacyErrors;
	}

	public void setTlegacyErrors(Set<TlegacyError> tlegacyErrors) {
		this.tlegacyErrors = tlegacyErrors;
	}
	
}