package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-02-24T11:59:50.001+0530")
@StaticMetamodel(TproductMmcp.class)
public class TproductMmcp_ {
	public static volatile SingularAttribute<TproductMmcp, Integer> productMmcpId;
	public static volatile SingularAttribute<TproductMmcp, String> classPerilCd;
	public static volatile SingularAttribute<TproductMmcp, Timestamp> createTs;
	public static volatile SingularAttribute<TproductMmcp, String> createUserId;
	public static volatile SingularAttribute<TproductMmcp, String> deletedIn;
	public static volatile SingularAttribute<TproductMmcp, String> majorLineCd;
	public static volatile SingularAttribute<TproductMmcp, String> minorLineCd;
	public static volatile SingularAttribute<TproductMmcp, Timestamp> updateTs;
	public static volatile SingularAttribute<TproductMmcp, String> updateUserId;
	public static volatile SingularAttribute<TproductMmcp, Tproduct> tproduct;
	public static volatile SingularAttribute<TproductMmcp, TproductTowerTuwSubProduct> tproductTowerTuwSubProduct;
	public static volatile SingularAttribute<TproductMmcp, String> mmcpNm;
}
