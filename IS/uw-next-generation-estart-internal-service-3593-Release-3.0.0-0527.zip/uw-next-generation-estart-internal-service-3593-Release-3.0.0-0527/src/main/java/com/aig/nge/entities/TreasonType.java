package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;

import org.apache.openjpa.persistence.DataCache;
import java.sql.Timestamp;
import java.util.Set;


/**
 * The persistent class for the TREASON_TYPE database table.
 * 
 */
@Entity
@DataCache
@Table(name="TREASON_TYPE")
public class TreasonType implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="REASON_TYPE_ID")
	private short reasonTypeId;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="CREATE_TS")
	private Timestamp createTs;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="CREATE_USER_ID")
	private String createUserId;

	@Column(name="REASON_TYPE_NM")
	private String reasonTypeNm;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="UPDATE_TS")
	private Timestamp updateTs;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="UPDATE_USER_ID")
	private String updateUserId;

	//bi-directional many-to-one association to Treason
	@OneToMany(mappedBy="treasonType", cascade={CascadeType.ALL})
	private Set<Treason> treasons;

	//bi-directional many-to-one association to TstatusReasonType
	@OneToMany(mappedBy="treasonType", cascade={CascadeType.ALL})
	private Set<TstatusReasonType> tstatusReasonTypes;

	//bi-directional many-to-one association to TstatusTransition
	@OneToMany(mappedBy="treasonType")
	private Set<TstatusTransition> tstatusTransitions;

    public TreasonType() {
    }

	public short getReasonTypeId() {
		return this.reasonTypeId;
	}

	public void setReasonTypeId(short reasonTypeId) {
		this.reasonTypeId = reasonTypeId;
	}

	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public String getReasonTypeNm() {
		return this.reasonTypeNm;
	}

	public void setReasonTypeNm(String reasonTypeNm) {
		this.reasonTypeNm = reasonTypeNm;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public Set<Treason> getTreasons() {
		return this.treasons;
	}

	public void setTreasons(Set<Treason> treasons) {
		this.treasons = treasons;
	}
	
	public Set<TstatusReasonType> getTstatusReasonTypes() {
		return this.tstatusReasonTypes;
	}

	public void setTstatusReasonTypes(Set<TstatusReasonType> tstatusReasonTypes) {
		this.tstatusReasonTypes = tstatusReasonTypes;
	}
	
	public Set<TstatusTransition> getTstatusTransitions() {
		return this.tstatusTransitions;
	}

	public void setTstatusTransitions(Set<TstatusTransition> tstatusTransitions) {
		this.tstatusTransitions = tstatusTransitions;
	}
	
}