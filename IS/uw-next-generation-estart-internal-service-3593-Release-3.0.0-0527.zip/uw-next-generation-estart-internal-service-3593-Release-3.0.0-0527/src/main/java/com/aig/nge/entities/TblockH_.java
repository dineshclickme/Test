package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-03-02T12:10:24.716+0530")
@StaticMetamodel(TblockH.class)
public class TblockH_ {
	public static volatile SingularAttribute<TblockH, TblockHPK> id;
	public static volatile SingularAttribute<TblockH, Short> blockTypeId;
	public static volatile SingularAttribute<TblockH, String> commentTx;
	public static volatile SingularAttribute<TblockH, Timestamp> createTs;
	public static volatile SingularAttribute<TblockH, String> createUserId;
	public static volatile SingularAttribute<TblockH, Short> reasonId;
	public static volatile SingularAttribute<TblockH, Short> statusId;
	public static volatile SingularAttribute<TblockH, Short> systemId;
	public static volatile SingularAttribute<TblockH, String> transactionComponentId;
	public static volatile SingularAttribute<TblockH, Timestamp> updateTs;
	public static volatile SingularAttribute<TblockH, String> updateUserId;
	public static volatile SingularAttribute<TblockH, Integer> partyId;
	public static volatile SingularAttribute<TblockH, Short> roleId;
}
