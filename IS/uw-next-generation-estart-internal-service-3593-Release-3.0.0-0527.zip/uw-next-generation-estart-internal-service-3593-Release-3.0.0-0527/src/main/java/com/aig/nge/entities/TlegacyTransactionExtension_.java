package com.aig.nge.entities;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-09-11T14:03:53.715+0530")
@StaticMetamodel(TlegacyTransactionExtension.class)
public class TlegacyTransactionExtension_ {
	public static volatile SingularAttribute<TlegacyTransactionExtension, TlegacyTransactionExtensionPK> id;
	public static volatile SingularAttribute<TlegacyTransactionExtension, BigDecimal> bundleAttachmentAm;
	public static volatile SingularAttribute<TlegacyTransactionExtension, BigDecimal> bundleLimitAm;
	public static volatile SingularAttribute<TlegacyTransactionExtension, BigDecimal> bundlePartOfAm;
	public static volatile SingularAttribute<TlegacyTransactionExtension, BigDecimal> bundlePremiumAm;
	public static volatile SingularAttribute<TlegacyTransactionExtension, Timestamp> createTs;
	public static volatile SingularAttribute<TlegacyTransactionExtension, String> createUserId;
	public static volatile SingularAttribute<TlegacyTransactionExtension, String> profitCenterCd;
	public static volatile SingularAttribute<TlegacyTransactionExtension, Short> profitUnitCd;
	public static volatile SingularAttribute<TlegacyTransactionExtension, String> legacyBundledCovgTypeCd;
	public static volatile SingularAttribute<TlegacyTransactionExtension, BigDecimal> localBundleAttachmentAm;
	public static volatile SingularAttribute<TlegacyTransactionExtension, Short> sectionCd;
	public static volatile SingularAttribute<TlegacyTransactionExtension, Timestamp> updateTs;
	public static volatile SingularAttribute<TlegacyTransactionExtension, String> updateUserId;
	public static volatile SingularAttribute<TlegacyTransactionExtension, TinsuranceCarrier> tinsuranceCarrier;
	public static volatile SingularAttribute<TlegacyTransactionExtension, TlegacyProduct> tlegacyProduct;
	public static volatile SingularAttribute<TlegacyTransactionExtension, TtransactionVersion> ttransactionVersion;
	public static volatile SingularAttribute<TlegacyTransactionExtension, BigDecimal> localBundleLimitAm;
	public static volatile SingularAttribute<TlegacyTransactionExtension, BigDecimal> localBundlePartOfAm;
	public static volatile SingularAttribute<TlegacyTransactionExtension, BigDecimal> localBundlePremiumAm;
	public static volatile SingularAttribute<TlegacyTransactionExtension, String> nonRecurringIn;
	public static volatile SingularAttribute<TlegacyTransactionExtension, Integer> rrPrtctvContNo;
	public static volatile SingularAttribute<TlegacyTransactionExtension, String> specialEventNm;
	public static volatile SingularAttribute<TlegacyTransactionExtension, Date> underwritingDt;
}
