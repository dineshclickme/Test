package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the TPARTY_ACTION database table.
 * 
 */
@Embeddable
public class TpartyActionPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="SYSTEM_ID")
	private short systemId;

	@Column(name="GEOGRAPHIC_LOCATION_ID")
	private int geographicLocationId;
	
	@Column(name="PRODUCT_TOWER_ID")
	private short productTowerId;

	@Column(name="DATA_CATEGORY_NM")
	private String dataCategoryNm;

	@Column(name="ROLE_ID")
	private short roleId;

	@Column(name="PARTY_ID")
	private int partyId;

    public TpartyActionPK() {
    }
	public short getSystemId() {
		return this.systemId;
	}
	public void setSystemId(short systemId) {
		this.systemId = systemId;
	}
	public int getGeographicLocationId() {
		return this.geographicLocationId;
	}
	public void setGeographicLocationId(int geographicLocationId) {
		this.geographicLocationId = geographicLocationId;
	}
	public short getProductTowerId() {
		return this.productTowerId;
	}
	public void setProductTowerId(short productTowerId) {
		this.productTowerId = productTowerId;
	}

	public String getDataCategoryNm() {
		return this.dataCategoryNm;
	}
	public void setDataCategoryNm(String dataCategoryNm) {
		this.dataCategoryNm = dataCategoryNm;
	}
	public short getRoleId() {
		return this.roleId;
	}
	public void setRoleId(short roleId) {
		this.roleId = roleId;
	}
	public int getPartyId() {
		return this.partyId;
	}
	public void setPartyId(int partyId) {
		this.partyId = partyId;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof TpartyActionPK)) {
			return false;
		}
		TpartyActionPK castOther = (TpartyActionPK)other;
		return 
			(this.systemId == castOther.systemId)
			&& (this.geographicLocationId == castOther.geographicLocationId)
			&& (this.productTowerId == castOther.productTowerId)
			&& this.dataCategoryNm.equals(castOther.dataCategoryNm)
			&& (this.roleId == castOther.roleId)
			&& (this.partyId == castOther.partyId);

    }
    
	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + ((int) this.systemId);
		hash = hash * prime + this.geographicLocationId;
		hash = hash * prime + ((int) this.productTowerId);
		hash = hash * prime + this.dataCategoryNm.hashCode();
		hash = hash * prime + ((int) this.roleId);
		hash = hash * prime + this.partyId;
		
		return hash;
    }
}