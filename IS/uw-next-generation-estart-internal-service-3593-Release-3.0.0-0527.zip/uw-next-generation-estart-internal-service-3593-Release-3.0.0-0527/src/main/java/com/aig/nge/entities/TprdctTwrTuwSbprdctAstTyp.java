package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;

import java.sql.Timestamp;


/**
 * The persistent class for the TPRDCT_TWR_TUW_SBPRDCT_AST_TYP database table.
 * 
 */
@Entity
@Table(name="TPRDCT_TWR_TUW_SBPRDCT_AST_TYP")
public class TprdctTwrTuwSbprdctAstTyp implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private TprdctTwrTuwSbprdctAstTypPK id;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="CREATE_TS")
	private Timestamp createTs;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="CREATE_USER_ID")
	private String createUserId;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="UPDATE_TS")
	private Timestamp updateTs;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="UPDATE_USER_ID")
	private String updateUserId;

	//bi-directional many-to-one association to TassetType
	@ManyToOne
	@JoinColumn(name="ASSET_TYPE_ID")
	private TassetType tassetType;

	//bi-directional many-to-one association to TproductTowerTuwSubProdct
    @ManyToOne
	@JoinColumns({
		@JoinColumn(name="PRODUCT_TOWER_ID", referencedColumnName="PRODUCT_TOWER_ID"),
		@JoinColumn(name="TUW_SUB_PRODUCT_ID", referencedColumnName="TUW_SUB_PRODUCT_ID")
		})
	private TproductTowerTuwSubProduct tproductTowerTuwSubProdct;

    public TprdctTwrTuwSbprdctAstTyp() {
    }

	public TprdctTwrTuwSbprdctAstTypPK getId() {
		return this.id;
	}

	public void setId(TprdctTwrTuwSbprdctAstTypPK id) {
		this.id = id;
	}
	
	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public TassetType getTassetType() {
		return this.tassetType;
	}

	public void setTassetType(TassetType tassetType) {
		this.tassetType = tassetType;
	}
	
	public TproductTowerTuwSubProduct getTproductTowerTuwSubProduct() {
		return this.tproductTowerTuwSubProdct;
	}

	public void setTproductTowerTuwSubProdct(TproductTowerTuwSubProduct tproductTowerTuwSubProduct) {
		this.tproductTowerTuwSubProdct = tproductTowerTuwSubProduct;
	}
	
}