package com.aig.nge.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Ssequence implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="DUMMY_ID")
	private int dummyId;

	public int getDummyId() {
		return dummyId;
	}

	public void setDummyId(int dummyId) {
		this.dummyId = dummyId;
	}
}