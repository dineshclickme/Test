package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the TLEGACY_TRANSACTION_EXTENSION database table.
 * 
 */
@Embeddable
public class TlegacyTransactionExtensionPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="TRANSACTION_ID")
	private String transactionId;

	@Column(name="VERSION_SQN")
	private short versionSqn;

	@Column(name="LEGACY_BUNDLED_PRODUCT_CD")
	private String legacyBundledProductCd;

    public TlegacyTransactionExtensionPK() {
    }
	public String getTransactionId() {
		return this.transactionId;
	}
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	public short getVersionSqn() {
		return this.versionSqn;
	}
	public void setVersionSqn(short versionSqn) {
		this.versionSqn = versionSqn;
	}
	public String getLegacyBundledProductCd() {
		return this.legacyBundledProductCd;
	}
	public void setLegacyBundledProductCd(String legacyBundledProductCd) {
		this.legacyBundledProductCd = legacyBundledProductCd;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof TlegacyTransactionExtensionPK)) {
			return false;
		}
		TlegacyTransactionExtensionPK castOther = (TlegacyTransactionExtensionPK)other;
		return 
			this.transactionId.equals(castOther.transactionId)
			&& (this.versionSqn == castOther.versionSqn)
			&& this.legacyBundledProductCd.equals(castOther.legacyBundledProductCd);

    }
    
	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.transactionId.hashCode();
		hash = hash * prime + ((int) this.versionSqn);
		hash = hash * prime + this.legacyBundledProductCd.hashCode();
		
		return hash;
    }
}