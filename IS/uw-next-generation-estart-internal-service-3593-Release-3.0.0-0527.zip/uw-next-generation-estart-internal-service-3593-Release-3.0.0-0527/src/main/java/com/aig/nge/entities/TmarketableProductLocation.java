package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;

import java.sql.Timestamp;


/**
 * The persistent class for the TMARKETABLE_PRODUCT_LOCATION database table.
 * 
 */
@Entity
@Table(name="TMARKETABLE_PRODUCT_LOCATION")
public class TmarketableProductLocation implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private TmarketableProductLocationPK id;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="CREATE_TS")
	private Timestamp createTs;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="CREATE_USER_ID")
	private String createUserId;

	@Column(name="DELETED_IN")
	private String deletedIn;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="UPDATE_TS")
	private Timestamp updateTs;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="UPDATE_USER_ID")
	private String updateUserId;
	
	//bi-directional many-to-one association to Tlocation
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="GEOGRAPHIC_LOCATION_ID")
	private Tlocation tlocation;
	
	//bi-directional many-to-one association to TmarketableProduct
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="MARKETABLE_PRODUCT_ID")
	private TmarketableProduct tmarketableProduct;

    public TmarketableProductLocation() {
    }

	public TmarketableProductLocationPK getId() {
		return this.id;
	}

	public void setId(TmarketableProductLocationPK id) {
		this.id = id;
	}
	
	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public String getDeletedIn() {
		return this.deletedIn;
	}

	public void setDeletedIn(String deletedIn) {
		this.deletedIn = deletedIn;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public Tlocation getTlocation() {
		return this.tlocation;
	}

	public void setTlocation(Tlocation tlocation) {
		this.tlocation = tlocation;
	}
	
	public TmarketableProduct getTmarketableProduct() {
		return this.tmarketableProduct;
	}

	public void setTmarketableProduct(TmarketableProduct tmarketableProduct) {
		this.tmarketableProduct = tmarketableProduct;
	}
}