package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the TOFAC_ALERT_NOTIFICATION database table.
 * 
 */
@Entity
@Table(name="TOFAC_ALERT_NOTIFICATION")
public class TofacAlertNotification implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="OFAC_ALERT_ID")
	private int ofacAlertId;

	@Column(name="CREATE_TS")
	private Timestamp createTs;

	@Column(name="CREATE_USER_ID")
	private String createUserId;

	@Column(name="NOTIFIED_IN")
	private String notifiedIn;

	@Column(name="UPDATE_TS")
	private Timestamp updateTs;

	@Column(name="UPDATE_USER_ID")
	private String updateUserId;

	//bi-directional many-to-one association to Tparty
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="PARTY_ID")
	private Tparty tparty;

	//bi-directional many-to-one association to Tsubmission
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="SUBMISSION_NO")
	private Tsubmission tsubmission;

	//bi-directional many-to-one association to TsubmissionEvaluationAlert
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="SUBMISSION_EVALUATION_CD")
	private TsubmissionEvaluationAlert tsubmissionEvaluationAlert;

    public TofacAlertNotification() {
    }

	public int getOfacAlertId() {
		return this.ofacAlertId;
	}

	public void setOfacAlertId(int ofacAlertId) {
		this.ofacAlertId = ofacAlertId;
	}

	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public String getNotifiedIn() {
		return this.notifiedIn;
	}

	public void setNotifiedIn(String notifiedIn) {
		this.notifiedIn = notifiedIn;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public Tparty getTparty() {
		return this.tparty;
	}

	public void setTparty(Tparty tparty) {
		this.tparty = tparty;
	}
	
	public Tsubmission getTsubmission() {
		return this.tsubmission;
	}

	public void setTsubmission(Tsubmission tsubmission) {
		this.tsubmission = tsubmission;
	}
	
	public TsubmissionEvaluationAlert getTsubmissionEvaluationAlert() {
		return this.tsubmissionEvaluationAlert;
	}

	public void setTsubmissionEvaluationAlert(TsubmissionEvaluationAlert tsubmissionEvaluationAlert) {
		this.tsubmissionEvaluationAlert = tsubmissionEvaluationAlert;
	}
	
}