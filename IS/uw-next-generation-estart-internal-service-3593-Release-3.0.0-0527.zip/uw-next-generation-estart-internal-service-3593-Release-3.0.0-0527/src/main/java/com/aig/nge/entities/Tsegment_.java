package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SetAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-02-19T16:13:04.412+0530")
@StaticMetamodel(Tsegment.class)
public class Tsegment_ {
	public static volatile SingularAttribute<Tsegment, String> segmentCd;
	public static volatile SingularAttribute<Tsegment, Timestamp> createTs;
	public static volatile SingularAttribute<Tsegment, String> createUserId;
	public static volatile SingularAttribute<Tsegment, String> segmentNm;
	public static volatile SingularAttribute<Tsegment, Timestamp> updateTs;
	public static volatile SingularAttribute<Tsegment, String> updateUserId;
	public static volatile SetAttribute<Tsegment, TproductTower> tproductTowers1;
	public static volatile SetAttribute<Tsegment, TproductTower> tproductTowers2;
}
