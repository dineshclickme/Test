package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the TTABLE_ATTRIBUTE database table.
 * 
 */
@Embeddable
public class TtableAttributePK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="TABLE_ID")
	private short tableId;

	@Column(name="ATTRIBUTE_ID")
	private short attributeId;

    public TtableAttributePK() {
    }
	public short getTableId() {
		return this.tableId;
	}
	public void setTableId(short tableId) {
		this.tableId = tableId;
	}
	public short getAttributeId() {
		return this.attributeId;
	}
	public void setAttributeId(short attributeId) {
		this.attributeId = attributeId;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof TtableAttributePK)) {
			return false;
		}
		TtableAttributePK castOther = (TtableAttributePK)other;
		return 
			(this.tableId == castOther.tableId)
			&& (this.attributeId == castOther.attributeId);

    }
    
	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + ((int) this.tableId);
		hash = hash * prime + ((int) this.attributeId);
		
		return hash;
    }
}