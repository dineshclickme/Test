package com.aig.nge.entities;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-02-19T16:13:03.507+0530")
@StaticMetamodel(ThelpLanguagePK.class)
public class ThelpLanguagePK_ {
	public static volatile SingularAttribute<ThelpLanguagePK, Integer> helpId;
	public static volatile SingularAttribute<ThelpLanguagePK, Short> languageId;
}
