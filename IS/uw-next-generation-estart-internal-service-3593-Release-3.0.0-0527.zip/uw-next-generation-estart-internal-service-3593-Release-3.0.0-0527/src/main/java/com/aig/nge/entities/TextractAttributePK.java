package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the TEXTRACT_ATTRIBUTE database table.
 * 
 */
@Embeddable
public class TextractAttributePK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="EXTRACT_NM")
	private String extractNm;

	@Column(name="ATTRIBUTE_ID")
	private short attributeId;

    public TextractAttributePK() {
    }
	public String getExtractNm() {
		return this.extractNm;
	}
	public void setExtractNm(String extractNm) {
		this.extractNm = extractNm;
	}
	public short getAttributeId() {
		return this.attributeId;
	}
	public void setAttributeId(short attributeId) {
		this.attributeId = attributeId;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof TextractAttributePK)) {
			return false;
		}
		TextractAttributePK castOther = (TextractAttributePK)other;
		return 
			this.extractNm.equals(castOther.extractNm)
			&& (this.attributeId == castOther.attributeId);

    }
    
	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.extractNm.hashCode();
		hash = hash * prime + ((int) this.attributeId);
		
		return hash;
    }
}