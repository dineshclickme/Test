package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;

import org.apache.openjpa.persistence.DataCache;
import java.sql.Timestamp;


/**
 * The persistent class for the TTOWER_EVENT database table.
 * 
 */
@Entity
@DataCache
@Table(name="TTOWER_EVENT")
public class TtowerEvent implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private TtowerEventPK id;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="CREATE_TS")
	private Timestamp createTs;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="CREATE_USER_ID")
	private String createUserId;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="UPDATE_TS")
	private Timestamp updateTs;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="UPDATE_USER_ID")
	private String updateUserId;

	//bi-directional many-to-one association to Tattribute
	@ManyToOne
	@JoinColumn(name="ATTRIBUTE_ID")
	private Tattribute tattribute;

	//bi-directional many-to-one association to Tevent
	@ManyToOne
	@JoinColumn(name="EVENT_ID")
	private Tevent tevent;

	//bi-directional many-to-one association to TproductTower
	@ManyToOne
	@JoinColumn(name="PRODUCT_TOWER_ID")
	private TproductTower tproductTower;

    public TtowerEvent() {
    }

	public TtowerEventPK getId() {
		return this.id;
	}

	public void setId(TtowerEventPK id) {
		this.id = id;
	}
	
	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public Tattribute getTattribute() {
		return this.tattribute;
	}

	public void setTattribute(Tattribute tattribute) {
		this.tattribute = tattribute;
	}
	
	public Tevent getTevent() {
		return this.tevent;
	}

	public void setTevent(Tevent tevent) {
		this.tevent = tevent;
	}
	
	public TproductTower getTproductTower() {
		return this.tproductTower;
	}

	public void setTproductTower(TproductTower tproductTower) {
		this.tproductTower = tproductTower;
	}
	
}