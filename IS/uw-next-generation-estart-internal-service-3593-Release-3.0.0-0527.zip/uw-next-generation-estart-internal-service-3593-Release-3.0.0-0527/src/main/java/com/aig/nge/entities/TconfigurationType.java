package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Set;


/**
 * The persistent class for the TCONFIGURATION_TYPE database table.
 * 
 */
@Entity
@Table(name="TCONFIGURATION_TYPE")
public class TconfigurationType implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="CONFIGURATION_TYPE_ID")
	private short configurationTypeId;

	@Column(name="CONFIGURATION_TYPE_DS")
	private String configurationTypeDs;

	@Column(name="CREATE_TS")
	private Timestamp createTs;

	@Column(name="CREATE_USER_ID")
	private String createUserId;

	@Column(name="UPDATE_TS")
	private Timestamp updateTs;

	@Column(name="UPDATE_USER_ID")
	private String updateUserId;

	//bi-directional many-to-one association to TproductTowerConfiguration
	@OneToMany(mappedBy="tconfigurationType")
	private Set<TproductTowerConfiguration> tproductTowerConfigurations;

    public TconfigurationType() {
    }

	public short getConfigurationTypeId() {
		return this.configurationTypeId;
	}

	public void setConfigurationTypeId(short configurationTypeId) {
		this.configurationTypeId = configurationTypeId;
	}

	public String getConfigurationTypeDs() {
		return this.configurationTypeDs;
	}

	public void setConfigurationTypeDs(String configurationTypeDs) {
		this.configurationTypeDs = configurationTypeDs;
	}

	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public Set<TproductTowerConfiguration> getTproductTowerConfigurations() {
		return this.tproductTowerConfigurations;
	}

	public void setTproductTowerConfigurations(Set<TproductTowerConfiguration> tproductTowerConfigurations) {
		this.tproductTowerConfigurations = tproductTowerConfigurations;
	}
	
}