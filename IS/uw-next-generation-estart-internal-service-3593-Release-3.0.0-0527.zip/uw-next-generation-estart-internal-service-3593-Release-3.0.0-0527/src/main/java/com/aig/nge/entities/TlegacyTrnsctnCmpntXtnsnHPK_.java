package com.aig.nge.entities;

import java.util.Date;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-04-15T15:31:47.291+0530")
@StaticMetamodel(TlegacyTrnsctnCmpntXtnsnHPK.class)
public class TlegacyTrnsctnCmpntXtnsnHPK_ {
	public static volatile SingularAttribute<TlegacyTrnsctnCmpntXtnsnHPK, String> transactionComponentId;
	public static volatile SingularAttribute<TlegacyTrnsctnCmpntXtnsnHPK, Date> createHistoryTs;
}
