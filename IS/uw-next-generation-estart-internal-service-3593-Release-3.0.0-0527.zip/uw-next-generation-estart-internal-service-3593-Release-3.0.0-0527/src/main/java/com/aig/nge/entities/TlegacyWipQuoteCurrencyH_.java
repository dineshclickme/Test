package com.aig.nge.entities;

import java.math.BigDecimal;
import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-04-15T15:31:47.337+0530")
@StaticMetamodel(TlegacyWipQuoteCurrencyH.class)
public class TlegacyWipQuoteCurrencyH_ {
	public static volatile SingularAttribute<TlegacyWipQuoteCurrencyH, TlegacyWipQuoteCurrencyHPK> id;
	public static volatile SingularAttribute<TlegacyWipQuoteCurrencyH, Timestamp> createTs;
	public static volatile SingularAttribute<TlegacyWipQuoteCurrencyH, String> createUserId;
	public static volatile SingularAttribute<TlegacyWipQuoteCurrencyH, BigDecimal> policyAtchmtPointAm;
	public static volatile SingularAttribute<TlegacyWipQuoteCurrencyH, BigDecimal> policyLimitAm;
	public static volatile SingularAttribute<TlegacyWipQuoteCurrencyH, BigDecimal> policyPartOfAm;
	public static volatile SingularAttribute<TlegacyWipQuoteCurrencyH, BigDecimal> quotedAtchmtPointAm;
	public static volatile SingularAttribute<TlegacyWipQuoteCurrencyH, BigDecimal> quotedLimitAm;
	public static volatile SingularAttribute<TlegacyWipQuoteCurrencyH, BigDecimal> quotedPremiumAm;
	public static volatile SingularAttribute<TlegacyWipQuoteCurrencyH, Timestamp> updateTs;
	public static volatile SingularAttribute<TlegacyWipQuoteCurrencyH, String> updateUserId;
	public static volatile SingularAttribute<TlegacyWipQuoteCurrencyH, BigDecimal> boundPremiumAm;
}
