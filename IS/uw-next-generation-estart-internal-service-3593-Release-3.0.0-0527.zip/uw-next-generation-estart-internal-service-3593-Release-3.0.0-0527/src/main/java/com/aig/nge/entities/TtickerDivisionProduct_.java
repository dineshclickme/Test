package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-06-19T14:59:46.073+0530")
@StaticMetamodel(TtickerDivisionProduct.class)
public class TtickerDivisionProduct_ {
	public static volatile SingularAttribute<TtickerDivisionProduct, TtickerDivisionProductPK> id;
	public static volatile SingularAttribute<TtickerDivisionProduct, Timestamp> createTs;
	public static volatile SingularAttribute<TtickerDivisionProduct, String> createUserId;
	public static volatile SingularAttribute<TtickerDivisionProduct, String> deletedIn;
	public static volatile SingularAttribute<TtickerDivisionProduct, Timestamp> updateTs;
	public static volatile SingularAttribute<TtickerDivisionProduct, String> updateUserId;
	public static volatile SingularAttribute<TtickerDivisionProduct, TtickerFeed> ttickerFeed;
	public static volatile SingularAttribute<TtickerDivisionProduct, Tdivision> tdivision;
	public static volatile SingularAttribute<TtickerDivisionProduct, Tproduct> tproduct;
}
