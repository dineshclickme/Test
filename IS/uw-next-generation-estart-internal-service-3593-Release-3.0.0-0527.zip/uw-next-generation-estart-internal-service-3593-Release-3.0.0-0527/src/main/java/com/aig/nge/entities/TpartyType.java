package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;

import org.apache.openjpa.persistence.DataCache;
import java.sql.Timestamp;
import java.util.Set;


/**
 * The persistent class for the TPARTY_TYPE database table.
 * 
 */
@Entity
@DataCache
@Table(name="TPARTY_TYPE")
public class TpartyType implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="PARTY_TYPE_ID")
	private short partyTypeId;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="CREATE_TS")
	private Timestamp createTs;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="CREATE_USER_ID")
	private String createUserId;

	@Column(name="PARTY_TYPE_NM")
	private String partyTypeNm;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="UPDATE_TS")
	private Timestamp updateTs;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="UPDATE_USER_ID")
	private String updateUserId;

	//bi-directional many-to-one association to Tparty
	@OneToMany(mappedBy="tpartyType", cascade={CascadeType.ALL})
	private Set<Tparty> tparties;
	//bi-directional many-to-one association to Trole
	@OneToMany(mappedBy="tpartyType")
	private Set<Trole> troles;

    public TpartyType() {
    }

	public short getPartyTypeId() {
		return this.partyTypeId;
	}

	public void setPartyTypeId(short partyTypeId) {
		this.partyTypeId = partyTypeId;
	}

	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public String getPartyTypeNm() {
		return this.partyTypeNm;
	}

	public void setPartyTypeNm(String partyTypeNm) {
		this.partyTypeNm = partyTypeNm;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public Set<Tparty> getTparties() {
		return this.tparties;
	}

	public void setTparties(Set<Tparty> tparties) {
		this.tparties = tparties;
	}
	
	public Set<Trole> getTroles() {
		return this.troles;
	}

	public void setTroles(Set<Trole> troles) {
		this.troles = troles;
	}
}