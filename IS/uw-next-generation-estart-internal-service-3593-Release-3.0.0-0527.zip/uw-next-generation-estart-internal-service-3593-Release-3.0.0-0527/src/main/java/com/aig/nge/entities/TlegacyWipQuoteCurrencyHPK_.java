package com.aig.nge.entities;

import java.util.Date;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-04-15T15:31:47.353+0530")
@StaticMetamodel(TlegacyWipQuoteCurrencyHPK.class)
public class TlegacyWipQuoteCurrencyHPK_ {
	public static volatile SingularAttribute<TlegacyWipQuoteCurrencyHPK, String> transactionComponentId;
	public static volatile SingularAttribute<TlegacyWipQuoteCurrencyHPK, String> wipId;
	public static volatile SingularAttribute<TlegacyWipQuoteCurrencyHPK, Short> quoteSqn;
	public static volatile SingularAttribute<TlegacyWipQuoteCurrencyHPK, Date> createHistoryTs;
	public static volatile SingularAttribute<TlegacyWipQuoteCurrencyHPK, Short> currencyId;
}
