package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-02-24T11:59:49.775+0530")
@StaticMetamodel(TmarketableProductComponent.class)
public class TmarketableProductComponent_ {
	public static volatile SingularAttribute<TmarketableProductComponent, Integer> marketableProductCmpntId;
	public static volatile SingularAttribute<TmarketableProductComponent, Timestamp> createTs;
	public static volatile SingularAttribute<TmarketableProductComponent, String> createUserId;
	public static volatile SingularAttribute<TmarketableProductComponent, String> deletedIn;
	public static volatile SingularAttribute<TmarketableProductComponent, String> marketableProductCmpntCd;
	public static volatile SingularAttribute<TmarketableProductComponent, String> marketableProductCmpntNm;
	public static volatile SingularAttribute<TmarketableProductComponent, Timestamp> updateTs;
	public static volatile SingularAttribute<TmarketableProductComponent, String> updateUserId;
	public static volatile SingularAttribute<TmarketableProductComponent, TmarketableProduct> tmarketableProduct;
	public static volatile SingularAttribute<TmarketableProductComponent, Tproduct> tproduct;
	public static volatile SingularAttribute<TmarketableProductComponent, TproductTowerTuwSubProduct> tproductTowerTuwSubProduct;
}
