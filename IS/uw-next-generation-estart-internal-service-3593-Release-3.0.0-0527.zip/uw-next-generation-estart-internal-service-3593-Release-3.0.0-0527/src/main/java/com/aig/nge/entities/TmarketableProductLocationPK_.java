package com.aig.nge.entities;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2016-01-29T22:27:16.128+0530")
@StaticMetamodel(TmarketableProductLocationPK.class)
public class TmarketableProductLocationPK_ {
	public static volatile SingularAttribute<TmarketableProductLocationPK, Integer> marketableProductId;
	public static volatile SingularAttribute<TmarketableProductLocationPK, Integer> geographicLocationId;
}
