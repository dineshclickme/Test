package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SetAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-02-19T16:13:04.422+0530")
@StaticMetamodel(Tservice.class)
public class Tservice_ {
	public static volatile SingularAttribute<Tservice, Short> serviceId;
	public static volatile SingularAttribute<Tservice, Timestamp> createTs;
	public static volatile SingularAttribute<Tservice, String> createUserId;
	public static volatile SingularAttribute<Tservice, String> serviceNm;
	public static volatile SingularAttribute<Tservice, Timestamp> updateTs;
	public static volatile SingularAttribute<Tservice, String> updateUserId;
	public static volatile SetAttribute<Tservice, Tmethod> tmethods;
}
