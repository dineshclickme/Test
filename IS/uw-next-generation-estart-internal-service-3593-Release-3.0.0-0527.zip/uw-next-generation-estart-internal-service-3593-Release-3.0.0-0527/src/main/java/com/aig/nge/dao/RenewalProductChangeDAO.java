package com.aig.nge.dao;


import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
/*
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;*/


import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.aig.nge.entities.Tblock;
import com.aig.nge.entities.TblockH;
import com.aig.nge.entities.TcomponentBlock;
import com.aig.nge.entities.TlegacyProduct;
import com.aig.nge.entities.TlegacyTrnsctnCmpntXtensn;
import com.aig.nge.entities.TlegacyWipQuote;
import com.aig.nge.entities.TlegacyWipQuoteH;
import com.aig.nge.entities.Tstatus;
import com.aig.nge.entities.Tsubmission;
import com.aig.nge.entities.TtransactionComponent;
import com.aig.nge.entities.TtransactionComponentAtrbt;
import com.aig.nge.entities.TtransactionComponentLimit;
import com.aig.nge.entities.TtransactionComponentStatus;
import com.aig.nge.repository.TBlockHRepository;
import com.aig.nge.repository.TBlockRepository;
import com.aig.nge.repository.TComponentBlockRepository;
import com.aig.nge.repository.TLegacyProductMappingRepository;
import com.aig.nge.repository.TLegacyProductRepository;
import com.aig.nge.repository.TLegacyWIPQuoteHsRepository;
import com.aig.nge.repository.TLegacyWipQuoteRepository;
import com.aig.nge.repository.TStatusRepository;
import com.aig.nge.repository.TSubmissionRepository;
import com.aig.nge.repository.TTransactionComponentAtrbtRepository;
import com.aig.nge.repository.TTransactionComponentLimitRepository;
import com.aig.nge.repository.TTransactionComponentRepository;
import com.aig.nge.repository.TlegacyTrnsctnCmpntXtensnRepository;
import com.aig.nge.utilities.AIGCIExceptionMsg;
import com.aig.nge.utilities.NGECommonUtil;
import com.aig.nge.utilities.NGEConstants;
import com.aig.nge.utilities.NGEErrorCodes;
import com.aig.nge.wsdl.legacy.skeleton.RenewalProductChangeRequest;
/*import javax.xml.datatype.XMLGregorianCalendar;*/
/*import com.aig.nge.entities.Tpolicy;*/
/*import com.aig.nge.repository.TPolicyRepository;*/
/*import com.aig.nge.repository.TTransactionComponentPolicyRepository;*/
//import com.aig.nge.legacysupportservices.handler.Transactional;
import com.aig.nge.wsdl.skeleton.AIGCIException;

 
@Repository
public class RenewalProductChangeDAO extends BaseDAO 
{

	@Autowired
	private TSubmissionRepository tsubmissionrepository;
	
	@Autowired
	private TlegacyTrnsctnCmpntXtensnRepository tlegacytrnsctncmpntxtensnrepository;
	
	@Autowired
	private TTransactionComponentRepository ttransactioncomponentrepository;	
	

	@Autowired
	private TTransactionComponentAtrbtRepository ttransactionComponentAtrbtRepository;
	
	@Autowired
	private TLegacyProductRepository tlegacyproductrepository;

	@Autowired
	private TTransactionComponentLimitRepository ttransactioncomponentlimitrepository;

	@Autowired
    private TLegacyWipQuoteRepository tlegacywipquoterepository;
	
	@Autowired
	private TLegacyProductMappingRepository tLegacyProductMappingRepository;
	
	
	@Autowired
	private TBlockHRepository tBlockHRepository;
	

	@Autowired
    private TLegacyWIPQuoteHsRepository tLegacyWIPQuoteHsRepository;
	
	@Autowired
	private TStatusRepository tStatusRepository;
	
	@Autowired
	private TBlockRepository tBlockRepository;
	
	@Autowired
	private TComponentBlockRepository tComponentBlockRepository;
	/*
	@PersistenceContext
    private EntityManager em;	*/
	
/*	@Autowired
	private TPolicyRepository tpolicyrepository;
	
	@Autowired
	private TTransactionComponentPolicyRepository ttransctioncomponentpolicyrepository;*/

	private static final Logger logger = LogManager.getLogger(RenewalProductChangeDAO.class);

	public Tsubmission  findSubmissionNo(String submissionNo) throws AIGCIExceptionMsg{		
		Tsubmission submissionData = null;
		submissionData=tsubmissionrepository.findOne(submissionNo);		
		logger.debug(":::::::::Exiting Submission Number Dao:::::::::::: ");
		return submissionData;
	}
	
	public void checkSubmissionNo(String submissionNo) throws AIGCIExceptionMsg 
	{
		
		logger.debug("Inside Renewal Product Change Dao");

		Tsubmission submissionData = null;
		submissionData=tsubmissionrepository.checkRenewalSubmission(submissionNo);	
		
		
		if(submissionData == null)
		{
			ngeException.throwException( NGEErrorCodes.INVALID_SUBMISSION_NUM, NGEErrorCodes.ERROR_TYPE, null,null);
		}
		  logger.debug("::::::::::Exiting submissionNo check::::::::::::::::::::");
	
	}
	
public String getTransactionComponentId(String currentProductCd,String currentCoverageType, String submissionNo) throws AIGCIExceptionMsg
{
	String ttransactionComponentId=null;
	List<Object[]> resultSet=tsubmissionrepository.checkProductExistsUnderGivenSubmission(NGECommonUtil.convertToString(currentProductCd),currentCoverageType,submissionNo);
	for(Object[] results:resultSet)
	   {
		
		if(results[0]==null && results[1]==null)
		{
			ngeException.throwException(NGEErrorCodes.NO_COMPONENT_SUBMISSION, NGEErrorCodes.ERROR_TYPE, null,null);
		}
		else{
			if(results[0].toString().equalsIgnoreCase(submissionNo)){
				ttransactionComponentId=results[1].toString();
			}else{
				ngeException.throwException(NGEErrorCodes.NO_COMPONENT_SUBMISSION, NGEErrorCodes.ERROR_TYPE, null,null);
			}
		}
		
	   }	
		
		logger.debug(":::::::::::::::::::::::::::Exiting getTransactionComponentId Method::::::::::::::::::::::");
		return ttransactionComponentId;
	}


public void checkBlockingProcessStatusCd(String transactionComponentId) throws AIGCIExceptionMsg
{
	
	String lockin=ttransactioncomponentrepository.getLockInIndicator(transactionComponentId);
	
	logger.debug(lockin);
	if(lockin!=null){
		if(lockin.equalsIgnoreCase("Y"))
		{
			ngeException.throwException(NGEErrorCodes.BLOCKED_PRODUCT_CANNOT_BE_RENEWED,NGEErrorCodes.ERROR_TYPE, null,null);
		}
		logger.debug("::::::::::::::::::Exiting blocking Process Status Code::::::::::::::::::::::");
	}
}


public Date checkBlockingExpirationDate(String transactionComponentId)
{
	
	Date blockingExpirationDate=ttransactioncomponentrepository.getBlockingExpirationDate(transactionComponentId);
	logger.debug(blockingExpirationDate);
	logger.debug("::::::::::::::::::Exiting Blocking Expiration Date::::::::::::::::::::::");
	return blockingExpirationDate;
}

public int getProductDetails(String currentProductCd) throws AIGCIExceptionMsg
{
	int minorGroupCode=0;
	TlegacyProduct tlegacyProduct=tlegacyproductrepository.getProductDetails(NGECommonUtil.convertToString(currentProductCd));
	if(null != tlegacyProduct){
		minorGroupCode=tlegacyProduct.getTlegacyMinorProductGroup().getId().getMnrProductGrpCd();
		logger.debug(minorGroupCode);
		
		String bundleTypeCd=tlegacyProduct.getBundleTypeCd();
		
		logger.debug(bundleTypeCd);
		
		if((bundleTypeCd.equalsIgnoreCase("B")))
		{
			ngeException.throwException(NGEErrorCodes.ONLY_COMPONENT_PRODUCTS_CAN_BE_RENEWED,NGEErrorCodes.ERROR_TYPE, null,null);
		}
	}else{
		AIGCIException faultInfo = new AIGCIException();
		faultInfo.setErrorType(NGEErrorCodes.ERROR_TYPE);
		throw new AIGCIExceptionMsg("E10015", faultInfo , null);
	}
	logger.debug("::::::::::::::::::::::::::::Exiting Product Details:::::::::::::::::::::::::::");
	return minorGroupCode;
}


public TlegacyProduct getProductDetail(String currentProductCd) throws AIGCIExceptionMsg
{
	
	TlegacyProduct tlegacyProduct=tlegacyproductrepository.getProductDetails(NGECommonUtil.convertToString(currentProductCd));
	if(null != tlegacyProduct){
		logger.debug("::::::::::::::::::::::::::::NoException Product Details:::::::::::::::::::::::::::");
	}else{
		logger.debug("::::::::::::::::::::::::::::Exception Product Details:::::::::::::::::::::::::::");
	}
	
	return tlegacyProduct;
}


public String checkBusinessType(String transactionComponentId) throws AIGCIExceptionMsg 
{
	String statusName=ttransactioncomponentrepository.getBusinessTypeNm(transactionComponentId);
	logger.debug(statusName);
	if(statusName!=null){
	if(!(statusName.equalsIgnoreCase(NGEConstants.ProductState.NEW) || !(statusName.equalsIgnoreCase(NGEConstants.ProductState.RENEWAL))))
	{
		ngeException.throwException(NGEErrorCodes.ONLY_NEW_OR_RENEWED_BUSINESS,NGEErrorCodes.ERROR_TYPE, null,null);
	}
	
	logger.debug("::::::::::::::::::::::::Exiting Business Type Code::::::::::::::::::::::::::::");
	}
	return statusName;
}

public List<BigDecimal> checkAttachmentPointAmtandLimitAmt(String transactionComponentId,String currentCoverageType) throws AIGCIExceptionMsg 
{
	/*P==0 ;E > 0*/
	List<BigDecimal> limitDetails = new ArrayList<BigDecimal>();
	TtransactionComponentLimit transactionComponentLimitData=ttransactioncomponentlimitrepository.getAttachmentPointAmountandLimit(transactionComponentId);
	
	//logger.debug(transactionComponentLimitData.getAttachmentPointAm()+"~~~"+transactionComponentLimitData.getLimitAm());
	if(transactionComponentLimitData!=null){
	if((transactionComponentLimitData.getAttachmentPointAm().compareTo(BigDecimal.ZERO)==0) && currentCoverageType.equalsIgnoreCase("E"))
	{
		ngeException.throwException(NGEErrorCodes.INVALID_ATTACHMENT_AND_COVERAGE,NGEErrorCodes.ERROR_TYPE, null,null);
	}
	if((transactionComponentLimitData.getAttachmentPointAm().compareTo(BigDecimal.ZERO)>0) && currentCoverageType.equalsIgnoreCase("P"))
	{
		ngeException.throwException(NGEErrorCodes.INVALID_ATTACHMENT_AND_COVERAGE,NGEErrorCodes.ERROR_TYPE, null,null);
	}
	
	logger.debug(":::::::::::::::::::::::::::::Exiting AttachmentPoint Amt::::::::::::::::::::::::");
	limitDetails.add(transactionComponentLimitData.getAttachmentPointAm());
	limitDetails.add(transactionComponentLimitData.getLimitAm());
	}
	return limitDetails;
}

public String getProductStatus(Set<TtransactionComponentStatus> transactionComponentId) throws AIGCIExceptionMsg 
{
	String status=null;
	Set<TtransactionComponentStatus> statusIdSet = transactionComponentId;
	List<TtransactionComponentStatus> statusId = null;
//	statusId=ttransactioncomponentstatusrepository.findByTtransactionComponentStatusPKTransactionComponentId(transactionComponentId);
	
	if (null != statusIdSet && !statusIdSet.isEmpty()){
		statusId = new ArrayList<TtransactionComponentStatus>(statusIdSet);
	 if(statusId.get(0).getTstatus().getStatusNm().equalsIgnoreCase(NGEConstants.LifeCycleStatus.WORKING) || statusId.get(1).getTstatus().getStatusNm().equalsIgnoreCase(NGEConstants.LifeCycleStatus.WORKING))
	   {
			if( ((statusId.get(0).getTstatus().getStatusNm().equalsIgnoreCase(NGEConstants.ReservationCondition.RESERVED)) || (statusId.get(0).getTstatus().getStatusNm().equalsIgnoreCase(NGEConstants.ReservationCondition.RELEASED))) || ((statusId.get(1).getTstatus().getStatusNm().equalsIgnoreCase(NGEConstants.ReservationCondition.RESERVED))|| ((statusId.get(1).getTstatus().getStatusNm().equalsIgnoreCase(NGEConstants.ReservationCondition.RELEASED))))){
				status=NGEConstants.LifeCycleStatus.WORKING;
			}
	    }
		
	   if(statusId.get(0).getTstatus().getStatusNm().equalsIgnoreCase(NGEConstants.LifeCycleStatus.QUOTED) || statusId.get(1).getTstatus().getStatusNm().equalsIgnoreCase(NGEConstants.LifeCycleStatus.QUOTED))
		{
			if( ((statusId.get(0).getTstatus().getStatusNm().equalsIgnoreCase(NGEConstants.ReservationCondition.RESERVED)) || (statusId.get(0).getTstatus().getStatusNm().equalsIgnoreCase(NGEConstants.ReservationCondition.RELEASED))) || ((statusId.get(1).getTstatus().getStatusNm().equalsIgnoreCase(NGEConstants.ReservationCondition.RESERVED))|| ((statusId.get(1).getTstatus().getStatusNm().equalsIgnoreCase(NGEConstants.ReservationCondition.RELEASED))))){
				status=NGEConstants.LifeCycleStatus.QUOTED;
			}
		}
	   if(statusId.get(0).getTstatus().getStatusNm().equalsIgnoreCase(NGEConstants.LifeCycleStatus.BOUND) || statusId.get(1).getTstatus().getStatusNm().equalsIgnoreCase(NGEConstants.LifeCycleStatus.BOUND))
		{
			if( ((statusId.get(0).getTstatus().getStatusNm().equalsIgnoreCase(NGEConstants.ReservationCondition.RESERVED)) || (statusId.get(0).getTstatus().getStatusNm().equalsIgnoreCase(NGEConstants.ReservationCondition.RELEASED))) || ((statusId.get(1).getTstatus().getStatusNm().equalsIgnoreCase(NGEConstants.ReservationCondition.RESERVED))|| ((statusId.get(1).getTstatus().getStatusNm().equalsIgnoreCase(NGEConstants.ReservationCondition.RELEASED))))){
				status=NGEConstants.LifeCycleStatus.BOUND;
			}
		}
	   if(statusId.get(0).getTstatus().getStatusNm().equalsIgnoreCase(NGEConstants.LifeCycleStatus.DECLINED) || statusId.get(1).getTstatus().getStatusNm().equalsIgnoreCase(NGEConstants.LifeCycleStatus.DECLINED))
		{
			status=NGEConstants.LifeCycleStatus.DECLINED;
		}
	   if(statusId.get(0).getTstatus().getStatusNm().equalsIgnoreCase(NGEConstants.LifeCycleStatus.VOID) || statusId.get(1).getTstatus().getStatusNm().equalsIgnoreCase(NGEConstants.LifeCycleStatus.VOID))
		{
			status=NGEConstants.LifeCycleStatus.VOID;
		}
	   if(statusId.get(0).getTstatus().getStatusNm().equalsIgnoreCase(NGEConstants.ReservationCondition.BLOCKED) || statusId.get(1).getTstatus().getStatusNm().equalsIgnoreCase(NGEConstants.ReservationCondition.BLOCKED))
		{
			status=NGEConstants.ReservationCondition.BLOCKED;
		}
		
		if(status==null)
		{
			ngeException.throwException(NGEErrorCodes.INVALID_STATUS,NGEErrorCodes.ERROR_TYPE, null,null);
		}
		
		logger.debug("::::::::::::Exiting Status A Code:::::::::::::::");
		}
	    return status;
	
}

public int getQuotedWipCounts(String transactionComponentId) throws AIGCIExceptionMsg 
{
		int quotedWipCounts=tlegacywipquoterepository.getCountQuotedWips(transactionComponentId);
		logger.debug(quotedWipCounts);
		
	return quotedWipCounts;
}


public int getBoundedWipCounts(String transactionComponentId) throws AIGCIExceptionMsg 
{
		int boundededWipCounts=tlegacywipquoterepository.getCountBoundedWips(transactionComponentId);
		logger.debug(boundededWipCounts);
		
	return boundededWipCounts;
}

public int getWipCounts(String transactionComponentId) throws AIGCIExceptionMsg 
{

	ArrayList<TlegacyWipQuote> wip=new ArrayList<TlegacyWipQuote>();
	wip=tlegacywipquoterepository.getWipCount(transactionComponentId);
	return wip.size();
}

public String getBusinessIndicator(String transactionComponentId)
{
	List<TtransactionComponentAtrbt> businessTypeIndicator=ttransactionComponentAtrbtRepository.findBusTypeByTransactionComponentIdAndAttributeId(transactionComponentId,NGEConstants.BusinessType.DIRECT_OR_ASSUMED);
	String attributeVal=null;
	if(businessTypeIndicator.size()>0){
		logger.debug(businessTypeIndicator.get(0).getAttributeVal());
		logger.debug("::::::::::::::::::Exiting Business Type Indicator::::::::::::::::::::::");
		attributeVal=businessTypeIndicator.get(0).getAttributeVal();
	}
	return attributeVal;
}

public String getTransactionComponentIdBasedOnPolicyDetails(RenewalProductChangeRequest renewalProductChangeRequestParameter) throws AIGCIExceptionMsg
{
	return null;/*
	ArrayList<TlegacyWipQuote>wipQuote=new ArrayList<TlegacyWipQuote>();
	
	Tpolicy tpolicy=new Tpolicy();
	String transactionComponentId=null;
	String policyEffDate=null;
	String policyExpDate=null;
	String effCal = renewalProductChangeRequestParameter.getRenewalPolicyInfo().getRenewalEffectiveDate();
	//java.util.Date effDate = effCal.toGregorianCalendar().getTime();
	String expCal = renewalProductChangeRequestParameter.getRenewalPolicyInfo().getRenewalExpirationDate();
	//java.util.Date expDate = expCal.toGregorianCalendar().getTime();
 
	ArrayList<Tpolicy> tpolicyPrior=tpolicyrepository.findPolicy(renewalProductChangeRequestParameter.getRenewalPolicyInfo().getRenewalPolicyNo(),effCal,renewalProductChangeRequestParameter.getRenewalPolicyInfo().getRenewalPriorIssuingCompany());
	
	for(int i=0;i<tpolicyPrior.size();i++)
	{
		
		//gets current policyIds
		wipQuote=tlegacywipquoterepository.getPolicyNo(tpolicyPrior.get(i).getPolicyId()); 
		
		for(int j=0;j<wipQuote.size();j++)
		{
		// gets one current policy based on id, eff and exp dates.
			tpolicy=tpolicyrepository.getPolicyBasedOnDate(wipQuote.get(j).getPolicyId(),effDate, expDate); //gets actual policies
		}
	
	}
	transactionComponentId=ttransctioncomponentpolicyrepository.getTransactionComponentId(tpolicy.getPolicyId());
          
	return transactionComponentId;
	
*/}

	public void checkIfPresentUnderSubmissionNo(String transactionComponentId,String submissionNo) throws AIGCIExceptionMsg
	{
		boolean flag=false;
		List<Tsubmission>submissions=new ArrayList<Tsubmission>();
		
		submissions=tsubmissionrepository.checkIfPresentUnderSubmission(transactionComponentId);
		
		for(int i=0;i<submissions.size();i++)
	   {
		if(submissions.get(i).getSubmissionNo().equalsIgnoreCase(submissionNo.toString()))
		{
			flag=true;
		}
	  }
		if(flag==false)
		{
			ngeException.throwException(NGEErrorCodes.NO_RECORDS,NGEErrorCodes.ERROR_TYPE, null, null);

		}
		
	}

	public TtransactionComponent getTransactionIdAndVersion(String transactionComponentIdS) 
	{
	

		 TtransactionComponent ttransactionComponent=ttransactioncomponentrepository.getTransactionIdAndVersion(transactionComponentIdS);
		
		return ttransactionComponent;
	}

	public TtransactionComponentLimit getComponentLimits(String transactionComponentIdS) 
	{
	
		TtransactionComponentLimit ttransactionComponentLimit=ttransactioncomponentlimitrepository.findByTransactionComponentId(transactionComponentIdS);
	    return ttransactionComponentLimit;

	}

	public TlegacyTrnsctnCmpntXtensn getComponentProducts(String productCode)
	{
		//List<TlegacyTrnsctnCmpntXtensn> tlegacyTrnsctnCmpntXtensn=tlegacytrnsctncmpntxtensnrepository.getComponentProductList(transactionComponentIdR,productCode);
		TlegacyTrnsctnCmpntXtensn tlegacyTrnsctnCmpntXtensn=tlegacytrnsctncmpntxtensnrepository.fetchByTransactionId(productCode);
	
		return tlegacyTrnsctnCmpntXtensn;
	
	}
	public TlegacyTrnsctnCmpntXtensn getComponentNewProducts(String productCode)
	{
		//List<TlegacyTrnsctnCmpntXtensn> tlegacyTrnsctnCmpntXtensn=tlegacytrnsctncmpntxtensnrepository.getComponentProductList(transactionComponentIdR,productCode);
		TlegacyTrnsctnCmpntXtensn tlegacyTrnsctnCmpntXtensn=tlegacytrnsctncmpntxtensnrepository.fetchByTransactionId(productCode);
	
		return tlegacyTrnsctnCmpntXtensn;
	
	}
	public TlegacyTrnsctnCmpntXtensn saveTlegacytrnsctncmpntxtensn(TlegacyTrnsctnCmpntXtensn tlegacyTrnsctnCmpntXtensn){
		/* Exadata changes - Not null issue starts */
		if(tlegacyTrnsctnCmpntXtensn.getDeclineReasonCd() != null){
			if(tlegacyTrnsctnCmpntXtensn.getDeclineReasonCd().trim().equals(NGEConstants.EMPTY_STRING))
				tlegacyTrnsctnCmpntXtensn.setDeclineReasonCd(NGEConstants.EMPTY_SPACE);
		}
		
		if(tlegacyTrnsctnCmpntXtensn.getSpecialEventNm() != null){
			if(tlegacyTrnsctnCmpntXtensn.getSpecialEventNm().trim().equals(NGEConstants.EMPTY_STRING))
				tlegacyTrnsctnCmpntXtensn.setSpecialEventNm(NGEConstants.EMPTY_SPACE);
		}
		/* Exadata changes - Not null issue ends */
		return tlegacytrnsctncmpntxtensnrepository.save(tlegacyTrnsctnCmpntXtensn);
	}

	public boolean checkProductExists(String transactionComponentIdR) {
		boolean productExists;
		if(transactionComponentIdR!=null){
			productExists=true;
		}else{
			productExists=false;
		}
		return productExists;
	}

	public boolean checkProductSame(String transactionComponentIdR,
			String transactionComponentIdS) {
		boolean productSame = false;
		if(transactionComponentIdR!=null){
			if(transactionComponentIdR.equalsIgnoreCase(transactionComponentIdS)){
				productSame=true;
			}else{
				productSame=false;
			}
		}
		return productSame;
	}

	public String getMonlineProduct(String currentProductCd,
			String currentCoverageType, String transactionId) {
		// TODO Auto-generated method stub
		return tlegacytrnsctncmpntxtensnrepository.getMonolineTransactionCmpId(currentProductCd.trim(), currentCoverageType.trim(), transactionId.trim());
	}

	public List<Object[]>  retrieveSegAndSubSegDsp(String productCd,String profictCentreCd,String sourceCd,String sectionCd,String profitUnitCd, String covTypeCd) {
		
		return tLegacyProductMappingRepository.getSegAndSubSeg(NGECommonUtil.convertToString(productCd), NGECommonUtil.convertToString(profictCentreCd), NGECommonUtil.convertToString(sourceCd), sectionCd, profitUnitCd,  covTypeCd);
		
	}
	
	public TlegacyTrnsctnCmpntXtensn fetchByTransactionComponentId(String transactionComponentId) {
		// TODO Auto-generated method stub
		return tlegacytrnsctncmpntxtensnrepository.fetchByTransactionId(transactionComponentId);
	}
	
	public TtransactionComponent fetchByTransComponentId(String transactionComponentId) {
		// TODO Auto-generated method stub
		return ttransactioncomponentrepository.findByTransactionComponentId(transactionComponentId);
	}

	public void updateComponentAndExt(TtransactionComponent transactionComponent) throws AIGCIExceptionMsg{
		
		/*TlegacyTrnsctnCmpntXtensn extension = transactionComponent.getTlegacyTrnsctnCmpntXtensn();
		int updateCount =  ttransactioncomponentrepository.updateLegacyInd(transactionComponent.getTransactionComponentId(),transactionComponent.getLegacyIn());
		if(updateCount > 0){
			String query =" INSERT INTO TLEGACY_TRNSCTN_CMPNT_XTENSN "+ 
						  " ( TRANSACTION_COMPONENT_ID,LEGACY_PRODUCT_CD," +
						  "   LEGACY_PRODCT_COVG_TYP_CD,LEGACY_BUNDLED_PRODUCT_CD, "+
						  "   SECTION_CD,PROFIT_UNIT_CD,PART_OF_AM," +
						  "   XCHANGE_RT_EFCTV_DT,CREATE_USER_ID," +
						  "   CREATE_TS,UPDATE_USER_ID, "+
						  "   UPDATE_TS,LOCAL_PART_OF_AM," +
						  "   SOURCE_CD,WORKING_BRANCH_CD," +
						  "   PROFIT_CENTER_CD,RR_PRTCTV_CONT_NO, "+
						  "   SPECIAL_EVENT_NM,UNDERWRITING_DT," +
						  "   DECLINE_REASON_CD,CURRNT_BUS_TYP_CD )  "+
						  " (" +extension.getTransactionComponentId()+ "," +extension.getTlegacyProduct().getProductCd()+ ","+
						  " " +extension.getLegacyProdctCovgTypCd()+ "," +null+ ","+
						  " " +extension.getSectionCd()+ "," +extension.getProfitUnitCd()+ "," +extension.getPartOfAm()+ ","+
						  " " +extension.getXchangeRtEfctvDt()+ "," +extension.getCreateUserId()+ ","+
						  " " +extension.getCreateTs()+ "," +extension.getUpdateUserId()+ ","+
						  " " +extension.getUpdateTs()+ "," +extension.getLocalPartOfAm()+ ","+
						  " )";  
			int x  = em.createNativeQuery(query).executeUpdate();
			logger.debug("tlegacy_wip_quote inserted with " + x);*/

		/* Exadata changes - Not null issue starts */
		if(transactionComponent.getTlegacyTrnsctnCmpntXtensn().getDeclineReasonCd() != null){
			if(transactionComponent.getTlegacyTrnsctnCmpntXtensn().getDeclineReasonCd().trim().equals(NGEConstants.EMPTY_STRING))
				transactionComponent.getTlegacyTrnsctnCmpntXtensn().setDeclineReasonCd(NGEConstants.EMPTY_SPACE);
		}
		
		if(transactionComponent.getTlegacyTrnsctnCmpntXtensn().getSpecialEventNm() != null){
			if(transactionComponent.getTlegacyTrnsctnCmpntXtensn().getSpecialEventNm().trim().equals(NGEConstants.EMPTY_STRING))
				transactionComponent.getTlegacyTrnsctnCmpntXtensn().setSpecialEventNm(NGEConstants.EMPTY_SPACE);
		}

		/* Exadata changes - Not null issue ends */
		tlegacytrnsctncmpntxtensnrepository.save(transactionComponent.getTlegacyTrnsctnCmpntXtensn());
			
		}

	public void saveTblockH(Set<TblockH> tblockHSet) {
		tBlockHRepository.save(tblockHSet);		
	}
	
	public void saveTblockH(TblockH tblockH) {
		tBlockHRepository.save(tblockH);		
	}

	public List<TlegacyWipQuote> saveLostWips(Set<TlegacyWipQuote> legacyWipQuotesSetModified) {
		return tlegacywipquoterepository.save(legacyWipQuotesSetModified);
	}
	
	public void deleteWips(Set<TlegacyWipQuote> legacyWipQuotesSetModified) {
		 tlegacywipquoterepository.delete(legacyWipQuotesSetModified);
	}

	public void saveLostWipsHistory(Set<TlegacyWipQuoteH> legacyWipQuoteHistSet) {
		tLegacyWIPQuoteHsRepository.save(legacyWipQuoteHistSet);		
	}

	public Tstatus retrieveStatusId(String statusName) {
		// TODO Auto-generated method stub
		
		/*
		* EXADATA Migration Changes
		* 		Adding space for status name 
		*/

		if(statusName.equals(NGEConstants.EMPTY_STRING))
			statusName = NGEConstants.EMPTY_SPACE;
		
		return tStatusRepository.findByStatusNm(statusName);
	}

	public void updateTblock(List<Tblock> tblocklist) {
		Iterator<Tblock> tblockIter = null;
		Tblock tblock = null;
		if(null != tblocklist && !tblocklist.isEmpty()){
			tblockIter = tblocklist.iterator();
			while(tblockIter.hasNext()){
				tblock = tblockIter.next();
				/* Exadata changes - Not null issue starts */
				if(tblock.getCommentTx() != null){
					if(tblock.getCommentTx().trim().equals(NGEConstants.EMPTY_STRING))
						tblock.setCommentTx(NGEConstants.EMPTY_SPACE);
				}
				/* Exadata changes - Not null issue ends */
				tBlockRepository.saveAndFlush(tblock);
			}
		}
		
	}

	public void updateTComponentBlock(Set<TcomponentBlock> componentBlockSetTemp) {
		Iterator<TcomponentBlock> tcomponentBlockIter = null;
		TcomponentBlock tcomponentBlock = null;
		if(null != componentBlockSetTemp && !componentBlockSetTemp.isEmpty()){
			tcomponentBlockIter = componentBlockSetTemp.iterator();
			while(tcomponentBlockIter.hasNext()){
				tcomponentBlock = tcomponentBlockIter.next();
				tComponentBlockRepository.saveAndFlush(tcomponentBlock);
			}
		}
		
		
	}
	
	}




	

	
	
	

