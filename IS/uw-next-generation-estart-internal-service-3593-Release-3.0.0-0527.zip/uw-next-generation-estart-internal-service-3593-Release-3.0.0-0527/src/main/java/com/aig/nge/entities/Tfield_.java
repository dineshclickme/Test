package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SetAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-02-19T16:13:03.445+0530")
@StaticMetamodel(Tfield.class)
public class Tfield_ {
	public static volatile SingularAttribute<Tfield, Short> fieldId;
	public static volatile SingularAttribute<Tfield, Timestamp> createTs;
	public static volatile SingularAttribute<Tfield, String> createUserId;
	public static volatile SingularAttribute<Tfield, String> fieldDs;
	public static volatile SingularAttribute<Tfield, String> fieldNm;
	public static volatile SingularAttribute<Tfield, Timestamp> updateTs;
	public static volatile SingularAttribute<Tfield, String> updateUserId;
	public static volatile SetAttribute<Tfield, TscreenField> tscreenFields;
	public static volatile SetAttribute<Tfield, TfieldLanguage> tfieldLanguages;
}
