package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the TLEGACY_SUBMISSION_ADDL_INFO database table.
 * 
 */
@Entity
@Table(name="TLEGACY_SUBMISSION_ADDL_INFO")
public class TlegacySubmissionAddlInfo implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private TlegacySubmissionAddlInfoPK id;

	@Column(name="ADDRESS_1_TX")
	private String address1Tx;

	@Column(name="ADDRESS_2_TX")
	private String address2Tx;

	@Column(name="CITY_NM")
	private String cityNm;

	@Column(name="COUNTRY_CD")
	private String countryCd;

	@Column(name="CREATE_TS")
	private Timestamp createTs;

	@Column(name="CREATE_USER_ID")
	private String createUserId;

	@Column(name="POSTAL_CD")
	private String postalCd;

	@Column(name="STATE_CD")
	private String stateCd;

	@Column(name="UPDATE_TS")
	private Timestamp updateTs;

	@Column(name="UPDATE_USER_ID")
	private String updateUserId;

	//bi-directional many-to-one association to TlegacySubmissionExtension
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="SUBMISSION_NO")
	private TlegacySubmissionExtension tlegacySubmissionExtension;

    public TlegacySubmissionAddlInfo() {
    }

	public TlegacySubmissionAddlInfoPK getId() {
		return this.id;
	}

	public void setId(TlegacySubmissionAddlInfoPK id) {
		this.id = id;
	}
	
	public String getAddress1Tx() {
		if(this.address1Tx != null)
			return this.address1Tx.trim();
		else
			return this.address1Tx;
	}

	public void setAddress1Tx(String address1Tx) {
		this.address1Tx = address1Tx;
	}

	public String getAddress2Tx() {
		return this.address2Tx;
	}

	public void setAddress2Tx(String address2Tx) {
		this.address2Tx = address2Tx;
	}

	public String getCityNm() {
		if(this.cityNm != null)
			return this.cityNm.trim();
		else
			return this.cityNm;
	}

	public void setCityNm(String cityNm) {
		this.cityNm = cityNm;
	}

	public String getCountryCd() {
		if(this.countryCd != null)
			return this.countryCd.trim();
		else
			return this.countryCd;
	}

	public void setCountryCd(String countryCd) {
		this.countryCd = countryCd;
	}

	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public String getPostalCd() {
		if(this.postalCd != null)
			return this.postalCd.trim();
		else
			return this.postalCd;
	}

	public void setPostalCd(String postalCd) {
		this.postalCd = postalCd;
	}

	public String getStateCd() {
		if(this.stateCd != null)
			return this.stateCd.trim();
		else
			return this.stateCd;
	}

	public void setStateCd(String stateCd) {
		this.stateCd = stateCd;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public TlegacySubmissionExtension getTlegacySubmissionExtension() {
		return this.tlegacySubmissionExtension;
	}

	public void setTlegacySubmissionExtension(TlegacySubmissionExtension tlegacySubmissionExtension) {
		this.tlegacySubmissionExtension = tlegacySubmissionExtension;
	}
	
}