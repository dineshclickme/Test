package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Date;
import java.util.Set;


/**
 * The persistent class for the TLEGACY_PROFIT_CENTER_PRODUCT database table.
 * 
 */
@Entity
@Table(name="TLEGACY_PROFIT_CENTER_PRODUCT")
public class TlegacyProfitCenterProduct implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private TlegacyProfitCenterProductPK id;

	@Column(name="AUTO_CLOSE_DAYS_CT")
	private short autoCloseDaysCt;

	@Column(name="BYPASS_BLOCKING_IN")
	private String bypassBlockingIn;

	@Column(name="CREATED_BY_ID")
	private String createdById;

	@Column(name="CROSS_SELLING_IN")
	private String crossSellingIn;

	@Column(name="DSP_REQUIRED_IN")
	private String dspRequiredIn;

	@Column(name="DSP_TABLE_CD")
	private String dspTableCd;

    @Temporal( TemporalType.DATE)
	@Column(name="ENTERED_DT")
	private Date enteredDt;

	@Column(name="LAST_UPDT_TS")
	private Timestamp lastUpdtTs;

	@Column(name="LAST_UPDT_USER_ID")
	private String lastUpdtUserId;

	@Column(name="MAX_AUTOCLS_EXT_CT")
	private short maxAutoclsExtCt;

	@Column(name="MULTIPLE_WIP_IN")
	private String multipleWipIn;

	@Column(name="POL_BACKDT_DAYS_CT")
	private short polBackdtDaysCt;

    @Temporal( TemporalType.DATE)
	@Column(name="PRF_CTR_PRD_EFV_DT")
	private Date prfCtrPrdEfvDt;

    @Temporal( TemporalType.DATE)
	@Column(name="PRF_CTR_PRD_XPN_DT")
	private Date prfCtrPrdXpnDt;

	@Column(name="PRODUCT_SYNONYM_NM")
	private String productSynonymNm;

	@Column(name="PRODUCTION_IN")
	private String productionIn;

	@Column(name="WRAP_UP_IN")
	private String wrapUpIn;

	//bi-directional many-to-one association to TlegacyMgaProduct
	@OneToMany(mappedBy="tlegacyProfitCenterProduct")
	private Set<TlegacyMgaProduct> tlegacyMgaProducts;

	//bi-directional many-to-one association to TlegacyProductMapping
	@OneToMany(mappedBy="tlegacyProfitCenterProduct")
	private Set<TlegacyProductMapping> tlegacyProductMappings;

	//bi-directional many-to-one association to TlegacyProduct
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="PRODUCT_CD")
	private TlegacyProduct tlegacyProduct;

	//bi-directional many-to-one association to Tsource
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="SOURCE_CD")
	private Tsource tsource;

    public TlegacyProfitCenterProduct() {
    }

	public TlegacyProfitCenterProductPK getId() {
		return this.id;
	}

	public void setId(TlegacyProfitCenterProductPK id) {
		this.id = id;
	}
	
	public short getAutoCloseDaysCt() {
		return this.autoCloseDaysCt;
	}

	public void setAutoCloseDaysCt(short autoCloseDaysCt) {
		this.autoCloseDaysCt = autoCloseDaysCt;
	}

	public String getBypassBlockingIn() {
		if(this.bypassBlockingIn != null)
			return this.bypassBlockingIn.trim();
		else
			return this.bypassBlockingIn;
	}

	public void setBypassBlockingIn(String bypassBlockingIn) {
		this.bypassBlockingIn = bypassBlockingIn;
	}

	public String getCreatedById() {
		return this.createdById;
	}

	public void setCreatedById(String createdById) {
		this.createdById = createdById;
	}

	public String getCrossSellingIn() {
		if(this.crossSellingIn != null)
			return this.crossSellingIn.trim();
		else
			return this.crossSellingIn;
	}

	public void setCrossSellingIn(String crossSellingIn) {
		this.crossSellingIn = crossSellingIn;
	}

	public String getDspRequiredIn() {
		if(this.dspRequiredIn != null)
			return this.dspRequiredIn.trim();
		else
			return this.dspRequiredIn;
	}

	public void setDspRequiredIn(String dspRequiredIn) {
		this.dspRequiredIn = dspRequiredIn;
	}

	public String getDspTableCd() {
		if(this.dspTableCd != null)
			return this.dspTableCd.trim();
		else
			return this.dspTableCd;
	}

	public void setDspTableCd(String dspTableCd) {
		this.dspTableCd = dspTableCd;
	}

	public Date getEnteredDt() {
		return this.enteredDt;
	}

	public void setEnteredDt(Date enteredDt) {
		this.enteredDt = enteredDt;
	}

	public Timestamp getLastUpdtTs() {
		return this.lastUpdtTs;
	}

	public void setLastUpdtTs(Timestamp lastUpdtTs) {
		this.lastUpdtTs = lastUpdtTs;
	}

	public String getLastUpdtUserId() {
		return this.lastUpdtUserId;
	}

	public void setLastUpdtUserId(String lastUpdtUserId) {
		this.lastUpdtUserId = lastUpdtUserId;
	}

	public short getMaxAutoclsExtCt() {
		return this.maxAutoclsExtCt;
	}

	public void setMaxAutoclsExtCt(short maxAutoclsExtCt) {
		this.maxAutoclsExtCt = maxAutoclsExtCt;
	}

	public String getMultipleWipIn() {
		if(this.multipleWipIn != null)
			return this.multipleWipIn.trim();
		else
			return this.multipleWipIn;
	}

	public void setMultipleWipIn(String multipleWipIn) {
		this.multipleWipIn = multipleWipIn;
	}

	public short getPolBackdtDaysCt() {
		return this.polBackdtDaysCt;
	}

	public void setPolBackdtDaysCt(short polBackdtDaysCt) {
		this.polBackdtDaysCt = polBackdtDaysCt;
	}

	public Date getPrfCtrPrdEfvDt() {
		return this.prfCtrPrdEfvDt;
	}

	public void setPrfCtrPrdEfvDt(Date prfCtrPrdEfvDt) {
		this.prfCtrPrdEfvDt = prfCtrPrdEfvDt;
	}

	public Date getPrfCtrPrdXpnDt() {
		return this.prfCtrPrdXpnDt;
	}

	public void setPrfCtrPrdXpnDt(Date prfCtrPrdXpnDt) {
		this.prfCtrPrdXpnDt = prfCtrPrdXpnDt;
	}

	public String getProductSynonymNm() {
		if(this.productSynonymNm != null)
			return this.productSynonymNm.trim();
		else
			return this.productSynonymNm;
	}

	public void setProductSynonymNm(String productSynonymNm) {
		this.productSynonymNm = productSynonymNm;
	}

	public String getProductionIn() {
		if(this.productionIn != null)
			return this.productionIn.trim();
		else
			return this.productionIn;
	}

	public void setProductionIn(String productionIn) {
		this.productionIn = productionIn;
	}

	public String getWrapUpIn() {
		if(this.wrapUpIn != null)
			return this.wrapUpIn.trim();
		else
			return this.wrapUpIn;
	}

	public void setWrapUpIn(String wrapUpIn) {
		this.wrapUpIn = wrapUpIn;
	}

	public Set<TlegacyMgaProduct> getTlegacyMgaProducts() {
		return this.tlegacyMgaProducts;
	}

	public void setTlegacyMgaProducts(Set<TlegacyMgaProduct> tlegacyMgaProducts) {
		this.tlegacyMgaProducts = tlegacyMgaProducts;
	}
	
	public Set<TlegacyProductMapping> getTlegacyProductMappings() {
		return this.tlegacyProductMappings;
	}

	public void setTlegacyProductMappings(Set<TlegacyProductMapping> tlegacyProductMappings) {
		this.tlegacyProductMappings = tlegacyProductMappings;
	}
	
	public TlegacyProduct getTlegacyProduct() {
		return this.tlegacyProduct;
	}

	public void setTlegacyProduct(TlegacyProduct tlegacyProduct) {
		this.tlegacyProduct = tlegacyProduct;
	}
	
	public Tsource getTsource() {
		return this.tsource;
	}

	public void setTsource(Tsource tsource) {
		this.tsource = tsource;
	}
	
}