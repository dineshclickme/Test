package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the TPROPERTY database table.
 * 
 */
@Embeddable
public class TpropertyPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="SYSTEM_ID")
	private short systemId;

	@Column(name="EVIRONMENT_NM")
	private String evironmentNm;

	@Column(name="PROPERTY_NM")
	private String propertyNm;

    public TpropertyPK() {
    }
	public short getSystemId() {
		return this.systemId;
	}
	public void setSystemId(short systemId) {
		this.systemId = systemId;
	}
	public String getEvironmentNm() {
		return this.evironmentNm;
	}
	public void setEvironmentNm(String evironmentNm) {
		this.evironmentNm = evironmentNm;
	}
	public String getPropertyNm() {
		return this.propertyNm;
	}
	public void setPropertyNm(String propertyNm) {
		this.propertyNm = propertyNm;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof TpropertyPK)) {
			return false;
		}
		TpropertyPK castOther = (TpropertyPK)other;
		return 
			(this.systemId == castOther.systemId)
			&& this.evironmentNm.equals(castOther.evironmentNm)
			&& this.propertyNm.equals(castOther.propertyNm);

    }
    
	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + ((int) this.systemId);
		hash = hash * prime + this.evironmentNm.hashCode();
		hash = hash * prime + this.propertyNm.hashCode();
		
		return hash;
    }
}