package com.aig.nge.entities;

import java.io.Serializable;

import javax.persistence.Column;


public class BlockingStoredProcResult implements Serializable{
	private static final long serialVersionUID = 1L;
	
	@Column(name="TRANSACTION_ID")
	private Long TRANSACTION_ID;
	
	@Column(name="VERSION_SQN")
	private short VERSION_SQN;
	
	@Column(name="TRANSACTION_COMPONENT_ID")
	private Long TRANSACTION_COMPONENT_ID;	
		
	@Column(name="EXCLUDE_IN")
	private String EXCLUDE_IN;

	 public String getEXCLUDE_IN() {
		return EXCLUDE_IN;
	}

	public void setEXCLUDE_IN(String eXCLUDE_IN) {
		EXCLUDE_IN = eXCLUDE_IN;
	}

	public BlockingStoredProcResult() {
		 
	 }
	
	public Long getTRANSACTION_ID() {
		return TRANSACTION_ID;
	}

	public void setTRANSACTION_ID(Long tRANSACTION_ID) {
		TRANSACTION_ID = tRANSACTION_ID;
	}

	public short getVERSION_SQN() {
		return VERSION_SQN;
	}

	public void setVERSION_SQN(short vERSION_SQN) {
		VERSION_SQN = vERSION_SQN;
	}

	public Long getTRANSACTION_COMPONENT_ID() {
		return TRANSACTION_COMPONENT_ID;
	}

	public void setTRANSACTION_COMPONENT_ID(Long tRANSACTION_COMPONENT_ID) {
		TRANSACTION_COMPONENT_ID = tRANSACTION_COMPONENT_ID;
	}

	@Override
	public String toString() {
		return "BlockingStoredProcResult [TRANSACTION_ID=" + TRANSACTION_ID
				+ ", VERSION_SQN=" + VERSION_SQN
				+ ", TRANSACTION_COMPONENT_ID=" + TRANSACTION_COMPONENT_ID
				+ ", EXCLUDE_IN=" + EXCLUDE_IN + "]";
	}
	
}
