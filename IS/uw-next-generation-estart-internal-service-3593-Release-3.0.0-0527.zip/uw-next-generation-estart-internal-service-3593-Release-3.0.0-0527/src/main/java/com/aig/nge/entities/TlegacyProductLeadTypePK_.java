package com.aig.nge.entities;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-04-15T15:31:47.119+0530")
@StaticMetamodel(TlegacyProductLeadTypePK.class)
public class TlegacyProductLeadTypePK_ {
	public static volatile SingularAttribute<TlegacyProductLeadTypePK, String> transactionComponentId;
	public static volatile SingularAttribute<TlegacyProductLeadTypePK, String> sourceCd;
	public static volatile SingularAttribute<TlegacyProductLeadTypePK, String> leadTypeCd;
	public static volatile SingularAttribute<TlegacyProductLeadTypePK, String> leadSubtypeCd;
}
