package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;

import org.apache.openjpa.persistence.DataCache;
import java.sql.Timestamp;
import java.util.Set;


/**
 * The persistent class for the TSEGMENT database table.
 * 
 */
@Entity
@DataCache
public class Tsegment implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="SEGMENT_CD")
	private String segmentCd;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="CREATE_TS")
	private Timestamp createTs;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="CREATE_USER_ID")
	private String createUserId;

	@Column(name="SEGMENT_NM")
	private String segmentNm;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="UPDATE_TS")
	private Timestamp updateTs;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="UPDATE_USER_ID")
	private String updateUserId;

	//bi-directional many-to-one association to TproductTower
	@OneToMany(mappedBy="tsegment1", cascade={CascadeType.ALL})
	private Set<TproductTower> tproductTowers1;

	//bi-directional many-to-one association to TproductTower
	@OneToMany(mappedBy="tsegment2", cascade={CascadeType.ALL})
	private Set<TproductTower> tproductTowers2;

    public Tsegment() {
    }

	public String getSegmentCd() {
		return this.segmentCd;
	}

	public void setSegmentCd(String segmentCd) {
		this.segmentCd = segmentCd;
	}

	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public String getSegmentNm() {
		return this.segmentNm;
	}

	public void setSegmentNm(String segmentNm) {
		this.segmentNm = segmentNm;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}
	
	public Set<TproductTower> getTproductTowers1() {
		return this.tproductTowers1;
	}

	public void setTproductTowers1(Set<TproductTower> tproductTowers1) {
		this.tproductTowers1 = tproductTowers1;
	}
	
	public Set<TproductTower> getTproductTowers2() {
		return this.tproductTowers2;
	}

	public void setTproductTowers2(Set<TproductTower> tproductTowers2) {
		this.tproductTowers2 = tproductTowers2;
	}
	
}