package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Set;


/**
 * The persistent class for the THELP database table.
 * 
 */
@Entity
public class Thelp implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="HELP_ID")
	private int helpId;

	@Column(name="CREATE_TS")
	private Timestamp createTs;

	@Column(name="CREATE_USER_ID")
	private String createUserId;

	@Column(name="HELP_DS")
	private String helpDs;

	@Column(name="HELP_TX")
	private String helpTx;

	@Column(name="UPDATE_TS")
	private Timestamp updateTs;

	@Column(name="UPDATE_USER_ID")
	private String updateUserId;

	//bi-directional many-to-one association to ThelpLanguage
	@OneToMany(mappedBy="thelp", cascade={CascadeType.ALL})
	private Set<ThelpLanguage> thelpLanguages;

	//bi-directional many-to-one association to TscreenField
	@OneToMany(mappedBy="thelp", cascade={CascadeType.ALL})
	private Set<TscreenField> tscreenFields;

    public Thelp() {
    }

	public int getHelpId() {
		return this.helpId;
	}

	public void setHelpId(int helpId) {
		this.helpId = helpId;
	}

	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public String getHelpDs() {
		return this.helpDs;
	}

	public void setHelpDs(String helpDs) {
		this.helpDs = helpDs;
	}

	public String getHelpTx() {
		if(this.helpTx != null)
			return this.helpTx.trim();
		else
			return this.helpTx;
	}

	public void setHelpTx(String helpTx) {
		this.helpTx = helpTx;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public Set<ThelpLanguage> getThelpLanguages() {
		return this.thelpLanguages;
	}

	public void setThelpLanguages(Set<ThelpLanguage> thelpLanguages) {
		this.thelpLanguages = thelpLanguages;
	}
	
	public Set<TscreenField> getTscreenFields() {
		return this.tscreenFields;
	}

	public void setTscreenFields(Set<TscreenField> tscreenFields) {
		this.tscreenFields = tscreenFields;
	}
	
}