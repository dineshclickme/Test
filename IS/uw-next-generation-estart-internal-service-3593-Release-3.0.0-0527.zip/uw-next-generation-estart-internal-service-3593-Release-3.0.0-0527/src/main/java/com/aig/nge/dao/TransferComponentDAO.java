package com.aig.nge.dao;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.aig.nge.entities.TlegacyProductBundling;
import com.aig.nge.entities.TlegacyProductBundlingPK;
import com.aig.nge.entities.TlegacyProfitCenterProduct;
import com.aig.nge.entities.TlegacyTrnsctnCmpntXtensn;
import com.aig.nge.entities.TlegacyTrnsctnCmpntXtnsnH;
import com.aig.nge.entities.TlegacyWipQuote;
import com.aig.nge.entities.TlegacyWipQuoteCurrency;
import com.aig.nge.entities.TlegacyWipQuoteCurrencyH;
import com.aig.nge.entities.TlegacyWipQuoteCurrencyHPK;
import com.aig.nge.entities.TlegacyWipQuoteH;
import com.aig.nge.entities.TlegacyWipQuoteHPK;
import com.aig.nge.entities.TlegacyWipQuotePK;
import com.aig.nge.entities.Tparty;
import com.aig.nge.entities.TproductState;
import com.aig.nge.entities.Tsubmission;
import com.aig.nge.entities.TtransactionComponent;
import com.aig.nge.entities.TtransactionComponentAtrbt;
import com.aig.nge.entities.TtransactionComponentH;
import com.aig.nge.entities.TtransactionComponentPolicy;
import com.aig.nge.entities.TtransactionComponentStatH;
import com.aig.nge.entities.TtransactionComponentStatus;
import com.aig.nge.entities.VcomponentProduct;
import com.aig.nge.entities.VcomponentProductPK;
import com.aig.nge.repository.TLegacyProductMappingRepository;
import com.aig.nge.repository.TLegacyWIPQuoteHsRepository;
import com.aig.nge.repository.TLegacyWipQuoteRepository;
import com.aig.nge.repository.TPartyRepository;
import com.aig.nge.repository.TSubmissionRepository;
import com.aig.nge.repository.TTransactionComponentAtrbtRepository;
import com.aig.nge.repository.TTransactionComponentHRepository;
import com.aig.nge.repository.TTransactionComponentPolicyRepository;
import com.aig.nge.repository.TTransactionComponentRepository;
import com.aig.nge.repository.TTransactionComponentStatHRepository;
import com.aig.nge.repository.TTransactionComponentStatusRepository;
import com.aig.nge.repository.TlegacyMgaProductRepository;
import com.aig.nge.repository.TlegacyProductBundlingRepository;
import com.aig.nge.repository.TlegacyProfitCenterProductRepository;
import com.aig.nge.repository.TlegacyTrnsctnCmpntXtensnHRepository;
import com.aig.nge.repository.TlegacyTrnsctnCmpntXtensnRepository;
import com.aig.nge.repository.TlegacyWipQuoteCurrencyHsRepository;
import com.aig.nge.repository.VComponentProductRepository;
import com.aig.nge.utilities.AIGCIExceptionMsg;
import com.aig.nge.utilities.NGECommonUtil;
import com.aig.nge.utilities.NGEConstants;
import com.aig.nge.utilities.NGEDateUtil;
import com.aig.nge.utilities.NGEErrorCodes;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;



@Repository
public class TransferComponentDAO extends BaseDAO
{
	@Autowired
	private TSubmissionRepository tsubmissionrepository;
	@Autowired
	private TlegacyProductBundlingRepository tlegacyproductbundlingrepository;
	@Autowired
	private TlegacyTrnsctnCmpntXtensnRepository tlegacytrnsctncmpntxtensnrepository;
	@Autowired
	private TTransactionComponentStatusRepository ttransactioncomponentstatusrepository;
    @Autowired
	private TLegacyWipQuoteRepository tlegacywipquoterepository;
	@Autowired
	private TTransactionComponentRepository ttransactioncomponentrepository;
	
	@Autowired
	private TlegacyProfitCenterProductRepository tlegacyprofitcenterproductrepository;
	@Autowired
	private TlegacyMgaProductRepository tlegacymgaproductrepository;
	@Autowired
	private TLegacyWIPQuoteHsRepository tlegacywipquotehsrepository;	
	@Autowired
	private TTransactionComponentHRepository tTransactionComponentHRepository;
	
	@Autowired
	private TlegacyTrnsctnCmpntXtensnHRepository trnsctnCmpntXtensnHRepository;
	String transactionComponentId=null;
	
	@Autowired
	private TTransactionComponentAtrbtRepository tTransactionComponentAtrbtRepository;
	
	@Autowired
	private TTransactionComponentPolicyRepository tTransactionComponentPolicyRepository;
	
	@Autowired
	private TTransactionComponentStatHRepository tTransactionComponentStatHRepository;
	
	@Autowired
	private TlegacyWipQuoteCurrencyHsRepository tlegacyWipQuoteCurrencyHsRepository;
	
	@Autowired
	private TLegacyProductMappingRepository legacyProductMappingRepository;
	@Autowired
	private VComponentProductRepository vComponentProductRepository;
	
	@Autowired
	TPartyRepository tPartyRepository;
	@PersistenceContext
    private EntityManager em;

	private static final Logger logger = LogManager.getLogger(TransferComponentDAO.class);
	public Tsubmission  findSubmissionNo(String submissionNo) throws AIGCIExceptionMsg{		
		Tsubmission submissionData = null;
		submissionData=tsubmissionrepository.findOne(submissionNo);		
		logger.debug(":::::::::Exiting Submission Number Dao:::::::::::: ");
		return submissionData;
	}

	public void getComponentCount(String fromBundledProductCd, Long submissionNo)throws AIGCIExceptionMsg 
	{	
		 List<TlegacyTrnsctnCmpntXtensn>count=new ArrayList<TlegacyTrnsctnCmpntXtensn>();
		  count=tlegacytrnsctncmpntxtensnrepository.getComponentProductCount(NGECommonUtil.convertToString(fromBundledProductCd));
		int size=0;
		logger.debug(size);
		  for(int i=0;i<count.size();i++)
		{
			if(tsubmissionrepository.getComponentCount(count.get(i).getTransactionComponentId()).getSubmissionNo().equalsIgnoreCase(submissionNo.toString()))
			size++;
		}
		  if(!(size>2))
		  {
			  ngeException.throwException(NGEErrorCodes.INVALID_NO_COMPONENTS,NGEErrorCodes.ERROR_TYPE,null,null);
		  }
		
		   logger.debug(":::::::::::Exiting Component Count::::::::::::");
	}

	public String getBundleProductStatusCode(String componentCd,String bundledProductCd,String componentCoverageTypeCode)throws AIGCIExceptionMsg
	{
	
		//checking component status code as bundle status code derieved from component statuses..(For SourceBundle, for Destination we check the Bundle Status)
		transactionComponentId=tlegacytrnsctncmpntxtensnrepository.getTransactionComponentId( NGECommonUtil.convertToString(componentCd), NGECommonUtil.convertToString(bundledProductCd), componentCoverageTypeCode);
		logger.debug(transactionComponentId);
	if(transactionComponentId==null)
	{
		ngeException.throwException(NGEErrorCodes.COMPONENT_ROW_NOT_FOUND_IN_BUNDLE,NGEErrorCodes.ERROR_TYPE,null,null);
	}
		ArrayList<TtransactionComponentStatus> statusIds = new ArrayList<TtransactionComponentStatus>();
		statusIds=ttransactioncomponentstatusrepository.getStatusId(transactionComponentId);
		logger.debug(statusIds.size());
		logger.debug(statusIds.get(0).getTstatus().getStatusId());
		logger.debug(statusIds.get(1).getTstatus().getStatusId());
		
			if(!(statusIds.get(0).getTstatus().getStatusId()==1 || statusIds.get(1).getTstatus().getStatusId()==1 || statusIds.get(1).getTstatus().getStatusId()==2 || statusIds.get(1).getTstatus().getStatusId()==2))
		{
			ngeException.throwException(NGEErrorCodes.INVALID_STATUS_CD,NGEErrorCodes.ERROR_TYPE,null,null);
		}
			logger.debug("::::::::::::Exiting Bundle Status Code:::::::::::::::");
		return transactionComponentId;
		
		
	}

	public String getBundleProductCoverageType(String bundledProductCd)throws AIGCIExceptionMsg
	{
		String coverageType=tlegacytrnsctncmpntxtensnrepository.getBundleProductCoverageType(NGECommonUtil.convertToString(bundledProductCd),NGECommonUtil.convertToString(bundledProductCd));
		if(!(coverageType.equalsIgnoreCase("P") || coverageType.equalsIgnoreCase("Primary") || coverageType.equalsIgnoreCase("E") ||coverageType.equalsIgnoreCase("Excess")))
		{
			ngeException.throwException(NGEErrorCodes.INVALID_BUNDLE_PRODUCT_COVERAGE,NGEErrorCodes.ERROR_TYPE,null,null);
		}
		logger.debug(":::::::::::Exiting Bundle Coverage Type::::::::::::::::::");
		return coverageType;
	}

	public List<TlegacyWipQuote> getNumberOfWips(String sourceTransactionComponentId){ 
		List<TlegacyWipQuote> wip =  null;
		wip=tlegacywipquoterepository.getWipCount(sourceTransactionComponentId);
		return wip;
	}
	public void getSourceWipCount(String sourceTransactionComponentId) throws AIGCIExceptionMsg
	{
		ArrayList<TlegacyWipQuote> wip=new ArrayList<TlegacyWipQuote>();
		boolean flag=false;
		wip=tlegacywipquoterepository.getWipCount(sourceTransactionComponentId);
	if(wip.size()==1)
	{
		TtransactionComponent ttransactioncomponent =ttransactioncomponentrepository.getProductStateId(sourceTransactionComponentId);
		//TproductState tproductstate=tproductstaterepository.getBusinessTypeCd(ttransactioncomponent.getTproductState().getProductStateId());
		TproductState tproductstate= ttransactioncomponent.getTproductState();
	if(!(tproductstate.getProductStateNm().charAt(0)=='r'))
	   {
		ngeException.throwException(NGEErrorCodes.INVALID_WIP_BUSINESSTYPE_COMBINATION,NGEErrorCodes.ERROR_TYPE,null,null);
	   }
	 }
	if(wip.size()>1)
	{
		for(int i=0;i<wip.size();i++)
		{
			if(wip.get(i).getWipStatusCd().equalsIgnoreCase("quoted") || wip.get(i).getWipStatusCd().equalsIgnoreCase("q"))
			{
				flag=true;
			}
		}
		if(flag==false)
		  {
			ngeException.throwException(NGEErrorCodes.NO_QUOTED_WIPS_PRESENT,NGEErrorCodes.ERROR_TYPE,null,null);
		  }
	}
	logger.debug("::::::::::::::::Exiting WIP Count::::::::::::::::::::::::::");
}

	public String getCrossSellingIndicator(String bundledProductCd)throws AIGCIExceptionMsg
	{
		ArrayList<String> sourceCrossSellingIndicatorlist=tlegacyprofitcenterproductrepository.getCrossSellingIndicator(NGECommonUtil.convertToString(bundledProductCd));
	
	    logger.debug("::::::::::::::ABC::::::::::::::::::");
	    logger.debug(":::::::::Exiting Cross Selling Indicator:::::::::::::");
		return sourceCrossSellingIndicatorlist.get(0);
	}

	public String retrieveCrossSellingInd(String profitCentreCd, String productCd, String sourceCd)throws AIGCIExceptionMsg{
		return tlegacyprofitcenterproductrepository.getCrossSellingInd(NGECommonUtil.convertToString(profitCentreCd),NGECommonUtil.convertToString(productCd),NGECommonUtil.convertToString(sourceCd),new Date());
	}
                             	//Destination Bundle Validations
	
	public void getDestinationWipCount(String destinationTransactionComponentId)throws com.aig.nge.utilities.AIGCIExceptionMsg
	{
		ArrayList<TlegacyWipQuote> wip=new ArrayList<TlegacyWipQuote>();
		boolean flag=false;
		wip=tlegacywipquoterepository.getWipCount(destinationTransactionComponentId);
		if(wip.size()>0)
		{
			for(int i=0;i<wip.size();i++)
			{
				if(wip.get(i).getWipStatusCd().equalsIgnoreCase("quoted") || wip.get(i).getWipStatusCd().equalsIgnoreCase("Q"))
				{
					flag=true;
				}
			}
			if(flag==false)
			{
				ngeException.throwException(NGEErrorCodes.NO_QUOTED_WIPS_PRESENT,NGEErrorCodes.ERROR_TYPE,null,null);
			}
		}
	if(wip.size()==0)
	  {
		TtransactionComponent ttransactioncomponent=ttransactioncomponentrepository.getProductStateId(destinationTransactionComponentId);
		if(!(ttransactioncomponent.getTproductState().getProductStateId()==102))
		{
			ngeException.throwException(NGEErrorCodes.INVALID_WIP_BUSINESSTYPE_COMBINATION,NGEErrorCodes.ERROR_TYPE,null,null);
		}
	
	  }
}
                                    //Actual Move Part
	
	public TlegacyProfitCenterProduct getProfitCenterCd(String bundledProductCd)
	{
		 TlegacyProfitCenterProduct tlegacyprofitcenterproduct=tlegacyprofitcenterproductrepository.getProfitCenterCd(NGECommonUtil.convertToString(bundledProductCd));
	   
		 logger.debug("::::::::::Fetching Profit Center Cd:::::::::::");
		 return tlegacyprofitcenterproduct;
	}

	
	
	public String getWrapUpIn(String bundledProductCd) 
	{
		String wrapUpIn=tlegacyprofitcenterproductrepository.getWrapUpIn(NGECommonUtil.convertToString(bundledProductCd));
	    return wrapUpIn;
	}

	public String getWorkingBranchCd(String bundledProductCd,String profitCenterCd) 
	{
		String sourceCd=tlegacyprofitcenterproductrepository.getSourceCd(NGECommonUtil.convertToString(bundledProductCd));
		String workingBranchCd=tlegacymgaproductrepository.getWorkingBranchCd(NGECommonUtil.convertToString(bundledProductCd),NGECommonUtil.convertToString(profitCenterCd),NGECommonUtil.convertToString(sourceCd));
		return workingBranchCd;
	}

	public Tparty getUnderwriterId(String transactioncomponentId) 
	{
		Tparty tparty=ttransactioncomponentrepository.getUnderwriterId(transactioncomponentId);
		return tparty;
	}

	public void moveAndDeleteQuotedWips(String sourceTransactionComponentId) 
	{
		Date date=new Date();
		ArrayList<TlegacyWipQuote> qwip=new ArrayList<TlegacyWipQuote>();
		qwip=tlegacywipquoterepository.getQuotedWips(sourceTransactionComponentId);
		if(qwip.size()!=0)
		{
			for(TlegacyWipQuote quote: qwip)
			{
				TlegacyWipQuoteH tlegacywipquoteh=new TlegacyWipQuoteH();
				TlegacyWipQuoteHPK tlegacywipquotehpk=new TlegacyWipQuoteHPK();
			    tlegacywipquotehpk.setQuoteSqn(quote.getId().getQuoteSqn());
				tlegacywipquotehpk.setTransactionComponentId(quote.getId().getTransactionComponentId());
				tlegacywipquotehpk.setWipId(quote.getId().getWipId());
				tlegacywipquotehpk.setCreateHistoryTs(date);
				
				tlegacywipquoteh.setAccountingPolNo(quote.getAccountingPolNo());
				tlegacywipquoteh.setAccountLegalNm(quote.getAccountLegalNm());
				tlegacywipquoteh.setAcctngPolPrfxCd(quote.getAcctngPolPrfxCd());
				tlegacywipquoteh.setCreateTs(quote.getCreateTs());
				tlegacywipquoteh.setCreateUserId(quote.getCreateUserId());
				tlegacywipquoteh.setId(tlegacywipquotehpk);
				
				tlegacywipquoteh.setLossrsnAdlcmtsTx(quote.getLossrsnAdlcmtsTx());
				tlegacywipquoteh.setMasterContractNo(quote.getMasterContractNo());
				tlegacywipquoteh.setNonRenewalIn(quote.getNonRenewalIn());
				tlegacywipquoteh.setNonRenewalReasonCd(quote.getNonRenewalReasonCd());
				tlegacywipquoteh.setPolEventNo(quote.getPolEventNo());
				tlegacywipquoteh.setPolicyId(quote.getPolicyId());
				tlegacywipquoteh.setPolicyMailedDt(quote.getPolicyMailedDt());
				tlegacywipquoteh.setPriorPolicyId(quote.getPriorPolicyId());
				tlegacywipquoteh.setProfitUnitCd(quote.getProfitUnitCd());
				tlegacywipquoteh.setQuoteAcceptedIn(quote.getQuoteAcceptedIn());
				tlegacywipquoteh.setQuoteEfctvDt(quote.getQuoteEfctvDt());
				tlegacywipquoteh.setQuoteXprtnDt(quote.getQuoteXprtnDt());
				tlegacywipquoteh.setReasonCd(quote.getReasonCd());
				tlegacywipquoteh.setSectionCd(quote.getSectionCd());
				tlegacywipquoteh.setStatusEnteredDt(quote.getStatusEnteredDt());
				tlegacywipquoteh.setUpdateTs(quote.getUpdateTs());
				tlegacywipquoteh.setUpdateUserId(quote.getUpdateUserId());
				//tlegacywipquoteh.setUwSystemId(Short.valueOf(quote.getTsystem().getSystemId()));
				tlegacywipquoteh.setUwSystemId(Short.valueOf(quote.getUwSystemID()));
				tlegacywipquoteh.setWinningCarrierNm(quote.getWinningCarrierNm());
				tlegacywipquoteh.setWipStatusCd(quote.getWipStatusCd());
				
				
				logger.debug(quote.getPolicyId());
				tlegacywipquotehsrepository.save(tlegacywipquoteh);
				tlegacywipquoterepository.delete(quote);
							
			}
		}
		
	}

	public void checkComponentPresentinDestinationBundle(String toBundledProductCd, String componentCd) throws AIGCIExceptionMsg
	{
		TlegacyProductBundling tlegacyProductBundling=tlegacyproductbundlingrepository.checkIfPresent(NGECommonUtil.convertToString(toBundledProductCd),NGECommonUtil.convertToString(componentCd));
		
		if(tlegacyProductBundling==null)
		{
			ngeException.throwException(NGEErrorCodes.COMPONENT_ABSENT_IN_DESTINATION_BUNDLE,NGEErrorCodes.ERROR_TYPE,null,null);
		}
		

	}

	public void checkIfPresentUnderSubmissionNo(Long submissionNo, String sourceTransactionComponentId) throws AIGCIExceptionMsg 
	{
		boolean flag=false;
		String submissionNoVal1="";
		submissionNoVal1 = submissionNo.toString();
		logger.debug(submissionNoVal1);
	    List<Tsubmission>submissions=new ArrayList<Tsubmission>();
		submissions=tsubmissionrepository.checkIfPresentUnderSubmission(sourceTransactionComponentId);
		logger.debug(submissions.get(0).getSubmissionNo());
		if(submissions.size()==0)
		{
			ngeException.throwException(NGEErrorCodes.COMPONENT_ROW_NOT_FOUND_IN_BUNDLE,NGEErrorCodes.ERROR_TYPE,null,null);
		}
		else
		{
			for(Tsubmission tsubmission : submissions)
			{
				if(tsubmission.getSubmissionNo().equalsIgnoreCase(submissionNoVal1))
				{
					flag=true;
				}
			}
		}
		if(!(flag==true))
		{
			ngeException.throwException(NGEErrorCodes.BUNDLE_NOT_PART_OF_SUBMISSION,NGEErrorCodes.ERROR_TYPE,null,null);
		}
		logger.debug("::::::::::::Bundle Present Under Given SubmissionNo:::::::::::::::::");
	}

	public TlegacyTrnsctnCmpntXtensn fetchRecordToOverwrite(String destinationTransactionComponentId)
	{
		TlegacyTrnsctnCmpntXtensn tlegacytrnsctncmpntxtensn=tlegacytrnsctncmpntxtensnrepository.fetchByTransactionId(destinationTransactionComponentId);
		logger.debug(":::::::::::::::Fetched TlegacyTrnsctnCmpntXtensn:::::::::::::::");
		
		return tlegacytrnsctncmpntxtensn;
				
	}

	public TlegacyProductBundling retrieveTLegacyProduct(String bundleProdCd, String prodCd){
		TlegacyProductBundlingPK tlegacyProductBundling=new TlegacyProductBundlingPK();		
		tlegacyProductBundling.setBundledProductCd(bundleProdCd);
		tlegacyProductBundling.setProductCd(prodCd);		
		return tlegacyproductbundlingrepository.checkIfPresent(NGECommonUtil.convertToString(bundleProdCd),NGECommonUtil.convertToString(prodCd)/*, new Date()*/);
	}
	public void overwriteRecord(TlegacyTrnsctnCmpntXtensn sourceTlegacytrnsctncmpntxtensn, TlegacyTrnsctnCmpntXtensn destinationTlegacytrnsctncmpntxtensn) 
	{
		
		TlegacyProductBundlingPK tlegacyProductBundling=new TlegacyProductBundlingPK();
		
		tlegacyProductBundling.setBundledProductCd(destinationTlegacytrnsctncmpntxtensn.getTlegacyProductBundling().getTlegacyProduct1().getProductCd());
		tlegacyProductBundling.setProductCd(sourceTlegacytrnsctncmpntxtensn.getTlegacyProductBundling().getId().getProductCd());
		
		TlegacyProductBundling tlegacyproductbundling=tlegacyproductbundlingrepository.findOne(tlegacyProductBundling);
	
		sourceTlegacytrnsctncmpntxtensn.setTlegacyProductBundling(tlegacyproductbundling);
		sourceTlegacytrnsctncmpntxtensn.setSectionCd(destinationTlegacytrnsctncmpntxtensn.getSectionCd());
		sourceTlegacytrnsctncmpntxtensn.setProfitUnitCd(destinationTlegacytrnsctncmpntxtensn.getProfitUnitCd());
		sourceTlegacytrnsctncmpntxtensn.setPartOfAm(destinationTlegacytrnsctncmpntxtensn.getPartOfAm());
		//sourceTlegacytrnsctncmpntxtensn.setAssumedBusIn(destinationTlegacytrnsctncmpntxtensn.getAssumedBusIn());
		sourceTlegacytrnsctncmpntxtensn.setXchangeRtEfctvDt(destinationTlegacytrnsctncmpntxtensn.getXchangeRtEfctvDt());
		sourceTlegacytrnsctncmpntxtensn.setCreateUserId(destinationTlegacytrnsctncmpntxtensn.getCreateUserId());
		sourceTlegacytrnsctncmpntxtensn.setCreateTs(destinationTlegacytrnsctncmpntxtensn.getCreateTs());
		sourceTlegacytrnsctncmpntxtensn.setUpdateUserId(destinationTlegacytrnsctncmpntxtensn.getUpdateUserId());
		sourceTlegacytrnsctncmpntxtensn.setUpdateTs(destinationTlegacytrnsctncmpntxtensn.getUpdateTs());
	
		/* Exadata changes - Not null issue starts */
		if(sourceTlegacytrnsctncmpntxtensn.getDeclineReasonCd() != null){
			if(sourceTlegacytrnsctncmpntxtensn.getDeclineReasonCd().trim().equals(NGEConstants.EMPTY_STRING))
				sourceTlegacytrnsctncmpntxtensn.setDeclineReasonCd(NGEConstants.EMPTY_SPACE);
		}
		
		if(sourceTlegacytrnsctncmpntxtensn.getSpecialEventNm() != null){
			if(sourceTlegacytrnsctncmpntxtensn.getSpecialEventNm().trim().equals(NGEConstants.EMPTY_STRING))
				sourceTlegacytrnsctncmpntxtensn.setSpecialEventNm(NGEConstants.EMPTY_SPACE);
		}

		/* Exadata changes - Not null issue ends */
		
		tlegacytrnsctncmpntxtensnrepository.save(sourceTlegacytrnsctncmpntxtensn);
	    logger.debug("::::::::::::::::::Bundles Swapped::::::::::::::::::::");
	}

	
	public void swapUnderwriterValues(Tparty destinationTparty, String sourceTransactioncomponentId) 
	{
		
		TtransactionComponent ttransactioncomponent=ttransactioncomponentrepository.getSourceUnderwriterDetails(sourceTransactioncomponentId);
		
		ttransactioncomponent.setTparty(destinationTparty);
		
		ttransactioncomponentrepository.save(ttransactioncomponent);
		
		logger.debug(":::::::::::::UnderWriterValuesSwapped:::::::::::::::::::");
		
	}

	public List<TlegacyTrnsctnCmpntXtensn> fetchExtData(String componentCd,String bundledProductCd,String componentCoverageTypeCode,Long submissionNo/*,String transactionId*/)throws AIGCIExceptionMsg{
		List<TlegacyTrnsctnCmpntXtensn> trnsCompExtList = null;
		trnsCompExtList=tlegacytrnsctncmpntxtensnrepository.getTransactionCmpXtenList(NGECommonUtil.convertToString(componentCd), NGECommonUtil.convertToString(bundledProductCd), componentCoverageTypeCode,String.valueOf(submissionNo)/*,transactionId*/);
		return trnsCompExtList;
	}
	
	public List<TlegacyTrnsctnCmpntXtensn> fetchExtData(String bundledProductCd,String componentCoverageTypeCode,Long submissionNo/*,String transactionId*/)throws AIGCIExceptionMsg{
		List<TlegacyTrnsctnCmpntXtensn> trnsCompExtList = null;
		trnsCompExtList=tlegacytrnsctncmpntxtensnrepository.getTransactionCmpXtenList( NGECommonUtil.convertToString(bundledProductCd), NGECommonUtil.convertToString(componentCoverageTypeCode),String.valueOf(submissionNo)/*,transactionId*/);
		return trnsCompExtList;
	}
	
	public int getNumberOfComponents(String bundledProductCd,Long submissionNo,String transactionId)throws AIGCIExceptionMsg{
		List<Object[]> productsAvailable = null;
		productsAvailable =  tlegacytrnsctncmpntxtensnrepository.getTransactionCmpXtenCount(NGECommonUtil.convertToString(bundledProductCd),String.valueOf(submissionNo),transactionId);
		if(productsAvailable == null){
			return 0;
		}
		return productsAvailable.size();		
	}
	public String getBundledProductStatusCode1(String componentCd,String bundledProductCd,String componentCoverageTypeCode,Long submissionNo)throws AIGCIExceptionMsg
	{
	List<String>transactionComponentIdList=new ArrayList<String>();
		//List<Tsubmission>submissions=new ArrayList<Tsubmission>();
		String ttransactionComponentId=null;
		logger.debug(ttransactionComponentId);
		
		transactionComponentIdList=tlegacytrnsctncmpntxtensnrepository.getTransactionComponentIdList(NGECommonUtil.convertToString(componentCd), NGECommonUtil.convertToString(bundledProductCd), componentCoverageTypeCode,String.valueOf(submissionNo));
		
		/*for(int i=0;i<transactionComponentIdList.size();i++)
	   {
			submissions=tsubmissionrepository.checkIfPresentUnderSubmission(transactionComponentIdList.get(i));
			for(int j=0;j<submissions.size();j++)
		   {
			if(submissions.get(j).getSubmissionNo().equalsIgnoreCase(submissionNo.toString()))
			{
				ttransactionComponentId=transactionComponentIdList.get(i);
			}
		  }
	   }
		*/
		if(transactionComponentIdList==null)
		{
			ngeException.throwException(NGEErrorCodes.COMPONENT_ROW_NOT_FOUND_IN_BUNDLE,NGEErrorCodes.ERROR_TYPE,null,null);
		}else{
		
		ttransactionComponentId=transactionComponentIdList.get(0);
		logger.debug(ttransactionComponentId);
		logger.debug(ttransactionComponentId);
		ArrayList<TtransactionComponentStatus> statusId = new ArrayList<TtransactionComponentStatus>();
		statusId=ttransactioncomponentstatusrepository.getStatusId(ttransactionComponentId);
		logger.debug(statusId.size());
		logger.debug(statusId.get(0).getTstatus().getStatusId());
		logger.debug(statusId.get(1).getTstatus().getStatusId());
		if((statusId.get(0).getId().getStatusId()==9 )|| (statusId.get(1).getId().getStatusId()==9 )){
			ngeException.throwException(NGEErrorCodes.BLOCK_STATUS_CD,NGEErrorCodes.ERROR_TYPE,null,null);
		}
		
			if(!(statusId.get(0).getId().getStatusId()==1 || statusId.get(1).getId().getStatusId()==1 || statusId.get(0).getId().getStatusId()==2 || statusId.get(1).getId().getStatusId()==2 ))
		{
			ngeException.throwException(NGEErrorCodes.INVALID_STATUS_CD,NGEErrorCodes.ERROR_TYPE,null,null);
		}
			logger.debug("::::::::::::Exiting Bundle Status Code:::::::::::::::");
		}
		return ttransactionComponentId;
		
	}
	public String getBundledProductCoverageType1(String bundledProductCd,Long submissionNo) throws AIGCIExceptionMsg
	{
		String coverageType=null;
		List<Tsubmission>submissions=new ArrayList<Tsubmission>();
		List<TlegacyTrnsctnCmpntXtensn>trnsctnCmpntXtensn=new ArrayList<TlegacyTrnsctnCmpntXtensn>();
		
		trnsctnCmpntXtensn=tlegacytrnsctncmpntxtensnrepository.getBundleProductCoverageType1(NGECommonUtil.convertToString(bundledProductCd));
		
		for(int i=0;i<trnsctnCmpntXtensn.size();i++)
		{
			
			submissions=tsubmissionrepository.checkIfPresentUnderSubmission(trnsctnCmpntXtensn.get(i).getTransactionComponentId());
			for(int j=0;j<submissions.size();j++)
			{
			if(submissions.get(i).getSubmissionNo().equalsIgnoreCase(submissionNo.toString()))
				{
				coverageType=trnsctnCmpntXtensn.get(i).getLegacyProdctCovgTypCd();
				}
			}
		}
		if((coverageType==null))
		{
			ngeException.throwException(NGEErrorCodes.COMPONENT_ROW_NOT_FOUND_IN_BUNDLE,NGEErrorCodes.ERROR_TYPE,null,null);
		}
		return coverageType;	
		
	}
	public void getComponentCount1(String fromBundledProductCd, Long submissionNo)throws AIGCIExceptionMsg 
	{
		 List<TlegacyTrnsctnCmpntXtensn>count=new ArrayList<TlegacyTrnsctnCmpntXtensn>();
		 List<Tsubmission>submissions=new ArrayList<Tsubmission>();
		 count=tlegacytrnsctncmpntxtensnrepository.getComponentProductCount(NGECommonUtil.convertToString(fromBundledProductCd));
		int size=0;
		logger.debug(size);
		
		for(int i=0;i<count.size();i++)
			{
				submissions=tsubmissionrepository.checkIfPresentUnderSubmission(count.get(i).getTransactionComponentId());
				
				for(int j=0;j<submissions.size();j++)
				{
					if(submissions.get(j).getSubmissionNo().equalsIgnoreCase(submissionNo.toString()))
					{
						size++;
					}
				}
			}
		if(!(size>2))
		  {
			  ngeException.throwException(NGEErrorCodes.INVALID_NO_COMPONENTS,NGEErrorCodes.ERROR_TYPE,null,null);
		  }
		
		   logger.debug(":::::::::::Exiting Component Count::::::::::::");
		
	}
	public void checkBlockingProcessStatusCd(String ttransactionComponentId)throws AIGCIExceptionMsg 
	{

		String lockin=ttransactioncomponentrepository.getLockInIndicator(ttransactionComponentId);
		
		logger.debug(lockin);
		
		if(lockin.equalsIgnoreCase("Y"))
		{
			 ngeException.throwException(NGEErrorCodes.BLOCKED_PRODUCT,NGEErrorCodes.ERROR_TYPE,null,null);
		}
		logger.debug("::::::::::::::::::Exiting blocking Process Status Code::::::::::::::::::::::");
	}
	

	public void checkComponentCoverageType(String componentCoverageType)throws AIGCIExceptionMsg
	{
		if(!(componentCoverageType.equalsIgnoreCase("P") || componentCoverageType.equalsIgnoreCase("Primary") || componentCoverageType.equalsIgnoreCase("E") ||componentCoverageType.equalsIgnoreCase("Excess")))
		{
			ngeException.throwException(NGEErrorCodes.INVALID_COMPONENT_PRODUCT_COVERAGE,NGEErrorCodes.ERROR_TYPE,null,null);
		}
	}

	                      
	                      // Destination Bundle Validations
 public void checkBundleProductCoverageType(String toProductCoverageType)throws AIGCIExceptionMsg
	{
		if(!(toProductCoverageType.equalsIgnoreCase("P") || toProductCoverageType.equalsIgnoreCase("Primary") || toProductCoverageType.equalsIgnoreCase("E") ||toProductCoverageType.equalsIgnoreCase("Excess")))
		{
			ngeException.throwException(NGEErrorCodes.INVALID_BUNDLE_PRODUCT_COVERAGE,NGEErrorCodes.ERROR_TYPE,null,null);
		}
	
	}

                                   // Combined Checks
public void compareCrossSellingIndicators(String sourceCrossSellingIndicator,String destinationCrossSellingIndicator)throws AIGCIExceptionMsg 
   {
		if(!(sourceCrossSellingIndicator.equalsIgnoreCase(destinationCrossSellingIndicator)))
		{
			ngeException.throwException(NGEErrorCodes.INVALID_CROSS_SELLING_IN_COMBINATION,NGEErrorCodes.ERROR_TYPE,null,null);
		}
   }


public void compareCoverageTypes(String sourceBundleCoverageType,String toProductCoverageType) throws AIGCIExceptionMsg
{
	if(!(sourceBundleCoverageType.charAt(0)==toProductCoverageType.charAt(0)))
	{
		ngeException.throwException(NGEErrorCodes.INVALID_COVERAGE_COMBINATION,NGEErrorCodes.ERROR_TYPE,null,null);
	}
	
}


public void checkComponentCode(String componentCd)throws AIGCIExceptionMsg
{
	if(componentCd.equalsIgnoreCase("RPL"))
	{
		ngeException.throwException(NGEErrorCodes.INVALID_SRC_PROD,NGEErrorCodes.ERROR_TYPE,null,null);
	}
}
public List<TtransactionComponentStatus> fetchStatusForComponent(
		String transactionComponentId2)throws AIGCIExceptionMsg {
	List<TtransactionComponentStatus> transactionComponentStatusList = null;
	transactionComponentStatusList = ttransactioncomponentstatusrepository.getStatusId(transactionComponentId2);
	return transactionComponentStatusList;
}

public TtransactionComponent retrieveTransactionComponent(
		TlegacyTrnsctnCmpntXtensn tlegacyTrnsctnCmpntFromXtensn) throws AIGCIExceptionMsg{
	TtransactionComponent ttransactionComponent = null;
	ttransactionComponent = ttransactioncomponentrepository.findByTransactionComponentId(tlegacyTrnsctnCmpntFromXtensn.getTransactionComponentId());
	return ttransactionComponent;
}

public void updateTransactionComponent(
		TtransactionComponent ttransactionComponent)throws AIGCIExceptionMsg {
		ttransactioncomponentrepository.save(ttransactionComponent);
}

public void insertIntoTransactionComponentHistory(
		TtransactionComponentH ttransactionComponentH)throws AIGCIExceptionMsg {
	tTransactionComponentHRepository.save(ttransactionComponentH);	
}

public TlegacyProductBundling retriveTlegacyProductBundle(
		TlegacyProductBundlingPK tlegacyProductBundling) throws AIGCIExceptionMsg {
	// TODO Auto-generated method stub
	return tlegacyproductbundlingrepository.findOne(tlegacyProductBundling);
}

public void updateExtensionData(
		TlegacyTrnsctnCmpntXtensn tlegacyTrnsctnCmpntFromXtensnTemp)throws AIGCIExceptionMsg  {	
	
	/* Exadata changes - Not null issue starts */
	if(tlegacyTrnsctnCmpntFromXtensnTemp.getDeclineReasonCd() != null){
		if(tlegacyTrnsctnCmpntFromXtensnTemp.getDeclineReasonCd().trim().equals(NGEConstants.EMPTY_STRING))
			tlegacyTrnsctnCmpntFromXtensnTemp.setDeclineReasonCd(NGEConstants.EMPTY_SPACE);
	}
	
	if(tlegacyTrnsctnCmpntFromXtensnTemp.getSpecialEventNm() != null){
		if(tlegacyTrnsctnCmpntFromXtensnTemp.getSpecialEventNm().trim().equals(NGEConstants.EMPTY_STRING))
			tlegacyTrnsctnCmpntFromXtensnTemp.setSpecialEventNm(NGEConstants.EMPTY_SPACE);
	}

	/* Exadata changes - Not null issue ends */
	
	tlegacytrnsctncmpntxtensnrepository.save(tlegacyTrnsctnCmpntFromXtensnTemp);
}

public void saveTlegacyExtensionHistory(
		TlegacyTrnsctnCmpntXtnsnH tlegacyTrnsctnCmpntXtnsnH)throws AIGCIExceptionMsg  {
	trnsctnCmpntXtensnHRepository.save(tlegacyTrnsctnCmpntXtnsnH);	
}

public List<TlegacyWipQuote> retieveLegacyWipQuote(String transactionComponentId2) throws AIGCIExceptionMsg {
	return tlegacywipquoterepository.findByTransactionComponentId(transactionComponentId2);
}

public List<TtransactionComponentAtrbt> retrieveTarrtributeDetail(String componentId, String attributeName)throws AIGCIExceptionMsg  {
	return tTransactionComponentAtrbtRepository.findByTransactionComponentIdAndAttributeNm(componentId,attributeName);
}

public void updateTattributeData(
		TtransactionComponentAtrbt ttransactionComponentAtrbtFrom) throws AIGCIExceptionMsg {
	tTransactionComponentAtrbtRepository.save(ttransactionComponentAtrbtFrom);
	
}

public void updateWipHistory(List<TlegacyWipQuote> tlegacyWipQuoteFromBundleList) throws AIGCIExceptionMsg {
	List<TlegacyWipQuoteH> tlegacyWipQuoteHsList = new ArrayList<TlegacyWipQuoteH>();
	if(null != tlegacyWipQuoteFromBundleList && !tlegacyWipQuoteFromBundleList.isEmpty()){
		Iterator<TlegacyWipQuote> tlegacyWipQuoteIter = tlegacyWipQuoteFromBundleList.iterator();
		TlegacyWipQuote tlegacyWipQuote = null;
		TlegacyWipQuoteH tlegacyWipQuoteH = null;
		TlegacyWipQuoteHPK tlegacyWipQuoteHPK = null;
		while(tlegacyWipQuoteIter.hasNext()){
			tlegacyWipQuote = tlegacyWipQuoteIter.next();
			tlegacyWipQuoteH = new TlegacyWipQuoteH();
			tlegacyWipQuoteHPK = new TlegacyWipQuoteHPK();
			tlegacyWipQuoteHPK.setCreateHistoryTs(NGEDateUtil.getTodayDate());
			tlegacyWipQuoteHPK.setQuoteSqn(tlegacyWipQuote.getId().getQuoteSqn());
			tlegacyWipQuoteHPK.setTransactionComponentId(tlegacyWipQuote.getId().getTransactionComponentId());
			tlegacyWipQuoteHPK.setWipId(tlegacyWipQuote.getId().getWipId());
			tlegacyWipQuoteH.setId(tlegacyWipQuoteHPK);
			tlegacyWipQuoteH.setAccountingPolNo(tlegacyWipQuote.getAccountingPolNo());
			tlegacyWipQuoteH.setAccountLegalNm(tlegacyWipQuote.getAccountLegalNm());
			tlegacyWipQuoteH.setAcctngPolPrfxCd(tlegacyWipQuote.getAcctngPolPrfxCd());
			tlegacyWipQuoteH.setBusinessTypeCd(tlegacyWipQuote.getBusinessTypeCd());
			tlegacyWipQuoteH.setCreateTs(tlegacyWipQuote.getCreateTs());
			tlegacyWipQuoteH.setCreateUserId(tlegacyWipQuote.getCreateUserId());
			tlegacyWipQuoteH.setDeletedIn(tlegacyWipQuote.getTtransactionComponent().getDeletedIn());
			tlegacyWipQuoteH.setLossrsnAdlcmtsTx(tlegacyWipQuote.getLossrsnAdlcmtsTx());
			tlegacyWipQuoteH.setMasterContractNo(tlegacyWipQuote.getMasterContractNo());
			tlegacyWipQuoteH.setNonRenewalIn(tlegacyWipQuote.getNonRenewalIn());
			tlegacyWipQuoteH.setNonRenewalReasonCd(tlegacyWipQuote.getReasonCd());
			tlegacyWipQuoteH.setPolEventNo(tlegacyWipQuote.getPolEventNo());
			tlegacyWipQuoteH.setPolicyId(tlegacyWipQuote.getPolicyId());
			tlegacyWipQuoteH.setPolicyMailedDt(tlegacyWipQuote.getPolicyMailedDt());
			tlegacyWipQuoteH.setPolicyXprtnDt(tlegacyWipQuote.getPolicyXprtnDt());
			tlegacyWipQuoteH.setPriorPolicyId(tlegacyWipQuote.getPriorPolicyId());
			tlegacyWipQuoteH.setProfitUnitCd(tlegacyWipQuote.getProfitUnitCd());
			tlegacyWipQuoteH.setQuoteAcceptedIn(tlegacyWipQuote.getQuoteAcceptedIn());
			tlegacyWipQuoteH.setQuoteEfctvDt(tlegacyWipQuote.getQuoteEfctvDt());
			tlegacyWipQuoteH.setQuoteXprtnDt(tlegacyWipQuote.getQuoteXprtnDt());
			tlegacyWipQuoteH.setReasonCd(tlegacyWipQuote.getReasonCd());
			tlegacyWipQuoteH.setSectionCd(tlegacyWipQuote.getSectionCd());
			tlegacyWipQuoteH.setStatusEnteredDt(tlegacyWipQuote.getStatusEnteredDt());
			tlegacyWipQuoteH.setUpdateTs(tlegacyWipQuote.getUpdateTs());
			tlegacyWipQuoteH.setUpdateUserId(tlegacyWipQuote.getUpdateUserId());
			tlegacyWipQuoteH.setUwSystemId(tlegacyWipQuote.getTtransactionComponent().getSystemId() );
			tlegacyWipQuoteH.setWinningCarrierNm(tlegacyWipQuote.getWinningCarrierNm());
			tlegacyWipQuoteH.setWipStatusCd(tlegacyWipQuote.getWipStatusCd());
			updateTwipCurrency(tlegacyWipQuote.getTlegacyWipQuoteCurrencies());
			tlegacyWipQuoteHsList.add(tlegacyWipQuoteH);
		}
		tlegacywipquotehsrepository.save(tlegacyWipQuoteHsList);
	}
}

private void updateTwipCurrency(
		Set<TlegacyWipQuoteCurrency> tlegacyWipQuoteCurrencies) {
	
	Iterator<TlegacyWipQuoteCurrency> wipCurrencyIterator = null;
	TlegacyWipQuoteCurrencyH tlegacyWipQuoteCurrencyH = null;
	TlegacyWipQuoteCurrencyHPK tlegacyWipQuoteCurrencyHPK = null;
	TlegacyWipQuoteCurrency tlegacyWipQuoteCurrency = null;
	List<TlegacyWipQuoteCurrencyH> tlegacyWipQuoteCurrencyHsList = new ArrayList<TlegacyWipQuoteCurrencyH>();
	
	if(null != tlegacyWipQuoteCurrencies && !tlegacyWipQuoteCurrencies.isEmpty()){
		wipCurrencyIterator = tlegacyWipQuoteCurrencies.iterator();
		while(wipCurrencyIterator.hasNext()){
			tlegacyWipQuoteCurrency = wipCurrencyIterator.next();
			tlegacyWipQuoteCurrencyH = new TlegacyWipQuoteCurrencyH();
			tlegacyWipQuoteCurrencyHPK = new TlegacyWipQuoteCurrencyHPK();
			
			tlegacyWipQuoteCurrencyHPK.setCreateHistoryTs(NGEDateUtil.getTodayDate());
			tlegacyWipQuoteCurrencyHPK.setCurrencyId(tlegacyWipQuoteCurrency.getId().getCurrencyId());
			tlegacyWipQuoteCurrencyHPK.setQuoteSqn(tlegacyWipQuoteCurrency.getId().getQuoteSqn());
			tlegacyWipQuoteCurrencyHPK.setTransactionComponentId(tlegacyWipQuoteCurrency.getId().getTransactionComponentId());
			tlegacyWipQuoteCurrencyHPK.setWipId(tlegacyWipQuoteCurrency.getId().getWipId());
			
			tlegacyWipQuoteCurrencyH.setBoundPremiumAm(tlegacyWipQuoteCurrency.getBoundPremiumAm());
			tlegacyWipQuoteCurrencyH.setCreateTs(tlegacyWipQuoteCurrency.getCreateTs());
			tlegacyWipQuoteCurrencyH.setCreateUserId(tlegacyWipQuoteCurrency.getCreateUserId());
			tlegacyWipQuoteCurrencyH.setId(tlegacyWipQuoteCurrencyHPK);
			tlegacyWipQuoteCurrencyH.setPolicyAtchmtPointAm(tlegacyWipQuoteCurrency.getPolicyAtchmtPointAm());
			tlegacyWipQuoteCurrencyH.setPolicyLimitAm(tlegacyWipQuoteCurrency.getPolicyLimitAm());
			tlegacyWipQuoteCurrencyH.setPolicyPartOfAm(tlegacyWipQuoteCurrency.getPolicyPartOfAm());
			tlegacyWipQuoteCurrencyH.setQuotedAtchmtPointAm(tlegacyWipQuoteCurrency.getQuotedAtchmtPointAm());
			tlegacyWipQuoteCurrencyH.setQuotedLimitAm(tlegacyWipQuoteCurrency.getQuotedLimitAm());
			tlegacyWipQuoteCurrencyH.setQuotedPremiumAm(tlegacyWipQuoteCurrency.getQuotedPremiumAm());
			tlegacyWipQuoteCurrencyH.setUpdateTs(tlegacyWipQuoteCurrency.getUpdateTs());
			tlegacyWipQuoteCurrencyH.setUpdateUserId(tlegacyWipQuoteCurrency.getUpdateUserId());
			tlegacyWipQuoteCurrencyHsList.add(tlegacyWipQuoteCurrencyH);
		}
		tlegacyWipQuoteCurrencyHsRepository.save(tlegacyWipQuoteCurrencyHsList);
	}
	
}

public void updateWipQuote(TlegacyTrnsctnCmpntXtensn tlegacyTrnsctnCmpntFromXtensn, List<TlegacyWipQuote> tlegacyWipQuoteToBundleList) throws AIGCIExceptionMsg {
	List<TlegacyWipQuote> tlegacyWipQuoteList = null;
	if(null != tlegacyWipQuoteToBundleList && !tlegacyWipQuoteToBundleList.isEmpty()){
		tlegacyWipQuoteList = new ArrayList<TlegacyWipQuote>();
		Iterator<TlegacyWipQuote> tLegacyWipQuoteToIterator = tlegacyWipQuoteToBundleList.iterator();
		TlegacyWipQuote tlegacyWipToQuote = null;
		TlegacyWipQuote tlegacyWipNewQuote = null;
		TlegacyWipQuotePK id;
		while(tLegacyWipQuoteToIterator.hasNext()){
			tlegacyWipToQuote = tLegacyWipQuoteToIterator.next();
			id = new TlegacyWipQuotePK();
			id.setQuoteSqn(tlegacyWipToQuote.getId().getQuoteSqn());
			id.setTransactionComponentId(tlegacyTrnsctnCmpntFromXtensn.getTransactionComponentId());
			id.setWipId(tlegacyWipToQuote.getId().getWipId());
			tlegacyWipNewQuote = new TlegacyWipQuote();
			tlegacyWipNewQuote.setAccountingPolNo(tlegacyWipToQuote.getAccountingPolNo());
			tlegacyWipNewQuote.setAccountLegalNm(tlegacyWipToQuote.getAccountLegalNm());
			tlegacyWipNewQuote.setAcctngPolPrfxCd(tlegacyWipToQuote.getAcctngPolPrfxCd());
			tlegacyWipNewQuote.setBusinessTypeCd(tlegacyWipToQuote.getBusinessTypeCd());
			tlegacyWipNewQuote.setCreateTs(tlegacyWipToQuote.getCreateTs());
			tlegacyWipNewQuote.setCreateUserId(tlegacyWipToQuote.getCreateUserId());
		
			tlegacyWipNewQuote.setId(id);
			tlegacyWipNewQuote.setLossrsnAdlcmtsTx(tlegacyWipToQuote.getLossrsnAdlcmtsTx());
			tlegacyWipNewQuote.setMasterContractNo(tlegacyWipToQuote.getMasterContractNo());
			tlegacyWipNewQuote.setNonRenewalIn(tlegacyWipToQuote.getNonRenewalIn());
			tlegacyWipNewQuote.setNonRenewalReasonCd(tlegacyWipToQuote.getNonRenewalReasonCd());
			tlegacyWipNewQuote.setPolEventNo(tlegacyWipToQuote.getPolEventNo());
			tlegacyWipNewQuote.setPolicyId(tlegacyWipToQuote.getPolicyId());
			tlegacyWipNewQuote.setPolicyMailedDt(tlegacyWipToQuote.getPolicyMailedDt());
			tlegacyWipNewQuote.setPolicyXprtnDt(tlegacyWipToQuote.getPolicyXprtnDt());
			tlegacyWipNewQuote.setPriorPolicyId(tlegacyWipToQuote.getPriorPolicyId());
			tlegacyWipNewQuote.setProfitUnitCd(tlegacyWipToQuote.getProfitUnitCd());
			tlegacyWipNewQuote.setQuoteAcceptedIn(tlegacyWipToQuote.getQuoteAcceptedIn());
			tlegacyWipNewQuote.setQuoteEfctvDt(tlegacyWipToQuote.getQuoteEfctvDt());
			tlegacyWipNewQuote.setQuoteXprtnDt(tlegacyWipToQuote.getQuoteXprtnDt());
			tlegacyWipNewQuote.setReasonCd(tlegacyWipToQuote.getReasonCd());
			tlegacyWipNewQuote.setSectionCd(tlegacyWipToQuote.getSectionCd());
			tlegacyWipNewQuote.setStatusEnteredDt(tlegacyWipToQuote.getStatusEnteredDt());
			tlegacyWipNewQuote.setTlegacyWipQuoteCurrencies(tlegacyWipToQuote.getTlegacyWipQuoteCurrencies());
			//tlegacyWipNewQuote.setTsystem(tlegacyWipToQuote.getTsystem());
			tlegacyWipNewQuote.setUwSystemID(tlegacyWipToQuote.getUwSystemID());
			tlegacyWipNewQuote.setTtransactionComponent(tlegacyTrnsctnCmpntFromXtensn.getTtransactionComponent());
			tlegacyWipNewQuote.setUpdateTs(NGEDateUtil.getTodayDate());
			tlegacyWipNewQuote.setUpdateUserId(tlegacyWipToQuote.getUpdateUserId());
			tlegacyWipNewQuote.setWinningCarrierNm(tlegacyWipToQuote.getWinningCarrierNm());
			tlegacyWipNewQuote.setWipStatusCd(tlegacyWipToQuote.getWipStatusCd());
			//tlegacyWipToQuote.getId().setTransactionComponentId(tlegacyTrnsctnCmpntFromXtensn.getTransactionComponentId());
			//tlegacyWipFromQuote.setSectionCd(tlegacyTrnsctnCmpntToXtensn.getSectionCd());
			//tlegacyWipFromQuote.setUpdateTs(NGEDateUtil.getTodayDate());
			//tlegacyWipFromQuote.setUpdateUserId(NGESession.getSessionData().getUserId());
			tlegacyWipQuoteList.add(tlegacyWipNewQuote);
			tlegacywipquoterepository.save(tlegacyWipNewQuote);
		}
		logger.debug("Entering save part of tlegacywipquote");
	//	tlegacywipquoterepository.save(tlegacyWipQuoteList);
	}
}

public List<TtransactionComponentPolicy> getComponentPolicyList(
		String transactionComponentId2) throws AIGCIExceptionMsg {
	// TODO Auto-generated method stub
	return null;
}

public int updateComponentPolicyList(String transactionComponentId2, Timestamp timestamp) throws AIGCIExceptionMsg {
	// TODO Auto-generated method stub
	return tTransactionComponentPolicyRepository.updateUsingTransactionComponentId(transactionComponentId2,timestamp);
}

public void updateTransactionComponentPolicy(
		List<TtransactionComponentPolicy> ttransactionComponentPolicieTempList) {
	tTransactionComponentPolicyRepository.save(ttransactionComponentPolicieTempList);	
}

public TtransactionComponent fetchTtransactionComponent(String sourceComponentId) {
	// TODO Auto-generated method stub
	return ttransactioncomponentrepository.findByTransactionComponentId(sourceComponentId);
}
	
public List<Object[]> populateWipQuoteDetail(String submissionNo, String productCd, String coverageTypeCd)throws AIGCIExceptionMsg {
	return ttransactioncomponentrepository.wipCount(submissionNo,NGECommonUtil.convertToString(productCd),coverageTypeCd);
}

public void deleteMultipleWips(String transactionComponentFromId) {
	tlegacywipquoterepository.deleteFromWipCurrency(transactionComponentFromId); 
	tlegacywipquoterepository.deleteFromWip(transactionComponentFromId); 
	
}

public void insertWipsRecord(String transactionComponentToId,String transactionComponentFromId) {
	String query ="INSERT INTO tlegacy_wip_quote (TRANSACTION_COMPONENT_ID, WIP_ID, QUOTE_SQN, WIP_STATUS_CD, STATUS_ENTERED_DT, SECTION_CD, PROFIT_UNIT_CD, REASON_CD, WINNING_CARRIER_NM, LOSSRSN_ADLCMTS_TX, UW_SYSTEM_ID, QUOTE_ACCEPTED_IN, QUOTE_EFCTV_DT, QUOTE_XPRTN_DT, POLICY_ID, PRIOR_POLICY_ID, POL_EVENT_NO, MASTER_CONTRACT_NO, ACCOUNT_LEGAL_NM, ACCOUNTING_POL_NO, ACCTNG_POL_PRFX_CD, NON_RENEWAL_IN, NON_RENEWAL_REASON_CD, POLICY_MAILED_DT, CREATE_USER_ID, CREATE_TS, UPDATE_USER_ID, UPDATE_TS, POLICY_XPRTN_DT, BUSINESS_TYPE_CD) "+
			"  (select "+transactionComponentToId+", WIP_ID, QUOTE_SQN, WIP_STATUS_CD, STATUS_ENTERED_DT, SECTION_CD, PROFIT_UNIT_CD, REASON_CD, WINNING_CARRIER_NM, LOSSRSN_ADLCMTS_TX, UW_SYSTEM_ID, QUOTE_ACCEPTED_IN, QUOTE_EFCTV_DT, QUOTE_XPRTN_DT, POLICY_ID, PRIOR_POLICY_ID, POL_EVENT_NO, MASTER_CONTRACT_NO, ACCOUNT_LEGAL_NM, ACCOUNTING_POL_NO, ACCTNG_POL_PRFX_CD, NON_RENEWAL_IN, NON_RENEWAL_REASON_CD, POLICY_MAILED_DT, CREATE_USER_ID, CREATE_TS, UPDATE_USER_ID, UPDATE_TS, POLICY_XPRTN_DT, BUSINESS_TYPE_CD from tlegacy_wip_quote  where TRANSACTION_COMPONENT_ID =" +transactionComponentFromId +")";  
	int x  = em.createNativeQuery(query).executeUpdate();
	logger.debug("tlegacy_wip_quote inserted with " + x);
	
	query="INSERT INTO tlegacy_wip_quote_currency (TRANSACTION_COMPONENT_ID, WIP_ID, QUOTE_SQN, CURRENCY_ID, QUOTED_PREMIUM_AM, QUOTED_LIMIT_AM, QUOTED_ATCHMT_POINT_AM, POLICY_LIMIT_AM, POLICY_ATCHMT_POINT_AM, POLICY_PART_OF_AM, CREATE_USER_ID, CREATE_TS, UPDATE_USER_ID, UPDATE_TS, BOUND_PREMIUM_AM) "+
			"   ( select "+transactionComponentToId+", WIP_ID, QUOTE_SQN, CURRENCY_ID, QUOTED_PREMIUM_AM, QUOTED_LIMIT_AM, QUOTED_ATCHMT_POINT_AM, POLICY_LIMIT_AM, POLICY_ATCHMT_POINT_AM, POLICY_PART_OF_AM, CREATE_USER_ID, CREATE_TS, UPDATE_USER_ID, UPDATE_TS, BOUND_PREMIUM_AM from tlegacy_wip_quote_currency where TRANSACTION_COMPONENT_ID= "+transactionComponentFromId +" )";
	 x  = em.createNativeQuery(query).executeUpdate();
	logger.debug("tlegacy_wip_quote_currency inserted with " + x);
	
	//tlegacywipquoterepository.insertIntoWipQuote(transactionComponentToId, transactionComponentFromId);
	//tlegacywipquoterepository.insertIntoWipQuoteCurrency(transactionComponentToId, transactionComponentFromId);
	
	
}


public void updateTransactionStatusList(
		List<TtransactionComponentStatus> tTransactionComponentStatusList) {
	ttransactioncomponentstatusrepository.save(tTransactionComponentStatusList);
	
}

public void updateStatusHistory(List<TtransactionComponentStatH> fromStatusList) {
	
	tTransactionComponentStatHRepository.save(fromStatusList);
	
}

public void updateTransactionComponentStatus(String transactionComponentId2,
		short statusFromId, short statusToId) {
	ttransactioncomponentstatusrepository.updateStatus(transactionComponentId2,
			statusFromId,statusToId);
}

public VcomponentProduct retrieveComponentDetails(TlegacyTrnsctnCmpntXtensn fromExtension,
		TlegacyTrnsctnCmpntXtensn toExtension, short profitUnit, String profictCentre, short sectionCd) {
	List<Object[]> objectList = null;
	Object[] objects = null;
	objectList = 	legacyProductMappingRepository.getComponentDetail(NGECommonUtil.convertToString(fromExtension.getTlegacyProductBundling().getId().getProductCd()),
		NGECommonUtil.convertToString(toExtension.getTlegacyProductBundling().getId().getBundledProductCd()), 
		NGECommonUtil.convertToString(profictCentre),
		NGECommonUtil.convertToString(toExtension.getSourceCd()), 
		String.valueOf(sectionCd), 
		String.valueOf(profitUnit), 
		fromExtension.getLegacyProdctCovgTypCd());
		if(null != objectList && !objectList.isEmpty()){
			logger.debug(":::::::::Main If DSP:::::::::::: ");
			objects =  objectList.get(0);
		}else{
			objectList = 	legacyProductMappingRepository.getComponentDetail(fromExtension.getTlegacyProductBundling().getId().getProductCd(),
					toExtension.getTlegacyProductBundling().getId().getBundledProductCd(), 
					profictCentre,
					toExtension.getSourceCd(), 
					String.valueOf("0"), 
					String.valueOf("0"), 
					fromExtension.getLegacyProdctCovgTypCd());
			if(null != objectList && !objectList.isEmpty()){
				logger.debug(":::::::::Main If UWSUBPROD:::::::::::: ");
				objects =  objectList.get(0);
			}	
		}
		if(null != objects){
			VcomponentProductPK arg0 = new VcomponentProductPK();
			arg0.setComponentProductId(Integer.valueOf(objects[0].toString()));
			arg0.setProductDetailId(Integer.valueOf(objects[1].toString()));
			return	vComponentProductRepository.findOne(arg0);
		}
	return null;
}

public Tparty retrieveTparty(String toUnderwriter2) {
	// TODO Auto-generated method stub
	return tPartyRepository.getPartyNo(Integer.valueOf(toUnderwriter2), "UNDERWRITER");
	}
}

