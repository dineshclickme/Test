package com.aig.nge.entities;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-02-19T16:13:04.709+0530")
@StaticMetamodel(TtowerEventPK.class)
public class TtowerEventPK_ {
	public static volatile SingularAttribute<TtowerEventPK, Short> eventId;
	public static volatile SingularAttribute<TtowerEventPK, Short> productTowerId;
	public static volatile SingularAttribute<TtowerEventPK, Short> attributeId;
}
