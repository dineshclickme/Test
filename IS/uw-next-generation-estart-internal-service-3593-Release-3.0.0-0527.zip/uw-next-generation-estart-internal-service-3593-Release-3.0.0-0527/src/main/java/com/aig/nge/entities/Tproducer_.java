package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-02-19T16:13:03.853+0530")
@StaticMetamodel(Tproducer.class)
public class Tproducer_ {
	public static volatile SingularAttribute<Tproducer, Integer> partyId;
	public static volatile SingularAttribute<Tproducer, Timestamp> createTs;
	public static volatile SingularAttribute<Tproducer, String> createUserId;
	public static volatile SingularAttribute<Tproducer, String> organizationNm;
	public static volatile SingularAttribute<Tproducer, Timestamp> updateTs;
	public static volatile SingularAttribute<Tproducer, String> updateUserId;
	public static volatile SingularAttribute<Tproducer, Tparty> tparty;
}
