package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the TTRANSACTION_ATTRIBUTE_HS database table.
 * 
 */
@Embeddable
public class TtransactionAttributeHPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="TRANSACTION_ID")
	private String transactionId;

	@Column(name="VERSION_SQN")
	private short versionSqn;

	@Column(name="ATTRIBUTE_ID")
	private short attributeId;

	@Column(name="ATTRIBUTE_SQN")
	private short attributeSqn;

    @Temporal( TemporalType.TIMESTAMP)
	@Column(name="CREATE_HISTORY_TS")
	private java.util.Date createHistoryTs;

    public TtransactionAttributeHPK() {
    }
	public String getTransactionId() {
		return this.transactionId;
	}
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	public short getVersionSqn() {
		return this.versionSqn;
	}
	public void setVersionSqn(short versionSqn) {
		this.versionSqn = versionSqn;
	}
	public short getAttributeId() {
		return this.attributeId;
	}
	public void setAttributeId(short attributeId) {
		this.attributeId = attributeId;
	}
	public short getAttributeSqn() {
		return this.attributeSqn;
	}
	public void setAttributeSqn(short attributeSqn) {
		this.attributeSqn = attributeSqn;
	}
	public java.util.Date getCreateHistoryTs() {
		return this.createHistoryTs;
	}
	public void setCreateHistoryTs(java.util.Date createHistoryTs) {
		this.createHistoryTs = createHistoryTs;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof TtransactionAttributeHPK)) {
			return false;
		}
		TtransactionAttributeHPK castOther = (TtransactionAttributeHPK)other;
		return 
			this.transactionId.equals(castOther.transactionId)
			&& (this.versionSqn == castOther.versionSqn)
			&& (this.attributeId == castOther.attributeId)
			&& (this.attributeSqn == castOther.attributeSqn)
			&& this.createHistoryTs.equals(castOther.createHistoryTs);

    }
    
	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.transactionId.hashCode();
		hash = hash * prime + ((int) this.versionSqn);
		hash = hash * prime + ((int) this.attributeId);
		hash = hash * prime + ((int) this.attributeSqn);
		hash = hash * prime + this.createHistoryTs.hashCode();
		
		return hash;
    }
}