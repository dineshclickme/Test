package com.aig.nge.entities;

import java.math.BigDecimal;
import java.text.DecimalFormat;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import com.aig.nge.utilities.NGECommonUtil;

@Entity
public class BlockedProductDetailsBO {
	
	@Id
	@Column(name="BLOCK_NO")
	private Integer blockNo;
	@Column(name = "TRANSACTION_ID")
    private long transactionId;
	@Column(name = "VERSION_SQN")
	private short transactionVersionNo;
    @Column(name = "SUBMISSION_NO")
    private Long submissionNo;
    @Column(name = "ORGANIZATION_NM")
    private String accountName;
    @Column(name = "UNDERWRITER_ID")
    private String underWriterId;
    @Column(name = "ALT_CONTACT_UNDERWRITER_ID")
    private String altContactUnderwriterId;
    @Column(name = "MARKETABLE_PRODUCT_SEGMENT_CD")
    private String marketableProductSegmentCd;
    @Column(name = "MARKETABLE_PRODUCT_SUB_SGMT_CD")
    private String marketableProductSubSegmentCd;
    @Column(name = "COMPONENT_SEGMENT_CD")
    private String componentProductSegmentCd;
    @Column(name = "COMPONENT_SUB_SEGMENT_CD")
    private String componentProductSubSegmentCd;
    @Column(name = "MARKETABLE_PRODUCT_CD")
    private String marketableProductCd;
    @Column(name = "MARKETABLE_PRODUCT_NM")
    private String marketableProductNm;
    @Column(name = "TUW_SUB_PRODUCT_CD")
    private String componentProductCd;
    @Column(name = "TUW_SUB_PRODUCT_NM")
    private String componentProductNm;
    @Column(name = "TRANSACTION_COMPONENT_ID")
    private Long transactionComponentId;
    @Column(name = "REASON_NM")
    private String reasonCd;
    @Column(name = "REASON_DS")
    private String reasonDs;
    @Column(name = "STATUS_ID")
    private String blockStatus;
    @Column(name = "BLOCKING_EXTENSION_DT")
    private String blockingExpirationDt;
    @Column(name = "CURRENCY_ID")
    private String currencyId;
    @Column(name = "ATTACHMENT_POINT_AM")
    private String attachmentPointAm;
    @Column(name = "LIMIT_AM")
    private String limitAm;
    @Column(name = "PREMIUM_AM")
    private String premiumAM;
    @Column(name = "TECHNICAL_PRICE_AM")
    private String technicalPriceAm;
    @Column(name = "EXPIRING_PREMIUM_AM")
    private String expiringPremiumAm;
    @Column(name = "BLOCK_LEVEL_NO")
    private int blockLevelNo; 
    

	public int getBlockLevelNo() {
		return blockLevelNo;
	}
	public void setBlockLevelNo(int blockLevelNo) {
		this.blockLevelNo = blockLevelNo;
	}
	public Integer getBlockNo() {
		return blockNo;
	}
	public void setBlockNo(Integer blockNo) {
		this.blockNo = blockNo;
	}
	public long getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(long transactionId) {
		this.transactionId = transactionId;
	}
	public short getTransactionVersionNo() {
		return transactionVersionNo;
	}
	public void setTransactionVersionNo(short transactionVersionNo) {
		this.transactionVersionNo = transactionVersionNo;
	}
	public Long getSubmissionNo() {
		return submissionNo;
	}
	public void setSubmissionNo(Long submissionNo) {
		this.submissionNo = submissionNo;
	}
	
	public String getMarketableProductSegmentCd() {
		return marketableProductSegmentCd;
	}
	public void setMarketableProductSegmentCd(String marketableProductSegmentCd) {
		this.marketableProductSegmentCd = marketableProductSegmentCd;
	}
	public String getMarketableProductSubSegmentCd() {
		return marketableProductSubSegmentCd;
	}
	public void setMarketableProductSubSegmentCd(
			String marketableProductSubSegmentCd) {
		this.marketableProductSubSegmentCd = marketableProductSubSegmentCd;
	}
	public String getComponentProductSegmentCd() {
		return componentProductSegmentCd;
	}
	public void setComponentProductSegmentCd(String componentProductSegmentCd) {
		this.componentProductSegmentCd = componentProductSegmentCd;
	}
	public String getComponentProductSubSegmentCd() {
		return componentProductSubSegmentCd;
	}
	public void setComponentProductSubSegmentCd(String componentProductSubSegmentCd) {
		this.componentProductSubSegmentCd = componentProductSubSegmentCd;
	}
	public String getMarketableProductCd() {
		return marketableProductCd;
	}
	public void setMarketableProductCd(String marketableProductCd) {
		this.marketableProductCd = marketableProductCd;
	}
	public String getMarketableProductNm() {
		return marketableProductNm;
	}
	public void setMarketableProductNm(String marketableProductNm) {
		this.marketableProductNm = marketableProductNm;
	}
	public String getComponentProductCd() {
		return componentProductCd;
	}
	public void setComponentProductCd(String componentProductCd) {
		this.componentProductCd = componentProductCd;
	}
	public String getComponentProductNm() {
		return componentProductNm;
	}
	public void setComponentProductNm(String componentProductNm) {
		this.componentProductNm = componentProductNm;
	}
	public Long getTransactionComponentId() {
		return transactionComponentId;
	}
	public void setTransactionComponentId(Long transactionComponentId) {
		this.transactionComponentId = transactionComponentId;
	}
	public String getReasonCd() {
		return NGECommonUtil.convertToString(reasonCd);
	}
	public void setReasonCd(String reasonCd) {
		this.reasonCd = reasonCd;
	}
	public String getReasonDs() {
		return reasonDs;
	}
	public void setReasonDs(String reasonDs) {
		this.reasonDs = reasonDs;
	}
	public String getBlockStatus() {
		return blockStatus;
	}
	public void setBlockStatus(String blockStatus) {
		this.blockStatus = blockStatus;
	}
	public String getBlockingExpirationDt() {
		return blockingExpirationDt;
	}
	public void setBlockingExpirationDt(String blockingExpirationDt) {
		this.blockingExpirationDt = blockingExpirationDt;
	}
	
	public String getAttachmentPointAm() {
		DecimalFormat df = new DecimalFormat("0.000000");
		if(attachmentPointAm != null)
			return df.format(new BigDecimal(attachmentPointAm.trim()));
		else
			return attachmentPointAm;
		
	}
	public void setAttachmentPointAm(String attachmentPointAm) {
		this.attachmentPointAm = attachmentPointAm;
	}
	public String getLimitAm() {
		DecimalFormat df = new DecimalFormat("0.000000");
		if(limitAm != null)
			return df.format(new BigDecimal(limitAm.trim()));
		else
			return limitAm;
	}
	public void setLimitAm(String limitAm) {
		this.limitAm = limitAm;
	}
	public String getPremiumAM() {
		DecimalFormat df = new DecimalFormat("0.000000");
		if(premiumAM != null)
			return df.format(new BigDecimal(premiumAM.trim()));
		else
			return premiumAM;
	}
	public void setPremiumAM(String premiumAM) {
		this.premiumAM = premiumAM;
	}
	public String getTechnicalPriceAm() {
		DecimalFormat df = new DecimalFormat("0.000000");
		if(technicalPriceAm != null)
			return df.format(new BigDecimal(technicalPriceAm.trim()));
		else
			return technicalPriceAm;
	}
	public void setTechnicalPriceAm(String technicalPriceAm) {
		this.technicalPriceAm = technicalPriceAm;
	}
	public String getExpiringPremiumAm() {
		DecimalFormat df = new DecimalFormat("0.000000");
		if(expiringPremiumAm != null)
			return df.format(new BigDecimal(expiringPremiumAm.trim()));
		else
			return expiringPremiumAm;
	}
	public void setExpiringPremiumAm(String expiringPremiumAm) {
		this.expiringPremiumAm = expiringPremiumAm;
	}
	public String getAccountName() {
		return accountName;
	}
	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}
	public String getUnderWriterId() {
		return underWriterId;
	}
	public void setUnderWriterId(String underWriterId) {
		this.underWriterId = underWriterId;
	}
	public String getAltContactUnderwriterId() {
		return altContactUnderwriterId;
	}
	public void setAltContactUnderwriterId(String altContactUnderwriterId) {
		this.altContactUnderwriterId = altContactUnderwriterId;
	}
	public String getCurrencyId() {
		return currencyId;
	}
	public void setCurrencyId(String currencyId) {
		this.currencyId = currencyId;
	}
}
