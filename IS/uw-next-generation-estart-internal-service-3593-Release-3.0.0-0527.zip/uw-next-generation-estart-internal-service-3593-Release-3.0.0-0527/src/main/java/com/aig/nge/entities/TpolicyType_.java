package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SetAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-02-19T16:13:03.835+0530")
@StaticMetamodel(TpolicyType.class)
public class TpolicyType_ {
	public static volatile SingularAttribute<TpolicyType, Short> policyTypeId;
	public static volatile SingularAttribute<TpolicyType, Timestamp> createTs;
	public static volatile SingularAttribute<TpolicyType, String> createUserId;
	public static volatile SingularAttribute<TpolicyType, String> policyTypeNm;
	public static volatile SingularAttribute<TpolicyType, Timestamp> updateTs;
	public static volatile SingularAttribute<TpolicyType, String> updateUserId;
	public static volatile SetAttribute<TpolicyType, Tpolicy> tpolicies;
}
