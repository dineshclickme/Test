package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-12-15T15:01:20.440+0530")
@StaticMetamodel(TlegacySubmissionXpsr.class)
public class TlegacySubmissionXpsr_ {
	public static volatile SingularAttribute<TlegacySubmissionXpsr, TlegacySubmissionXpsrPK> id;
	public static volatile SingularAttribute<TlegacySubmissionXpsr, Timestamp> createTs;
	public static volatile SingularAttribute<TlegacySubmissionXpsr, String> createUserId;
	public static volatile SingularAttribute<TlegacySubmissionXpsr, Timestamp> updateTs;
	public static volatile SingularAttribute<TlegacySubmissionXpsr, String> updateUserId;
	public static volatile SingularAttribute<TlegacySubmissionXpsr, Tsubmission> tsubmission;
	public static volatile SingularAttribute<TlegacySubmissionXpsr, Tsource> tsource;
}
