package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the TTRANSACTION_COMPONENT_BRANCH database table.
 * 
 */
@Entity
@Table(name="TTRANSACTION_COMPONENT_BRANCH")
public class TtransactionComponentBranch implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private TtransactionComponentBranchPK id;

	@Column(name="CREATE_TS")
	private Timestamp createTs;

	@Column(name="CREATE_USER_ID")
	private String createUserId;

	@Column(name="SYSTEM_ID")
	private short systemId;

	@Column(name="UPDATE_TS")
	private Timestamp updateTs;

	@Column(name="UPDATE_USER_ID")
	private String updateUserId;

	//bi-directional many-to-one association to Tbranch
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="BRANCH_ID")
	private Tbranch tbranch;

	//bi-directional many-to-one association to TbranchType
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="BRANCH_TYPE_ID")
	private TbranchType tbranchType;

	//bi-directional many-to-one association to TtransactionComponent
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="TRANSACTION_COMPONENT_ID")
	private TtransactionComponent ttransactionComponent;

    public TtransactionComponentBranch() {
    }

	public TtransactionComponentBranchPK getId() {
		return this.id;
	}

	public void setId(TtransactionComponentBranchPK id) {
		this.id = id;
	}
	
	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public short getSystemId() {
		return this.systemId;
	}

	public void setSystemId(short systemId) {
		this.systemId = systemId;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public Tbranch getTbranch() {
		return this.tbranch;
	}

	public void setTbranch(Tbranch tbranch) {
		this.tbranch = tbranch;
	}
	
	public TbranchType getTbranchType() {
		return this.tbranchType;
	}

	public void setTbranchType(TbranchType tbranchType) {
		this.tbranchType = tbranchType;
	}
	
	public TtransactionComponent getTtransactionComponent() {
		return this.ttransactionComponent;
	}

	public void setTtransactionComponent(TtransactionComponent ttransactionComponent) {
		this.ttransactionComponent = ttransactionComponent;
	}
	
}