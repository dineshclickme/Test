package com.aig.nge.entities;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-04-15T15:31:47.415+0530")
@StaticMetamodel(TlegacyWipQuotePK.class)
public class TlegacyWipQuotePK_ {
	public static volatile SingularAttribute<TlegacyWipQuotePK, String> transactionComponentId;
	public static volatile SingularAttribute<TlegacyWipQuotePK, String> wipId;
	public static volatile SingularAttribute<TlegacyWipQuotePK, Short> quoteSqn;
}
