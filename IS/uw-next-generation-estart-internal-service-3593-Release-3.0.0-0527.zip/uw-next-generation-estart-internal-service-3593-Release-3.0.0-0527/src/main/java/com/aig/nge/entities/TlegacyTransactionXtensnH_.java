package com.aig.nge.entities;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-09-11T14:03:53.734+0530")
@StaticMetamodel(TlegacyTransactionXtensnH.class)
public class TlegacyTransactionXtensnH_ {
	public static volatile SingularAttribute<TlegacyTransactionXtensnH, TlegacyTransactionXtensnHPK> id;
	public static volatile SingularAttribute<TlegacyTransactionXtensnH, Timestamp> createTs;
	public static volatile SingularAttribute<TlegacyTransactionXtensnH, BigDecimal> bundleAttachmentAm;
	public static volatile SingularAttribute<TlegacyTransactionXtensnH, String> createUserId;
	public static volatile SingularAttribute<TlegacyTransactionXtensnH, Timestamp> updateTs;
	public static volatile SingularAttribute<TlegacyTransactionXtensnH, String> updateUserId;
	public static volatile SingularAttribute<TlegacyTransactionXtensnH, BigDecimal> bundleLimitAm;
	public static volatile SingularAttribute<TlegacyTransactionXtensnH, BigDecimal> bundlePartOfAm;
	public static volatile SingularAttribute<TlegacyTransactionXtensnH, BigDecimal> bundlePremiumAm;
	public static volatile SingularAttribute<TlegacyTransactionXtensnH, Integer> carrierId;
	public static volatile SingularAttribute<TlegacyTransactionXtensnH, String> legacyBundledCovgTypeCd;
	public static volatile SingularAttribute<TlegacyTransactionXtensnH, BigDecimal> localBundleAttachmentAm;
	public static volatile SingularAttribute<TlegacyTransactionXtensnH, BigDecimal> localBundleLimitAm;
	public static volatile SingularAttribute<TlegacyTransactionXtensnH, BigDecimal> localBundlePartOfAm;
	public static volatile SingularAttribute<TlegacyTransactionXtensnH, BigDecimal> localBundlePremiumAm;
	public static volatile SingularAttribute<TlegacyTransactionXtensnH, String> nonRecurringIn;
	public static volatile SingularAttribute<TlegacyTransactionXtensnH, String> profitCenterCd;
	public static volatile SingularAttribute<TlegacyTransactionXtensnH, Short> profitUnitCd;
	public static volatile SingularAttribute<TlegacyTransactionXtensnH, Integer> rrPrtctvContNo;
	public static volatile SingularAttribute<TlegacyTransactionXtensnH, Short> sectionCd;
	public static volatile SingularAttribute<TlegacyTransactionXtensnH, String> specialEventNm;
	public static volatile SingularAttribute<TlegacyTransactionXtensnH, Date> underwritingDt;
}
