package com.aig.nge.entities;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-08-04T13:12:21.305+0530")
@StaticMetamodel(TlegacyProductDspPK.class)
public class TlegacyProductDspPK_ {
	public static volatile SingularAttribute<TlegacyProductDspPK, String> prodctCovgTypCd;
	public static volatile SingularAttribute<TlegacyProductDspPK, String> profitCenterCd;
	public static volatile SingularAttribute<TlegacyProductDspPK, String> productCd;
	public static volatile SingularAttribute<TlegacyProductDspPK, Short> sectionCd;
	public static volatile SingularAttribute<TlegacyProductDspPK, Short> profitUnitCd;
	public static volatile SingularAttribute<TlegacyProductDspPK, String> sourceCd;
}
