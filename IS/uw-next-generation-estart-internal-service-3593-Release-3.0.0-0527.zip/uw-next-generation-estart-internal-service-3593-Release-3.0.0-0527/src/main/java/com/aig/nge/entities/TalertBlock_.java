package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-02-19T16:13:02.782+0530")
@StaticMetamodel(TalertBlock.class)
public class TalertBlock_ {
	public static volatile SingularAttribute<TalertBlock, Integer> blockNo;
	public static volatile SingularAttribute<TalertBlock, Timestamp> createTs;
	public static volatile SingularAttribute<TalertBlock, String> createUserId;
	public static volatile SingularAttribute<TalertBlock, Integer> submissionEvaluationCd;
	public static volatile SingularAttribute<TalertBlock, Short> systemId;
	public static volatile SingularAttribute<TalertBlock, Timestamp> updateTs;
	public static volatile SingularAttribute<TalertBlock, String> updateUserId;
	public static volatile SingularAttribute<TalertBlock, Tblock> tblock;
}
