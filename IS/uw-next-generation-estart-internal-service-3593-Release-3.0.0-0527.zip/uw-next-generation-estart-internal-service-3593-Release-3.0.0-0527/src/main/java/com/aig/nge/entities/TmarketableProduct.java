package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;

import org.apache.openjpa.persistence.DataCache;
import java.sql.Timestamp;
import java.util.Set;


/**
 * The persistent class for the TMARKETABLE_PRODUCT database table.
 * 
 */
@Entity
@DataCache
@Table(name="TMARKETABLE_PRODUCT")
public class TmarketableProduct implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="MARKETABLE_PRODUCT_ID")
	private int marketableProductId;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="CREATE_TS")
	private Timestamp createTs;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="CREATE_USER_ID")
	private String createUserId;

	@Column(name="DELETED_IN")
	private String deletedIn;

	@Column(name="MARKETABLE_PRODUCT_CD")
	private String marketableProductCd;

	@Column(name="MARKETABLE_PRODUCT_NM")
	private String marketableProductNm;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="UPDATE_TS")
	private Timestamp updateTs;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="UPDATE_USER_ID")
	private String updateUserId;

	//bi-directional one-to-one association to Tproduct
	@OneToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="MARKETABLE_PRODUCT_ID")
	private Tproduct tproduct;

	//bi-directional many-to-one association to TproductTower
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="PRODUCT_TOWER_ID")
	private TproductTower tproductTower;

	//bi-directional many-to-one association to TmarketableProductComponent
	@OneToMany(mappedBy="tmarketableProduct", cascade={CascadeType.ALL})
	private Set<TmarketableProductComponent> tmarketableProductComponents;
	
	//bi-directional many-to-one association to TmarketableProductLocation
	@OneToMany(mappedBy="tmarketableProduct", cascade={CascadeType.ALL})
	private Set<TmarketableProductLocation> tmarketableProductLocation;

    public TmarketableProduct() {
    }

	public int getMarketableProductId() {
		return this.marketableProductId;
	}

	public void setMarketableProductId(int marketableProductId) {
		this.marketableProductId = marketableProductId;
	}

	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public String getDeletedIn() {
		return this.deletedIn;
	}

	public void setDeletedIn(String deletedIn) {
		this.deletedIn = deletedIn;
	}

	public String getMarketableProductCd() {
		return this.marketableProductCd;
	}

	public void setMarketableProductCd(String marketableProductCd) {
		this.marketableProductCd = marketableProductCd;
	}

	public String getMarketableProductNm() {
		return this.marketableProductNm;
	}

	public void setMarketableProductNm(String marketableProductNm) {
		this.marketableProductNm = marketableProductNm;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public Tproduct getTproduct() {
		return this.tproduct;
	}

	public void setTproduct(Tproduct tproduct) {
		this.tproduct = tproduct;
	}
	
	public TproductTower getTproductTower() {
		return this.tproductTower;
	}

	public void setTproductTower(TproductTower tproductTower) {
		this.tproductTower = tproductTower;
	}
	
	public Set<TmarketableProductComponent> getTmarketableProductComponents() {
		return this.tmarketableProductComponents;
	}

	public void setTmarketableProductComponents(Set<TmarketableProductComponent> tmarketableProductComponents) {
		this.tmarketableProductComponents = tmarketableProductComponents;
	}

	public Set<TmarketableProductLocation> getTmarketableProductLocation() {
		return tmarketableProductLocation;
	}

	public void setTmarketableProductLocation(
			Set<TmarketableProductLocation> tmarketableProductLocation) {
		this.tmarketableProductLocation = tmarketableProductLocation;
	}
	
}