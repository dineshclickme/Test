package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-03-02T12:10:25.188+0530")
@StaticMetamodel(TtransactionCmpntBranchH.class)
public class TtransactionCmpntBranchH_ {
	public static volatile SingularAttribute<TtransactionCmpntBranchH, TtransactionCmpntBranchHPK> id;
	public static volatile SingularAttribute<TtransactionCmpntBranchH, Integer> branchId;
	public static volatile SingularAttribute<TtransactionCmpntBranchH, Timestamp> createTs;
	public static volatile SingularAttribute<TtransactionCmpntBranchH, String> createUserId;
	public static volatile SingularAttribute<TtransactionCmpntBranchH, Short> systemId;
	public static volatile SingularAttribute<TtransactionCmpntBranchH, String> updateUserId;
	public static volatile SingularAttribute<TtransactionCmpntBranchH, Timestamp> updateTs;
}
