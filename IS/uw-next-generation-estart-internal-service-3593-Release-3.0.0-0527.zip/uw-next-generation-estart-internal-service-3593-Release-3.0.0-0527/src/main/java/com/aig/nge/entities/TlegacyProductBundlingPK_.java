package com.aig.nge.entities;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-04-15T15:31:47.041+0530")
@StaticMetamodel(TlegacyProductBundlingPK.class)
public class TlegacyProductBundlingPK_ {
	public static volatile SingularAttribute<TlegacyProductBundlingPK, String> productCd;
	public static volatile SingularAttribute<TlegacyProductBundlingPK, String> bundledProductCd;
}
