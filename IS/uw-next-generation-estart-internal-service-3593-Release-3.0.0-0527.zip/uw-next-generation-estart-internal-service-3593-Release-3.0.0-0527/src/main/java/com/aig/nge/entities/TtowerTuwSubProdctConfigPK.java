package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the TTOWER_TUW_SUB_PRODCT_CONFIG database table.
 * 
 */
@Embeddable
public class TtowerTuwSubProdctConfigPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="CONFIGURATION_ID")
	private int configurationId;

	@Column(name="TUW_SUB_PRODUCT_ID")
	private int tuwSubProductId;

    public TtowerTuwSubProdctConfigPK() {
    }
	public int getConfigurationId() {
		return this.configurationId;
	}
	public void setConfigurationId(int configurationId) {
		this.configurationId = configurationId;
	}
	public int getTuwSubProductId() {
		return this.tuwSubProductId;
	}
	public void setTuwSubProductId(int tuwSubProductId) {
		this.tuwSubProductId = tuwSubProductId;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof TtowerTuwSubProdctConfigPK)) {
			return false;
		}
		TtowerTuwSubProdctConfigPK castOther = (TtowerTuwSubProdctConfigPK)other;
		return 
			(this.configurationId == castOther.configurationId)
			&& (this.tuwSubProductId == castOther.tuwSubProductId);

    }
    
	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.configurationId;
		hash = hash * prime + this.tuwSubProductId;
		
		return hash;
    }
}