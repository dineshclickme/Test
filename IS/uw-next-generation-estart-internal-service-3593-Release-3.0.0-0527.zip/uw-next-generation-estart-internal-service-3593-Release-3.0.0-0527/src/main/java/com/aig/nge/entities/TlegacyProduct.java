package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Date;
import java.util.Set;


/**
 * The persistent class for the TLEGACY_PRODUCT database table.
 * 
 */
@Entity
@Table(name="TLEGACY_PRODUCT")
public class TlegacyProduct implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="PRODUCT_CD")
	private String productCd;

	@Column(name="BLK_MJPRD_GRP_IN")
	private String blkMjprdGrpIn;

	@Column(name="BUNDLE_TYPE_CD")
	private String bundleTypeCd;

	@Column(name="BYPASS_BLOCKING_IN")
	private String bypassBlockingIn;

	@Column(name="CREATED_BY_ID")
	private String createdById;

    @Temporal( TemporalType.DATE)
	@Column(name="ENTERED_DT")
	private Date enteredDt;

	@Column(name="LAST_UPDT_TS")
	private Timestamp lastUpdtTs;

	@Column(name="LAST_UPDT_USER_ID")
	private String lastUpdtUserId;

	@Column(name="LEAD_UMBRELLA_IN")
	private String leadUmbrellaIn;

	@Column(name="LOSS_CONTROL_IN")
	private String lossControlIn;

	@Column(name="LST1_OPTNL_REQD_IN")
	private String lst1OptnlReqdIn;

	@Column(name="ONLY1_OPTL_ALWD_IN")
	private String only1OptlAlwdIn;

	@Column(name="PRMRY_COVG_ALWD_IN")
	private String prmryCovgAlwdIn;

	@Column(name="PRODUCT_DS")
	private String productDs;

    @Temporal( TemporalType.DATE)
	@Column(name="PRODUCT_EFCTV_DT")
	private Date productEfctvDt;

	@Column(name="PRODUCT_NM")
	private String productNm;

	@Column(name="PRODUCT_SHORT_NM")
	private String productShortNm;

    @Temporal( TemporalType.DATE)
	@Column(name="PRODUCT_XPRTN_DT")
	private Date productXprtnDt;

	@Column(name="PRODUCTION_IN")
	private String productionIn;

	@Column(name="RR_PROTECTIVE_IN")
	private String rrProtectiveIn;

	@Column(name="SPECIAL_EVENT_IN")
	private String specialEventIn;

	@Column(name="STATUTORY_LIMIT_IN")
	private String statutoryLimitIn;

	@Column(name="WORLDWIDE_XPSR_IN")
	private String worldwideXpsrIn;

	@Column(name="XCES_COVG_ALWD_IN")
	private String xcesCovgAlwdIn;

	//bi-directional many-to-one association to TlegacyMinorProductBlock
	@OneToMany(mappedBy="tlegacyProduct")
	private Set<TlegacyMinorProductBlock> tlegacyMinorProductBlocks;

	//bi-directional many-to-one association to TlegacyMinorProductGroup
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumns({
		@JoinColumn(name="MJR_PRODUCT_GRP_CD", referencedColumnName="MJR_PRODUCT_GRP_CD"),
		@JoinColumn(name="MNR_PRODUCT_GRP_CD", referencedColumnName="MNR_PRODUCT_GRP_CD")
		})
	private TlegacyMinorProductGroup tlegacyMinorProductGroup;

	//bi-directional many-to-one association to TlegacyProductBundling
	@OneToMany(mappedBy="tlegacyProduct1")
	private Set<TlegacyProductBundling> tlegacyProductBundlings1;

	//bi-directional many-to-one association to TlegacyProductBundling
	@OneToMany(mappedBy="tlegacyProduct2")
	private Set<TlegacyProductBundling> tlegacyProductBundlings2;

	//bi-directional many-to-one association to TlegacyProductMapping
	@OneToMany(mappedBy="tlegacyProduct")
	private Set<TlegacyProductMapping> tlegacyProductMappings;

	//bi-directional many-to-one association to TlegacyProfitCenterProduct
	@OneToMany(mappedBy="tlegacyProduct")
	private Set<TlegacyProfitCenterProduct> tlegacyProfitCenterProducts;

	//bi-directional many-to-one association to TlegacyTransactionExtension
	@OneToMany(mappedBy="tlegacyProduct")
	private Set<TlegacyTransactionExtension> tlegacyTransactionExtensions;

	//bi-directional many-to-one association to TlegacyTrnsctnCmpntXtensn
	@OneToMany(mappedBy="tlegacyProduct")
	private Set<TlegacyTrnsctnCmpntXtensn> tlegacyTrnsctnCmpntXtensns;

    public TlegacyProduct() {
    }

	public String getProductCd() {
		return this.productCd;
	}

	public void setProductCd(String productCd) {
		this.productCd = productCd;
	}

	public String getBlkMjprdGrpIn() {
		if(this.blkMjprdGrpIn != null)
			return this.blkMjprdGrpIn.trim();
		else
			return this.blkMjprdGrpIn;
	}

	public void setBlkMjprdGrpIn(String blkMjprdGrpIn) {
		this.blkMjprdGrpIn = blkMjprdGrpIn;
	}

	public String getBundleTypeCd() {
		if(this.bundleTypeCd != null)
			return this.bundleTypeCd.trim();
		else
			return this.bundleTypeCd;
	}

	public void setBundleTypeCd(String bundleTypeCd) {
		this.bundleTypeCd = bundleTypeCd;
	}

	public String getBypassBlockingIn() {
		if(this.bypassBlockingIn != null)
			return this.bypassBlockingIn.trim();
		else
			return this.bypassBlockingIn;
	}

	public void setBypassBlockingIn(String bypassBlockingIn) {
		this.bypassBlockingIn = bypassBlockingIn;
	}

	public String getCreatedById() {
		return this.createdById;
	}

	public void setCreatedById(String createdById) {
		this.createdById = createdById;
	}

	public Date getEnteredDt() {
		return this.enteredDt;
	}

	public void setEnteredDt(Date enteredDt) {
		this.enteredDt = enteredDt;
	}

	public Timestamp getLastUpdtTs() {
		return this.lastUpdtTs;
	}

	public void setLastUpdtTs(Timestamp lastUpdtTs) {
		this.lastUpdtTs = lastUpdtTs;
	}

	public String getLastUpdtUserId() {
		return this.lastUpdtUserId;
	}

	public void setLastUpdtUserId(String lastUpdtUserId) {
		this.lastUpdtUserId = lastUpdtUserId;
	}

	public String getLeadUmbrellaIn() {
		if(this.leadUmbrellaIn != null)
			return this.leadUmbrellaIn.trim();
		else
			return this.leadUmbrellaIn;
	}

	public void setLeadUmbrellaIn(String leadUmbrellaIn) {
		this.leadUmbrellaIn = leadUmbrellaIn;
	}

	public String getLossControlIn() {
		if(this.lossControlIn != null)
			return this.lossControlIn.trim();
		else
			return this.lossControlIn;
	}

	public void setLossControlIn(String lossControlIn) {
		this.lossControlIn = lossControlIn;
	}

	public String getLst1OptnlReqdIn() {
		if(this.lst1OptnlReqdIn != null)
			return this.lst1OptnlReqdIn.trim();
		else
			return this.lst1OptnlReqdIn;
	}

	public void setLst1OptnlReqdIn(String lst1OptnlReqdIn) {
		this.lst1OptnlReqdIn = lst1OptnlReqdIn;
	}

	public String getOnly1OptlAlwdIn() {
		if(this.only1OptlAlwdIn != null)
			return this.only1OptlAlwdIn.trim();
		else
			return this.only1OptlAlwdIn;
	}

	public void setOnly1OptlAlwdIn(String only1OptlAlwdIn) {
		this.only1OptlAlwdIn = only1OptlAlwdIn;
	}

	public String getPrmryCovgAlwdIn() {
		if(this.prmryCovgAlwdIn != null)
			return this.prmryCovgAlwdIn.trim();
		else
			return this.prmryCovgAlwdIn;
	}

	public void setPrmryCovgAlwdIn(String prmryCovgAlwdIn) {
		this.prmryCovgAlwdIn = prmryCovgAlwdIn;
	}

	public String getProductDs() {
		if(this.productDs != null)
			return this.productDs.trim();
		else
			return this.productDs;
	}

	public void setProductDs(String productDs) {
		this.productDs = productDs;
	}

	public Date getProductEfctvDt() {
		return this.productEfctvDt;
	}

	public void setProductEfctvDt(Date productEfctvDt) {
		this.productEfctvDt = productEfctvDt;
	}

	public String getProductNm() {
		return this.productNm;
	}

	public void setProductNm(String productNm) {
		this.productNm = productNm;
	}

	public String getProductShortNm() {
		return this.productShortNm;
	}

	public void setProductShortNm(String productShortNm) {
		this.productShortNm = productShortNm;
	}

	public Date getProductXprtnDt() {
		return this.productXprtnDt;
	}

	public void setProductXprtnDt(Date productXprtnDt) {
		this.productXprtnDt = productXprtnDt;
	}

	public String getProductionIn() {
		if(this.productionIn != null)
			return this.productionIn.trim();
		else
			return this.productionIn;
	}

	public void setProductionIn(String productionIn) {
		this.productionIn = productionIn;
	}

	public String getRrProtectiveIn() {
		if(this.rrProtectiveIn != null)
			return this.rrProtectiveIn.trim();
		else
			return this.rrProtectiveIn;
	}

	public void setRrProtectiveIn(String rrProtectiveIn) {
		this.rrProtectiveIn = rrProtectiveIn;
	}

	public String getSpecialEventIn() {
		if(this.specialEventIn != null)
			return this.specialEventIn.trim();
		else
			return this.specialEventIn;
	}

	public void setSpecialEventIn(String specialEventIn) {
		this.specialEventIn = specialEventIn;
	}

	public String getStatutoryLimitIn() {
		if(this.statutoryLimitIn != null) 
			return this.statutoryLimitIn.trim();
		else
			return this.statutoryLimitIn;
	}

	public void setStatutoryLimitIn(String statutoryLimitIn) {
		this.statutoryLimitIn = statutoryLimitIn;
	}

	public String getWorldwideXpsrIn() {
		if(this.worldwideXpsrIn != null)
			return this.worldwideXpsrIn.trim();
		else
			return this.worldwideXpsrIn;
	}

	public void setWorldwideXpsrIn(String worldwideXpsrIn) {
		this.worldwideXpsrIn = worldwideXpsrIn;
	}

	public String getXcesCovgAlwdIn() {
		if(this.xcesCovgAlwdIn != null)
			return this.xcesCovgAlwdIn.trim();
		else
			return this.xcesCovgAlwdIn;
	}

	public void setXcesCovgAlwdIn(String xcesCovgAlwdIn) {
		this.xcesCovgAlwdIn = xcesCovgAlwdIn;
	}

	public Set<TlegacyMinorProductBlock> getTlegacyMinorProductBlocks() {
		return this.tlegacyMinorProductBlocks;
	}

	public void setTlegacyMinorProductBlocks(Set<TlegacyMinorProductBlock> tlegacyMinorProductBlocks) {
		this.tlegacyMinorProductBlocks = tlegacyMinorProductBlocks;
	}
	
	public TlegacyMinorProductGroup getTlegacyMinorProductGroup() {
		return this.tlegacyMinorProductGroup;
	}

	public void setTlegacyMinorProductGroup(TlegacyMinorProductGroup tlegacyMinorProductGroup) {
		this.tlegacyMinorProductGroup = tlegacyMinorProductGroup;
	}
	
	public Set<TlegacyProductBundling> getTlegacyProductBundlings1() {
		return this.tlegacyProductBundlings1;
	}

	public void setTlegacyProductBundlings1(Set<TlegacyProductBundling> tlegacyProductBundlings1) {
		this.tlegacyProductBundlings1 = tlegacyProductBundlings1;
	}
	
	public Set<TlegacyProductBundling> getTlegacyProductBundlings2() {
		return this.tlegacyProductBundlings2;
	}

	public void setTlegacyProductBundlings2(Set<TlegacyProductBundling> tlegacyProductBundlings2) {
		this.tlegacyProductBundlings2 = tlegacyProductBundlings2;
	}
	
	public Set<TlegacyProductMapping> getTlegacyProductMappings() {
		return this.tlegacyProductMappings;
	}

	public void setTlegacyProductMappings(Set<TlegacyProductMapping> tlegacyProductMappings) {
		this.tlegacyProductMappings = tlegacyProductMappings;
	}
	
	public Set<TlegacyProfitCenterProduct> getTlegacyProfitCenterProducts() {
		return this.tlegacyProfitCenterProducts;
	}

	public void setTlegacyProfitCenterProducts(Set<TlegacyProfitCenterProduct> tlegacyProfitCenterProducts) {
		this.tlegacyProfitCenterProducts = tlegacyProfitCenterProducts;
	}
	
	public Set<TlegacyTransactionExtension> getTlegacyTransactionExtensions() {
		return this.tlegacyTransactionExtensions;
	}

	public void setTlegacyTransactionExtensions(Set<TlegacyTransactionExtension> tlegacyTransactionExtensions) {
		this.tlegacyTransactionExtensions = tlegacyTransactionExtensions;
	}
	
	public Set<TlegacyTrnsctnCmpntXtensn> getTlegacyTrnsctnCmpntXtensns() {
		return this.tlegacyTrnsctnCmpntXtensns;
	}

	public void setTlegacyTrnsctnCmpntXtensns(Set<TlegacyTrnsctnCmpntXtensn> tlegacyTrnsctnCmpntXtensns) {
		this.tlegacyTrnsctnCmpntXtensns = tlegacyTrnsctnCmpntXtensns;
	}
	
}