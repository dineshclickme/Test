package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-02-19T16:13:03.490+0530")
@StaticMetamodel(ThelpLanguage.class)
public class ThelpLanguage_ {
	public static volatile SingularAttribute<ThelpLanguage, ThelpLanguagePK> id;
	public static volatile SingularAttribute<ThelpLanguage, Timestamp> createTs;
	public static volatile SingularAttribute<ThelpLanguage, String> createUserId;
	public static volatile SingularAttribute<ThelpLanguage, String> helpTx;
	public static volatile SingularAttribute<ThelpLanguage, Timestamp> updateTs;
	public static volatile SingularAttribute<ThelpLanguage, String> updateUserId;
	public static volatile SingularAttribute<ThelpLanguage, Thelp> thelp;
	public static volatile SingularAttribute<ThelpLanguage, Tlanguage> tlanguage;
}
