package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-09-11T14:03:54.031+0530")
@StaticMetamodel(TseAlertSource.class)
public class TseAlertSource_ {
	public static volatile SingularAttribute<TseAlertSource, TseAlertSourcePK> id;
	public static volatile SingularAttribute<TseAlertSource, Timestamp> createTs;
	public static volatile SingularAttribute<TseAlertSource, String> createUserId;
	public static volatile SingularAttribute<TseAlertSource, Timestamp> updateTs;
	public static volatile SingularAttribute<TseAlertSource, String> updateUserId;
	public static volatile SingularAttribute<TseAlertSource, TsubmissionEvaluationAlert> tsubmissionEvaluationAlert;
	public static volatile SingularAttribute<TseAlertSource, Tsource> tsource;
}
