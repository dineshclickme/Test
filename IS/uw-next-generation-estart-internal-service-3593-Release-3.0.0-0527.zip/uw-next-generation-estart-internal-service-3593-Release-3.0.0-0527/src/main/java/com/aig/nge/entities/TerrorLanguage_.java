package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-08-04T13:12:21.158+0530")
@StaticMetamodel(TerrorLanguage.class)
public class TerrorLanguage_ {
	public static volatile SingularAttribute<TerrorLanguage, TerrorLanguagePK> id;
	public static volatile SingularAttribute<TerrorLanguage, Timestamp> createTs;
	public static volatile SingularAttribute<TerrorLanguage, String> createUserId;
	public static volatile SingularAttribute<TerrorLanguage, String> errorMesageTx;
	public static volatile SingularAttribute<TerrorLanguage, Timestamp> updateTs;
	public static volatile SingularAttribute<TerrorLanguage, String> updateUserId;
	public static volatile SingularAttribute<TerrorLanguage, Terror> terror;
	public static volatile SingularAttribute<TerrorLanguage, Tlanguage> tlanguage;
}
