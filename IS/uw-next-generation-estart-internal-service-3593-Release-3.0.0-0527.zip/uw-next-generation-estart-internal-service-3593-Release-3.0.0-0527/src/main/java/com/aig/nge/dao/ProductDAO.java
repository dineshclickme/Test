package com.aig.nge.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.orm.jpa.JpaSystemException;
import org.springframework.stereotype.Repository;


import com.aig.nge.entities.Tasset;
import com.aig.nge.entities.TassetAttribute;
import com.aig.nge.entities.TassetType;
import com.aig.nge.entities.Tattribute;
import com.aig.nge.entities.Tblock;
import com.aig.nge.entities.TmarketableProductComponent;
import com.aig.nge.entities.TmarketableProductLocation;
// NGE UI sept release changes start
import com.aig.nge.entities.TprdctTwrTuwSubPrdctDiv;
import com.aig.nge.repository.TMarketableProductRepository;
//NGE UI sept release changes end
import com.aig.nge.entities.TproductDsp;
import com.aig.nge.entities.TproductMmcp;
import com.aig.nge.entities.TproductTower;
import com.aig.nge.entities.TproductTowerAttribute;
import com.aig.nge.entities.TproductTowerAttributeUsage;
import com.aig.nge.entities.TproductTowerAutoCloseRule;
import com.aig.nge.entities.TproductTowerDivision;
import com.aig.nge.entities.TproductTowerReason;
import com.aig.nge.entities.TproductTowerReasonPK;
import com.aig.nge.entities.Treason;
import com.aig.nge.entities.Tstatus;
import com.aig.nge.entities.TstatusReasonType;
import com.aig.nge.entities.TstatusReasonTypePK;
import com.aig.nge.entities.TtransactionCmpntXpsrLoc;
import com.aig.nge.entities.TtransactionComponent;
import com.aig.nge.entities.TtransactionComponentAsset;
import com.aig.nge.entities.TtransactionComponentAtrbt;
import com.aig.nge.entities.TtransactionComponentBranch;
import com.aig.nge.entities.TtransactionComponentLimit;
import com.aig.nge.entities.TtransactionComponentParty;
import com.aig.nge.entities.TtransactionComponentPolicy;
import com.aig.nge.entities.TtransactionComponentRltn;
import com.aig.nge.entities.TtransactionComponentStatus;
import com.aig.nge.entities.TtransactionComponentStatusPK;
import com.aig.nge.entities.TtransactionProductAttribute;
import com.aig.nge.entities.TtransactionVersion;
import com.aig.nge.entities.TtuwSubProduct;
import com.aig.nge.entities.VcomponentProduct;
import com.aig.nge.model.ProductModel;
import com.aig.nge.repository.TAssetAttributeRepository;
import com.aig.nge.repository.TAssetHRepository;
import com.aig.nge.repository.TAssetRepository;
import com.aig.nge.repository.TAssetTypeRepository;
import com.aig.nge.repository.TAttributeRepository;
import com.aig.nge.repository.TBlockRepository;
import com.aig.nge.repository.TCompnentStatusAttributeRepository;
import com.aig.nge.repository.TMarketableProductComponentRepository;
import com.aig.nge.repository.TMarketableProductLocationRepository;

import com.aig.nge.repository.TProductDSPRepository;
import com.aig.nge.repository.TProductMMCPRepository;
import com.aig.nge.repository.TProductTowerAttributeRepository;
import com.aig.nge.repository.TProductTowerAutoCloseRuleRepository;
import com.aig.nge.repository.TProductTowerDivsionRepository;
import com.aig.nge.repository.TProductTowerReasonRepository;
import com.aig.nge.repository.TProductTowerRepository;
import com.aig.nge.repository.TReasonRepository;
import com.aig.nge.repository.TStatusReasonTypeRepository;
import com.aig.nge.repository.TStatusRepository;
import com.aig.nge.repository.TTransactionCmpntAssetHRepository;
import com.aig.nge.repository.TTransactionCmpntXpsrLocRepository;
import com.aig.nge.repository.TTransactionComponentAssetRepository;
import com.aig.nge.repository.TTransactionComponentAtrbtRepository;
import com.aig.nge.repository.TTransactionComponentBranchRepository;
import com.aig.nge.repository.TTransactionComponentLimitRepository;
import com.aig.nge.repository.TTransactionComponentPartyRepository;
import com.aig.nge.repository.TTransactionComponentPolicyRepository;
import com.aig.nge.repository.TTransactionComponentRepository;
import com.aig.nge.repository.TTransactionComponentRltnRepository;
import com.aig.nge.repository.TTransactionComponentStatusRepository;
import com.aig.nge.repository.TTransactionProductAttributeRepository;
import com.aig.nge.repository.TUwSubProductRepository;
import com.aig.nge.repository.TproductTowerAttributeUsageRepository;
import com.aig.nge.repository.VComponentProductRepository;
import com.aig.nge.utilities.AIGCIExceptionMsg;
import com.aig.nge.utilities.NGECommonUtil;
import com.aig.nge.utilities.NGEConstants;
import com.aig.nge.utilities.NGEDateUtil;
import com.aig.nge.utilities.NGEErrorCodes;
import com.aig.nge.utilities.NGESession;
import com.aig.nge.utilities.NGEValidations;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;



/**
 * @author DineshKumar This DAO class is used accessing the Product related
 *         repositories Used repositories are :
 * 
 */
@Repository
public class ProductDAO extends BaseDAO {

	private static final Logger logger = LogManager.getLogger(ProductDAO.class);

	@Autowired
	private TProductTowerAutoCloseRuleRepository productTowerAutoCloseRuleRepository;

	@Autowired
	private TTransactionComponentStatusRepository transactionComponentStatusRepository;

	@Autowired
	private TTransactionComponentRepository transactionComponentRepository;

	@Autowired
	private TTransactionProductAttributeRepository transactionProductAttributeRepository;
	
	@Autowired
	private TTransactionComponentAtrbtRepository transactionComponentAtrbtRepository;
	
	@Autowired
	private TTransactionComponentBranchRepository transactionComponentBranchRepository;
	
	@Autowired
	private TTransactionCmpntXpsrLocRepository transactionCmpntXpsrLocRepository;
	
	@Autowired
	private TTransactionComponentAssetRepository transactionComponentAssetRepository;
		
	@Autowired
	private TTransactionComponentLimitRepository transactionComponentLimitRepository;
	
	@Autowired
	private TTransactionComponentPartyRepository transactionComponentPartyRepository;
	
	@Autowired
	private TTransactionComponentPolicyRepository transactionComponentPolicyRepository;
	
	@Autowired
	private TAssetAttributeRepository assetAttributeRepository; 
	
	@Autowired
	private TStatusRepository statusRepository;
	
	@Autowired
	private TBlockRepository blockRepository;
	
	@Autowired
	private TReasonRepository reasonRepository;
	
	@Autowired
	private TStatusReasonTypeRepository statusReasonTypeRepository;
	
	@Autowired
	private TProductTowerRepository productTowerRepository;
	
	@Autowired
	private TProductTowerReasonRepository productTowerReasonRepository ;

	
	@Autowired
	private TproductTowerAttributeUsageRepository productTowerAttributeUsageRepository;
	
	@Autowired
	private TProductTowerDivsionRepository tProductTowerDivisionRepository; 

	@Autowired
	private VComponentProductRepository vComponentProductRepository; 
	 
	@Autowired
	private TProductTowerAttributeRepository tProductTowerAttributeRepository; 

	@Autowired
	private TAttributeRepository tAttributeRepository; 

	@Autowired
	private TTransactionComponentAtrbtRepository transactionComponentAttributeRepository;
	
	@Autowired
	private TAssetRepository tAssetRepository;
	
	@Autowired
	private TAssetTypeRepository tAssetTypeRepository;

	@Autowired
	TTransactionCmpntAssetHRepository tTransactionCmpntAssetHRepository;
	
	@Autowired
	TAssetHRepository tAssetHRepository;
	
	@Autowired
	private NGEValidations ngeValidations;
	
	@Autowired
	private TMarketableProductComponentRepository tMarketableProductComponentRepository;
	
	@Autowired
	private TUwSubProductRepository tTuwSubProductRepository;
	
	@Autowired
	private TProductDSPRepository tProductDSPRepository;
	
	@Autowired
	private TProductMMCPRepository tProductMMCPRepository;
		
	@Autowired
	private  TCompnentStatusAttributeRepository tCompnentStatusAttributeRepository;
	
	@Autowired
	private TTransactionComponentRltnRepository tTransactionComponentRltnRepository;
	
	@Autowired
	private AttributeDAO attributeDAO;
	
	@Autowired
	private TMarketableProductLocationRepository tMarketableProductLocationRepository;
	
	// NGE UI sept release changes start
	@Autowired
	private TMarketableProductRepository tMarketableProductRepository;
	// NGE UI sept release changes end

	public TtransactionComponentStatus getTtransactionComponentStatus(
			String transactionComponentId, String statusTypeNm) throws AIGCIExceptionMsg {
		TtransactionComponentStatus transactionComponentStatus ;
		 transactionComponentStatus = transactionComponentStatusRepository
				.findByTransactionComponentIdAndStatusTypeNm(transactionComponentId, statusTypeNm.toUpperCase());
		if(transactionComponentStatus == null)
		{
			ngeException.throwException(NGEErrorCodes.TRANSACTION_COMPONENT_STATUS_LIST_CANNOT_BE_ZERO,NGEErrorCodes.ERROR_TYPE, null, null);
			
		}
		
		return transactionComponentStatus;
	}
	
	public TtransactionComponentStatus getTtransactionComponentStatus(String transactionComponentId, String statusTypeNm, String statusNm) throws AIGCIExceptionMsg {
		List<TtransactionComponentStatus> transactionComponentStatusList = null;
		
		/*
		 * EXADATA Migration Changes
		 * 		Adding space for status name 
		 */
		
		if(statusNm.equals(NGEConstants.EMPTY_STRING))
			statusNm = NGEConstants.EMPTY_SPACE;
		
		transactionComponentStatusList = transactionComponentStatusRepository
				.findByTransactionComponentIdAndStatusTypeNmAndStatusNm(transactionComponentId, statusTypeNm.toUpperCase(), statusNm.toUpperCase());
		// UAT Defect ID 226 - Fixed - Unnecessary Exception is removed
		if(!transactionComponentStatusList.isEmpty() && transactionComponentStatusList.size() == 1){
			return transactionComponentStatusList.get(0);
		}
		return null;
	}


	public String getProductCurrentStatus(
			TtransactionComponentStatus transactionComponentStatus) {
		String statusNm = transactionComponentStatus.getTstatus().getStatusNm();
		return statusNm;
	}

	public Date getCalculatedAutoCloseDays(Date inputDate, short extensionCT,
			TproductTowerAutoCloseRule productTowerAutoCloseRule, boolean isExtension)
			throws AIGCIExceptionMsg {
		short daysPerExtensionNo = 0;
		short allowableExtensionsNo = 0;

		if(isExtension)
		{
			daysPerExtensionNo = productTowerAutoCloseRule.getDaysPerExtensionNo();
		}
		else
		{
			daysPerExtensionNo = productTowerAutoCloseRule.getAutoCloseDaysNo();
		}

		allowableExtensionsNo = productTowerAutoCloseRule
				.getAllowableExtensionsNo();

		/*
		 * compare the allowableExtensionsNo comparing TTransaction component
		 * table and TProductTowerAutoCloseRule
		 */
		//Only if it is extension, compare the allowableExtensionsNo with extensionCT
		if(isExtension)
		{
			if (allowableExtensionsNo > extensionCT) {
				logger.info("AllowableExtensions is avilable");
			} else {
				ngeException.throwException(
						NGEErrorCodes.ALLOWABLE_EXTENSIONS_NOT_AVILABLE,
						NGEErrorCodes.ERROR_TYPE,"ExtensionCT is already greater than the allowable Extensions", null);
			}
		}
		// update the AutoCloseDT in TTransactionComponet table dd/mm/yyyy
		Date autoCloseDate = NGEDateUtil.incrementDateByDate(inputDate, daysPerExtensionNo);

		return autoCloseDate;
	}

	public TproductTowerAutoCloseRule getTproductTowerAutoCloseRules(
			String segmentCd, String subSegmentCD, String lifecycleStatusName, String reservationStatusName) throws AIGCIExceptionMsg {
		// fetching the details from TProductTowerAutoCloseRule table passing
		// particular inputs
		TproductTowerAutoCloseRule tproductTowerAutoCloseRuleData = null;
		if(subSegmentCD != null)
		{
			subSegmentCD = subSegmentCD.toUpperCase();
		}
		
		/*
		* EXADATA Migration Changes
		* 		Adding space for status name 
		*/
		
		if(lifecycleStatusName.equals(NGEConstants.EMPTY_STRING))
			lifecycleStatusName = NGEConstants.EMPTY_SPACE;
		
		if(reservationStatusName.equals(NGEConstants.EMPTY_STRING))
			reservationStatusName = NGEConstants.EMPTY_SPACE;
		
		tproductTowerAutoCloseRuleData = productTowerAutoCloseRuleRepository
				.findBySegmentCdAndSubSegmentCd(segmentCd.toUpperCase(), subSegmentCD,lifecycleStatusName.toUpperCase(),reservationStatusName.toUpperCase());
		if(tproductTowerAutoCloseRuleData==null)
		{
			ngeException.throwException(
					NGEErrorCodes.AUTO_CLOSE_DAYS_NO_NOT_FOUND,
					NGEErrorCodes.ERROR_TYPE, null, null);
		}
		return tproductTowerAutoCloseRuleData;
	}

	public TtransactionComponentStatus saveTransactionComponentStatus(
			TtransactionComponentStatus transactionComponentStatusData) {
		

		/* Exadata changes - Not null issue starts */
		if(transactionComponentStatusData.getCommentTx() != null){
			if(transactionComponentStatusData.getCommentTx().trim().equals(NGEConstants.EMPTY_STRING))
				transactionComponentStatusData.setCommentTx(NGEConstants.EMPTY_SPACE);
		}
		/* Exadata changes - Not null issue ends */
		transactionComponentStatusData = transactionComponentStatusRepository
				.save(transactionComponentStatusData);
		return transactionComponentStatusData;
	}

	public TtransactionComponent saveTtransactionComponent(
			TtransactionComponent transactionComponentData) {
		transactionComponentData = transactionComponentRepository
				.save(transactionComponentData);
		return transactionComponentData;
	}
	
	public List<TtransactionProductAttribute> getMarketableProductAttribute(int productId, String transactionId, short versionNo){
		
		List<TtransactionProductAttribute> tTransactionProductAttributeList = null;		
		tTransactionProductAttributeList=transactionProductAttributeRepository.getMarketableProductAttribute(productId, transactionId, versionNo);
		return tTransactionProductAttributeList;
	}
	
	public List<String> getMktProductAttributeValues(short attributeId, int productId, String transactionId, short versionNo){
		
		List<String> attributeValuesList = null; 
		attributeValuesList=transactionProductAttributeRepository.getMktProductAttributeValues(attributeId, productId, transactionId, versionNo, NGEConstants.NO);
		return attributeValuesList;	
	}
	
	public List<Short> getUniqueMktProductAttributeId(int productId, String transactionId, short versionNo){
		
		List<Short> uniqueAttributeId = null; 
		uniqueAttributeId=transactionProductAttributeRepository.getUniqueMktProductAttributeId(productId, transactionId, versionNo);
		return uniqueAttributeId;	
	}
	public List<TtransactionProductAttribute> getUnderwriterId(int productId, String transactionId, short versionNo, String attributeTypeNm){
		
		List<TtransactionProductAttribute> tTransactionProductAttributeList = null;		
		tTransactionProductAttributeList=transactionProductAttributeRepository.getUnderwriterId(productId, transactionId, versionNo, attributeTypeNm);
		return tTransactionProductAttributeList;
	}	

	public List<TtransactionComponentAtrbt> getComponentAttribute(String componentId){
	
		List<TtransactionComponentAtrbt> tTransactionComponentAtrbtList = null; 
		tTransactionComponentAtrbtList=transactionComponentAtrbtRepository.getComponentAttribute(componentId);
		return tTransactionComponentAtrbtList;
	
	}
	
	public List<TtransactionComponentAtrbt> getAttributeValues(List<Short> attributeIdList, String componentId){
		
		List<TtransactionComponentAtrbt> attributeValuesList = null; 
		attributeValuesList=transactionComponentAtrbtRepository.getAttributeValues(attributeIdList, componentId);
		return attributeValuesList;	
	}
	
	/*public List<Short> getUniqueAttributeId(String componentId){
		
		List<Short> uniqueAttributeId = null; 
		uniqueAttributeId=transactionComponentAtrbtRepository.getUniqueAttributeId(componentId);
		return uniqueAttributeId;	
	}*/
	public Set<Short> getUniqueAttributeId(TtransactionComponent transactionComponent, String tableName){
		
		Set<Short> uniqueAttributeId = new HashSet<Short>(); 
		//uniqueAttributeId=transactionComponentAtrbtRepository.getUniqueAttributeId(componentId);
		if(tableName.equalsIgnoreCase(NGEConstants.TTRANSACTION_COMPONENT_ATTRIBUTE))
		{
			for (TtransactionComponentAtrbt transactionComponentAtrbt : transactionComponent.getTtransactionComponentAtrbts())
			{
				uniqueAttributeId.add(transactionComponentAtrbt.getTattribute().getAttributeId());
			}
		}
		return uniqueAttributeId;	
	}
	
	public List<Short> getUniqueStatusAttributeId(String componentId){
		
		List<Short> uniqueAttributeId = null; 
		uniqueAttributeId=tCompnentStatusAttributeRepository.getUniqueStatusAttributeId(componentId);
		return uniqueAttributeId;	
	}
	
	public List<String> getStatusAttributeValues(short attributeId, String componentId){
		
		List<String> attributeValuesList = null; 
		attributeValuesList=tCompnentStatusAttributeRepository.getStatusAttributeValues(attributeId, componentId);
		return attributeValuesList;	
	}
	
	public String getAttributeNm(short attributeId){
		
		Tattribute attribute = null; 
		attribute=tAttributeRepository.getAttributeNm(attributeId);
		return attribute.getAttributeNm();	
	}	
	public List<TtransactionComponentBranch> getComponentBranch(String componentId){
	
	List<TtransactionComponentBranch> tTransactionComponentBranchList = null;
	tTransactionComponentBranchList=transactionComponentBranchRepository.getComponentBranch(componentId);
	return tTransactionComponentBranchList;
	
	}
	
	public List<TtransactionComponentLimit> getComponentLimit(String componentId){
	
	List<TtransactionComponentLimit> tTransactionComponentLimitList = null; 
	tTransactionComponentLimitList=transactionComponentLimitRepository.getComponentLimit(componentId);
	return tTransactionComponentLimitList;
	
	}
	
	public List<TtransactionCmpntXpsrLoc> getComponentExposure(String componentId){
		
	List<TtransactionCmpntXpsrLoc> tTransactionCmpntXpsrLocList = null;
	tTransactionCmpntXpsrLocList=transactionCmpntXpsrLocRepository.getComponentExposure(componentId, NGEConstants.NO);
	return tTransactionCmpntXpsrLocList;
	
	}
	
	public List<TtransactionComponentParty> getComponentParty(String componentId){
		
	List<TtransactionComponentParty> tTransactionComponentPartyList = null;
	tTransactionComponentPartyList=transactionComponentPartyRepository.getComponentParty(componentId, NGEConstants.NO);
	return tTransactionComponentPartyList;
	
	}
	
	public List<TassetAttribute> getAssetAttribute(int assetId){
		
	List<TassetAttribute> tAssetAttributeList = null;
	tAssetAttributeList=assetAttributeRepository.getAssetAttribute(assetId);
	return tAssetAttributeList;
	
	}
	
	public List<String> getAssetAttributeValues(short attributeId, int assetId){
		
		List<String> attributeValuesList = null; 
		attributeValuesList=assetAttributeRepository.getAssetAttributeValues(attributeId, assetId);
		return attributeValuesList;	
	}
	
	public List<Short> getUniqueAssetAttributeId(int assetId){
		
		List<Short> uniqueAttributeId = null; 
		uniqueAttributeId=assetAttributeRepository.getUniqueAssetAttributeId(assetId);
		return uniqueAttributeId;	
	}
	public List<TtransactionComponentAsset> getComponentAsset(String componentId){
		
	List<TtransactionComponentAsset> tTransactionComponentAssetList = null;	
	tTransactionComponentAssetList=transactionComponentAssetRepository.getComponentAsset(componentId, NGEConstants.NO);
	return tTransactionComponentAssetList;
	
	}
	
	public List<TtransactionComponentPolicy> getComponentPolicy(String componentId){
		
	List<TtransactionComponentPolicy> tTransactionComponentPolicyList = null;
	tTransactionComponentPolicyList=transactionComponentPolicyRepository.getComponentPolicy(componentId, NGEConstants.NO);
	return tTransactionComponentPolicyList;
	
	}	
	
	public List<TtransactionComponentRltn> getExpiringComponentProducts(String componentId){
		
		List<TtransactionComponentRltn> expiringProductsList = null;
		expiringProductsList=tTransactionComponentRltnRepository.getExpiringProducts(componentId, NGEConstants.RelationTypeName.RENEWALPRODUCT);
		return expiringProductsList;
		
	}
	
	public List<TtransactionComponentRltn> getRelatedRenewedProducts(String componentId){
		
		List<TtransactionComponentRltn> expiringProductsList = null;
		expiringProductsList=tTransactionComponentRltnRepository.getRelatedRenewedProducts(componentId, NGEConstants.RelationTypeName.RENEWALPRODUCT);
		return expiringProductsList;
		
	}
	
	public TtransactionComponentStatus getProductStatus(String componentId, String statutsTypeNm){
		
		TtransactionComponentStatus productStatus = null;
		productStatus=transactionComponentStatusRepository.findByTransactionComponentIdAndStatusTypeNm(componentId, statutsTypeNm.toUpperCase());
		return productStatus;		
	}
	public TtransactionComponentStatus getProductStatusLifeCycleStatus(TtransactionComponent transactionComponentData){
		
		TtransactionComponentStatus productStatus = null;
		//productStatus=transactionComponentStatusRepository.findByTransactionComponentIdAndStatusTypeNm(componentId);
		for(TtransactionComponentStatus transactionComponentStatus : transactionComponentData.getTtransactionComponentStatuses())
		{
			if(NGEConstants.StatusType.LIFECYCLE_STATUS.equalsIgnoreCase(transactionComponentStatus.getTstatus().getTstatusType().getStatusTypeNm()))
			{
				productStatus = transactionComponentStatus;
			}
		}
		return productStatus;		
	}
	public List<TtransactionComponent> getTransactionComponent(String transactionId, int versionNo, String deletedIn, List<String> productlifeCycleStatusFilterList){
		
		List<TtransactionComponent> componentProductList = null;
	
		if(productlifeCycleStatusFilterList != null && productlifeCycleStatusFilterList.size() > 0){	
			/*
			* EXADATA Migration Changes
			* 		Adding space for status name 
			*/
			List<String>  productlifeCycleStatusFilterListModified = new ArrayList<String>();
			
			for(String statusNm : productlifeCycleStatusFilterList){
				if(statusNm.equals(NGEConstants.EMPTY_STRING))
					statusNm=NGEConstants.EMPTY_SPACE;
				productlifeCycleStatusFilterListModified.add(statusNm);
			}
				componentProductList=transactionComponentRepository.getTransactionComponentByStatus(transactionId, (short) versionNo, deletedIn, productlifeCycleStatusFilterListModified);
		}else{			
				componentProductList=transactionComponentRepository.getTransactionComponentForGetSubmission(transactionId, (short) versionNo, deletedIn);
			}
		
		
		return componentProductList;		
	}
	
	public List<TtransactionComponent> getTransactionComponentDetailsForGetSubmission(String submissionNo, List<String> productlifeCycleStatusFilterList){
		
		List<TtransactionComponent> componentProductList = null;
	
		if(productlifeCycleStatusFilterList != null && productlifeCycleStatusFilterList.size() > 0){	
			//	componentProductList=transactionComponentRepository.getTransactionComponentByStatus(transactionId, (short) versionNo, deletedIn, productlifeCycleStatusFilterList);
		}else{			
				componentProductList=transactionComponentRepository.getTransactionComponentForGetSubmission(submissionNo, NGEConstants.NO);
			}
		
		
		return componentProductList;		
	}
	
	public List<TtransactionComponent> getTransactionComponentList(String transactionId, int versionNo, String deletedIn){
		
		List<TtransactionComponent> componentProductList = null;
		componentProductList=transactionComponentRepository.getTransactionComponentList(transactionId, (short) versionNo, deletedIn);
		return componentProductList;		
	}

	public Tblock getTblock(int blockNo)throws AIGCIExceptionMsg
	{
	Tblock block =	blockRepository.findOne(blockNo);
		
		return block;
	}
	
	public Treason getTReason(String reasonCd) throws AIGCIExceptionMsg
	{
		/*
		* EXADATA Migration Changes
		* 		Adding space for reason name 
		*/

		if(reasonCd.equals(NGEConstants.EMPTY_STRING))
			reasonCd = NGEConstants.EMPTY_SPACE;
		else
			reasonCd = reasonCd.trim();
		Treason  reason = reasonRepository.findByReasonNm( reasonCd.toUpperCase());
		   
		   return reason;
	}
	
	public Treason getTReason(String reasonNm, String reasonTypeNm) throws AIGCIExceptionMsg
	{
		
		/*
		* EXADATA Migration Changes
		* 		Adding space for reason name 
		*/

		if(reasonNm.equals(NGEConstants.EMPTY_STRING))
			reasonNm = NGEConstants.EMPTY_SPACE;
		else
			reasonNm = reasonNm.trim();
		Treason  reason = reasonRepository.findByReasonTypeIdAndReasonNm(reasonTypeNm.toUpperCase(),reasonNm.toUpperCase());
		   
		   return reason;
	}
	
	public Tstatus getTStatus(String status)throws AIGCIExceptionMsg
	{
		/*
		* EXADATA Migration Changes
		* 		Adding space for status name 
		*/

		if(status.equals(NGEConstants.EMPTY_STRING))
			status = NGEConstants.EMPTY_SPACE;	
		else
			status = status.trim();
		Tstatus statusObj =   statusRepository.findByStatusNm(status.toUpperCase());
		return statusObj;
	}
	
	public TstatusReasonType getStatusReasonType(short statusId,
			short reasonTypeId)throws AIGCIExceptionMsg {
		
		TstatusReasonTypePK statusReasonTypePK = new TstatusReasonTypePK();
		
        statusReasonTypePK.setReasonTypeId(reasonTypeId);
        statusReasonTypePK.setStatusId(statusId);
        TstatusReasonType statusReasonType = statusReasonTypeRepository.findOne(statusReasonTypePK);
		
		return statusReasonType;
	}
	
	public TproductTower getProductTowerBySegmentandSubSegmentCd(
			String segmentCd, String subSegmentCode)throws AIGCIExceptionMsg {
		
		if(ngeValidations.isNullOrEmptyOrSpaces(subSegmentCode)){
			subSegmentCode=null;
		}
		if(subSegmentCode != null)
		{
			subSegmentCode = subSegmentCode.toUpperCase();
		}
		List<TproductTower> productTowerList = productTowerRepository.findBySegmentCdAndSubSegmentCd(segmentCd.toUpperCase(), subSegmentCode);
		TproductTower productTower = new TproductTower();
		
		if (productTowerList.size() == 0 || productTowerList.size()>1) {
			ngeException.throwException(
					NGEErrorCodes.INVALID_PRODUCT_TOWER,
					NGEErrorCodes.ERROR_TYPE, "Product Tower is not available for segmentCd "+segmentCd+" and subSegmentCode "+subSegmentCode+"", null);
		}
		else
		{
			productTower = productTowerList.get(0);
		}
		return productTower;
	}

	public TproductTowerReason getProductTowerReason(TproductTower productTower, short reasonId) throws AIGCIExceptionMsg{
	
		   TproductTowerReasonPK productTowerReasonPK = new TproductTowerReasonPK();

           productTowerReasonPK.setProductTowerId(productTower.getProductTowerId());
           productTowerReasonPK.setReasonId(reasonId);
           TproductTowerReason   productTowerReason = productTowerReasonRepository.findOne(productTowerReasonPK);
		
		return productTowerReason;
	}


	
	
	public void updateBlock(Tblock block)
	{
		/* Exadata changes - Not null issue starts */
		if(block.getCommentTx() != null){
			if(block.getCommentTx().trim().equals(NGEConstants.EMPTY_STRING))
				block.setCommentTx(NGEConstants.EMPTY_SPACE);
		}
		/* Exadata changes - Not null issue ends */
		blockRepository.save(block);
	}


	public TtransactionComponentStatus getTransactionComponentStatus(
			TtransactionComponentStatusPK transactionComponentStatHPK) throws AIGCIExceptionMsg {
		
		TtransactionComponentStatus transactionComponentStatus	= transactionComponentStatusRepository.findOne(transactionComponentStatHPK);
		return transactionComponentStatus;
	}


	public void deleteTransactionComponentStatus(
			TtransactionComponentStatus transactionComponentStatus) throws AIGCIExceptionMsg{
		// TODO Auto-generated method stub
		
		transactionComponentStatusRepository.delete(transactionComponentStatus);
		
	}


	public TtransactionComponentStatus createTransactionComponentStatus(
			String transactionComponentId, String statusNm, String reasonCd,String userId) throws AIGCIExceptionMsg{
		
		TtransactionComponentStatusPK transactionComponentStatusPK = new TtransactionComponentStatusPK();
		TtransactionComponentStatus componentStatus = new TtransactionComponentStatus();
		Tstatus statusObj =  getTStatus(statusNm);
		transactionComponentStatusPK.setStatusId(statusObj.getStatusId());
		transactionComponentStatusPK.setTransactionComponentId(transactionComponentId);
		componentStatus.setId(transactionComponentStatusPK);
		
		componentStatus.setStatusTs(NGEDateUtil.getTodayDate());
		if(reasonCd != null)
		{
			Treason reason  = getTReason(reasonCd);
		componentStatus.setTreason(reason);
		}
		componentStatus.setCreateUserId(userId);
		componentStatus.setCreateTs(NGEDateUtil.getTodayDate());

		componentStatus = transactionComponentStatusRepository.save(componentStatus);
		
		
		return componentStatus;
	}

	public void updateTransactionComponentStatus(
			TtransactionComponentStatus transactionComponentStatus,
			String statusNm, String reasonCd)throws AIGCIExceptionMsg {
		// TODO Auto-generated method stub
		Tstatus statusObj;
			
		statusObj =  getTStatus(statusNm);
		transactionComponentStatus.setTstatus(statusObj);
		transactionComponentStatus.setStatusTs(NGEDateUtil.getTodayDate());
		
		if(reasonCd != null)
		{
			Treason reason  = getTReason(reasonCd);
			transactionComponentStatus.setTreason(reason);
			
		}
		transactionComponentStatus.setUpdateTs(NGEDateUtil.getTodayDate());
		transactionComponentStatus.setUpdateUserId(NGESession.getSessionData().getUserId());
		transactionComponentStatusRepository.save(transactionComponentStatus);
	}
	
	public TtransactionComponentBranch getProductBranch(String componentId, String branchType){
		
		TtransactionComponentBranch productBranch = null;
		productBranch=transactionComponentBranchRepository.getProductBranch(componentId, branchType.toUpperCase());
		return productBranch;
		
	}
	
	public List<TproductTowerAttributeUsage> findAttributesForBlocking(short productTowerId, String usageTypeNm){
		List<TproductTowerAttributeUsage> productTowerAttributeUsage = null;		
		productTowerAttributeUsage=productTowerAttributeUsageRepository.findAttributesForBlocking(productTowerId, usageTypeNm.toUpperCase());		
		return productTowerAttributeUsage;
	}

	/**
	 * @author Dinesh Selvaraj
	 * @param divisionNo
	 * @param productTowerID
	 * @return
	 * @throws JpaSystemException
	 * @throws AIGCIExceptionMsg
	 * This method is used to get product tower division information
	 */
	public TproductTowerDivision getTProductTowerDivision(short divisionNo,short productTowerID) throws JpaSystemException, AIGCIExceptionMsg
	{
		TproductTowerDivision tProductTowerDivisionData=null;
		
		tProductTowerDivisionData=tProductTowerDivisionRepository.findProductTowerDivisionIDByDivisionNoAndTowerID(divisionNo, productTowerID);
		if(tProductTowerDivisionData==null){
			ngeException.throwException(NGEErrorCodes.PRODUCT_TOWER_DIVISION_NOT_AVAILABLE, NGEErrorCodes.ERROR_TYPE, "Product Tower Division not available for the given product tower and division", null); /*EXC Product Tower Division not available for the given divison no and tower ID*/
		}
		return tProductTowerDivisionData;
	}
	// NGE UI sept release changes start
	public TprdctTwrTuwSubPrdctDiv getTProductTowerSubProductDivision(short divisionNo,short productTowerID,String subPrdctCd) throws JpaSystemException, AIGCIExceptionMsg
	{
		TprdctTwrTuwSubPrdctDiv tPrdctTwrTuwSubPrdctDivData=null;
		
		tPrdctTwrTuwSubPrdctDivData=tProductTowerDivisionRepository.findSubProductDivByDivisionNoTowerIDAndSubPrct(divisionNo, productTowerID, subPrdctCd);
		if(tPrdctTwrTuwSubPrdctDivData==null){
			ngeException.throwException(NGEErrorCodes.PRODUCT_DIVISION_NOT_AVAILABLE, NGEErrorCodes.ERROR_TYPE, "Invalid combination of division, product and product tower", null);
		}
		return tPrdctTwrTuwSubPrdctDivData;
	}

	public TprdctTwrTuwSubPrdctDiv getTProductTowerCmpntProductDivision(short divisionNo,short productTowerID,String mktPrdctCd,String cmpntPrdctCd) throws JpaSystemException, AIGCIExceptionMsg
	{
		TprdctTwrTuwSubPrdctDiv tPrdctTwrTuwSubPrdctDivData=null;
		
		tPrdctTwrTuwSubPrdctDivData=tProductTowerDivisionRepository.findCompProductDivByDivisionNoTowerIDAndSubPrct(divisionNo, productTowerID, mktPrdctCd,cmpntPrdctCd);
		if(tPrdctTwrTuwSubPrdctDivData==null){
			ngeException.throwException(NGEErrorCodes.PRODUCT_DIVISION_NOT_AVAILABLE, NGEErrorCodes.ERROR_TYPE, "Invalid combination of division, product and product tower", null);
		}
		return tPrdctTwrTuwSubPrdctDivData;
	}
	// NGE UI sept release changes end
	
	public List<VcomponentProduct> getMarketableProducts(String marketableProdSegmentCd,String marketableProdSubSegmentCd,String marketableProductCd, String componentProductCd, ProductModel splProductCodes, String componentSegmentCd, String componentSubSegmentCd) throws JpaSystemException, AIGCIExceptionMsg
	{
		List<VcomponentProduct> vComponentProductData=null;
		/*Converting to upper case - PME - Starts*/
		marketableProdSegmentCd = marketableProdSegmentCd.toUpperCase();
		if(marketableProdSubSegmentCd != null)
		{
			marketableProdSubSegmentCd = marketableProdSubSegmentCd.toUpperCase();
		}
		
		componentSegmentCd = componentSegmentCd.toUpperCase();
		if(componentSubSegmentCd != null)
		{
			componentSubSegmentCd = componentSubSegmentCd.toUpperCase();
		}
		
		componentProductCd = componentProductCd.toUpperCase();
		if(marketableProductCd != null)
		{
			marketableProductCd = marketableProductCd.toUpperCase();
		}
		/*Converting to upper case - PME - Ends*/
		if(NGEConstants.DSP_PRODUCT.equalsIgnoreCase(splProductCodes.getStatus())){
		vComponentProductData=vComponentProductRepository.findByMarketableProductForDSP(marketableProdSegmentCd, marketableProdSubSegmentCd, marketableProductCd, componentProductCd,Short.valueOf(splProductCodes.getDivsionNo()),Short.valueOf(splProductCodes.getSectionCode()),Short.valueOf(splProductCodes.getProfitUnitCode()), componentSegmentCd, componentSubSegmentCd);
		}
		else if(NGEConstants.MMCP_PRODUCT.equalsIgnoreCase(splProductCodes.getStatus())){
			vComponentProductData=vComponentProductRepository.findByMarketableProductForMMCP(marketableProdSegmentCd, marketableProdSubSegmentCd, marketableProductCd, componentProductCd, NGECommonUtil.convertToString(splProductCodes.getMajorLineCode()), NGECommonUtil.convertToString(splProductCodes.getMinorLineCode()), NGECommonUtil.convertToString(splProductCodes.getClassPerilCode()), componentSegmentCd, componentSubSegmentCd);
		}else if(NGEConstants.MJC_PRODUCT.equalsIgnoreCase(splProductCodes.getStatus())){
			//vComponentProductData=vComponentProductRepository.findByMarketableProductForMJC(segmentCd, subSegmentCd, marketableProductCd, componentProductCd,Short.valueOf(splProductCodes.getMajorClassCode()),Short.valueOf(splProductCodes.getDivsionNo()));
		}
		else{
			vComponentProductData=vComponentProductRepository.findByMarketableProduct(marketableProdSegmentCd, marketableProdSubSegmentCd, marketableProductCd, componentProductCd , componentSegmentCd, componentSubSegmentCd);
		}
		
		if(vComponentProductData==null || vComponentProductData.size()<=0){
			ngeException.throwException(NGEErrorCodes.NO_PRODUCTS_FOUND,NGEErrorCodes.ERROR_TYPE, "Unable to add the product. Products are not available in NGE for the given request", null); /*EXC Marketable Products not available for the given segmentCd/subSegmentCd/marketableProductCd/componentProductCd*/ 
		}
		else if(vComponentProductData.size()>1){
			ngeException.throwException(NGEErrorCodes.MULTIPLE_PRODUCTS_FOUND,NGEErrorCodes.ERROR_TYPE, "Multiple Component products available. Please verify the inputs", null);
		}
		else{
			if(vComponentProductData.get(0).getComponentProductDeletedIn().equalsIgnoreCase(NGEConstants.YES) || 
					vComponentProductData.get(0).getProductDetailDeletedIn().equalsIgnoreCase(NGEConstants.YES)){
				
				if(NGESession.getSessionData().getClientId() != null){
					
					if(!NGESession.getSessionData().getClientId().equalsIgnoreCase(NGEConstants.LEGACY_CONSUMERS)){
						
						ngeException.throwException(NGEErrorCodes.PRODUCT_INACTIVE, NGEErrorCodes.ERROR_TYPE, "Product is inactive in the Lookup table", null);
					}					
				}
				else{
					ngeException.throwException(NGEErrorCodes.PRODUCT_INACTIVE, NGEErrorCodes.ERROR_TYPE, "Product is inactive in the Lookup table", null);
				}				
			}
		}
		
		return vComponentProductData;
	}
	
	public List<VcomponentProduct> getComponentProducts(String segmentCd,String subSegmentCd, String componentProductCd, ProductModel splProductCodes) throws AIGCIExceptionMsg,JpaSystemException 
	{
	
		List<VcomponentProduct> vComponentProductData=null;
		/*Converting to upper case - PME - Starts*/
		segmentCd = segmentCd.toUpperCase();
		if(subSegmentCd != null)
		{
			subSegmentCd = subSegmentCd.toUpperCase();
		}
		componentProductCd = componentProductCd.toUpperCase();
		/*Converting to upper case - PME - Ends*/
		if(NGEConstants.DSP_PRODUCT.equalsIgnoreCase(splProductCodes.getStatus())){
		vComponentProductData=vComponentProductRepository.findByComponentProductForDSP(segmentCd, subSegmentCd, componentProductCd,Short.valueOf(splProductCodes.getDivsionNo()),Short.valueOf(splProductCodes.getSectionCode()),Short.valueOf(splProductCodes.getProfitUnitCode()));
		}
		else if(NGEConstants.MMCP_PRODUCT.equalsIgnoreCase(splProductCodes.getStatus())){
			vComponentProductData=vComponentProductRepository.findByComponentProductForMMCP(segmentCd, subSegmentCd, componentProductCd, splProductCodes.getMajorLineCode(), splProductCodes.getMinorLineCode(), splProductCodes.getClassPerilCode());
		}else if(NGEConstants.MJC_PRODUCT.equalsIgnoreCase(splProductCodes.getStatus())){
			//vComponentProductData=vComponentProductRepository.findByComponentProductForMJC(segmentCd, subSegmentCd, componentProductCd,Short.valueOf(splProductCodes.getMajorClassCode()),Short.valueOf(splProductCodes.getDivsionNo()));
		}
		else{
			vComponentProductData=vComponentProductRepository.findByComponentProduct(componentProductCd,segmentCd, subSegmentCd);
		}
		
		if(vComponentProductData==null || vComponentProductData.size()<=0){
			ngeException.throwException(NGEErrorCodes.NO_PRODUCTS_FOUND, NGEErrorCodes.ERROR_TYPE, "Unable to add the product. Products are not available in NGE for the given request", null); /*EXC Component Products not available for the given segmentCd/subSegmentCd/marketableProductCd/componentProductCd*/ 
		}
		else if(vComponentProductData.size()>1){
			ngeException.throwException(NGEErrorCodes.MULTIPLE_PRODUCTS_FOUND,NGEErrorCodes.ERROR_TYPE, "Multiple Component products available. Please verify the inputs", null);
		}
		else{
			if(vComponentProductData.get(0).getComponentProductDeletedIn().equalsIgnoreCase(NGEConstants.YES) || 
					vComponentProductData.get(0).getProductDetailDeletedIn().equalsIgnoreCase(NGEConstants.YES)){
				
				if(NGESession.getSessionData().getClientId() != null){
					
					if(!NGESession.getSessionData().getClientId().equalsIgnoreCase(NGEConstants.LEGACY_CONSUMERS)){
						
						ngeException.throwException(NGEErrorCodes.PRODUCT_INACTIVE, NGEErrorCodes.ERROR_TYPE, "Product is inactive in the Lookup table", null);
					}					
				}
				else{
					ngeException.throwException(NGEErrorCodes.PRODUCT_INACTIVE, NGEErrorCodes.ERROR_TYPE, "Product is inactive in the Lookup table", null);
				}				
			}
		}
		return vComponentProductData;
	}

	public List<VcomponentProduct> getComponentProductsWithoutSplProductCodes(
			String segmentCd, String subSegmentCd, String componentProductCd) throws AIGCIExceptionMsg {

	List<VcomponentProduct> vComponentProductData=null;
	/*Converting to upper case - PME - Starts*/
	segmentCd = segmentCd.toUpperCase();
	if(subSegmentCd != null)
	{
		subSegmentCd = subSegmentCd.toUpperCase();
	}
	componentProductCd = componentProductCd.toUpperCase();
	/*Converting to upper case - PME - Ends*/
	vComponentProductData=vComponentProductRepository.findByComponentProductWithoutSplProductCodes(componentProductCd,segmentCd, subSegmentCd);
	if(vComponentProductData==null || vComponentProductData.size()<0){
		ngeException.throwException(NGEErrorCodes.NO_PRODUCTS_FOUND, NGEErrorCodes.ERROR_TYPE, "Unable to add the product. Products are not available in NGE for the given request", null); /*EXC Component Products not available for the given segmentCd/subSegmentCd/marketableProductCd/componentProductCd */
	}
	else if(vComponentProductData.size()>1){
		ngeException.throwException(NGEErrorCodes.MULTIPLE_PRODUCTS_FOUND,NGEErrorCodes.ERROR_TYPE, "Multiple Component products available. Please verify the inputs", null);
	}
	else{
		if(vComponentProductData.get(0).getComponentProductDeletedIn().equalsIgnoreCase(NGEConstants.YES) || 
				vComponentProductData.get(0).getProductDetailDeletedIn().equalsIgnoreCase(NGEConstants.YES)){
			
			if(NGESession.getSessionData().getClientId() != null){
				
				if(!NGESession.getSessionData().getClientId().equalsIgnoreCase(NGEConstants.LEGACY_CONSUMERS)){
					
					ngeException.throwException(NGEErrorCodes.PRODUCT_INACTIVE, NGEErrorCodes.ERROR_TYPE, "Product is inactive in the Lookup table", null);
				}					
			}
			else{
				ngeException.throwException(NGEErrorCodes.PRODUCT_INACTIVE, NGEErrorCodes.ERROR_TYPE, "Product is inactive in the Lookup table", null);
			}				
		}
	}
	
	return vComponentProductData;
	}
	public List<VcomponentProduct> getMarketableProductsWithoutSplProductCodes(String segmentCd,String subSegmentCd,String marketableProductCd, String componentProductCd) throws AIGCIExceptionMsg
	{
		List<VcomponentProduct> vComponentProductData=null;
		/*Converting to upper case - PME - Starts*/
		segmentCd = segmentCd.toUpperCase();
		if(subSegmentCd != null)
		{
			subSegmentCd = subSegmentCd.toUpperCase();
		}
		componentProductCd = componentProductCd.toUpperCase();
		if(marketableProductCd != null)
		{
			marketableProductCd = marketableProductCd.toUpperCase();
		}
		/*Converting to upper case - PME - Ends*/
		vComponentProductData=vComponentProductRepository.findByMarketableProductWithoutSplProductCodes(segmentCd, subSegmentCd, marketableProductCd, componentProductCd);
		if(vComponentProductData==null || vComponentProductData.size()<=0){
			ngeException.throwException(NGEErrorCodes.NO_PRODUCTS_FOUND, NGEErrorCodes.ERROR_TYPE, "Unable to add the product. Products are not available in NGE for the given request", null); /*EXC Marketable Products not available for the given segmentCd/subSegmentCd/marketableProductCd/componentProductCd */
		}
		else if(vComponentProductData.size()>1){
			ngeException.throwException(NGEErrorCodes.MULTIPLE_PRODUCTS_FOUND,NGEErrorCodes.ERROR_TYPE, "Multiple Component products available. Please verify the inputs", null);
		}
		else{
			if(vComponentProductData.get(0).getComponentProductDeletedIn().equalsIgnoreCase(NGEConstants.YES) || 
					vComponentProductData.get(0).getProductDetailDeletedIn().equalsIgnoreCase(NGEConstants.YES)){
				
				if(NGESession.getSessionData().getClientId() != null){
					
					if(!NGESession.getSessionData().getClientId().equalsIgnoreCase(NGEConstants.LEGACY_CONSUMERS)){
						
						ngeException.throwException(NGEErrorCodes.PRODUCT_INACTIVE, NGEErrorCodes.ERROR_TYPE, "Product is inactive in the Lookup table", null);
					}					
				}
				else{
					ngeException.throwException(NGEErrorCodes.PRODUCT_INACTIVE, NGEErrorCodes.ERROR_TYPE, "Product is inactive in the Lookup table", null);
				}				
			}
		}
		
		return vComponentProductData;
	}

 	public List<Tattribute> findTattribute() {
		// TODO Auto-generated method stub
		
		return tAttributeRepository.findAll();
	}
 	/**
	 * @author Nandhakumarm
	 * @param transactionId
	 * @param versionNo
	 * @param productlifeCycleStatusFilterList
	 * @return
	 */
     
     public List<TtransactionComponentStatus> findByProductStatusList(String transactionId, short versionNo, List<String> productlifeCycleStatusFilterList){
 		
 		List<TtransactionComponentStatus> componentProductList = null;
 		componentProductList=transactionComponentStatusRepository.findByProductStatusList(transactionId, versionNo, productlifeCycleStatusFilterList);
 		return componentProductList; 		
 	}
     
     public List<TtransactionComponent> getTransactionComponentByStatusFilter(List<String> transactionComponentIdList, String deletedIn){
  		
  		List<TtransactionComponent> componentProductList = null;
  		componentProductList=transactionComponentRepository.getTransactionComponentByStatusFilter(transactionComponentIdList, deletedIn);
  		return componentProductList; 		
  	}

     
     /**
 	 * @author Nandhakumarm
 	 * @param attributeName
 	 * @return
 	 * @throws AIGCIExceptionMsg 
 	 */
 	public List<String> findByAttributeNameList(List<String> attributeName) throws AIGCIExceptionMsg,JpaSystemException{
 		List<String> attributeList= new ArrayList<String>();
 		List<Tattribute> attributeListFromDB = null;
 		//attributeListFromDB = tAttributeRepository.findByAttributeNames(attributeName);
 		attributeListFromDB = attributeDAO.findByAttributeNames(attributeName);
 		
 		for(Tattribute attribute : attributeListFromDB)
 		{
 			attributeList.add(attribute.getAttributeNm().toUpperCase());
 		}
 	
 		if(attributeList.isEmpty()){
 			//Error message to be updated
 			ngeException.throwException(NGEErrorCodes.INVALID_ATTRIBUTE_NAME,NGEErrorCodes.ERROR_TYPE, null,null);
 		}
 		
 		return attributeList;
 	}
 	/**
 	 * @author Nandhakumarm
 	 * @param attributeName
 	 * @return
 	 * @throws AIGCIExceptionMsg
 	 * @throws JpaSystemException
 	 */
 	public Tattribute findByAttributeName(String attributeName) throws AIGCIExceptionMsg,JpaSystemException{
 		Tattribute attributeList=null;
 		attributeList = tAttributeRepository.findByAttributeName(attributeName.toUpperCase());
 	
 		if(null == attributeList){
 			ngeException.throwException(NGEErrorCodes.INVALID_ATTRIBUTE_NAME,NGEErrorCodes.ERROR_TYPE, null,null);
 		}
 		return attributeList;
 	}
 	/**
 	 * @author Nandhakumarm
 	 * @param transactionId
 	 * @param versionSqn
 	 * @param productId
 	 * @param attributeId
 	 * @return
 	 * @throws AIGCIExceptionMsg
 	 * @throws JpaSystemException
 	 */
 	public List<TtransactionProductAttribute> findProductAttributeByPkId(String transactionId, short versionSqn, int productId) throws AIGCIExceptionMsg,JpaSystemException{
 		List<TtransactionProductAttribute> attributeList=null;
 		attributeList = transactionProductAttributeRepository.findByAttributePkId(transactionId, versionSqn, productId);
 	
 		if(attributeList.isEmpty()){
 			ngeException.throwException(NGEErrorCodes.EMPTY_MARKETABLE_PRODUCT_ATTRIBUTES,NGEErrorCodes.ERROR_TYPE, null,null);
 		}
 		return attributeList;
 	}
 	
 	/**
 	 * @author Nandhakumarm
 	 * @param productTowerId
 	 * @param tableId
 	 * @return
 	 * @throws AIGCIExceptionMsg 
 	 */
 	 public List<TproductTowerAttribute> findByProdTowerIdAndTableId(short productTowerId, short tableId, String mandatoryFlag) throws AIGCIExceptionMsg,JpaSystemException{
          List<TproductTowerAttribute> tProductTowerAttribute = new ArrayList<TproductTowerAttribute>();
          tProductTowerAttribute = tProductTowerAttributeRepository.findByProdTowerIdAndTableId(productTowerId, tableId,NGEConstants.NO, mandatoryFlag);
          
          return tProductTowerAttribute;
    }
 	
 	public List<TproductTowerAttribute> findByProdTowerIdAndTableIdAndAssetId(short productTowerId, short tableId, String mandatoryFlag, List<Short> attributesIdList) throws AIGCIExceptionMsg,JpaSystemException{
        List<TproductTowerAttribute> tProductTowerAttribute = new ArrayList<TproductTowerAttribute>();
        List<TproductTowerAttribute> tProductTowerAttributeFromDb = null;
        for(Short attributeId : attributesIdList)
        {
        	tProductTowerAttributeFromDb = tProductTowerAttributeRepository.findByProdTowerIdAndTableIdAndAssetId(productTowerId, tableId,NGEConstants.NO, attributeId);
        	for(TproductTowerAttribute productTowerAttribute : tProductTowerAttributeFromDb)
        	{
        		if(mandatoryFlag.equalsIgnoreCase(productTowerAttribute.getMandatoryIn()))
        		{
        			tProductTowerAttribute.add(productTowerAttribute);
        		}
        	}
        }
        
        return tProductTowerAttribute;
  }
 	 
 	 public List<String> getMandatoryAttributesList(short productTowerId, short tableId, List<Short> attributesIdList) throws AIGCIExceptionMsg,JpaSystemException{
         List<String> mandatoryAttributesList = new ArrayList<String>();
         List<TproductTowerAttribute> productTowerAttributeList= null;
         
         if(attributesIdList ==null || attributesIdList.isEmpty())
         {
        	 productTowerAttributeList = tProductTowerAttributeRepository.findByProdTowerIdAndTableId(productTowerId, tableId,NGEConstants.NO, NGEConstants.YES);
         }
         else
         {
        	 productTowerAttributeList = findByProdTowerIdAndTableIdAndAssetId(productTowerId, tableId,NGEConstants.YES, attributesIdList);
         }
         
         for(TproductTowerAttribute productTowerAttribute : productTowerAttributeList)
         {
        	 mandatoryAttributesList.add(productTowerAttribute.getTattribute().getAttributeNm());
         }
         
         return mandatoryAttributesList;
   }

 
 	/**
 	 * Author Nandhakumar
 	 * @param productTowerId
 	 * @param tableId
 	 * @param attributeName
 	 * @return
 	 */
 	public List<TproductTowerAttribute> findByProdTowerAttributeId(short productTowerId, short tableId,String attributeName)throws AIGCIExceptionMsg,JpaSystemException{
 		List<TproductTowerAttribute> tProductTowerAttribute=null;
 		tProductTowerAttribute = tProductTowerAttributeRepository.findByProdTowerAttributeId(productTowerId, tableId,NGEConstants.NO,attributeName);
 		if(tProductTowerAttribute.isEmpty()){
 			List<Object> errorFieldList=new ArrayList<Object>();		           
			errorFieldList.add(attributeName);
 			ngeException.throwException(
 					NGEErrorCodes.INVALID_ATTRIBUTEID_PRODUCT_TOWER,
 					NGEConstants.ERROR_TYPE_ERROR, "Attributes not found ",errorFieldList);
 		}
 		return tProductTowerAttribute;
 	}
 	
/**
 * @author Nandhakumarm
 * @param transactionId
 * @param versionSqn
 * @param productId
 * @param attributeId
 * @return
 * @throws JpaSystemException
 */
 	public Short getMaxProductAttributeSequence(String transactionId, short versionSqn, int productId, short attributeId)throws JpaSystemException{
 		Short maxSequenceNo;
 		maxSequenceNo = transactionProductAttributeRepository.findMaxAttributeSequence(transactionId, versionSqn, productId, attributeId);
 	
 		
 		return maxSequenceNo;
 	}
 	/**
 	 * @author Nandhakumarm
 	 * @param attributeList
 	 * @return
 	 * @throws AIGCIExceptionMsg
 	 * @throws JpaSystemException
 	 */
 	public List<TtransactionProductAttribute> saveProductAttribute(List<TtransactionProductAttribute> attributeList) throws AIGCIExceptionMsg,JpaSystemException{
 		List<TtransactionProductAttribute> attribute;
 		
 		attribute = transactionProductAttributeRepository.save(attributeList);
 		if(attribute.isEmpty()){
 			ngeException.throwException(NGEErrorCodes.SERVICE_FAILED,NGEErrorCodes.ERROR_TYPE, null,null);
 		}
 		return attribute;
 	}
 	/**
 	 * @author nandhakumarm
 	 * @param attributeList
 	 * @throws JpaSystemException
 	 */
 	
 	public void deleteProductAttribute(List<TtransactionProductAttribute> attributeList)throws JpaSystemException{
 		
 		for(TtransactionProductAttribute transactionProductAttribute: attributeList)
		{
 			transactionProductAttributeRepository.delete(transactionProductAttribute);
		}
 	
 		
 	}
 	
 	public void deleteComponentAttribute(List<TtransactionComponentAtrbt> attributeList)throws JpaSystemException{
 		for(TtransactionComponentAtrbt transactionComponentAttribute: attributeList)
		{
 		transactionComponentAttributeRepository.delete(transactionComponentAttribute);
		}
 	}
 	
 	public List<Tasset> findByAssetTypeAndValue(String assetType, String assetValue) throws AIGCIExceptionMsg, JpaSystemException{
 		List<Tasset> asset = new ArrayList<Tasset>();
 		asset = tAssetRepository.findByAssetTypeAndValue(assetType.toUpperCase(), assetValue);
 		if(asset.isEmpty()){
 			ngeException.throwException(NGEErrorCodes.SERVICE_FAILED,NGEErrorCodes.ERROR_TYPE, null,null);
 		}
 		return asset;
 	}
 	public List<Tasset> findByAssetTypeAndValueAndAssetId(String assetType, List<Integer> assetIdList)throws JpaSystemException{
 		List<Tasset> asset = new ArrayList<Tasset>();
 		asset = tAssetRepository.findByAssetTypeAndValueAndAssetId(assetType.toUpperCase(),assetIdList);
 		return asset;
 	}
 	
 	// Asset Handling - Starts
 	public List<TtransactionComponentAsset> getCompAssetsforAssetType(String assetType, String transactionComponentId)throws JpaSystemException{
 		List<TtransactionComponentAsset> compAsset = null;
 		compAsset = transactionComponentAssetRepository.getCompAssetsforAssetType(assetType.toUpperCase(), transactionComponentId);
 		return compAsset;
 	}
 	// Asset Handling - Ends
 
 	public TtransactionComponentAsset updateComponentAsset(TtransactionComponentAsset componentAsset) throws AIGCIExceptionMsg, JpaSystemException{
 		TtransactionComponentAsset tComponentAsset = null;
 		tComponentAsset = transactionComponentAssetRepository.save(componentAsset);
 		if(null ==tComponentAsset){
 			ngeException.throwException(NGEErrorCodes.SERVICE_FAILED,NGEErrorCodes.ERROR_TYPE, null,null);
 		}
 		return tComponentAsset;
 	}
 	
 	public void deleteAssetAttribute(List<TassetAttribute> assetAttributeList)throws JpaSystemException{
 		assetAttributeRepository.delete(assetAttributeList);
 	}
 	
 	public void deleteAssetAttributesSet(Set<TassetAttribute> assetAttributeList)throws JpaSystemException{
 		assetAttributeRepository.delete(assetAttributeList);
 	}
 	
 	public void deleteAsset(Tasset asset)throws JpaSystemException{
 		tAssetRepository.delete(asset);
 	}
 	
 	public void deleteAssetsList(List<Tasset> assetList)throws JpaSystemException{
 		tAssetRepository.delete(assetList);
 	}
 	
 	public List<TassetType> findByAssetTypeNm(String assetTypeNm)throws JpaSystemException, AIGCIExceptionMsg{
 		List<TassetType> assetTypeList = new ArrayList<TassetType>();
 		assetTypeList = tAssetTypeRepository.findByAssetTypeNmIgnoreCase(assetTypeNm);
 		if(assetTypeList == null){
 			ngeException.throwException(NGEErrorCodes.ASSET_TYPE_REQUIRED, NGEErrorCodes.ERROR_TYPE,"Invalid Asset Type.  Given Asset Type is either blank or does not exist in NGE",null);	
 		}
 		return assetTypeList;
 	}
 	public Tasset updateTasset(Tasset tAsset)throws JpaSystemException{
 		Tasset asset = new Tasset();
 		asset = tAssetRepository.save(tAsset);
 		return asset;
 	}
 	
 	public List<TassetAttribute> findAssetAttributeByAssetIdAndAttributeId(int assetId, short attributeId)throws JpaSystemException{
 		
 		List<TassetAttribute> tAssetAttributeList = null;
 		tAssetAttributeList=assetAttributeRepository.findByAssetIdAndAttributeId(assetId,attributeId);
 		return tAssetAttributeList;
 		
 	}
 	public Short getMaxAssetAttributeSequence(int assetId, short attributeId)throws JpaSystemException{
		Short maxSequenceNo;
 		maxSequenceNo = assetAttributeRepository.findMaxAttributeSequence(assetId, attributeId);
		 if(maxSequenceNo == null)
		 {
			 maxSequenceNo = 0;
		 }
 		return maxSequenceNo;
 	}
 	public List<TassetAttribute> saveAssetAttribute(List<TassetAttribute> assetAttributeList)throws JpaSystemException{
 		List<TassetAttribute> tAssetAttributeList = new ArrayList<TassetAttribute>();
 		tAssetAttributeList = assetAttributeRepository.save(assetAttributeList);
 	
 		
 		return tAssetAttributeList;
 	}
 	
 	public Treason getAlertorProductBlockReason(String reasonCd, String reasonType) throws AIGCIExceptionMsg
	{
 		
 		/*
		* EXADATA Migration Changes
		* 		Adding space for reason name 
		*/

		if(reasonCd.equals(NGEConstants.EMPTY_STRING))
			reasonCd = NGEConstants.EMPTY_SPACE;
		
		Treason  reason = reasonRepository.findByReasonTypeIdAndReasonNm( reasonType.toUpperCase(), reasonCd.toUpperCase());
		   
		   return reason;
	}
 	
 	@Cacheable("ProductDAO.getSubProductIdFromVComponentProduct")
 	public int getSubProductIdFromVComponentProduct(int componentProductId)throws AIGCIExceptionMsg{
 		
 		TmarketableProductComponent marketableProductComponentData = null; 		
 		int tTuwSubProductId = 0;
 		TtuwSubProduct tTuwSubProductData = null;
 		TproductDsp TproductDspData = null;
 		TproductMmcp TproductMmcpData = null;
 		 		
 			marketableProductComponentData = tMarketableProductComponentRepository.findOne(componentProductId);
 			if(marketableProductComponentData != null){
 				tTuwSubProductId = marketableProductComponentData.getTproductTowerTuwSubProduct().getTtuwSubProduct().getTuwSubProductId();			
 			} 		
 			else {
 			tTuwSubProductData = tTuwSubProductRepository.findOne(componentProductId);
 			if(tTuwSubProductData != null){
 				tTuwSubProductId = tTuwSubProductData.getTuwSubProductId();
 				} 
 				else{
 				TproductDspData = tProductDSPRepository.findOne(componentProductId);
 	 			if(TproductDspData != null){
 	 				tTuwSubProductId = TproductDspData.getTproductTowerTuwSubProduct().getTtuwSubProduct().getTuwSubProductId();
 	 			}
 	 			else{
 	 				TproductMmcpData = tProductMMCPRepository.findOne(componentProductId);
 	 	 			if(TproductMmcpData != null){
 	 	 				tTuwSubProductId = TproductMmcpData.getTproductTowerTuwSubProduct().getTtuwSubProduct().getTuwSubProductId();
 	 	 			} 	 	 			 	 	 			
 	 			} 	 			
 			} 			
 		}
		return tTuwSubProductId; 		
 	} 
 	
 	public List<Short> findAttributesForBatch(short productTowerId, short tableId, String usageTypeNm){
		List<Short> attributes = new ArrayList<Short>();		
		attributes=productTowerAttributeUsageRepository.findAttributesForBatch(productTowerId, tableId, usageTypeNm.toUpperCase());		
		return attributes;
	}
 	
 	public List<TproductTowerAttributeUsage> getODMRelatedAttributes(short productTowerId, String tableName, String attributeName, String usageTypeNm){
 		List<TproductTowerAttributeUsage> productTowerAttrUsageList = null;
 		productTowerAttrUsageList = productTowerAttributeUsageRepository.getODMRelatedAttributes(productTowerId, tableName, attributeName, usageTypeNm.toUpperCase());
 		return productTowerAttrUsageList;
 	}
 	
 	public TtransactionVersion fetchTransactionComponentVersionObject(String transactionComponentId) throws AIGCIExceptionMsg{
 		TtransactionVersion versionObject = null;
 		versionObject = transactionComponentRepository.fetchTransactionComponentVersionObject(transactionComponentId);
 		if(versionObject == null){
 			ngeException.throwException(NGEErrorCodes.COMPONENT_NOT_FOUND, NGEErrorCodes.ERROR_TYPE, null, null);
 		}
 		return  versionObject;
 	}
 	
 	public TmarketableProductLocation getMarketableProdLocationCombination(int marketableProductId, int geographicLocationId) throws AIGCIExceptionMsg{
 		
 		TmarketableProductLocation marketableProductLocationData = null;
 		marketableProductLocationData = tMarketableProductLocationRepository.getMarketableProdLocationCombination(marketableProductId, geographicLocationId);
 		return marketableProductLocationData;  		
 	}
 // NGE UI sept release changes start
 	public String getDSPByPrdctTwrMktPdCDAndCmpntPdCdDAO(short productTowerId,String marketableProductCd,String componentProductCd){
 		String dspId = tMarketableProductRepository.getDSPByPrdctTwrMktPdCDAndCmpntPdCd(productTowerId,marketableProductCd,componentProductCd);
 		return dspId;
 	}
 	
 	public String getMMCPByPrdctTwrMktPdCDAndCmpntPdCdDAO(short productTowerId,String marketableProductCd,String componentProductCd){
 		String dspId = tMarketableProductRepository.getMMCPByPrdctTwrMktPdCDAndCmpntPdCd(productTowerId,marketableProductCd,componentProductCd);
 		return dspId;
 	}
 	
 	public String getDSPByPrdctTwrAndCmpntPdCdDAO(short productTowerId,String componentProductCd){
 		String dspId = tMarketableProductRepository.getDSPByPrdctTwrAndCmpntPdCd(productTowerId,componentProductCd);
 		return dspId;
 	}
 	
 	public String getMMCPByPrdctTwrAndCmpntPdCdDAO(short productTowerId,String componentProductCd){
 		String dspId = tMarketableProductRepository.getMMCPByPrdctTwrAndCmpntPdCd(productTowerId,componentProductCd);
 		return dspId;
 	}
 // NGE UI sept release changes end
 	public TproductDsp getDSPByComponentId(int componentProductId){
 		TproductDsp productDspData = tProductDSPRepository.findOne(componentProductId);
 		return productDspData;
 	}
 	public TproductMmcp getMMCPByComponentId(int componentProductId){
 		TproductMmcp productMMCPData = tProductMMCPRepository.findOne(componentProductId);
 		return productMMCPData;
 	}
}
