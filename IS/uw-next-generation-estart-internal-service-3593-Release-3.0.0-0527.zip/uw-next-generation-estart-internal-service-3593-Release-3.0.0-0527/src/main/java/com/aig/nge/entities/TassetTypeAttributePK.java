package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the TASSET_TYPE_ATTRIBUTE database table.
 * 
 */
@Embeddable
public class TassetTypeAttributePK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="ASSET_TYPE_ID")
	private int assetTypeId;

	@Column(name="ATTRIBUTE_ID")
	private short attributeId;

	@Column(name="ATTRIBUTE_SQN")
	private short attributeSqn;

    public TassetTypeAttributePK() {
    }
	public int getAssetTypeId() {
		return this.assetTypeId;
	}
	public void setAssetTypeId(int assetTypeId) {
		this.assetTypeId = assetTypeId;
	}
	public short getAttributeId() {
		return this.attributeId;
	}
	public void setAttributeId(short attributeId) {
		this.attributeId = attributeId;
	}
	public short getAttributeSqn() {
		return this.attributeSqn;
	}
	public void setAttributeSqn(short attributeSqn) {
		this.attributeSqn = attributeSqn;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof TassetTypeAttributePK)) {
			return false;
		}
		TassetTypeAttributePK castOther = (TassetTypeAttributePK)other;
		return 
			(this.assetTypeId == castOther.assetTypeId)
			&& (this.attributeId == castOther.attributeId)
			&& (this.attributeSqn == castOther.attributeSqn);

    }
    
	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.assetTypeId;
		hash = hash * prime + ((int) this.attributeId);
		hash = hash * prime + ((int) this.attributeSqn);
		
		return hash;
    }
}