package com.aig.nge.entities;

import java.util.Date;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-04-15T15:31:47.400+0530")
@StaticMetamodel(TlegacyWipQuoteHPK.class)
public class TlegacyWipQuoteHPK_ {
	public static volatile SingularAttribute<TlegacyWipQuoteHPK, String> transactionComponentId;
	public static volatile SingularAttribute<TlegacyWipQuoteHPK, String> wipId;
	public static volatile SingularAttribute<TlegacyWipQuoteHPK, Short> quoteSqn;
	public static volatile SingularAttribute<TlegacyWipQuoteHPK, Date> createHistoryTs;
}
