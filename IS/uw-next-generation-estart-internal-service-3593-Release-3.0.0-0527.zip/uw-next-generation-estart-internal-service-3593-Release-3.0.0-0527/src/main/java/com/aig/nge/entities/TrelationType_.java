package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SetAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-02-19T16:13:04.347+0530")
@StaticMetamodel(TrelationType.class)
public class TrelationType_ {
	public static volatile SingularAttribute<TrelationType, Short> relationTypeId;
	public static volatile SingularAttribute<TrelationType, Timestamp> createTs;
	public static volatile SingularAttribute<TrelationType, String> createUserId;
	public static volatile SingularAttribute<TrelationType, String> relationTypeNm;
	public static volatile SingularAttribute<TrelationType, Timestamp> updateTs;
	public static volatile SingularAttribute<TrelationType, String> updateUserId;
	public static volatile SetAttribute<TrelationType, TtransactionRelation> ttransactionRelations;
}
