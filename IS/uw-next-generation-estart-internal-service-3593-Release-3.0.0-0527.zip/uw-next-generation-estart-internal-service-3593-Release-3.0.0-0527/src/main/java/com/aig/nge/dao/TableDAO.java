package com.aig.nge.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.jpa.JpaSystemException;
import org.springframework.stereotype.Repository;

import com.aig.nge.entities.Tattribute;
import com.aig.nge.entities.Ttable;
import com.aig.nge.entities.TtableAttribute;
import com.aig.nge.entities.TtableAttributePK;
import com.aig.nge.repository.TAttributeRepository;
import com.aig.nge.repository.TTableAttributeRepository;
import com.aig.nge.repository.TTableRepository;
import com.aig.nge.utilities.AIGCIExceptionMsg;
import com.aig.nge.utilities.NGEErrorCodes;

@Repository
public class TableDAO extends BaseDAO{
	
	@Autowired
	private TTableRepository tableRepository;
	
	@Autowired
	private TTableAttributeRepository tableAttributeRepository;
	
	@Autowired
	private TAttributeRepository attributeRepository;
	
	public Tattribute getByAttributeNm(String attributeName){
	Tattribute attributeObj = attributeRepository.findByAttributeName(attributeName.toUpperCase());
	return attributeObj;
	}
	
	public TtableAttribute getTableAttribute( TtableAttributePK tableAttributePK){
		
		TtableAttribute tableAttributeData = tableAttributeRepository.findOne(tableAttributePK);
		return tableAttributeData;
	}

	
	public Ttable getTableData(String tableName) throws AIGCIExceptionMsg{
	
		Ttable tableData = tableRepository.findByTableNm(tableName);
		if(null == tableData){
			List<Object> errorFieldList=new ArrayList<Object>();		           
 			errorFieldList.add(tableName);
      	  ngeException.throwException(
						NGEErrorCodes.NO_TABLE_FOUND,
						NGEErrorCodes.ERROR_TYPE, null, errorFieldList);
        }
		return tableData;
	}
	/**
 	 * Author Nandhakumar
 	 * @param tableNm
 	 * @return
 	 * @throws AIGCIExceptionMsg 
 	 */
 	public Ttable findByTableName(String tableNm) throws AIGCIExceptionMsg,JpaSystemException{
 		Ttable tTable=null;
 		tTable = tableRepository.findByTableNm(tableNm);
 		if(null == tTable){
 			List<Object> errorFieldList=new ArrayList<Object>();		           
 			errorFieldList.add(tableNm);
 			ngeException.throwException(
 					NGEErrorCodes.NO_TABLE_FOUND,
 					NGEErrorCodes.ERROR_TYPE, null, errorFieldList);
 		}
 		return tTable;
 	}
}
