package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-06-19T14:59:45.634+0530")
@StaticMetamodel(TerrorMapping.class)
public class TerrorMapping_ {
	public static volatile SingularAttribute<TerrorMapping, TerrorMappingPK> id;
	public static volatile SingularAttribute<TerrorMapping, Timestamp> createTs;
	public static volatile SingularAttribute<TerrorMapping, String> createUserId;
	public static volatile SingularAttribute<TerrorMapping, Timestamp> updateTs;
	public static volatile SingularAttribute<TerrorMapping, String> updateUserId;
	public static volatile SingularAttribute<TerrorMapping, Terror> terror;
	public static volatile SingularAttribute<TerrorMapping, TlegacyError> tlegacyError;
}
