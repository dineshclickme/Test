package com.aig.nge.entities;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.text.DecimalFormat;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


/**
 * The persistent class for the TLEGACY_TRANSACTION_EXTENSION database table.
 * 
 */
@Entity
@Table(name="TLEGACY_TRANSACTION_EXTENSION")
public class TlegacyTransactionExtension implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private TlegacyTransactionExtensionPK id;

	@Column(name="BUNDLE_ATTACHMENT_AM")
	private BigDecimal bundleAttachmentAm;

	@Column(name="BUNDLE_LIMIT_AM")
	private BigDecimal bundleLimitAm;

	@Column(name="BUNDLE_PART_OF_AM")
	private BigDecimal bundlePartOfAm;

	@Column(name="BUNDLE_PREMIUM_AM")
	private BigDecimal bundlePremiumAm;

	@Column(name="CREATE_TS")
	private Timestamp createTs;

	@Column(name="CREATE_USER_ID")
	private String createUserId;

	@Column(name="LEGACY_BUNDLED_COVG_TYPE_CD")
	private String legacyBundledCovgTypeCd;

	@Column(name="LOCAL_BUNDLE_ATTACHMENT_AM")
	private BigDecimal localBundleAttachmentAm;

	@Column(name="LOCAL_BUNDLE_LIMIT_AM")
	private BigDecimal localBundleLimitAm;

	@Column(name="LOCAL_BUNDLE_PART_OF_AM")
	private BigDecimal localBundlePartOfAm;

	@Column(name="LOCAL_BUNDLE_PREMIUM_AM")
	private BigDecimal localBundlePremiumAm;

	@Column(name="NON_RECURRING_IN")
	private String nonRecurringIn;

	@Column(name="PROFIT_CENTER_CD")
	private String profitCenterCd;

	@Column(name="PROFIT_UNIT_CD")
	private short profitUnitCd;

	@Column(name="RR_PRTCTV_CONT_NO")
	private int rrPrtctvContNo;

	@Column(name="SECTION_CD")
	private short sectionCd;

	@Column(name="SPECIAL_EVENT_NM")
	private String specialEventNm;

    @Temporal( TemporalType.DATE)
	@Column(name="UNDERWRITING_DT")
	private Date underwritingDt;

	@Column(name="UPDATE_TS")
	private Timestamp updateTs;

	@Column(name="UPDATE_USER_ID")
	private String updateUserId;

	//bi-directional many-to-one association to TinsuranceCarrier
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="CARRIER_ID")
	private TinsuranceCarrier tinsuranceCarrier;

	//bi-directional many-to-one association to TlegacyProduct
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="LEGACY_BUNDLED_PRODUCT_CD")
	private TlegacyProduct tlegacyProduct;
    @ManyToOne(fetch=FetchType.LAZY)
	@JoinColumns({
		@JoinColumn(name="TRANSACTION_ID", referencedColumnName="TRANSACTION_ID"),
		@JoinColumn(name="VERSION_SQN", referencedColumnName="VERSION_SQN")
		})
	private TtransactionVersion ttransactionVersion;

    public TlegacyTransactionExtension() {
    }

	public TlegacyTransactionExtensionPK getId() {
		return this.id;
	}

	public void setId(TlegacyTransactionExtensionPK id) {
		this.id = id;
	}
	
	public BigDecimal getBundleAttachmentAm() {
		/* exadata changes - formatting the decimal field */
		if(this.bundleAttachmentAm != null){
			DecimalFormat df = new DecimalFormat("0.000000");
	    	BigDecimal formattedPremAm = new BigDecimal(df.format(this.bundleAttachmentAm));	
			return formattedPremAm;
		}else{
			return this.bundleAttachmentAm;
		}
	}

	public void setBundleAttachmentAm(BigDecimal bundleAttachmentAm) {
		this.bundleAttachmentAm = bundleAttachmentAm;
	}

	public BigDecimal getBundleLimitAm() {
		/* exadata changes - formatting the decimal field */
		if(this.bundleLimitAm != null){
			DecimalFormat df = new DecimalFormat("0.000000");
	    	BigDecimal formattedPremAm = new BigDecimal(df.format(this.bundleLimitAm));	
			return formattedPremAm;
		}else{
			return this.bundleLimitAm;
		}
	}

	public void setBundleLimitAm(BigDecimal bundleLimitAm) {
		this.bundleLimitAm = bundleLimitAm;
	}

	public BigDecimal getBundlePartOfAm() {
		/* exadata changes - formatting the decimal field */
		if(this.bundlePartOfAm != null){
			DecimalFormat df = new DecimalFormat("0.000000");
	    	BigDecimal formattedPremAm = new BigDecimal(df.format(this.bundlePartOfAm));	
			return formattedPremAm;
		}else{
			return this.bundlePartOfAm;
		}
	}

	public void setBundlePartOfAm(BigDecimal bundlePartOfAm) {
		this.bundlePartOfAm = bundlePartOfAm;
	}

	public BigDecimal getBundlePremiumAm() {
		/* exadata changes - formatting the decimal field */
		if(this.bundlePremiumAm != null){
			DecimalFormat df = new DecimalFormat("0.000000");
	    	BigDecimal formattedPremAm = new BigDecimal(df.format(this.bundlePremiumAm));	
			return formattedPremAm;
		}else{
			return this.bundlePremiumAm;
		}
	}

	public void setBundlePremiumAm(BigDecimal bundlePremiumAm) {
		this.bundlePremiumAm = bundlePremiumAm;
	}

	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public String getLegacyBundledCovgTypeCd() {
		return this.legacyBundledCovgTypeCd;
	}

	public void setLegacyBundledCovgTypeCd(String legacyBundledCovgTypeCd) {
		this.legacyBundledCovgTypeCd = legacyBundledCovgTypeCd;
	}

	public BigDecimal getLocalBundleAttachmentAm() {
		/* exadata changes - formatting the decimal field */
		if(this.localBundleAttachmentAm != null){
			DecimalFormat df = new DecimalFormat("0.000000");
	    	BigDecimal formattedPremAm = new BigDecimal(df.format(this.localBundleAttachmentAm));	
			return formattedPremAm;
		}else{
			return this.localBundleAttachmentAm;
		}
	}

	public void setLocalBundleAttachmentAm(BigDecimal localBundleAttachmentAm) {
		this.localBundleAttachmentAm = localBundleAttachmentAm;
	}

	public BigDecimal getLocalBundleLimitAm() {
		/* exadata changes - formatting the decimal field */
		if(this.localBundleLimitAm != null){
			DecimalFormat df = new DecimalFormat("0.000000");
	    	BigDecimal formattedPremAm = new BigDecimal(df.format(this.localBundleLimitAm));	
			return formattedPremAm;
		}else{
			return this.localBundleLimitAm;
		}
	}

	public void setLocalBundleLimitAm(BigDecimal localBundleLimitAm) {
		this.localBundleLimitAm = localBundleLimitAm;
	}

	public BigDecimal getLocalBundlePartOfAm() {
		/* exadata changes - formatting the decimal field */
		if(this.localBundlePartOfAm != null){
			DecimalFormat df = new DecimalFormat("0.000000");
	    	BigDecimal formattedPremAm = new BigDecimal(df.format(this.localBundlePartOfAm));	
			return formattedPremAm;
		}else{
			return this.localBundlePartOfAm;
		}
	}

	public void setLocalBundlePartOfAm(BigDecimal localBundlePartOfAm) {
		this.localBundlePartOfAm = localBundlePartOfAm;
	}

	public BigDecimal getLocalBundlePremiumAm() {
		/* exadata changes - formatting the decimal field */
		if(this.localBundlePremiumAm != null){
			DecimalFormat df = new DecimalFormat("0.000000");
	    	BigDecimal formattedPremAm = new BigDecimal(df.format(this.localBundlePremiumAm));	
			return formattedPremAm;
		}else{
			return this.localBundlePremiumAm;
		}
	}

	public void setLocalBundlePremiumAm(BigDecimal localBundlePremiumAm) {
		this.localBundlePremiumAm = localBundlePremiumAm;
	}

	public String getNonRecurringIn() {
		return this.nonRecurringIn;
	}

	public void setNonRecurringIn(String nonRecurringIn) {
		this.nonRecurringIn = nonRecurringIn;
	}

	public String getProfitCenterCd() {
		return this.profitCenterCd;
	}

	public void setProfitCenterCd(String profitCenterCd) {
		this.profitCenterCd = profitCenterCd;
	}

	public short getProfitUnitCd() {
		return this.profitUnitCd;
	}

	public void setProfitUnitCd(short profitUnitCd) {
		this.profitUnitCd = profitUnitCd;
	}

	public int getRrPrtctvContNo() {
		return this.rrPrtctvContNo;
	}

	public void setRrPrtctvContNo(int rrPrtctvContNo) {
		this.rrPrtctvContNo = rrPrtctvContNo;
	}

	public short getSectionCd() {
		return this.sectionCd;
	}

	public void setSectionCd(short sectionCd) {
		this.sectionCd = sectionCd;
	}

	public String getSpecialEventNm() {
		return this.specialEventNm;
	}

	public void setSpecialEventNm(String specialEventNm) {
		this.specialEventNm = specialEventNm;
	}

	public Date getUnderwritingDt() {
		return this.underwritingDt;
	}

	public void setUnderwritingDt(Date underwritingDt) {
		this.underwritingDt = underwritingDt;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public TinsuranceCarrier getTinsuranceCarrier() {
		return this.tinsuranceCarrier;
	}

	public void setTinsuranceCarrier(TinsuranceCarrier tinsuranceCarrier) {
		this.tinsuranceCarrier = tinsuranceCarrier;
	}
	
	public TlegacyProduct getTlegacyProduct() {
		return this.tlegacyProduct;
	}

	public void setTlegacyProduct(TlegacyProduct tlegacyProduct) {
		this.tlegacyProduct = tlegacyProduct;
	}
	
	public TtransactionVersion getTtransactionVersion() {
		return this.ttransactionVersion;
	}

	public void setTtransactionVersion(TtransactionVersion ttransactionVersion) {
		this.ttransactionVersion = ttransactionVersion;
	}
	
}