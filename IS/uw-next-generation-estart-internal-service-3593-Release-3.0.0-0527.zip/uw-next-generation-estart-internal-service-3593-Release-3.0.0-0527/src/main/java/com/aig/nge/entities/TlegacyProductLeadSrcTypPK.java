package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the TLEGACY_PRODUCT_LEAD_SRC_TYP database table.
 * 
 */
@Embeddable
public class TlegacyProductLeadSrcTypPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="TRANSACTION_COMPONENT_ID")
	private String transactionComponentId;

	@Column(name="SOURCE_CD")
	private String sourceCd;

	@Column(name="LEAD_SOURCE_TYPE_CD")
	private String leadSourceTypeCd;

    public TlegacyProductLeadSrcTypPK() {
    }
	public String getTransactionComponentId() {
		return this.transactionComponentId;
	}
	public void setTransactionComponentId(String transactionComponentId) {
		this.transactionComponentId = transactionComponentId;
	}
	public String getSourceCd() {
		return this.sourceCd;
	}
	public void setSourceCd(String sourceCd) {
		this.sourceCd = sourceCd;
	}
	public String getLeadSourceTypeCd() {
		return this.leadSourceTypeCd;
	}
	public void setLeadSourceTypeCd(String leadSourceTypeCd) {
		this.leadSourceTypeCd = leadSourceTypeCd;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof TlegacyProductLeadSrcTypPK)) {
			return false;
		}
		TlegacyProductLeadSrcTypPK castOther = (TlegacyProductLeadSrcTypPK)other;
		return 
			this.transactionComponentId.equals(castOther.transactionComponentId)
			&& this.sourceCd.equals(castOther.sourceCd)
			&& this.leadSourceTypeCd.equals(castOther.leadSourceTypeCd);

    }
    
	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.transactionComponentId.hashCode();
		hash = hash * prime + this.sourceCd.hashCode();
		hash = hash * prime + this.leadSourceTypeCd.hashCode();
		
		return hash;
    }
}