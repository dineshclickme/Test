package com.aig.nge.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.aig.nge.entities.Tparty;
import com.aig.nge.entities.Tuser;
import com.aig.nge.utilities.AIGCIExceptionMsg;
import com.aig.nge.utilities.NGEConstants;
import com.aig.nge.utilities.NGEErrorCodes;
import com.aig.nge.utilities.NGESession;
import com.aig.nge.utilities.NGEValidations;

/**
 * 
 * @author Manasaj This DAO class is used for accessing the User related
 *         repositories Used repositories are TuserRepository
 */
@Repository
public class UserDAO extends BaseDAO{

	
	
	@Autowired
	private NGEValidations ngeValidations;
	
	@Autowired
	private PartyDAO partyDAO;

	
	
	
	public void validateUnderwriterId(String underwriterId)
			throws AIGCIExceptionMsg {
				
		Tparty partyData = null;
		Tuser userData = null;
		
		// Validate for Empty String
		ngeValidations.validateNullCheck(underwriterId, NGEErrorCodes.UNDERWRITER_ID_MISSING,
				NGEErrorCodes.ERROR_TYPE);
		
				
		//Validate the Underwriter against TPARTY table	
		partyData = partyDAO.getUnderwriterParty(underwriterId, NGEConstants.PartyType.UNDERWRITER);
		
		//User service validation bypassed to support legacy
		if(partyData == null)
		{		
			if(NGESession.getSessionData().getClientId() != null){
				
				if(!NGESession.getSessionData().getClientId().equalsIgnoreCase(NGEConstants.LEGACY_CONSUMERS)){
					
					ngeException.throwException(NGEErrorCodes.UNDERWRITER_ID_MISSING,NGEErrorCodes.ERROR_TYPE, null, null);
				}
			}
			else{
				ngeException.throwException(NGEErrorCodes.UNDERWRITER_ID_MISSING,NGEErrorCodes.ERROR_TYPE, null, null);
			}			
		}
		
		// Validate the Underwriter Status
		if(partyData != null){
			
			userData = partyDAO.findByPartyId(partyData.getPartyId());
			if(userData == null){
				
				ngeException.throwException(NGEErrorCodes.UNDERWRITER_ID_MISSING,NGEErrorCodes.ERROR_TYPE, null, null);
			}
			else{
				
				if(userData.getTuserStatus().getStatusDs().equalsIgnoreCase(NGEConstants.UserStatus.SUSPENDED_STATUS)){
					if(NGESession.getSessionData().getClientId() !=null){					
					
					if(! NGESession.getSessionData().getClientId().equalsIgnoreCase(NGEConstants.LEGACY_CONSUMERS))
					{
					ngeException.throwException(NGEErrorCodes.UNDERWRITER_IN_ACTIVE,NGEErrorCodes.ERROR_TYPE, null, null);
					}
					}
					else
					{
						ngeException.throwException(NGEErrorCodes.UNDERWRITER_IN_ACTIVE,NGEErrorCodes.ERROR_TYPE, null, null);	
					}
				}
			}
		}

	
	}

}
