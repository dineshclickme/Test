package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SetAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-02-19T16:13:03.641+0530")
@StaticMetamodel(Tmethod.class)
public class Tmethod_ {
	public static volatile SingularAttribute<Tmethod, Short> methodId;
	public static volatile SingularAttribute<Tmethod, Timestamp> createTs;
	public static volatile SingularAttribute<Tmethod, String> createUserId;
	public static volatile SingularAttribute<Tmethod, String> methodNm;
	public static volatile SingularAttribute<Tmethod, Timestamp> updateTs;
	public static volatile SingularAttribute<Tmethod, String> updateUserId;
	public static volatile SingularAttribute<Tmethod, Tservice> tservice;
	public static volatile SetAttribute<Tmethod, TsystemMethod> tsystemMethods;
}
