package com.aig.nge.entities;

import java.math.BigDecimal;
import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-04-15T15:31:47.322+0530")
@StaticMetamodel(TlegacyWipQuoteCurrency.class)
public class TlegacyWipQuoteCurrency_ {
	public static volatile SingularAttribute<TlegacyWipQuoteCurrency, TlegacyWipQuoteCurrencyPK> id;
	public static volatile SingularAttribute<TlegacyWipQuoteCurrency, Timestamp> createTs;
	public static volatile SingularAttribute<TlegacyWipQuoteCurrency, String> createUserId;
	public static volatile SingularAttribute<TlegacyWipQuoteCurrency, BigDecimal> policyAtchmtPointAm;
	public static volatile SingularAttribute<TlegacyWipQuoteCurrency, BigDecimal> policyLimitAm;
	public static volatile SingularAttribute<TlegacyWipQuoteCurrency, BigDecimal> policyPartOfAm;
	public static volatile SingularAttribute<TlegacyWipQuoteCurrency, BigDecimal> quotedAtchmtPointAm;
	public static volatile SingularAttribute<TlegacyWipQuoteCurrency, BigDecimal> quotedLimitAm;
	public static volatile SingularAttribute<TlegacyWipQuoteCurrency, BigDecimal> quotedPremiumAm;
	public static volatile SingularAttribute<TlegacyWipQuoteCurrency, Timestamp> updateTs;
	public static volatile SingularAttribute<TlegacyWipQuoteCurrency, String> updateUserId;
	public static volatile SingularAttribute<TlegacyWipQuoteCurrency, Tcurrency> tcurrency;
	public static volatile SingularAttribute<TlegacyWipQuoteCurrency, TlegacyWipQuote> tlegacyWipQuote;
	public static volatile SingularAttribute<TlegacyWipQuoteCurrency, BigDecimal> boundPremiumAm;
}
