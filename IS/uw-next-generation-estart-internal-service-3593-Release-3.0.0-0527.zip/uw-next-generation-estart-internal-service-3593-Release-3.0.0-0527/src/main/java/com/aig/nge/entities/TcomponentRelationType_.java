package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SetAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-02-19T16:13:03.178+0530")
@StaticMetamodel(TcomponentRelationType.class)
public class TcomponentRelationType_ {
	public static volatile SingularAttribute<TcomponentRelationType, Short> relationTypeId;
	public static volatile SingularAttribute<TcomponentRelationType, Timestamp> createTs;
	public static volatile SingularAttribute<TcomponentRelationType, String> createUserId;
	public static volatile SingularAttribute<TcomponentRelationType, String> relationTypeNm;
	public static volatile SingularAttribute<TcomponentRelationType, Timestamp> updateTs;
	public static volatile SingularAttribute<TcomponentRelationType, String> updateUserId;
	public static volatile SetAttribute<TcomponentRelationType, TtransactionComponentRltn> ttransactionComponentRltns;
}
