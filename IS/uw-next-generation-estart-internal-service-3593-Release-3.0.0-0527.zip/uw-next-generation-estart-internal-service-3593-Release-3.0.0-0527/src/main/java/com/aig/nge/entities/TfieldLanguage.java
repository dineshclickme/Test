package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the TFIELD_LANGUAGE database table.
 * 
 */
@Entity
@Table(name="TFIELD_LANGUAGE")
public class TfieldLanguage implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private TfieldLanguagePK id;

	@Column(name="CREATE_TS")
	private Timestamp createTs;

	@Column(name="CREATE_USER_ID")
	private String createUserId;

	@Column(name="FIELD_IN_LANGUAGE_NM")
	private String fieldInLanguageNm;

	@Column(name="UPDATE_TS")
	private Timestamp updateTs;

	@Column(name="UPDATE_USER_ID")
	private String updateUserId;

	//bi-directional many-to-one association to Tfield
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="FIELD_ID")
	private Tfield tfield;

	//bi-directional many-to-one association to Tlanguage
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="LANGUAGE_ID")
	private Tlanguage tlanguage;

    public TfieldLanguage() {
    }

	public TfieldLanguagePK getId() {
		return this.id;
	}

	public void setId(TfieldLanguagePK id) {
		this.id = id;
	}
	
	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public String getFieldInLanguageNm() {
		if(fieldInLanguageNm != null)
			return this.fieldInLanguageNm.trim();
		else
			return this.fieldInLanguageNm;
	}

	public void setFieldInLanguageNm(String fieldInLanguageNm) {
		this.fieldInLanguageNm = fieldInLanguageNm;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public Tfield getTfield() {
		return this.tfield;
	}

	public void setTfield(Tfield tfield) {
		this.tfield = tfield;
	}
	
	public Tlanguage getTlanguage() {
		return this.tlanguage;
	}

	public void setTlanguage(Tlanguage tlanguage) {
		this.tlanguage = tlanguage;
	}
	
}