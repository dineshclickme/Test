package com.aig.nge.entities;

import java.sql.Timestamp;
import java.util.Date;
import javax.annotation.Generated;
import javax.persistence.metamodel.SetAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-02-19T16:13:04.622+0530")
@StaticMetamodel(Tsystem.class)
public class Tsystem_ {
	public static volatile SingularAttribute<Tsystem, Short> systemId;
	public static volatile SingularAttribute<Tsystem, Date> certificateExpirationDt;
	public static volatile SingularAttribute<Tsystem, Timestamp> createTs;
	public static volatile SingularAttribute<Tsystem, String> createUserId;
	public static volatile SingularAttribute<Tsystem, String> systemNm;
	public static volatile SingularAttribute<Tsystem, String> systemShortNm;
	public static volatile SingularAttribute<Tsystem, Timestamp> updateTs;
	public static volatile SingularAttribute<Tsystem, String> updateUserId;
	public static volatile SetAttribute<Tsystem, Terror> terrors;
	public static volatile SetAttribute<Tsystem, TlegacyRulesViolation> tlegacyRulesViolations;
	public static volatile SetAttribute<Tsystem, TpartyAction> tpartyActions;
	public static volatile SetAttribute<Tsystem, Tproperty> tproperties;
	public static volatile SetAttribute<Tsystem, Tsubmission> tsubmissions;
	public static volatile SetAttribute<Tsystem, TsystemMethod> tsystemMethods;
	public static volatile SetAttribute<Tsystem, TlegacyPolicySplitRule> tlegacyPolicySplitRules;
	//public static volatile SetAttribute<Tsystem, TlegacyWipQuote> tlegacyWipQuotes;
}
