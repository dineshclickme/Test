package com.aig.nge.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.aig.nge.entities.TreftabMis780;
import com.aig.nge.entities.TtransactionComponent;
import com.aig.nge.repository.TLegacyProductMappingRepository;
import com.aig.nge.repository.TReftabRepository;
import com.aig.nge.utilities.AIGCIExceptionMsg;
import com.aig.nge.utilities.NGECommonUtil;
import com.aig.nge.utilities.NGEConstants;
import com.aig.nge.utilities.NGEErrorCodes;
import com.aig.nge.utilities.NGESession;import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * @author Chinthamani This DAO class is used for accessing the
 *         LegacyProductMapping related repositories 
 * 
 */
@Repository
public class TLegacyProductMappingDAO  extends BaseDAO{

	private static final Logger logger = LogManager.getLogger(TLegacyProductMappingDAO.class);
	
	@Autowired
	private TLegacyProductMappingRepository legacyProduct;
	@Autowired
	private TReftabRepository refTab;
	
//	public List<Object[]> getProduct(Long componentProductId,Long productDetailID){
//	List<Object[]> monoProductList=	legacyProduct.findMappedProduct(componentProductId.toString(), productDetailID.toString());
//	return monoProductList;
//	}
//	public Object[] getMappedProduct(Long componentProductId,Long productDetailID){
//		Object[] monoProductList=	legacyProduct.findProduct(componentProductId.toString(), productDetailID.toString());
//		return monoProductList;
//		}
//	public List<Object[]> getBundledProduct(Long componentProductId){
//		List<Object[]> bundledProductList=	legacyProduct.findBundledProduct(componentProductId);
//		return bundledProductList;
//		}
	
	public List<Object[]> getLegacyProductProduct(String transactionCmpId){
		List<Object[]> bundledProductList=	legacyProduct.getLegacyProductwithSource(transactionCmpId);
		if(bundledProductList==null)
			bundledProductList=legacyProduct.getLegacyProductwithoutSource(transactionCmpId);
		if(bundledProductList==null)
			bundledProductList=legacyProduct.getLegacyProductForBundle(transactionCmpId);
		return bundledProductList;
	}
    public String getTransactionComponentIdByProductCd(String productCd,Long submissionNo){
	String componentId=legacyProduct.getTransactionComponentIdByProductCd(NGECommonUtil.convertToString(productCd), submissionNo);
	return componentId;
	}
    public String ascoCd(int isCode)throws AIGCIExceptionMsg{
    	
    	TreftabMis780 refTab1 = null;
    	String ascoCode = NGEConstants.EMPTY_STRING;
    	
    	refTab1=refTab.validateIssueCompanyCd(isCode);
    	
    	if(refTab1 != null){
    		
    		if(refTab1.getDeletedIn().equalsIgnoreCase(NGEConstants.YES)){
    			
    			if(NGESession.getSessionData().getClientId() != null){
    				
    				if(!NGESession.getSessionData().getClientId().equalsIgnoreCase(NGEConstants.LEGACY_CONSUMERS)){
    					
    					ngeException.throwException(NGEErrorCodes.INVALID_POLICY_ISS_COMP_CD,
    							NGEErrorCodes.ERROR_TYPE, "Invalid Issuing Company Code. Given Issuing Company Code is either blank or does not exist in NGE", null);
    				}			
    			}
    			else{
    				ngeException.throwException(NGEErrorCodes.INVALID_POLICY_ISS_COMP_CD,
    						NGEErrorCodes.ERROR_TYPE, "Invalid Issuing Company Code. Given Issuing Company Code is either blank or does not exist in NGE", null);
    			} 
    		}    	
    		ascoCode=refTab1.getMis780AscoCode();
    	}
    	
    	return ascoCode;
    }
    public void getAutoRenewalComponentsForInsert()
    {           
          String nonRecurringIndVal = "Recurring";  
          String legacyInd = "N";
          String deletedInd = "N";
          short statusId = 3;
short nonRecurringAttributeId = 117;
List<TtransactionComponent> insertComponentList =null;                  
          
insertComponentList = legacyProduct.getEligibleAutoRenewalComponentsNew(legacyInd, deletedInd, statusId, nonRecurringIndVal, nonRecurringAttributeId);
          
	logger.debug(insertComponentList.size());
          
    }
	
		public String getproductCd(String transactionComponentid){
	
	
			String productCd=null;
	
					List<Object[]> bundledList=getLegacyProductProduct(transactionComponentid);
					for(Object[] bundledProd:bundledList){
						if(null!=bundledProd[4]){
						productCd=bundledProd[4].toString();
						}else{
							productCd=bundledProd[2].toString();
						}
					
			}
			return productCd;
		}
		
		public List<Object[]> getInquireProduct(Long componentProductId,Long productDetailID){
			List<Object[]> monoProductList=	legacyProduct.findMappedProductforInquiryBlock(componentProductId.toString(), productDetailID.toString());
			if(monoProductList==null)
				monoProductList=	legacyProduct.findMappedProductforInquiryBlockForBundle(componentProductId.toString(), productDetailID.toString());
			return monoProductList;
		}
		public List<Object[]> getInquireProductByTrsnCmpId(String trnsCmpId){
			List<Object[]> monoProductList=	legacyProduct.getLegacyProductwithSource(trnsCmpId);
			if(monoProductList==null)
				monoProductList=	legacyProduct.getLegacyProductwithoutSource(trnsCmpId);
			if(monoProductList==null)
				monoProductList=	legacyProduct.getLegacyProductForBundle(trnsCmpId);
			return monoProductList;
		}
}
