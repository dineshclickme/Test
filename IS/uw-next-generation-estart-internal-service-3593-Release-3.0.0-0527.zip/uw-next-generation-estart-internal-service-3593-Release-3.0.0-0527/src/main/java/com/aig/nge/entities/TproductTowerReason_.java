package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-02-19T16:13:04.085+0530")
@StaticMetamodel(TproductTowerReason.class)
public class TproductTowerReason_ {
	public static volatile SingularAttribute<TproductTowerReason, TproductTowerReasonPK> id;
	public static volatile SingularAttribute<TproductTowerReason, Timestamp> createTs;
	public static volatile SingularAttribute<TproductTowerReason, String> createUserId;
	public static volatile SingularAttribute<TproductTowerReason, String> deletedIn;
	public static volatile SingularAttribute<TproductTowerReason, Timestamp> updateTs;
	public static volatile SingularAttribute<TproductTowerReason, String> updateUserId;
	public static volatile SingularAttribute<TproductTowerReason, TproductTower> tproductTower;
	public static volatile SingularAttribute<TproductTowerReason, Treason> treason;
}
