package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the TPRDCT_TWR_TUW_SBPRDCT_AST_TYP database table.
 * 
 */
@Embeddable
public class TprdctTwrTuwSbprdctAstTypPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="PRODUCT_TOWER_ID")
	private short productTowerId;

	@Column(name="TUW_SUB_PRODUCT_ID")
	private int tuwSubProductId;

	@Column(name="ASSET_TYPE_ID")
	private int assetTypeId;
	
	public TprdctTwrTuwSbprdctAstTypPK() {
    }
	public short getProductTowerId() {
		return this.productTowerId;
	}
	public void setProductTowerId(short productTowerId) {
		this.productTowerId = productTowerId;
	}
	public int getTuwSubProductId() {
		return this.tuwSubProductId;
	}
	public void setTuwSubProductId(int tuwSubProductId) {
		this.tuwSubProductId = tuwSubProductId;
	}
	public int getAssetTypeId() {
		return this.assetTypeId;
	}
	public void setAssetTypeId(int assetTypeId) {
		this.assetTypeId = assetTypeId;
	}
	
	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof TprdctTwrTuwSbprdctAstTypPK)) {
			return false;
		}
		TprdctTwrTuwSbprdctAstTypPK castOther = (TprdctTwrTuwSbprdctAstTypPK)other;
		return 
			(this.productTowerId == castOther.productTowerId)
			&& (this.tuwSubProductId == castOther.tuwSubProductId)
			&& (this.assetTypeId == castOther.assetTypeId);

    }
    
	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + ((int) this.productTowerId);
		hash = hash * prime + this.tuwSubProductId;
		hash = hash * prime + this.assetTypeId;
		
		return hash;
    }
}