package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SetAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-02-19T16:13:03.458+0530")
@StaticMetamodel(Tformat.class)
public class Tformat_ {
	public static volatile SingularAttribute<Tformat, Short> formatId;
	public static volatile SingularAttribute<Tformat, Timestamp> createTs;
	public static volatile SingularAttribute<Tformat, String> createUserId;
	public static volatile SingularAttribute<Tformat, String> formatDs;
	public static volatile SingularAttribute<Tformat, String> formatVal;
	public static volatile SingularAttribute<Tformat, Timestamp> updateTs;
	public static volatile SingularAttribute<Tformat, String> updateUserId;
	public static volatile SetAttribute<Tformat, TuserPrefernce> tuserPrefernces1;
	public static volatile SetAttribute<Tformat, TuserPrefernce> tuserPrefernces2;
}
