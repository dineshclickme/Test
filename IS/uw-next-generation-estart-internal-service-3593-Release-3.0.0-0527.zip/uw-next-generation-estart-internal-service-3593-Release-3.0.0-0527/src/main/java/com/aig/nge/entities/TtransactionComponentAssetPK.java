package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the TTRANSACTION_COMPONENT_ASSET database table.
 * 
 */
@Embeddable
public class TtransactionComponentAssetPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="TRANSACTION_COMPONENT_ID")
	private String transactionComponentId;

	@Column(name="ASSET_ID")
	private int assetId;

    public TtransactionComponentAssetPK() {
    }
	public String getTransactionComponentId() {
		return this.transactionComponentId;
	}
	public void setTransactionComponentId(String transactionComponentId) {
		this.transactionComponentId = transactionComponentId;
	}
	public int getAssetId() {
		return this.assetId;
	}
	public void setAssetId(int assetId) {
		this.assetId = assetId;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof TtransactionComponentAssetPK)) {
			return false;
		}
		TtransactionComponentAssetPK castOther = (TtransactionComponentAssetPK)other;
		return 
			this.transactionComponentId.equals(castOther.transactionComponentId)
			&& (this.assetId == castOther.assetId);

    }
    
	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.transactionComponentId.hashCode();
		hash = hash * prime + this.assetId;
		
		return hash;
    }
}