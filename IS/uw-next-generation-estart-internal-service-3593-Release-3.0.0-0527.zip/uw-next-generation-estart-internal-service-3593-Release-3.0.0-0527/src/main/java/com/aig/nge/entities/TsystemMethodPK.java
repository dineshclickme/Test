package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the TSYSTEM_METHOD database table.
 * 
 */
@Embeddable
public class TsystemMethodPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="SYSTEM_ID")
	private short systemId;

	@Column(name="METHOD_ID")
	private short methodId;

    public TsystemMethodPK() {
    }
	public short getSystemId() {
		return this.systemId;
	}
	public void setSystemId(short systemId) {
		this.systemId = systemId;
	}
	public short getMethodId() {
		return this.methodId;
	}
	public void setMethodId(short methodId) {
		this.methodId = methodId;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof TsystemMethodPK)) {
			return false;
		}
		TsystemMethodPK castOther = (TsystemMethodPK)other;
		return 
			(this.systemId == castOther.systemId)
			&& (this.methodId == castOther.methodId);

    }
    
	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + ((int) this.systemId);
		hash = hash * prime + ((int) this.methodId);
		
		return hash;
    }
}