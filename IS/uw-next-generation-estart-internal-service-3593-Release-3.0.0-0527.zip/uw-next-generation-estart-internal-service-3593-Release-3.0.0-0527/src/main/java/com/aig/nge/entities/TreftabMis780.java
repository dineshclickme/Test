package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;

import java.sql.Timestamp;
import java.util.Date;


/**
 * The persistent class for the TREFTAB_MIS780 database table.
 * 
 */
@Entity
@Table(name="TREFTAB_MIS780")
public class TreftabMis780 implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name="DELETED_IN")
	private String deletedIn;

	@Column(name="MIS780_ARTS_CO_IND")
	private short mis780ArtsCoInd;

	@Column(name="MIS780_ASCO_CODE")
	private String mis780AscoCode;

	@Column(name="MIS780_ASCO_NAME")
	private String mis780AscoName;

	@Id
	@Column(name="MIS780_COMP_CODE")
	private short mis780CompCode;

	@Column(name="MIS780_COMP_NAME")
	private String mis780CompName;

    @Temporal( TemporalType.DATE)
	@Column(name="MIS780_EFF_DT")
	private Date mis780EffDt;

    @Temporal( TemporalType.DATE)
	@Column(name="MIS780_EXP_DT")
	private Date mis780ExpDt;

	@Column(name="MIS780_SOURCE")
	private String mis780Source;

	@Column(name="MIS780_STATE_NM")
	private String mis780StateNm;

	@Column(name="MIS780_UPD_TMP")
	private Timestamp mis780UpdTmp;

	@Column(name="MIS780_UPD_USER")
	private String mis780UpdUser;

	@Column(name="MIS780_VALID_IND")
	private short mis780ValidInd;

    public TreftabMis780() {
    }

	public String getDeletedIn() {
		return this.deletedIn;
	}

	public void setDeletedIn(String deletedIn) {
		this.deletedIn = deletedIn;
	}

	public short getMis780ArtsCoInd() {
		return this.mis780ArtsCoInd;
	}

	public void setMis780ArtsCoInd(short mis780ArtsCoInd) {
		this.mis780ArtsCoInd = mis780ArtsCoInd;
	}

	public String getMis780AscoCode() {
		if(this.mis780AscoCode != null)
			return this.mis780AscoCode.trim();
		else
			return this.mis780AscoCode;
	}

	public void setMis780AscoCode(String mis780AscoCode) {
		this.mis780AscoCode = mis780AscoCode;
	}

	public String getMis780AscoName() {
		if(this.mis780AscoName != null)
			return this.mis780AscoName.trim();
		else
			return this.mis780AscoName;
	}

	public void setMis780AscoName(String mis780AscoName) {
		this.mis780AscoName = mis780AscoName;
	}

	public short getMis780CompCode() {
		return this.mis780CompCode;
	}

	public void setMis780CompCode(short mis780CompCode) {
		this.mis780CompCode = mis780CompCode;
	}

	public String getMis780CompName() {
		if(this.mis780CompName != null)
			return this.mis780CompName.trim();
		else
			return this.mis780CompName;
	}

	public void setMis780CompName(String mis780CompName) {
		this.mis780CompName = mis780CompName;
	}

	public Date getMis780EffDt() {
		return this.mis780EffDt;
	}

	public void setMis780EffDt(Date mis780EffDt) {
		this.mis780EffDt = mis780EffDt;
	}

	public Date getMis780ExpDt() {
		return this.mis780ExpDt;
	}

	public void setMis780ExpDt(Date mis780ExpDt) {
		this.mis780ExpDt = mis780ExpDt;
	}

	public String getMis780Source() {
		if(this.mis780Source != null)
			return this.mis780Source.trim();
		else
			return this.mis780Source;
	}

	public void setMis780Source(String mis780Source) {
		this.mis780Source = mis780Source;
	}

	public String getMis780StateNm() {
		if(this.mis780StateNm != null)
			return this.mis780StateNm.trim();
		else
			return this.mis780StateNm;
	}

	public void setMis780StateNm(String mis780StateNm) {
		this.mis780StateNm = mis780StateNm;
	}

	public Timestamp getMis780UpdTmp() {
		return this.mis780UpdTmp;
	}

	public void setMis780UpdTmp(Timestamp mis780UpdTmp) {
		this.mis780UpdTmp = mis780UpdTmp;
	}

	public String getMis780UpdUser() {
		if(this.mis780UpdUser != null )
			return this.mis780UpdUser.trim();
		else
			return this.mis780UpdUser;
	}

	public void setMis780UpdUser(String mis780UpdUser) {
		this.mis780UpdUser = mis780UpdUser;
	}

	public short getMis780ValidInd() {
		return this.mis780ValidInd;
	}

	public void setMis780ValidInd(short mis780ValidInd) {
		this.mis780ValidInd = mis780ValidInd;
	}

}