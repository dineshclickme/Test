package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Date;


/**
 * The persistent class for the TSOLR_EXTRACT_LOOKUP database table.
 * 
 */
@Entity
@Table(name="TSOLR_EXTRACT_LOOKUP")
public class TsolrExtractLookup implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="SOLR_EXTRACT_ID")
	private short solrExtractId;

	@Column(name="ACCOUNT_CD")
	private String accountCd;

	@Column(name="ACCOUNT_NM")
	private String accountNm;

	@Column(name="COMPONENT_PRODUCT_CD")
	private String componentProductCd;

	@Column(name="COMPONENT_PRODUCT_DELETED_IN")
	private String componentProductDeletedIn;

	@Column(name="COMPONENT_PRODUCT_NM")
	private String componentProductNm;

	@Column(name="CREATE_TS")
	private Timestamp createTs;

	@Column(name="CREATE_USER_ID")
	private String createUserId;

	@Column(name="CREDITED_BRANCH_CNTRY_NM")
	private String creditedBranchCntryNm;

	@Column(name="CREDITED_BRANCH_NM")
	private String creditedBranchNm;

	@Column(name="DIVISION_NM")
	private String divisionNm;

	@Column(name="DIVISION_NO")
	private short divisionNo;

	@Column(name="MARKETABLE_PRODUCT_CD")
	private String marketableProductCd;

	@Column(name="MARKETABLE_PRODUCT_NM")
	private String marketableProductNm;

	@Column(name="PRODUCT_STATUS_DS")
	private String productStatusDs;

    @Temporal( TemporalType.DATE)
	@Column(name="PRODUCT_STATUS_DT")
	private Date productStatusDt;

	@Column(name="PRODUCT_TOWER_DIVISION_ID")
	private short productTowerDivisionId;

	@Column(name="RESERVATION_STATUS_DS")
	private String reservationStatusDs;

	@Column(name="SEGMENT_NM")
	private String segmentNm;

	@Column(name="SUB_SEGMENT_NM")
	private String subSegmentNm;

    @Temporal( TemporalType.DATE)
	@Column(name="SUBMISSION_CREATED_DT")
	private Date submissionCreatedDt;

	@Column(name="SUBMISSION_NO")
	private Object submissionNo;

	@Column(name="TRANSACTION_COMPONENT_ID")
	private Object transactionComponentId;

	@Column(name="TRANSACTION_ID")
	private Object transactionId;

	@Column(name="UNDERWRITER_ID")
	private int underwriterId;

	@Column(name="UNDERWRITER_NM")
	private String underwriterNm;

	@Column(name="UPDATE_TS")
	private Timestamp updateTs;

	@Column(name="UPDATE_USER_ID")
	private String updateUserId;

	@Column(name="VERSION_SQN")
	private short versionSqn;

    public TsolrExtractLookup() {
    }

	public short getSolrExtractId() {
		return this.solrExtractId;
	}

	public void setSolrExtractId(short solrExtractId) {
		this.solrExtractId = solrExtractId;
	}

	public String getAccountCd() {
		return this.accountCd;
	}

	public void setAccountCd(String accountCd) {
		this.accountCd = accountCd;
	}

	public String getAccountNm() {
		return this.accountNm;
	}

	public void setAccountNm(String accountNm) {
		this.accountNm = accountNm;
	}

	public String getComponentProductCd() {
		return this.componentProductCd;
	}

	public void setComponentProductCd(String componentProductCd) {
		this.componentProductCd = componentProductCd;
	}

	public String getComponentProductDeletedIn() {
		return this.componentProductDeletedIn;
	}

	public void setComponentProductDeletedIn(String componentProductDeletedIn) {
		this.componentProductDeletedIn = componentProductDeletedIn;
	}

	public String getComponentProductNm() {
		return this.componentProductNm;
	}

	public void setComponentProductNm(String componentProductNm) {
		this.componentProductNm = componentProductNm;
	}

	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public String getCreditedBranchCntryNm() {
		return this.creditedBranchCntryNm;
	}

	public void setCreditedBranchCntryNm(String creditedBranchCntryNm) {
		this.creditedBranchCntryNm = creditedBranchCntryNm;
	}

	public String getCreditedBranchNm() {
		return this.creditedBranchNm;
	}

	public void setCreditedBranchNm(String creditedBranchNm) {
		this.creditedBranchNm = creditedBranchNm;
	}

	public String getDivisionNm() {
		return this.divisionNm;
	}

	public void setDivisionNm(String divisionNm) {
		this.divisionNm = divisionNm;
	}

	public short getDivisionNo() {
		return this.divisionNo;
	}

	public void setDivisionNo(short divisionNo) {
		this.divisionNo = divisionNo;
	}

	public String getMarketableProductCd() {
		return this.marketableProductCd;
	}

	public void setMarketableProductCd(String marketableProductCd) {
		this.marketableProductCd = marketableProductCd;
	}

	public String getMarketableProductNm() {
		return this.marketableProductNm;
	}

	public void setMarketableProductNm(String marketableProductNm) {
		this.marketableProductNm = marketableProductNm;
	}

	public String getProductStatusDs() {
		return this.productStatusDs;
	}

	public void setProductStatusDs(String productStatusDs) {
		this.productStatusDs = productStatusDs;
	}

	public Date getProductStatusDt() {
		return this.productStatusDt;
	}

	public void setProductStatusDt(Date productStatusDt) {
		this.productStatusDt = productStatusDt;
	}

	public short getProductTowerDivisionId() {
		return this.productTowerDivisionId;
	}

	public void setProductTowerDivisionId(short productTowerDivisionId) {
		this.productTowerDivisionId = productTowerDivisionId;
	}

	public String getReservationStatusDs() {
		return this.reservationStatusDs;
	}

	public void setReservationStatusDs(String reservationStatusDs) {
		this.reservationStatusDs = reservationStatusDs;
	}

	public String getSegmentNm() {
		return this.segmentNm;
	}

	public void setSegmentNm(String segmentNm) {
		this.segmentNm = segmentNm;
	}

	public String getSubSegmentNm() {
		return this.subSegmentNm;
	}

	public void setSubSegmentNm(String subSegmentNm) {
		this.subSegmentNm = subSegmentNm;
	}

	public Date getSubmissionCreatedDt() {
		return this.submissionCreatedDt;
	}

	public void setSubmissionCreatedDt(Date submissionCreatedDt) {
		this.submissionCreatedDt = submissionCreatedDt;
	}

	public Object getSubmissionNo() {
		return this.submissionNo;
	}

	public void setSubmissionNo(Object submissionNo) {
		this.submissionNo = submissionNo;
	}

	public Object getTransactionComponentId() {
		return this.transactionComponentId;
	}

	public void setTransactionComponentId(Object transactionComponentId) {
		this.transactionComponentId = transactionComponentId;
	}

	public Object getTransactionId() {
		return this.transactionId;
	}

	public void setTransactionId(Object transactionId) {
		this.transactionId = transactionId;
	}

	public int getUnderwriterId() {
		return this.underwriterId;
	}

	public void setUnderwriterId(int underwriterId) {
		this.underwriterId = underwriterId;
	}

	public String getUnderwriterNm() {
		return this.underwriterNm;
	}

	public void setUnderwriterNm(String underwriterNm) {
		this.underwriterNm = underwriterNm;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public short getVersionSqn() {
		return this.versionSqn;
	}

	public void setVersionSqn(short versionSqn) {
		this.versionSqn = versionSqn;
	}

}