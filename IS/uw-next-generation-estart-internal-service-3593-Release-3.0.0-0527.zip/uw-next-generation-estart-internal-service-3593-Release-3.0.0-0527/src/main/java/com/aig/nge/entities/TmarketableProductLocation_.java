package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2016-01-29T22:27:16.118+0530")
@StaticMetamodel(TmarketableProductLocation.class)
public class TmarketableProductLocation_ {
	public static volatile SingularAttribute<TmarketableProductLocation, TmarketableProductLocationPK> id;
	public static volatile SingularAttribute<TmarketableProductLocation, Timestamp> createTs;
	public static volatile SingularAttribute<TmarketableProductLocation, String> createUserId;
	public static volatile SingularAttribute<TmarketableProductLocation, String> deletedIn;
	public static volatile SingularAttribute<TmarketableProductLocation, Timestamp> updateTs;
	public static volatile SingularAttribute<TmarketableProductLocation, String> updateUserId;
	public static volatile SingularAttribute<TmarketableProductLocation, Tlocation> tlocation;
	public static volatile SingularAttribute<TmarketableProductLocation, TmarketableProduct> tmarketableProduct;
}
