package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-02-24T11:59:49.670+0530")
@StaticMetamodel(TextractAttribute.class)
public class TextractAttribute_ {
	public static volatile SingularAttribute<TextractAttribute, TextractAttributePK> id;
	public static volatile SingularAttribute<TextractAttribute, Timestamp> createTs;
	public static volatile SingularAttribute<TextractAttribute, String> createUserId;
	public static volatile SingularAttribute<TextractAttribute, String> labelNm;
	public static volatile SingularAttribute<TextractAttribute, Timestamp> updateTs;
	public static volatile SingularAttribute<TextractAttribute, String> updateUserId;
	public static volatile SingularAttribute<TextractAttribute, Tattribute> tattribute;
	public static volatile SingularAttribute<TextractAttribute, Textract> textract;
}
