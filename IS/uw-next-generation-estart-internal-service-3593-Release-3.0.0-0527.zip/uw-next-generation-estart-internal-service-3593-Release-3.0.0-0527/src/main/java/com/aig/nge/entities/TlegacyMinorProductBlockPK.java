package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the TLEGACY_MINOR_PRODUCT_BLOCK database table.
 * 
 */
@Embeddable
public class TlegacyMinorProductBlockPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="PRODUCT_CD")
	private String productCd;

	@Column(name="MJR_PRODUCT_GRP_CD")
	private short mjrProductGrpCd;

	@Column(name="MNR_PRODUCT_GRP_CD")
	private short mnrProductGrpCd;

    public TlegacyMinorProductBlockPK() {
    }
	public String getProductCd() {
		return this.productCd;
	}
	public void setProductCd(String productCd) {
		this.productCd = productCd;
	}
	public short getMjrProductGrpCd() {
		return this.mjrProductGrpCd;
	}
	public void setMjrProductGrpCd(short mjrProductGrpCd) {
		this.mjrProductGrpCd = mjrProductGrpCd;
	}
	public short getMnrProductGrpCd() {
		return this.mnrProductGrpCd;
	}
	public void setMnrProductGrpCd(short mnrProductGrpCd) {
		this.mnrProductGrpCd = mnrProductGrpCd;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof TlegacyMinorProductBlockPK)) {
			return false;
		}
		TlegacyMinorProductBlockPK castOther = (TlegacyMinorProductBlockPK)other;
		return 
			this.productCd.equals(castOther.productCd)
			&& (this.mjrProductGrpCd == castOther.mjrProductGrpCd)
			&& (this.mnrProductGrpCd == castOther.mnrProductGrpCd);

    }
    
	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.productCd.hashCode();
		hash = hash * prime + ((int) this.mjrProductGrpCd);
		hash = hash * prime + ((int) this.mnrProductGrpCd);
		
		return hash;
    }
}