package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;

import org.apache.openjpa.persistence.DataCache;
import java.sql.Timestamp;


/**
 * The persistent class for the TSTATUS_REASON_TYPE database table.
 * 
 */
@Entity
@DataCache
@Table(name="TSTATUS_REASON_TYPE")
public class TstatusReasonType implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private TstatusReasonTypePK id;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="CREATE_TS")
	private Timestamp createTs;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="CREATE_USER_ID")
	private String createUserId;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="UPDATE_TS")
	private Timestamp updateTs;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="UPDATE_USER_ID")
	private String updateUserId;

	//bi-directional many-to-one association to TreasonType
	@ManyToOne
	@JoinColumn(name="REASON_TYPE_ID")
	private TreasonType treasonType;

	//bi-directional many-to-one association to Tstatus
	@ManyToOne
	@JoinColumn(name="STATUS_ID")
	private Tstatus tstatus;

    public TstatusReasonType() {
    }

	public TstatusReasonTypePK getId() {
		return this.id;
	}

	public void setId(TstatusReasonTypePK id) {
		this.id = id;
	}
	
	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public TreasonType getTreasonType() {
		return this.treasonType;
	}

	public void setTreasonType(TreasonType treasonType) {
		this.treasonType = treasonType;
	}
	
	public Tstatus getTstatus() {
		return this.tstatus;
	}

	public void setTstatus(Tstatus tstatus) {
		this.tstatus = tstatus;
	}
	
}