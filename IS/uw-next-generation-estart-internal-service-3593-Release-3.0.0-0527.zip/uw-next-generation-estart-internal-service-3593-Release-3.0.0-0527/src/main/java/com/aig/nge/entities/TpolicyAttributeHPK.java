package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the TPOLICY_ATTRIBUTE_HS database table.
 * 
 */
@Embeddable
public class TpolicyAttributeHPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="POLICY_ID")
	private int policyId;

	@Column(name="ATTRIBUTE_ID")
	private short attributeId;

	@Column(name="ATTRIBUTE_SQN")
	private short attributeSqn;

    @Temporal( TemporalType.TIMESTAMP)
	@Column(name="CREATE_HISTORY_TS")
	private java.util.Date createHistoryTs;

    public TpolicyAttributeHPK() {
    }
	public int getPolicyId() {
		return this.policyId;
	}
	public void setPolicyId(int policyId) {
		this.policyId = policyId;
	}
	public short getAttributeId() {
		return this.attributeId;
	}
	public void setAttributeId(short attributeId) {
		this.attributeId = attributeId;
	}
	public short getAttributeSqn() {
		return this.attributeSqn;
	}
	public void setAttributeSqn(short attributeSqn) {
		this.attributeSqn = attributeSqn;
	}
	public java.util.Date getCreateHistoryTs() {
		return this.createHistoryTs;
	}
	public void setCreateHistoryTs(java.util.Date createHistoryTs) {
		this.createHistoryTs = createHistoryTs;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof TpolicyAttributeHPK)) {
			return false;
		}
		TpolicyAttributeHPK castOther = (TpolicyAttributeHPK)other;
		return 
			(this.policyId == castOther.policyId)
			&& (this.attributeId == castOther.attributeId)
			&& (this.attributeSqn == castOther.attributeSqn)
			&& this.createHistoryTs.equals(castOther.createHistoryTs);

    }
    
	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.policyId;
		hash = hash * prime + ((int) this.attributeId);
		hash = hash * prime + ((int) this.attributeSqn);
		hash = hash * prime + this.createHistoryTs.hashCode();
		
		return hash;
    }
}