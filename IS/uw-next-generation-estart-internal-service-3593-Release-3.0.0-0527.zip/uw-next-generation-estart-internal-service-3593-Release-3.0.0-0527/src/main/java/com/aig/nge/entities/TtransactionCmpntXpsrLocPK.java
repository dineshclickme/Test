package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the TTRANSACTION_CMPNT_XPSR_LOC database table.
 * 
 */
@Embeddable
public class TtransactionCmpntXpsrLocPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="TRANSACTION_COMPONENT_ID")
	private String transactionComponentId;

	@Column(name="GEOGRAPHIC_LOCATION_ID")
	private int geographicLocationId;

    public TtransactionCmpntXpsrLocPK() {
    }
	public String getTransactionComponentId() {
		return this.transactionComponentId;
	}
	public void setTransactionComponentId(String transactionComponentId) {
		this.transactionComponentId = transactionComponentId;
	}
	public int getGeographicLocationId() {
		return this.geographicLocationId;
	}
	public void setGeographicLocationId(int geographicLocationId) {
		this.geographicLocationId = geographicLocationId;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof TtransactionCmpntXpsrLocPK)) {
			return false;
		}
		TtransactionCmpntXpsrLocPK castOther = (TtransactionCmpntXpsrLocPK)other;
		return 
			this.transactionComponentId.equals(castOther.transactionComponentId)
			&& (this.geographicLocationId == castOther.geographicLocationId);

    }
    
	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.transactionComponentId.hashCode();
		hash = hash * prime + this.geographicLocationId;
		
		return hash;
    }
}