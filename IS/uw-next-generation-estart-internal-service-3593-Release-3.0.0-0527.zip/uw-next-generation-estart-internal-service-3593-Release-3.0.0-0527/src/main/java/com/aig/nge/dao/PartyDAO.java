package com.aig.nge.dao;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.orm.jpa.JpaSystemException;
import org.springframework.stereotype.Repository;
//Userservice Impl to support legacy -starts
import com.aig.nge.entities.Tuser;
import com.aig.nge.entities.TuserType;
import com.aig.nge.entities.TuserStatus;
import com.aig.nge.repository.TUserStatusRepository;
import com.aig.nge.repository.TLocationRepository;
import com.aig.nge.repository.TUserRepository;
import com.aig.nge.repository.TUserTypeRepository;
//Userservice Impl to support legacy -ends

import com.aig.nge.entities.Taccount;
import com.aig.nge.entities.Tagent;
import com.aig.nge.entities.Tlocation;
import com.aig.nge.entities.TmailingAddress;
import com.aig.nge.entities.Tparty;
//import com.aig.nge.entities.TpartyAction;
import com.aig.nge.entities.TpartyDetail;
import com.aig.nge.entities.TpartyProcessing;
import com.aig.nge.entities.TpartyRelationType;
import com.aig.nge.entities.TpartyType;
import com.aig.nge.entities.Tproducer;
import com.aig.nge.entities.TproducerContact;
import com.aig.nge.entities.TproducerContactPK;
import com.aig.nge.entities.TrelatedParty;
import com.aig.nge.entities.TrelatedPartyPK;
import com.aig.nge.entities.TshellAccount;
import com.aig.nge.entities.Ttransaction;
import com.aig.nge.entities.TtransactionComponentParty;
import com.aig.nge.entities.TtransactionParty;
import com.aig.nge.repository.TAccountRepository;
import com.aig.nge.repository.TAgentRepository;
import com.aig.nge.repository.TMailingAddressRepository;
//import com.aig.nge.repository.TPartyActionRepository;
import com.aig.nge.repository.TPartyDetailsRepository;
import com.aig.nge.repository.TPartyProcessingRepository;
import com.aig.nge.repository.TPartyRelationTypeRepository;
import com.aig.nge.repository.TPartyRepository;
import com.aig.nge.repository.TPartyTypeRepository;
import com.aig.nge.repository.TProducerContactRepository;
import com.aig.nge.repository.TProducerRepository;
import com.aig.nge.repository.TRelatedPartyRepository;
import com.aig.nge.repository.TShellAccountRepository;
import com.aig.nge.repository.TTransactionComponentPartyRepository;
import com.aig.nge.repository.TTransactionPartyHRepository;
import com.aig.nge.repository.TTransactionPartyRepository;
import com.aig.nge.utilities.AIGCIExceptionMsg;
import com.aig.nge.utilities.NGEConstants;
import com.aig.nge.utilities.NGEDateUtil;
import com.aig.nge.utilities.NGEErrorCodes;
import com.aig.nge.utilities.NGESession;
import com.aig.nge.wsdl.skeleton.Address;
import com.aig.nge.wsdl.skeleton.Broker;
import com.aig.nge.wsdl.skeleton.ResponseHeader;
import com.aig.nge.wsdl.skeleton.ServiceResponseContext;
import com.aig.nge.wsdl.skeleton.StatusCategoryType;
import com.aig.nge.wsdl.skeleton.StatusType;
import com.aig.nge.wsdl.skeleton.TransactionDataResponseHeader;
import com.aig.nge.model.UserRespData;
import com.aig.nge.dao.LocationDAO;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * @author DineshKumar This DAO class is used accessing the Party related
 *         repositories Used repositories are :
 *         TPartyRepository,TaccountRepository,TproducerRepository,
 *         TPartyTypeRepository TshellAccountRepository, TrelatedPartyRepository
 */
@Repository
public class PartyDAO extends BaseDAO {

	private static final Logger logger = LogManager.getLogger(PartyDAO.class);
	@Autowired
	private TPartyRepository partyRepository;
	@Autowired
	private TAgentRepository agentRepository;
	@Autowired
	private TAccountRepository accountRepository;
	@Autowired
	private TProducerRepository producerRepository;
	@Autowired
	private TPartyTypeRepository partytypeRepository;
	@Autowired
	private TShellAccountRepository shellAccountRepository;
	@Autowired
	private TRelatedPartyRepository relatedPartyRepository;
	/*@Autowired
	private SequenceNumberGeneration sequenceNumberGeneration;*/
	@Autowired
	TPartyRelationTypeRepository  relationTypeRepository;
	@Autowired
	TTransactionPartyRepository transactionPartyRepository;
	@Autowired
	TTransactionPartyHRepository transactionPartyHRepository;
	@Autowired
	private TPartyProcessingRepository tPartyProcessingRepository;
/*	@Autowired
	private TPartyActionRepository tPartyActionRepository;*/
	@Autowired
	private LocationDAO tlocationDAO;
	@Autowired
	private TAgentRepository tAgentRepository;
	@Autowired
	private TMailingAddressRepository tMailingAddressRepository;
	@Autowired
	private TRelatedPartyRepository trelatedPartyRepository;
	
	@Autowired
	private TPartyDetailsRepository tPartyDetailsRepository;
	
	@Autowired
	private TProducerContactRepository tProducerContactRepository;
	
	@Autowired
	private TTransactionComponentPartyRepository tTransactionComponentPartyRepository;
	//Userservice Impl to support legacy
	@Autowired
	private TUserRepository tUserRepository ;
	@Autowired
	private TUserTypeRepository tUserTypeRepository ;
	@Autowired
	private TUserStatusRepository tUserStatusRepository ;
	@Autowired
	private TLocationRepository tLocationRepository;
	
	@Autowired
	private TUserRepository userRepository;
	
	/**
	 * @param partyNo
	 * @param partyTypeName
	 * @param userId
	 * @return
	 * @throws JpaSystemException
	 *             This method used to save the Party details
	 * @throws AIGCIExceptionMsg 
	 */
	public Tparty createParty(Object partyNo, String partyTypeName) throws JpaSystemException, AIGCIExceptionMsg {
		Tparty partyData = null;

		List<Tparty> partyRecord = new ArrayList<Tparty>();
		TpartyType partyTypeData = null;
		List<TpartyType> partyTypeRecord = partytypeRepository
				.findByPartyTypeNm(partyTypeName.toUpperCase());

		if (partyTypeRecord.size() == 1) {
            partyTypeData = partyTypeRecord.get(0);
		}else if (partyTypeRecord.size() == 0){
            ngeException.throwException(NGEErrorCodes.NO_PARTY_TYPE, NGEErrorCodes.ERROR_TYPE, null,null);
		}else{
            ngeException.throwException(NGEErrorCodes.DUPLICATE_PARTY_TYPE, NGEErrorCodes.ERROR_TYPE, null,null);
		}
		// int partyId=partyRepository.getMaxPartyId()+1;
		//int partyId = getPartyIdSequence();
		
		partyData = populateParty(partyNo.toString(), partyTypeData);
		partyRecord.add(partyData);
		partyRecord = partyRepository.save(partyRecord);

		if (partyRecord.size() > 0) {
			partyData = partyRecord.get(0);

		}

		return partyData;
	}
	//Userservice Impl to support legacy

		public TpartyDetail createPartyDetails(int partyId,UserRespData userResp1,String locationtype) throws JpaSystemException, AIGCIExceptionMsg {
		
					
		TpartyDetail partyDetailData = null;
		
		List<TpartyDetail> partyDetailRecord = new ArrayList<TpartyDetail>();
		
		String  countryCode=userResp1.getCountryCode();
		
			
		Tlocation locationRecord =null;
		
		if(! countryCode.equalsIgnoreCase(NGEConstants.COMMA_SYMBOL) && !countryCode.trim().isEmpty() )
		{
		locationRecord = tLocationRepository.getCountryByAlternateLocationCd(countryCode, locationtype);
		
		if(locationRecord== null )
		{
			locationRecord=tlocationDAO.findLocationByCountryCd(countryCode, locationtype);
		}
		}
		
		else 
		{
			locationRecord=tlocationDAO.findLocationByCountryCd(NGEConstants.LocationCode.UNKNOWN, locationtype);
		}
		
		partyDetailData = populatePartyDetail(partyId,userResp1.getLocation(),locationRecord);
		
		/* Exadata changes - Not null issue starts */
		
		if(partyDetailData.getAddress2Tx() != null){
			if(partyDetailData.getAddress2Tx().trim().equals(NGEConstants.EMPTY_STRING))
				partyDetailData.setAddress2Tx(NGEConstants.EMPTY_SPACE);
		}
		
		if(partyDetailData.getAddress3Tx() != null){
			if(partyDetailData.getAddress3Tx().trim().equals(NGEConstants.EMPTY_STRING))
				partyDetailData.setAddress3Tx(NGEConstants.EMPTY_SPACE);
		}
		
		if(partyDetailData.getCountyNm() != null){
			if(partyDetailData.getCountyNm().trim().equals(NGEConstants.EMPTY_STRING))
				partyDetailData.setCountyNm(NGEConstants.EMPTY_SPACE);
		}
		
		if(partyDetailData.getPostalCd() != null){
			if(partyDetailData.getPostalCd().trim().equals(NGEConstants.EMPTY_STRING))
				partyDetailData.setPostalCd(NGEConstants.EMPTY_SPACE);
		}
		
		if(partyDetailData.getStateCd() != null){
			if(partyDetailData.getStateCd().trim().equals(NGEConstants.EMPTY_STRING))
				partyDetailData.setStateCd(NGEConstants.EMPTY_SPACE);
		}
		
		/* Exadata changes - Not null issue ends */
		
		partyDetailRecord.add(partyDetailData);
		
		partyDetailRecord = tPartyDetailsRepository.save(partyDetailRecord);
		
		if (partyDetailRecord.size() > 0) {
			partyDetailData = partyDetailRecord.get(0);
		}
		return partyDetailData;
	}

	public Tuser createUser(int partyid,UserRespData userResp1,String userTypeName ) throws JpaSystemException, AIGCIExceptionMsg {
		
	
		String userstatus=userResp1.getUserstatus();
		Tuser userData = null;
		List<Tuser> userRecord = new ArrayList<Tuser>();
		
		TuserType userTypeData = null;
		List<TuserType> userTypeRecord = tUserTypeRepository.findByUserTypeNm(userTypeName.toUpperCase());

		if (userTypeRecord.size() == 1) {
            userTypeData = userTypeRecord.get(0);
		}
		else if (userTypeRecord.size() == 0){
            ngeException.throwException(NGEErrorCodes.NO_USER_TYPE , NGEErrorCodes.ERROR_TYPE, null,null);
		}else{
            ngeException.throwException(NGEErrorCodes.DUPLICATE_USER_TYPE, NGEErrorCodes.ERROR_TYPE, null,null);
		}	
		
		TuserStatus userStatusData = null;
		List<TuserStatus> userStatusRecord = tUserStatusRepository.findByStatusDs(userstatus.toUpperCase());

		if (userStatusRecord.size() == 1) {
			userStatusData = userStatusRecord.get(0);
		}
		else if (userStatusRecord.size() == 0){
            ngeException.throwException(NGEErrorCodes.NO_USER_TYPE , NGEErrorCodes.ERROR_TYPE, null,null);//add error
		}else{
            ngeException.throwException(NGEErrorCodes.DUPLICATE_PARTY_TYPE, NGEErrorCodes.ERROR_TYPE, null,null);//add error
		}			
		userData = populateUser(partyid,userResp1,userTypeData,userStatusData);
		
		/* Exadata changes - Not null issue starts */
		if(userData.getMiddleNm() != null){
			if(userData.getMiddleNm().trim().equals(NGEConstants.EMPTY_STRING))
				userData.setMiddleNm(NGEConstants.EMPTY_SPACE);
		}
		/* Exadata changes - Not null issue ends */
		userRecord.add(userData);
		userRecord = tUserRepository.save(userRecord);
		
		if (userRecord.size() > 0) {
			userData = userRecord.get(0);
		}
		return userData;
	}

	
    public Tagent getAgent(int partyId){
    	Tagent agent=new Tagent();
    	agent=tAgentRepository.findOne(partyId);
    	return agent;
    }
	
	/**
	 * @param partyId
	 * @param organisationName
	 * @param userId
	 * @return
	 * @throws JpaSystemException
	 *             This method is used to save the Shell account details.
	 */
	public TshellAccount createShellAccount(int partyId,
			String organisationName, String multinationalIndicator) throws JpaSystemException {
		TshellAccount shellData = populateShellAccount(partyId,
				organisationName, multinationalIndicator);
		List<TshellAccount> shellRecord = new ArrayList<TshellAccount>();
		shellRecord.add(shellData);
		shellRecord = shellAccountRepository.save(shellRecord);

		if (shellRecord.size() > 0) {
			shellData = shellRecord.get(0);

		}
		return shellData;
	}

	/**
	 * @param partyId
	 * @param organisationName
	 * @param userId
	 * @return
	 * @throws JpaSystemException
	 *             This method is used to save the account details.
	 */
	public Taccount createAccount(int partyId, String organisationName, String multinationalInd) throws JpaSystemException {
		Taccount accoutnData = populateAccount(partyId, organisationName, multinationalInd);
		List<Taccount> accountRecord = new ArrayList<Taccount>();
		accountRecord.add(accoutnData);
		accountRecord = accountRepository.save(accountRecord);

		if (accountRecord.size() > 0) {
			accoutnData = accountRecord.get(0);

		}
		return accoutnData;
	}

	/**
	 * @param partyId
	 * @param organisationName
	 * @param userId
	 * @return
	 * @throws JpaSystemException
	 *             This method is used to save the Producer informations.
	 */
	public Tproducer createProducer(int partyId, String organisationName) throws JpaSystemException {
		Tproducer producerData = populateProducer(partyId, organisationName);
		List<Tproducer> producerRecord = new ArrayList<Tproducer>();
		producerRecord.add(producerData);
		producerRecord = producerRepository.save(producerRecord);

		if (producerRecord.size() > 0) {
			producerData = producerRecord.get(0);

		}
		return producerData;
	}

	public Tagent createAgent(int partyId,String firstNm, String middleNm, String lastNm) throws JpaSystemException
	{
		Tagent agentData=populateAgent(partyId,firstNm,middleNm,lastNm);
		List<Tagent> agentRecord = new ArrayList<Tagent>();	

		/* Exadata changes - Not null issue starts */
		
		if(agentData.getMiddleNm() != null){
			if(agentData.getMiddleNm().trim().equals(NGEConstants.EMPTY_STRING))
				agentData.setMiddleNm(NGEConstants.EMPTY_SPACE);
		}
		/* Exadata changes - Not null issue ends */
		agentRecord.add(agentData);
		agentRecord = agentRepository.save(agentRecord);
			 
		if (agentRecord.size() > 0) {
			agentData = agentRecord.get(0);
		
		} 
		return agentData;
	}

	/**
	 * @param parentOrUltimateAccountNo
	 * @param organisationName
	 * @param partyTypeName
	 * @param userId
	 * @param accountData
	 * @throws JpaSystemException
	 *             This method first check whether parent Or UltimateAccountNo
	 *             is available in TPARTY If not available in TPATY it will put
	 *             entry in TPARTY Then it will put entry in the TrelatedParty
	 * @throws AIGCIExceptionMsg 
	 */
	public void createRelatedParty(int parentOrUltimatePartyId,String partyTypeName,int partyId) throws JpaSystemException, AIGCIExceptionMsg {
		TpartyRelationType partyRelationTypeData=null;
		
		List<TpartyRelationType> relationType = relationTypeRepository.findByRelationTypeNm(partyTypeName.toUpperCase());
		
		if (relationType.size() == 0){
            ngeException.throwException(NGEErrorCodes.NO_PARTY_TYPE, NGEErrorCodes.ERROR_TYPE, null,null);
      }else if(relationType.size() > 1){
            ngeException.throwException(NGEErrorCodes.DUPLICATE_PARTY_TYPE, NGEErrorCodes.ERROR_TYPE, null,null);
      }		
				partyRelationTypeData = relationType.get(0);
				TrelatedParty relatedPartyData = populateRelatedParty(partyId,
						parentOrUltimatePartyId, partyRelationTypeData);
				relatedPartyRepository.save(relatedPartyData);				
		
			}	
	/**
	 * @param partyNo
	 * @param partyTypeName
	 * @return This method used for finding the party based on the given Party
	 *         Number and Party Type
	 * @throws AIGCIExceptionMsg 
	 */
	public Tparty getParty(Object partyNo, String partyTypeName)
			throws JpaSystemException, AIGCIExceptionMsg {

		Tparty partyData = null;
		//Exadata changes for avoiding duplicate records in tparty table
		partyData = partyRepository.findByPartyNoAndTpartyType(
				partyNo.toString().trim(), partyTypeName.toUpperCase());		
		return partyData;

	}
	
	/* 2021 MDM Changes - Starts */
	public TrelatedParty getRelatedPartyByMDMPartyID(String mdmPartyId, String partyTypeName) {
		TrelatedParty relatedParty = null;
		relatedParty = relatedPartyRepository.getRelatedPartyByMDMPartyID(mdmPartyId, partyTypeName.toUpperCase()); 
		return relatedParty;
	}
	
	public String getMDMPartyIdbyAccountNo(String partyNo, String partyTypeName) {
		String MDMPartyID = NGEConstants.EMPTY_STRING;
		MDMPartyID = relatedPartyRepository.getMDMPartyIdbyAccountNo(partyNo, partyTypeName.toUpperCase());
		return MDMPartyID;
	}
	
	public Tparty getMDMPartyRecord(Object partyNo, String partyTypeName)
			throws JpaSystemException, AIGCIExceptionMsg {
		Tparty partyData = null;
		partyData = partyRepository.getMDMPartyRecord(partyNo.toString().trim(), partyTypeName.toUpperCase());		
		return partyData;
	}
	
	public void createAccountMDMRelation(int accountID, int mdmPartyID, String partyTypeName) throws JpaSystemException, AIGCIExceptionMsg {
		TpartyRelationType partyRelationTypeData=null;
		List<TpartyRelationType> relationType = relationTypeRepository.findByRelationTypeNm(partyTypeName.toUpperCase());
		if (relationType.size() == 0){
			ngeException.throwException(NGEErrorCodes.NO_PARTY_TYPE, NGEErrorCodes.ERROR_TYPE, null,null);
		}else if(relationType.size() > 1){
			ngeException.throwException(NGEErrorCodes.DUPLICATE_PARTY_TYPE, NGEErrorCodes.ERROR_TYPE, null,null);
		}		
		partyRelationTypeData = relationType.get(0);
		TrelatedParty relatedPartyData = populateRelatedParty(accountID, mdmPartyID, partyRelationTypeData);
		relatedPartyRepository.save(relatedPartyData);
	}
	
	public void createRelationBetweenMDMs(int mdmPartyID, int relatedMDMPartyID, String partyTypeName) throws JpaSystemException, AIGCIExceptionMsg {
		TpartyRelationType partyRelationTypeData=null;
		List<TpartyRelationType> relationType = relationTypeRepository.findByRelationTypeNm(partyTypeName.toUpperCase());
		if (relationType.size() == 0){
			ngeException.throwException(NGEErrorCodes.NO_PARTY_TYPE, NGEErrorCodes.ERROR_TYPE, null,null);
		}else if(relationType.size() > 1){
			ngeException.throwException(NGEErrorCodes.DUPLICATE_PARTY_TYPE, NGEErrorCodes.ERROR_TYPE, null,null);
		}		
		partyRelationTypeData = relationType.get(0);
		TrelatedParty relatedPartyData = populateRelatedParty(mdmPartyID, relatedMDMPartyID, partyRelationTypeData);
		relatedPartyRepository.save(relatedPartyData);
	}
	
	public TrelatedParty getRelationBetweenMDMs(String mdmPartyId, String relatedMDMPartyId, String partyTypeName) {
		TrelatedParty relatedParty = null;
		relatedParty = relatedPartyRepository.getRelationBetweenMDMs(mdmPartyId, relatedMDMPartyId, partyTypeName.toUpperCase()); 
		return relatedParty;
	}
	/* 2021 MDM Changes - Ends */
	
	@Cacheable(value="PartyDAO.getUnderwriterParty", unless="#result == null")
	public Tparty getUnderwriterParty(Object partyNo, String partyTypeName)
			throws JpaSystemException, AIGCIExceptionMsg {

		return getParty(partyNo,partyTypeName);
	}
	
	@Cacheable(value="PartyDAO.getProducerOrAgentParty", unless="#result == null")
	public Tparty getProducerOrAgentParty(Object partyNo, String partyTypeName)
			throws JpaSystemException, AIGCIExceptionMsg {

		return getParty(partyNo,partyTypeName);
	}
	
	/*private int getPartyIdSequence() throws AIGCIExceptionMsg {
		int partyId = 0;
		HashMap<String, String> sequenceRequestMap = new HashMap<String, String>();
		HashMap<String, Object> sequenceValueMap = new HashMap<String, Object>();

		sequenceRequestMap.put(NGEConstants.Sequence.PARTY_ID, NGEConstants.DataType.INT);
		To be updated
		sequenceValueMap = sequenceNumberGeneration
				.getNextSequenceNumber(sequenceRequestMap);

		partyId = (Integer) sequenceValueMap.get(NGEConstants.Sequence.PARTY_ID);
		return partyId;
	}*/

	/**
	 * @param partyNo
	 * @param partyId
	 * @param partyType
	 * @param userId
	 * @return This method is used to populate the Tparty entity with the given
	 *         parameters
	 */
	public Tparty populateParty(String partyNo, 
			TpartyType partyType) {
		
		//Exadata changes for avoiding duplicate records in tparty table
		partyNo  = partyNo.trim();
		Tparty partyData = new Tparty();
		//partyData.setPartyId(partyId);
		partyData.setTpartyType(partyType);
		partyData.setPartyNo(partyNo);
		partyData.setCreateUserId(NGESession.getSessionData().getUserId());
		partyData.setCreateTs(NGEDateUtil.getTodayDate());

		return partyData;
	}
	//Userservice Impl to support legacy- starts

	public TpartyDetail populatePartyDetail(int partyId, String location,Tlocation locationRecord) {
		String countryName=locationRecord.getLocationNm();
		TpartyDetail partyDetailData = new TpartyDetail();
		//partyData.setPartyId(partyId);
		partyDetailData.setAddress1Tx(location);
		partyDetailData.setAddress2Tx(NGEConstants.COMMA_SYMBOL);
		partyDetailData.setAddress3Tx(NGEConstants.COMMA_SYMBOL);
		partyDetailData.setCityNm(location);
		partyDetailData.setStateCd(NGEConstants.COMMA_SYMBOL);
		partyDetailData.setPostalCd(NGEConstants.COMMA_SYMBOL);
		partyDetailData.setCountyNm(countryName);
		partyDetailData.setPartyId(partyId);
		partyDetailData.setTlocation(locationRecord);
		partyDetailData.setCreateUserId(NGESession.getSessionData().getUserId());
		partyDetailData.setCreateTs(NGEDateUtil.getTodayDate());

		return partyDetailData;
	}
	
public Tuser populateUser(int partyid,UserRespData userResp1, TuserType userTypeData, TuserStatus userStatusData) {
	
	String firstname=userResp1.getFirstName();
	String lastname=userResp1.getLastName();
	String middlename=userResp1.getMiddleName();
	String emailid=userResp1.getEmailId();
	String phoneno=userResp1.getPhonenumber();
	Tuser userData = new Tuser();
	userData.setFirstNm(firstname);
	userData.setMiddleNm(middlename);
	userData.setLastNm(lastname);
	userData.setEmailAddressTx(emailid);
	userData.setPhoneNo(phoneno);
	userData.setPartyId(partyid);
	userData.setTuserStatus(userStatusData);
	userData.setTuserType(userTypeData);
	userData.setCreateUserId(NGESession.getSessionData().getUserId());
	userData.setCreateTs(NGEDateUtil.getTodayDate());

		return userData;
	}
//Userservice Impl to support legacy -ends

	
	public Tagent populateInternationalAgent(int partyId, String firstNm, String lastNm)  {

		Tagent agentData = new Tagent();
		agentData.setPartyId(partyId);
		agentData.setFirstNm(firstNm);
		agentData.setLastNm(lastNm);
		agentData.setCreateTs(NGEDateUtil.getTodayDate());
		agentData.setCreateUserId(NGESession.getSessionData().getUserId());

		return agentData;

	}

	/**
	 * @param partyTypeName
	 * @return This method is used to populate the TpartyType entity with the
	 *         given parameters
	 */
	public TpartyType populatePartyType(String partyTypeName) {

		TpartyType partyTypeData = new TpartyType();
		partyTypeData.setPartyTypeNm(partyTypeName);
		return partyTypeData;

	}

	/**
	 * @param accountId
	 * @param accountName
	 * @param userId
	 * @return This method is used to populate the Taccount entity with the
	 *         given parameters
	 */
	public Taccount populateAccount(int accountId, String accountName, String multinationalInd) {
		Taccount accountData = new Taccount();
		accountData.setPartyId(accountId);
		accountData.setOrganizationNm(accountName);
		accountData.setMultinationalIn(multinationalInd);
		accountData.setCreateUserId(NGESession.getSessionData().getUserId());
		accountData.setCreateTs(NGEDateUtil.getTodayDate());
		return accountData;
	}

	/**
	 * @param accountId
	 * @param accountName
	 * @param userId
	 * @return This method is used to populate the TshellAccount entity with the
	 *         given parameters
	 */
	public TshellAccount populateShellAccount(int accountId, String accountName, String multinationalIndicator) {
		TshellAccount shellAccountData = new TshellAccount();
		shellAccountData.setPartyId(accountId);
		shellAccountData.setOrganizationNm(accountName);
		shellAccountData.setMultinationalIn(multinationalIndicator);
		shellAccountData.setCreateUserId(NGESession.getSessionData().getUserId());
		shellAccountData.setCreateTs(NGEDateUtil.getTodayDate());
		return shellAccountData;
	}

	/**
	 * @param producerId
	 * @param producerName
	 * @param userId
	 * @return This method is used to populate the Tproducer entity with the
	 *         given parameters
	 */
	public Tproducer populateProducer(int producerId, String producerName) {
		Tproducer producerData = new Tproducer();
		producerData.setPartyId(producerId);
		producerData.setOrganizationNm(producerName);
		producerData.setCreateUserId(NGESession.getSessionData().getUserId());
		producerData.setCreateTs(NGEDateUtil.getTodayDate());
		return producerData;
	}

	public Tagent populateAgent(int agentId, String firstNm, String middleNm, String lastNm) {
		Tagent agentData = new Tagent();
		agentData.setPartyId(agentId);
		agentData.setFirstNm(firstNm);
		agentData.setMiddleNm(middleNm);
		agentData.setLastNm(lastNm);
		agentData.setCreateTs(NGEDateUtil.getTodayDate());
		agentData.setCreateUserId(NGESession.getSessionData().getUserId());
		return agentData;
	}

	
	/**
	 * @param partyData
	 * @param relatedPartyData
	 * @param partyTypename
	 * @param userId
	 * @return This method is used to populate the TrelatedParty entity with the
	 *         given parameters
	 */
	public TrelatedParty populateRelatedParty(int partyId, int relatedPartyId,
			TpartyRelationType relationType) {
		TrelatedPartyPK trelatedPartyPK = new TrelatedPartyPK();
		TrelatedParty relatedData = new TrelatedParty();
		trelatedPartyPK.setPartyId(partyId);
		trelatedPartyPK.setRelatedPartyId(relatedPartyId);
		trelatedPartyPK.setRelationTypeId(relationType.getRelationTypeId());
		relatedData.setId(trelatedPartyPK);
		relatedData.setCreateUserId(NGESession.getSessionData().getUserId());
		relatedData.setCreateTs(NGEDateUtil.getTodayDate());
		return relatedData;
	}

	public TransactionDataResponseHeader populateHeader(
			StatusCategoryType statusCategoryType, String code, String messsage) {
		TransactionDataResponseHeader transactionDataResponseHeader = new TransactionDataResponseHeader();
		ResponseHeader responseHeader = new ResponseHeader();
		ServiceResponseContext serviceResponseContext = new ServiceResponseContext();
		StatusType statusType = new StatusType();

		statusType.setCategory(statusCategoryType);
		statusType.setCode(code);
		statusType.setStatusMessage(messsage);

		serviceResponseContext.setStatus(statusType);
		responseHeader.setServiceResponseContext(serviceResponseContext);
		transactionDataResponseHeader.setResponseHeader(responseHeader);

		return transactionDataResponseHeader;
	}

	
	
	public TmailingAddress populateAccountMailingAddress   (
			Address mailingAddress)throws AIGCIExceptionMsg {
		TmailingAddress tmailingAddress = null;
		if(mailingAddress!=null){
	   
	        	tmailingAddress = new TmailingAddress();
				Tlocation tlocationData = new Tlocation();
				List<Tlocation> locationList = null;
				String addressLine1=null;
				String addressLine2=null;
				String addressLine3=null;
				String cityNm =null;
				String stateCd =null;
				String postalCd = null;
				String mailingCountryCd=null;				
			//	int addressId=0;
			
				
	
			//	HashMap<String, String> sequenceIdList = new HashMap<String, String>();
			//    HashMap<String, Object> sequenceValueMap = new HashMap<String, Object>();
			//  	sequenceIdList.put(NGEConstants.Sequence.ADDRESS_ID,"INT");
			//	sequenceValueMap = sequenceNumberGeneration.getNextSequenceNumber(sequenceIdList);
			//	addressId = Integer.parseInt(sequenceValueMap.get(NGEConstants.Sequence.ADDRESS_ID).toString());
						
				addressLine1 = mailingAddress.getAddressLine1Tx();
				addressLine2 = mailingAddress.getAddressLine2Tx();
				addressLine3 = mailingAddress.getAddressLine3Tx();
				cityNm = mailingAddress.getCityNm();
				stateCd = mailingAddress.getStateCd();
				mailingCountryCd =mailingAddress.getCountryCd(); 				
				postalCd= mailingAddress.getZIPCd();
				
				locationList = tlocationDAO.getByCountryCdAndCountry(mailingCountryCd.toUpperCase());
				tlocationData = locationList.get(0);
				
				tmailingAddress.setAddress1Tx(addressLine1);
				tmailingAddress.setAddress2Tx(addressLine2);
				tmailingAddress.setAddress3Tx(addressLine3);
				tmailingAddress.setCityNm(cityNm);
				tmailingAddress.setStateCd(stateCd);
				tmailingAddress.setTlocation(tlocationData);
				tmailingAddress.setPostalCd(postalCd);
			//	tmailingAddress.setAddressId(addressId);				
				tmailingAddress.setCreateUserId(NGESession.getSessionData().getUserId());					
				tmailingAddress.setCreateTs(NGEDateUtil.getTodayDate());
				/* Exadata changes - Not null issue starts */
				
				if(tmailingAddress.getAddress2Tx()!= null){
					if(tmailingAddress.getAddress2Tx().trim().equals(NGEConstants.EMPTY_STRING))
							tmailingAddress.setAddress2Tx(NGEConstants.EMPTY_SPACE);
				}
				
				if(tmailingAddress.getAddress3Tx()!= null){
					if(tmailingAddress.getAddress3Tx().trim().equals(NGEConstants.EMPTY_STRING))
							tmailingAddress.setAddress3Tx(NGEConstants.EMPTY_SPACE);
				}
				
				if(tmailingAddress.getPostalCd()!= null){
					if(tmailingAddress.getPostalCd().trim().equals(NGEConstants.EMPTY_STRING))
							tmailingAddress.setPostalCd(NGEConstants.EMPTY_SPACE);
				}
				
				if(tmailingAddress.getStateCd()!= null){
					if(tmailingAddress.getStateCd().trim().equals(NGEConstants.EMPTY_STRING))
							tmailingAddress.setStateCd(NGEConstants.EMPTY_SPACE);
				}
				
				/* Exadata changes - Not null issue ends */
				
				tmailingAddress = tMailingAddressRepository.save(tmailingAddress);			
				}
			return tmailingAddress ;
		}

	public TproducerContact populateProducerContact(Broker producerContact,Ttransaction transactionData) throws AIGCIExceptionMsg {
		TproducerContact brokerData = null;
		if(producerContact!=null){
		    brokerData =new TproducerContact();
			Set<TproducerContact> producerContactData = new HashSet<TproducerContact>();
			TproducerContactPK producerContactPKData = new TproducerContactPK();
			short contactSqn = 0;
			
			String brokerFirstName = producerContact.getFirstNm();
			String brokerLastName = producerContact.getLastNm();
			String brokerPhoneNo = producerContact.getPhoneNo();
			String brokerEmailAddress = producerContact.getEmailAddress();
			String contactTx = producerContact.getCommentTx();
			
			/*HashMap<String, String> sequenceIdList = new HashMap<String, String>();
		    HashMap<String, Object> sequenceValueMap = new HashMap<String, Object>();
		  	sequenceIdList.put("Contact_ASQN","INT");
			sequenceValueMap = sequenceNumberGeneration.getNextSequenceNumber(sequenceIdList);
			contactSqn = (short) Integer.parseInt(sequenceValueMap.get("Contact_ASQN").toString());*/
			
			// Fetch the max Sequence available in DB
			//contactSqn = (short)findMaxProducerContactSequence(transactionData.getTransactionId());
			if(contactSqn == 0){
				contactSqn = 1;
			}
			else{
				contactSqn++;
			}			
			
		    producerContactPKData.setTransactionId(transactionData.getTransactionId());
			producerContactPKData.setContactSqn(contactSqn);
			
			brokerData.setId(producerContactPKData);
			brokerData.setFirstNm(brokerFirstName);
			brokerData.setLastNm(brokerLastName);
			brokerData.setPhoneNo(brokerPhoneNo);
			brokerData.setEmailAddressTx(brokerEmailAddress);
			brokerData.setContactTx(contactTx);
			brokerData.setCreateTs(NGEDateUtil.getTodayDate());
			brokerData.setCreateUserId(NGESession.getSessionData().getUserId());

			producerContactData.add(brokerData);
		}
			return brokerData;
	}
	
 	public Short findMaxProducerContactSequence(String transactionId)throws JpaSystemException{
 		Short maxSequenceNo = 0;
 		maxSequenceNo = tProducerContactRepository.findMaxProducerContactSequence(transactionId);
		 if(maxSequenceNo == null)
		 {
			 maxSequenceNo = 0;
		 }
 		return maxSequenceNo;
 	}
	
	
	public TtransactionParty getById(String transactionId,short versionNo,int partyId){
		
		/* 2021 MDM Changes - Starts */
		TtransactionParty transactionPartyData=transactionPartyRepository.findById(transactionId,versionNo,partyId, NGEConstants.NO);
		/* 2021 MDM Changes - Ends */
		
		return transactionPartyData;
	}
	
	public TtransactionParty savePartyData(TtransactionParty transactionPartyData){
		
		transactionPartyData = transactionPartyRepository.save(transactionPartyData);
		return transactionPartyData;
	}
	
	/**
	 * @author Dinesh Selvaraj
	 * @param partyID
	 * @return
	 * This method gives Tparty object for party id
	 */
	public Tparty getPartyByPartyID(int partyID) {
		Tparty tPartyData=null;
		logger.info("getPartyByPartyID is invoked for "+partyID);
		tPartyData=partyRepository.findOne(partyID);
		return tPartyData;

	}
	
	@Cacheable(value="PartyDAO.getPartyByPartyIDForUnderwriter", unless="#result == null")
	public Tparty getPartyByPartyIDForUnderwriter(int partyID) {
		return getPartyByPartyID(partyID);
	}
	/**
	 * @author Dinesh Selvaraj
	 * @param partyProcessignDesc
	 * @return
	 * @throws AIGCIExceptionMsg 
	 */
	public TpartyProcessing findByPartyProcessingID(String partyProcessignDesc) throws AIGCIExceptionMsg {
		TpartyProcessing tPartyProcessingData=null;
		tPartyProcessingData=tPartyProcessingRepository.findByPartyProcessingID(partyProcessignDesc.toUpperCase());
		if(tPartyProcessingData == null)
    	{
    		ngeException.throwException(NGEErrorCodes.WRONG_PARTY_PROCESSING,NGEErrorCodes.ERROR_TYPE , "Party processing not found in TPARTY_PROCESSING", null); 
    	}
		return tPartyProcessingData;
	}
	public List<Tparty> getPartyByPartyNo(String partyNo) {
		List<Tparty>  tPartyData=null;
		tPartyData=partyRepository.findByPartyNo(partyNo);
		return tPartyData;
	}
	public List<TrelatedParty> getRelatedParty(int partyId){
		return relatedPartyRepository.findRelatedParty(partyId);
	}
	/*public TpartyAction fetchPartyActionForUnderwriter(short productTowerId, String underwriter, int partyId) throws AIGCIExceptionMsg{
		TpartyAction partyAction = tPartyActionRepository.fetchPartyActionForUnderwriter(productTowerId, underwriter.toUpperCase(),partyId);
		
		if(partyAction == null){
			ngeException.throwException( NGEErrorCodes.DIFFERENT_PRODUCT_TOWER, NGEErrorCodes.ERROR_TYPE, null,null);
		}
		
		return partyAction;
	}*/
	
	public List<TrelatedParty> getResolvedParty(int partyId)throws AIGCIExceptionMsg {
		
		List<TrelatedParty> resolvedData = trelatedPartyRepository.findRelatedParty(partyId);		
		return resolvedData;		
	}
	
	public TpartyDetail getUnderwriterPartyDetails (String partyNo) {
		TpartyDetail partyDetailsData = null;
		
		partyDetailsData = tPartyDetailsRepository.getPartyDetails(partyNo, NGEConstants.PartyType.UNDERWRITER);
		return partyDetailsData;
	}
	
	/*public TpartyAction getPartyActionRecord(short productTowerId, short roleId) 
	{
		TpartyAction partyAction = tPartyActionRepository.fetchPartyId(productTowerId, roleId);		
		return partyAction;
	}	*/
	
	public String getAdditionalInsured(String compId, String roleName)
	{
		String additionalinsured = null;
		List<TtransactionComponentParty> componentPartyList = tTransactionComponentPartyRepository.findAdditionalInsured(compId, roleName);
		
		if(null != componentPartyList && componentPartyList.size() > 0)
		{
			additionalinsured = NGEConstants.YES;
		}
		else
		{
			additionalinsured = NGEConstants.NO;
		}
		return additionalinsured;
	}

	@Cacheable(value="PartyDAO.findByPartyId", unless="#result == null")
	public Tuser findByPartyId(int partyId) {
		Tuser user = null; 
		user = userRepository.findOne(partyId);
		return user;
	}
	
}
