package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SetAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-02-19T16:13:04.363+0530")
@StaticMetamodel(Trole.class)
public class Trole_ {
	public static volatile SingularAttribute<Trole, Short> roleId;
	public static volatile SingularAttribute<Trole, Timestamp> createTs;
	public static volatile SingularAttribute<Trole, String> createUserId;
	public static volatile SingularAttribute<Trole, String> roleNm;
	public static volatile SingularAttribute<Trole, Timestamp> updateTs;
	public static volatile SingularAttribute<Trole, String> updateUserId;
	public static volatile SetAttribute<Trole, TpartyAction> tpartyActions;
	public static volatile SetAttribute<Trole, TproductTowerParty> tproductTowerParties;
	public static volatile SetAttribute<Trole, TtransactionComponentParty> ttransactionComponentParties;
	public static volatile SetAttribute<Trole, TtransactionParty> ttransactionParties;
	public static volatile SetAttribute<Trole, Tblock> tblocks;
	public static volatile SingularAttribute<Trole, TpartyType> tpartyType;
}
