package com.aig.nge.entities;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-12-15T15:01:20.455+0530")
@StaticMetamodel(TlegacySubmissionXpsrPK.class)
public class TlegacySubmissionXpsrPK_ {
	public static volatile SingularAttribute<TlegacySubmissionXpsrPK, Long> submissionNo;
	public static volatile SingularAttribute<TlegacySubmissionXpsrPK, String> exposureSourceCd;
}
