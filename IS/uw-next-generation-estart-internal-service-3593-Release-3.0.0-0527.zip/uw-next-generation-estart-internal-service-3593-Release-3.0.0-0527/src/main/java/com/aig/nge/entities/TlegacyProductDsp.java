package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Date;


/**
 * The persistent class for the TLEGACY_PRODUCT_DSP database table.
 * 
 */
@Entity
@Table(name="TLEGACY_PRODUCT_DSP")
public class TlegacyProductDsp implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private TlegacyProductDspPK id;

	@Column(name="CREATED_BY_ID")
	private String createdById;

    @Temporal( TemporalType.DATE)
	@Column(name="ENTERED_DT")
	private Date enteredDt;

	@Column(name="LAST_UPDT_TS")
	private Timestamp lastUpdtTs;

	@Column(name="LAST_UPDT_USER_ID")
	private String lastUpdtUserId;

    @Temporal( TemporalType.DATE)
	@Column(name="PRDCT_DSP_EFCTV_DT")
	private Date prdctDspEfctvDt;

    @Temporal( TemporalType.DATE)
	@Column(name="PRDCT_DSP_XPRTN_DT")
	private Date prdctDspXprtnDt;

	@Column(name="PRODUCTION_IN")
	private String productionIn;

    public TlegacyProductDsp() {
    }

	public TlegacyProductDspPK getId() {
		return this.id;
	}

	public void setId(TlegacyProductDspPK id) {
		this.id = id;
	}
	
	public String getCreatedById() {
		return this.createdById;
	}

	public void setCreatedById(String createdById) {
		this.createdById = createdById;
	}

	public Date getEnteredDt() {
		return this.enteredDt;
	}

	public void setEnteredDt(Date enteredDt) {
		this.enteredDt = enteredDt;
	}

	public Timestamp getLastUpdtTs() {
		return this.lastUpdtTs;
	}

	public void setLastUpdtTs(Timestamp lastUpdtTs) {
		this.lastUpdtTs = lastUpdtTs;
	}

	public String getLastUpdtUserId() {
		return this.lastUpdtUserId;
	}

	public void setLastUpdtUserId(String lastUpdtUserId) {
		this.lastUpdtUserId = lastUpdtUserId;
	}

	public Date getPrdctDspEfctvDt() {
		return this.prdctDspEfctvDt;
	}

	public void setPrdctDspEfctvDt(Date prdctDspEfctvDt) {
		this.prdctDspEfctvDt = prdctDspEfctvDt;
	}

	public Date getPrdctDspXprtnDt() {
		return this.prdctDspXprtnDt;
	}

	public void setPrdctDspXprtnDt(Date prdctDspXprtnDt) {
		this.prdctDspXprtnDt = prdctDspXprtnDt;
	}

	public String getProductionIn() {
		return this.productionIn;
	}

	public void setProductionIn(String productionIn) {
		this.productionIn = productionIn;
	}

}