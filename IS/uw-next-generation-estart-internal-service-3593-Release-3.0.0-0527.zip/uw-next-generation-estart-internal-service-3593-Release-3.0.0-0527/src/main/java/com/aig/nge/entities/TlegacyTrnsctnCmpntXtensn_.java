package com.aig.nge.entities;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-09-11T14:03:53.784+0530")
@StaticMetamodel(TlegacyTrnsctnCmpntXtensn.class)
public class TlegacyTrnsctnCmpntXtensn_ {
	public static volatile SingularAttribute<TlegacyTrnsctnCmpntXtensn, String> transactionComponentId;
	public static volatile SingularAttribute<TlegacyTrnsctnCmpntXtensn, Timestamp> createTs;
	public static volatile SingularAttribute<TlegacyTrnsctnCmpntXtensn, String> createUserId;
	public static volatile SingularAttribute<TlegacyTrnsctnCmpntXtensn, String> currntBusTypCd;
	public static volatile SingularAttribute<TlegacyTrnsctnCmpntXtensn, String> declineReasonCd;
	public static volatile SingularAttribute<TlegacyTrnsctnCmpntXtensn, String> legacyProdctCovgTypCd;
	public static volatile SingularAttribute<TlegacyTrnsctnCmpntXtensn, BigDecimal> partOfAm;
	public static volatile SingularAttribute<TlegacyTrnsctnCmpntXtensn, Short> profitUnitCd;
	public static volatile SingularAttribute<TlegacyTrnsctnCmpntXtensn, Short> sectionCd;
	public static volatile SingularAttribute<TlegacyTrnsctnCmpntXtensn, Timestamp> updateTs;
	public static volatile SingularAttribute<TlegacyTrnsctnCmpntXtensn, String> updateUserId;
	public static volatile SingularAttribute<TlegacyTrnsctnCmpntXtensn, Date> xchangeRtEfctvDt;
	public static volatile SingularAttribute<TlegacyTrnsctnCmpntXtensn, TlegacyProduct> tlegacyProduct;
	public static volatile SingularAttribute<TlegacyTrnsctnCmpntXtensn, TlegacyProductBundling> tlegacyProductBundling;
	public static volatile SingularAttribute<TlegacyTrnsctnCmpntXtensn, TtransactionComponent> ttransactionComponent;
	public static volatile SingularAttribute<TlegacyTrnsctnCmpntXtensn, BigDecimal> localPartOfAm;
	public static volatile SingularAttribute<TlegacyTrnsctnCmpntXtensn, String> profitCenterCd;
	public static volatile SingularAttribute<TlegacyTrnsctnCmpntXtensn, String> sourceCd;
	public static volatile SingularAttribute<TlegacyTrnsctnCmpntXtensn, String> workingBranchCd;
	public static volatile SingularAttribute<TlegacyTrnsctnCmpntXtensn, Integer> rrPrtctvContNo;
	public static volatile SingularAttribute<TlegacyTrnsctnCmpntXtensn, String> specialEventNm;
	public static volatile SingularAttribute<TlegacyTrnsctnCmpntXtensn, Date> underwritingDt;
}
