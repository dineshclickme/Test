package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Set;


/**
 * The persistent class for the TSCREEN database table.
 * 
 */
@Entity
public class Tscreen implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="SCREEN_ID")
	private short screenId;

	@Column(name="CREATE_TS")
	private Timestamp createTs;

	@Column(name="CREATE_USER_ID")
	private String createUserId;

	@Column(name="SCREEN_DS")
	private String screenDs;

	@Column(name="SCREEN_NM")
	private String screenNm;

	@Column(name="UPDATE_TS")
	private Timestamp updateTs;

	@Column(name="UPDATE_USER_ID")
	private String updateUserId;

	//bi-directional many-to-one association to TscreenField
	@OneToMany(mappedBy="tscreen", cascade={CascadeType.ALL})
	private Set<TscreenField> tscreenFields;

    public Tscreen() {
    }

	public short getScreenId() {
		return this.screenId;
	}

	public void setScreenId(short screenId) {
		this.screenId = screenId;
	}

	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public String getScreenDs() {
		return this.screenDs;
	}

	public void setScreenDs(String screenDs) {
		this.screenDs = screenDs;
	}

	public String getScreenNm() {
		return this.screenNm;
	}

	public void setScreenNm(String screenNm) {
		this.screenNm = screenNm;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public Set<TscreenField> getTscreenFields() {
		return this.tscreenFields;
	}

	public void setTscreenFields(Set<TscreenField> tscreenFields) {
		this.tscreenFields = tscreenFields;
	}
	
}