package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-02-19T16:13:04.502+0530")
@StaticMetamodel(TstatusTransition.class)
public class TstatusTransition_ {
	public static volatile SingularAttribute<TstatusTransition, TstatusTransitionPK> id;
	public static volatile SingularAttribute<TstatusTransition, Timestamp> createTs;
	public static volatile SingularAttribute<TstatusTransition, String> createUserId;
	public static volatile SingularAttribute<TstatusTransition, Timestamp> updateTs;
	public static volatile SingularAttribute<TstatusTransition, String> updateUserId;
	public static volatile SingularAttribute<TstatusTransition, Tstatus> tstatus;
	public static volatile SingularAttribute<TstatusTransition, TstatusCondition> tstatusCondition;
	public static volatile SingularAttribute<TstatusTransition, TreasonType> treasonType;
}
