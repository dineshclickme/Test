package com.aig.nge.entities;

import java.util.Date;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-03-02T12:10:24.952+0530")
@StaticMetamodel(TsubmissionHPK.class)
public class TsubmissionHPK_ {
	public static volatile SingularAttribute<TsubmissionHPK, String> submissionNo;
	public static volatile SingularAttribute<TsubmissionHPK, Date> createHistoryTs;
}
