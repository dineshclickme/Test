package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the TLEGACY_PRODUCT_LEAD_SRC_TYP database table.
 * 
 */
@Entity
@Table(name="TLEGACY_PRODUCT_LEAD_SRC_TYP")
public class TlegacyProductLeadSrcTyp implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private TlegacyProductLeadSrcTypPK id;

	@Column(name="BRANCH_NO")
	private String branchNo;

	@Column(name="CREATE_TS")
	private Timestamp createTs;

	@Column(name="CREATE_USER_ID")
	private String createUserId;

	@Column(name="LEAD_SOURCE_ID")
	private String leadSourceId;

	@Column(name="OPERATING_CO_CD")
	private String operatingCoCd;

	@Column(name="UPDATE_TS")
	private Timestamp updateTs;

	@Column(name="UPDATE_USER_ID")
	private String updateUserId;

	//bi-directional many-to-one association to TlegacyLeadSourceType
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumns({
		@JoinColumn(name="LEAD_SOURCE_TYPE_CD", referencedColumnName="LEAD_SOURCE_TYPE_CD"),
		@JoinColumn(name="SOURCE_CD", referencedColumnName="SOURCE_CD")
		})
	private TlegacyLeadSourceType tlegacyLeadSourceType;

	//bi-directional many-to-one association to TtransactionComponent
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="TRANSACTION_COMPONENT_ID")
	private TtransactionComponent ttransactionComponent;

    public TlegacyProductLeadSrcTyp() {
    }

	public TlegacyProductLeadSrcTypPK getId() {
		return this.id;
	}

	public void setId(TlegacyProductLeadSrcTypPK id) {
		this.id = id;
	}
	
	public String getBranchNo() {
		return this.branchNo;
	}

	public void setBranchNo(String branchNo) {
		this.branchNo = branchNo;
	}

	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public String getLeadSourceId() {
		if(this.leadSourceId != null)
			return this.leadSourceId.trim();
		else
			return this.leadSourceId;
	}

	public void setLeadSourceId(String leadSourceId) {
		this.leadSourceId = leadSourceId;
	}

	public String getOperatingCoCd() {
		return this.operatingCoCd;
	}

	public void setOperatingCoCd(String operatingCoCd) {
		this.operatingCoCd = operatingCoCd;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public TlegacyLeadSourceType getTlegacyLeadSourceType() {
		return this.tlegacyLeadSourceType;
	}

	public void setTlegacyLeadSourceType(TlegacyLeadSourceType tlegacyLeadSourceType) {
		this.tlegacyLeadSourceType = tlegacyLeadSourceType;
	}
	
	public TtransactionComponent getTtransactionComponent() {
		return this.ttransactionComponent;
	}

	public void setTtransactionComponent(TtransactionComponent ttransactionComponent) {
		this.ttransactionComponent = ttransactionComponent;
	}
	
}