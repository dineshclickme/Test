package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SetAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-02-20T11:23:26.670+0530")
@StaticMetamodel(Tproduct.class)
public class Tproduct_ {
	public static volatile SingularAttribute<Tproduct, Integer> productId;
	public static volatile SingularAttribute<Tproduct, Timestamp> createTs;
	public static volatile SingularAttribute<Tproduct, String> createUserId;
	public static volatile SingularAttribute<Tproduct, String> deletedIn;
	public static volatile SingularAttribute<Tproduct, Timestamp> updateTs;
	public static volatile SingularAttribute<Tproduct, String> updateUserId;
	public static volatile SetAttribute<Tproduct, TlegacyProductMapping> tlegacyProductMappings1;
	public static volatile SetAttribute<Tproduct, TlegacyProductMapping> tlegacyProductMappings2;
	public static volatile SetAttribute<Tproduct, TlegacyProductMapping> tlegacyProductMappings3;
	public static volatile SetAttribute<Tproduct, TlegacyProductMapping> tlegacyProductMappings4;
	public static volatile SetAttribute<Tproduct, TlegacyProductMapping> tlegacyProductMappings5;
	public static volatile SingularAttribute<Tproduct, TmarketableProduct> tmarketableProduct;
	public static volatile SingularAttribute<Tproduct, TmarketableProductComponent> tmarketableProductComponent;
	public static volatile SingularAttribute<Tproduct, TproductType> tproductType;
	public static volatile SingularAttribute<Tproduct, TproductDsp> tproductDsp;
	
	public static volatile SingularAttribute<Tproduct, TproductMmcp> tproductMmcp;
	public static volatile SetAttribute<Tproduct, TtickerDivisionProduct> ttickerDivisionProducts;
	public static volatile SetAttribute<Tproduct, TtransactionProductAttribute> ttransactionProductAttributes;
	public static volatile SingularAttribute<Tproduct, TtuwProduct> ttuwProduct;
	public static volatile SingularAttribute<Tproduct, TtuwSubProduct> ttuwSubProduct;
	public static volatile SingularAttribute<Tproduct, TproductTowerTuwSubProduct> tproductTowerTuwSubProdct;

}
