package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;

import org.apache.openjpa.persistence.DataCache;
import java.sql.Timestamp;


/**
 * The persistent class for the TMARKETABLE_PRODUCT_COMPONENT database table.
 * 
 */
@Entity
@DataCache
@Table(name="TMARKETABLE_PRODUCT_COMPONENT")
public class TmarketableProductComponent implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="MARKETABLE_PRODUCT_CMPNT_ID")
	private int marketableProductCmpntId;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="CREATE_TS")
	private Timestamp createTs;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="CREATE_USER_ID")
	private String createUserId;

	@Column(name="DELETED_IN")
	private String deletedIn;

	@Column(name="MARKETABLE_PRODUCT_CMPNT_CD")
	private String marketableProductCmpntCd;

	@Column(name="MARKETABLE_PRODUCT_CMPNT_NM")
	private String marketableProductCmpntNm;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="UPDATE_TS")
	private Timestamp updateTs;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="UPDATE_USER_ID")
	private String updateUserId;

	//bi-directional many-to-one association to TmarketableProduct
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="MARKETABLE_PRODUCT_ID")
	private TmarketableProduct tmarketableProduct;

	//bi-directional one-to-one association to Tproduct
	@OneToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="MARKETABLE_PRODUCT_CMPNT_ID")
	private Tproduct tproduct;

	//bi-directional many-to-one association to TproductTowerTuwSubProdct
    @ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="PRODUCT_TOWER_TUW_SUBPRODCT_ID")
	private TproductTowerTuwSubProduct tproductTowerTuwSubProduct;


    public TmarketableProductComponent() {
    }

	public int getMarketableProductCmpntId() {
		return this.marketableProductCmpntId;
	}

	public void setMarketableProductCmpntId(int marketableProductCmpntId) {
		this.marketableProductCmpntId = marketableProductCmpntId;
	}

	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public String getDeletedIn() {
		return this.deletedIn;
	}

	public void setDeletedIn(String deletedIn) {
		this.deletedIn = deletedIn;
	}

	public String getMarketableProductCmpntCd() {
		return this.marketableProductCmpntCd;
	}

	public void setMarketableProductCmpntCd(String marketableProductCmpntCd) {
		this.marketableProductCmpntCd = marketableProductCmpntCd;
	}

	public String getMarketableProductCmpntNm() {
		return this.marketableProductCmpntNm;
	}

	public void setMarketableProductCmpntNm(String marketableProductCmpntNm) {
		this.marketableProductCmpntNm = marketableProductCmpntNm;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public TmarketableProduct getTmarketableProduct() {
		return this.tmarketableProduct;
	}

	public void setTmarketableProduct(TmarketableProduct tmarketableProduct) {
		this.tmarketableProduct = tmarketableProduct;
	}
	
	public Tproduct getTproduct() {
		return this.tproduct;
	}

	public void setTproduct(Tproduct tproduct) {
		this.tproduct = tproduct;
	}
		
	public TproductTowerTuwSubProduct getTproductTowerTuwSubProduct() {
		return this.tproductTowerTuwSubProduct;
	}

	public void setTproductTowerTuwSubProduct(TproductTowerTuwSubProduct tproductTowerTuwSubProduct) {
		this.tproductTowerTuwSubProduct = tproductTowerTuwSubProduct;
	}

	
}