package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-06-19T14:59:45.741+0530")
@StaticMetamodel(TlegacySourceMapping.class)
public class TlegacySourceMapping_ {
	public static volatile SingularAttribute<TlegacySourceMapping, TlegacySourceMappingPK> id;
	public static volatile SingularAttribute<TlegacySourceMapping, Timestamp> createTs;
	public static volatile SingularAttribute<TlegacySourceMapping, String> createUserId;
	public static volatile SingularAttribute<TlegacySourceMapping, String> defaultIn;
	public static volatile SingularAttribute<TlegacySourceMapping, Timestamp> updateTs;
	public static volatile SingularAttribute<TlegacySourceMapping, String> updateUserId;
	public static volatile SingularAttribute<TlegacySourceMapping, Tsource> tsource;
	public static volatile SingularAttribute<TlegacySourceMapping, Tbranch> tbranch;
}
