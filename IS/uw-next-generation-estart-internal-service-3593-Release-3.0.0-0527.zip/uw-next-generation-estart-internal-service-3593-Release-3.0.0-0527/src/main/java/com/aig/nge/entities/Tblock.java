package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;

import java.sql.Timestamp;


/**
 * The persistent class for the TBLOCK database table.
 * 
 */
@Entity
public class Tblock implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "block_id_gen")
	@SequenceGenerator(name = "block_id_gen", sequenceName = "BLOCK_ID_SEQ", allocationSize = 1)
	@Column(name="BLOCK_NO")
	private int blockNo;

	@Column(name="COMMENT_TX")
	private String commentTx;

	@Column(name="CREATE_TS")
	private Timestamp createTs;

	@Column(name="CREATE_USER_ID")
	private String createUserId;

	@Column(name="SYSTEM_ID")
	private short systemId;

	@Column(name="UPDATE_TS")
	private Timestamp updateTs;

	@Column(name="UPDATE_USER_ID")
	private String updateUserId;

	//bi-directional one-to-one association to TalertBlock
	@OneToOne(mappedBy="tblock", cascade={CascadeType.ALL}, fetch=FetchType.LAZY)
	private TalertBlock talertBlock;

	//bi-directional many-to-one association to TblockType
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="BLOCK_TYPE_ID")
	private TblockType tblockType;

	//bi-directional many-to-one association to Tparty
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="PARTY_ID")
	private Tparty tparty;

	//bi-directional many-to-one association to Treason
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="REASON_ID")
	private Treason treason;

	//bi-directional many-to-one association to Trole
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="ROLE_ID")
	private Trole trole;

	//bi-directional many-to-one association to Tstatus
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="STATUS_ID")
	private Tstatus tstatus;

	//bi-directional many-to-one association to TtransactionComponent
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="TRANSACTION_COMPONENT_ID")
	private TtransactionComponent ttransactionComponent;

	//bi-directional one-to-one association to TcomponentBlock
	@OneToOne(mappedBy="tblock", cascade={CascadeType.ALL}, fetch=FetchType.LAZY)
	private TcomponentBlock tcomponentBlock;

    public Tblock() {
    }

	public int getBlockNo() {
		return this.blockNo;
	}

	public void setBlockNo(int blockNo) {
		this.blockNo = blockNo;
	}

	public String getCommentTx() {
		return this.commentTx;
	}

	public void setCommentTx(String commentTx) {
		this.commentTx = commentTx;
	}

	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public short getSystemId() {
		return this.systemId;
	}

	public void setSystemId(short systemId) {
		this.systemId = systemId;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public TalertBlock getTalertBlock() {
		return this.talertBlock;
	}

	public void setTalertBlock(TalertBlock talertBlock) {
		this.talertBlock = talertBlock;
	}
	
	public TblockType getTblockType() {
		return this.tblockType;
	}

	public void setTblockType(TblockType tblockType) {
		this.tblockType = tblockType;
	}
	
	public Tparty getTparty() {
		return this.tparty;
	}

	public void setTparty(Tparty tparty) {
		this.tparty = tparty;
	}
	
	public Treason getTreason() {
		return this.treason;
	}

	public void setTreason(Treason treason) {
		this.treason = treason;
	}
	
	public Trole getTrole() {
		return this.trole;
	}

	public void setTrole(Trole trole) {
		this.trole = trole;
	}
	
	public Tstatus getTstatus() {
		return this.tstatus;
	}

	public void setTstatus(Tstatus tstatus) {
		this.tstatus = tstatus;
	}
	
	public TtransactionComponent getTtransactionComponent() {
		return this.ttransactionComponent;
	}

	public void setTtransactionComponent(TtransactionComponent ttransactionComponent) {
		this.ttransactionComponent = ttransactionComponent;
	}
	
	public TcomponentBlock getTcomponentBlock() {
		return this.tcomponentBlock;
	}

	public void setTcomponentBlock(TcomponentBlock tcomponentBlock) {
		this.tcomponentBlock = tcomponentBlock;
	}
	
}