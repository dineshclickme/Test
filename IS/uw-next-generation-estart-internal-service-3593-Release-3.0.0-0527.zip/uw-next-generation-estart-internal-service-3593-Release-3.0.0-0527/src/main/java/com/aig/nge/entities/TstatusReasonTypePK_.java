package com.aig.nge.entities;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-02-19T16:13:04.488+0530")
@StaticMetamodel(TstatusReasonTypePK.class)
public class TstatusReasonTypePK_ {
	public static volatile SingularAttribute<TstatusReasonTypePK, Short> statusId;
	public static volatile SingularAttribute<TstatusReasonTypePK, Short> reasonTypeId;
}
