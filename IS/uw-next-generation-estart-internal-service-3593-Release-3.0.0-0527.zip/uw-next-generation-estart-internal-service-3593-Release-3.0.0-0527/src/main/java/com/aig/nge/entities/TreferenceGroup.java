package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;

import org.apache.openjpa.persistence.DataCache;
import java.sql.Timestamp;
import java.util.Set;


/**
 * The persistent class for the TREFERENCE_GROUP database table.
 * 
 */
@Entity
@DataCache
@Table(name="TREFERENCE_GROUP")
public class TreferenceGroup implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="REFERENCE_GROUP_ID")
	private short referenceGroupId;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="CREATE_TS")
	private Timestamp createTs;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="CREATE_USER_ID")
	private String createUserId;

	@Column(name="GROUP_DS")
	private String groupDs;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="UPDATE_TS")
	private Timestamp updateTs;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="UPDATE_USER_ID")
	private String updateUserId;

	//bi-directional many-to-one association to TattributeReference
	@OneToMany(mappedBy="treferenceGroup", cascade={CascadeType.ALL})
	private Set<TattributeReference> tattributeReferences;

    public TreferenceGroup() {
    }

	public short getReferenceGroupId() {
		return this.referenceGroupId;
	}

	public void setReferenceGroupId(short referenceGroupId) {
		this.referenceGroupId = referenceGroupId;
	}

	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public String getGroupDs() {
		return this.groupDs;
	}

	public void setGroupDs(String groupDs) {
		this.groupDs = groupDs;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public Set<TattributeReference> getTattributeReferences() {
		return this.tattributeReferences;
	}

	public void setTattributeReferences(Set<TattributeReference> tattributeReferences) {
		this.tattributeReferences = tattributeReferences;
	}
	
}