package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;

import org.apache.openjpa.persistence.DataCache;
import java.sql.Timestamp;
import java.util.Set;


/**
 * The persistent class for the TPOLICY_TYPE database table.
 * 
 */
@Entity
@DataCache
@Table(name="TPOLICY_TYPE")
public class TpolicyType implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="POLICY_TYPE_ID")
	private short policyTypeId;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="CREATE_TS")
	private Timestamp createTs;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="CREATE_USER_ID")
	private String createUserId;

	@Column(name="POLICY_TYPE_NM")
	private String policyTypeNm;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="UPDATE_TS")
	private Timestamp updateTs;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="UPDATE_USER_ID")
	private String updateUserId;

	//bi-directional many-to-one association to Tpolicy
	@OneToMany(mappedBy="tpolicyType", cascade={CascadeType.ALL})
	private Set<Tpolicy> tpolicies;

    public TpolicyType() {
    }

	public short getPolicyTypeId() {
		return this.policyTypeId;
	}

	public void setPolicyTypeId(short policyTypeId) {
		this.policyTypeId = policyTypeId;
	}

	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public String getPolicyTypeNm() {
		return this.policyTypeNm;
	}

	public void setPolicyTypeNm(String policyTypeNm) {
		this.policyTypeNm = policyTypeNm;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public Set<Tpolicy> getTpolicies() {
		return this.tpolicies;
	}

	public void setTpolicies(Set<Tpolicy> tpolicies) {
		this.tpolicies = tpolicies;
	}
	
}