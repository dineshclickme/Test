package com.aig.nge.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.aig.nge.entities.Tbranch;
import com.aig.nge.repository.TBranchRepository;

/**
 * @author Dinesh Sekar
 *
 */
@Repository
public class BranchDAO extends BaseDAO{

	@Autowired
	private TBranchRepository branchRepository;
	
	public Tbranch getBranchByBranchCd(String branchCd)
	{
		Tbranch branchObj = branchRepository.findByBranchCd(branchCd.trim());
		return branchObj;
	}
	
	public Tbranch getBranchByLegacyBranchCd(String sourceCd,String branchCd)
	{
		Tbranch branchObj = branchRepository.findByLegacyBranchCd(sourceCd, branchCd.trim());
		return branchObj;
	}
}
