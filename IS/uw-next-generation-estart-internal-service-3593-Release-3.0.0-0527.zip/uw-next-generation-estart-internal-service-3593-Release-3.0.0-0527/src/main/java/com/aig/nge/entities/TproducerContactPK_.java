package com.aig.nge.entities;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-02-19T16:13:03.872+0530")
@StaticMetamodel(TproducerContactPK.class)
public class TproducerContactPK_ {
	public static volatile SingularAttribute<TproducerContactPK, String> transactionId;
	public static volatile SingularAttribute<TproducerContactPK, Short> contactSqn;
}
