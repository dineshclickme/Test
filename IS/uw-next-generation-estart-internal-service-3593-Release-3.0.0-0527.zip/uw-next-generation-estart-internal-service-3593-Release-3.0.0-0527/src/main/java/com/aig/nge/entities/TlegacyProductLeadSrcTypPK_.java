package com.aig.nge.entities;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-04-15T15:31:47.057+0530")
@StaticMetamodel(TlegacyProductLeadSrcTypPK.class)
public class TlegacyProductLeadSrcTypPK_ {
	public static volatile SingularAttribute<TlegacyProductLeadSrcTypPK, String> transactionComponentId;
	public static volatile SingularAttribute<TlegacyProductLeadSrcTypPK, String> sourceCd;
	public static volatile SingularAttribute<TlegacyProductLeadSrcTypPK, String> leadSourceTypeCd;
}
