package com.aig.nge.entities;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.StringTokenizer;


public class TransactionChildEntriesBO {
	private static final Logger logger = LogManager.getLogger(TransactionChildEntriesBO.class);
	
	private String attributeDetails;
		
	private String transactionParty;
	
	private String producerContactDetails;
	
	private String producerContactEmail;
	
	private String producerContactPhone;
	
	private String genericDelimiter = "|";
	private String recordDelimiter = "~";
	

	public void setProducerContactDetails(String producerContactDetails) {
		this.producerContactDetails = producerContactDetails;
	}

	public void setProducerContactEmail(String producerContactEmail) {
		this.producerContactEmail = producerContactEmail;
	}

	public void setProducerContactPhone(String producerContactPhone) {
		this.producerContactPhone = producerContactPhone;
	}

	public void setAttributeDetails(String attributeDetails) {
		this.attributeDetails = attributeDetails;
	}

	public String getTransactionParty() {
		return transactionParty;
	}


	public void setTransactionParty(
			String transactionParty) {
		this.transactionParty = transactionParty;
	}

	
	public class TransactionPartyDetails {
		
		private String roleNm;
		private String partyNo;
		private String partyTypeNm;
		private Short versionSqn;
		private String accountNm;
		
		public String getRoleNm() {
			return roleNm;
		}
		public void setRoleNm(String roleNm) {
			this.roleNm = roleNm;
		}
		public String getPartyNo() {
			return partyNo;
		}
		public void setPartyNo(String partyNo) {
			this.partyNo = partyNo;
		}
		public String getPartyTypeNm() {
			return partyTypeNm;
		}
		public void setPartyTypeNm(String partyTypeNm) {
			this.partyTypeNm = partyTypeNm;
		}
		public Short getVersionSqn() {
			return versionSqn;
		}
		public void setVersionSqn(Short versionSqn) {
			this.versionSqn = versionSqn;
		}
		public String getAccountNm() {
			return accountNm;
		}
		public void setAccountNm(String accountNm) {
			this.accountNm = accountNm;
		}
	}
	
	public class AttributeDetails {
		private Short attributeId;
		private String attributeVal;
		private Short versionSqn;
		
		public Short getAttributeId() {
			return attributeId;
		}
		public void setAttributeId(Short attributeId) {
			this.attributeId = attributeId;
		}
		public String getAttributeVal() {
			return attributeVal;
		}
		public void setAttributeVal(String attributeVal) {
			this.attributeVal = attributeVal;
		}
		public Short getVersionSqn() {
			return versionSqn;
		}
		public void setVersionSqn(Short versionSqn) {
			this.versionSqn = versionSqn;
		}
	}
	
	public class ProducerContactDetails {
		
		private short producerContactSqn;
		private String producerContactFirstName;
		private String producerContactLastName;
		private String eMail;
		private String phone;
		
		public short getProducerContactSqn() {
			return producerContactSqn;
		}
		public void setProducerContactSqn(short producerContactSqn) {
			this.producerContactSqn = producerContactSqn;
		}
		public String getProducerContactFirstName() {
			return producerContactFirstName;
		}
		public void setProducerContactFirstName(String producerContactFirstName) {
			this.producerContactFirstName = producerContactFirstName;
		}
		public String getProducerContactLastName() {
			return producerContactLastName;
		}
		public void setProducerContactLastName(String producerContactLastName) {
			this.producerContactLastName = producerContactLastName;
		}
		public String geteMail() {
			return eMail;
		}
		public void seteMail(String eMail) {
			this.eMail = eMail;
		}
		public String getPhone() {
			return phone;
		}
		public void setPhone(String phone) {
			this.phone = phone;
		}
	
		
		
	}

	private Set<String> getUniqueValues(String stringContainingDuplicates) {
		if(null != stringContainingDuplicates)
		{
			logger.debug("stringContainingDuplicates : "+stringContainingDuplicates);
			/*int index = stringContainingDuplicates.lastIndexOf(recordDelimiter);
			logger.debug("index : "+index);
			if(index > 0)
			{
				stringContainingDuplicates = stringContainingDuplicates.substring(0, index);
			}*/
			logger.debug("After stringContainingDuplicates : "+stringContainingDuplicates);
			Set<String> uniqueValueSet = new HashSet<String>(Arrays.asList(stringContainingDuplicates.split(recordDelimiter)));
			return uniqueValueSet;
		}
		return new HashSet<String>();
	}
	
	
	
	public List<AttributeDetails> getAttributeDetails() {
		
		Short versionSqn = null;
		String attributeId = null;
		String attributeVal = null;
		List<AttributeDetails> attributeDetailsList = new ArrayList<AttributeDetails>();
		logger.debug("getUniqueAttributeDetails : "+this.attributeDetails);
		for(String temp : getUniqueValues(this.attributeDetails))
		{
			logger.debug("temp : "+temp);
			AttributeDetails attDetails = new AttributeDetails();
			StringTokenizer st = new StringTokenizer(temp,genericDelimiter);
										
			if(st.hasMoreTokens())
			{
				versionSqn = Short.valueOf(st.nextToken());
				attDetails.setVersionSqn(versionSqn);
			}
			if(st.hasMoreTokens())
			{
				attributeId = st.nextToken();
				attDetails.setAttributeId(Short.valueOf(attributeId));
			}
			if(st.hasMoreTokens())
			{
				attributeVal = st.nextToken();
				attDetails.setAttributeVal(attributeVal);
			}
			 
			attributeDetailsList.add(attDetails);
		}
		
		return attributeDetailsList;
	}
	

	public List<TransactionPartyDetails> getTransactionPartyDetails() {
		
		String roleNm = null;
		String partyNo = null;
		String partyTypeNm = null;
		Short versionSqn = null;
		String accountNm = null;

		List<TransactionPartyDetails> transactionPartyDetailsList = new ArrayList<TransactionPartyDetails>();
		logger.debug("transactionParty : "+this.transactionParty);
		for(String temp : getUniqueValues(this.transactionParty))
		{
			logger.debug("temp : "+temp);
			TransactionPartyDetails transactionPartyDetails = new TransactionPartyDetails();
			StringTokenizer st = new StringTokenizer(temp,genericDelimiter);
			
			if(st.hasMoreTokens())
			{
				roleNm = st.nextToken();
				transactionPartyDetails.setRoleNm(roleNm);
			}
			if(st.hasMoreTokens())
			{
				partyNo = st.nextToken();
				transactionPartyDetails.setPartyNo(partyNo);
			}
			if(st.hasMoreTokens())
			{
				partyTypeNm = st.nextToken();
				transactionPartyDetails.setPartyTypeNm(partyTypeNm);
			}
			if(st.hasMoreTokens())
			{
				versionSqn = Short.valueOf(st.nextToken());
				transactionPartyDetails.setVersionSqn(versionSqn);
			}
			if(st.hasMoreTokens())
 			{
				accountNm = st.nextToken();
				transactionPartyDetails.setAccountNm(accountNm);
 			}
				
			transactionPartyDetailsList.add(transactionPartyDetails);
		}
		
		return transactionPartyDetailsList;
	}
	
	public List<ProducerContactDetails> getProducerContactDetails() {
		
		String contactSqn = null;
		String firstName = null;
		String lastName = null;
		String email = null;
		String phone = null;
		
		List<ProducerContactDetails> producerContactList = new ArrayList<ProducerContactDetails>();
		logger.debug("producerContactDetails : "+this.producerContactDetails);
		
		for(String temp : getUniqueValues(this.producerContactDetails))
		{
			ProducerContactDetails producerContact = new ProducerContactDetails();
			StringTokenizer st = new StringTokenizer(temp,genericDelimiter);
				
			if(st.hasMoreTokens())
			{
				contactSqn = st.nextToken();
				producerContact.setProducerContactSqn(Short.valueOf(contactSqn));
			}
			if(st.hasMoreTokens())
			{
				firstName = st.nextToken();
			
				/*	Exadata migration changes
				*		Adding trim() function
				**/
				
				producerContact.setProducerContactFirstName(firstName.trim());
			}
			if(st.hasMoreTokens())
			{
				lastName = st.nextToken();
				
				/*	Exadata migration changes
				*		Adding trim() function
				**/
				
				producerContact.setProducerContactLastName(lastName.trim());
			}
			
			
			
			
			for(String temp1 : getUniqueValues(this.producerContactEmail))
			{
				StringTokenizer st1 = new StringTokenizer(temp1,genericDelimiter);
									
				if(st1.hasMoreTokens())
				{
					contactSqn = st1.nextToken();
				}
				if(st1.hasMoreTokens())
				{
					email = st1.nextToken();
				}
				
				if(contactSqn.equalsIgnoreCase(String.valueOf(producerContact.getProducerContactSqn())))
				{
					logger.debug("email : "+email);
					producerContact.seteMail(email);
				}
				
			}
			
			for(String temp1 : getUniqueValues(this.producerContactPhone))
			{
				StringTokenizer st1 = new StringTokenizer(temp1,genericDelimiter);
				
				if(st1.hasMoreTokens())
				{
					contactSqn = st1.nextToken();
				}
				if(st1.hasMoreTokens())
				{
					phone = st1.nextToken();
				}
				
				if(contactSqn.equalsIgnoreCase(String.valueOf(producerContact.getProducerContactSqn())))
				{
					logger.debug("phone : "+phone);
					producerContact.setPhone(phone);
				}
				
			}			
		     
			producerContactList.add(producerContact);
		}
		
		return producerContactList;
	}
}
