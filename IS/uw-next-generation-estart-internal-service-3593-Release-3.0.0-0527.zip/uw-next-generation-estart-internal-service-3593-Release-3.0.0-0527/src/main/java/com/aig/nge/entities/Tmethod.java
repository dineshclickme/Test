package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;

import org.apache.openjpa.persistence.DataCache;
import java.sql.Timestamp;
import java.util.Set;


/**
 * The persistent class for the TMETHOD database table.
 * 
 */
@Entity
@DataCache
public class Tmethod implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="METHOD_ID")
	private short methodId;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="CREATE_TS")
	private Timestamp createTs;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="CREATE_USER_ID")
	private String createUserId;

	@Column(name="METHOD_NM")
	private String methodNm;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="UPDATE_TS")
	private Timestamp updateTs;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="UPDATE_USER_ID")
	private String updateUserId;

	//bi-directional many-to-one association to Tservice
	@ManyToOne
	@JoinColumn(name="SERVICE_ID")
	private Tservice tservice;

	//bi-directional many-to-one association to TsystemMethod
	@OneToMany(mappedBy="tmethod", cascade={CascadeType.ALL})
	private Set<TsystemMethod> tsystemMethods;

    public Tmethod() {
    }

	public short getMethodId() {
		return this.methodId;
	}

	public void setMethodId(short methodId) {
		this.methodId = methodId;
	}

	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public String getMethodNm() {
		return this.methodNm;
	}

	public void setMethodNm(String methodNm) {
		this.methodNm = methodNm;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public Tservice getTservice() {
		return this.tservice;
	}

	public void setTservice(Tservice tservice) {
		this.tservice = tservice;
	}
	
	public Set<TsystemMethod> getTsystemMethods() {
		return this.tsystemMethods;
	}

	public void setTsystemMethods(Set<TsystemMethod> tsystemMethods) {
		this.tsystemMethods = tsystemMethods;
	}
	
}