package com.aig.nge.entities;

import java.sql.Timestamp;
import java.util.Date;
import javax.annotation.Generated;
import javax.persistence.metamodel.SetAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-02-19T16:13:03.239+0530")
@StaticMetamodel(Tcurrency.class)
public class Tcurrency_ {
	public static volatile SingularAttribute<Tcurrency, Short> currencyId;
	public static volatile SingularAttribute<Tcurrency, String> aigCurrencyCd;
	public static volatile SingularAttribute<Tcurrency, Timestamp> createTs;
	public static volatile SingularAttribute<Tcurrency, String> createUserId;
	public static volatile SingularAttribute<Tcurrency, String> currencyCd;
	public static volatile SingularAttribute<Tcurrency, String> currencyNm;
	public static volatile SingularAttribute<Tcurrency, Date> effectiveDt;
	public static volatile SingularAttribute<Tcurrency, Date> expirationDt;
	public static volatile SingularAttribute<Tcurrency, Timestamp> updateTs;
	public static volatile SingularAttribute<Tcurrency, String> updateUserId;
	public static volatile SingularAttribute<Tcurrency, Tcurrency> tcurrency;
	public static volatile SetAttribute<Tcurrency, Tcurrency> tcurrencies;
	public static volatile SetAttribute<Tcurrency, TlegacyWipQuoteCurrency> tlegacyWipQuoteCurrencies;
	public static volatile SetAttribute<Tcurrency, Tpolicy> tpolicies;
	public static volatile SetAttribute<Tcurrency, TtransactionComponentLimit> ttransactionComponentLimits;
	public static volatile SetAttribute<Tcurrency, TuserPrefernce> tuserPrefernces;
}
