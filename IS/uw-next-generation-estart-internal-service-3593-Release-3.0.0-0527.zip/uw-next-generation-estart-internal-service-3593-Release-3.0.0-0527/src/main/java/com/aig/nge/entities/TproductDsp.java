package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;

import org.apache.openjpa.persistence.DataCache;
import java.sql.Timestamp;


/**
 * The persistent class for the TPRODUCT_DSP database table.
 * 
 */
@Entity
@DataCache
@Table(name="TPRODUCT_DSP")
public class TproductDsp implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="PRODUCT_DSP_ID")
	private int productDspId;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="CREATE_TS")
	private Timestamp createTs;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="CREATE_USER_ID")
	private String createUserId;

	@Column(name="DELETED_IN")
	private String deletedIn;

	@Column(name="PROFIT_UNIT_CD")
	private short profitUnitCd;

	@Column(name="SECTION_CD")
	private short sectionCd;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="UPDATE_TS")
	private Timestamp updateTs;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="UPDATE_USER_ID")
	private String updateUserId;
	@Column(name="DSP_NM")
	private String dspNm;

	//bi-directional many-to-one association to Tdivision
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="DIVISION_NO")
	private Tdivision tdivision;

	//bi-directional one-to-one association to Tproduct
	@OneToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="PRODUCT_DSP_ID")
	private Tproduct tproduct;

	//bi-directional many-to-one association to TproductTowerTuwSubProdct
    @ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="PRODUCT_TOWER_TUW_SUBPRODCT_ID")
	private TproductTowerTuwSubProduct tproductTowerTuwSubProduct;


    public TproductDsp() {
    }

	public int getProductDspId() {
		return this.productDspId;
	}

	public void setProductDspId(int productDspId) {
		this.productDspId = productDspId;
	}

	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public String getDeletedIn() {
		return this.deletedIn;
	}

	public void setDeletedIn(String deletedIn) {
		this.deletedIn = deletedIn;
	}

	public short getProfitUnitCd() {
		return this.profitUnitCd;
	}

	public void setProfitUnitCd(short profitUnitCd) {
		this.profitUnitCd = profitUnitCd;
	}

	public short getSectionCd() {
		return this.sectionCd;
	}

	public void setSectionCd(short sectionCd) {
		this.sectionCd = sectionCd;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public Tdivision getTdivision() {
		return this.tdivision;
	}

	public void setTdivision(Tdivision tdivision) {
		this.tdivision = tdivision;
	}
	
	public Tproduct getTproduct() {
		return this.tproduct;
	}

	public void setTproduct(Tproduct tproduct) {
		this.tproduct = tproduct;
	}
	
	public TproductTowerTuwSubProduct getTproductTowerTuwSubProduct() {
		return this.tproductTowerTuwSubProduct;
	}

	public void setTproductTowerTuwSubProduct(TproductTowerTuwSubProduct tproductTowerTuwSubProduct) {
		this.tproductTowerTuwSubProduct = tproductTowerTuwSubProduct;
	}

	public String getDspNm() {
		return dspNm;
	}
	public void setDspNm(String dspNm) {
		this.dspNm = dspNm;
	
}
}
