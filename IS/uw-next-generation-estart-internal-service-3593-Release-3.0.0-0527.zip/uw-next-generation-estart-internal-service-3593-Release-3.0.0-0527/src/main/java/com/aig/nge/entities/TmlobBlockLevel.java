package com.aig.nge.entities;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.apache.openjpa.persistence.DataCache;


/**
 * The persistent class for the TMLOB_BLOCK_LEVEL database table.
 * 
 */
@Entity
@DataCache
@Table(name="TMLOB_BLOCK_LEVEL")
public class TmlobBlockLevel implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="BLOCK_LEVEL_ID")
	private int blockLevelId;
	
	@Column(name="MASTER_LOB_CD")
	private String masterLobCd;
	
	@Column(name="MASTER_LOB_NM")
	private String masterLobNm;
	
	@Column(name="COVERAGE_LINE_CD")
	private String coverageLineCd; 
	
	@Column(name="COVERAGE_LINE_NM")
	private String coverageLineNm; 
	
	@Column(name="COVERAGE_SUB_LINE_CD")
	private String coverageSubLineCd; 
	
	@Column(name="COVERAGE_SUB_LINE_NM")
	private String coverageSubLineNm; 	
	
	@Column(name="BLOCK_LEVEL_NO")
	private int blockLevelNo; 	
	
	@Column(name="CREATE_TS")
	private Timestamp createTs;

	@Column(name="CREATE_USER_ID")
	private String createUserId;

	@Column(name="UPDATE_TS")
	private Timestamp updateTs;

	@Column(name="UPDATE_USER_ID")
	private String updateUserId;

	public int getBlockLevelId() {
		return blockLevelId;
	}

	public void setBlockLevelId(int blockLevelId) {
		this.blockLevelId = blockLevelId;
	}

	public String getMasterLobCd() {
		return this.masterLobCd;
	}

	public void setMasterLobCd(String masterLobCd) {
		this.masterLobCd = masterLobCd;
	}

	public String getMasterLobNm() {
		return this.masterLobNm;
	}

	public void setMasterLobNm(String masterLobNm) {
		this.masterLobNm = masterLobNm;
	}

	public String getCoverageLineCd() {
		return this.coverageLineCd;
	}

	public void setCoverageLineCd(String coverageLineCd) {
		this.coverageLineCd = coverageLineCd;
	}

	public String getCoverageLineNm() {
		return this.coverageLineNm;
	}

	public void setCoverageLineNm(String coverageLineNm) {
		this.coverageLineNm = coverageLineNm;
	}

	public String getCoverageSubLineCd() {
		return this.coverageSubLineCd;
	}

	public void setCoverageSubLineCd(String coverageSubLineCd) {
		this.coverageSubLineCd = coverageSubLineCd;
	}

	public String getCoverageSubLineNm() {
		return this.coverageSubLineNm;
	}

	public void setCoverageSubLineNm(String coverageSubLineNm) {
		this.coverageSubLineNm = coverageSubLineNm;
	}

	public int getBlockLevelNo() {
		return blockLevelNo;
	}

	public void setBlockLevelNo(int blockLevelNo) {
		this.blockLevelNo = blockLevelNo;
	}

	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	
}