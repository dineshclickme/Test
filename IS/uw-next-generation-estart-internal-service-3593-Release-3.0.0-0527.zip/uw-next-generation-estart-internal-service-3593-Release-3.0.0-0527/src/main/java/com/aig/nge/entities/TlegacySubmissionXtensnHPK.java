package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the TLEGACY_SUBMISSION_XTENSN_HS database table.
 * 
 */
@Embeddable
public class TlegacySubmissionXtensnHPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="SUBMISSION_NO")
	private String submissionNo;

    @Temporal( TemporalType.TIMESTAMP)
	@Column(name="CREATE_HISTORY_TS")
	private java.util.Date createHistoryTs;

    public TlegacySubmissionXtensnHPK() {
    }
	public String getSubmissionNo() {
		return this.submissionNo;
	}
	public void setSubmissionNo(String submissionNo) {
		this.submissionNo = submissionNo;
	}
	public java.util.Date getCreateHistoryTs() {
		return this.createHistoryTs;
	}
	public void setCreateHistoryTs(java.util.Date createHistoryTs) {
		this.createHistoryTs = createHistoryTs;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof TlegacySubmissionXtensnHPK)) {
			return false;
		}
		TlegacySubmissionXtensnHPK castOther = (TlegacySubmissionXtensnHPK)other;
		return 
			this.submissionNo.equals(castOther.submissionNo)
			&& this.createHistoryTs.equals(castOther.createHistoryTs);

    }
    
	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.submissionNo.hashCode();
		hash = hash * prime + this.createHistoryTs.hashCode();
		
		return hash;
    }
}