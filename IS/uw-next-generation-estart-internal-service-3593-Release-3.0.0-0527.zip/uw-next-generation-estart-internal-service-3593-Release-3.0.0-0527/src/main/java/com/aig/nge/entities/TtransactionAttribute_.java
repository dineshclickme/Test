package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-02-19T16:13:04.729+0530")
@StaticMetamodel(TtransactionAttribute.class)
public class TtransactionAttribute_ {
	public static volatile SingularAttribute<TtransactionAttribute, TtransactionAttributePK> id;
	public static volatile SingularAttribute<TtransactionAttribute, String> attributeVal;
	public static volatile SingularAttribute<TtransactionAttribute, Timestamp> createTs;
	public static volatile SingularAttribute<TtransactionAttribute, String> createUserId;
	public static volatile SingularAttribute<TtransactionAttribute, Short> systemId;
	public static volatile SingularAttribute<TtransactionAttribute, Timestamp> updateTs;
	public static volatile SingularAttribute<TtransactionAttribute, String> updateUserId;
	public static volatile SingularAttribute<TtransactionAttribute, Tattribute> tattribute;
	public static volatile SingularAttribute<TtransactionAttribute, TtransactionVersion> ttransactionVersion;
}
