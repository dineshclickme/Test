package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-02-24T11:59:50.609+0530")
@StaticMetamodel(TtransactionComponentAtrbt.class)
public class TtransactionComponentAtrbt_ {
	public static volatile SingularAttribute<TtransactionComponentAtrbt, TtransactionComponentAtrbtPK> id;
	public static volatile SingularAttribute<TtransactionComponentAtrbt, String> attributeVal;
	public static volatile SingularAttribute<TtransactionComponentAtrbt, Timestamp> createTs;
	public static volatile SingularAttribute<TtransactionComponentAtrbt, String> createUserId;
	public static volatile SingularAttribute<TtransactionComponentAtrbt, Short> systemId;
	public static volatile SingularAttribute<TtransactionComponentAtrbt, Timestamp> updateTs;
	public static volatile SingularAttribute<TtransactionComponentAtrbt, String> updateUserId;
	public static volatile SingularAttribute<TtransactionComponentAtrbt, Tattribute> tattribute;
	public static volatile SingularAttribute<TtransactionComponentAtrbt, TtransactionComponent> ttransactionComponent;
}
