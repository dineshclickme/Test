package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the TERROR_MAPPING database table.
 * 
 */
@Entity
@Table(name="TERROR_MAPPING")
public class TerrorMapping implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private TerrorMappingPK id;

	@Column(name="CREATE_TS")
	private Timestamp createTs;

	@Column(name="CREATE_USER_ID")
	private String createUserId;

	@Column(name="UPDATE_TS")
	private Timestamp updateTs;

	@Column(name="UPDATE_USER_ID")
	private String updateUserId;

	//bi-directional many-to-one association to Terror
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="ERROR_ID")
	private Terror terror;

	//bi-directional many-to-one association to TlegacyError
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="LEGACY_ERROR_ID")
	private TlegacyError tlegacyError;

    public TerrorMapping() {
    }

	public TerrorMappingPK getId() {
		return this.id;
	}

	public void setId(TerrorMappingPK id) {
		this.id = id;
	}
	
	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public Terror getTerror() {
		return this.terror;
	}

	public void setTerror(Terror terror) {
		this.terror = terror;
	}
	
	public TlegacyError getTlegacyError() {
		return this.tlegacyError;
	}

	public void setTlegacyError(TlegacyError tlegacyError) {
		this.tlegacyError = tlegacyError;
	}
	
}