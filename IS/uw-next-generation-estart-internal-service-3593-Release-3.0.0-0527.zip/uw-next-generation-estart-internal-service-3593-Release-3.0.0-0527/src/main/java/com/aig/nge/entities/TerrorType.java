package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Set;


/**
 * The persistent class for the TERROR_TYPE database table.
 * 
 */
@Entity
@Table(name="TERROR_TYPE")
public class TerrorType implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="ERROR_TYPE_CD")
	private String errorTypeCd;

	@Column(name="CREATE_TS")
	private Timestamp createTs;

	@Column(name="CREATE_USER_ID")
	private String createUserId;

	@Column(name="ERROR_TYPE_DS")
	private String errorTypeDs;

	@Column(name="UPDATE_TS")
	private Timestamp updateTs;

	@Column(name="UPDATE_USER_ID")
	private String updateUserId;

	//bi-directional many-to-one association to Terror
	@OneToMany(mappedBy="terrorType")
	private Set<Terror> terrors;

	//bi-directional many-to-one association to TlegacyError
	@OneToMany(mappedBy="terrorType")
	private Set<TlegacyError> tlegacyErrors;

    public TerrorType() {
    }

	public String getErrorTypeCd() {
		return this.errorTypeCd;
	}

	public void setErrorTypeCd(String errorTypeCd) {
		this.errorTypeCd = errorTypeCd;
	}

	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public String getErrorTypeDs() {
		return this.errorTypeDs;
	}

	public void setErrorTypeDs(String errorTypeDs) {
		this.errorTypeDs = errorTypeDs;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public Set<Terror> getTerrors() {
		return this.terrors;
	}

	public void setTerrors(Set<Terror> terrors) {
		this.terrors = terrors;
	}
	
	public Set<TlegacyError> getTlegacyErrors() {
		return this.tlegacyErrors;
	}

	public void setTlegacyErrors(Set<TlegacyError> tlegacyErrors) {
		this.tlegacyErrors = tlegacyErrors;
	}
	
}