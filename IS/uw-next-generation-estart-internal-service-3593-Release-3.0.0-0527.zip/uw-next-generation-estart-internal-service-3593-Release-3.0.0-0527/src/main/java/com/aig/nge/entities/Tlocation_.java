package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SetAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-02-24T11:59:49.691+0530")
@StaticMetamodel(Tlocation.class)
public class Tlocation_ {
	public static volatile SingularAttribute<Tlocation, Integer> geographicLocationId;
	public static volatile SingularAttribute<Tlocation, Timestamp> createTs;
	public static volatile SingularAttribute<Tlocation, String> createUserId;
	public static volatile SingularAttribute<Tlocation, String> deletedIn;
	public static volatile SingularAttribute<Tlocation, String> locationCd;
	public static volatile SingularAttribute<Tlocation, String> locationNm;
	public static volatile SingularAttribute<Tlocation, Timestamp> updateTs;
	public static volatile SingularAttribute<Tlocation, String> updateUserId;
	public static volatile SetAttribute<Tlocation, Tbranch> tbranches;
	public static volatile SingularAttribute<Tlocation, Tlocation> tlocation;
	public static volatile SetAttribute<Tlocation, Tlocation> tlocations;
	public static volatile SingularAttribute<Tlocation, TlocationType> tlocationType;
	public static volatile SetAttribute<Tlocation, TmailingAddress> tmailingAddresses;
	public static volatile SetAttribute<Tlocation, TpartyAction> tpartyActions;
	public static volatile SetAttribute<Tlocation, TpartyDetail> tpartyDetails;
	public static volatile SetAttribute<Tlocation, TtransactionCmpntXpsrLoc> ttransactionCmpntXpsrLocs;
	public static volatile SetAttribute<Tlocation, TuserPrefernce> tuserPrefernces1;
	public static volatile SetAttribute<Tlocation, TuserPrefernce> tuserPrefernces2;
	public static volatile SingularAttribute<Tlocation, String> alternateLocationCd;
}
