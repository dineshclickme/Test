package com.aig.nge.dao;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.PersistenceException;

import com.aig.nge.entities.*;
import com.aig.nge.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.jpa.JpaSystemException;
import org.springframework.stereotype.Repository;

import com.aig.componentproductinput.ComponentProductData;
import com.aig.incomingdata.IncomingProductData.ComponentProducts.PotentialBlockingComponentProduct.ExistingComponentProduct;
import com.aig.nge.helper.CommonServiceHelper;
import com.aig.nge.helper.HistoryHelper;
import com.aig.nge.helper.ReserveProductHelper;
import com.aig.nge.helper.StatusAttributeHelper;
import com.aig.nge.model.BlockingSubmissionData;
import com.aig.nge.model.GetUnderWriterResponse;
import com.aig.nge.model.LimitsModel;
import com.aig.nge.model.ProductModel;
import com.aig.nge.utilities.AIGCIExceptionMsg;
import com.aig.nge.utilities.CurrencyConversionDynaCache;
import com.aig.nge.utilities.NGECommonUtil;
import com.aig.nge.utilities.NGEConstants;
import com.aig.nge.utilities.NGEDateUtil;
import com.aig.nge.utilities.NGEErrorCodes;
import com.aig.nge.utilities.NGEException;
import com.aig.nge.utilities.NGEProperties;
import com.aig.nge.utilities.NGESession;
import com.aig.nge.utilities.NGEValidations;
import com.aig.nge.utilities.SequenceNumberGeneration;
import com.aig.nge.wsdl.skeleton.Attribute;
import com.aig.nge.wsdl.skeleton.Attributes;
import com.aig.nge.wsdl.skeleton.SetProductStatus;import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * @author DineshKumar This DAO class is used for accessing the
 *         TransactionComponenetDetails related repositories Used repositories
 *         are : TransactionComponenet Repository
 * 
 */
@Repository
public class TransactionComponentDAO extends BaseDAO{

	private static final Logger logger = LogManager.getLogger(TransactionComponentDAO.class);
	/*@PersistenceContext
    private EntityManager em;*/
	
	@Autowired
	private TTransactionComponentLimitRepository transactionComponentLimitRepository;

	@Autowired
	private TSegmentRepository tSegmentRepository;

	@Autowired
	private NGEException nGEException;

	@Autowired
	private TTransactionComponentRepository tTransactionComponentRepository;

	@Autowired
	private TTransactionComponentStatusRepository tTransactionComponentStatusRepository;

	@Autowired
	private TTransactionComponentPolicyRepository transactionComponentPolicyRepository;

	@Autowired
	private TAlertBlockRepository tAlertBlockRepository;
	
	@Autowired
	private TComponentBlockRepository tComponentBlockRepository;
	
	@Autowired
	private TBlockRepository tBlockRepository;
	
	@Autowired
	private NGEValidations ngeValidations;
	
	@Autowired
	private CurrencyConversionDynaCache dynaCache;
	
	@Autowired
	private TransactionComponentChildEntriesBORepository transactionComponentChildEntriesBORepository;
	
	@Autowired
	private TransactionComponentPolicyAttributesRepository transactionComponentPolicyAttributesRepository;
	
	
	@Autowired
	private TMarketableProductRepository marketableProductRepository;
	
	@Autowired
	private SequenceNumberGeneration sequenceNumberGeneration;
	
	@Autowired
	private CommonDAO commonDAO;

	@Autowired
	private TCurrencyRepository tCurrencyRepository;
	
	@Autowired
	private TReasonRepository tReasonRepository;
	
	@Autowired
	private TStatusRepository tStatusRepository;
	
	@Autowired
	private TEventRepository tEventRepository;

	@Autowired
	private  TCompnentStatusAttributeRepository tCompnentStatusAttributeRepository;

	@Autowired
	private TTransactionComponentRelationRepository transactionComponentRelationRepository;
	
	@Autowired
	private  TTransactionComponentRltnRepository transactionComponentRltnRepository;
	
	@Autowired
	private  TComponentRelationTypeRepository componentRelationTypeRepository;
	
	@Autowired
	private StatusAttributeHelper statusAttributeHelper;
	
	@Autowired
	private ReasonDAO reasonDAO;
	
	@Autowired
	private ProductDAO productDAO;
	
	@Autowired
	private StatusDAO statusDAO;
	
	@Autowired
	private TTransactionComponentStatusRepository transactionComponentStatusRepository;
	
	@Autowired
	private TTransactionComponentPartyRepository tTransactionComponentPartyRepository;
	
	@Autowired
	private TProductTowerReasonRepository tProductTowerReasonRepository;
	
	@Autowired
	private ReserveProductHelper reserveProductHelper;
	
/*	@Autowired
	private NGEProperties ngeProperties;*/
	
	@Autowired
	private AttributeDAO attributeDAO;
	
	@Autowired
	private TTransactionComponentAtrbtRepository tTransactionComponentAtrbtRepository;
	
	@Autowired
	private TTableRepository tableRepository;
	
	@Autowired
	private TproductTowerAttributeUsageRepository productTowerAttributeUsageRepository; 
	
	@Autowired
	private TTransactionComponentAssetRepository transactionComponentAssetRepository;
	
	@Autowired
	private TusageTypeRepository usageTypeRepository;
	
	@Autowired
	private TTransactionComponentBranchRepository transactionComponentBranchRepository;
	
	@Autowired
	private TlegacyTrnsctnCmpntXtensnRepository trnsctnCmpntXtensnRepository;
	
	@Autowired
	private TTransactionComponentHRepository tTransactionComponentHRepository;
	
	@Autowired
	private TlegacyTrnsctnCmpntXtensnHRepository tlegacyTrnsctnCmpntXtensnHRepository;
	
	@Autowired
	private TTransactionCmpntBranchHRepository tTransactionCmpntBranchHRepository;
	
	@Autowired
	private NGEProperties ngeProperties;
	
	@Autowired
	private HistoryHelper historyHelper;
	
	@Autowired
	private PartyDAO partyDAO;
	
	@Autowired
	private TmlobExcludeBlockByTypeRepository mlobExcludeBlockByTypeRepository;
	
	/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
	@Autowired
	private CommonServiceHelper commonServiceHelper;
	/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */

	@Autowired
	private TLegacyWipQuoteRepository tLegacyWipQuoteRepository;
	
	public List<TtransactionComponent> getTransactionComponents(String underwriterId)
	{
		List<TtransactionComponent> transactionComponentList = tTransactionComponentRepository.findByUnderWriter(underwriterId);
		return transactionComponentList;
	}
	
	/**
	 * @author Dinesh Selvaraj
	 * @param productModel
	 * @return TtransactionComponentLimit
	 * @throws AIGCIExceptionMsg
	 * 
	 * This method returns TtransactionComponentLimit Data to validate overlapping limits with
	 * current attachment point and limit for the given product
	 */
	public List<TtransactionComponentLimit> fetchTransactionComponentList(ProductModel productModel)throws AIGCIExceptionMsg {
		List<TtransactionComponentLimit> transactionComponentLimitList;
		long transactionId=productModel.getTransactionId();
		short versionNo=productModel.getVersionNo();
		String segmentCode=productModel.getSegmentCode();
		String subSegmentCode=productModel.getSubSegmentCode();
		String componentProductCode=productModel.getComponentProductCode();
		String marketableProductCode=productModel.getMarketableProductCode();
		BigDecimal attachementPoint=productModel.getAttachmentPoint();
		String marketableProdSegCode = productModel.getMarketableProdSegmentCode();
		String marketableProdSubSegCode = productModel.getMarketableProdSubSegmentCode();
		
		/*Converting to upper case - PME - Starts*/
		segmentCode = segmentCode.toUpperCase();
		if(subSegmentCode != null)
		{
			subSegmentCode = subSegmentCode.toUpperCase();
		}
		componentProductCode = componentProductCode.toUpperCase();
		if(marketableProductCode != null)
		{
			marketableProductCode = marketableProductCode.toUpperCase();
		}
		if(marketableProdSegCode != null){
			
			marketableProdSegCode = marketableProdSegCode.toUpperCase();
		}
		if(marketableProdSubSegCode != null){
			
			marketableProdSubSegCode = marketableProdSubSegCode.toUpperCase();
		}
		
		/*Converting to upper case - PME - Ends*/
		if (ngeValidations.isNullOrEmptyOrSpaces(marketableProductCode)) {
			transactionComponentLimitList = transactionComponentLimitRepository
					.findByComponentProduct(String.valueOf(transactionId), versionNo,
							segmentCode, subSegmentCode, componentProductCode,
							attachementPoint);
		} else {
			transactionComponentLimitList = transactionComponentLimitRepository
					.findByMarketableComponent(String.valueOf(transactionId), versionNo,
							segmentCode, subSegmentCode, marketableProductCode,
							componentProductCode, attachementPoint, marketableProdSegCode, marketableProdSubSegCode);
		}
		return transactionComponentLimitList;
	}
	
	/**
	 * 
	 * @param productModel
	 * @return
	 * @throws AIGCIExceptionMsg
	 * This method is used to fetch the product irrespective of marketable product in order to check for overlapping limits
	 */
	public List<TtransactionComponentLimit> fetchTransactionComponentProductList(ProductModel productModel)throws AIGCIExceptionMsg {
		List<TtransactionComponentLimit> transactionComponentLimitList;
		long transactionId=productModel.getTransactionId();
		short versionNo=productModel.getVersionNo();
		String segmentCode=productModel.getSegmentCode();
		String subSegmentCode=productModel.getSubSegmentCode();
		String componentProductCode=productModel.getComponentProductCode();		
		BigDecimal attachementPoint=productModel.getAttachmentPoint();
		
		/*Converting to upper case - PME - Starts*/
		segmentCode = segmentCode.toUpperCase();
		if(subSegmentCode != null)
		{
			subSegmentCode = subSegmentCode.toUpperCase();
		}
		componentProductCode = componentProductCode.toUpperCase();
		/*Converting to upper case - PME - Ends*/
		
			transactionComponentLimitList = transactionComponentLimitRepository
					.fetchTransactionComponentProductList(String.valueOf(transactionId), versionNo,
							segmentCode, subSegmentCode, componentProductCode,
							attachementPoint);
		
		return transactionComponentLimitList;
	}
	
	
	/**
	 * @author Bharath K S
	 * @param transactionId
	 * @param versionNo
	 * @param segmentCode
	 * @param subSegmentCode
	 * @param componentProductCode
	 * @param marketableProductCode
	 * @param attachmentPoint
	 * @throws AIGCIExceptionMsg
	 *             This method is used to fetch the transaction component
	 *             details from TTRANSACTION_COMPONENT_LIMIT (table), TTRANSACTION_COMPONENT (table) and TCOMPONENT_PRODUCT_LOOKUP(view).
	 *             It will get the various product input parameters and identify the correct transaction component for the provided input.
	 *             Exception will be thrown if no component is available or there are more than one components.
	 *             In case if the transaction component is having multiple currency (USD & NON-USD), then USD will be ignored.
	 *             **2020 SCUP Release - MLOB change - US145615 **
	 *             validates incoming MLOB details in request with DB.
	 *             
	 */
	public TtransactionComponent fetchTransactionComponentDetails(ProductModel productModel)throws AIGCIExceptionMsg {
		
		List<TtransactionComponentLimit> transactionComponentLimitList;
		List<TtransactionComponent> transactionComponentFinalList = new ArrayList<TtransactionComponent>();
		TtransactionComponent transactionComponent = null ;
		boolean dataMisMatch = false;
		boolean mlobDataMisMatch = false;
		
		int usdCount = 0;
		
		// Find product by Transaction Component ID - Requested for Coexistence Layer to avoid complexity
		if(productModel.getTransactionComponentId() != null){
			transactionComponent = tTransactionComponentRepository.findByTransactionComponentId(productModel.getTransactionComponentId());
			if(transactionComponent == null){
				
				ngeException.throwException(NGEErrorCodes.COMPONENT_NOT_FOUND, NGEErrorCodes.ERROR_TYPE,
						"Could not get transaction component for the data passed", null);
			}
			else{
				
				// Validate the input business parameters against the fetched product
				if(!productModel.getSegmentCode().equalsIgnoreCase(transactionComponent.getVcomponentProduct().getComponentSegmentCd())){
					
					dataMisMatch = true;
				}
				
				if(productModel.getSubSegmentCode() != null){
					
					if(!productModel.getSubSegmentCode().equalsIgnoreCase(transactionComponent.getVcomponentProduct().getComponentSubSegmentCd())){
						
						dataMisMatch = true;
					}
				}
				
				if(productModel.getMarketableProductCode() != null){
					
					if(!productModel.getMarketableProductCode().equalsIgnoreCase(transactionComponent.getVcomponentProduct().getMarketableProductCd())){
						
						dataMisMatch = true;
					}
					
					if(!productModel.getMarketableProdSegmentCode().equalsIgnoreCase(transactionComponent.getVcomponentProduct().getMarketableProductSegmentCd())){
						
						dataMisMatch = true;
					}
					
					if(productModel.getMarketableProdSubSegmentCode() != null){
						
						if(!productModel.getMarketableProdSubSegmentCode().equalsIgnoreCase(transactionComponent.getVcomponentProduct().getMarketableProductSubSgmtCd())){
							
							dataMisMatch = true;
						}
					}
					
					if(!productModel.getComponentProductCode().equalsIgnoreCase(transactionComponent.getVcomponentProduct().getMarketableProductCmpntCd())){
						
						dataMisMatch = true;
					}
				}
				else{
					
					if(!productModel.getComponentProductCode().equalsIgnoreCase(transactionComponent.getVcomponentProduct().getTuwSubProductCd())){
					
						dataMisMatch = true;
					}
				}
				
				if(productModel.getAttachmentPoint() != null){
					
					if(transactionComponent.getTtransactionComponentLimits() != null){
						
						Set<TtransactionComponentLimit> transactionComponentLimitSet = transactionComponent.getTtransactionComponentLimits();
						
						if(transactionComponentLimitSet.size() == 1){
							
							for(TtransactionComponentLimit transactionComponentLimitData : transactionComponentLimitSet){
								
								BigDecimal attachPointAmount = transactionComponentLimitData.getAttachmentPointAm();
								if(!(attachPointAmount.compareTo(productModel.getAttachmentPoint()) == 0)){
									
									dataMisMatch = true;
								}
							}
						}
						else if(transactionComponentLimitSet.size() == 2){
							
							for(TtransactionComponentLimit transactionComponentLimitData : transactionComponentLimitSet){
								
								String currencyCode = transactionComponentLimitData.getTcurrency().getCurrencyCd();
								
								if(!currencyCode.equalsIgnoreCase(NGEConstants.USD)){
									
									BigDecimal attachPointAmount = transactionComponentLimitData.getAttachmentPointAm();
									if(!(attachPointAmount.compareTo(productModel.getAttachmentPoint()) == 0)){
										
										dataMisMatch = true;
									}
								}
							}
						}
						
					}
				}
				/*2020 SCUP Release - MLOB change - US145615- starts */
				if(NGESession.getSessionData().isMlobSys()){
					
					if (!productModel.getMasterLineOfCode().equalsIgnoreCase(transactionComponent.getMasterLobCd())) {
						mlobDataMisMatch = true;
					}
					
					if (!productModel.getCoverageLineCode().equalsIgnoreCase(transactionComponent.getCoverageLineCd())) {
						mlobDataMisMatch = true;
					}					
				}
				/*2020 SCUP Release - MLOB change - US145615- ends */
			}
			
			if(dataMisMatch){
				
				ngeException.throwException(NGEErrorCodes.COMPONENT_NOT_FOUND, NGEErrorCodes.ERROR_TYPE,
						"Could not get transaction component for the data passed", null);
			}
			
			if(mlobDataMisMatch){
				
				ngeException.throwException(NGEErrorCodes.MLOB_COMPONENT_NOT_FOUND_IN_DB, NGEErrorCodes.ERROR_TYPE,
						"Could not get transaction component for the MLOB data passed", null);
				
			}
		}
		else{
			
			if(productModel.getAttachmentPoint()==null){
				productModel.setAttachmentPoint(BigDecimal.ZERO);
			}
			if(ngeValidations.isNullOrEmptyOrSpaces(productModel.getSubSegmentCode())){
				productModel.setSubSegmentCode(null);
			}
					
			if(ngeValidations.isNullOrEmptyOrSpaces(productModel.getMarketableProdSubSegmentCode())){
				productModel.setMarketableProdSubSegmentCode(null);
			}
		
		transactionComponentLimitList = fetchTransactionComponentList(productModel);

		if (transactionComponentLimitList.size() == 0) {
			ngeException.throwException(NGEErrorCodes.COMPONENT_NOT_FOUND, NGEErrorCodes.ERROR_TYPE,
					"Could not get transaction component for the data passed", null);
		} 
		else if (transactionComponentLimitList.size() == 1) {
			transactionComponent = transactionComponentLimitList.get(0).getTtransactionComponent();
		} 
		else 
		{
			for(TtransactionComponentLimit transactionComponentLimit : transactionComponentLimitList)
			{
				//NON-USD currencies have to be selected. Hence removing the USD currency record.
				if(!transactionComponentLimit.getTcurrency().getCurrencyCd().equalsIgnoreCase(NGEConstants.USD))
				{
					transactionComponentFinalList.add(transactionComponentLimit.getTtransactionComponent());
				}
				else
				{
					usdCount++;
				}
			}
			//After removing the USD currency, if the size is zero, then we are unable to identify the correct product.
			if(transactionComponentFinalList.size() == 0)
			{
				if(usdCount > 0)
				{
					ngeException.throwException(NGEErrorCodes.MULTIPLE_PRODUCTS_FOUND, NGEErrorCodes.ERROR_TYPE,
							"Multiple Component products available. Please verify the inputs", null);
				}
				else
				{
					ngeException.throwException(NGEErrorCodes.COMPONENT_NOT_FOUND, NGEErrorCodes.ERROR_TYPE,
						"Could not get transaction component for the data passed", null);
				}
			}
			//Even after removing the USD currency, if the size is still more than one, then we are unable to identify the correct product.
			else if (transactionComponentFinalList.size() >1) {
				ngeException.throwException(NGEErrorCodes.MULTIPLE_PRODUCTS_FOUND, NGEErrorCodes.ERROR_TYPE,
						"Multiple Component products available. Please verify the inputs", null);
			}
			else
			{
				transactionComponent = transactionComponentFinalList.get(0);
			}
		}
	}

		return transactionComponent;
}
	

	/**
	 * @author Bhakavathy Adithan B R
	 * @param transactionid
	 * @param transactionVersionSqn
	 * @throws AIGCIExceptionMsg
	 *             This Method is used to fetch the number of Products under a
	 *             transaction
	 */
	public List<TtransactionComponent> fetchProductsUnderATransaction(long transactionid,
			short transactionVersionSqn, String deletedindicator) throws AIGCIExceptionMsg {		
		List<TtransactionComponent> productList = new ArrayList<TtransactionComponent>();
		productList = tTransactionComponentRepository
				.getTransactionComponent(Long.toString(transactionid),
						transactionVersionSqn,deletedindicator);		 
		return productList;
	}

	/**
	 * @author Bhakavathy Adithan B R
	 * @param segmentCd
	 * @throws AIGCIExceptionMsg
	 *             This method is used to validate Segment and Sub-Segment Code
	 */
	public void validateSegmentCd(String segmentCd) throws AIGCIExceptionMsg {
		List<Object> errorReason=new ArrayList<Object>();
		errorReason.add(segmentCd);
		Tsegment tSegment = null;
		tSegment = tSegmentRepository.findOne(segmentCd);
		if (tSegment == null) {
			nGEException.throwException(NGEErrorCodes.SEGEMNT_NOT_AVAILABLE,
					NGEErrorCodes.ERROR_TYPE, null, errorReason);
		}

	}
	
	/**
	 * @author Bhakavathy Adithan B R
	 * @param Sub-SegmentCd
	 * @throws AIGCIExceptionMsg
	 *             This method is used to validate Segment and Sub-Segment Code
	 */
	public void validateSubSegmentCd(String subSegmentCd) throws AIGCIExceptionMsg {
		List<Object> errorReason=new ArrayList<Object>();
		errorReason.add(subSegmentCd);
		Tsegment tSegment = null;
		tSegment = tSegmentRepository.findOne(subSegmentCd);
		if (tSegment == null) {
			nGEException.throwException(NGEErrorCodes.SUB_SEGEMNT_NOT_AVAILABLE,
					NGEErrorCodes.ERROR_TYPE, null, errorReason);
		}

	}

	/**
	 * @param transactionComponentId
	 * @return TtransactionComponentStatus This method is used to find whether
	 *         the particular Transaction Component has any valid lifecycle and
	 *         reservation status
	 */
	public List<TtransactionComponentStatus> fetchTransactionComponentStatus(
			String transactionComponentId) {
		return tTransactionComponentStatusRepository
				.findByTtransactionComponentStatusPKTransactionComponentId(transactionComponentId);
		}
	
	public TtransactionComponentStatus fetchTransactionComponentStatusData(
			String transactionComponentId,String statusTypeNm) {
		return tTransactionComponentStatusRepository
				.findByTransactionComponentIdAndStatusTypeNm(transactionComponentId,statusTypeNm.toUpperCase());
		}
	
	/**
	 * @param tComponentStatus - Set of Ttransaction_Component_Status Table objects 
	 * @throws AIGCIExceptionMsg
	 * 
	 * Thsi method is used to delete the life-cycle status and reservation condition of a product
	 * from Ttransaction_Component_Status table
	 * 
	 */
	public void deleteProductLifeCycleStatusAndReservationCondition(Set<TtransactionComponentStatus> tComponentStatus) throws AIGCIExceptionMsg
	{
		try
		{
			tTransactionComponentStatusRepository.delete(tComponentStatus);
		}
		catch(Exception e)
		{
			/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
			if(commonServiceHelper.checkForRetryExceptions(e, 115, NGEConstants.CatchExceptionTypes.THROW_HANDLED_EXCEPTION))
			{
				logger.error("checkForRetryExceptions returned true");
			}
			/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
			logger.error("Exception Message :" +e.getMessage());
			ngeException.throwException(NGEErrorCodes.REMOVE_PRODUCT_DATABASE_UPDATE_FAILURE,
					NGEErrorCodes.ERROR_TYPE, null, null);
		}
	}
	
	
	/**
	 * 
	 * @author Bhakavathy Adithan. B.R.
	 * 
	 * @param tComponentStatus - Set of Ttransaction_Component_Status Table objects 
	 * @throws AIGCIExceptionMsg
	 * 
	 * This method is used to delete the life-cycle status OR Reservation Condition of a product
	 * from Ttransaction_Component_Status table
	 * 
	 */
	public void deleteProductLifeCycleStatusOrReservationCondition(TtransactionComponentStatus tComponentStatus) throws AIGCIExceptionMsg
	{
		try
		{
			tTransactionComponentStatusRepository.delete(tComponentStatus);
		}
		catch(Exception e)
		{
			/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
			if(commonServiceHelper.checkForRetryExceptions(e, 116, NGEConstants.CatchExceptionTypes.THROW_HANDLED_EXCEPTION))
			{
				logger.error("checkForRetryExceptions returned true");
			}
			/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
			logger.error("Exception Message :" +e.getMessage());
			ngeException.throwException(NGEErrorCodes.REMOVE_PRODUCT_DATABASE_UPDATE_FAILURE,
					NGEErrorCodes.ERROR_TYPE, null, null);
		}
	}

	
	/**
	 * @param rTransactionComponentEntity - Transaction Component Entry to soft delete
	 * @return - Transaction Componnet table object after updating the Deleted_in indicator
	 * @throws AIGCIExceptionMsg
	 * 
	 * 		   This method is used to Soft-delete the Transaction
	 *         Component Id associated with the Transaction Id and Version
	 *         Number
	 * 
	 */
	public TtransactionComponent modifyTransactionComponentDeletedInFlagToY(TtransactionComponent rTransactionComponentEntity) throws AIGCIExceptionMsg 
	{
		try
		{
			// Modify the Deleted Indicator of Ttransaction_Component Table
			java.util.Date date= new java.util.Date();
			rTransactionComponentEntity.setDeletedIn(NGEConstants.YES);
			rTransactionComponentEntity.setUpdateUserId(NGESession.getSessionData().getUserId());
			rTransactionComponentEntity.setUpdateTs(new Timestamp(date.getTime()));
			//Abul changes starts
			rTransactionComponentEntity.setSystemId(NGESession.getSessionData().getSystem().getSystemId());
			//Abul changes ends
			rTransactionComponentEntity = tTransactionComponentRepository.save(rTransactionComponentEntity);
		}
		catch(Exception e)
		{	
			/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
			if(commonServiceHelper.checkForRetryExceptions(e, 117, NGEConstants.CatchExceptionTypes.THROW_HANDLED_EXCEPTION))
			{
				logger.error("checkForRetryExceptions returned true");
			}
			/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
			logger.error("Exception Message :" +e.getMessage());
			ngeException.throwException(NGEErrorCodes.REMOVE_PRODUCT_DATABASE_UPDATE_FAILURE,
					NGEErrorCodes.ERROR_TYPE, null, null);
		}
		return rTransactionComponentEntity;
	}
	/**
	 * @author Padma E
	 * @param policyId
	 * @param transactionComponentId
	 * @return
	 * @throws AIGCIExceptionMsg
	 *             this method is used to get the transaction component policy
	 *             information by using the policyId, transactionComponentId
	 */

	public TtransactionComponentPolicy getTransactionComponentPolicy(
			int policyId, String transactionComponentId) {
		TtransactionComponentPolicy transactionComponentPolicy = new TtransactionComponentPolicy();

		TtransactionComponentPolicyPK transactionComponentPolicyPK = new TtransactionComponentPolicyPK();
		transactionComponentPolicyPK.setPolicyId(policyId);
		transactionComponentPolicyPK.setTransactionComponentId(transactionComponentId);
		// validate if already associated
		transactionComponentPolicy = transactionComponentPolicyRepository
				.findOne(transactionComponentPolicyPK);
		return transactionComponentPolicy;
	}

	/**
	 * @author Padma E
	 * @param transactionCompPolicy
	 * @return
	 * @throws AIGCIExceptionMsg
	 *             this method is used to save the transaction component policy
	 *             information in Ttransaction_component_policy
	 */

	public TtransactionComponentPolicy saveTransactionComponentPolicy(
			TtransactionComponentPolicy transactionCompPolicy) {
		transactionComponentPolicyRepository.save(transactionCompPolicy);
		return transactionCompPolicy;
	}

	public TtransactionComponent getTransactionComponent(
			String transactionComponentId) {
		TtransactionComponent transactionComp = null;
		transactionComp = tTransactionComponentRepository
				.findOne(transactionComponentId);
		return transactionComp;
	}
	
	public List<TtransactionComponent> getTransactionComponent(
			List<String> transactionComponentIdList) {
		List<TtransactionComponent> transactionComp = null;
		transactionComp = tTransactionComponentRepository
				.findByTransactionComponentId(transactionComponentIdList);
		return transactionComp;
	}
	
	public List <TtransactionComponent> findByTransactionIdAndVersionSqn(String transactionId,short versionNo,String deletedindicator) {
	List<TtransactionComponent> transactionComponentList=null;
	transactionComponentList  = tTransactionComponentRepository.getTransactionComponent(transactionId,versionNo,deletedindicator);
		return transactionComponentList;
	}

	public TtransactionComponent getTransactionComponentBytransactionCompId(String transCompId){
		TtransactionComponent transactionComp=	tTransactionComponentRepository.findOne(transCompId);
		return transactionComp;
	}


	
	
	
	
	public void deleteBlockDetails(String transactionComponentId) throws AIGCIExceptionMsg
	{						
		deleteAlertBlockDetails(transactionComponentId);
		deleteProductBlockDetails(transactionComponentId);
		deleteBlocks(transactionComponentId);
		
	}
	
	public List<Tblock> fetchBlockDetails(String transactionComponentId, String blockTypeNm){
		List<Tblock> tBlockList = tBlockRepository.findByTransCompIdandBlockTypeNm(transactionComponentId, blockTypeNm.toUpperCase());
		return tBlockList;
	}
	
	public Tsegment findSegmentDetails(String segmentCd) {
		// TODO Auto-generated method stub
		Tsegment segmentData = null;
		segmentData = tSegmentRepository.findOne(segmentCd);
		return segmentData;
	}
	
	public TmarketableProduct findMarketableProduct(String segmentCd,
			String subSegmentCd, String marketableProductCd) throws AIGCIExceptionMsg {
		// TODO Auto-generated method stub
		TmarketableProduct marketableProduct = null;
		marketableProduct = marketableProductRepository.findBySegmentCdAndSubSegmentCdAndMarketableProductCd(segmentCd,subSegmentCd,marketableProductCd);
		if(marketableProduct==null){
				ngeException.throwException(NGEErrorCodes.MARKETABLE_PRODUCT_DETAILS_REQUIERD, NGEErrorCodes.ERROR_TYPE,
						null, null);
		}
		return marketableProduct;
	}
	
	public void deleteAlertBlockDetails(String transactionComponentId) {
		// TODO Auto-generated method stub	
		int tblockNo = 0;
		List<Tblock> tBlockList = fetchBlockDetails(transactionComponentId, NGEConstants.ALERT_BLOCK);
		if(tBlockList.size()>0){
			for(Tblock tblock:tBlockList){
				tblockNo = tblock.getBlockNo();
				TalertBlock alertBlock = tAlertBlockRepository.findOne(tblockNo);
				if(alertBlock != null){
						tAlertBlockRepository.delete(alertBlock);
				}				
			}
		}
		
	}
	
	public void deleteBlocks(String transactionComponentId) {
		// TODO Auto-generated method stub			
		List<Tblock> tBlockList = tBlockRepository.findByTransactionComponentId(transactionComponentId); 		
		if(tBlockList.size()>0){
			for(Tblock tblock:tBlockList){				
				tBlockRepository.delete(tblock);									
			}
		}		
	}
	
	public void deleteProductBlockDetails(String transactionComponentId) {
		// TODO Auto-generated method stub		
		int tblockNo = 0;
		List<Tblock> tBlockList = fetchBlockDetails(transactionComponentId, NGEConstants.PRODUCT_BLOCK);	
		if(tBlockList.size()>0){
			for(Tblock tblock:tBlockList){
				tblockNo = tblock.getBlockNo();
				List<TcomponentBlock> componentBlockList = tComponentBlockRepository.findByBlockNo(tblockNo);
				if(componentBlockList.size()>0){
					for(TcomponentBlock componentBlock:componentBlockList){
						tComponentBlockRepository.delete(componentBlock);
					}
				}							
			}
		}
	}

	/**
	 * @author Dinesh Selvaraj
	 * @param tTransactionComponentData
	 * @return
	 * @throws JpaSystemException
	 * @throws AIGCIExceptionMsg
	 * This method saves transaction component data
	 * into transaction component table
	 */
	public TtransactionComponent saveTtransactionComponent(TtransactionComponent tTransactionComponentData) throws JpaSystemException, AIGCIExceptionMsg
	{
		if(tTransactionComponentData==null){		
			ngeException.throwException("ERR30015", NGEErrorCodes.ERROR_TYPE, null,null); /*EXC Unable to insert data into  Transaction Component Table */
		}else{
			tTransactionComponentData=tTransactionComponentRepository.save(tTransactionComponentData);	
		}
		return tTransactionComponentData;
	}
/*	
	*//**
	 * @author Dinesh Selvaraj
	 * @param componentProductID
	 * @param componentProductDetailID
	 * @param transactionId
	 * @param transactionVersionSqnShrt
	 * @return tTransactionComponentData
	 * @throws JpaSystemException
	 * @throws AIGCIExceptionMsg
	 * This method is used to get product data using product ID and detail ID
	 *//*
	public List<TtransactionComponent> getTransactionComponentByCompProdIDAndDetailID(int componentProductID,int componentProductDetailID,String transactionId,short transactionVersionSqnShrt) throws JpaSystemException, AIGCIExceptionMsg
	{
		List<TtransactionComponent> tTransCompData = null;
		if(componentProductID==0 || componentProductDetailID==0){		
			ngeException.throwException(NGEErrorCodes.NO_PRODUCTS_FOUND,NGEErrorCodes.ERROR_TYPE, "Unable to add the product. Products are not available in NGE for the given request",null); 
		}else{
			 tTransCompData=tTransactionComponentRepository.findTransactionComponentByProdIDAndDetailID(componentProductID,componentProductDetailID,transactionId,transactionVersionSqnShrt);	
		}
		if(tTransCompData==null){
			ngeException.throwException(NGEErrorCodes.NO_PRODUCTS_FOUND,NGEErrorCodes.ERROR_TYPE, "Unable to add the product. Products are not available in NGE for the given request",null);
		}
		
		return tTransCompData;
	}
	*/
	/**
	 * @author Dinesh Selvaraj
	 * @param TpartyData
	 * @param tTransactionComponentData
	 * @param systemID
	 * @param createUserId
	 * @return tTransactionComponentData
	 * @throws AIGCIExceptionMsg
	 * This method inserts additional insured into TTRANSACTION_COMPONENT_PARTY Table 
	 */
	public Set<TtransactionComponentParty> insertIntoTransactionComponentParty(Tparty TpartyData,TtransactionComponent tTransactionComponentData, Set<TtransactionComponentParty> tTransactionComponentPartySet, short partySqn) throws AIGCIExceptionMsg{
			java.util.Date date= new java.util.Date();
			//Set<TtransactionComponentParty> tTransactionComponentPartySet=new HashSet<TtransactionComponentParty>();
			Trole tRoleData=new Trole();
			tRoleData=commonDAO.getRole(NGEConstants.ROLE.ADDITIONAL_NAMED_INSURED);
		 	

		 	/*HashMap<String, String> sequenceRequestMap = new HashMap<String, String>();
			HashMap<String, Object> sequenceValueMap = new HashMap<String, Object>();
			sequenceRequestMap.put("PARTY_SQN", "short");
			sequenceValueMap = sequenceNumberGeneration.getNextSequenceNumber(sequenceRequestMap);
			partySqn = Short.parseShort(sequenceValueMap.get("PARTY_SQN").toString());*/
						
			//partySqn = (short)findMaxAdditionalPartySequence(tTransactionComponentData.getTransactionComponentId(), NGEConstants.ROLE.ADDITIONAL_NAMED_INSURED);
									
		    if(TpartyData!=null){
				TtransactionComponentParty tTransactionComponentPartyData=new TtransactionComponentParty();
				TtransactionComponentPartyPK tTransactionComponentPartyPKData=new TtransactionComponentPartyPK();
				tTransactionComponentPartyPKData.setPartySqn(partySqn);
				tTransactionComponentPartyPKData.setTransactionComponentId(tTransactionComponentData.getTransactionComponentId());
				tTransactionComponentPartyData.setId(tTransactionComponentPartyPKData);
				tTransactionComponentPartyData.setTparty(TpartyData);
				tTransactionComponentPartyData.setTrole(tRoleData);
				tTransactionComponentPartyData.setSystemId(NGESession.getSessionData().getSystem().getSystemId());
				tTransactionComponentPartyData.setDeletedIn(NGEConstants.NO);
				tTransactionComponentPartyData.setCreateUserId(NGESession.getSessionData().getUserId());
				tTransactionComponentPartyData.setCreateTs(new Timestamp(date.getTime()));
				tTransactionComponentPartySet.add(tTransactionComponentPartyData);
			}
			return tTransactionComponentPartySet;
		
		}
	
	public Short findMaxAdditionalPartySequence(String transactionComponentId, String roleNm)throws JpaSystemException{
		Short maxSequenceNo = 0;
 		maxSequenceNo = tTransactionComponentPartyRepository.findMaxAdditionalPartySequence(transactionComponentId, roleNm);
		 if(maxSequenceNo == null)
		 {
			 maxSequenceNo = 0;
		 }
 		return maxSequenceNo;
 	}
	
	
	/**
	 * @author Dinesh Selvaraj
	 * @return Seq No
	 * @throws AIGCIExceptionMsg
	 * This method is used to get transaction component ID sequence
	 */
	public String getTransactionComponentIdSequence() throws AIGCIExceptionMsg{
		 HashMap<String, String> sequenceRequestMap = new HashMap<String, String>();
	        HashMap<String, Object> sequenceValueMap = new HashMap<String, Object>();
	     long transactionComponentSeqInitial=1;
         sequenceRequestMap.put("TRANSACTION_COMPONENT_ID", "long");
         sequenceValueMap = sequenceNumberGeneration.getNextSequenceNumber(sequenceRequestMap);
         transactionComponentSeqInitial = Long.parseLong(sequenceValueMap.get("TRANSACTION_COMPONENT_ID").toString());
         if(transactionComponentSeqInitial<0){
         	ngeException.throwException("ERR30080", NGEErrorCodes.ERROR_TYPE, null,null);
         }
         return String.valueOf(transactionComponentSeqInitial);
	}
	/**
	 * @author Dinesh Selvaraj
	 * @param attributeID
	 * @param attributeValue
	 * @param transactionComponentID
	 * @param systemId
	 * @param createUserID
	 * This method is used to save component product level 
	 * attributes into TTRANSACTION_COMPONENT_ATRBT Table
	 */
	public TtransactionComponentAtrbt insertTransactionComponenetAttributes(Tattribute tAttributeData,String attributeValue,TtransactionComponent tTransactionComponentData, short attributeIdSequence) {
		java.util.Date date= new java.util.Date();
		Timestamp createTS =new Timestamp(date.getTime());
				
		TtransactionComponentAtrbt tTransactionComponentAtrbtData=new TtransactionComponentAtrbt();
		TtransactionComponentAtrbtPK tTransactionComponentAtrbtPKData=new TtransactionComponentAtrbtPK();
		
		tTransactionComponentAtrbtPKData.setTransactionComponentId(tTransactionComponentData.getTransactionComponentId());
		tTransactionComponentAtrbtPKData.setAttributeId(tAttributeData.getAttributeId());
		tTransactionComponentAtrbtPKData.setAttributeSqn(attributeIdSequence);
		tTransactionComponentAtrbtData.setId(tTransactionComponentAtrbtPKData);
		tTransactionComponentAtrbtData.setSystemId(NGESession.getSessionData().getSystem().getSystemId());
		tTransactionComponentAtrbtData.setAttributeVal(attributeValue);
		tTransactionComponentAtrbtData.setTattribute(tAttributeData);
		tTransactionComponentAtrbtData.setCreateUserId(NGESession.getSessionData().getUserId());
		tTransactionComponentAtrbtData.setCreateTs(createTS);
		
		return tTransactionComponentAtrbtData;
		}

	public Tcurrency getCurrencyData(String currencyCd) throws AIGCIExceptionMsg{
		Tcurrency currencyData=null;
		currencyData=tCurrencyRepository.findByCurrencyCd(currencyCd);
		if(currencyData==null){
			ngeException.throwException(NGEErrorCodes.INVALID_CURRENCY, NGEErrorCodes.ERROR_TYPE, "Invalid Currency. Given Currency is either blank or does not exist in NGE",null);
		}
		return currencyData;
	}

	/**
	 * @author Dinesh Selvaraj
	 * @param limitsModel
	 * @param tTransactionComponentData
	 * @return tTransactionComponentData
	 * @throws AIGCIExceptionMsg
	 * 
	 * This method inserts the records into TTRANSACTION_COMPONENT_LIMIT Table
	 * 
	 */
	public TtransactionComponent insertIntoTransactionComponentLimit(LimitsModel limitsModel,TtransactionComponent tTransactionComponentData) throws AIGCIExceptionMsg{
		java.util.Date date= new java.util.Date(); 
		Set<TtransactionComponentLimit> tTransactionComponentLimitSet=new HashSet<TtransactionComponentLimit>();
		TtransactionComponentLimitPK tTransactionComponentLimitPKData=new TtransactionComponentLimitPK();
		TtransactionComponentLimit tTransactionComponentLimitUsdData=new TtransactionComponentLimit();
		TtransactionComponentLimit tTransactionComponentLimitLocalData=new TtransactionComponentLimit();
		String aigCurrencyCd=null;
		if(limitsModel.gettCurrencyData()!=null){
			
			/*If currency code is non USD , Insert the records directly into TTRANASCTION_COMPONENT_LIMIT Table through tTransactionComponentData */
			tTransactionComponentLimitPKData.setTransactionComponentId(tTransactionComponentData.getTransactionComponentId());
			tTransactionComponentLimitPKData.setCurrencyId(limitsModel.gettCurrencyData().getCurrencyId());
			tTransactionComponentLimitLocalData.setId(tTransactionComponentLimitPKData);
			tTransactionComponentLimitLocalData.setLimitAm(limitsModel.getLimitAmount());
			tTransactionComponentLimitLocalData.setAttachmentPointAm(limitsModel.getAttachmentPointAmount());
			tTransactionComponentLimitLocalData.setPremiumAm(limitsModel.getPremiumAmount());
			tTransactionComponentLimitLocalData.setTechnicalPriceAm(limitsModel.getTechnicalPriceAmount());
			tTransactionComponentLimitLocalData.setExpiringPremiumAm(limitsModel.getExpiringPremiumAmount());
			tTransactionComponentLimitLocalData.setSystemId(NGESession.getSessionData().getSystem().getSystemId());
			tTransactionComponentLimitLocalData.setCreateUserId(limitsModel.getUserId());
			tTransactionComponentLimitLocalData.setCreateTs(new Timestamp(date.getTime()));
			tTransactionComponentLimitLocalData.setTtransactionComponent(tTransactionComponentData);
			tTransactionComponentLimitLocalData.setTcurrency(limitsModel.gettCurrencyData());
			tTransactionComponentLimitSet.add(tTransactionComponentLimitLocalData);
			
			/*If currency code is other than USD , call currency conversion service and 
			 *insert the USD records into TTRANASCTION_COMPONENT_LIMIT Table through tTransactionComponentData */
			if(!NGEConstants.USD.equalsIgnoreCase(limitsModel.gettCurrencyData().getCurrencyCd())){
				aigCurrencyCd = limitsModel.gettCurrencyData().getAigCurrencyCd();
				
				Tcurrency usCurrencyData=getCurrencyData(NGEConstants.USD);
				/*Currency Conversion Service Call*/
				HashMap<String, BigDecimal> sourceMap = null;
				sourceMap = dynaCache.getCurrencyRate();
				if(sourceMap!=null && !sourceMap.isEmpty()){
				
				BigDecimal rate = sourceMap.get(aigCurrencyCd);	
				tTransactionComponentLimitPKData=new TtransactionComponentLimitPK();
				tTransactionComponentLimitPKData.setTransactionComponentId(tTransactionComponentData.getTransactionComponentId());
				tTransactionComponentLimitPKData.setCurrencyId(usCurrencyData.getCurrencyId()); /* USD CurrencyID*/
				tTransactionComponentLimitUsdData.setId(tTransactionComponentLimitPKData);
				
				if(rate!=null){
					tTransactionComponentLimitUsdData.setLimitAm(limitsModel.getLimitAmount().multiply(rate));
					tTransactionComponentLimitUsdData.setAttachmentPointAm(limitsModel.getAttachmentPointAmount().multiply(rate));
					if(limitsModel.getPremiumAmount() != null)
					{
						tTransactionComponentLimitUsdData.setPremiumAm(limitsModel.getPremiumAmount().multiply(rate));
					}
					if(limitsModel.getTechnicalPriceAmount() != null)
					{
						tTransactionComponentLimitUsdData.setTechnicalPriceAm(limitsModel.getTechnicalPriceAmount().multiply(rate));
					}
					if(limitsModel.getExpiringPremiumAmount() != null)
					{
						tTransactionComponentLimitUsdData.setExpiringPremiumAm(limitsModel.getExpiringPremiumAmount().multiply(rate));
					}
				}
				else{
					ngeException.throwException(NGEErrorCodes.AIG_CURRENCY_NOT_MATCHING, NGEErrorCodes.ERROR_TYPE, null,null);
				}
				tTransactionComponentLimitUsdData.setSystemId(NGESession.getSessionData().getSystem().getSystemId());
				tTransactionComponentLimitUsdData.setCreateUserId(limitsModel.getUserId());
				tTransactionComponentLimitUsdData.setCreateTs(new Timestamp(date.getTime()));
				tTransactionComponentLimitUsdData.setTcurrency(usCurrencyData);
				tTransactionComponentLimitUsdData.setTtransactionComponent(tTransactionComponentData);
				tTransactionComponentLimitSet.add(tTransactionComponentLimitUsdData);
				}
				else{
					ngeException.throwException(NGEErrorCodes.PROBLEM_IN_CURRENCY_CONNVERSION_SERVICE, NGEErrorCodes.ERROR_TYPE, "Problem occurred in currency conversion service",null);
				}
			}
			tTransactionComponentData.setTtransactionComponentLimits(tTransactionComponentLimitSet);
		}
		return  tTransactionComponentData;
	}	

	

	/**
	 * 
	 * @param ttransactionComponents
	 * @throws JpaSystemException
	 */
	public void saveTransactionComponents(List<TtransactionComponent> ttransactionComponents) {
		tTransactionComponentRepository.save(ttransactionComponents);
	}
	
	/**
	 * 
	 * @param transactionComponentIdSet
	 * @param statusTypeIdSet
	 * @return
	 */
	public List<TtransactionComponentStatus> getTransactionComponentIdInAndStatusTypeNmIn(Set<String> transactionComponentIdSet, List<String> statusTypeIdSet) {
		
		/*
		* EXADATA Migration Changes
		* 		Adding space for status name 
		*/
		
		List<String> statusNmListModified = new ArrayList<String>();
					for(String statusNm : statusTypeIdSet){
						if(statusNm.equals(NGEConstants.EMPTY_STRING))
							statusNm = NGEConstants.EMPTY_SPACE;
						statusNmListModified.add(statusNm);
					}
		
		return tTransactionComponentStatusRepository.findByTransactionComponentIdInAndStatusTypeNmIn(transactionComponentIdSet, statusNmListModified);
	}



	/**
	 * @author Bhakavathy Adithan.B.R.
	 * @param tComponentStatus - Set of Transaction Component Status Objects specific to a Transaction Componnet
	 * @return
	 * 
	 * This method returns a boolean value of false if the product has positive life-Cycle and reservation condition
	 * and true for negative  life-Cycle and Reservation condition
	 * 
	 */
	public boolean checkProductAvailabilityInNegativeStatus(Set<TtransactionComponentStatus> tComponentStatus)
	{
		
			boolean isproductAvailable=true;
			for(TtransactionComponentStatus tComptStatus : tComponentStatus)
			{
				if((tComptStatus.getTstatus().getStatusNm().equalsIgnoreCase(NGEConstants.LifeCycleStatus.WORKING)
						|| tComptStatus.getTstatus().getStatusNm().equalsIgnoreCase(NGEConstants.LifeCycleStatus.QUOTED) 
						|| tComptStatus.getTstatus().getStatusNm().equalsIgnoreCase(NGEConstants.LifeCycleStatus.BOUND))
						&& tComptStatus.getTstatus().getStatusNm().equalsIgnoreCase(NGEConstants.ReservationCondition.RESERVED))
				{
					isproductAvailable=false;
				}
				
			}
		
		
		return isproductAvailable;
		
		
	}
	
	public ArrayList<Integer> fetchPossibleToStatusIds(int fromStatusId)
	{
		ArrayList<Integer> possibleToStatusIds=new ArrayList<Integer>();
		List<Tevent> tEventtoStatusList=new ArrayList<Tevent>();
		tEventtoStatusList=tEventRepository.findByStatusId((short)fromStatusId);
		for(Tevent tEventObj: tEventtoStatusList)
		{
			possibleToStatusIds.add(new Integer(tEventObj.getTstatus2().getStatusId()));
		}
		return possibleToStatusIds;
	}
	
	/**
	 * @author Bhakavathy Adithan B.R.
	 * 
	 * @param reOpenTransactionComponentId - Transaction Component Id of the product
	 * @param newStatusId - New Life-Cycle Status Id
	 * @param updateUserId - Updating User Id
	 * @param lifeCycleStatusObj - Existing life-cycle Status Object containing back-up data
	 * @param reOpenReason - Re-Open Reason Object
	 * @param statusIndicator - Indicator to denote whether it is Life-Cycle status update or reservation condition update
	 * @param lifecycleStatus 
	 * @return
	 * @throws AIGCIExceptionMsg - throws exception if any database failure occurs
	 * 
	 * This method is used to add new updated entries of Life-Cycle status or Reservation Condition for the current product which undergoes
	 * Re-Open process 
	 * 
	 */
	public TtransactionComponentStatus updateLifeCycleStatusOrReservationInTransactionComponentStatus(String reOpenTransactionComponentId, int newStatusId,TtransactionComponentStatus lifeCycleStatusObj,Treason reOpenReason,String statusIndicator, String toComments) throws AIGCIExceptionMsg
	{
		java.util.Date date= new java.util.Date();
		TtransactionComponentStatusPK transactionComponentStatusReOpenPrimaryKey=new TtransactionComponentStatusPK();
		TtransactionComponentStatus updatedTransactionComponentStatusDataset=new TtransactionComponentStatus();
		TtransactionComponentStatus transactionComponentStatusReopenObj=new TtransactionComponentStatus();

		transactionComponentStatusReOpenPrimaryKey.setTransactionComponentId(reOpenTransactionComponentId);
		transactionComponentStatusReOpenPrimaryKey.setStatusId((short)newStatusId);
		transactionComponentStatusReopenObj.setId(transactionComponentStatusReOpenPrimaryKey);
		/*transactionComponentStatusReopenObj.setCommentTx(lifeCycleStatusObj.getCommentTx());*/
		if(toComments!=null && toComments.trim().length()!=0){
			transactionComponentStatusReopenObj.setCommentTx(toComments);
		}
		transactionComponentStatusReopenObj.setCreateTs(lifeCycleStatusObj.getCreateTs());
		transactionComponentStatusReopenObj.setCreateUserId(lifeCycleStatusObj.getCreateUserId());
		transactionComponentStatusReopenObj.setExtensionCt(lifeCycleStatusObj.getExtensionCt());
		transactionComponentStatusReopenObj.setStatusTs(new Timestamp(date.getTime()));
		if(statusIndicator.equalsIgnoreCase(NGEConstants.StatusType.LIFECYCLE_STATUS))
		{
			transactionComponentStatusReopenObj.setTreason(reOpenReason);
		}
		transactionComponentStatusReopenObj.setUpdateUserId(NGESession.getSessionData().getUserId());
		transactionComponentStatusReopenObj.setUpdateTs(new Timestamp(date.getTime()));
		
		/* Exadata changes - Not null issue starts */
		if(transactionComponentStatusReopenObj.getCommentTx() != null){
			if(transactionComponentStatusReopenObj.getCommentTx().trim().equals(NGEConstants.EMPTY_STRING))
				transactionComponentStatusReopenObj.setCommentTx(NGEConstants.EMPTY_SPACE);
		}
		/* Exadata changes - Not null issue ends */
		updatedTransactionComponentStatusDataset=tTransactionComponentStatusRepository.save(transactionComponentStatusReopenObj);	
		
		
		return updatedTransactionComponentStatusDataset;
	}
	
	public List<TtransactionComponentStatus> findByStatusNmList(
		String transactionComponentId, String statusTypeNm, List<String> statusNms) {
		
		/*
		* EXADATA Migration Changes
		* 		Adding space for status name 
		*/
		
		List<String> statusNmListModified = new ArrayList<String>();
		for(String statusNm : statusNms){
			if(statusNm.equals(NGEConstants.EMPTY_STRING))
				statusNm = NGEConstants.EMPTY_SPACE;
			statusNmListModified.add(statusNm);
		}
		
		List<TtransactionComponentStatus> ttransactionComponentStatusData=tTransactionComponentStatusRepository.findByTransactionComponentIdAndStatusTypeNmAndStatusNmIn(transactionComponentId,statusTypeNm,statusNmListModified);
		return ttransactionComponentStatusData;
	}
	public List<TcompnentStatusAttribute> getByAttributeId(String transactionComponentId,short statusId){
		
		List <TcompnentStatusAttribute> transactionAttributeData = tCompnentStatusAttributeRepository.findById(transactionComponentId,statusId);
		return transactionAttributeData;
	}

	public List<TtransactionComponentRltn> getTransactionComponentRltn(String transactionComponentId)
	{
		List<TtransactionComponentRltn> transactionComponentRltn;
		transactionComponentRltn = transactionComponentRelationRepository.findByTransactionComponentId(transactionComponentId);
		return transactionComponentRltn;
	}

	/**
	 * @author Chitra Devi P
	 * @param transactionComponentStatus
	 * @param userId
	 * @param systemName
	 * @param productDetails
	 * @throws AIGCIExceptionMsg
	 * This method is used to update the product status from bind to quote in TTRANSACTION_COMPONENT_STATUS table.
	 */
	public TtransactionComponentStatus updateQuoteStatusIdForBindProducts(TtransactionComponentStatus transactionComponentStatus, SetProductStatus productDetails) throws AIGCIExceptionMsg
	{
		java.util.Date date= new java.util.Date();
		String transactionComponentId = "";
		String reasonCd=productDetails.getReasonCd();
		String comments=productDetails.getComment();
		Attributes attributes=null;
		attributes =productDetails.getStatusAttributes();
		Set<TcompnentStatusAttribute> tcomponentStatusAttributeSet = new HashSet<TcompnentStatusAttribute>();
		//Get the reasonId from TREASON table using requested input ReasonCd
		Treason treason = reasonDAO.findByReasonTypeIdAndReasonNm(NGEConstants.ReasonType.UNBIND_PRODUCT,reasonCd);
		if(treason==null)
		{
		   ngeException.throwException(NGEErrorCodes.REASON_CD_INVALID,NGEErrorCodes.ERROR_TYPE, null, null);
		}
		//Get the Quote StatusId from TSTATUS table
		Tstatus tstatusNew = statusDAO.findByStatusTypeNmAndStatusNm(transactionComponentStatus.getTstatus().getTstatusType().getStatusTypeNm(), NGEConstants.LifeCycleStatus.QUOTED);
		transactionComponentStatus.setTstatus(tstatusNew);
		transactionComponentStatus.setStatusTs(new Timestamp(date.getTime()));
		transactionComponentStatus.setTreason(treason);
		transactionComponentStatus.setCommentTx(comments);
		transactionComponentStatus.setUpdateUserId(NGESession.getSessionData().getUserId()); 
		transactionComponentStatus.setUpdateTs(new Timestamp(date.getTime()));
		transactionComponentStatus.setExtensionCt(NGEConstants.ZERO_SHORT);
		//Update the status attribute in TCOMPNENT_STATUS_ATTRIBUTE
		if(attributes!=null)
		{   
			List<Attribute> attributeList = attributes.getAttribute();
			transactionComponentId = transactionComponentStatus.getId().getTransactionComponentId();
			TtransactionComponentStatus transactionCompStatusData = productDAO.getTtransactionComponentStatus(transactionComponentId,NGEConstants.StatusType.LIFECYCLE_STATUS);
			if(transactionCompStatusData!=null)
			{
			tcomponentStatusAttributeSet = statusAttributeHelper.processAttributes(attributeList, transactionCompStatusData);					
			transactionComponentStatus.setTcompnentStatusAttributes(tcomponentStatusAttributeSet);
			}
			else 
			{
				ngeException.throwException(NGEErrorCodes.COMPONENT_STATUS_NOT_AVAILABLE, NGEErrorCodes.ERROR_TYPE, null, null);
			}
		}	
		transactionComponentStatus = transactionComponentStatusRepository.save(transactionComponentStatus);
		return transactionComponentStatus;
	}
	public List<TtransactionComponentRltn> findByRelationCompIdANDrelationTypeId(String transactionComponentId,String relationTypeNm){
		 List<TtransactionComponentRltn> transactionComponentRltnList=null;
	     
	     transactionComponentRltnList = transactionComponentRltnRepository.findByRelationCompIdANDrelationTypeId(transactionComponentId,relationTypeNm.toUpperCase());
	     return transactionComponentRltnList;
	}
	public void saveTransactionComponentSet(
			Set<TtransactionComponent> transactionComponent) {
			Iterable<TtransactionComponent> iterable=transactionComponent;
			tTransactionComponentRepository.save(iterable);
		
	}
	
public List<TtransactionComponent> fetchBindProductsWithRecurringYes(long transactionId,short  versionNo,String segmentCode,String subSegmentCode, String componentProductCode, String marketableProductCode,BigDecimal attachmentPoint, String transactionComponentId, String marketableProdSegCode, String marketableProdSubSegCode, String masterLineOfCode, String coverageLineCode, String coverageSubLineCode) throws AIGCIExceptionMsg{
	
	List<TtransactionComponent> transactionComponentList = new ArrayList<TtransactionComponent>();
	if(segmentCode == null){
		transactionComponentList = tTransactionComponentRepository.findProduct(String.valueOf(transactionId),versionNo,NGEConstants.LifeCycleStatus.BOUND,NGEConstants.StatusType.LIFECYCLE_STATUS,NGEConstants.RECURRING_NAME,NGEConstants.RECURRING_VALUE,segmentCode,subSegmentCode, marketableProductCode,componentProductCode,attachmentPoint, marketableProdSegCode, marketableProdSubSegCode);
		
		if(transactionComponentList.size() == 0){
			ngeException.throwException(NGEErrorCodes.NO_BOUND_AND_RECURRING_PRODUCTS,NGEErrorCodes.ERROR_TYPE, null, null);
		}
	} else{
		ProductModel productModel = new ProductModel();
		TtransactionComponent transactionComponentData = null;
		Set<TtransactionComponentStatus> transactionComponentStatusData = null;
		Set<TtransactionComponentAtrbt> transactionComponentAtrbtData = null;
		String statusTypeNm = NGEConstants.EMPTY_STRING;
		String statusNm = NGEConstants.EMPTY_STRING;
		String attributeNm = NGEConstants.EMPTY_STRING;
		String attribtueVal = NGEConstants.EMPTY_STRING;

		productModel.setTransactionId(transactionId);
		productModel.setVersionNo(versionNo);
		productModel.setSegmentCode(segmentCode);
		productModel.setSubSegmentCode(subSegmentCode);
		productModel.setComponentProductCode(componentProductCode);
		productModel.setMarketableProductCode(marketableProductCode);
		productModel.setAttachmentPoint(attachmentPoint);
		
		productModel.setMasterLineOfCode(masterLineOfCode);
		productModel.setCoverageLineCode(coverageLineCode);
		productModel.setCoverageSubLineCode(coverageSubLineCode);
		
		productModel.setMarketableProdSegmentCode(marketableProdSegCode);
		productModel.setMarketableProdSubSegmentCode(marketableProdSubSegCode);
		
		if(transactionComponentId != null){
			 productModel.setTransactionComponentId(transactionComponentId);
		 }
		 		
		transactionComponentData = fetchTransactionComponentDetails(productModel);
		
		transactionComponentStatusData = transactionComponentData.getTtransactionComponentStatuses();
		for(TtransactionComponentStatus componentStatusData : transactionComponentStatusData){
			statusTypeNm = componentStatusData.getTstatus().getTstatusType().getStatusTypeNm();
			if(statusTypeNm.equalsIgnoreCase(NGEConstants.StatusType.LIFECYCLE_STATUS)){
				statusNm = componentStatusData.getTstatus().getStatusNm();
				if(!statusNm.equalsIgnoreCase(NGEConstants.LifeCycleStatus.BOUND)){
					/* Apr 2017 Maintenance Release 2.4 - AIQ Prior Pol Canceled - Not Valid Status to Renew - Starts */
					//Renewal allowed for cancelled product for legacy consumers alone to support legacy behavior
					if(NGESession.getSessionData().getClientId() != null && NGESession.getSessionData().getClientId().equalsIgnoreCase(NGEConstants.LEGACY_CONSUMERS))
					{
						if(!statusNm.equalsIgnoreCase(NGEConstants.LifeCycleStatus.CANCELLED))
						{
							ngeException.throwException(NGEErrorCodes.PRODUCT_NOT_BIND,NGEErrorCodes.ERROR_TYPE, "Product cannot be renewed. Product should be bound/cancelled for renewal", null);
						}
					}
					else
					{
						ngeException.throwException(NGEErrorCodes.PRODUCT_NOT_BIND,NGEErrorCodes.ERROR_TYPE, "Product cannot be renewed. Product should be bound for renewal", null);
					}
					/* Apr 2017 Maintenance Release 2.4 - AIQ Prior Pol Canceled - Not Valid Status to Renew - Ends */
				}
			}
		}
		
		transactionComponentAtrbtData = transactionComponentData.getTtransactionComponentAtrbts();
		if(transactionComponentAtrbtData != null){
			for(TtransactionComponentAtrbt componentAtrbtData : transactionComponentAtrbtData){
				attributeNm = componentAtrbtData.getTattribute().getAttributeNm();
				if(attributeNm.equalsIgnoreCase(NGEConstants.RECURRING_NAME)){
					attribtueVal = componentAtrbtData.getAttributeVal();
					if(!attribtueVal.equalsIgnoreCase(NGEConstants.RECURRING_VALUE)){
						ngeException.throwException(NGEErrorCodes.PRODUCT_NOT_RENEWABLE,NGEErrorCodes.ERROR_TYPE, "Product cannot be renewed. Product should be a recurring product for renewal", null);
					}
				}
			}
		}
		transactionComponentList.add(transactionComponentData);
	}	
		return transactionComponentList;
	}


public TcomponentRelationType getComponentRelationByType(String relationType) throws AIGCIExceptionMsg
{
	TcomponentRelationType relationTypeData=null;
	List<Object> errorFieldList=new ArrayList<Object>();
	List<TcomponentRelationType> realtionTypeList=componentRelationTypeRepository.findByRelationTypeNm(relationType.toUpperCase());

	if (realtionTypeList.size() == 1) {
		relationTypeData = realtionTypeList.get(0);
	}else if (realtionTypeList.size() == 0){
		errorFieldList.add(relationType);
		ngeException.throwException(NGEErrorCodes.NO_COMPONENT_PRODUCT_RELATION_TYPE, NGEErrorCodes.ERROR_TYPE, null,errorFieldList);
	}else{
		errorFieldList.add(relationType);
		ngeException.throwException(NGEErrorCodes.DUPLICATE_COMPONENT_PRODUCT_RELATION_TYPE, NGEErrorCodes.ERROR_TYPE, null,errorFieldList);
	}
	
	return relationTypeData;
}

	public TtransactionComponentRltn getComponentProductRelation(String relatedTransactionId,String relationTypeName){
		TtransactionComponentRltn transactionComponentRltnData=null;
	List<TtransactionComponentRltn> transactionComponentRltnList=transactionComponentRltnRepository.getComponentProductRelation(relatedTransactionId, relationTypeName.toUpperCase());
		if(transactionComponentRltnList.size() > 0){
			transactionComponentRltnData=transactionComponentRltnList.get(0);
		}
		return transactionComponentRltnData;
	}
	
	/**
	 * Nandhakumar
	 * @param transactionComponentId
	 * @param partyId
	 * @return
	 */
	public TtransactionComponentParty findByTransactionComponentIdAndPartyId(String transactionComponentId, int partyId){
		TtransactionComponentParty componentParty = new TtransactionComponentParty();
		componentParty = tTransactionComponentPartyRepository.findByTransactionComponentIdAndPartyId(transactionComponentId,partyId);
		
		return componentParty;
	}
	public void updateAdditionalInsured(TtransactionComponentParty componentParty) throws AIGCIExceptionMsg{
		TtransactionComponentParty tComponentParty = new TtransactionComponentParty();
		tComponentParty =tTransactionComponentPartyRepository.save(componentParty);
		if(null ==tComponentParty){
			ngeException.throwException(NGEErrorCodes.SERVICE_FAILED, NGEErrorCodes.ERROR_TYPE, null,null);
		}
	}
	public void updateComponentLimit(List<TtransactionComponentLimit> limitList) throws AIGCIExceptionMsg{
		List<TtransactionComponentLimit> limitResponse = new ArrayList<TtransactionComponentLimit>();
		limitResponse = transactionComponentLimitRepository.save(limitList);
		if(limitResponse.isEmpty()){
			ngeException.throwException(NGEErrorCodes.SERVICE_FAILED, NGEErrorCodes.ERROR_TYPE, null,null);
		}
	}
	public TtransactionComponent findByTransactionComponentId(String transactionComponentId) {
		TtransactionComponent transactionComponent = new TtransactionComponent();
		transactionComponent=tTransactionComponentRepository.findByTransactionComponentId(transactionComponentId);
		return transactionComponent;
	}

	public TtransactionComponent findByTransactionComponentIdGetSubmission(String transactionComponentId) {
		TtransactionComponent transactionComponent = new TtransactionComponent();
		transactionComponent=tTransactionComponentRepository.findByTransactionComponentIdGetSubmission(transactionComponentId);
		return transactionComponent;
	}

	
	
	/**
	 * @author Bhakavathy Adithan B.R.
	 * @param toLifeCycleCode - To Life- Cycle status code provided in request
	 * @return
	 * 
	 * This method returns the Tstatus object for the provided status Name
	 * 
	 */
	public Tstatus getTstatusFromStatusCd(String toLifeCycleCode)
	{
		return tStatusRepository.findByStatusNm(toLifeCycleCode.toUpperCase());
	}
	
	/**
	 * @author Bhakavathy Adithan B.R.
	 * @param toReasonCd - Reason Code Provided in the request
	 * @return
	 * 
	 * This method returns the reason object for the reason Code provided
	 */
	public Treason getTreasonFromReasonCd(String toReasonCd)
	{
		/*
		* EXADATA Migration Changes
		* 		Adding space for reason name 
		*/

		if(toReasonCd.equals(NGEConstants.EMPTY_STRING))
			toReasonCd = NGEConstants.EMPTY_SPACE;
		else
			toReasonCd = toReasonCd.trim();
		
		return tReasonRepository.findByReasonNm(toReasonCd.toUpperCase());
	}
	
	/**
	 * @author Bhakavathy Adithan B.R.
	 * @param reasonDesc - Reason Description framed from the life-cycle status 
	 * @return
	 * 
	 * This method returns the reason object for the description provided
	 * 
	 */
	public Treason getTreasonFromReasonDescription(String reasonDesc)
	{
		return tReasonRepository.findByReasonDs(reasonDesc.toUpperCase());
	}
	
	/**
	 * @author Bhakavathy Adithan B.R.
	 * @param towerId - Product tower id derived from request
	 * @param reasonId - Reason Id derived from the reason Code provided in the request
	 * @return
	 * 
	 * This method returns the Tproduct tower reason object for the provided tower id and reason Id
	 * 
	 */
	public TproductTowerReason getTProductTowerReason(short towerId, short reasonId)
	{
		return tProductTowerReasonRepository.findByProductTowerIdAndReasonId(towerId,reasonId);
	}
	
	

	public List<ExistingComponentProduct> getPotentialBlockingSubmissionProducts(
			BlockingSubmissionData blockingSubmissionData, TtransactionComponent incomingTransactionComponent, TransactionComponentChildEntriesBO incomingTransactionComponentChildEntriesBO) throws AIGCIExceptionMsg {
		
			List<ExistingComponentProduct> potentialBlockingComponentList = new ArrayList<ExistingComponentProduct>(); 
			ComponentProductData componentProductData = null;
			blockingSubmissionData.setUltimateBlockingIndicator("Y");
			blockingSubmissionData.setMultipleInsuredIndicator("Y");
			//blockingSubmissionData.setRenewalIndicator("N");
			//blockingSubmissionData.setExpirationTransactionID("0");
			
			/*String schema = ngeProperties.readMessageFromFile(NGEConstants.DB_SCHEMA,NGEConstants.CONFIG_FILE_NAME,true);//"IGNWDB02";
			logger.debug("Schema from property file: "+schema);*/
			
			try {
				
				//Abul Defect Fix 1080 Changes Starts
				
				String segmentCd = ngeProperties.readMessageFromFile(NGEConstants.ProductTower.AEROSPACE_SEGMENT_CD,NGEConstants.CONFIG_FILE_NAME,true);
				String subSegmentCd = ngeProperties.readMessageFromFile(NGEConstants.ProductTower.AEROSPACE_SUB_SEGMENT_CD,NGEConstants.CONFIG_FILE_NAME,true);
				
				//Abul Defect Fix 1080 Changes ends
				
				int subProductId = productDAO.getSubProductIdFromVComponentProduct(blockingSubmissionData.getUnderwritingSubProductID());	
				TproductTower productTower = productDAO.getProductTowerBySegmentandSubSegmentCd(blockingSubmissionData.getSegmentCode(), blockingSubmissionData.getSubSegmentCode());
				boolean callAeroSpaceBlockingQuery = false;
				
				blockingSubmissionData.setProductTowerID(String.valueOf(productTower.getProductTowerId()));//2020 SCUP Release - MLOB change - US147331
				
				//Abul Defect Fix 1080 Changes Starts
				/*if(productTower.getProductTowerNm().equalsIgnoreCase(NGEConstants.ProductTower.AEROSPACE))*/
				if(blockingSubmissionData.getSegmentCode().equalsIgnoreCase(segmentCd)&& blockingSubmissionData.getSubSegmentCode().equalsIgnoreCase(subSegmentCd))
					//Abul Defect Fix 1080 Changes ends
				{
					Ttable table = tableRepository.findByTableNm(NGEConstants.TASSET_ATTRIBUTE);
					if(table != null)
					{
						List<Short> attributeIdList = productTowerAttributeUsageRepository.findAttributesForBatch(productTower.getProductTowerId(), table.getTableId(), NGEConstants.ODM_USAGE);
						
						if(!attributeIdList.isEmpty())
						{
							List<TtransactionComponentAsset> transactionComponentAssetList = transactionComponentAssetRepository.getComponentAssetBasedOnUsageType(incomingTransactionComponent.getTransactionComponentId(), NGEConstants.NO, attributeIdList);
							if(!transactionComponentAssetList.isEmpty())
							{
								callAeroSpaceBlockingQuery = true;
							}
						}
					}

				}
				List<BigDecimal> transactionComponentList;
				if(callAeroSpaceBlockingQuery)
				{
					List<TusageType> usageTypeList = usageTypeRepository.findByUsageTypeDs(NGEConstants.ODM_USAGE);
					TusageType usageType = new TusageType();
					
					if(usageTypeList.isEmpty())
					{
						ngeException.throwException(NGEErrorCodes.INTERNAL_CONFIGURATION_ERROR, NGEErrorCodes.ERROR_TYPE,null, null);
					}
					else
					{
						usageType = usageTypeList.get(0);
					}
					/*2020 SCUP Release - MLOB change - US152343 starts*/	
					if(isBlockExcludedByType(blockingSubmissionData,NGEConstants.ExcludeBlockType.LIMIT)){
						transactionComponentList = tTransactionComponentRepository.fetchPotentialBlockingSubmissionsForAerospaceWithoutLimit(blockingSubmissionData.getMasterLineOfBusinessCd(),blockingSubmissionData.getCoverageLineCd(), blockingSubmissionData.getTransactionComponentID(), blockingSubmissionData.getTransactionID(), new Long(blockingSubmissionData.getExpirationTransactionID()), blockingSubmissionData.getRenewalIndicator(), productTower.getProductTowerId(), NGEConstants.TASSET_ATTRIBUTE, usageType.getUsageTypeId() );
					}else{
						transactionComponentList = tTransactionComponentRepository.fetchPotentialBlockingSubmissionsForAerospace(blockingSubmissionData.getMasterLineOfBusinessCd(),blockingSubmissionData.getCoverageLineCd(), blockingSubmissionData.getTransactionComponentID(), blockingSubmissionData.getTransactionID(), blockingSubmissionData.getAttachmentPointAmount().doubleValue(), blockingSubmissionData.getLimitAmount().doubleValue()+blockingSubmissionData.getAttachmentPointAmount().doubleValue(), new Long(blockingSubmissionData.getExpirationTransactionID()), blockingSubmissionData.getRenewalIndicator(), productTower.getProductTowerId(), NGEConstants.TASSET_ATTRIBUTE, usageType.getUsageTypeId() );
					}
					/*2020 SCUP Release - MLOB change - US152343 ends*/
					
				}
				else
				{
					logger.debug("subProductId : "+subProductId);
					logger.debug("blockingSubmissionData.getTransactionComponentID() : "+blockingSubmissionData.getTransactionComponentID());
					logger.debug("blockingSubmissionData.getTransactionID() : "+blockingSubmissionData.getTransactionID());
					logger.debug("blockingSubmissionData.getUltimateDunsNumber() : "+blockingSubmissionData.getUltimateDunsNumber());
					logger.debug("blockingSubmissionData.getAttachmentPointAmount() : "+blockingSubmissionData.getAttachmentPointAmount());
					logger.debug("blockingSubmissionData.getLimitAmount() : "+blockingSubmissionData.getLimitAmount());
					logger.debug("blockingSubmissionData.getExpirationTransactionID() : "+blockingSubmissionData.getExpirationTransactionID());
					logger.debug("blockingSubmissionData.getRenewalIndicator() : "+blockingSubmissionData.getRenewalIndicator());
					
					/*2020 SCUP Release - MLOB change - US152343 starts*/	
					/*MDM Changes - Replaces Ultimate DUNS with MDM Number - Starts*/
					String ultimateMDM = partyDAO.getMDMPartyIdbyAccountNo(blockingSubmissionData.getUltimateDunsNumber(), NGEConstants.RelatedPartyType.ACCOUNT_MDM_PARTY);
					logger.debug("blockingSubmissionData.ultimateMDM : "+ultimateMDM);	
					if(isBlockExcludedByType(blockingSubmissionData,NGEConstants.ExcludeBlockType.LIMIT)){
						transactionComponentList = tTransactionComponentRepository.fetchPotentialBlockingSubmissionsWithoutLimit(blockingSubmissionData.getMasterLineOfBusinessCd(),blockingSubmissionData.getCoverageLineCd(), blockingSubmissionData.getTransactionComponentID(), blockingSubmissionData.getTransactionID(), ultimateMDM, new Long(blockingSubmissionData.getExpirationTransactionID()), blockingSubmissionData.getRenewalIndicator());
					}else{
						transactionComponentList = tTransactionComponentRepository.fetchPotentialBlockingSubmissions(blockingSubmissionData.getMasterLineOfBusinessCd(),blockingSubmissionData.getCoverageLineCd(), blockingSubmissionData.getTransactionComponentID(), blockingSubmissionData.getTransactionID(), ultimateMDM, blockingSubmissionData.getAttachmentPointAmount().doubleValue(), blockingSubmissionData.getLimitAmount().doubleValue()+blockingSubmissionData.getAttachmentPointAmount().doubleValue(), new Long(blockingSubmissionData.getExpirationTransactionID()), blockingSubmissionData.getRenewalIndicator());
					}
					/*MDM Changes - Replaces Ultimate DUNS with MDM Number - Ends*/
					/*2020 SCUP Release - MLOB change - US152343 ends*/
				}
				if(transactionComponentList.isEmpty())
				{
					logger.info("Potential Blocking Submission Ouput : NO POTENTIAL BLOCKING");
				}
				else
				{
					logger.info("Potential Blocking Submission Ouput : "+transactionComponentList.toString());
					
					List<String> transactionComponentIdList = new ArrayList<String>();
					//for(Long transactionComponentObject : transactionComponentList)
					for(BigDecimal transactionComponentObject : transactionComponentList)
					{
						transactionComponentIdList.add(transactionComponentObject.toString());						
					}
					List<TtransactionComponent> transComponentList = getTransactionComponent(transactionComponentIdList);
					
					if(transComponentList.size() != transactionComponentList.size())
					{
						ngeException.throwException(NGEErrorCodes.COMPONENT_NOT_FOUND, NGEErrorCodes.ERROR_TYPE,null, null);
					}
					
					/* Adding potential blocking size calculation. If the size if more than specified in TPROPERTY (POTENTIAL_BLOCKING_ONLINE_MAX_COUNT),
					 * do the reservation in batch mode - Starts*/
					int potentialBlockingCount = 0;
					for(TtransactionComponent transComponent : transComponentList)
					{
						if(transComponent.getDeletedIn().equalsIgnoreCase(NGEConstants.NO))
						{
							potentialBlockingCount++;
						}
					}
					int maxPotentialBlockingCount= 10000;
					
					try
					{
						maxPotentialBlockingCount = Integer.parseInt(ngeProperties.readMessageFromFile(NGEConstants.POTENTIAL_BLOCKING_ONLINE_MAX_COUNT, NGEConstants.CONFIG_FILE_NAME,true));
					}
					catch(Exception e)
					{
						maxPotentialBlockingCount = 10000;
					}
					
					String requestUserId = NGESession.getSessionData().getUserId();
					
					if(potentialBlockingCount >= maxPotentialBlockingCount && !(requestUserId.equalsIgnoreCase(NGEConstants.BATCH_ID)))
					{
						historyHelper.createTransactionComponentHistory(incomingTransactionComponent);
						
						incomingTransactionComponent.setLockIn(NGEConstants.YES);
						
						//Abul changes starts
						incomingTransactionComponent.setUpdateTs(NGEDateUtil.getTodayDate());
						incomingTransactionComponent.setUpdateUserId(NGESession.getSessionData().getUserId());
						/* Q2 2018 Maintenance Release - NGE Batch Issues Fix - Starts */
						//incomingTransactionComponent.setSystemId(NGESession.getSessionData().getSystem().getSystemId());
						/* Q2 2018 Maintenance Release - NGE Batch Issues Fix - Ends */
						
						//Abul changes ends
						try
						{
							saveTtransactionComponent(incomingTransactionComponent);
						}
						catch(Exception e)
						{
							/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
							if(commonServiceHelper.checkForRetryExceptions(e, 118, NGEConstants.CatchExceptionTypes.THROW_HANDLED_EXCEPTION))
							{
								logger.error("checkForRetryExceptions returned true");
							}
							/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
							logger.error("Exception Message :" +e.getMessage());
							ngeException.throwException(NGEErrorCodes.SERVICE_FAILED,NGEErrorCodes.ERROR_TYPE, "Failed while setting lock in to product", null);
						}
						
						ngeException.throwException(NGEErrorCodes.PRODUCT_LOCKED_FOR_BATCH_UPDATES,NGEConstants.MessageType.WARNING, "Product locked for batch updates due to more potential blocks : "+potentialBlockingCount, null);
					}
					/* Adding potential blocking size calculation. If the size if more than specified in TPROPERTY (POTENTIAL_BLOCKING_ONLINE_MAX_COUNT),
					 * do the reservation in batch mode - Ends*/
					
					for(TtransactionComponent transComponent : transComponentList)
					{
						if(transComponent.getDeletedIn().equalsIgnoreCase(NGEConstants.NO))
						{
						
							TransactionComponentChildEntriesBO transactionComponentChildEntriesBO = null;
							
							//If Incoming product is legacy product, then don't block them within submissions
							if(incomingTransactionComponent.getLegacyIn().equalsIgnoreCase(NGEConstants.YES)){
									
									List<TransactionComponentChildEntriesBO> transactionComponentChildEntriesBOList = getBasicChildDetails(transComponent.getTransactionComponentId());
									
									logger.debug("transactionComponentChildEntriesBOList size : "+transactionComponentChildEntriesBOList.size());
									
									for(TransactionComponentChildEntriesBO transactionComponentChildEntries : transactionComponentChildEntriesBOList)
									{
										if(transactionComponentChildEntries.getTransactionCcomponentId().equalsIgnoreCase(transComponent.getTransactionComponentId()))
										{
											transactionComponentChildEntriesBO = transactionComponentChildEntries;
											break;
										}
									}
									
									if(transactionComponentChildEntriesBO != null 
											&& incomingTransactionComponentChildEntriesBO !=null
											&& !transactionComponentChildEntriesBO.getSubmissionNo().equalsIgnoreCase(incomingTransactionComponentChildEntriesBO.getSubmissionNo())){
										
										componentProductData = new ComponentProductData();
										componentProductData = reserveProductHelper.fetchComponentProductDetails(transComponent,componentProductData,transactionComponentChildEntriesBO);
																
										ExistingComponentProduct existingCompProd = new ExistingComponentProduct(); 
										existingCompProd.setComponentProductDetails(componentProductData);
										potentialBlockingComponentList.add(existingCompProd);
									}
							}							
							else
							{
								componentProductData = new ComponentProductData();
								componentProductData = reserveProductHelper.fetchComponentProductDetails(transComponent,componentProductData,null);
														
								ExistingComponentProduct existingCompProd = new ExistingComponentProduct(); 
								existingCompProd.setComponentProductDetails(componentProductData);
								potentialBlockingComponentList.add(existingCompProd);
							}
						}
						else
						{
							logger.error("Potential Blocking Submission Ouput - DELETED IN - NOT N: "+transComponent.getTransactionComponentId());
						}
					}
				}
				
				/*logger.debug("Potential Blocking Submission Inputs : "+blockingSubmissionData.toString());
				Query query=  em.createNativeQuery("{call "+schema+".BLOCKM2(?1,?2,?3,?4,?5,?6,?7,?8,?9,?10,?11,?12,?13,?14,?15,?16,?17)}", BlockingStoredProcResult.class);
				//Query query=  em.createNativeQuery("{call BLOCKM(?1,?2,?3,?4,?5,?6,?7,?8,?9,?10,?11,?12,?13,?14,?15,?16)}", BlockingStoredProcResult.class);
				
				query.setParameter(1,blockingSubmissionData.getUltimateDunsNumber());
				query.setParameter(2, blockingSubmissionData.getDunsNumber());
				query.setParameter(3, blockingSubmissionData.getUltimateBlockingIndicator());
				query.setParameter(4, blockingSubmissionData.getMultipleInsuredIndicator());
				query.setParameter(5, blockingSubmissionData.getUnderwritingSubProductID());
				query.setParameter(6, blockingSubmissionData.getSegmentCode());
				query.setParameter(7, blockingSubmissionData.getSubSegmentCode()==null?"NULL":blockingSubmissionData.getSubSegmentCode());
				query.setParameter(8, blockingSubmissionData.getTransactionID());
				query.setParameter(9, blockingSubmissionData.getTransactionComponentID());
				
				query.setParameter(10, blockingSubmissionData.getLimitAmount());
				query.setParameter(11, blockingSubmissionData.getAttachmentPointAmount());
				query.setParameter(12, blockingSubmissionData.getRenewalIndicator());
				query.setParameter(13, new Long(blockingSubmissionData.getExpirationTransactionID()));
				
				query.setParameter(14, "");
				
				// to set the error codes - ignore
				query.setParameter(15, 0);
				query.setParameter(16, "");
				query.setParameter(17, "");						
				
				List<BlockingStoredProcResult> blockedSubmissionResult = query.getResultList();
				
				if(blockedSubmissionResult.size()>0){				
					if(blockedSubmissionResult.size()==1 && blockedSubmissionResult.get(0).getEXCLUDE_IN().equalsIgnoreCase("Y")){
						logger.debug("Potential Blocking Submission Ouput : NO POTENTIAL BLOCKING");
					}else{
						for (BlockingStoredProcResult spResultSet1 : blockedSubmissionResult) {							
							logger.debug("Potential Blocking Submission Ouput : "+spResultSet1.toString());
							TtransactionComponent transComponent = getTransactionComponent(spResultSet1.getTRANSACTION_COMPONENT_ID().toString());
							if (transComponent == null) {					
									ngeException.throwException(NGEErrorCodes.COMPONENT_NOT_FOUND, NGEErrorCodes.ERROR_TYPE,null, null);
								
							}else {
								componentProductData = new ComponentProductData();
								componentProductData = reserveProductHelper.fetchComponentProductDetails(transComponent,componentProductData);
								
							}
							ExistingComponentProduct existingCompProd = new ExistingComponentProduct(); 
							existingCompProd.setComponentProductDetails(componentProductData);
							potentialBlockingComponentList.add(existingCompProd);							
						}
					}
				}*/
			} catch (PersistenceException e) {
				logger.error("Exception while invoking Potential Blocking Submission : "+e.getMessage());
				ngeException.throwException(NGEErrorCodes.POTENTIAL_BLOCKING_FAILED, NGEErrorCodes.ERROR_TYPE,e.getMessage(), null);
			}
			return potentialBlockingComponentList;
		}

	
	public List<TtransactionComponent> fetchEligibleProductsForBindTransaction(short workingStatus, short quotedStatus, short reservedCondition, short releasedCondition, String transactionId, short versionNo) throws AIGCIExceptionMsg {		
		List<TtransactionComponent> productList = new ArrayList<TtransactionComponent>();
		productList = tTransactionComponentRepository
				.fetchEligibleProductsForBindTransaction(workingStatus, quotedStatus, reservedCondition, releasedCondition, transactionId, versionNo);		 
		return productList;
	}
	
	public List<TtransactionComponentParty> getTransactionComponentParty(String transactionComponentId, String roleNm) {		
		List<TtransactionComponentParty> transactionComponentParties = null;
		transactionComponentParties = tTransactionComponentPartyRepository
				.findByTransactionComponentIdAndRole(transactionComponentId, roleNm.toUpperCase(), NGEConstants.NO);		 
		return transactionComponentParties;
	}
	
	public List<GetUnderWriterResponse> fetchUnderWriterDiary(String partyNo, String submissionNo, String accountNo, String autoCloseFlag, Date startDt, Date endDate, String renewalFlag, List<String> statusIdList, List<String> productStateList) throws AIGCIExceptionMsg {
		List<GetUnderWriterResponse> getUnderWriterResponseList= new ArrayList<GetUnderWriterResponse>();
		
		short currencyId = 0;
		short lifeCycleStatusId = 0;
		short reservationStatusId = 0;
		short underwriterAttributeId = 0;
		short nonRecurringAttributeId = 0;
		List<String> attributeNameList = new ArrayList<String>();
		Short workingStatusId = null;
		Short quotedStatusId = null;
		Short bindStatusId = null;

		// Fetch the Currency Id for Currency Code USD
		Tcurrency currencyData = commonDAO.getCurrencyId(NGEConstants.USD);
		if(currencyData == null){			
			ngeException.throwException(NGEErrorCodes.INVALID_CURRENCY, NGEErrorCodes.ERROR_TYPE, null, null);
		}
		else{
			currencyId = currencyData.getCurrencyId();
		}
		
		// Fetch the Status Type Id for both Life Cycle Status and Reservation Condition status types
		List<TstatusType> statusTypeDataList = statusDAO.findStatusType();
		for(TstatusType statusTypeData : statusTypeDataList){
			if(statusTypeData.getStatusTypeNm().equalsIgnoreCase(NGEConstants.StatusType.LIFECYCLE_STATUS)){
				lifeCycleStatusId = statusTypeData.getStatusTypeId();
			}
			else if(statusTypeData.getStatusTypeNm().equalsIgnoreCase(NGEConstants.StatusType.RESERVATION_STATUS)){
				reservationStatusId = statusTypeData.getStatusTypeId();
			}
		}
		
		// Fetch the Attribute Id for both Underwriter and Non Recurring attributes
		attributeNameList.add(NGEConstants.PartyType.UNDERWRITER);
		attributeNameList.add(NGEConstants.RECURRING_NAME);
		
		NGECommonUtil.convertCollectionsToUpperCase(attributeNameList);
		List<Tattribute> attributeDataList = attributeDAO.findByAttributeNames(attributeNameList);
		
		for(Tattribute attributeData : attributeDataList){
			if(attributeData.getAttributeNm().equalsIgnoreCase(NGEConstants.PartyType.UNDERWRITER)){
				underwriterAttributeId = attributeData.getAttributeId();
			}
			else if(attributeData.getAttributeNm().equalsIgnoreCase(NGEConstants.RECURRING_NAME)){
				nonRecurringAttributeId = attributeData.getAttributeId();
			}
		}
		
		// Fetch the Status ID for the Life Cycle Status given
		if(statusIdList != null){
			List<Tstatus> statusList = statusDAO.findLifeCycleStatusList(statusIdList);
			
			for(Tstatus statusData : statusList){
				if(statusData.getStatusNm().equalsIgnoreCase(NGEConstants.LifeCycleStatus.WORKING)){
					workingStatusId = statusData.getStatusId();
				}
				else if(statusData.getStatusNm().equalsIgnoreCase(NGEConstants.LifeCycleStatus.QUOTED)){
					quotedStatusId = statusData.getStatusId();
				}
				else if(statusData.getStatusNm().equalsIgnoreCase(NGEConstants.LifeCycleStatus.BOUND)){
					bindStatusId = statusData.getStatusId();
				}			
			}
		}
		
		List<Object[]> diaryList= tTransactionComponentRepository.fetchUnderWriterDiary(partyNo, submissionNo, accountNo, autoCloseFlag, startDt, 
																endDate, renewalFlag, currencyId, lifeCycleStatusId, reservationStatusId, 
																underwriterAttributeId, nonRecurringAttributeId, workingStatusId, quotedStatusId, bindStatusId);
		
		if(diaryList.isEmpty())
		{
			ngeException.throwException(NGEErrorCodes.NO_UNDERWRITER_DIARY_RECORDS, NGEErrorCodes.ERROR_TYPE, null, null);
		}
		
		for(Object[] diary : diaryList)
		{
			GetUnderWriterResponse getUnderWriterResponse= new GetUnderWriterResponse();
			getUnderWriterResponse.setTransactionComponentId(diary[0].toString());
			
			getUnderWriterResponse.setSubmissionNo(diary[1].toString());
			getUnderWriterResponse.setTransactionId(diary[2].toString());
			getUnderWriterResponse.setTransactionVersionNo(Short.valueOf(diary[3].toString()));
			getUnderWriterResponse.setAccountNo(diary[4].toString());
			/* 2021 MDM Changes - Starts */
			getUnderWriterResponse.setMdmPartyId(partyDAO.getMDMPartyIdbyAccountNo(diary[4].toString(), NGEConstants.RelatedPartyType.ACCOUNT_MDM_PARTY));
			/* 2021 MDM Changes - Ends */
			if(diary[5] != null)
			{
				getUnderWriterResponse.setAccountNm(diary[5].toString());
			}
			getUnderWriterResponse.setProducerCd(diary[6].toString());
			getUnderWriterResponse.setProducerNm(diary[7].toString());
			if(diary[8]!= null)
			{
				getUnderWriterResponse.setCityNm(diary[8].toString());
			}
			if(diary[9] != null)
			{
				getUnderWriterResponse.setStateNm(diary[9].toString());
			}
			getUnderWriterResponse.setCreationTs(diary[10].toString());
			getUnderWriterResponse.setSegmentCd(diary[11].toString());
			if(diary[12] != null)
			{
				getUnderWriterResponse.setSubSegmentCd(diary[12].toString());
			}
			if(diary[13] != null){
				
				getUnderWriterResponse.setMarketableProdSegmentCode(diary[13].toString());
			}
			if(diary[14] != null){
				
				getUnderWriterResponse.setMarketableProdSubSegmentCode(diary[14].toString());
			}
						
			getUnderWriterResponse.setComponentProductNm(diary[15].toString());
			getUnderWriterResponse.setComponentProductCd(diary[16].toString());
			getUnderWriterResponse.setProductTowerId(Integer.valueOf(diary[17].toString()));
			getUnderWriterResponse.setProductTowerNm(diary[18].toString());
			
			if(diary[19] != null){
				getUnderWriterResponse.setMarketableProductTowerId(Integer.valueOf(diary[19].toString()));
			}
			if(diary[20] != null){
				getUnderWriterResponse.setMarketableProductTowerNm(diary[20].toString());
			}			
			
			getUnderWriterResponse.setCurrencyCd(diary[21].toString());
			if(diary[22] != null)
			{
				getUnderWriterResponse.setMarketableProductCd(diary[22].toString());
			}
			if(diary[23] != null)
			{
				getUnderWriterResponse.setMarketableProductNm(diary[23].toString());
			}
			if(diary[27] != null)
			{
				//Local currency
				getUnderWriterResponse.setAttachmentPointAmt(BigDecimal.valueOf(Double.valueOf(diary[27].toString())));
			}
			else
			{
				//USD
				getUnderWriterResponse.setAttachmentPointAmt(BigDecimal.valueOf(Double.valueOf(diary[26].toString())));
			}
			
			/*
			* EXADATA Migration Changes
			* 		Removing space for status name 
			*/
			getUnderWriterResponse.setLifecycleStatusCd(diary[28].toString().trim());
			getUnderWriterResponse.setReservationStatus(diary[29].toString().trim());
			getUnderWriterResponse.setEffectiveDt(NGEDateUtil.convertStringToDate(diary[30].toString()));
			getUnderWriterResponse.setExtensionDaysCt(Short.valueOf(diary[31].toString()));
			getUnderWriterResponse.setExtensionCt(Short.valueOf(diary[32].toString()));
			if(diary[33] != null){
				getUnderWriterResponse.setAutocloseDate(NGEDateUtil.convertStringToDate(diary[33].toString()));	
			}
					
			/*getUnderWriterResponse.setUnderwriterId(partyNo);*/
			getUnderWriterResponse.setUnderwriterId(diary[38].toString());
			logger.debug("diary[38].toString()"+diary[38].toString());
			getUnderWriterResponse.setProductStateCd(diary[34].toString());
			if(diary[36] != null)
			{
				getUnderWriterResponse.setExpirationDt(NGEDateUtil.convertStringToDate(diary[36].toString()));
			}
			//2020 SCUP Release - MLOB change - US134960
			setMLOBforGetUnderWriterResponse(getUnderWriterResponse, diary[39], diary[40], diary[41], diary[42]); 
			
			//If product state is available, then filter the results
			if(productStateList != null && !productStateList.isEmpty())
			{
				for(String productState :productStateList)
				{
					if(productState.equalsIgnoreCase(getUnderWriterResponse.getProductStateCd()))
					{
						getUnderWriterResponseList.add(getUnderWriterResponse);
					}
				}
			}
			else
			{
				getUnderWriterResponseList.add(getUnderWriterResponse);
			}
		}
		return getUnderWriterResponseList;
	}
	
	/**
	 * set MLOB for Get Submission
	 * 2020 SCUP Release - MLOB change - US143528
	 * @param getUnderWriterResponse
	 * @param masterLineOfBusinessCd
	 * @param coverageLineCd
	 * @param coverageSubLineCd
	 * @param masterLineOfBusinessIn 
	 */
	private void setMLOBforGetUnderWriterResponse(
			GetUnderWriterResponse getUnderWriterResponse, Object masterLineOfBusinessCd,
			Object coverageLineCd, Object coverageSubLineCd, Object masterLineOfBusinessIn) {
		if(masterLineOfBusinessCd != null){
			getUnderWriterResponse.setMasterLineOfCode(masterLineOfBusinessCd.toString());
		}
		if(coverageLineCd != null){
			getUnderWriterResponse.setCoverageLineCode(coverageLineCd.toString());
		}
		if(coverageSubLineCd != null){
			getUnderWriterResponse.setCoverageSubLineCode(coverageSubLineCd.toString());
		}			
		if(masterLineOfBusinessIn != null){
			getUnderWriterResponse.setMlobIn(masterLineOfBusinessIn.toString());
		}
		
	}

	public List<TtransactionComponent> getComponentProductUnderwriter(int partyId, String segmentCd, String subSegmentCd, TproductTowerDivision productTowerDivision, List<String> statusNmList) {
		List<TtransactionComponent> transactionComponentList = null;
		if(statusNmList == null)
		{
			transactionComponentList = tTransactionComponentRepository.getComponentProductUnderwriter(partyId, segmentCd, subSegmentCd, productTowerDivision);
		}
		else
		{
			/*
			* EXADATA Migration Changes
			* 		Adding space for status name 
			*/
			List<String> statusNmListModified = new ArrayList<String>();
			for(String statusNm : statusNmList){
				if(statusNm.equals(NGEConstants.EMPTY_STRING))
					statusNm = NGEConstants.EMPTY_SPACE;
				statusNmListModified.add(statusNm);
			}
			
			transactionComponentList = tTransactionComponentRepository.getComponentProductUnderwriter(partyId, segmentCd, subSegmentCd, productTowerDivision, statusNmListModified);
		}
		return transactionComponentList;
	}
	
	public TtransactionComponentAtrbt saveTransactionComponentAtrbt(TtransactionComponentAtrbt transactionComponentAtrbt)
	{		
		TtransactionComponentAtrbt componentAtrbt = tTransactionComponentAtrbtRepository.save(transactionComponentAtrbt);		
		return componentAtrbt;
	}
	
	public TtransactionComponentAtrbt getTransactionCompAttribute(String transactionComponentId, String attributeNm)
	{
		TtransactionComponentAtrbt transactionCompAtrbt = tTransactionComponentAtrbtRepository.getTransactionComponentAtrbt(transactionComponentId, attributeNm);		
		return transactionCompAtrbt;
	}
	
	//Bulk Transfer - 1B related changes
	
	
		public void saveTransactionComponent(TtransactionComponent transactionComponent)
		{
			tTransactionComponentRepository.save(transactionComponent);
		}
		
		public void saveTransactionComponentBranch(TtransactionComponentBranch transactionComponentBranch)
		{
			transactionComponentBranchRepository.save(transactionComponentBranch);
		}
		
		public TtransactionComponentBranch getTransactionComponentBranch(String transactionComponentId, String branchTypeNm)
		{
			TtransactionComponentBranch transactionComponentBranch = transactionComponentBranchRepository.getProductBranch(transactionComponentId, branchTypeNm);
			return transactionComponentBranch;
		}
		
		public boolean updateTransactionComponentList(List<TtransactionComponent> ttransactionComponentList){
			tTransactionComponentRepository.save(ttransactionComponentList);
			return true;
		}

		public boolean updateTransactionComponentBranchList(
				List<TtransactionComponentBranch> tTransactionComponentBranchList) {
			transactionComponentBranchRepository.save(tTransactionComponentBranchList);
			return true;
		}

		

		public boolean updateTransactionExtComponentBranchList(
				String componentId, String workingBranchCd) {
			int updateCount = 0;
			updateCount = trnsctnCmpntXtensnRepository.changeUnderwriter(workingBranchCd,componentId);
			if(updateCount > 0 ){
				return true;
			}
			return false;
		}
		

		public List<TransactionComponentChildEntriesBO> getBasicChildDetails(String transactionComponentId) throws AIGCIExceptionMsg {
				
			//List<Object[]> transactionComponentChildDataObj = tTransactionComponentRepository.fetchTransactionComponentChildData(transactionComponentId);
			List<TransactionComponentChildEntriesBO> transactionComponentChildEntriesBOList = transactionComponentChildEntriesBORepository.fetchTransactionComponentChildData(transactionComponentId);
			/*List<TransactionComponentChildEntriesBO> transactionComponentChildEntriesBOList = new ArrayList<TransactionComponentChildEntriesBO>();
			
			for(Object[] child : transactionComponentChildDataObj)
			{
				TransactionComponentChildEntriesBO transactionComponentChildEntriesBO= new TransactionComponentChildEntriesBO();
				
				int counter = 0;
				transactionComponentChildEntriesBO.setTransactionCcomponentId(child[counter].toString());
				counter++;
				if(null != child[counter])
				{
					logger.debug("child[counter] : "+child[counter].toString());
					transactionComponentChildEntriesBO.setExposureGeographicLocationId(child[counter].toString());				
				}
				counter++;
				if(null != child[counter])
				{
					transactionComponentChildEntriesBO.setStatusId(child[counter].toString());
				}
				counter++;
				if(null != child[counter])
				{					
					transactionComponentChildEntriesBO.setAttributeDetails(child[counter].toString());
				}
				counter++;
				if(null != child[counter])
				{
					transactionComponentChildEntriesBO.setAssetDetails(child[counter].toString());
				}
				counter++;
				if(null != child[counter])
				{
					transactionComponentChildEntriesBO.setAssetAttributeDetails(child[counter].toString());
				}
				counter++;
				if(null != child[counter])
				{
					transactionComponentChildEntriesBO.setBranchId(child[counter].toString());
				}
				counter++;
				if(null != child[counter])
				{
					logger.debug("((ee)child[counter]) : "+(ee)child[counter]);
					logger.debug("((ee)child[counter]).tostring : "+((ee)child[counter]).toString());
					clobToString((ee)child[counter]);
					//logger.debug("((ee)child[counter])..E() : "+((ee)child[counter]).getCharacterStream());
					transactionComponentChildEntriesBO.setPartyId(child[counter].toString());
				}
				counter++;
				if(null != child[counter])
				{
					transactionComponentChildEntriesBO.setRelatedTransactionId(child[counter].toString());
				}
				counter++;
				if(null != child[counter])
				{
					transactionComponentChildEntriesBO.setSubmissionNo(child[counter].toString());
				}
				counter++;
				if(null != child[counter])
				{
					transactionComponentChildEntriesBO.setDnbNo(child[counter].toString());
				}
				counter++;
				if(null != child[counter])
				{
					transactionComponentChildEntriesBO.setRelatedParty(child[counter].toString());
				}
				counter++;
				if(null != child[counter])
				{
					transactionComponentChildEntriesBO.setTransactionParty(child[counter].toString());
				}
				counter++;
				if(null != child[counter])
				{
					transactionComponentChildEntriesBO.setComponentUnderwriterNo(child[counter].toString());
				}
				counter++;
				if(null != child[counter])
				{
					transactionComponentChildEntriesBO.setDnbAccountName(child[counter].toString());
				}
				counter++;
				if(null != child[counter])
				{
					transactionComponentChildEntriesBO.setCreditedBranchId(child[counter].toString());
				}
				counter++;
				if(null != child[counter])
				{
					transactionComponentChildEntriesBO.setTransactionId(child[counter].toString());
				}
				counter++;
				if(null != child[counter])
				{
					transactionComponentChildEntriesBO.setAttachmentPoint(child[counter].toString());
				}
				counter++;
				if(null != child[counter])
				{
					transactionComponentChildEntriesBO.setLimitAmt(child[counter].toString());
				}
				counter++;
				if(null != child[counter])
				{
					transactionComponentChildEntriesBO.setPremiumAmt(child[counter].toString());
				}
				counter++;
				if(null != child[counter])
				{
					transactionComponentChildEntriesBO.setTechnicalPriceAmt(child[counter].toString());
				}
				counter++;
				if(null != child[counter])
				{
					transactionComponentChildEntriesBO.setExpiringPremiumAmt(child[counter].toString());
				}
				counter++;
				if(null != child[counter])
				{
					transactionComponentChildEntriesBO.setStatusWithReason(child[counter].toString());
				}
				counter++;
				if(null != child[counter])
				{
					transactionComponentChildEntriesBO.setStatusWithComments(child[counter].toString());
				}
				counter++;
				if(null != child[counter])
				{
					transactionComponentChildEntriesBO.setStatusAttributes(child[counter].toString());
				}
				counter++;
				
				if(null != child[counter])
				{
					transactionComponentChildEntriesBO.setPolicyDetails(child[counter].toString());
				}
				counter++;
				if(null != child[counter])
				{
					transactionComponentChildEntriesBO.setPolicyAtrbt(child[counter].toString());
				}
				counter++;*/
				
				/*if(null != child[counter])
				{
					transactionComponentChildEntriesBO.setWipQuoteDetails(child[counter].toString());
				}
				counter++;
				if(null != child[counter])
				{
					transactionComponentChildEntriesBO.setWipQuoteSectionCd(child[counter].toString());
				}
				counter++;
				if(null != child[counter])
				{
					transactionComponentChildEntriesBO.setWipQuoteProfitUnitCd(child[counter].toString());
				}
				counter++;
				if(null != child[counter])
				{
					transactionComponentChildEntriesBO.setWipQuoteWinningCarrierNm(child[counter].toString());
				}
				counter++;
				if(null != child[counter])
				{
					transactionComponentChildEntriesBO.setWipQuoteLossrsn(child[counter].toString());
				}
				counter++;
				if(null != child[counter])
				{
					transactionComponentChildEntriesBO.setWipQuoteQuoteEffectiveDt(child[counter].toString());
				}
				counter++;
				if(null != child[counter])
				{
					transactionComponentChildEntriesBO.setWipQuoteQuoteExpirationDt(child[counter].toString());
				}
				counter++;
				if(null != child[counter])
				{
					transactionComponentChildEntriesBO.setWipQuoteReasonCd(child[counter].toString());
				}
				counter++;
				if(null != child[counter])
				{
					transactionComponentChildEntriesBO.setWipQuotePolEventNo(child[counter].toString());
				}
				counter++;
				if(null != child[counter])
				{
					transactionComponentChildEntriesBO.setWipQuotePolicyId(child[counter].toString());
				}
				counter++;
				if(null != child[counter])
				{
					transactionComponentChildEntriesBO.setWipQuotePriorPolicyId(child[counter].toString());
				}
				counter++;
				
				if(null != child[counter])
				{
					transactionComponentChildEntriesBO.setWipQuoteMasterContractNo(child[counter].toString());
				}
				counter++;
				if(null != child[counter])
				{
					transactionComponentChildEntriesBO.setWipQuoteAccountLegalNm(child[counter].toString());
				}
				counter++;
				if(null != child[counter])
				{
					transactionComponentChildEntriesBO.setWipQuoteAccountPolNo(child[counter].toString());
				}
				counter++;
				if(null != child[counter])
				{
					transactionComponentChildEntriesBO.setWipQuoteAccountPolPrfxCd(child[counter].toString());
				}
				counter++;
				if(null != child[counter])
				{
					transactionComponentChildEntriesBO.setWipQuoteNonRenewalReasonCd(child[counter].toString());
				}
				counter++;
				if(null != child[counter])
				{
					transactionComponentChildEntriesBO.setWipQuotePolicyMailedDt(child[counter].toString());
				}
				counter++;
				
				if(null != child[counter])
				{
					transactionComponentChildEntriesBO.setWipQuoteCurrencyId(child[counter].toString());
				}
				counter++;
				if(null != child[counter])
				{
					transactionComponentChildEntriesBO.setWipQuoteCurrencyQuotedPremiumAmt(child[counter].toString());
				}
				counter++;
				if(null != child[counter])
				{
					transactionComponentChildEntriesBO.setWipQuoteCurrencyQuotedLimitAmt(child[counter].toString());
				}
				counter++;
				if(null != child[counter])
				{
					transactionComponentChildEntriesBO.setWipQuoteCurrencyQuotedAttachmentPointAmt(child[counter].toString());
				}
				counter++;
				if(null != child[counter])
				{
					transactionComponentChildEntriesBO.setWipQuoteCurrencyPolicyAttachmentPointAmt(child[counter].toString());
				}
				counter++;
				if(null != child[counter])
				{
					transactionComponentChildEntriesBO.setWipQuoteCurrencyPolicyLimitAmt(child[counter].toString());
				}
				counter++;
				if(null != child[counter])
				{
					transactionComponentChildEntriesBO.setWipQuoteCurrencyPolicyPartOfAmt(child[counter].toString());
				}
				counter++;*/
				
				/*transactionComponentChildEntriesBOList.add(transactionComponentChildEntriesBO);
				
			}*/
			
			return transactionComponentChildEntriesBOList;
		}
		
		public List<TransactionChildEntriesBO> getBasicChildTransactionDetails(String transactionId) throws AIGCIExceptionMsg {
			
			List<Object[]> transactionChildDataObj = tTransactionComponentRepository.fetchTransactionChildData(transactionId);
			
			List<TransactionChildEntriesBO> transactionChildEntriesBOList = new ArrayList<TransactionChildEntriesBO>();
			
			for(Object[] child : transactionChildDataObj)
			{
				TransactionChildEntriesBO transactionChildEntriesBO= new TransactionChildEntriesBO();
				
				int counter = 0;
				
				if(null != child[counter])
				{
					transactionChildEntriesBO.setTransactionParty(child[counter].toString());				
				}
				counter++;
				if(null != child[counter])
				{
					transactionChildEntriesBO.setProducerContactDetails(child[counter].toString());
				}
				counter++;
				if(null != child[counter])
				{
					transactionChildEntriesBO.setProducerContactEmail(child[counter].toString());
				}
				counter++;
				if(null != child[counter])
				{
					transactionChildEntriesBO.setProducerContactPhone(child[counter].toString());
				}
				counter++;
				if(null != child[counter])
				{
					transactionChildEntriesBO.setAttributeDetails(child[counter].toString());
				}
				counter++;
				
				
				transactionChildEntriesBOList.add(transactionChildEntriesBO);
				
			}
			
			return transactionChildEntriesBOList;
		}
		
		// Fetch the products count under the transaction version
		public short getProductCountUnderTransactionVersion(String transactionId, short versionNo){
			
			short productCount = 0;
			productCount = tTransactionComponentRepository.getTransactionComponentByTransactionIdAndVersionNo(transactionId,versionNo);
			
			return productCount;
		}
		
		//estartProductCode
		public List<Object []> getEstartproductcode(String transactionCompId){
			   List<Object []> tlegacyTrnsctnCmpntXtensn = trnsctnCmpntXtensnRepository.findByTransactionCompId(transactionCompId);
			   return tlegacyTrnsctnCmpntXtensn;
		}
		// estartProductName

		public TlegacyProduct getEstartProductNM(String productcd){
			   TlegacyProduct tlegacyproduct = trnsctnCmpntXtensnRepository.findByLegacyProdCd(productcd);
			   return tlegacyproduct;
		}
		
		public List<Tblock> getAsssetName(String transactionCompId) {
			List<Tblock> assetype = tBlockRepository.getAsssetName(transactionCompId);
			return assetype;
		}

		public boolean updateTransactionComponent(int partyId,String profitCenterCode,boolean isVoid,int topartyId, String userId) {
			int count = 0;
			if(isVoid){
				tTransactionComponentHRepository.insertIntoHistoryNotVoid(partyId,NGECommonUtil.convertToString(profitCenterCode));
				count = tTransactionComponentRepository.updateNotVoid(partyId, NGECommonUtil.convertToString(profitCenterCode), topartyId, userId);
				if(0 != count){
					return true;
				}
				return false;
			}
				tTransactionComponentHRepository.insertIntoHistoryNotDecVoidLost(partyId,NGECommonUtil.convertToString(profitCenterCode));
				count = tTransactionComponentRepository.updateNotDecVoidLost(partyId, NGECommonUtil.convertToString(profitCenterCode), topartyId, userId);
				if(0 != count){
					return true;
				}
				return false;
		}

		public boolean updateTransactionComponentExt(int partyId,String profitCenterCode,boolean isVoid,String workingBranchCd, String userId) {
			int count = 0;
			if(isVoid){
				tlegacyTrnsctnCmpntXtensnHRepository.insertIntoHistoryNotVoid(partyId, NGECommonUtil.convertToString(profitCenterCode));
				count = trnsctnCmpntXtensnRepository.updateNotVoid(partyId, NGECommonUtil.convertToString(profitCenterCode), workingBranchCd, userId);
				if(0 != count){
					return true;
				}
				return false;
			}
				tlegacyTrnsctnCmpntXtensnHRepository.insertIntoHistoryNotDecVoidLost(partyId, NGECommonUtil.convertToString(profitCenterCode));
				count = trnsctnCmpntXtensnRepository.updateNotDecVoidLost(partyId, NGECommonUtil.convertToString(profitCenterCode), workingBranchCd, userId);
				if(0 != count){
					return true;
				}
				return false;
		}
		
		public boolean updateTransactionComponentbranch(int partyId,
				String profitCenterCode,boolean isVoid,int branchId,String userId) {
			int count = 0;
			if(isVoid){
				tTransactionCmpntBranchHRepository.insertIntoHistoryNotVoid(partyId, NGECommonUtil.convertToString(profitCenterCode));
				count = transactionComponentBranchRepository.updateNotVoid(partyId, NGECommonUtil.convertToString(profitCenterCode), branchId, userId);
				if(0 != count){
					return true;
				}
				return false;
			}
			
				tTransactionCmpntBranchHRepository.insertIntoHistoryNotDecVoidLost(partyId, NGECommonUtil.convertToString(profitCenterCode));
				count = transactionComponentBranchRepository.updateNotDecVoidLost(partyId, NGECommonUtil.convertToString(profitCenterCode), branchId, userId);
				if(0 != count){
					return true;
				}
				return false;
		}

		public TransactionComponentPolicyAttributesBO getTransactionComponentPolicyAttributes(String transactionComponentId) throws AIGCIExceptionMsg {
			
			TransactionComponentPolicyAttributesBO transactionComponentPolicyAttributesBO = transactionComponentPolicyAttributesRepository.fetchTransactionComponentPolicyAttributes(transactionComponentId);
			
			return transactionComponentPolicyAttributesBO;
		}	
		
		/**
		 * @param blockingSubmissionData
		 * @param blockTypeNm
		 * 2020 SCUP Release - MLOB change - US147331
		 */
		private boolean isBlockExcludedByType(BlockingSubmissionData blockingSubmissionData,String blockTypeNm){
		
			List<TmlobExcludeBlockByType> excludeList=mlobExcludeBlockByTypeRepository.getExcludeDetails(blockTypeNm,blockingSubmissionData.getProductTowerID(),blockingSubmissionData.getLocationID(),blockingSubmissionData.getDivisionNo(),blockingSubmissionData.getMasterLineOfBusinessCd(),blockingSubmissionData.getCoverageLineCd(),NGEConstants.MLOB_CHECK_ALL);
			
			if(excludeList != null && excludeList.size() > 0){
				logger.info("Potential Blocking Limit : excluded");
				return true;
			}
			logger.info("Potential Blocking Limit : included");
			return false;
		}

	public TtransactionComponentStatus findByTransactionComponentIdAndStatusType(String transactionComponentId, String lifeCycleStatus) {

		int retryCount = 0;
		TtransactionComponentStatus transactionComponentStatus = null;

		while(transactionComponentStatus == null && retryCount <= 3){
			try {
				transactionComponentStatus = transactionComponentStatusRepository.findByTransactionComponentIdAndStatusType(transactionComponentId, lifeCycleStatus);
                logger.info("Success during findByTransactionComponentIdAndStatusType - retryCount : "+retryCount);
			} catch (Exception e) {
				retryCount++;
				logger.info("Exception during findByTransactionComponentIdAndStatusType - retryCount : "+retryCount);
			}
		}
		return transactionComponentStatus;
	}

    public TtransactionComponent findByTransactionComponentIdForWIPS(String transactionComponentId) {

        int retryCount = 0;
        TtransactionComponent transactionComponent = null;

        while(transactionComponent == null && retryCount <= 3){
            try {
                transactionComponent = tTransactionComponentRepository.findByTransactionComponentId(transactionComponentId);
                logger.info("Success during findByTransactionComponentIdForWIPS - retryCount : "+retryCount);
            } catch (Exception e) {
                retryCount++;
                logger.info("Exception during findByTransactionComponentIdForWIPS - retryCount : "+retryCount);
            }
        }
        return transactionComponent;
    }

	public List<TlegacyWipQuote> findByTransCompIdandWipId(String transactionComponentId, String wipId) {

		int retryCount = 0;
		List<TlegacyWipQuote> tlegacyWipQuotesList = null;

		while(tlegacyWipQuotesList == null && retryCount <= 3){
			try {
				tlegacyWipQuotesList = tLegacyWipQuoteRepository.findByTransCompIdandWipId(transactionComponentId, wipId);
				logger.info("Success during findByTransCompIdandWipId - retryCount : "+retryCount);
			} catch (Exception e) {
				retryCount++;
				logger.info("Exception during findByTransCompIdandWipId - retryCount : "+retryCount);
			}
		}
		return tlegacyWipQuotesList;
	}
}
