package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;

import org.apache.openjpa.persistence.DataCache;
import java.sql.Timestamp;
import java.util.Set;


/**
 * The persistent class for the TRELATION_TYPE database table.
 * 
 */
@Entity
@DataCache
@Table(name="TRELATION_TYPE")
public class TrelationType implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="RELATION_TYPE_ID")
	private short relationTypeId;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="CREATE_TS")
	private Timestamp createTs;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="CREATE_USER_ID")
	private String createUserId;

	@Column(name="RELATION_TYPE_NM")
	private String relationTypeNm;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="UPDATE_TS")
	private Timestamp updateTs;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="UPDATE_USER_ID")
	private String updateUserId;

	//bi-directional many-to-one association to TtransactionRelation
	@OneToMany(mappedBy="trelationType", cascade={CascadeType.ALL})
	private Set<TtransactionRelation> ttransactionRelations;

    public TrelationType() {
    }

	public short getRelationTypeId() {
		return this.relationTypeId;
	}

	public void setRelationTypeId(short relationTypeId) {
		this.relationTypeId = relationTypeId;
	}

	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public String getRelationTypeNm() {
		return this.relationTypeNm;
	}

	public void setRelationTypeNm(String relationTypeNm) {
		this.relationTypeNm = relationTypeNm;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public Set<TtransactionRelation> getTtransactionRelations() {
		return this.ttransactionRelations;
	}

	public void setTtransactionRelations(Set<TtransactionRelation> ttransactionRelations) {
		this.ttransactionRelations = ttransactionRelations;
	}
	
}