package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Set;


/**
 * The persistent class for the TPRODUCT_TOWER_CONFIGURATION database table.
 * 
 */
@Entity
@Table(name="TPRODUCT_TOWER_CONFIGURATION")
public class TproductTowerConfiguration implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="CONFIGURATION_ID")
	private int configurationId;

	@Column(name="CONFIGURATION_VAL")
	private String configurationVal;

	@Column(name="CREATE_TS")
	private Timestamp createTs;

	@Column(name="CREATE_USER_ID")
	private String createUserId;

	@Column(name="UPDATE_TS")
	private Timestamp updateTs;

	@Column(name="UPDATE_USER_ID")
	private String updateUserId;

	//bi-directional many-to-one association to TconfigurationType
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="CONFIGURATION_TYPE_ID")
	private TconfigurationType tconfigurationType;

	//bi-directional many-to-one association to TproductTower
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="PRODUCT_TOWER_ID")
	private TproductTower tproductTower;

	//bi-directional many-to-one association to TtowerTuwSubProdctConfig
	@OneToMany(mappedBy="tproductTowerConfiguration")
	private Set<TtowerTuwSubProdctConfig> ttowerTuwSubProdctConfigs;

    public TproductTowerConfiguration() {
    }

	public int getConfigurationId() {
		return this.configurationId;
	}

	public void setConfigurationId(int configurationId) {
		this.configurationId = configurationId;
	}

	public String getConfigurationVal() {
		return this.configurationVal;
	}

	public void setConfigurationVal(String configurationVal) {
		this.configurationVal = configurationVal;
	}

	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public TconfigurationType getTconfigurationType() {
		return this.tconfigurationType;
	}

	public void setTconfigurationType(TconfigurationType tconfigurationType) {
		this.tconfigurationType = tconfigurationType;
	}
	
	public TproductTower getTproductTower() {
		return this.tproductTower;
	}

	public void setTproductTower(TproductTower tproductTower) {
		this.tproductTower = tproductTower;
	}
	
	public Set<TtowerTuwSubProdctConfig> getTtowerTuwSubProdctConfigs() {
		return this.ttowerTuwSubProdctConfigs;
	}

	public void setTtowerTuwSubProdctConfigs(Set<TtowerTuwSubProdctConfig> ttowerTuwSubProdctConfigs) {
		this.ttowerTuwSubProdctConfigs = ttowerTuwSubProdctConfigs;
	}
	
}