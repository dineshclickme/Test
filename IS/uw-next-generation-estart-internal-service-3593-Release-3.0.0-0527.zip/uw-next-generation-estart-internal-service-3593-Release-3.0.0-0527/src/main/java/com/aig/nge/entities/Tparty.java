package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;

import java.sql.Timestamp;
import java.util.Set;


/**
 * The persistent class for the TPARTY database table.
 * 
 */
@Entity
public class Tparty implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "party_id_gen")
	@SequenceGenerator(name = "party_id_gen", sequenceName = "PARTY_ID_SEQ", allocationSize=1)
	@Column(name="PARTY_ID")
	private int partyId;

	@Column(name="CREATE_TS")
	private Timestamp createTs;

	@Column(name="CREATE_USER_ID")
	private String createUserId;

	@Column(name="PARTY_NO")
	private String partyNo;

	@Column(name="UPDATE_TS")
	private Timestamp updateTs;

	@Column(name="UPDATE_USER_ID")
	private String updateUserId;

	//bi-directional one-to-one association to Taccount
	@OneToOne(mappedBy="tparty", cascade={CascadeType.ALL}, fetch=FetchType.LAZY)
	private Taccount taccount;

	//bi-directional one-to-one association to Tagent
	@OneToOne(mappedBy="tparty", cascade={CascadeType.ALL}, fetch=FetchType.LAZY)
	private Tagent tagent;

	//bi-directional many-to-one association to Tblock
	@OneToMany(mappedBy="tparty")
	private Set<Tblock> tblocks;

	//bi-directional many-to-one association to TofacAlertNotification
	@OneToMany(mappedBy="tparty")
	private Set<TofacAlertNotification> tofacAlertNotifications;

	//bi-directional many-to-one association to TpartyType
    @ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="PARTY_TYPE_ID")
	private TpartyType tpartyType;

	//bi-directional many-to-one association to TpartyAction
	@OneToMany(mappedBy="tparty", cascade={CascadeType.ALL})
	private Set<TpartyAction> tpartyActions;

	//bi-directional one-to-one association to TpartyDetail
	@OneToOne(mappedBy="tparty", cascade={CascadeType.ALL}, fetch=FetchType.LAZY)
	private TpartyDetail tpartyDetail;

	//bi-directional one-to-one association to Tproducer
	@OneToOne(mappedBy="tparty", cascade={CascadeType.ALL}, fetch=FetchType.LAZY)
	private Tproducer tproducer;

	//bi-directional many-to-one association to TproductTowerParty
	@OneToMany(mappedBy="tparty", cascade={CascadeType.ALL})
	private Set<TproductTowerParty> tproductTowerParties;

	//bi-directional many-to-one association to TrelatedParty
	@OneToMany(mappedBy="tparty1", cascade={CascadeType.ALL})
	private Set<TrelatedParty> trelatedParties1;

	//bi-directional many-to-one association to TrelatedParty
	@OneToMany(mappedBy="tparty2", cascade={CascadeType.ALL})
	private Set<TrelatedParty> trelatedParties2;

	//bi-directional one-to-one association to TshellAccount
	@OneToOne(mappedBy="tparty", cascade={CascadeType.ALL}, fetch=FetchType.LAZY)
	private TshellAccount tshellAccount;

	//bi-directional many-to-one association to Tsubmission
	@OneToMany(mappedBy="tparty1")
	private Set<Tsubmission> tsubmissions1;

	//bi-directional many-to-one association to Tsubmission
	@OneToMany(mappedBy="tparty2", cascade={CascadeType.ALL})
	private Set<Tsubmission> tsubmissions2;

	//bi-directional many-to-one association to Ttransaction
	@OneToMany(mappedBy="tparty1", cascade={CascadeType.ALL})
	private Set<Ttransaction> ttransactions1;

	//bi-directional many-to-one association to Ttransaction
	@OneToMany(mappedBy="tparty2", cascade={CascadeType.ALL})
	private Set<Ttransaction> ttransactions2;

	//bi-directional many-to-one association to Ttransaction
	@OneToMany(mappedBy="tparty3", cascade={CascadeType.ALL})
	private Set<Ttransaction> ttransactions3;

	//bi-directional many-to-one association to TtransactionComponent
	@OneToMany(mappedBy="tparty", cascade={CascadeType.ALL})
	private Set<TtransactionComponent> ttransactionComponents;

	//bi-directional many-to-one association to TtransactionComponentParty
	@OneToMany(mappedBy="tparty", cascade={CascadeType.ALL})
	private Set<TtransactionComponentParty> ttransactionComponentParties;

	//bi-directional many-to-one association to TtransactionParty
	@OneToMany(mappedBy="tparty", cascade={CascadeType.ALL})
	private Set<TtransactionParty> ttransactionParties;

	//bi-directional one-to-one association to Tuser
	@OneToOne(mappedBy="tparty", cascade={CascadeType.ALL}, fetch=FetchType.LAZY)
	private Tuser tuser;

	//bi-directional many-to-one association to TuserPreferedProducer
	@OneToMany(mappedBy="tparty", cascade={CascadeType.ALL})
	private Set<TuserPreferedProducer> tuserPreferedProducers;

	//bi-directional many-to-one association to TuserPreferredUnderwriter
	@OneToMany(mappedBy="tparty", cascade={CascadeType.ALL},fetch=FetchType.LAZY)
	private Set<TuserPreferredUnderwriter> tuserPreferredUnderwriter;

	//bi-directional one-to-one association to TuserPrefernce
	@OneToOne(mappedBy="tparty1",fetch=FetchType.LAZY)
	private TuserPrefernce tuserPrefernce;

    public Tparty() {
    }

	public int getPartyId() {
		return this.partyId;
	}

	public void setPartyId(int partyId) {
		this.partyId = partyId;
	}

	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public String getPartyNo() {
		return this.partyNo;
	}

	public void setPartyNo(String partyNo) {
		this.partyNo = partyNo;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public Taccount getTaccount() {
		return this.taccount;
	}

	public void setTaccount(Taccount taccount) {
		this.taccount = taccount;
	}
	
	public Tagent getTagent() {
		return this.tagent;
	}

	public void setTagent(Tagent tagent) {
		this.tagent = tagent;
	}
	
	public Set<Tblock> getTblocks() {
		return this.tblocks;
	}

	public void setTblocks(Set<Tblock> tblocks) {
		this.tblocks = tblocks;
	}
	
	public Set<TofacAlertNotification> getTofacAlertNotifications() {
		return this.tofacAlertNotifications;
	}

	public void setTofacAlertNotifications(Set<TofacAlertNotification> tofacAlertNotifications) {
		this.tofacAlertNotifications = tofacAlertNotifications;
	}
	
	public TpartyType getTpartyType() {
		return this.tpartyType;
	}

	public void setTpartyType(TpartyType tpartyType) {
		this.tpartyType = tpartyType;
	}
	
	public Set<TpartyAction> getTpartyActions() {
		return this.tpartyActions;
	}

	public void setTpartyActions(Set<TpartyAction> tpartyActions) {
		this.tpartyActions = tpartyActions;
	}
	
	public TpartyDetail getTpartyDetail() {
		return this.tpartyDetail;
	}

	public void setTpartyDetail(TpartyDetail tpartyDetail) {
		this.tpartyDetail = tpartyDetail;
	}
	
	public Tproducer getTproducer() {
		return this.tproducer;
	}

	public void setTproducer(Tproducer tproducer) {
		this.tproducer = tproducer;
	}
	
	public Set<TproductTowerParty> getTproductTowerParties() {
		return this.tproductTowerParties;
	}

	public void setTproductTowerParties(Set<TproductTowerParty> tproductTowerParties) {
		this.tproductTowerParties = tproductTowerParties;
	}
	
	public Set<TrelatedParty> getTrelatedParties1() {
		return this.trelatedParties1;
	}

	public void setTrelatedParties1(Set<TrelatedParty> trelatedParties1) {
		this.trelatedParties1 = trelatedParties1;
	}
	
	public Set<TrelatedParty> getTrelatedParties2() {
		return this.trelatedParties2;
	}

	public void setTrelatedParties2(Set<TrelatedParty> trelatedParties2) {
		this.trelatedParties2 = trelatedParties2;
	}
	
	public TshellAccount getTshellAccount() {
		return this.tshellAccount;
	}

	public void setTshellAccount(TshellAccount tshellAccount) {
		this.tshellAccount = tshellAccount;
	}
	
	public Set<Tsubmission> getTsubmissions1() {
		return this.tsubmissions1;
	}

	public void setTsubmissions1(Set<Tsubmission> tsubmissions1) {
		this.tsubmissions1 = tsubmissions1;
	}
	
	public Set<Tsubmission> getTsubmissions2() {
		return this.tsubmissions2;
	}

	public void setTsubmissions2(Set<Tsubmission> tsubmissions2) {
		this.tsubmissions2 = tsubmissions2;
	}
	
	public Set<Ttransaction> getTtransactions1() {
		return this.ttransactions1;
	}

	public void setTtransactions1(Set<Ttransaction> ttransactions1) {
		this.ttransactions1 = ttransactions1;
	}
	
	public Set<Ttransaction> getTtransactions2() {
		return this.ttransactions2;
	}

	public void setTtransactions2(Set<Ttransaction> ttransactions2) {
		this.ttransactions2 = ttransactions2;
	}
	
	public Set<Ttransaction> getTtransactions3() {
		return this.ttransactions3;
	}

	public void setTtransactions3(Set<Ttransaction> ttransactions3) {
		this.ttransactions3 = ttransactions3;
	}
	
	public Set<TtransactionComponent> getTtransactionComponents() {
		return this.ttransactionComponents;
	}

	public void setTtransactionComponents(Set<TtransactionComponent> ttransactionComponents) {
		this.ttransactionComponents = ttransactionComponents;
	}
	
	public Set<TtransactionComponentParty> getTtransactionComponentParties() {
		return this.ttransactionComponentParties;
	}

	public void setTtransactionComponentParties(Set<TtransactionComponentParty> ttransactionComponentParties) {
		this.ttransactionComponentParties = ttransactionComponentParties;
	}
	
	public Set<TtransactionParty> getTtransactionParties() {
		return this.ttransactionParties;
	}

	public void setTtransactionParties(Set<TtransactionParty> ttransactionParties) {
		this.ttransactionParties = ttransactionParties;
	}
	
	public Tuser getTuser() {
		return this.tuser;
	}

	public void setTuser(Tuser tuser) {
		this.tuser = tuser;
	}
	
 // Q2 May 2018 - Maintenance release - Preferred underwriter List Changes starts
	public Set<TuserPreferredUnderwriter> getTuserPreferredUnderwriter(){
		return this.tuserPreferredUnderwriter;
	}
	
	public void setTuserPreferredUnderwriter (Set<TuserPreferredUnderwriter> tuserPreferredUnderwriter){
		this.tuserPreferredUnderwriter = tuserPreferredUnderwriter;
	}
 // Q2 May 2018 - Maintenance release - Preferred underwriter List Changes ends.
	public Set<TuserPreferedProducer> getTuserPreferedProducers() {
		return this.tuserPreferedProducers;
	}

	public void setTuserPreferedProducers(Set<TuserPreferedProducer> tuserPreferedProducers) {
		this.tuserPreferedProducers = tuserPreferedProducers;
	}
	
	public TuserPrefernce getTuserPrefernce() {
		return this.tuserPrefernce;
	}

	public void setTuserPrefernce(TuserPrefernce tuserPrefernce) {
		this.tuserPrefernce = tuserPrefernce;
	}
	
}