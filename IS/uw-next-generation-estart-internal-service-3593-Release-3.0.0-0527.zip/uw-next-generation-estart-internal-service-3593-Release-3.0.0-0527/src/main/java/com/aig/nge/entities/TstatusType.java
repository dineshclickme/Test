package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;

import org.apache.openjpa.persistence.DataCache;
import java.sql.Timestamp;
import java.util.Set;


/**
 * The persistent class for the TSTATUS_TYPE database table.
 * 
 */
@Entity
@DataCache
@Table(name="TSTATUS_TYPE")
public class TstatusType implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="STATUS_TYPE_ID")
	private short statusTypeId;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="CREATE_TS")
	private Timestamp createTs;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="CREATE_USER_ID")
	private String createUserId;

	@Column(name="STATUS_TYPE_NM")
	private String statusTypeNm;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="UPDATE_TS")
	private Timestamp updateTs;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="UPDATE_USER_ID")
	private String updateUserId;

	//bi-directional many-to-one association to Tstatus
	@OneToMany(mappedBy="tstatusType", cascade={CascadeType.ALL})
	private Set<Tstatus> tstatuses;

    public TstatusType() {
    }

	public short getStatusTypeId() {
		return this.statusTypeId;
	}

	public void setStatusTypeId(short statusTypeId) {
		this.statusTypeId = statusTypeId;
	}

	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public String getStatusTypeNm() {
		return this.statusTypeNm;
	}

	public void setStatusTypeNm(String statusTypeNm) {
		this.statusTypeNm = statusTypeNm;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public Set<Tstatus> getTstatuses() {
		return this.tstatuses;
	}

	public void setTstatuses(Set<Tstatus> tstatuses) {
		this.tstatuses = tstatuses;
	}
	
}