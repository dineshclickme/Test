package com.aig.nge.entities;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-03-02T12:10:24.832+0530")
@StaticMetamodel(TpolicyH.class)
public class TpolicyH_ {
	public static volatile SingularAttribute<TpolicyH, TpolicyHPK> id;
	public static volatile SingularAttribute<TpolicyH, Short> companyCd;
	public static volatile SingularAttribute<TpolicyH, Timestamp> createTs;
	public static volatile SingularAttribute<TpolicyH, String> createUserId;
	public static volatile SingularAttribute<TpolicyH, Date> effectiveDt;
	public static volatile SingularAttribute<TpolicyH, Date> expirationDt;
	public static volatile SingularAttribute<TpolicyH, Short> localCurrencyId;
	public static volatile SingularAttribute<TpolicyH, BigDecimal> localCurrencyPremiumAm;
	public static volatile SingularAttribute<TpolicyH, String> policyNo;
	public static volatile SingularAttribute<TpolicyH, Short> policyTypeId;
	public static volatile SingularAttribute<TpolicyH, BigDecimal> premiumAm;
	public static volatile SingularAttribute<TpolicyH, Short> systemId;
	public static volatile SingularAttribute<TpolicyH, String> updateUserId;
	public static volatile SingularAttribute<TpolicyH, Timestamp> updateTs;
}
