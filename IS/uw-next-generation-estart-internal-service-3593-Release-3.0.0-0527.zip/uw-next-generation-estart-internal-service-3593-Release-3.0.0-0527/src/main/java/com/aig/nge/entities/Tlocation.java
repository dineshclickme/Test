package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;

import org.apache.openjpa.persistence.DataCache;
import java.sql.Timestamp;
import java.util.Set;


/**
 * The persistent class for the TLOCATION database table.
 * 
 */
@Entity
@DataCache
public class Tlocation implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="GEOGRAPHIC_LOCATION_ID")
	private int geographicLocationId;

	@Column(name="ALTERNATE_LOCATION_CD")
	private String alternateLocationCd;

	@Basic(fetch=FetchType.LAZY)
	@Column(name="CREATE_TS")
	private Timestamp createTs;

	@Basic(fetch=FetchType.LAZY)
	@Column(name="CREATE_USER_ID")
	private String createUserId;

	@Column(name="DELETED_IN")
	private String deletedIn;

	@Column(name="LOCATION_CD")
	private String locationCd;

	@Column(name="LOCATION_NM")
	private String locationNm;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="UPDATE_TS")
	private Timestamp updateTs;

	@Basic(fetch=FetchType.LAZY)
	@Column(name="UPDATE_USER_ID")
	private String updateUserId;

	//bi-directional many-to-one association to Tbranch
	@OneToMany(mappedBy="tlocation", cascade={CascadeType.ALL})
	private Set<Tbranch> tbranches;

	//bi-directional many-to-one association to Tlocation
	//Feb 27, 2018. NGE-AIQ Integration Performance fix - Added Fetch Type Lazy
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="PARENT_LOCATION_ID")
	private Tlocation tlocation;

	//bi-directional many-to-one association to Tlocation
	@OneToMany(mappedBy="tlocation")
	private Set<Tlocation> tlocations;

	//bi-directional many-to-one association to TlocationType
	@ManyToOne
	@JoinColumn(name="LOCATION_TYPE_ID")
	private TlocationType tlocationType;

	//bi-directional many-to-one association to TmailingAddress
	@OneToMany(mappedBy="tlocation", cascade={CascadeType.ALL})
	private Set<TmailingAddress> tmailingAddresses;

	//bi-directional many-to-one association to TpartyAction
	@OneToMany(mappedBy="tlocation", cascade={CascadeType.ALL})
	private Set<TpartyAction> tpartyActions;

	//bi-directional many-to-one association to TpartyDetail
	@OneToMany(mappedBy="tlocation", cascade={CascadeType.ALL})
	private Set<TpartyDetail> tpartyDetails;

	//bi-directional many-to-one association to TtransactionCmpntXpsrLoc
	@OneToMany(mappedBy="tlocation", cascade={CascadeType.ALL})
	private Set<TtransactionCmpntXpsrLoc> ttransactionCmpntXpsrLocs;

	//bi-directional many-to-one association to TuserPrefernce
	@OneToMany(mappedBy="tlocation1", cascade={CascadeType.ALL})
	private Set<TuserPrefernce> tuserPrefernces1;

	//bi-directional many-to-one association to TuserPrefernce
	@OneToMany(mappedBy="tlocation2", cascade={CascadeType.ALL})
	private Set<TuserPrefernce> tuserPrefernces2;
	
	//bi-directional many-to-one association to TmarketableProductLocation
	@OneToMany(mappedBy="tlocation", cascade={CascadeType.ALL})
	private Set<TmarketableProductLocation> tmarketableProductLocation;

    public Tlocation() {
    }

	public int getGeographicLocationId() {
		return this.geographicLocationId;
	}

	public void setGeographicLocationId(int geographicLocationId) {
		this.geographicLocationId = geographicLocationId;
	}

	public String getAlternateLocationCd() {
		return this.alternateLocationCd;
	}

	public void setAlternateLocationCd(String alternateLocationCd) {
		this.alternateLocationCd = alternateLocationCd;
	}

	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public String getDeletedIn() {
		return this.deletedIn;
	}

	public void setDeletedIn(String deletedIn) {
		this.deletedIn = deletedIn;
	}

	public String getLocationCd() {
		return this.locationCd;
	}

	public void setLocationCd(String locationCd) {
		this.locationCd = locationCd;
	}

	public String getLocationNm() {
		return this.locationNm;
	}

	public void setLocationNm(String locationNm) {
		this.locationNm = locationNm;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public Set<Tbranch> getTbranches() {
		return this.tbranches;
	}

	public void setTbranches(Set<Tbranch> tbranches) {
		this.tbranches = tbranches;
	}
	
	public Tlocation getTlocation() {
		return this.tlocation;
	}

	public void setTlocation(Tlocation tlocation) {
		this.tlocation = tlocation;
	}
	
	public Set<Tlocation> getTlocations() {
		return this.tlocations;
	}

	public void setTlocations(Set<Tlocation> tlocations) {
		this.tlocations = tlocations;
	}
	
	public TlocationType getTlocationType() {
		return this.tlocationType;
	}

	public void setTlocationType(TlocationType tlocationType) {
		this.tlocationType = tlocationType;
	}
	
	public Set<TmailingAddress> getTmailingAddresses() {
		return this.tmailingAddresses;
	}

	public void setTmailingAddresses(Set<TmailingAddress> tmailingAddresses) {
		this.tmailingAddresses = tmailingAddresses;
	}
	
	public Set<TpartyAction> getTpartyActions() {
		return this.tpartyActions;
	}

	public void setTpartyActions(Set<TpartyAction> tpartyActions) {
		this.tpartyActions = tpartyActions;
	}
	
	public Set<TpartyDetail> getTpartyDetails() {
		return this.tpartyDetails;
	}

	public void setTpartyDetails(Set<TpartyDetail> tpartyDetails) {
		this.tpartyDetails = tpartyDetails;
	}
	
	public Set<TtransactionCmpntXpsrLoc> getTtransactionCmpntXpsrLocs() {
		return this.ttransactionCmpntXpsrLocs;
	}

	public void setTtransactionCmpntXpsrLocs(Set<TtransactionCmpntXpsrLoc> ttransactionCmpntXpsrLocs) {
		this.ttransactionCmpntXpsrLocs = ttransactionCmpntXpsrLocs;
	}
	
	public Set<TuserPrefernce> getTuserPrefernces1() {
		return this.tuserPrefernces1;
	}

	public void setTuserPrefernces1(Set<TuserPrefernce> tuserPrefernces1) {
		this.tuserPrefernces1 = tuserPrefernces1;
	}
	
	public Set<TuserPrefernce> getTuserPrefernces2() {
		return this.tuserPrefernces2;
	}

	public void setTuserPrefernces2(Set<TuserPrefernce> tuserPrefernces2) {
		this.tuserPrefernces2 = tuserPrefernces2;
	}

	public Set<TmarketableProductLocation> getTmarketableProductLocation() {
		return tmarketableProductLocation;
	}

	public void setTmarketableProductLocation(
			Set<TmarketableProductLocation> tmarketableProductLocation) {
		this.tmarketableProductLocation = tmarketableProductLocation;
	}
	
}