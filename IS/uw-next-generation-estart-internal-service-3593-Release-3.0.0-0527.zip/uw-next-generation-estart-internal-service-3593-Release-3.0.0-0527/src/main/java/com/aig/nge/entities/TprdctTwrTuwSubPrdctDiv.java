package com.aig.nge.entities;


import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the TPRDCT_TWR_TUW_SUB_PRDCT_DIV database table.
 * 
 */
@Entity
@Table(name="TPRDCT_TWR_TUW_SUB_PRDCT_DIV")
public class TprdctTwrTuwSubPrdctDiv implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private TprdctTwrTuwSubPrdctDivPK id;

	@Column(name="CREATE_TS")
	private Timestamp createTs;

	@Column(name="CREATE_USER_ID")
	private String createUserId;

	@Column(name="DELETED_IN")
	private String deletedIn;

	@Column(name="UPDATE_TS")
	private Timestamp updateTs;

	@Column(name="UPDATE_USER_ID")
	private String updateUserId;

	//bi-directional many-to-one association to TproductTowerTuwSubProdct
    @ManyToOne
	@JoinColumn(name="PRODUCT_TOWER_TUW_SUBPRODCT_ID")
	private TproductTowerTuwSubProduct tproductTowerTuwSubProdct;

	//bi-directional many-to-one association to Tdivision
    @ManyToOne
	@JoinColumn(name="DIVISION_NO")
	private Tdivision tdivision;

    public TprdctTwrTuwSubPrdctDiv() {
    }

	public TprdctTwrTuwSubPrdctDivPK getId() {
		return this.id;
	}

	public void setId(TprdctTwrTuwSubPrdctDivPK id) {
		this.id = id;
	}
	
	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public String getDeletedIn() {
		return this.deletedIn;
	}

	public void setDeletedIn(String deletedIn) {
		this.deletedIn = deletedIn;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public TproductTowerTuwSubProduct getTproductTowerTuwSubProdct() {
		return this.tproductTowerTuwSubProdct;
	}

	public void setTproductTowerTuwSubProdct(TproductTowerTuwSubProduct tproductTowerTuwSubProdct) {
		this.tproductTowerTuwSubProdct = tproductTowerTuwSubProdct;
	}
	
	public Tdivision getTdivision() {
		return this.tdivision;
	}

	public void setTdivision(Tdivision tdivision) {
		this.tdivision = tdivision;
	}
	
}