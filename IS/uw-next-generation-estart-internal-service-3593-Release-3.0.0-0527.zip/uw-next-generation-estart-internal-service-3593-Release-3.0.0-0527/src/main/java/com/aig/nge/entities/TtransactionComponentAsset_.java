package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-02-24T11:59:50.593+0530")
@StaticMetamodel(TtransactionComponentAsset.class)
public class TtransactionComponentAsset_ {
	public static volatile SingularAttribute<TtransactionComponentAsset, TtransactionComponentAssetPK> id;
	public static volatile SingularAttribute<TtransactionComponentAsset, Timestamp> createTs;
	public static volatile SingularAttribute<TtransactionComponentAsset, String> createUserId;
	public static volatile SingularAttribute<TtransactionComponentAsset, String> deletedIn;
	public static volatile SingularAttribute<TtransactionComponentAsset, Short> systemId;
	public static volatile SingularAttribute<TtransactionComponentAsset, Timestamp> updateTs;
	public static volatile SingularAttribute<TtransactionComponentAsset, String> updateUserId;
	public static volatile SingularAttribute<TtransactionComponentAsset, Tasset> tasset;
	public static volatile SingularAttribute<TtransactionComponentAsset, TtransactionComponent> ttransactionComponent;
}
