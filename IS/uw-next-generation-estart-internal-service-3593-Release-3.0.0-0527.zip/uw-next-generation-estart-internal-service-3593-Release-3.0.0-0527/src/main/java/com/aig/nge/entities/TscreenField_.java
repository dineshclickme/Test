package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-02-24T11:59:50.227+0530")
@StaticMetamodel(TscreenField.class)
public class TscreenField_ {
	public static volatile SingularAttribute<TscreenField, TscreenFieldPK> id;
	public static volatile SingularAttribute<TscreenField, Timestamp> createTs;
	public static volatile SingularAttribute<TscreenField, String> createUserId;
	public static volatile SingularAttribute<TscreenField, String> displayNm;
	public static volatile SingularAttribute<TscreenField, Timestamp> updateTs;
	public static volatile SingularAttribute<TscreenField, String> updateUserId;
	public static volatile SingularAttribute<TscreenField, Tfield> tfield;
	public static volatile SingularAttribute<TscreenField, Thelp> thelp;
	public static volatile SingularAttribute<TscreenField, Tscreen> tscreen;
}
