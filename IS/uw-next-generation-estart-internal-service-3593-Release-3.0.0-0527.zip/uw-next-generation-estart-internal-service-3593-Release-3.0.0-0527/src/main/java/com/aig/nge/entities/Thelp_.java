package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SetAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-02-19T16:13:03.481+0530")
@StaticMetamodel(Thelp.class)
public class Thelp_ {
	public static volatile SingularAttribute<Thelp, Integer> helpId;
	public static volatile SingularAttribute<Thelp, Timestamp> createTs;
	public static volatile SingularAttribute<Thelp, String> createUserId;
	public static volatile SingularAttribute<Thelp, String> helpDs;
	public static volatile SingularAttribute<Thelp, String> helpTx;
	public static volatile SingularAttribute<Thelp, Timestamp> updateTs;
	public static volatile SingularAttribute<Thelp, String> updateUserId;
	public static volatile SetAttribute<Thelp, ThelpLanguage> thelpLanguages;
	public static volatile SetAttribute<Thelp, TscreenField> tscreenFields;
}
