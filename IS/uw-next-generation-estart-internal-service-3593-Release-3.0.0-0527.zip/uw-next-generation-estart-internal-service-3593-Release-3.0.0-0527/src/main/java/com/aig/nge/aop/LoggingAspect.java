package com.aig.nge.aop;

import java.util.Arrays;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.jpa.JpaSystemException;
import org.springframework.stereotype.Component;

import com.aig.nge.utilities.NGECommonUtil;
import com.aig.nge.utilities.NGEErrorCodes;
import com.aig.nge.utilities.NGEException;
import com.aig.nge.utilities.NGESession;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;


/**
 * @author Dineshkumar 
 * 09-Jan-2015 
 * This is AOP(Aspect Oriented Programming) class used
 * for logging the exception flows and method execution flows
 */
@Component
@Aspect
public class LoggingAspect {
	private static final Logger logger = LogManager.getLogger(LoggingAspect.class);
	@Autowired
	private NGEException ngeException;

	/**
	 * @param joinPoint
	 * @throws Throwable
	 * This method used for log the all methods execution under the com.aig package
	 * This AOP method is used for logging the different methods with different 
	 * data types so currently this method return type made as Object 
	 */
	@Around("execution(* com.aig..*(..))")
	public Object log(ProceedingJoinPoint joinPoint) throws Throwable {
		String packageName = joinPoint.getSignature().getDeclaringTypeName();
		String methodName = joinPoint.getSignature().getName();

		long start = System.currentTimeMillis();
		
		String requestMessageID = "Not Available";
		if(NGESession.getSessionData() != null && NGESession.getSessionData().getRequestMessageId() != null)
		{
			requestMessageID = NGESession.getSessionData().getRequestMessageId();			
		}

		logger.debug("RequestMessageID : " +requestMessageID+" Entering method [" + packageName + "." + methodName + "]");
		logger.debug("RequestMessageID : " +requestMessageID+" arguments : " + Arrays.toString(joinPoint.getArgs()));

		Object result = null;
		
		try {
			result  = joinPoint.proceed();
		} catch (JpaSystemException e) {
			logger.error(e.getMessage());
			ngeException.throwException(NGEErrorCodes.SERVICE_FAILED, NGEErrorCodes.ERROR_TYPE,
					e.getMessage(), null);
		}
		long elapsedTime = System.currentTimeMillis() - start;
		logger.debug("Exiting method [" + packageName + "." + methodName
				+ "]; exec time (ms): " + elapsedTime);

		return result;

	}

	@AfterThrowing(pointcut = "execution(* com.aig..*(..))", throwing = "error")
	public void logAfterThrowing(JoinPoint joinPoint, Throwable error) {

		String packageName = joinPoint.getSignature().getDeclaringTypeName();
		String methodName = joinPoint.getSignature().getName();
		String requestMessageID = "Not Available";
		if(NGESession.getSessionData() != null && NGESession.getSessionData().getRequestMessageId() != null)
		{
			requestMessageID = NGESession.getSessionData().getRequestMessageId();			
		}
		//eStart 2.8 December Release - Source code scan fix:Log forging 
		logger.error("RequestMessageID : " +NGECommonUtil.stripXSS(requestMessageID)+" Exception Occured [" + NGECommonUtil.stripXSS(packageName) + "." + NGECommonUtil.stripXSS(methodName)
				+ "] : "+error);
		
		

	}

}