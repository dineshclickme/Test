package com.aig.nge.dao;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.aig.nge.entities.TlegacyWipQuote;
import com.aig.nge.entities.Tpolicy;
import com.aig.nge.entities.TpolicyType;
import com.aig.nge.repository.TPolicyAttributeRepository;
import com.aig.nge.repository.TLegacyWipQuoteRepository;
import com.aig.nge.repository.TPolicyHRepository;
import com.aig.nge.repository.TPolicyRepository;
import com.aig.nge.repository.TPolicyTypeRepository;
import com.aig.nge.utilities.AIGCIExceptionMsg;
import com.aig.nge.utilities.NGEErrorCodes;

/**
 * @author Padma This DAO class is used for accessing the policy repository
 *         functions
 */

@Repository
public class PolicyDAO extends BaseDAO{

	@Autowired
	TPolicyRepository policyRepository;

	@Autowired
	TPolicyHRepository policyHRepository;

	@Autowired
	TPolicyTypeRepository policyTypeRepository;
	
	@Autowired
	private TLegacyWipQuoteRepository wipQuoteRepository;
	
	@Autowired
	TPolicyAttributeRepository policyAttributeRepository;

	/**
	 * @param policyNo
	 * @param issuingCompanyCd
	 * @param effectiveDate
	 * @return
	 * @throws AIGCIExceptionMsg
	 *             this method is used to get the policy information by using
	 *             the policyNo, issuingCompanyCd and effectiveDate
	 */

	public Tpolicy getPolicy(String policyNo, short issuingCompanyCd,
			Date effectiveDate) {
		Tpolicy policy = null;
		//PI3 Maintenance Release - Default Issuing company code policy conflicts starts
		
		List<Tpolicy> policyList = null; 
		policyList = policyRepository.findByPolicyNoAndCompanyCdAndEffectiveDt(
				policyNo, issuingCompanyCd, effectiveDate);
		
		if(policyList!=null && policyList.size()==1)
		{
			policy = policyList.get(0);
		}
		else if (policyList!= null){
			for(Tpolicy pol:policyList){
				if(pol.getCompanyCd()!=777){
					policy = pol;
				}
			}
		}
		
		//PI3 Maintenance Release - Default Issuing company code policy conflicts ends
		return policy;
	}

	/**
	 * @author Padma E
	 * @param policy
	 * @return
	 * @throws AIGCIExceptionMsg
	 *             this method is used to save the policy information in TPolicy
	 */

	public Tpolicy savePolicy(Tpolicy policy) {
		policy = policyRepository.save(policy);

		return policy;
	}

	/**
	 * @author Padma E
	 * @param policyTypeName
	 * @return
	 * @throws AIGCIExceptionMsg
	 *             this method is used to get the policy type information from
	 *             Tpolicy_type
	 */

	public TpolicyType getPolicyType(String policyTypeName) {
		TpolicyType policy = null;
		policy = policyTypeRepository.findByPolicyTypeNm(policyTypeName.toUpperCase());
		return policy;
	}
	public Tpolicy findpolicy(int policyId)
	{
		Tpolicy policy = null;
		policy = policyRepository.findOne(policyId);
		return policy;
	}
	
	/**
	 * 
	 * @param policyNo
	 * @return
	 * @throws AIGCIExceptionMsg
	 */
	public List<Tpolicy> getPolicyId(String policyNo) throws AIGCIExceptionMsg{
		
		List<Tpolicy> policyList = null;
		policyList = policyRepository.findByPolicyNo(policyNo);
		if(policyList.isEmpty()){
			ngeException.throwException( NGEErrorCodes.Invalid_Policy, NGEErrorCodes.ERROR_TYPE_LOGICAL, null,null);
		}
		return policyList;
	}	
	
	public List<Short> getUniquePolicyAttributeId(int policyId){
	
	List<Short> uniqueAttributeId = null; 
	uniqueAttributeId=policyAttributeRepository.getUniquePolicyAttributeId(policyId);
	return uniqueAttributeId;	
	}
	
	public List<String> getPolicyAttributeValues(short attributeId, int policyId){
		
		List<String> attributeValuesList = null; 
		attributeValuesList=policyAttributeRepository.getPolicyAttributeValues(attributeId, policyId);
		return attributeValuesList;	
	}

public List<TlegacyWipQuote> getWipQuoteByAcctPolicy(int policyNo,String prefixCd,int policyId){
	List<TlegacyWipQuote> legacyWipQuoteList=wipQuoteRepository.findByAccountingPolNoAndAcctngPolPrfxCdAndPolicyId(policyNo,prefixCd,policyId);
	return legacyWipQuoteList;
}

public Integer getMaxPloEventNo(int policyId){
	Integer  polEventNo=wipQuoteRepository.findMaxPolicyEventNo(policyId);
	if(polEventNo == null)
	{
		polEventNo = 0;
	}
	return polEventNo;
}

public TlegacyWipQuote getWipQuoteBypolEventNo(int policyId,int polEventNo){
	TlegacyWipQuote legacyWipQuote=wipQuoteRepository.findByAccountingPolNoAndAcctngPolPrfxCdAndPolicyIdandpolEventNo(policyId,polEventNo).get(0);
	return legacyWipQuote;
}

public TlegacyWipQuote getWipQuoteByPolicyId(int policyId){
	List<TlegacyWipQuote> legacyWipQuote=wipQuoteRepository.findBypolicyId(policyId);
	return legacyWipQuote.get(0);
}

/**
 * 
 * @param accountingPolicyNo
 * @param issuingCompanyCd
 * @param effectiveDate
 * @return
 * @throws AIGCIExceptionMsg
 */
public List<Tpolicy> getPolicyList(int policyNo,Short issuingCompanyCd,Date effectiveDt) throws AIGCIExceptionMsg{
	
	List<Tpolicy> policyList = null;
	policyList = policyRepository.getPolicy(policyNo, issuingCompanyCd, effectiveDt);
	
	return policyList;
}
}