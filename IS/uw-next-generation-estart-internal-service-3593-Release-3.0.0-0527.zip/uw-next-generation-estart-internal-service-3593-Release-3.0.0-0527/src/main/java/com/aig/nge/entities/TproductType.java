package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;

import org.apache.openjpa.persistence.DataCache;
import java.sql.Timestamp;
import java.util.Set;


/**
 * The persistent class for the TPRODUCT_TYPE database table.
 * 
 */
@Entity
@DataCache
@Table(name="TPRODUCT_TYPE")
public class TproductType implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="PRODUCT_TYPE_ID")
	private short productTypeId;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="CREATE_TS")
	private Timestamp createTs;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="CREATE_USER_ID")
	private String createUserId;

	@Column(name="PRODUCT_TYPE_NM")
	private String productTypeNm;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="UPDATE_TS")
	private Timestamp updateTs;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="UPDATE_USER_ID")
	private String updateUserId;

	//bi-directional many-to-one association to Tproduct
	@OneToMany(mappedBy="tproductType", cascade={CascadeType.ALL})
	private Set<Tproduct> tproducts;

    public TproductType() {
    }

	public short getProductTypeId() {
		return this.productTypeId;
	}

	public void setProductTypeId(short productTypeId) {
		this.productTypeId = productTypeId;
	}

	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public String getProductTypeNm() {
		return this.productTypeNm;
	}

	public void setProductTypeNm(String productTypeNm) {
		this.productTypeNm = productTypeNm;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public Set<Tproduct> getTproducts() {
		return this.tproducts;
	}

	public void setTproducts(Set<Tproduct> tproducts) {
		this.tproducts = tproducts;
	}
	
}