package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the TERROR_MAPPING database table.
 * 
 */
@Embeddable
public class TerrorMappingPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="ERROR_ID")
	private short errorId;

	@Column(name="LEGACY_ERROR_ID")
	private short legacyErrorId;

    public TerrorMappingPK() {
    }
	public short getErrorId() {
		return this.errorId;
	}
	public void setErrorId(short errorId) {
		this.errorId = errorId;
	}
	public short getLegacyErrorId() {
		return this.legacyErrorId;
	}
	public void setLegacyErrorId(short legacyErrorId) {
		this.legacyErrorId = legacyErrorId;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof TerrorMappingPK)) {
			return false;
		}
		TerrorMappingPK castOther = (TerrorMappingPK)other;
		return 
			(this.errorId == castOther.errorId)
			&& (this.legacyErrorId == castOther.legacyErrorId);

    }
    
	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + ((int) this.errorId);
		hash = hash * prime + ((int) this.legacyErrorId);
		
		return hash;
    }
}