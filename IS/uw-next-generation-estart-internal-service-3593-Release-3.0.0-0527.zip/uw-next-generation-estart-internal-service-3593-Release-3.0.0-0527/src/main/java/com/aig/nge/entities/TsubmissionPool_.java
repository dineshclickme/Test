package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-06-19T14:59:46.037+0530")
@StaticMetamodel(TsubmissionPool.class)
public class TsubmissionPool_ {
	public static volatile SingularAttribute<TsubmissionPool, String> submissionPoolId;
	public static volatile SingularAttribute<TsubmissionPool, Timestamp> createTs;
	public static volatile SingularAttribute<TsubmissionPool, String> createUserId;
	public static volatile SingularAttribute<TsubmissionPool, Timestamp> updateTs;
	public static volatile SingularAttribute<TsubmissionPool, String> updateUserId;
	public static volatile SingularAttribute<TsubmissionPool, String> usedIn;
}
