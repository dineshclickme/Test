package com.aig.nge.entities;

import java.sql.Timestamp;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-02-19T16:13:03.705+0530")
@StaticMetamodel(TmlobExcludeBlockByType.class)
public class TmlobExcludeBlockByType_ {
	public static volatile SingularAttribute<TmlobExcludeBlockByType, String> mlobExcludeBlockByTypeId;
	public static volatile SingularAttribute<TmlobExcludeBlockByType, String> productTowerId;
	public static volatile SingularAttribute<TmlobExcludeBlockByType, String> locationId;
	public static volatile SingularAttribute<TmlobExcludeBlockByType, String> divisionNo;
	public static volatile SingularAttribute<TmlobExcludeBlockByType, String> masterLobCd;
	public static volatile SingularAttribute<TmlobExcludeBlockByType, String> coverageLineCd;
	public static volatile SingularAttribute<TmlobExcludeBlockByType, Timestamp> createTs;
	public static volatile SingularAttribute<TmlobExcludeBlockByType, String> createUserId;
	public static volatile SingularAttribute<TmlobExcludeBlockByType, Timestamp> updateTs;
	public static volatile SingularAttribute<TmlobExcludeBlockByType, String> updateUserId;
	public static volatile SingularAttribute<TmlobExcludeBlockByType, TexcludeBlockType> excludeBlockType;
}
