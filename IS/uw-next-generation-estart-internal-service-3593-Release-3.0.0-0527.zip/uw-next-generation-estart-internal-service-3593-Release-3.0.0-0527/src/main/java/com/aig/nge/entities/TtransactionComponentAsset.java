package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the TTRANSACTION_COMPONENT_ASSET database table.
 * 
 */
@Entity
@Table(name="TTRANSACTION_COMPONENT_ASSET")
public class TtransactionComponentAsset implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private TtransactionComponentAssetPK id;

	@Column(name="CREATE_TS")
	private Timestamp createTs;

	@Column(name="CREATE_USER_ID")
	private String createUserId;

	@Column(name="DELETED_IN")
	private String deletedIn;

	@Column(name="SYSTEM_ID")
	private short systemId;

	@Column(name="UPDATE_TS")
	private Timestamp updateTs;

	@Column(name="UPDATE_USER_ID")
	private String updateUserId;

	//bi-directional many-to-one association to Tasset
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="ASSET_ID")
	private Tasset tasset;

	//bi-directional many-to-one association to TtransactionComponent
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="TRANSACTION_COMPONENT_ID")
	private TtransactionComponent ttransactionComponent;

    public TtransactionComponentAsset() {
    }

	public TtransactionComponentAssetPK getId() {
		return this.id;
	}

	public void setId(TtransactionComponentAssetPK id) {
		this.id = id;
	}
	
	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public String getDeletedIn() {
		return this.deletedIn;
	}

	public void setDeletedIn(String deletedIn) {
		this.deletedIn = deletedIn;
	}

	public short getSystemId() {
		return this.systemId;
	}

	public void setSystemId(short systemId) {
		this.systemId = systemId;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public Tasset getTasset() {
		return this.tasset;
	}

	public void setTasset(Tasset tasset) {
		this.tasset = tasset;
	}
	
	public TtransactionComponent getTtransactionComponent() {
		return this.ttransactionComponent;
	}

	public void setTtransactionComponent(TtransactionComponent ttransactionComponent) {
		this.ttransactionComponent = ttransactionComponent;
	}
	
}