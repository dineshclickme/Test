package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;
import org.apache.openjpa.persistence.DataCache;
import java.sql.Timestamp;
import java.util.Set;


/**
 * The persistent class for the TDATA_TYPE database table.
 * 
 */
@Entity
@DataCache
@Table(name="TDATA_TYPE")
public class TdataType implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="DATA_TYPE_ID")
	private short dataTypeId;

	@Basic(fetch=FetchType.LAZY)
	@Column(name="CREATE_TS")
	private Timestamp createTs;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="CREATE_USER_ID")
	private String createUserId;

	@Column(name="DATA_TYPE_NM")
	private String dataTypeNm;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="UPDATE_TS")
	private Timestamp updateTs;

	@Basic(fetch=FetchType.LAZY)
	@Column(name="UPDATE_USER_ID")
	private String updateUserId;

	//bi-directional many-to-one association to Tattribute
	@OneToMany(mappedBy="tdataType", cascade={CascadeType.ALL})
	private Set<Tattribute> tattributes;

    public TdataType() {
    }

	public short getDataTypeId() {
		return this.dataTypeId;
	}

	public void setDataTypeId(short dataTypeId) {
		this.dataTypeId = dataTypeId;
	}

	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public String getDataTypeNm() {
		return this.dataTypeNm;
	}

	public void setDataTypeNm(String dataTypeNm) {
		this.dataTypeNm = dataTypeNm;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public Set<Tattribute> getTattributes() {
		return this.tattributes;
	}

	public void setTattributes(Set<Tattribute> tattributes) {
		this.tattributes = tattributes;
	}
	
}