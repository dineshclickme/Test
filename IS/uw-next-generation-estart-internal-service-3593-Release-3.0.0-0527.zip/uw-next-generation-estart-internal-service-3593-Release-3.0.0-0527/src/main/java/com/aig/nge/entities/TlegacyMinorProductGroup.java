package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Date;
import java.util.Set;


/**
 * The persistent class for the TLEGACY_MINOR_PRODUCT_GROUP database table.
 * 
 */
@Entity
@Table(name="TLEGACY_MINOR_PRODUCT_GROUP")
public class TlegacyMinorProductGroup implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private TlegacyMinorProductGroupPK id;

	@Column(name="CREATED_BY_ID")
	private String createdById;

    @Temporal( TemporalType.DATE)
	@Column(name="ENTERED_DT")
	private Date enteredDt;

	@Column(name="LAST_UPDT_TS")
	private Timestamp lastUpdtTs;

	@Column(name="LAST_UPDT_USER_ID")
	private String lastUpdtUserId;

	@Column(name="MNR_PRODUCT_GRP_NM")
	private String mnrProductGrpNm;

	//bi-directional many-to-one association to TlegacyMajorProductGroup
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="MJR_PRODUCT_GRP_CD")
	private TlegacyMajorProductGroup tlegacyMajorProductGroup;

	//bi-directional many-to-one association to TlegacyProduct
	@OneToMany(mappedBy="tlegacyMinorProductGroup")
	private Set<TlegacyProduct> tlegacyProducts;

    public TlegacyMinorProductGroup() {
    }

	public TlegacyMinorProductGroupPK getId() {
		return this.id;
	}

	public void setId(TlegacyMinorProductGroupPK id) {
		this.id = id;
	}
	
	public String getCreatedById() {
		return this.createdById;
	}

	public void setCreatedById(String createdById) {
		this.createdById = createdById;
	}

	public Date getEnteredDt() {
		return this.enteredDt;
	}

	public void setEnteredDt(Date enteredDt) {
		this.enteredDt = enteredDt;
	}

	public Timestamp getLastUpdtTs() {
		return this.lastUpdtTs;
	}

	public void setLastUpdtTs(Timestamp lastUpdtTs) {
		this.lastUpdtTs = lastUpdtTs;
	}

	public String getLastUpdtUserId() {
		return this.lastUpdtUserId;
	}

	public void setLastUpdtUserId(String lastUpdtUserId) {
		this.lastUpdtUserId = lastUpdtUserId;
	}

	public String getMnrProductGrpNm() {
		return this.mnrProductGrpNm;
	}

	public void setMnrProductGrpNm(String mnrProductGrpNm) {
		this.mnrProductGrpNm = mnrProductGrpNm;
	}

	public TlegacyMajorProductGroup getTlegacyMajorProductGroup() {
		return this.tlegacyMajorProductGroup;
	}

	public void setTlegacyMajorProductGroup(TlegacyMajorProductGroup tlegacyMajorProductGroup) {
		this.tlegacyMajorProductGroup = tlegacyMajorProductGroup;
	}
	
	public Set<TlegacyProduct> getTlegacyProducts() {
		return this.tlegacyProducts;
	}

	public void setTlegacyProducts(Set<TlegacyProduct> tlegacyProducts) {
		this.tlegacyProducts = tlegacyProducts;
	}
	
}