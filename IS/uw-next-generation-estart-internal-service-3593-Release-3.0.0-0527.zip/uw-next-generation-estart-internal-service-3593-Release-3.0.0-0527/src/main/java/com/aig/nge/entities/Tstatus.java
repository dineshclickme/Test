package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;

import org.apache.openjpa.persistence.DataCache;
import java.sql.Timestamp;
import java.util.Set;


/**
 * The persistent class for the TSTATUS database table.
 * 
 */
@Entity
@DataCache
public class Tstatus implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="STATUS_ID")
	private short statusId;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="CREATE_TS")
	private Timestamp createTs;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="CREATE_USER_ID")
	private String createUserId;

	@Column(name="STATUS_DS")
	private String statusDs;

	@Column(name="STATUS_NM")
	private String statusNm;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="UPDATE_TS")
	private Timestamp updateTs;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="UPDATE_USER_ID")
	private String updateUserId;

	//bi-directional many-to-one association to Tblock
	@OneToMany(mappedBy="tstatus", cascade={CascadeType.ALL})
	private Set<Tblock> tblocks;

	//bi-directional many-to-one association to Tbranch
	@OneToMany(mappedBy="tstatus")
	private Set<Tbranch> tbranches;

	//bi-directional many-to-one association to Tevent
	@OneToMany(mappedBy="tstatus1", cascade={CascadeType.ALL})
	private Set<Tevent> tevents1;

	//bi-directional many-to-one association to Tevent
	@OneToMany(mappedBy="tstatus2", cascade={CascadeType.ALL})
	private Set<Tevent> tevents2;

	//bi-directional many-to-one association to TproductTowerAutoCloseRule
	@OneToMany(mappedBy="tstatus1", cascade={CascadeType.ALL})
	private Set<TproductTowerAutoCloseRule> tproductTowerAutoCloseRules1;

	//bi-directional many-to-one association to TproductTowerAutoCloseRule
	@OneToMany(mappedBy="tstatus2", cascade={CascadeType.ALL})
	private Set<TproductTowerAutoCloseRule> tproductTowerAutoCloseRules2;

	//bi-directional many-to-one association to TproductTowerAutoCloseRule
	@OneToMany(mappedBy="tstatus3", cascade={CascadeType.ALL})
	private Set<TproductTowerAutoCloseRule> tproductTowerAutoCloseRules3;

	//bi-directional many-to-one association to TproductTowerAutoCloseRule
	@OneToMany(mappedBy="tstatus4", cascade={CascadeType.ALL})
	private Set<TproductTowerAutoCloseRule> tproductTowerAutoCloseRules4;

	//bi-directional many-to-one association to TstatusType
	@ManyToOne
	@JoinColumn(name="STATUS_TYPE_ID")
	private TstatusType tstatusType;

	//bi-directional many-to-one association to TstatusCondition
	@OneToMany(mappedBy="tstatus1", cascade={CascadeType.ALL})
	private Set<TstatusCondition> tstatusConditions1;

	//bi-directional many-to-one association to TstatusCondition
	@OneToMany(mappedBy="tstatus2", cascade={CascadeType.ALL})
	private Set<TstatusCondition> tstatusConditions2;

	//bi-directional many-to-one association to TstatusReasonType
	@OneToMany(mappedBy="tstatus", cascade={CascadeType.ALL})
	private Set<TstatusReasonType> tstatusReasonTypes;

	//bi-directional many-to-one association to TstatusTransition
	@OneToMany(mappedBy="tstatus", cascade={CascadeType.ALL})
	private Set<TstatusTransition> tstatusTransitions;

	//bi-directional many-to-one association to TtransactionComponentStatus
	@OneToMany(mappedBy="tstatus", cascade={CascadeType.ALL})
	private Set<TtransactionComponentStatus> ttransactionComponentStatuses;

    public Tstatus() {
    }

	public short getStatusId() {
		return this.statusId;
	}

	public void setStatusId(short statusId) {
		this.statusId = statusId;
	}

	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public String getStatusDs() {
		return this.statusDs;
	}

	public void setStatusDs(String statusDs) {
		this.statusDs = statusDs;
	}

	public String getStatusNm() {
		if(this.statusNm!= null)
			return this.statusNm.trim();
		else
			return this.statusNm;
	}

	public void setStatusNm(String statusNm) {
		this.statusNm = statusNm;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public Set<Tblock> getTblocks() {
		return this.tblocks;
	}

	public void setTblocks(Set<Tblock> tblocks) {
		this.tblocks = tblocks;
	}
	
	public Set<Tbranch> getTbranches() {
		return this.tbranches;
	}

	public void setTbranches(Set<Tbranch> tbranches) {
		this.tbranches = tbranches;
	}
	
	public Set<Tevent> getTevents1() {
		return this.tevents1;
	}

	public void setTevents1(Set<Tevent> tevents1) {
		this.tevents1 = tevents1;
	}
	
	public Set<Tevent> getTevents2() {
		return this.tevents2;
	}

	public void setTevents2(Set<Tevent> tevents2) {
		this.tevents2 = tevents2;
	}
	
	public Set<TproductTowerAutoCloseRule> getTproductTowerAutoCloseRules1() {
		return this.tproductTowerAutoCloseRules1;
	}

	public void setTproductTowerAutoCloseRules1(Set<TproductTowerAutoCloseRule> tproductTowerAutoCloseRules1) {
		this.tproductTowerAutoCloseRules1 = tproductTowerAutoCloseRules1;
	}
	
	public Set<TproductTowerAutoCloseRule> getTproductTowerAutoCloseRules2() {
		return this.tproductTowerAutoCloseRules2;
	}

	public void setTproductTowerAutoCloseRules2(Set<TproductTowerAutoCloseRule> tproductTowerAutoCloseRules2) {
		this.tproductTowerAutoCloseRules2 = tproductTowerAutoCloseRules2;
	}
	
	public Set<TproductTowerAutoCloseRule> getTproductTowerAutoCloseRules3() {
		return this.tproductTowerAutoCloseRules3;
	}

	public void setTproductTowerAutoCloseRules3(Set<TproductTowerAutoCloseRule> tproductTowerAutoCloseRules3) {
		this.tproductTowerAutoCloseRules3 = tproductTowerAutoCloseRules3;
	}
	
	public Set<TproductTowerAutoCloseRule> getTproductTowerAutoCloseRules4() {
		return this.tproductTowerAutoCloseRules4;
	}

	public void setTproductTowerAutoCloseRules4(Set<TproductTowerAutoCloseRule> tproductTowerAutoCloseRules4) {
		this.tproductTowerAutoCloseRules4 = tproductTowerAutoCloseRules4;
	}
	
	public TstatusType getTstatusType() {
		return this.tstatusType;
	}

	public void setTstatusType(TstatusType tstatusType) {
		this.tstatusType = tstatusType;
	}
	
	public Set<TstatusCondition> getTstatusConditions1() {
		return this.tstatusConditions1;
	}

	public void setTstatusConditions1(Set<TstatusCondition> tstatusConditions1) {
		this.tstatusConditions1 = tstatusConditions1;
	}
	
	public Set<TstatusCondition> getTstatusConditions2() {
		return this.tstatusConditions2;
	}

	public void setTstatusConditions2(Set<TstatusCondition> tstatusConditions2) {
		this.tstatusConditions2 = tstatusConditions2;
	}
	
	public Set<TstatusReasonType> getTstatusReasonTypes() {
		return this.tstatusReasonTypes;
	}

	public void setTstatusReasonTypes(Set<TstatusReasonType> tstatusReasonTypes) {
		this.tstatusReasonTypes = tstatusReasonTypes;
	}
	
	public Set<TstatusTransition> getTstatusTransitions() {
		return this.tstatusTransitions;
	}

	public void setTstatusTransitions(Set<TstatusTransition> tstatusTransitions) {
		this.tstatusTransitions = tstatusTransitions;
	}
	
	public Set<TtransactionComponentStatus> getTtransactionComponentStatuses() {
		return this.ttransactionComponentStatuses;
	}

	public void setTtransactionComponentStatuses(Set<TtransactionComponentStatus> ttransactionComponentStatuses) {
		this.ttransactionComponentStatuses = ttransactionComponentStatuses;
	}
	
}