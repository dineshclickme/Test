package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;

import org.springframework.data.domain.Persistable;

import java.sql.Timestamp;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the TPOLICY_HS database table.
 * 
 */
@Entity
@Table(name="TPOLICY_HS")
public class TpolicyH implements Persistable<Serializable> {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private TpolicyHPK id;

	@Column(name="COMPANY_CD")
	private short companyCd;

	@Column(name="CREATE_TS")
	private Timestamp createTs;

	@Column(name="CREATE_USER_ID")
	private String createUserId;

    @Temporal( TemporalType.DATE)
	@Column(name="EFFECTIVE_DT")
	private Date effectiveDt;

    @Temporal( TemporalType.DATE)
	@Column(name="EXPIRATION_DT")
	private Date expirationDt;

	@Column(name="LOCAL_CURRENCY_ID")
	private short localCurrencyId;

	@Column(name="LOCAL_CURRENCY_PREMIUM_AM")
	private BigDecimal localCurrencyPremiumAm;

	@Column(name="POLICY_NO")
	private String policyNo;

	@Column(name="POLICY_TYPE_ID")
	private short policyTypeId;

	@Column(name="PREMIUM_AM")
	private BigDecimal premiumAm;

	@Column(name="SYSTEM_ID")
	private short systemId;

	@Column(name="UPDATE_TS")
	private Timestamp updateTs;

	@Column(name="UPDATE_USER_ID")
	private String updateUserId;

    public TpolicyH() {
    }

	public TpolicyHPK getId() {
		return this.id;
	}

	public void setId(TpolicyHPK id) {
		this.id = id;
	}
	
	public short getCompanyCd() {
		return this.companyCd;
	}

	public void setCompanyCd(short companyCd) {
		this.companyCd = companyCd;
	}

	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public Date getEffectiveDt() {
		return this.effectiveDt;
	}

	public void setEffectiveDt(Date effectiveDt) {
		this.effectiveDt = effectiveDt;
	}

	public Date getExpirationDt() {
		return this.expirationDt;
	}

	public void setExpirationDt(Date expirationDt) {
		this.expirationDt = expirationDt;
	}

	public short getLocalCurrencyId() {
		return this.localCurrencyId;
	}

	public void setLocalCurrencyId(short localCurrencyId) {
		this.localCurrencyId = localCurrencyId;
	}

	public BigDecimal getLocalCurrencyPremiumAm() {
		return this.localCurrencyPremiumAm;
	}

	public void setLocalCurrencyPremiumAm(BigDecimal localCurrencyPremiumAm) {
		this.localCurrencyPremiumAm = localCurrencyPremiumAm;
	}

	public String getPolicyNo() {
		return this.policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public short getPolicyTypeId() {
		return this.policyTypeId;
	}

	public void setPolicyTypeId(short policyTypeId) {
		this.policyTypeId = policyTypeId;
	}

	public BigDecimal getPremiumAm() {
		return this.premiumAm;
	}

	public void setPremiumAm(BigDecimal premiumAm) {
		this.premiumAm = premiumAm;
	}

	public short getSystemId() {
		return this.systemId;
	}

	public void setSystemId(short systemId) {
		this.systemId = systemId;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	@Override
	public boolean isNew() {
		// TODO Auto-generated method stub
		return true;
	}
}