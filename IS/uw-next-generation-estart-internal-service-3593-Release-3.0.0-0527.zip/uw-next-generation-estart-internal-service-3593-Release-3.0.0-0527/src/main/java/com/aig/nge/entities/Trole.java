package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;

import org.apache.openjpa.persistence.DataCache;
import java.sql.Timestamp;
import java.util.Set;


/**
 * The persistent class for the TROLE database table.
 * 
 */
@Entity
@DataCache
public class Trole implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="ROLE_ID")
	private short roleId;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="CREATE_TS")
	private Timestamp createTs;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="CREATE_USER_ID")
	private String createUserId;

	@Column(name="ROLE_NM")
	private String roleNm;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="UPDATE_TS")
	private Timestamp updateTs;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="UPDATE_USER_ID")
	private String updateUserId;

	//bi-directional many-to-one association to Tblock
	@OneToMany(mappedBy="trole")
	private Set<Tblock> tblocks;

	//bi-directional many-to-one association to TpartyAction
	@OneToMany(mappedBy="trole", cascade={CascadeType.ALL})
	private Set<TpartyAction> tpartyActions;

	//bi-directional many-to-one association to TproductTowerParty
	@OneToMany(mappedBy="trole", cascade={CascadeType.ALL})
	private Set<TproductTowerParty> tproductTowerParties;

	//bi-directional many-to-one association to TpartyType
	@ManyToOne
	@JoinColumn(name="PARTY_TYPE_ID")
	private TpartyType tpartyType;

	//bi-directional many-to-one association to TtransactionComponentParty
	@OneToMany(mappedBy="trole", cascade={CascadeType.ALL})
	private Set<TtransactionComponentParty> ttransactionComponentParties;

	//bi-directional many-to-one association to TtransactionParty
	@OneToMany(mappedBy="trole", cascade={CascadeType.ALL})
	private Set<TtransactionParty> ttransactionParties;

    public Trole() {
    }

	public short getRoleId() {
		return this.roleId;
	}

	public void setRoleId(short roleId) {
		this.roleId = roleId;
	}

	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public String getRoleNm() {
		return this.roleNm;
	}

	public void setRoleNm(String roleNm) {
		this.roleNm = roleNm;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public Set<Tblock> getTblocks() {
		return this.tblocks;
	}

	public void setTblocks(Set<Tblock> tblocks) {
		this.tblocks = tblocks;
	}
	
	public Set<TpartyAction> getTpartyActions() {
		return this.tpartyActions;
	}

	public void setTpartyActions(Set<TpartyAction> tpartyActions) {
		this.tpartyActions = tpartyActions;
	}
	
	public Set<TproductTowerParty> getTproductTowerParties() {
		return this.tproductTowerParties;
	}

	public void setTproductTowerParties(Set<TproductTowerParty> tproductTowerParties) {
		this.tproductTowerParties = tproductTowerParties;
	}
	
	public TpartyType getTpartyType() {
		return this.tpartyType;
	}

	public void setTpartyType(TpartyType tpartyType) {
		this.tpartyType = tpartyType;
	}
	
	public Set<TtransactionComponentParty> getTtransactionComponentParties() {
		return this.ttransactionComponentParties;
	}

	public void setTtransactionComponentParties(Set<TtransactionComponentParty> ttransactionComponentParties) {
		this.ttransactionComponentParties = ttransactionComponentParties;
	}
	
	public Set<TtransactionParty> getTtransactionParties() {
		return this.ttransactionParties;
	}

	public void setTtransactionParties(Set<TtransactionParty> ttransactionParties) {
		this.ttransactionParties = ttransactionParties;
	}
	
}