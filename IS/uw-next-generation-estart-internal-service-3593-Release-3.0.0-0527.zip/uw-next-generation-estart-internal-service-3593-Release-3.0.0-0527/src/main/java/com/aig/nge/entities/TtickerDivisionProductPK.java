package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the TTICKER_DIVISION_PRODUCT database table.
 * 
 */
@Embeddable
public class TtickerDivisionProductPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="FEED_ID")
	private short feedId;

	@Column(name="FEED_SQN")
	private short feedSqn;

    public TtickerDivisionProductPK() {
    }
	public short getFeedId() {
		return this.feedId;
	}
	public void setFeedId(short feedId) {
		this.feedId = feedId;
	}
	public short getFeedSqn() {
		return this.feedSqn;
	}
	public void setFeedSqn(short feedSqn) {
		this.feedSqn = feedSqn;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof TtickerDivisionProductPK)) {
			return false;
		}
		TtickerDivisionProductPK castOther = (TtickerDivisionProductPK)other;
		return 
			(this.feedId == castOther.feedId)
			&& (this.feedSqn == castOther.feedSqn);

    }
    
	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + ((int) this.feedId);
		hash = hash * prime + ((int) this.feedSqn);
		
		return hash;
    }
}