package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the THELP_LANGUAGE database table.
 * 
 */
@Embeddable
public class ThelpLanguagePK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="HELP_ID")
	private int helpId;

	@Column(name="LANGUAGE_ID")
	private short languageId;

    public ThelpLanguagePK() {
    }
	public int getHelpId() {
		return this.helpId;
	}
	public void setHelpId(int helpId) {
		this.helpId = helpId;
	}
	public short getLanguageId() {
		return this.languageId;
	}
	public void setLanguageId(short languageId) {
		this.languageId = languageId;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof ThelpLanguagePK)) {
			return false;
		}
		ThelpLanguagePK castOther = (ThelpLanguagePK)other;
		return 
			(this.helpId == castOther.helpId)
			&& (this.languageId == castOther.languageId);

    }
    
	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.helpId;
		hash = hash * prime + ((int) this.languageId);
		
		return hash;
    }
}