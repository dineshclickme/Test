package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the TASSET_ATTRIBUTE database table.
 * 
 */
@Embeddable
public class TassetAttributePK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="ASSET_ID")
	private int assetId;

	@Column(name="ATTRIBUTE_ID")
	private short attributeId;

	@Column(name="ATTRIBUTE_SQN")
	private short attributeSqn;

    public TassetAttributePK() {
    }
	public int getAssetId() {
		return this.assetId;
	}
	public void setAssetId(int assetId) {
		this.assetId = assetId;
	}
	public short getAttributeId() {
		return this.attributeId;
	}
	public void setAttributeId(short attributeId) {
		this.attributeId = attributeId;
	}
	public short getAttributeSqn() {
		return this.attributeSqn;
	}
	public void setAttributeSqn(short attributeSqn) {
		this.attributeSqn = attributeSqn;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof TassetAttributePK)) {
			return false;
		}
		TassetAttributePK castOther = (TassetAttributePK)other;
		return 
			(this.assetId == castOther.assetId)
			&& (this.attributeId == castOther.attributeId)
			&& (this.attributeSqn == castOther.attributeSqn);

    }
    
	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.assetId;
		hash = hash * prime + ((int) this.attributeId);
		hash = hash * prime + ((int) this.attributeSqn);
		
		return hash;
    }
}