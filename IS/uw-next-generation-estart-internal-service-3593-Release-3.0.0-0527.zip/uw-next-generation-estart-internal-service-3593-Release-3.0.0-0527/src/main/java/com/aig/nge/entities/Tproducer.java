package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the TPRODUCER database table.
 * 
 */
@Entity
public class Tproducer implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="PARTY_ID")
	private int partyId;

	@Column(name="CREATE_TS")
	private Timestamp createTs;

	@Column(name="CREATE_USER_ID")
	private String createUserId;

	@Column(name="ORGANIZATION_NM")
	private String organizationNm;

	@Column(name="UPDATE_TS")
	private Timestamp updateTs;

	@Column(name="UPDATE_USER_ID")
	private String updateUserId;

	//bi-directional one-to-one association to Tparty
	@OneToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="PARTY_ID")
	private Tparty tparty;

    public Tproducer() {
    }

	public int getPartyId() {
		return this.partyId;
	}

	public void setPartyId(int partyId) {
		this.partyId = partyId;
	}

	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public String getOrganizationNm() {
		return this.organizationNm;
	}

	public void setOrganizationNm(String organizationNm) {
		this.organizationNm = organizationNm;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public Tparty getTparty() {
		return this.tparty;
	}

	public void setTparty(Tparty tparty) {
		this.tparty = tparty;
	}
	
}