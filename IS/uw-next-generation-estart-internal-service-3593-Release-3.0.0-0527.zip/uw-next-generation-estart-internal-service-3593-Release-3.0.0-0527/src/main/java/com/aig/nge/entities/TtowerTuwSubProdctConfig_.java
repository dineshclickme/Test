package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-08-04T13:12:21.582+0530")
@StaticMetamodel(TtowerTuwSubProdctConfig.class)
public class TtowerTuwSubProdctConfig_ {
	public static volatile SingularAttribute<TtowerTuwSubProdctConfig, TtowerTuwSubProdctConfigPK> id;
	public static volatile SingularAttribute<TtowerTuwSubProdctConfig, Timestamp> createTs;
	public static volatile SingularAttribute<TtowerTuwSubProdctConfig, String> createUserId;
	public static volatile SingularAttribute<TtowerTuwSubProdctConfig, Timestamp> updateTs;
	public static volatile SingularAttribute<TtowerTuwSubProdctConfig, String> updateUserId;
	public static volatile SingularAttribute<TtowerTuwSubProdctConfig, TproductTowerConfiguration> tproductTowerConfiguration;
	public static volatile SingularAttribute<TtowerTuwSubProdctConfig, TtuwSubProduct> ttuwSubProduct;
}
