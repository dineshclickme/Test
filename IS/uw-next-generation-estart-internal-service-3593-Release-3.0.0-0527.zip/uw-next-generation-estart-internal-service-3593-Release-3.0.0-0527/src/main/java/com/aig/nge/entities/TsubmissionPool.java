package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the TSUBMISSION_POOL database table.
 * 
 */
@Entity
@Table(name="TSUBMISSION_POOL")
public class TsubmissionPool implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="SUBMISSION_POOL_ID")
	private String submissionPoolId;

	@Column(name="CREATE_TS")
	private Timestamp createTs;

	@Column(name="CREATE_USER_ID")
	private String createUserId;

	@Column(name="SUBMISSION_NO")
	private String submissionNo;

	@Column(name="UPDATE_TS")
	private Timestamp updateTs;

	@Column(name="UPDATE_USER_ID")
	private String updateUserId;

	@Column(name="USED_IN")
	private String usedIn;

    public TsubmissionPool() {
    }

	public String getSubmissionPoolId() {
		return this.submissionPoolId;
	}

	public void setSubmissionPoolId(String submissionPoolId) {
		this.submissionPoolId = submissionPoolId;
	}

	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public String getSubmissionNo() {
		return this.submissionNo;
	}

	public void setSubmissionNo(String submissionNo) {
		this.submissionNo = submissionNo;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public String getUsedIn() {
		return this.usedIn;
	}

	public void setUsedIn(String usedIn) {
		this.usedIn = usedIn;
	}

}