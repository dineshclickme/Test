package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;

import org.springframework.data.domain.Persistable;

import java.sql.Timestamp;


/**
 * The persistent class for the TTRANSACTION_ATTRIBUTE_HS database table.
 * 
 */
@Entity
@Table(name="TTRANSACTION_ATTRIBUTE_HS")
public class TtransactionAttributeH implements Persistable<Serializable> {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private TtransactionAttributeHPK id;

	@Column(name="ATTRIBUTE_VAL")
	private String attributeVal;

	@Column(name="CREATE_TS")
	private Timestamp createTs;

	@Column(name="CREATE_USER_ID")
	private String createUserId;

	@Column(name="SYSTEM_ID")
	private short systemId;

	@Column(name="UPDATE_TS")
	private Timestamp updateTs;

	@Column(name="UPDATE_USER_ID")
	private String updateUserId;

    public TtransactionAttributeH() {
    }

	public TtransactionAttributeHPK getId() {
		return this.id;
	}

	public void setId(TtransactionAttributeHPK id) {
		this.id = id;
	}
	
	public String getAttributeVal() {
		return this.attributeVal;
	}

	public void setAttributeVal(String attributeVal) {
		this.attributeVal = attributeVal;
	}

	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public short getSystemId() {
		return this.systemId;
	}

	public void setSystemId(short systemId) {
		this.systemId = systemId;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	@Override
	public boolean isNew() {
		// TODO Auto-generated method stub
		return true;
	}
}