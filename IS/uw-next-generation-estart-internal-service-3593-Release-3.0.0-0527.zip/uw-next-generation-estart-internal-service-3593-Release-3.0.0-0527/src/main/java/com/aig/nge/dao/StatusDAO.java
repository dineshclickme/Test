package com.aig.nge.dao;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.jpa.JpaSystemException;
import org.springframework.stereotype.Repository;

import com.aig.nge.entities.TproductState;
import com.aig.nge.entities.Tstatus;
import com.aig.nge.entities.TstatusType;
import com.aig.nge.entities.TtransactionComponent;
import com.aig.nge.entities.TtransactionComponentStatus;
import com.aig.nge.entities.TtransactionComponentStatusPK;
import com.aig.nge.repository.TCompnentStatusAttributeRepository;
import com.aig.nge.repository.TProductStateRepository;
import com.aig.nge.repository.TReasonRepository;
import com.aig.nge.repository.TStatusRepository;
import com.aig.nge.repository.TStatusTypeRepository;
import com.aig.nge.repository.TTransactionComponentStatusRepository;
import com.aig.nge.utilities.AIGCIExceptionMsg;
import com.aig.nge.utilities.NGEConstants;
import com.aig.nge.utilities.NGEDateUtil;
import com.aig.nge.utilities.NGEErrorCodes;
import com.aig.nge.utilities.NGESession;
/*import org.apache.commons.beanutils.BeanUtils;*/


/**
 * 
 * @author Manasaj This DAO class is used for accessing the Status related
 *         repositories used repositories are TStatusRepository
 */
@Repository
public class StatusDAO extends BaseDAO{

	@Autowired
	private TStatusRepository statusRepository;

	@Autowired
	private TProductStateRepository tProductStateRepository; 
	
	@Autowired
	private TTransactionComponentStatusRepository tTransactionComponentStatusRepository;
	
	@Autowired
	private TCompnentStatusAttributeRepository tCompnentStatusAttributeRepository;
	
	@Autowired
	private TStatusTypeRepository tStatusTypeRepository; 
	
	@Autowired
	private TReasonRepository tReasonRepository;
	/**
	 * @author Manasaj
	 * @param statusId
	 * @return
	 */
	public Tstatus findByStatusId(short statusId) {
		Tstatus status = statusRepository.findOne(statusId);
		return status;
	}

	/**
	 * @author Dinesh Selvaraj
	 * @param productStateCd
	 * @return
	 * @throws JpaSystemException
	 * @throws AIGCIExceptionMsg
	 * This method is used to get the product state for given product name
	 */
	public TproductState getProductState(String productStateCd) throws JpaSystemException, AIGCIExceptionMsg
	{
		TproductState tProductStateData=null;
		
		tProductStateData=tProductStateRepository.findByProductStateNm(productStateCd.toUpperCase());
		if(tProductStateData==null){
			ngeException.throwException(NGEErrorCodes.UNSUPPORTED_PRODUCT_STATE, NGEErrorCodes.ERROR_TYPE, null, null); /*EXC Product State ID not available for the given Product State Code */
		}
		return tProductStateData;
	}
	
	/**
	 * @author Dinesh Selvaraj
	 * @param tTransactionComponentData
	 * @param createUserId
	 * @return tTransactionComponentData
	 * @throws AIGCIExceptionMsg
	 * This method is used to insert product status into TTRANSACTION_COMPONENT_STATUS Table 
	 */
	public TtransactionComponent insertTransactionComponentProductStatus(TtransactionComponent tTransactionComponentData) throws AIGCIExceptionMsg{
		
		java.util.Date date= new java.util.Date();
		Set<TtransactionComponentStatus> tTransactionComponentStatusesSet=new HashSet<TtransactionComponentStatus>();
		/*Life Cycle Status Insert*/
		TtransactionComponentStatus tTransactionComponentStatusForLCData=new TtransactionComponentStatus();
		Tstatus TtransCompStatusForLCData=findByStatusTypeNmAndStatusNm(NGEConstants.StatusType.LIFECYCLE_STATUS, NGEConstants.LifeCycleStatus.WORKING);
		TtransactionComponentStatus tTransactionComponentStatusForResData=new TtransactionComponentStatus();
		TtransactionComponentStatusPK tTransactionComponentStatusPKData=new TtransactionComponentStatusPK();
		if(TtransCompStatusForLCData != null){
			short statusIdForLC=TtransCompStatusForLCData.getStatusId();
			Tstatus tStatusForLCData = statusRepository.findOne(statusIdForLC);
			tTransactionComponentStatusPKData.setTransactionComponentId(tTransactionComponentData.getTransactionComponentId());
			tTransactionComponentStatusPKData.setStatusId(TtransCompStatusForLCData.getStatusId());
			tTransactionComponentStatusForLCData.setTstatus(tStatusForLCData);
			tTransactionComponentStatusForLCData.setStatusTs(new Timestamp(date.getTime()));
			tTransactionComponentStatusForLCData.setCreateTs(new Timestamp(date.getTime()));
			tTransactionComponentStatusForLCData.setCreateUserId(NGESession.getSessionData().getUserId());
			tTransactionComponentStatusForLCData.setId(tTransactionComponentStatusPKData);
		}
		
		tTransactionComponentStatusesSet.add(tTransactionComponentStatusForLCData);
		
		/*	Reservation COndition Insert*/
		Tstatus TtransCompStatusForResData=findByStatusTypeNmAndStatusNm(NGEConstants.StatusType.RESERVATION_STATUS, NGEConstants.ReservationCondition.NOT_YET_RESERVED);
		if(TtransCompStatusForResData != null){
			short statusIdForRes=TtransCompStatusForResData.getStatusId();
			Tstatus tStatusForResData = statusRepository.findOne(statusIdForRes);
			tTransactionComponentStatusPKData=new TtransactionComponentStatusPK();
			tTransactionComponentStatusPKData.setTransactionComponentId(tTransactionComponentData.getTransactionComponentId());
			tTransactionComponentStatusPKData.setStatusId(TtransCompStatusForResData.getStatusId());
			tTransactionComponentStatusForResData.setStatusTs(new Timestamp(date.getTime()));
			tTransactionComponentStatusForResData.setTstatus(tStatusForResData);
			tTransactionComponentStatusForResData.setCreateUserId(NGESession.getSessionData().getUserId());
			tTransactionComponentStatusForResData.setCreateTs(new Timestamp(date.getTime()));		
			tTransactionComponentStatusForResData.setId(tTransactionComponentStatusPKData);
		}
		tTransactionComponentStatusesSet.add(tTransactionComponentStatusForResData);
		tTransactionComponentData.setTtransactionComponentStatuses(tTransactionComponentStatusesSet);
		return tTransactionComponentData;
		}
	
	public void insertProductAttemptedReservationStatus(TtransactionComponent tTransactionComponentData) throws AIGCIExceptionMsg{
		
		java.util.Date date= new java.util.Date();		
		TtransactionComponentStatus tTransactionComponentStatusForResData=new TtransactionComponentStatus();
		TtransactionComponentStatusPK tTransactionComponentStatusPKData=new TtransactionComponentStatusPK();
		
		Tstatus TtransCompStatusForResData=findByStatusTypeNmAndStatusNm(NGEConstants.StatusType.ATTEMPTED_RESERVATION, NGEConstants.UNDERGONE_RESERVATION);
		if(TtransCompStatusForResData != null){
			short statusIdForRes=TtransCompStatusForResData.getStatusId();
			Tstatus tStatusForResData = statusRepository.findOne(statusIdForRes);
			tTransactionComponentStatusPKData=new TtransactionComponentStatusPK();
			tTransactionComponentStatusPKData.setTransactionComponentId(tTransactionComponentData.getTransactionComponentId());
			tTransactionComponentStatusPKData.setStatusId(TtransCompStatusForResData.getStatusId());
			tTransactionComponentStatusForResData.setStatusTs(new Timestamp(date.getTime()));
			tTransactionComponentStatusForResData.setTstatus(tStatusForResData);
			tTransactionComponentStatusForResData.setCreateUserId(NGESession.getSessionData().getUserId());
			tTransactionComponentStatusForResData.setCreateTs(new Timestamp(date.getTime()));		
			tTransactionComponentStatusForResData.setId(tTransactionComponentStatusPKData);
			
			/* Exadata changes - Not null issue starts */
			if(tTransactionComponentStatusForResData.getCommentTx() != null){
				if(tTransactionComponentStatusForResData.getCommentTx().trim().equals(NGEConstants.EMPTY_STRING))
					tTransactionComponentStatusForResData.setCommentTx(NGEConstants.EMPTY_SPACE);
			}
			/* Exadata changes - Not null issue ends */
			tTransactionComponentStatusRepository.save(tTransactionComponentStatusForResData);
		}		
	}
	
	
	public Tstatus findByStatusTypeNmAndStatusNm(String statusType,String statusName) throws AIGCIExceptionMsg {
		Tstatus statusData=null;
		List<Object> errorFieldList=new ArrayList<Object>();
		
		/*
		* EXADATA Migration Changes
		* 		Adding space for status name 
		*/

		if(statusName.equals(NGEConstants.EMPTY_STRING))
			statusName = NGEConstants.EMPTY_SPACE;
		
		List<Tstatus> statusList = statusRepository.findByStatusTypeNmAndStatusNm(statusType.toUpperCase(), statusName.toUpperCase());
		if (statusList.size() == 1) {
			statusData = statusList.get(0);
		}else if (statusList.size() == 0){
			errorFieldList.add(statusName);
			errorFieldList.add(statusType);
			ngeException.throwException(NGEErrorCodes.NO_STATUS, NGEErrorCodes.ERROR_TYPE, null,errorFieldList);
		}else{
			errorFieldList.add(statusName);
			errorFieldList.add(statusType);
			ngeException.throwException(NGEErrorCodes.DUPLICATE_STATUS, NGEErrorCodes.ERROR_TYPE, null,errorFieldList);
		}
		return statusData;
	}
	
	public short getMaxStatusAttributeSqn(String componentId, short statusId, short attributeId) {

		short attributeSqn = tCompnentStatusAttributeRepository.getMaxAttributeSqn(componentId, statusId, attributeId);
		return attributeSqn;
	}
	
	public List<TstatusType> findStatusType() throws AIGCIExceptionMsg {
		
		List<TstatusType> statusTypeData = null;
		statusTypeData = tStatusTypeRepository.findStatusType();
		
		if(statusTypeData == null){
			ngeException.throwException(NGEErrorCodes.STATUS_TYPE_DATA_NOT_AVAIL, NGEErrorCodes.ERROR_TYPE, null,null);
		}		
		 return statusTypeData;		
	}
	
	public List<Tstatus> findLifeCycleStatusList(List<String> statusNameList) throws AIGCIExceptionMsg{
		
		List<Tstatus> statusList = new ArrayList<Tstatus>();
		Tstatus tstatus = null;
		
		for(String statusNm : statusNameList)
		{
			/*
			* EXADATA Migration Changes
			* 		Adding space for status name 
			*/

			if(statusNm.equals(NGEConstants.EMPTY_STRING))
				statusNm = NGEConstants.EMPTY_SPACE;
			
			tstatus = statusRepository.findByStatusNm(statusNm);
			if(tstatus == null){
				ngeException.throwException(NGEErrorCodes.STATUS_DATA_NOT_AVAIL, NGEErrorCodes.ERROR_TYPE, null,null);
			}
			statusList.add(tstatus);
		}
		
		return statusList;
	}
public TtransactionComponentStatus updateProductStatus(TtransactionComponentStatus tTransactionComponentStatus,String statusType,String statusName,String userId,boolean isLifeCycleStatus) throws AIGCIExceptionMsg{
	Tstatus tStatus=findByStatusTypeNmAndStatusNm(statusType, statusName);
	
		if(tTransactionComponentStatus != null){			
			tTransactionComponentStatus.setTstatus(tStatus);			
			tTransactionComponentStatus.setUpdateUserId(userId);
			tTransactionComponentStatus.setUpdateTs(NGEDateUtil.getTodayDate());	
			if(isLifeCycleStatus)
				tTransactionComponentStatus.setTreason(tReasonRepository.findByReasonDs("Void Default Reason"));
			return tTransactionComponentStatusRepository.save(tTransactionComponentStatus);
		}		
		return null;
	}
}
