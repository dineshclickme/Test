package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;

import java.sql.Timestamp;
import java.text.DecimalFormat;
import java.math.BigDecimal;
import java.util.Date;
import java.util.Set;


/**
 * The persistent class for the TPOLICY database table.
 * 
 */
@Entity
public class Tpolicy implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "policy_id_gen")
	@SequenceGenerator(name = "policy_id_gen", sequenceName = "POLICY_ID_SEQ", allocationSize=1)
	@Column(name="POLICY_ID")
	private int policyId;

	@Column(name="COMPANY_CD")
	private short companyCd;

	@Column(name="CREATE_TS")
	private Timestamp createTs;

	@Column(name="CREATE_USER_ID")
	private String createUserId;

    @Temporal( TemporalType.DATE)
	@Column(name="EFFECTIVE_DT")
	private Date effectiveDt;

    @Temporal( TemporalType.DATE)
	@Column(name="EXPIRATION_DT")
	private Date expirationDt;

	@Column(name="LOCAL_CURRENCY_PREMIUM_AM")
	private BigDecimal localCurrencyPremiumAm;

	@Column(name="POLICY_NO")
	private String policyNo;

	@Column(name="PREMIUM_AM")
	private BigDecimal premiumAm;

	@Column(name="SYSTEM_ID")
	private short systemId;

	@Column(name="UPDATE_TS")
	private Timestamp updateTs;

	@Column(name="UPDATE_USER_ID")
	private String updateUserId;

	//bi-directional many-to-one association to Tcurrency
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="LOCAL_CURRENCY_ID")
	private Tcurrency tcurrency;

	//bi-directional many-to-one association to TpolicyType
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="POLICY_TYPE_ID")
	private TpolicyType tpolicyType;

	//bi-directional many-to-one association to TpolicyAttribute
	@OneToMany(mappedBy="tpolicy", cascade={CascadeType.ALL})
	private Set<TpolicyAttribute> tpolicyAttributes;

	//bi-directional many-to-one association to TtransactionComponentPolicy
	@OneToMany(mappedBy="tpolicy", cascade={CascadeType.ALL})
	private Set<TtransactionComponentPolicy> ttransactionComponentPolicies;

    public Tpolicy() {
    }

	public int getPolicyId() {
		return this.policyId;
	}

	public void setPolicyId(int policyId) {
		this.policyId = policyId;
	}

	public short getCompanyCd() {
		return this.companyCd;
	}

	public void setCompanyCd(short companyCd) {
		this.companyCd = companyCd;
	}

	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public Date getEffectiveDt() {
		return this.effectiveDt;
	}

	public void setEffectiveDt(Date effectiveDt) {
		this.effectiveDt = effectiveDt;
	}

	public Date getExpirationDt() {
		return this.expirationDt;
	}

	public void setExpirationDt(Date expirationDt) {
		this.expirationDt = expirationDt;
	}

	public BigDecimal getLocalCurrencyPremiumAm() {
		/* exadata changes - formatting the decimal field */
		if(this.localCurrencyPremiumAm != null){
			DecimalFormat df = new DecimalFormat("0.000000");
	    	BigDecimal formattedPremAm = new BigDecimal(df.format(this.localCurrencyPremiumAm));	
			return formattedPremAm;
		}else{
			return this.localCurrencyPremiumAm;
		}
	}

	public void setLocalCurrencyPremiumAm(BigDecimal localCurrencyPremiumAm) {
		this.localCurrencyPremiumAm = localCurrencyPremiumAm;
	}

	public String getPolicyNo() {
		if(this.policyNo != null)
			return this.policyNo.trim();
		else
			return this.policyNo;
	}

	public void setPolicyNo(String policyNo) {
/*2020 PI5  eStart-Resolve issue with space in policy number for NGE UI - Starts*/
		if(policyNo != null)
			this.policyNo = policyNo.trim();
		else
/*2020 PI5  eStart-Resolve issue with space in policy number for NGE UI - Ends*/
			this.policyNo = policyNo;
	}

	public BigDecimal getPremiumAm() {
		/* exadata changes - formatting the decimal field */
		if(this.premiumAm != null){
			DecimalFormat df = new DecimalFormat("0.000000");
	    	BigDecimal formattedPremAm = new BigDecimal(df.format(this.premiumAm));	
			return formattedPremAm;
		}else{
			return this.premiumAm;
		}
    	
	}

	public void setPremiumAm(BigDecimal premiumAm) {
		this.premiumAm = premiumAm;
	}

	public short getSystemId() {
		return this.systemId;
	}

	public void setSystemId(short systemId) {
		this.systemId = systemId;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public Tcurrency getTcurrency() {
		return this.tcurrency;
	}

	public void setTcurrency(Tcurrency tcurrency) {
		this.tcurrency = tcurrency;
	}
	
	public TpolicyType getTpolicyType() {
		return this.tpolicyType;
	}

	public void setTpolicyType(TpolicyType tpolicyType) {
		this.tpolicyType = tpolicyType;
	}
	
	public Set<TpolicyAttribute> getTpolicyAttributes() {
		return this.tpolicyAttributes;
	}

	public void setTpolicyAttributes(Set<TpolicyAttribute> tpolicyAttributes) {
		this.tpolicyAttributes = tpolicyAttributes;
	}
	
	public Set<TtransactionComponentPolicy> getTtransactionComponentPolicies() {
		return this.ttransactionComponentPolicies;
	}

	public void setTtransactionComponentPolicies(Set<TtransactionComponentPolicy> ttransactionComponentPolicies) {
		this.ttransactionComponentPolicies = ttransactionComponentPolicies;
	}
	
}