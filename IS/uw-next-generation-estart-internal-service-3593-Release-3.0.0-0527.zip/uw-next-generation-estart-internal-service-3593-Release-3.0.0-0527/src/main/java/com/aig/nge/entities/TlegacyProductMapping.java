package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the TLEGACY_PRODUCT_MAPPING database table.
 * 
 */
@Entity
@Table(name="TLEGACY_PRODUCT_MAPPING")
public class TlegacyProductMapping implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="LEGACY_PRODUCT_MAP_ID")
	private short legacyProductMapId;

	@Column(name="CREATE_TS")
	private Timestamp createTs;

	@Column(name="CREATE_USER_ID")
	private String createUserId;

	@Column(name="DEFAULT_PRODUCT_IN")
	private String defaultProductIn;

	@Column(name="LEGACT_SECTION_CD")
	private short legactSectionCd;

	@Column(name="LEGACY_PRODCT_COVG_TYP_CD")
	private String legacyProdctCovgTypCd;

	@Column(name="LEGACY_PROFIT_UNIT_CD")
	private short legacyProfitUnitCd;

	@Column(name="UPDATE_TS")
	private Timestamp updateTs;

	@Column(name="UPDATE_USER_ID")
	private String updateUserId;

	//bi-directional many-to-one association to TlegacyProduct
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="LEGACY_BUNDLED_PRODUCT_CD")
	private TlegacyProduct tlegacyProduct;

	//bi-directional many-to-one association to TlegacyProfitCenterProduct
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumns({
		@JoinColumn(name="LEGACY_PRODUCT_CD", referencedColumnName="PRODUCT_CD"),
		@JoinColumn(name="LEGACY_PROFIT_CENTER_CD", referencedColumnName="PROFIT_CENTER_CD"),
		@JoinColumn(name="LEGACY_SOURCE_CD", referencedColumnName="SOURCE_CD")
		})
	private TlegacyProfitCenterProduct tlegacyProfitCenterProduct;

	//bi-directional many-to-one association to Tproduct
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="TUW_SUB_PRODUCT_ID")
	private Tproduct tproduct1;

	//bi-directional many-to-one association to Tproduct
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="MARKETABLE_PRODUCT_ID")
	private Tproduct tproduct2;

	//bi-directional many-to-one association to Tproduct
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="PRODUCT_DSP_ID")
	private Tproduct tproduct3;

	//bi-directional many-to-one association to Tproduct
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="PRODUCT_MMCP_ID")
	private Tproduct tproduct4;

	//bi-directional many-to-one association to Tproduct
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="PRODUCTMJC_ID")
	private Tproduct tproduct5;

	//bi-directional many-to-one association to TproductTower
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="PRODUCT_TOWER_ID")
	private TproductTower tproductTower;

    public TlegacyProductMapping() {
    }

	public short getLegacyProductMapId() {
		return this.legacyProductMapId;
	}

	public void setLegacyProductMapId(short legacyProductMapId) {
		this.legacyProductMapId = legacyProductMapId;
	}

	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public String getDefaultProductIn() {
		return this.defaultProductIn;
	}

	public void setDefaultProductIn(String defaultProductIn) {
		this.defaultProductIn = defaultProductIn;
	}

	public short getLegactSectionCd() {
		return this.legactSectionCd;
	}

	public void setLegactSectionCd(short legactSectionCd) {
		this.legactSectionCd = legactSectionCd;
	}

	public String getLegacyProdctCovgTypCd() {
		return this.legacyProdctCovgTypCd;
	}

	public void setLegacyProdctCovgTypCd(String legacyProdctCovgTypCd) {
		this.legacyProdctCovgTypCd = legacyProdctCovgTypCd;
	}

	public short getLegacyProfitUnitCd() {
		return this.legacyProfitUnitCd;
	}

	public void setLegacyProfitUnitCd(short legacyProfitUnitCd) {
		this.legacyProfitUnitCd = legacyProfitUnitCd;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public TlegacyProduct getTlegacyProduct() {
		return this.tlegacyProduct;
	}

	public void setTlegacyProduct(TlegacyProduct tlegacyProduct) {
		this.tlegacyProduct = tlegacyProduct;
	}
	
	public TlegacyProfitCenterProduct getTlegacyProfitCenterProduct() {
		return this.tlegacyProfitCenterProduct;
	}

	public void setTlegacyProfitCenterProduct(TlegacyProfitCenterProduct tlegacyProfitCenterProduct) {
		this.tlegacyProfitCenterProduct = tlegacyProfitCenterProduct;
	}
	
	public Tproduct getTproduct1() {
		return this.tproduct1;
	}

	public void setTproduct1(Tproduct tproduct1) {
		this.tproduct1 = tproduct1;
	}
	
	public Tproduct getTproduct2() {
		return this.tproduct2;
	}

	public void setTproduct2(Tproduct tproduct2) {
		this.tproduct2 = tproduct2;
	}
	
	public Tproduct getTproduct3() {
		return this.tproduct3;
	}

	public void setTproduct3(Tproduct tproduct3) {
		this.tproduct3 = tproduct3;
	}
	
	public Tproduct getTproduct4() {
		return this.tproduct4;
	}

	public void setTproduct4(Tproduct tproduct4) {
		this.tproduct4 = tproduct4;
	}
	
	public Tproduct getTproduct5() {
		return this.tproduct5;
	}

	public void setTproduct5(Tproduct tproduct5) {
		this.tproduct5 = tproduct5;
	}
	
	public TproductTower getTproductTower() {
		return this.tproductTower;
	}

	public void setTproductTower(TproductTower tproductTower) {
		this.tproductTower = tproductTower;
	}
	
}