package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the TLEGACY_PRODUCT_DSP database table.
 * 
 */
@Embeddable
public class TlegacyProductDspPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="PRODCT_COVG_TYP_CD")
	private String prodctCovgTypCd;

	@Column(name="PROFIT_CENTER_CD")
	private String profitCenterCd;

	@Column(name="PRODUCT_CD")
	private String productCd;

	@Column(name="SECTION_CD")
	private short sectionCd;

	@Column(name="PROFIT_UNIT_CD")
	private short profitUnitCd;

	@Column(name="SOURCE_CD")
	private String sourceCd;

    public TlegacyProductDspPK() {
    }
	public String getProdctCovgTypCd() {
		return this.prodctCovgTypCd;
	}
	public void setProdctCovgTypCd(String prodctCovgTypCd) {
		this.prodctCovgTypCd = prodctCovgTypCd;
	}
	public String getProfitCenterCd() {
		return this.profitCenterCd;
	}
	public void setProfitCenterCd(String profitCenterCd) {
		this.profitCenterCd = profitCenterCd;
	}
	public String getProductCd() {
		return this.productCd;
	}
	public void setProductCd(String productCd) {
		this.productCd = productCd;
	}
	public short getSectionCd() {
		return this.sectionCd;
	}
	public void setSectionCd(short sectionCd) {
		this.sectionCd = sectionCd;
	}
	public short getProfitUnitCd() {
		return this.profitUnitCd;
	}
	public void setProfitUnitCd(short profitUnitCd) {
		this.profitUnitCd = profitUnitCd;
	}
	public String getSourceCd() {
		return this.sourceCd;
	}
	public void setSourceCd(String sourceCd) {
		this.sourceCd = sourceCd;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof TlegacyProductDspPK)) {
			return false;
		}
		TlegacyProductDspPK castOther = (TlegacyProductDspPK)other;
		return 
			this.prodctCovgTypCd.equals(castOther.prodctCovgTypCd)
			&& this.profitCenterCd.equals(castOther.profitCenterCd)
			&& this.productCd.equals(castOther.productCd)
			&& (this.sectionCd == castOther.sectionCd)
			&& (this.profitUnitCd == castOther.profitUnitCd)
			&& this.sourceCd.equals(castOther.sourceCd);

    }
    
	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.prodctCovgTypCd.hashCode();
		hash = hash * prime + this.profitCenterCd.hashCode();
		hash = hash * prime + this.productCd.hashCode();
		hash = hash * prime + ((int) this.sectionCd);
		hash = hash * prime + ((int) this.profitUnitCd);
		hash = hash * prime + this.sourceCd.hashCode();
		
		return hash;
    }
}