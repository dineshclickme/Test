package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the TLEGACY_TRNSCTN_CMPNT_XTNSN_HS database table.
 * 
 */
@Embeddable
public class TlegacyTrnsctnCmpntXtnsnHPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="TRANSACTION_COMPONENT_ID")
	private String transactionComponentId;

    @Temporal( TemporalType.TIMESTAMP)
	@Column(name="CREATE_HISTORY_TS")
	private java.util.Date createHistoryTs;

    public TlegacyTrnsctnCmpntXtnsnHPK() {
    }
	public String getTransactionComponentId() {
		return this.transactionComponentId;
	}
	public void setTransactionComponentId(String transactionComponentId) {
		this.transactionComponentId = transactionComponentId;
	}
	public java.util.Date getCreateHistoryTs() {
		return this.createHistoryTs;
	}
	public void setCreateHistoryTs(java.util.Date createHistoryTs) {
		this.createHistoryTs = createHistoryTs;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof TlegacyTrnsctnCmpntXtnsnHPK)) {
			return false;
		}
		TlegacyTrnsctnCmpntXtnsnHPK castOther = (TlegacyTrnsctnCmpntXtnsnHPK)other;
		return 
			this.transactionComponentId.equals(castOther.transactionComponentId)
			&& this.createHistoryTs.equals(castOther.createHistoryTs);

    }
    
	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.transactionComponentId.hashCode();
		hash = hash * prime + this.createHistoryTs.hashCode();
		
		return hash;
    }
}