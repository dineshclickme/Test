package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the TPRODUCER_CONTACT database table.
 * 
 */
@Entity
@Table(name="TPRODUCER_CONTACT")
public class TproducerContact implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private TproducerContactPK id;

	@Column(name="CONTACT_TX")
	private String contactTx;

	@Column(name="CREATE_TS")
	private Timestamp createTs;

	@Column(name="CREATE_USER_ID")
	private String createUserId;

	@Column(name="EMAIL_ADDRESS_TX")
	private String emailAddressTx;

	@Column(name="FIRST_NM")
	private String firstNm;

	@Column(name="LAST_NM")
	private String lastNm;

	@Column(name="PHONE_NO")
	private String phoneNo;

	@Column(name="UPDATE_TS")
	private Timestamp updateTs;

	@Column(name="UPDATE_USER_ID")
	private String updateUserId;

	//bi-directional many-to-one association to Ttransaction
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="TRANSACTION_ID")
	private Ttransaction ttransaction;

    public TproducerContact() {
    }

	public TproducerContactPK getId() {
		return this.id;
	}

	public void setId(TproducerContactPK id) {
		this.id = id;
	}
	
	public String getContactTx() {
		return this.contactTx;
	}

	public void setContactTx(String contactTx) {
		this.contactTx = contactTx;
	}

	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public String getEmailAddressTx() {
		return this.emailAddressTx;
	}

	public void setEmailAddressTx(String emailAddressTx) {
		this.emailAddressTx = emailAddressTx;
	}

	public String getFirstNm() {
		if(this.firstNm != null)
			return this.firstNm.trim();
		else
			return this.firstNm;
	}

	public void setFirstNm(String firstNm) {
		this.firstNm = firstNm;
	}

	public String getLastNm() {
		return this.lastNm.trim();
	}

	public void setLastNm(String lastNm) {
		this.lastNm = lastNm;
	}

	public String getPhoneNo() {
		return this.phoneNo;
	}

	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public Ttransaction getTtransaction() {
		return this.ttransaction;
	}

	public void setTtransaction(Ttransaction ttransaction) {
		this.ttransaction = ttransaction;
	}
	
}