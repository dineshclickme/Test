package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the TSCREEN_FIELD database table.
 * 
 */
@Embeddable
public class TscreenFieldPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="SCREEN_ID")
	private short screenId;

	@Column(name="FIELD_ID")
	private short fieldId;

    public TscreenFieldPK() {
    }
	public short getScreenId() {
		return this.screenId;
	}
	public void setScreenId(short screenId) {
		this.screenId = screenId;
	}
	public short getFieldId() {
		return this.fieldId;
	}
	public void setFieldId(short fieldId) {
		this.fieldId = fieldId;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof TscreenFieldPK)) {
			return false;
		}
		TscreenFieldPK castOther = (TscreenFieldPK)other;
		return 
			(this.screenId == castOther.screenId)
			&& (this.fieldId == castOther.fieldId);

    }
    
	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + ((int) this.screenId);
		hash = hash * prime + ((int) this.fieldId);
		
		return hash;
    }
}