package com.aig.nge.entities;

import java.sql.Timestamp;
import java.util.Date;
import javax.annotation.Generated;
import javax.persistence.metamodel.SetAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-04-15T15:31:47.135+0530")
@StaticMetamodel(TlegacyProfitCenterProduct.class)
public class TlegacyProfitCenterProduct_ {
	public static volatile SingularAttribute<TlegacyProfitCenterProduct, TlegacyProfitCenterProductPK> id;
	public static volatile SingularAttribute<TlegacyProfitCenterProduct, Short> autoCloseDaysCt;
	public static volatile SingularAttribute<TlegacyProfitCenterProduct, String> bypassBlockingIn;
	public static volatile SingularAttribute<TlegacyProfitCenterProduct, String> createdById;
	public static volatile SingularAttribute<TlegacyProfitCenterProduct, String> crossSellingIn;
	public static volatile SingularAttribute<TlegacyProfitCenterProduct, String> dspRequiredIn;
	public static volatile SingularAttribute<TlegacyProfitCenterProduct, String> dspTableCd;
	public static volatile SingularAttribute<TlegacyProfitCenterProduct, Date> enteredDt;
	public static volatile SingularAttribute<TlegacyProfitCenterProduct, Timestamp> lastUpdtTs;
	public static volatile SingularAttribute<TlegacyProfitCenterProduct, String> lastUpdtUserId;
	public static volatile SingularAttribute<TlegacyProfitCenterProduct, Short> maxAutoclsExtCt;
	public static volatile SingularAttribute<TlegacyProfitCenterProduct, String> multipleWipIn;
	public static volatile SingularAttribute<TlegacyProfitCenterProduct, Short> polBackdtDaysCt;
	public static volatile SingularAttribute<TlegacyProfitCenterProduct, Date> prfCtrPrdEfvDt;
	public static volatile SingularAttribute<TlegacyProfitCenterProduct, Date> prfCtrPrdXpnDt;
	public static volatile SingularAttribute<TlegacyProfitCenterProduct, String> productSynonymNm;
	public static volatile SingularAttribute<TlegacyProfitCenterProduct, String> productionIn;
	public static volatile SingularAttribute<TlegacyProfitCenterProduct, String> wrapUpIn;
	public static volatile SetAttribute<TlegacyProfitCenterProduct, TlegacyMgaProduct> tlegacyMgaProducts;
	public static volatile SetAttribute<TlegacyProfitCenterProduct, TlegacyProductMapping> tlegacyProductMappings;
	public static volatile SingularAttribute<TlegacyProfitCenterProduct, TlegacyProduct> tlegacyProduct;
	public static volatile SingularAttribute<TlegacyProfitCenterProduct, Tsource> tsource;
}
