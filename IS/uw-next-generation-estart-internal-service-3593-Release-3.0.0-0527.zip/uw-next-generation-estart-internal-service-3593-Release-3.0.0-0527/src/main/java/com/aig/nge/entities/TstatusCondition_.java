package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SetAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-02-19T16:13:04.468+0530")
@StaticMetamodel(TstatusCondition.class)
public class TstatusCondition_ {
	public static volatile SingularAttribute<TstatusCondition, Short> statusConditionId;
	public static volatile SingularAttribute<TstatusCondition, Timestamp> createTs;
	public static volatile SingularAttribute<TstatusCondition, String> createUserId;
	public static volatile SingularAttribute<TstatusCondition, Timestamp> updateTs;
	public static volatile SingularAttribute<TstatusCondition, String> updateUserId;
	public static volatile SingularAttribute<TstatusCondition, Tstatus> tstatus1;
	public static volatile SingularAttribute<TstatusCondition, Tstatus> tstatus2;
	public static volatile SetAttribute<TstatusCondition, TstatusTransition> tstatusTransitions;
}
