package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the TSE_ALERT_SOURCE database table.
 * 
 */
@Embeddable
public class TseAlertSourcePK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="SUBMISSION_EVALUATION_CD")
	private int submissionEvaluationCd;

	@Column(name="SOURCE_CD")
	private String sourceCd;

    public TseAlertSourcePK() {
    }
	public int getSubmissionEvaluationCd() {
		return this.submissionEvaluationCd;
	}
	public void setSubmissionEvaluationCd(int submissionEvaluationCd) {
		this.submissionEvaluationCd = submissionEvaluationCd;
	}
	public String getSourceCd() {
		return this.sourceCd;
	}
	public void setSourceCd(String sourceCd) {
		this.sourceCd = sourceCd;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof TseAlertSourcePK)) {
			return false;
		}
		TseAlertSourcePK castOther = (TseAlertSourcePK)other;
		return 
			(this.submissionEvaluationCd == castOther.submissionEvaluationCd)
			&& this.sourceCd.equals(castOther.sourceCd);

    }
    
	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.submissionEvaluationCd;
		hash = hash * prime + this.sourceCd.hashCode();
		
		return hash;
    }
}