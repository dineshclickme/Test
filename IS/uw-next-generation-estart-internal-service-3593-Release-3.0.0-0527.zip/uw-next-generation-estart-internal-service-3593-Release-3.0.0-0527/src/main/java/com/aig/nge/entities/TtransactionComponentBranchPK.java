package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the TTRANSACTION_COMPONENT_BRANCH database table.
 * 
 */
@Embeddable
public class TtransactionComponentBranchPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="TRANSACTION_COMPONENT_ID")
	private String transactionComponentId;

	@Column(name="BRANCH_TYPE_ID")
	private short branchTypeId;

    public TtransactionComponentBranchPK() {
    }
	public String getTransactionComponentId() {
		return this.transactionComponentId;
	}
	public void setTransactionComponentId(String transactionComponentId) {
		this.transactionComponentId = transactionComponentId;
	}
	public short getBranchTypeId() {
		return this.branchTypeId;
	}
	public void setBranchTypeId(short branchTypeId) {
		this.branchTypeId = branchTypeId;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof TtransactionComponentBranchPK)) {
			return false;
		}
		TtransactionComponentBranchPK castOther = (TtransactionComponentBranchPK)other;
		return 
			this.transactionComponentId.equals(castOther.transactionComponentId)
			&& (this.branchTypeId == castOther.branchTypeId);

    }
    
	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.transactionComponentId.hashCode();
		hash = hash * prime + ((int) this.branchTypeId);
		
		return hash;
    }
}