package com.aig.nge.entities;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.apache.openjpa.persistence.DataCache;


/**
 * The persistent class for the TPARTY_TYPE database table.
 * 
 */
@Entity
@DataCache
@Table(name="TEXCLUDE_BLOCK_TYPE")
public class TexcludeBlockType implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="EXCLUDE_BLOCK_TYPE_ID")
	private short excludeBlockTypeId;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="CREATE_TS")
	private Timestamp createTs;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="CREATE_USER_ID")
	private String createUserId;

	@Column(name="BLOCK_TYPE_NM")
	private String blockTypeNm;
	
	@Column(name="BLOCK_TYPE_DS")
	private String blockTypeDs;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="UPDATE_TS")
	private Timestamp updateTs;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="UPDATE_USER_ID")
	private String updateUserId;


	public short getExcludeBlockTypeId() {
		return excludeBlockTypeId;
	}

	public void setExcludeBlockTypeId(short excludeBlockTypeId) {
		this.excludeBlockTypeId = excludeBlockTypeId;
	}

	public Timestamp getCreateTs() {
		return createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public String getBlockTypeNm() {
		return blockTypeNm;
	}

	public void setBlockTypeNm(String blockTypeNm) {
		this.blockTypeNm = blockTypeNm;
	}

	public String getBlockTypeDs() {
		return blockTypeDs;
	}

	public void setBlockTypeDs(String blockTypeDs) {
		this.blockTypeDs = blockTypeDs;
	}

	public Timestamp getUpdateTs() {
		return updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	
}