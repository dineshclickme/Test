package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-02-24T11:59:50.400+0530")
@StaticMetamodel(TtableAttributeReference.class)
public class TtableAttributeReference_ {
	public static volatile SingularAttribute<TtableAttributeReference, TtableAttributeReferencePK> id;
	public static volatile SingularAttribute<TtableAttributeReference, Timestamp> createTs;
	public static volatile SingularAttribute<TtableAttributeReference, String> createUserId;
	public static volatile SingularAttribute<TtableAttributeReference, Timestamp> updateTs;
	public static volatile SingularAttribute<TtableAttributeReference, String> updateUserId;
	public static volatile SingularAttribute<TtableAttributeReference, TattributeReference> tattributeReference;
	public static volatile SingularAttribute<TtableAttributeReference, TtableAttribute> ttableAttribute;
}
