package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SetAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-04-15T15:31:47.665+0530")
@StaticMetamodel(TproductTowerConfiguration.class)
public class TproductTowerConfiguration_ {
	public static volatile SingularAttribute<TproductTowerConfiguration, Integer> configurationId;
	public static volatile SingularAttribute<TproductTowerConfiguration, String> configurationVal;
	public static volatile SingularAttribute<TproductTowerConfiguration, Timestamp> createTs;
	public static volatile SingularAttribute<TproductTowerConfiguration, String> createUserId;
	public static volatile SingularAttribute<TproductTowerConfiguration, Timestamp> updateTs;
	public static volatile SingularAttribute<TproductTowerConfiguration, String> updateUserId;
	public static volatile SingularAttribute<TproductTowerConfiguration, TconfigurationType> tconfigurationType;
	public static volatile SingularAttribute<TproductTowerConfiguration, TproductTower> tproductTower;
	public static volatile SetAttribute<TproductTowerConfiguration, TtowerTuwSubProdctConfig> ttowerTuwSubProdctConfigs;
}
