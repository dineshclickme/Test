package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the TPRODUCT_TOWER_REASON database table.
 * 
 */
@Embeddable
public class TproductTowerReasonPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="PRODUCT_TOWER_ID")
	private short productTowerId;

	@Column(name="REASON_ID")
	private short reasonId;

    public TproductTowerReasonPK() {
    }
	public short getProductTowerId() {
		return this.productTowerId;
	}
	public void setProductTowerId(short productTowerId) {
		this.productTowerId = productTowerId;
	}
	public short getReasonId() {
		return this.reasonId;
	}
	public void setReasonId(short reasonId) {
		this.reasonId = reasonId;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof TproductTowerReasonPK)) {
			return false;
		}
		TproductTowerReasonPK castOther = (TproductTowerReasonPK)other;
		return 
			(this.productTowerId == castOther.productTowerId)
			&& (this.reasonId == castOther.reasonId);

    }
    
	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + ((int) this.productTowerId);
		hash = hash * prime + ((int) this.reasonId);
		
		return hash;
    }
}