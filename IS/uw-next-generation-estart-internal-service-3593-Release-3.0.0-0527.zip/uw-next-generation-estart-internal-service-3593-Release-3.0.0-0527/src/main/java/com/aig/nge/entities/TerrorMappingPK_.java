package com.aig.nge.entities;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-06-19T14:59:45.645+0530")
@StaticMetamodel(TerrorMappingPK.class)
public class TerrorMappingPK_ {
	public static volatile SingularAttribute<TerrorMappingPK, Short> errorId;
	public static volatile SingularAttribute<TerrorMappingPK, Short> legacyErrorId;
}
