package com.aig.nge.entities;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-02-19T16:13:03.670+0530")
@StaticMetamodel(TpartyActionPK.class)
public class TpartyActionPK_ {
	public static volatile SingularAttribute<TpartyActionPK, Short> systemId;
	public static volatile SingularAttribute<TpartyActionPK, Integer> geographicLocationId;
	public static volatile SingularAttribute<TpartyActionPK, String> dataCategoryNm;
	public static volatile SingularAttribute<TpartyActionPK, Short> roleId;
	public static volatile SingularAttribute<TpartyActionPK, Integer> partyId;
	public static volatile SingularAttribute<TpartyActionPK, Short> productTowerId;
}
