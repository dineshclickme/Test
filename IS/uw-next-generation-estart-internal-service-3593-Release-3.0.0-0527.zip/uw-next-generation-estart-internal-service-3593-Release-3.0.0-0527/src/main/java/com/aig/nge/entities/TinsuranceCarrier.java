package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Set;


/**
 * The persistent class for the TINSURANCE_CARRIER database table.
 * 
 */
@Entity
@Table(name="TINSURANCE_CARRIER")
public class TinsuranceCarrier implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="CARRIER_ID")
	private int carrierId;

	@Column(name="CARRIER_CD")
	private String carrierCd;

	@Column(name="CARRIER_NM")
	private String carrierNm;

	@Column(name="CREATE_TS")
	private Timestamp createTs;

	@Column(name="CREATE_USER_ID")
	private String createUserId;

	@Column(name="UPDATE_TS")
	private Timestamp updateTs;

	@Column(name="UPDATE_USER_ID")
	private String updateUserId;

	//bi-directional many-to-one association to TlegacyTransactionExtension
	@OneToMany(mappedBy="tinsuranceCarrier")
	private Set<TlegacyTransactionExtension> tlegacyTransactionExtensions;

    public TinsuranceCarrier() {
    }

	public int getCarrierId() {
		return this.carrierId;
	}

	public void setCarrierId(int carrierId) {
		this.carrierId = carrierId;
	}

	public String getCarrierCd() {
		return this.carrierCd;
	}

	public void setCarrierCd(String carrierCd) {
		this.carrierCd = carrierCd;
	}

	public String getCarrierNm() {
		return this.carrierNm;
	}

	public void setCarrierNm(String carrierNm) {
		this.carrierNm = carrierNm;
	}

	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public Set<TlegacyTransactionExtension> getTlegacyTransactionExtensions() {
		return this.tlegacyTransactionExtensions;
	}

	public void setTlegacyTransactionExtensions(Set<TlegacyTransactionExtension> tlegacyTransactionExtensions) {
		this.tlegacyTransactionExtensions = tlegacyTransactionExtensions;
	}
	
}