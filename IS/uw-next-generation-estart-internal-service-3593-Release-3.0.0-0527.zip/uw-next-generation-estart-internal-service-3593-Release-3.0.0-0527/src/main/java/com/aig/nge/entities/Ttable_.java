package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SetAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-02-19T16:13:04.652+0530")
@StaticMetamodel(Ttable.class)
public class Ttable_ {
	public static volatile SingularAttribute<Ttable, Short> tableId;
	public static volatile SingularAttribute<Ttable, Timestamp> createTs;
	public static volatile SingularAttribute<Ttable, String> createUserId;
	public static volatile SingularAttribute<Ttable, String> tableNm;
	public static volatile SingularAttribute<Ttable, Timestamp> updateTs;
	public static volatile SingularAttribute<Ttable, String> updateUserId;
	public static volatile SetAttribute<Ttable, TtableAttribute> ttableAttributes;
}
