package com.aig.nge.entities;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-02-19T16:13:03.785+0530")
@StaticMetamodel(TpolicyAttributePK.class)
public class TpolicyAttributePK_ {
	public static volatile SingularAttribute<TpolicyAttributePK, Integer> policyId;
	public static volatile SingularAttribute<TpolicyAttributePK, Short> attributeId;
	public static volatile SingularAttribute<TpolicyAttributePK, Short> attributeSqn;
}
