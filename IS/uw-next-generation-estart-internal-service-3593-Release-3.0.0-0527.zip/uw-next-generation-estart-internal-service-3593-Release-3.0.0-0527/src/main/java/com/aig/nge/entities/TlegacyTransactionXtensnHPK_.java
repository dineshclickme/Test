package com.aig.nge.entities;

import java.util.Date;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-04-15T15:31:47.228+0530")
@StaticMetamodel(TlegacyTransactionXtensnHPK.class)
public class TlegacyTransactionXtensnHPK_ {
	public static volatile SingularAttribute<TlegacyTransactionXtensnHPK, String> transactionId;
	public static volatile SingularAttribute<TlegacyTransactionXtensnHPK, Short> versionSqn;
	public static volatile SingularAttribute<TlegacyTransactionXtensnHPK, Date> createHistoryTs;
	public static volatile SingularAttribute<TlegacyTransactionXtensnHPK, String> legacyBundledProductCd;
}
