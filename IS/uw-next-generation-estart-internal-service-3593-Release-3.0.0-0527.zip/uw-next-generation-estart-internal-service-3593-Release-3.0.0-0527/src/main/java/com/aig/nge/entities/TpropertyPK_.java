package com.aig.nge.entities;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-06-19T14:59:45.954+0530")
@StaticMetamodel(TpropertyPK.class)
public class TpropertyPK_ {
	public static volatile SingularAttribute<TpropertyPK, Short> systemId;
	public static volatile SingularAttribute<TpropertyPK, String> evironmentNm;
	public static volatile SingularAttribute<TpropertyPK, String> propertyNm;
}
