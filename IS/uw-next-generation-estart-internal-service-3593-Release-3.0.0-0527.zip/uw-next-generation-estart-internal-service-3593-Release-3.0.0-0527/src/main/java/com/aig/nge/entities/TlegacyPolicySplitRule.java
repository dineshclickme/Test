package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the TLEGACY_POLICY_SPLIT_RULE database table.
 * 
 */
@Entity
@Table(name="TLEGACY_POLICY_SPLIT_RULE")
public class TlegacyPolicySplitRule implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private TlegacyPolicySplitRulePK id;

	@Column(name="CREATE_TS")
	private Timestamp createTs;

	@Column(name="CREATE_USER_ID")
	private String createUserId;

	@Column(name="POLICY_DIGITS_IN")
	private String policyDigitsIn;

	@Column(name="UPDATE_TS")
	private Timestamp updateTs;

	@Column(name="UPDATE_USER_ID")
	private String updateUserId;

	//bi-directional many-to-one association to Tsystem
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="SYSTEM_ID")
	private Tsystem tsystem;

	//bi-directional many-to-one association to Tdivision
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="DIVISION_NO")
	private Tdivision tdivision;

    public TlegacyPolicySplitRule() {
    }

	public TlegacyPolicySplitRulePK getId() {
		return this.id;
	}

	public void setId(TlegacyPolicySplitRulePK id) {
		this.id = id;
	}
	
	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public String getPolicyDigitsIn() {
		return this.policyDigitsIn;
	}

	public void setPolicyDigitsIn(String policyDigitsIn) {
		this.policyDigitsIn = policyDigitsIn;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public Tsystem getTsystem() {
		return this.tsystem;
	}

	public void setTsystem(Tsystem tsystem) {
		this.tsystem = tsystem;
	}
	
	public Tdivision getTdivision() {
		return this.tdivision;
	}

	public void setTdivision(Tdivision tdivision) {
		this.tdivision = tdivision;
	}
	
}