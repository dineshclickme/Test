package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Date;
import java.util.Set;


/**
 * The persistent class for the TLEGACY_MAJOR_PRODUCT_GROUP database table.
 * 
 */
@Entity
@Table(name="TLEGACY_MAJOR_PRODUCT_GROUP")
public class TlegacyMajorProductGroup implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="MJR_PRODUCT_GRP_CD")
	private short mjrProductGrpCd;

	@Column(name="CREATED_BY_ID")
	private String createdById;

    @Temporal( TemporalType.DATE)
	@Column(name="ENTERED_DT")
	private Date enteredDt;

	@Column(name="LAST_UPDT_TS")
	private Timestamp lastUpdtTs;

	@Column(name="LAST_UPDT_USER_ID")
	private String lastUpdtUserId;

	@Column(name="MJR_PRODUCT_GRP_NM")
	private String mjrProductGrpNm;

	//bi-directional many-to-one association to TlegacyMinorProductGroup
	@OneToMany(mappedBy="tlegacyMajorProductGroup")
	private Set<TlegacyMinorProductGroup> tlegacyMinorProductGroups;

    public TlegacyMajorProductGroup() {
    }

	public short getMjrProductGrpCd() {
		return this.mjrProductGrpCd;
	}

	public void setMjrProductGrpCd(short mjrProductGrpCd) {
		this.mjrProductGrpCd = mjrProductGrpCd;
	}

	public String getCreatedById() {
		return this.createdById;
	}

	public void setCreatedById(String createdById) {
		this.createdById = createdById;
	}

	public Date getEnteredDt() {
		return this.enteredDt;
	}

	public void setEnteredDt(Date enteredDt) {
		this.enteredDt = enteredDt;
	}

	public Timestamp getLastUpdtTs() {
		return this.lastUpdtTs;
	}

	public void setLastUpdtTs(Timestamp lastUpdtTs) {
		this.lastUpdtTs = lastUpdtTs;
	}

	public String getLastUpdtUserId() {
		return this.lastUpdtUserId;
	}

	public void setLastUpdtUserId(String lastUpdtUserId) {
		this.lastUpdtUserId = lastUpdtUserId;
	}

	public String getMjrProductGrpNm() {
		return this.mjrProductGrpNm;
	}

	public void setMjrProductGrpNm(String mjrProductGrpNm) {
		this.mjrProductGrpNm = mjrProductGrpNm;
	}

	public Set<TlegacyMinorProductGroup> getTlegacyMinorProductGroups() {
		return this.tlegacyMinorProductGroups;
	}

	public void setTlegacyMinorProductGroups(Set<TlegacyMinorProductGroup> tlegacyMinorProductGroups) {
		this.tlegacyMinorProductGroups = tlegacyMinorProductGroups;
	}
	
}