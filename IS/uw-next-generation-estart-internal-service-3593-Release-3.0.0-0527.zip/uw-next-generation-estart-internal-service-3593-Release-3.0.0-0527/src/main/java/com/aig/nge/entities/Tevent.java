package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;
import org.apache.openjpa.persistence.DataCache;
import java.sql.Timestamp;
import java.util.Set;


/**
 * The persistent class for the TEVENT database table.
 * 
 */
@Entity
@DataCache
public class Tevent implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="EVENT_ID")
	private short eventId;

	@Basic(fetch=FetchType.LAZY)
	@Column(name="CREATE_TS")
	private Timestamp createTs;

	@Basic(fetch=FetchType.LAZY)
	@Column(name="CREATE_USER_ID")
	private String createUserId;

	@Basic(fetch=FetchType.LAZY)
	@Column(name="UPDATE_TS")
	private Timestamp updateTs;

	@Basic(fetch=FetchType.LAZY)
	@Column(name="UPDATE_USER_ID")
	private String updateUserId;

	//bi-directional many-to-one association to Tstatus
	@ManyToOne
	@JoinColumn(name="STATUS_ID")
	private Tstatus tstatus1;

	//bi-directional many-to-one association to Tstatus
	@ManyToOne
	@JoinColumn(name="TO_STATUS_ID")
	private Tstatus tstatus2;

	//bi-directional many-to-one association to TtowerEvent
	@OneToMany(mappedBy="tevent", cascade={CascadeType.ALL})
	private Set<TtowerEvent> ttowerEvents;

    public Tevent() {
    }

	public short getEventId() {
		return this.eventId;
	}

	public void setEventId(short eventId) {
		this.eventId = eventId;
	}

	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public Tstatus getTstatus1() {
		return this.tstatus1;
	}

	public void setTstatus1(Tstatus tstatus1) {
		this.tstatus1 = tstatus1;
	}
	
	public Tstatus getTstatus2() {
		return this.tstatus2;
	}

	public void setTstatus2(Tstatus tstatus2) {
		this.tstatus2 = tstatus2;
	}
	
	public Set<TtowerEvent> getTtowerEvents() {
		return this.ttowerEvents;
	}

	public void setTtowerEvents(Set<TtowerEvent> ttowerEvents) {
		this.ttowerEvents = ttowerEvents;
	}
	
}