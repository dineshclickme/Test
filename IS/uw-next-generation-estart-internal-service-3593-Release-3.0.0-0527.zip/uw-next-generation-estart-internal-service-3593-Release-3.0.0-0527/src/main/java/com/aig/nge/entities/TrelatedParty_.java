package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-02-19T16:13:04.329+0530")
@StaticMetamodel(TrelatedParty.class)
public class TrelatedParty_ {
	public static volatile SingularAttribute<TrelatedParty, TrelatedPartyPK> id;
	public static volatile SingularAttribute<TrelatedParty, Timestamp> createTs;
	public static volatile SingularAttribute<TrelatedParty, String> createUserId;
	public static volatile SingularAttribute<TrelatedParty, Timestamp> updateTs;
	public static volatile SingularAttribute<TrelatedParty, String> updateUserId;
	public static volatile SingularAttribute<TrelatedParty, Tparty> tparty1;
	public static volatile SingularAttribute<TrelatedParty, Tparty> tparty2;
	public static volatile SingularAttribute<TrelatedParty, TpartyRelationType> tpartyRelationType;
}
