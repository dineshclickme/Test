package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Date;
import java.util.Set;


/**
 * The persistent class for the TLEGACY_PRODUCT_BUNDLING database table.
 * 
 */
@Entity
@Table(name="TLEGACY_PRODUCT_BUNDLING")
public class TlegacyProductBundling implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private TlegacyProductBundlingPK id;

	@Column(name="CREATED_BY_ID")
	private String createdById;

    @Temporal( TemporalType.DATE)
	@Column(name="ENTERED_DT")
	private Date enteredDt;

	@Column(name="LAST_UPDT_TS")
	private Timestamp lastUpdtTs;

	@Column(name="LAST_UPDT_USER_ID")
	private String lastUpdtUserId;

	@Column(name="MNDTRY_IN_BUNDL_IN")
	private String mndtryInBundlIn;

    @Temporal( TemporalType.DATE)
	@Column(name="PRD_BNDLG_EFCTV_DT")
	private Date prdBndlgEfctvDt;

    @Temporal( TemporalType.DATE)
	@Column(name="PRD_BNDLG_XPRTN_DT")
	private Date prdBndlgXprtnDt;

	@Column(name="PRODUCTION_IN")
	private String productionIn;

	//bi-directional many-to-one association to TlegacyProduct
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="BUNDLED_PRODUCT_CD")
	private TlegacyProduct tlegacyProduct1;

	//bi-directional many-to-one association to TlegacyProduct
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="PRODUCT_CD")
	private TlegacyProduct tlegacyProduct2;

	//bi-directional many-to-one association to TlegacyTrnsctnCmpntXtensn
	@OneToMany(mappedBy="tlegacyProductBundling")
	private Set<TlegacyTrnsctnCmpntXtensn> tlegacyTrnsctnCmpntXtensns;

    public TlegacyProductBundling() {
    }

	public TlegacyProductBundlingPK getId() {
		return this.id;
	}

	public void setId(TlegacyProductBundlingPK id) {
		this.id = id;
	}
	
	public String getCreatedById() {
		return this.createdById;
	}

	public void setCreatedById(String createdById) {
		this.createdById = createdById;
	}

	public Date getEnteredDt() {
		return this.enteredDt;
	}

	public void setEnteredDt(Date enteredDt) {
		this.enteredDt = enteredDt;
	}

	public Timestamp getLastUpdtTs() {
		return this.lastUpdtTs;
	}

	public void setLastUpdtTs(Timestamp lastUpdtTs) {
		this.lastUpdtTs = lastUpdtTs;
	}

	public String getLastUpdtUserId() {
		return this.lastUpdtUserId;
	}

	public void setLastUpdtUserId(String lastUpdtUserId) {
		this.lastUpdtUserId = lastUpdtUserId;
	}

	public String getMndtryInBundlIn() {
		return this.mndtryInBundlIn;
	}

	public void setMndtryInBundlIn(String mndtryInBundlIn) {
		this.mndtryInBundlIn = mndtryInBundlIn;
	}

	public Date getPrdBndlgEfctvDt() {
		return this.prdBndlgEfctvDt;
	}

	public void setPrdBndlgEfctvDt(Date prdBndlgEfctvDt) {
		this.prdBndlgEfctvDt = prdBndlgEfctvDt;
	}

	public Date getPrdBndlgXprtnDt() {
		return this.prdBndlgXprtnDt;
	}

	public void setPrdBndlgXprtnDt(Date prdBndlgXprtnDt) {
		this.prdBndlgXprtnDt = prdBndlgXprtnDt;
	}

	public String getProductionIn() {
		return this.productionIn;
	}

	public void setProductionIn(String productionIn) {
		this.productionIn = productionIn;
	}

	public TlegacyProduct getTlegacyProduct1() {
		return this.tlegacyProduct1;
	}

	public void setTlegacyProduct1(TlegacyProduct tlegacyProduct1) {
		this.tlegacyProduct1 = tlegacyProduct1;
	}
	
	public TlegacyProduct getTlegacyProduct2() {
		return this.tlegacyProduct2;
	}

	public void setTlegacyProduct2(TlegacyProduct tlegacyProduct2) {
		this.tlegacyProduct2 = tlegacyProduct2;
	}
	
	public Set<TlegacyTrnsctnCmpntXtensn> getTlegacyTrnsctnCmpntXtensns() {
		return this.tlegacyTrnsctnCmpntXtensns;
	}

	public void setTlegacyTrnsctnCmpntXtensns(Set<TlegacyTrnsctnCmpntXtensn> tlegacyTrnsctnCmpntXtensns) {
		this.tlegacyTrnsctnCmpntXtensns = tlegacyTrnsctnCmpntXtensns;
	}
	
}