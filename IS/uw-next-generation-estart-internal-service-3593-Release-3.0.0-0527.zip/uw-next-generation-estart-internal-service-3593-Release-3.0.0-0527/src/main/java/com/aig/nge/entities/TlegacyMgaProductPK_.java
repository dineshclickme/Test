package com.aig.nge.entities;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-04-15T15:31:46.932+0530")
@StaticMetamodel(TlegacyMgaProductPK.class)
public class TlegacyMgaProductPK_ {
	public static volatile SingularAttribute<TlegacyMgaProductPK, String> productCd;
	public static volatile SingularAttribute<TlegacyMgaProductPK, String> mgaId;
}
