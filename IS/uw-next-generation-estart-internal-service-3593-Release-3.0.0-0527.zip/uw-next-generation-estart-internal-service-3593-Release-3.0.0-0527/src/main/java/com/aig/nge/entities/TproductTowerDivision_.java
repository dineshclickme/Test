package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SetAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-02-24T11:59:50.084+0530")
@StaticMetamodel(TproductTowerDivision.class)
public class TproductTowerDivision_ {
	public static volatile SingularAttribute<TproductTowerDivision, Short> productTowerDivisionId;
	public static volatile SingularAttribute<TproductTowerDivision, Timestamp> createTs;
	public static volatile SingularAttribute<TproductTowerDivision, String> createUserId;
	public static volatile SingularAttribute<TproductTowerDivision, Timestamp> updateTs;
	public static volatile SingularAttribute<TproductTowerDivision, String> updateUserId;
	public static volatile SingularAttribute<TproductTowerDivision, Tdivision> tdivision;
	public static volatile SingularAttribute<TproductTowerDivision, TproductTower> tproductTower;
	public static volatile SetAttribute<TproductTowerDivision, TtransactionComponent> ttransactionComponents;
}
