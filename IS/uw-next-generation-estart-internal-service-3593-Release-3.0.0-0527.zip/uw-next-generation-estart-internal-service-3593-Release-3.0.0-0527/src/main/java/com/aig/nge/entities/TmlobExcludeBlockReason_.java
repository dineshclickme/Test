package com.aig.nge.entities;

import java.sql.Timestamp;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;


/**
 * @author AIGAdmin
 * 2020 SCUP Release - MLOB change - US159484
 */
@Generated(value="Dali", date="2015-02-19T16:13:03.705+0530")
@StaticMetamodel(TmlobExcludeBlockReason.class)
public class TmlobExcludeBlockReason_ {
	public static volatile SingularAttribute<TmlobExcludeBlockReason_, String> excludeBlockReasonId;
	public static volatile SingularAttribute<TmlobExcludeBlockReason_, TmlobExcludeBlockByType> tmlobExcludeBlockByType;
	public static volatile SingularAttribute<TmlobExcludeBlockReason_, Treason> treason;
	public static volatile SingularAttribute<TmlobExcludeBlockReason_, Tstatus> tstatus;
	public static volatile SingularAttribute<TmlobExcludeBlockReason_, Timestamp> createTs;
	public static volatile SingularAttribute<TmlobExcludeBlockReason_, String> createUserId;
	public static volatile SingularAttribute<TmlobExcludeBlockReason_, Timestamp> updateTs;
	public static volatile SingularAttribute<TmlobExcludeBlockReason_, String> updateUserId;
}