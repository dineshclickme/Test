package com.aig.nge.entities;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-08-04T13:12:21.336+0530")
@StaticMetamodel(TlegacySubmissionAddlInfoPK.class)
public class TlegacySubmissionAddlInfoPK_ {
	public static volatile SingularAttribute<TlegacySubmissionAddlInfoPK, String> submissionNo;
	public static volatile SingularAttribute<TlegacySubmissionAddlInfoPK, Integer> accountNo;
}
