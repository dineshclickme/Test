package com.aig.nge.entities;

import java.util.Date;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-03-02T12:10:25.149+0530")
@StaticMetamodel(TtransactionCmpntAtrbtHPK.class)
public class TtransactionCmpntAtrbtHPK_ {
	public static volatile SingularAttribute<TtransactionCmpntAtrbtHPK, String> transactionComponentId;
	public static volatile SingularAttribute<TtransactionCmpntAtrbtHPK, Short> attributeId;
	public static volatile SingularAttribute<TtransactionCmpntAtrbtHPK, Short> attributeSqn;
	public static volatile SingularAttribute<TtransactionCmpntAtrbtHPK, Date> createHistoryTs;
}
