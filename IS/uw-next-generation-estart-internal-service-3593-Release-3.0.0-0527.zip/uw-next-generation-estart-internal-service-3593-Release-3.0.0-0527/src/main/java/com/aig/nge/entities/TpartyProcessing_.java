package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SetAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-02-19T16:13:03.687+0530")
@StaticMetamodel(TpartyProcessing.class)
public class TpartyProcessing_ {
	public static volatile SingularAttribute<TpartyProcessing, Short> partyProcessingId;
	public static volatile SingularAttribute<TpartyProcessing, Timestamp> createTs;
	public static volatile SingularAttribute<TpartyProcessing, String> createUserId;
	public static volatile SingularAttribute<TpartyProcessing, String> partyProcessingDs;
	public static volatile SingularAttribute<TpartyProcessing, Timestamp> updateTs;
	public static volatile SingularAttribute<TpartyProcessing, String> updateUserId;
	public static volatile SetAttribute<TpartyProcessing, TtransactionComponent> ttransactionComponents;
}
