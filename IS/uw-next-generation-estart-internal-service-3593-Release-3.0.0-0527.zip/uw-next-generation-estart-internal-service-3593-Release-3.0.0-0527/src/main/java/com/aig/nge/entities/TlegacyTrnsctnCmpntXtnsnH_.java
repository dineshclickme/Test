package com.aig.nge.entities;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-09-11T14:03:53.804+0530")
@StaticMetamodel(TlegacyTrnsctnCmpntXtnsnH.class)
public class TlegacyTrnsctnCmpntXtnsnH_ {
	public static volatile SingularAttribute<TlegacyTrnsctnCmpntXtnsnH, TlegacyTrnsctnCmpntXtnsnHPK> id;
	public static volatile SingularAttribute<TlegacyTrnsctnCmpntXtnsnH, Timestamp> createTs;
	public static volatile SingularAttribute<TlegacyTrnsctnCmpntXtnsnH, String> createUserId;
	public static volatile SingularAttribute<TlegacyTrnsctnCmpntXtnsnH, String> legacyBundledProductCd;
	public static volatile SingularAttribute<TlegacyTrnsctnCmpntXtnsnH, String> legacyProdctCovgTypCd;
	public static volatile SingularAttribute<TlegacyTrnsctnCmpntXtnsnH, String> legacyProductCd;
	public static volatile SingularAttribute<TlegacyTrnsctnCmpntXtnsnH, BigDecimal> partOfAm;
	public static volatile SingularAttribute<TlegacyTrnsctnCmpntXtnsnH, Short> profitUnitCd;
	public static volatile SingularAttribute<TlegacyTrnsctnCmpntXtnsnH, Short> sectionCd;
	public static volatile SingularAttribute<TlegacyTrnsctnCmpntXtnsnH, Timestamp> updateTs;
	public static volatile SingularAttribute<TlegacyTrnsctnCmpntXtnsnH, String> updateUserId;
	public static volatile SingularAttribute<TlegacyTrnsctnCmpntXtnsnH, Date> xchangeRtEfctvDt;
	public static volatile SingularAttribute<TlegacyTrnsctnCmpntXtnsnH, BigDecimal> localPartOfAm;
	public static volatile SingularAttribute<TlegacyTrnsctnCmpntXtnsnH, String> profitCenterCd;
	public static volatile SingularAttribute<TlegacyTrnsctnCmpntXtnsnH, String> sourceCd;
	public static volatile SingularAttribute<TlegacyTrnsctnCmpntXtnsnH, String> workingBranchCd;
	public static volatile SingularAttribute<TlegacyTrnsctnCmpntXtnsnH, Integer> rrPrtctvContNo;
	public static volatile SingularAttribute<TlegacyTrnsctnCmpntXtnsnH, String> specialEventNm;
	public static volatile SingularAttribute<TlegacyTrnsctnCmpntXtnsnH, Date> underwritingDt;
	public static volatile SingularAttribute<TlegacyTrnsctnCmpntXtnsnH, String> currntBusTypCd;
}
