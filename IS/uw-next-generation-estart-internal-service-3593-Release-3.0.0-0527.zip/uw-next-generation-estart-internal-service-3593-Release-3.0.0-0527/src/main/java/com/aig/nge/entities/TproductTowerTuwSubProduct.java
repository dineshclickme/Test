package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;

import org.apache.openjpa.persistence.DataCache;
import java.sql.Timestamp;
import java.util.Set;


/**
 * The persistent class for the TPRODUCT_TOWER_TUW_SUB_PRODCT database table.
 * 
 */
@Entity
@DataCache
@Table(name="TPRODUCT_TOWER_TUW_SUB_PRODCT")
public class TproductTowerTuwSubProduct implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="PRODUCT_TOWER_TUW_SUBPRODCT_ID")
	private int productTowerTuwSubprodctId;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="CREATE_TS")
	private Timestamp createTs;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="CREATE_USER_ID")
	private String createUserId;

	@Column(name="DELETED_IN")
	private String deletedIn;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="UPDATE_TS")
	private Timestamp updateTs;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="UPDATE_USER_ID")
	private String updateUserId;
	
	@Column(name="PRODUCT_TOWER_ID")
	private short productTowerId;

	@Column(name="TUW_SUB_PRODUCT_ID")
	private int tuwSubProductId;

	//bi-directional many-to-one association to TprdctTwrTuwSbprdctAstTyp
	@OneToMany(mappedBy="tproductTowerTuwSubProdct")
	private Set<TprdctTwrTuwSbprdctAstTyp> tprdctTwrTuwSbprdctAstTyps;

	//bi-directional many-to-one association to TtuwSubProduct
    @ManyToOne
	@JoinColumn(name="TUW_SUB_PRODUCT_ID")
	private TtuwSubProduct ttuwSubProduct;

	//bi-directional many-to-one association to TproductTower
    @ManyToOne
	@JoinColumn(name="PRODUCT_TOWER_ID")
	private TproductTower tproductTower;

    
	//bi-directional many-to-one association to TmarketableProductComponent
	@OneToMany(mappedBy="tproductTowerTuwSubProduct")
	private Set<TmarketableProductComponent> tmarketableProductComponents;
// NGE UI sept release changes start
	//bi-directional many-to-one association to TprdctTwrTuwSubPrdctDiv
	@OneToMany(mappedBy="tproductTowerTuwSubProdct")
	private Set<TprdctTwrTuwSubPrdctDiv> tprdctTwrTuwSubPrdctDivs;
// NGE UI sept release changes end
	//bi-directional many-to-one association to TproductDsp
	@OneToMany(mappedBy="tproductTowerTuwSubProduct")
	private Set<TproductDsp> tproductDsps;

	//bi-directional many-to-one association to TproductMmcp
	@OneToMany(mappedBy="tproductTowerTuwSubProduct")
	private Set<TproductMmcp> tproductMmcps;
	
	//bi-directional one-to-one association to Tproduct
	@OneToOne
	@JoinColumn(name="PRODUCT_TOWER_TUW_SUBPRODCT_ID")
	private Tproduct tproduct;

	//bi-directional many-to-one association to TtuwSubProductBlockXclusn
	@OneToMany(mappedBy="tproductTowerTuwSubProdct")
	private Set<TtuwSubProductBlockXclusn> ttuwSubProductBlockXclusns;
	
	//bi-directional many-to-one association to TprdctTwrTuwSbprdctAstTyp
		@OneToMany(mappedBy="tproductTowerTuwSubProdct")
		private Set<TprdctTwrTuwSbprdctAstTyp> tprdctTwrTuwSbprdctAstTyp;

    public TproductTowerTuwSubProduct() {
    }

	public int getProductTowerTuwSubprodctId() {
		return this.productTowerTuwSubprodctId;
	}

	public void setProductTowerTuwSubprodctId(int productTowerTuwSubprodctId) {
		this.productTowerTuwSubprodctId = productTowerTuwSubprodctId;
	}
	
	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public String getDeletedIn() {
		return this.deletedIn;
	}

	public void setDeletedIn(String deletedIn) {
		this.deletedIn = deletedIn;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}
	
	public Set<TmarketableProductComponent> getTmarketableProductComponents() {
		return this.tmarketableProductComponents;
	}

	public void setTmarketableProductComponents(Set<TmarketableProductComponent> tmarketableProductComponents) {
		this.tmarketableProductComponents = tmarketableProductComponents;
	}
// NGE UI sept release changes start
	public Set<TprdctTwrTuwSubPrdctDiv> getTprdctTwrTuwSubPrdctDivs() {
		return this.tprdctTwrTuwSubPrdctDivs;
	}

	public void setTprdctTwrTuwSubPrdctDivs(Set<TprdctTwrTuwSubPrdctDiv> tprdctTwrTuwSubPrdctDivs) {
		this.tprdctTwrTuwSubPrdctDivs = tprdctTwrTuwSubPrdctDivs;
	}
// NGE UI sept release changes end	
	public Set<TproductDsp> getTproductDsps() {
		return this.tproductDsps;
	}

	public void setTproductDsps(Set<TproductDsp> tproductDsps) {
		this.tproductDsps = tproductDsps;
	}
	
	public Set<TproductMmcp> getTproductMmcps() {
		return this.tproductMmcps;
	}

	public void setTproductMmcps(Set<TproductMmcp> tproductMmcps) {
		this.tproductMmcps = tproductMmcps;
	}
	
	public Tproduct getTproduct() {
		return this.tproduct;
	}

	public void setTproduct(Tproduct tproduct) {
		this.tproduct = tproduct;
	}
	
	public Set<TprdctTwrTuwSbprdctAstTyp> getTprdctTwrTuwSbprdctAstTyps() {
		return this.tprdctTwrTuwSbprdctAstTyps;
	}

	public void setTprdctTwrTuwSbprdctAstTyps(Set<TprdctTwrTuwSbprdctAstTyp> tprdctTwrTuwSbprdctAstTyps) {
		this.tprdctTwrTuwSbprdctAstTyps = tprdctTwrTuwSbprdctAstTyps;
	}
	
	public TproductTower getTproductTower() {
		return this.tproductTower;
	}

	public void setTproductTower(TproductTower tproductTower) {
		this.tproductTower = tproductTower;
	}
	
	public TtuwSubProduct getTtuwSubProduct() {
		return this.ttuwSubProduct;
	}

	public void setTtuwSubProduct(TtuwSubProduct ttuwSubProduct) {
		this.ttuwSubProduct = ttuwSubProduct;
	}
	
	public Set<TtuwSubProductBlockXclusn> getTtuwSubProductBlockXclusns() {
		return this.ttuwSubProductBlockXclusns;
	}

	public void setTtuwSubProductBlockXclusns(Set<TtuwSubProductBlockXclusn> ttuwSubProductBlockXclusns) {
		this.ttuwSubProductBlockXclusns = ttuwSubProductBlockXclusns;
	}
	
	public short getProductTowerId() {
		return this.productTowerId;
	}
	public void setProductTowerId(short productTowerId) {
		this.productTowerId = productTowerId;
	}
	public int getTuwSubProductId() {
		return this.tuwSubProductId;
	}
	public void setTuwSubProductId(int tuwSubProductId) {
		this.tuwSubProductId = tuwSubProductId;
	}

	public Set<TprdctTwrTuwSbprdctAstTyp> getTprdctTwrTuwSbprdctAstTyp() {
		return tprdctTwrTuwSbprdctAstTyp;
	}

	public void setTprdctTwrTuwSbprdctAstTyp(
			Set<TprdctTwrTuwSbprdctAstTyp> tprdctTwrTuwSbprdctAstTyp) {
		this.tprdctTwrTuwSbprdctAstTyp = tprdctTwrTuwSbprdctAstTyp;
	}

	
}
