package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SetAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-02-19T16:13:03.273+0530")
@StaticMetamodel(TdataType.class)
public class TdataType_ {
	public static volatile SingularAttribute<TdataType, Short> dataTypeId;
	public static volatile SingularAttribute<TdataType, Timestamp> createTs;
	public static volatile SingularAttribute<TdataType, String> createUserId;
	public static volatile SingularAttribute<TdataType, String> dataTypeNm;
	public static volatile SingularAttribute<TdataType, Timestamp> updateTs;
	public static volatile SingularAttribute<TdataType, String> updateUserId;
	public static volatile SetAttribute<TdataType, Tattribute> tattributes;
}
