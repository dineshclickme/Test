package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the TPRODUCER_CONTACT database table.
 * 
 */
@Embeddable
public class TproducerContactPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="TRANSACTION_ID")
	private String transactionId;

	@Column(name="CONTACT_SQN")
	private short contactSqn;

    public TproducerContactPK() {
    }
	public String getTransactionId() {
		return this.transactionId;
	}
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	public short getContactSqn() {
		return this.contactSqn;
	}
	public void setContactSqn(short contactSqn) {
		this.contactSqn = contactSqn;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof TproducerContactPK)) {
			return false;
		}
		TproducerContactPK castOther = (TproducerContactPK)other;
		return 
			this.transactionId.equals(castOther.transactionId)
			&& (this.contactSqn == castOther.contactSqn);

    }
    
	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.transactionId.hashCode();
		hash = hash * prime + ((int) this.contactSqn);
		
		return hash;
    }
}