package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-04-15T15:31:47.431+0530")
@StaticMetamodel(TofacAlertNotification.class)
public class TofacAlertNotification_ {
	public static volatile SingularAttribute<TofacAlertNotification, Integer> ofacAlertId;
	public static volatile SingularAttribute<TofacAlertNotification, Timestamp> createTs;
	public static volatile SingularAttribute<TofacAlertNotification, String> createUserId;
	public static volatile SingularAttribute<TofacAlertNotification, String> notifiedIn;
	public static volatile SingularAttribute<TofacAlertNotification, Timestamp> updateTs;
	public static volatile SingularAttribute<TofacAlertNotification, String> updateUserId;
	public static volatile SingularAttribute<TofacAlertNotification, Tparty> tparty;
	public static volatile SingularAttribute<TofacAlertNotification, Tsubmission> tsubmission;
	public static volatile SingularAttribute<TofacAlertNotification, TsubmissionEvaluationAlert> tsubmissionEvaluationAlert;
}
