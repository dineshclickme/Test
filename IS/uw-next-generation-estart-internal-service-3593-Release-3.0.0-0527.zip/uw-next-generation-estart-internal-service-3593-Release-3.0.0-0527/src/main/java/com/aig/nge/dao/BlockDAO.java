package com.aig.nge.dao;

import java.sql.Timestamp;
import java.util.HashMap;
import java.util.List;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.jpa.JpaSystemException;
import org.springframework.stereotype.Repository;

import com.aig.nge.entities.BlockedProductDetailsBO;
import com.aig.nge.entities.TalertBlock;
import com.aig.nge.entities.Tblock;
import com.aig.nge.entities.TblockType;
import com.aig.nge.entities.TcomponentBlock;
import com.aig.nge.entities.Tcurrency;
import com.aig.nge.entities.Tlocation;
import com.aig.nge.entities.Tparty;
import com.aig.nge.entities.TrelatedParty;
import com.aig.nge.entities.Trole;
import com.aig.nge.entities.Tstatus;
import com.aig.nge.helper.CreateTransactionVersionHelper;
import com.aig.nge.repository.TAlertBlockRepository;
import com.aig.nge.repository.TBlockHRepository;
import com.aig.nge.repository.TBlockRepository;
import com.aig.nge.repository.TBlockTypeRepository;
import com.aig.nge.repository.TComponentBlockRepository;
import com.aig.nge.repository.TCurrencyRepository;
import com.aig.nge.repository.TLocationRepository;
import com.aig.nge.repository.TRoleRepository;
import com.aig.nge.repository.TStatusRepository;
import com.aig.nge.utilities.AIGCIExceptionMsg;
import com.aig.nge.utilities.NGEConstants;
import com.aig.nge.utilities.NGEErrorCodes;
import com.aig.nge.utilities.NGEQueryConstants;


/**
 * @author Manasaj This DAO class is used for accessing the Block related
 *         repositories Used repositories are : TBlockRepository
 *         TComponentBlockRepository
 * 
 */

@Repository
public class BlockDAO extends BaseDAO{

	@Autowired
	private TBlockRepository blockRepository;

	@Autowired
	private TComponentBlockRepository componentBlockRepository;

	@Autowired
	private TBlockTypeRepository blockTypeRepository;

	@Autowired
	private TAlertBlockRepository alertBlockRepository;

	@Autowired
	private CreateTransactionVersionHelper createTransactionVersionHelper;

	@Autowired
	private TBlockHRepository tBlockHRepository;
	
	@Autowired
	private TBlockTypeRepository tBlockTypeRepository;
	
	@Autowired
	private TStatusRepository statusRepository;
	@Autowired
	private TCurrencyRepository currencyRepository;
	@Autowired
	private TLocationRepository locationRepository;
	@Autowired
	private TRoleRepository roleRepository;
	
	@Autowired
	private PartyDAO partyDAO;
	
	 @PersistenceContext(unitName = "a_NGEJPA_ORA")
	 private EntityManager em;
	
	
	/**
	 * @author Manasaj
	 * @param BlockNo
	 * @return
	 * @throws AIGCIExceptionMsg
	 */
	public Tblock findByBlockNo(int BlockNo) throws AIGCIExceptionMsg {
		Tblock block = blockRepository.findOne(BlockNo);

		if (block == null) {
			ngeException.throwException(NGEErrorCodes.INVALID_BLOCK_NUMBER,
					NGEErrorCodes.ERROR_TYPE, "Invalid Block Number", null);
		}
		return block;
	}
	
	public Tblock saveBlock(Tblock block) throws AIGCIExceptionMsg {
		/* Exadata changes - Not null issue starts */
		if(block.getCommentTx() != null){
			if(block.getCommentTx().trim().equals(NGEConstants.EMPTY_STRING))
				block.setCommentTx(NGEConstants.EMPTY_SPACE);
		}
		/* Exadata changes - Not null issue ends */
		Tblock tblock = blockRepository.save(block);
		return tblock;
	}

	/**
	 * @author Manasaj
	 * @param BlockNo
	 * @return
	 * @throws AIGCIExceptionMsg 
	 */
	public TcomponentBlock getComponentBlockByBlockNo(int BlockNo) throws AIGCIExceptionMsg {
		TcomponentBlock componentBlock = componentBlockRepository
				.findOne(BlockNo);
		if(componentBlock == null){
			ngeException.throwException(NGEErrorCodes.NO_BLOCKS_AVAILABLE,
					NGEErrorCodes.ERROR_TYPE, "Component Blocks are not available", null);
		}
		return componentBlock;
	}

	

	public Set<TcomponentBlock> getTransCompBlockList(
			String transactionComponentId) {
		Set<TcomponentBlock> compBlockList = componentBlockRepository
				.findBytransactionComponentId(transactionComponentId);

		return compBlockList;
	}

	public Tblock getBlock(int blockNo) throws AIGCIExceptionMsg {
		Tblock block = null;
		block = blockRepository.findOne(blockNo);
		if(block == null){
			ngeException.throwException(NGEErrorCodes.INVALID_BLOCK_NUMBER,
					NGEErrorCodes.ERROR_TYPE, "Invalid Block Number", null);
		}
		return block;
	}

	public TblockType getType(short blockId) {
		TblockType blockType = blockTypeRepository.findOne(blockId);
		return blockType;
	}
	public List<Tblock> findBlockedProductForTransactionCCompProduct (String transactionComponentId, String statusNm){
		
		/*
		* EXADATA Migration Changes
		* 		Adding space for status name 
		*/
		
		if(statusNm.equals(NGEConstants.EMPTY_STRING))
			statusNm = NGEConstants.EMPTY_SPACE;		
		List<Tblock> blocks = blockRepository.findByTransactionComponentIdAndStatusNm(transactionComponentId, statusNm.toUpperCase());
		return blocks;
	}
	/**
	 * @author Padma E
	 * @param BlockNo
	 * @return
	 * @throws AIGCIExceptionMsg
	 */
	public TalertBlock getAlertBlockNo(int BlockNo) throws AIGCIExceptionMsg {
		TalertBlock alertBlock = null; 
		alertBlock = alertBlockRepository.findOne(BlockNo);
		if(alertBlock == null){
			ngeException.throwException(NGEErrorCodes.INVALID_BLOCK_NUMBER,
					NGEErrorCodes.ERROR_TYPE, "Invalid Block Number", null);
		}
		return alertBlock;
	}
	
	public Tblock saveTblock(Tblock block) throws AIGCIExceptionMsg {
		Tblock blockData = null; 
		blockData = blockRepository.save(block);
		return blockData;
	}
	
	public TcomponentBlock saveComponentBlock(TcomponentBlock block) throws AIGCIExceptionMsg {
		TcomponentBlock tComponentBlock = null;
		tComponentBlock = componentBlockRepository.save(block);
		return tComponentBlock;
	}
	
	public List<Tblock> getOtherBlockForComponentId(String transactionCompId, String statusNm, String blockType) 
	{
		/*
		* EXADATA Migration Changes
		* 		Adding space for status name 
		*/

		if(statusNm.equals(NGEConstants.EMPTY_STRING))
			statusNm = NGEConstants.EMPTY_SPACE;
		
		List<Tblock> blockList = blockRepository.getOtherBlocks(transactionCompId, statusNm, blockType);	
		return blockList;
	}
	public List<Object[]> fetchTBlock(String existingTtransactionCompId) {
		List<Object[]> tblockObjects=blockRepository.fetchBlock(existingTtransactionCompId);
		return tblockObjects;
	}
	public void insertTBlock(int blockNo,
			String existingTtransactionCompId, Short statusId, Short reasonID,
			Short blockTypeId, String comment, Short systemId,
			String createUserID, Timestamp createTs, int partyId, int roleId) throws AIGCIExceptionMsg {
		int blockSequence=blockRepository.getMaxBlockSqn();	
		HashMap<String, Object> sequenceNumber = null;
		sequenceNumber=createTransactionVersionHelper.getBlockIdSequence();
		blockSequence = Integer.parseInt(sequenceNumber.get(
		NGEConstants.Sequence.BLOCK_ID).toString());
		tBlockHRepository.insertTblockHistory(blockNo);
		/* Exadata changes - Not null issue starts */
		if(comment != null){
			if(comment.trim().equals(NGEConstants.EMPTY_STRING))
				comment = NGEConstants.EMPTY_SPACE;
		}
		/* Exadata changes - Not null issue ends */
		blockRepository.insertTBlock(blockSequence, existingTtransactionCompId, statusId, reasonID, blockTypeId, comment, systemId, createUserID, createTs, partyId, roleId);
		blockRepository.updateTComponentBlock(blockSequence,blockNo,createUserID,null) ;
	}
	public void updateTBlock(String existingTtransactionComponentId,int statusId) {
		
		blockRepository.updateTBlockStatus(existingTtransactionComponentId,statusId,"dinz",null);
	}
	
	public int getRemainingActiveBlocksCountForBlockedProduct (int blockedSubmissionNo, int blockingSubmissionNo, String blockedMarketableProductCd, int blockTypeId, int blockNo, int statusId){
		
		int blockCount = 0;
		blockCount = blockRepository.getRemainingActiveBlocksCountForBlockedProduct(blockedSubmissionNo, blockingSubmissionNo, blockedMarketableProductCd, blockTypeId, blockNo, statusId);
		return blockCount;
		
	}
	
	public int getRemainingActiveBlocksCountForBlockingProduct (int blockedSubmissionNo, int blockingSubmissionNo, String blockingMarketableProductCd, int blockTypeId, int blockNo, int statusId){
		
		int blockCount = 0;
		blockCount = blockRepository.getRemainingActiveBlocksCountForBlockingProduct(blockedSubmissionNo, blockingSubmissionNo, blockingMarketableProductCd, blockTypeId, blockNo, statusId);
		return blockCount;
		
	}

	public List<BlockedProductDetailsBO> getBlockedProductDetails (Long submissionNo, Long accountNo, String mdmPartyId,
			String underWriterNo, String submissionEnteredFromDate,String submissionEnteredToDate,String advBlockSearchMaxResult) throws JpaSystemException, AIGCIExceptionMsg{
		String getBlockedProductQuery="";
		getBlockedProductQuery+=NGEQueryConstants.GET_BLOC_PROD_QRY_SELECT_FROM_CLAUSE;
		
		
		Tstatus tStatus=statusRepository.findByStatusNm(NGEConstants.ReservationCondition.BLOCKED);
		TblockType tBlockType=tBlockTypeRepository.findByBlockTypeDs(NGEConstants.PRODUCT_BLOCK);
		Tcurrency tcurrency=currencyRepository.findByCurrencyCd(NGEConstants.USD);
		Tlocation tlocation=locationRepository.getByLocationCode(NGEConstants.Location.UNITED_STATES, NGEConstants.LocationType.COUNTRY);
		Trole tRole=roleRepository.findByRoleNmIgnoreCase(NGEConstants.ROLE.NGE_MANAGER);
		if(submissionNo!=null){
			getBlockedProductQuery+=NGEQueryConstants.GET_BLOC_PROD_QRY_SUBMISSION_WHERE_CLAUSE;
		}
		Integer accountId=null;
		if(accountNo!=null){
			Tparty tpartyAccount=partyDAO.getParty(accountNo,NGEConstants.PartyType.ACCOUNT);
			if(tpartyAccount!=null){
				accountId=tpartyAccount.getPartyId();
			}else{
				Tparty tpartyShellAccount=partyDAO.getParty(accountNo,NGEConstants.PartyType.SHELL);
				if(tpartyShellAccount!=null)
					accountId=tpartyShellAccount.getPartyId();
			}
			if(accountId==null){
				ngeException.throwException(NGEErrorCodes.INVALID_ACCOUNT,
						NGEErrorCodes.ERROR_TYPE, null, null);
			}
			getBlockedProductQuery+=NGEQueryConstants.GET_BLOC_PROD_QRY_ACC_WHERE_CLAUSE;
		}
		/* 2021 MDM Changes - Starts */
		if(mdmPartyId!=null){
			Tparty mdmPartyRecord = null;
			TrelatedParty relatedPartyRecord = null;
			Tparty accPartyRecord = null;
			
			mdmPartyRecord=partyDAO.getMDMPartyRecord(mdmPartyId,NGEConstants.PartyType.MDM_PARTY_ID);
			if(mdmPartyRecord == null) {
				ngeException.throwException(NGEErrorCodes.INVALID_MDMPARTYID,
						NGEErrorCodes.ERROR_TYPE, "Invalid Universal Party ID. Given Universal Party ID is either blank or does not exist in NGE", null);
			}
			relatedPartyRecord = partyDAO.getRelatedPartyByMDMPartyID(mdmPartyId, NGEConstants.RelatedPartyType.ACCOUNT_MDM_PARTY);
			if(relatedPartyRecord == null) {
				ngeException.throwException(NGEErrorCodes.MISSING_ACC_MAPPING,
						NGEErrorCodes.ERROR_TYPE, "Account number not available for the given Universal Party ID", null);
			}
			accPartyRecord = relatedPartyRecord.getTparty1();
			if(accPartyRecord != null){
				accountId=accPartyRecord.getPartyId();				
			}
			getBlockedProductQuery+=NGEQueryConstants.GET_BLOC_PROD_QRY_ACC_WHERE_CLAUSE;
		}
		/* 2021 MDM Changes - Ends */
		
		Integer underWriterId=null;
		if(underWriterNo!=null){
			Tparty tPartyUW=partyDAO.getUnderwriterParty(underWriterNo,NGEConstants.PartyType.UNDERWRITER);
			if(tPartyUW!=null){
				underWriterId=tPartyUW.getPartyId();
			}
			if(underWriterId==null){
				ngeException.throwException(NGEErrorCodes.NO_UNDERWRITERS_FOUND,
						NGEErrorCodes.ERROR_TYPE, null, null);
			}
			getBlockedProductQuery+=NGEQueryConstants.GET_BLOC_PROD_QRY_UW_WHERE_CLAUSE;
		}
		if(submissionEnteredFromDate!=null && submissionEnteredToDate!=null){
			getBlockedProductQuery+=NGEQueryConstants.GET_BLOC_PROD_QRY_DATE_WHERE_CLAUSE;
		}
		getBlockedProductQuery=getBlockedProductQuery.substring(0, getBlockedProductQuery.length()-5);
		getBlockedProductQuery+=NGEQueryConstants.GET_BLOC_PROD_QRY_ORDER;
		
		Query query=em.createNativeQuery(getBlockedProductQuery,BlockedProductDetailsBO.class).setMaxResults(Integer.parseInt(advBlockSearchMaxResult));
		query.setParameter(1, tStatus.getStatusId());
		query.setParameter(2, tBlockType.getBlockTypeId());
		query.setParameter(3, tlocation.getGeographicLocationId());
		query.setParameter(4, tRole.getRoleId());
		query.setParameter(5, NGEConstants.MANAGER_FUNCTIONS);
		query.setParameter(6, tcurrency.getCurrencyId());
		if(submissionNo!=null){
			query.setParameter(7, submissionNo);
		}
		if(accountId!=null){
			query.setParameter(8, accountId);
		}
		if(underWriterId!=null){
			query.setParameter(9, underWriterId);
		}
		if(submissionEnteredFromDate!=null && submissionEnteredToDate!=null){
			query.setParameter(10, submissionEnteredFromDate+NGEConstants.START_TIME);
			query.setParameter(11, submissionEnteredToDate+NGEConstants.END_TIME);
		}
		return query.getResultList();
	}
	
}
