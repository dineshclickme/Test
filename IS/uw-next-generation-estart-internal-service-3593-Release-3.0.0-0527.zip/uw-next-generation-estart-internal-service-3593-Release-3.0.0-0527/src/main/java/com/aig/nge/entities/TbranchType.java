package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;
import org.apache.openjpa.persistence.DataCache;
import java.sql.Timestamp;
import java.util.Set;


/**
 * The persistent class for the TBRANCH_TYPE database table.
 * 
 */
@Entity
@DataCache
@Table(name="TBRANCH_TYPE")
public class TbranchType implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="BRANCH_TYPE_ID")
	private short branchTypeId;

	@Column(name="BRANCH_TYPE_NM")
	private String branchTypeNm;

	@Basic(fetch=FetchType.LAZY)
	@Column(name="CREATE_TS")
	private Timestamp createTs;

	@Basic(fetch=FetchType.LAZY)
	@Column(name="CREATE_USER_ID")
	private String createUserId;

	@Basic(fetch=FetchType.LAZY)
	@Column(name="UPDATE_TS")
	private Timestamp updateTs;

	@Basic(fetch=FetchType.LAZY)
	@Column(name="UPDATE_USER_ID")
	private String updateUserId;

	//bi-directional many-to-one association to TtransactionComponentBranch
	@OneToMany(mappedBy="tbranchType", cascade={CascadeType.ALL})
	private Set<TtransactionComponentBranch> ttransactionComponentBranches;

    public TbranchType() {
    }

	public short getBranchTypeId() {
		return this.branchTypeId;
	}

	public void setBranchTypeId(short branchTypeId) {
		this.branchTypeId = branchTypeId;
	}

	public String getBranchTypeNm() {
		return this.branchTypeNm;
	}

	public void setBranchTypeNm(String branchTypeNm) {
		this.branchTypeNm = branchTypeNm;
	}

	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public Set<TtransactionComponentBranch> getTtransactionComponentBranches() {
		return this.ttransactionComponentBranches;
	}

	public void setTtransactionComponentBranches(Set<TtransactionComponentBranch> ttransactionComponentBranches) {
		this.ttransactionComponentBranches = ttransactionComponentBranches;
	}
	
}