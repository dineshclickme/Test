package com.aig.nge.entities;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.apache.openjpa.persistence.DataCache;


/**
 * The persistent class for the TMLOB_EXCLUDE_BLOCK_REASON database table.
 * 2020 SCUP Release - MLOB change - US159484
 */
@Entity
@DataCache
@Table(name="TMLOB_EXCLUDE_BLOCK_REASON")
public class TmlobExcludeBlockReason implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="MLOB_EXCLUDE_BLOCK_REASON_ID")
	private int excludeBlockReasonId;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="MLOB_EXCLUDE_BLOCK_BY_TYPE_ID")
	private TmlobExcludeBlockByType tmlobExcludeBlockByType;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="REASON_ID")
	private Treason treason;

	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="STATUS_ID")
	private Tstatus tstatus;
	
	@Column(name="CREATE_TS")
	private Timestamp createTs;

	@Column(name="CREATE_USER_ID")
	private String createUserId;

	@Column(name="UPDATE_TS")
	private Timestamp updateTs;

	@Column(name="UPDATE_USER_ID")
	private String updateUserId;

	public int getExcludeBlockReasonId() {
		return excludeBlockReasonId;
	}

	public void setExcludeBlockReasonId(int excludeBlockReasonId) {
		this.excludeBlockReasonId = excludeBlockReasonId;
	}

	public TmlobExcludeBlockByType getTmlobExcludeBlockByType() {
		return tmlobExcludeBlockByType;
	}

	public void setTmlobExcludeBlockByType(
			TmlobExcludeBlockByType tmlobExcludeBlockByType) {
		this.tmlobExcludeBlockByType = tmlobExcludeBlockByType;
	}

	public Treason getTreason() {
		return treason;
	}

	public void setTreason(Treason treason) {
		this.treason = treason;
	}

	public Tstatus getTstatus() {
		return tstatus;
	}

	public void setTstatus(Tstatus tstatus) {
		this.tstatus = tstatus;
	}

	public Timestamp getCreateTs() {
		return createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public Timestamp getUpdateTs() {
		return updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

}