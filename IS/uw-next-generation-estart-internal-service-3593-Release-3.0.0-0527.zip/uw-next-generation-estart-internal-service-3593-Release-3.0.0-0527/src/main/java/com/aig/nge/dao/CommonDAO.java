package com.aig.nge.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.jpa.JpaSystemException;
import org.springframework.stereotype.Repository;

import com.aig.nge.entities.Taccount;
import com.aig.nge.entities.Tcurrency;
import com.aig.nge.entities.Tlocation;
import com.aig.nge.entities.TpartyAction;
import com.aig.nge.entities.TproductTower;
import com.aig.nge.entities.TproductTowerAutoCloseRule;
import com.aig.nge.entities.TrelatedParty;
import com.aig.nge.entities.Trole;
import com.aig.nge.entities.TshellAccount;
import com.aig.nge.entities.Tsubmission;
import com.aig.nge.entities.Tsystem;
import com.aig.nge.entities.TtableAttribute;
import com.aig.nge.entities.TtransactionComponent;
import com.aig.nge.entities.TtransactionComponentBranch;
import com.aig.nge.helper.CommonServiceHelper;
import com.aig.nge.repository.TAccountRepository;
import com.aig.nge.repository.TCurrencyRepository;
import com.aig.nge.repository.TPartyActionRepository;
import com.aig.nge.repository.TProductTowerAutoCloseRuleRepository;
import com.aig.nge.repository.TRelatedPartyRepository;
import com.aig.nge.repository.TRoleRepository;
import com.aig.nge.repository.TShellAccountRepository;
import com.aig.nge.repository.TSubmissionRepository;
import com.aig.nge.repository.TSystemRepository;
import com.aig.nge.repository.TTableAttributeRepository;
import com.aig.nge.repository.TTransactionComponentBranchRepository;
import com.aig.nge.repository.TofacAlertNotificationRepository;
import com.aig.nge.utilities.AIGCIExceptionMsg;
import com.aig.nge.utilities.NGEConstants;
import com.aig.nge.utilities.NGEErrorCodes;import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
//import com.aig.nge.wsdl.skeleton.AIGCIException;


/**
 * @author DineshKumar This DAO class is used for accessing the common
 *         repository functions
 */
@Repository
public class CommonDAO extends BaseDAO {

	private static final Logger logger = LogManager.getLogger(CommonDAO.class);

	@Autowired
	private TSystemRepository systemRepository;

	@Autowired
	private TCurrencyRepository currencyRepository;
	@Autowired
	private TRoleRepository roleRepository;
	
	@Autowired
	TSubmissionRepository submissionRepository;
		
	@Autowired
	private TAccountRepository accountRepository;

	@Autowired
	TRoleRepository tRoleRepository;
	
	@Autowired
	private TPartyActionRepository tpartyActionRepository;

	@Autowired
	private TProductTowerAutoCloseRuleRepository productTowerAutoCloseRuleRepository;

	@Autowired
	private TTableAttributeRepository tableAttributeRepository;
	
	@Autowired
	private TShellAccountRepository tShellAccountRepository;
	
	@Autowired
	private TofacAlertNotificationRepository tOfacAlertNotificationRepository;
	
	@Autowired
	private TRelatedPartyRepository tRelatedPartyRepository;
	
	/*@Autowired
	private TProductTowerRepository tProductTowerRepository; */
	
	@Autowired
	private TTransactionComponentBranchRepository tTransactionComponentBranchRepository;
	
	@Autowired
	private LocationDAO locationDAO;
	
	/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
	@Autowired
	private CommonServiceHelper commonServiceHelper;
	/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
	
	/**
	 * @param systemName
	 * @return
	 * @throws AIGCIExceptionMsg
	 *             this method is used to get the sytem information by using the
	 *             system name
	 */
	public Tsystem getSystem(String systemName) throws AIGCIExceptionMsg,
			JpaSystemException {
		Tsystem systemData = null;

		List<Tsystem> systemRecord = new ArrayList<Tsystem>();

		systemRecord = systemRepository.findBySystemShortNm(systemName);

		if (systemRecord.size() > 0) {
			systemData = systemRecord.get(0);
		} else {
			ngeException.throwException(NGEErrorCodes.SERVICE_INVOKER_MISSING,
					NGEErrorCodes.ERROR_TYPE, null, null);
		}

		return systemData;
	}
	
	public Tsubmission validateSubmissionNo(Long submissionNo) throws AIGCIExceptionMsg {
		Tsubmission submissionData = submissionRepository.findOne(String.valueOf(submissionNo));
		if (submissionData == null) {
			ngeException.throwException(NGEErrorCodes.INVALID_SUBMISSION_NO_VALUE,
					NGEErrorCodes.ERROR_TYPE, "Invalid Submission Number. Given Submission Number is either blank or does not exist in NGE", null);
		}
		return submissionData;
	}
    	
	/**
	 * @author Padma E
	 * @param currencyCode
	 * @return
	 * @throws AIGCIExceptionMsg
	 *             this method is used to get the currency information by using
	 *             the currency code
	 */
	public Tcurrency getCurrency(String currencyCode) {
		Tcurrency currency = null;
		currency = currencyRepository.findByCurrencyCd(currencyCode);
		return currency;
	}
	/**
	 * @author Chitra P
	 * @param currencyCd
	 * @return
	 * This method is used to get the USD currencyId by using the USD currency code       
	 */
	public Tcurrency getCurrencyId(String currencyCd) {
		Tcurrency currency = null;
		currency = currencyRepository.findByCurrencyCd(currencyCd);
		return currency;
	}
	/**
	 * @author Manasaj
	 * @param roleNm
	 * @return
	 * @throws AIGCIExceptionMsg 
	 */
	public Trole getRole(String roleNm) throws AIGCIExceptionMsg {
		Trole tRoleData = roleRepository.findByRoleNmIgnoreCase(roleNm);
		if (tRoleData==null) 
		{
			ngeException.throwException(NGEErrorCodes.NO_ROLE_AVAILABLE, NGEErrorCodes.ERROR_TYPE, "Given Role is either invalid or not available in NGE", null);
		}
		return tRoleData;
	}
	
	public TtableAttribute validateAttribute(short attributeLevel, String attributeName) throws AIGCIExceptionMsg
	{
		int tableId = NGEConstants.AttributeTable.UNKNOWN;
		
		switch(attributeLevel) {
			case 101:
				tableId = NGEConstants.AttributeTable.TRANSACTION;
				break;
			case 102:
				tableId = NGEConstants.AttributeTable.MARKETABLE_PRODUCT;
				break;
			case 107:
				tableId = NGEConstants.AttributeTable.COMPONENT_PRODUCT;
				break;
			case 106:
				tableId = NGEConstants.AttributeTable.ASSET;
				break;
			case 105:
				tableId =  NGEConstants.AttributeTable.POLICY;
				break;				
		}
		
		TtableAttribute tableAttributeData = tableAttributeRepository.findByTableNmAndAttributeNm(tableId, attributeName);
		if(tableAttributeData == null)
		{
			ngeException.throwException(NGEErrorCodes.INVALID_TRANSACTION_ATTRIBUTE, NGEErrorCodes.ERROR_TYPE, "Invalid Transaction Attribute", null);
		}
		return tableAttributeData;

	}
	
	public List<Taccount> getByAccountNm(String organizationNm) throws AIGCIExceptionMsg{
		
		List<Taccount> accountData = null;
			
		accountData = accountRepository.findByOrganizationNm(organizationNm.toUpperCase());
		
		return accountData;
	}
	
	public List<TshellAccount> getByShellAccountNm(String organizationNm) throws AIGCIExceptionMsg{
		
		List<TshellAccount> shellAccountData = null;
		
		shellAccountData = tShellAccountRepository.findByOrganizationNm(organizationNm.toUpperCase());
		
		return shellAccountData;
	}
	
	/**
	 * @author Dinesh Selvaraj
	 * @param productTowerID
	 * @return
	 * @throws AIGCIExceptionMsg
	 * This method is used to get auto close days no
	 */
	public List<TproductTowerAutoCloseRule> getAutoCloseDaysNo(short productTowerID) throws AIGCIExceptionMsg {
		List<TproductTowerAutoCloseRule> tProductTowerAutoCloseRuleData=null;
		
		tProductTowerAutoCloseRuleData=productTowerAutoCloseRuleRepository.findAutoCloseDaysNoByTowerID(productTowerID, NGEConstants.LifeCycleStatus.WORKING);
			 
		if (tProductTowerAutoCloseRuleData==null) 
		{
			ngeException.throwException(NGEErrorCodes.AUTO_CLOSE_DAYS_NO_NOT_FOUND, NGEErrorCodes.ERROR_TYPE, "AutoClose days no not found", null); //Unable to fetch auto close days no for given product tower id
		}
		
		return tProductTowerAutoCloseRuleData;
		
	}
	//Open Item -Get Alternate contact details logic change
	public TpartyAction getPartyActionRecord(TproductTower tproductTower, Trole role, TtransactionComponent transactionComponent) throws AIGCIExceptionMsg{
		
		List<TpartyAction> partyActionlist=null;
		TpartyAction partyAction=null;
		TpartyAction partyActionPriority=null;
		boolean flag1=false;
		boolean flag2=false;
		
		short productTowerId = tproductTower.getProductTowerId();
		short roleId = role.getRoleId();
		String sourceCode = NGEConstants.EMPTY_STRING;
		Tlocation locationRecord = null;
		int geoLocationId = 0;
		
		try{
			//Open Item -Get Alternate contact details logic change	
			String divisionNo = null;	
			
		      if(transactionComponent.getLegacyIn().equalsIgnoreCase(NGEConstants.YES))
		      {
		    	  	productTowerId=NGEConstants.ZERO_SHORT;
		    	  	
		    	  	if(transactionComponent.getTlegacyTrnsctnCmpntXtensn() != null){
		    	  		
		    	  		sourceCode = transactionComponent.getTlegacyTrnsctnCmpntXtensn().getSourceCd();
		    	  		
		    	  		if(!sourceCode.equalsIgnoreCase(NGEConstants.EMPTY_STRING)){
		    	  			
		    	  			locationRecord = locationDAO.findGeographicLocationIDByLocationTypeCdAndLcoationCd(sourceCode, NGEConstants.LocationType.LEGACY_SOURCE_CODE);
		    	  			
		    	  			if(locationRecord != null){
		    	  				
		    	  				geoLocationId = locationRecord.getGeographicLocationId();
		    	  			}
		    	  		}
		    	  	}
		    	  
		    	  if (transactionComponent.getTlegacyTrnsctnCmpntXtensn() != null && transactionComponent.getTlegacyTrnsctnCmpntXtensn().getProfitCenterCd() != null){
		    		  
		    		  divisionNo = transactionComponent.getTlegacyTrnsctnCmpntXtensn().getProfitCenterCd().trim();
		    	  }    	  
		    	  else if(transactionComponent.getTproductTowerDivision() != null && String.valueOf(transactionComponent.getTproductTowerDivision().getProductTowerDivisionId()) != null ){
		    		  
		    		  divisionNo = String.valueOf(transactionComponent.getTproductTowerDivision().getTdivision().getDivisionNo());
		    	  }
		      }
		      else
		      {
		    	  	//locationRecord = locationDAO.findGeographicLocationIDByLocationTypeCdAndLcoationCd(NGEConstants.Location.UNITED_STATES, NGEConstants.LocationType.COUNTRY);
		  			
		  			if(transactionComponent.getTtransactionVersion() != null && transactionComponent.getTtransactionVersion().getTtransaction() != null &&  transactionComponent.getTtransactionVersion().getTtransaction().getTbranch() != null && transactionComponent.getTtransactionVersion().getTtransaction().getTbranch().getTlocation() != null){
		  				
		  				
		  				geoLocationId = transactionComponent.getTtransactionVersion().getTtransaction().getTbranch().getTlocation().getGeographicLocationId();
		  			}
		  			
		    	  if(transactionComponent.getTproductTowerDivision() != null && String.valueOf(transactionComponent.getTproductTowerDivision().getProductTowerDivisionId()) != null )
		    		  
		    		  divisionNo = String.valueOf(transactionComponent.getTproductTowerDivision().getTdivision().getDivisionNo());
		      }		
			
			
			
			partyActionlist = tpartyActionRepository.fetchPartyId(productTowerId, roleId, geoLocationId);
			
			// Exception Suppressed to avoid breaking the flow
			/*if(partyActionlist.isEmpty()){
				ngeException.throwException( NGEErrorCodes.NO_ALTERNATE_CONTACT_UNDERWRITER_FOUND, NGEErrorCodes.ERROR_TYPE, null,null);
			}*/
			
			if(partyActionlist != null && !partyActionlist.isEmpty()){
				
				if(divisionNo != null){
					
					for(TpartyAction partyActioniter:partyActionlist)
					{
					String dataCategory=partyActioniter.getId().getDataCategoryNm().trim();
							
					if(dataCategory.equalsIgnoreCase(NGEConstants.DIV_+divisionNo))
						{		
							if(partyActioniter.getPriorityNo() == NGEConstants.ALTERNATE_CONTACT_PRIORITY){
							partyAction=partyActioniter;
								break;
						}
							/* To keep the legacy flow as it is -  Maintenance release 2.29 - Alternate contact Division change ends*/
						}					
					}
				}
				
				 if(transactionComponent.getLegacyIn().equalsIgnoreCase(NGEConstants.NO))
			      {
					 
					 if(partyAction == null)
						{
							for(TpartyAction partyActioniter:partyActionlist)
							{
								if(role.getRoleNm().equalsIgnoreCase(NGEConstants.ROLE.NGE_MANAGER)){
									
									if(partyActioniter.getId().getDataCategoryNm().equalsIgnoreCase(NGEConstants.MANAGER_FUNCTIONS) && partyActioniter.getPriorityNo() == NGEConstants.ALTERNATE_CONTACT_PRIORITY)
									{
										partyAction=partyActioniter;
										flag2=true;	
									}
									if(flag2){
										break;
									}								
								}
								else if(role.getRoleNm().equalsIgnoreCase(NGEConstants.ROLE.ALERT_BLOCK_RELEASER) && partyActioniter.getPriorityNo() == NGEConstants.ALTERNATE_CONTACT_PRIORITY ){
									
									if(partyActioniter.getId().getDataCategoryNm().equalsIgnoreCase(NGEConstants.ALL_DIVISIONS))
									{
										partyAction=partyActioniter;
										flag2=true;	
									}
									if(flag2){
										break;	
									}								
								}				
							}
						}
			      }			
			}
		}
		catch(Exception e){
			/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
			if(commonServiceHelper.checkForRetryExceptions(e, 2, NGEConstants.CatchExceptionTypes.NO_THROW))
			{
				logger.error("checkForRetryExceptions returned true");
			}
			/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
			// Exception Suppressed to avoid flow break
			logger.error("Exception Occurred during Alternate Contact details fetch " +e.getMessage());
		}
		
		return partyAction;
	}
	
	
	/**
	 * @author Nandhakumarm
	 * @param currencyId
	 * @return
	 */
	public Tcurrency getCurrencyByCurrencyId(short currencyId){
		Tcurrency tCurrency = new Tcurrency();
		tCurrency = currencyRepository.findOne(currencyId);
		return tCurrency;
	}

	public Tsystem findBySystemID(int systemID) throws AIGCIExceptionMsg {
		Tsystem systemData = null;

		List<Tsystem> systemRecord = new ArrayList<Tsystem>();

		systemRecord = systemRepository.findBySystemId(systemID);

		if (systemRecord.size() > 0) {
			systemData = systemRecord.get(0);
		} else {
			ngeException.throwException(NGEErrorCodes.SERVICE_INVOKER_MISSING,
					NGEErrorCodes.ERROR_TYPE, null, null);
		}

		return systemData;
	
	}

	public String getSourceCode(String transactionId, String defaultVal)
	{
		String sourceCd = tOfacAlertNotificationRepository.getSourceCdByTransactionNo(transactionId, defaultVal);		
		return sourceCd;
	}
	
	public TrelatedParty getUltimateDandB(int accountNo, String partyRelationType)
	{
		TrelatedParty relatedParty = tRelatedPartyRepository.getRelatedParty(accountNo, partyRelationType);
		return relatedParty;	
	}
	
	public TtransactionComponentBranch getWorkingBranch(String transCompId, String branchType)
	{
		TtransactionComponentBranch transactionComponentBranch = tTransactionComponentBranchRepository.getProductBranch(transCompId, branchType);		
		return transactionComponentBranch;
	}
	
	public Tsystem getSystemforLegacy(String systemName) throws AIGCIExceptionMsg,
			JpaSystemException {
		Tsystem systemData = null;
		
		List<Tsystem> systemRecord = new ArrayList<Tsystem>();
		
		systemRecord = systemRepository.findBySystemShortNm(systemName);
		
		if (systemRecord.size() > 0) {
			systemData = systemRecord.get(0);
		} else {
			//AIGCIException faultInfo = new AIGCIException();
			//ngeException.throwException("E999998","Logical", "", null);
			/*faultInfo.setErrorCode("S10005");
			faultInfo.setErrorMessage(">E10027       ANYOQ001S30000-SOFUndw System ID not found on Undw System Table");
			faultInfo.setErrorType("Error");
			throw new AIGCIExceptionMsg(faultInfo.getErrorMessage(), faultInfo);*/
				ngeException.throwLegacyException(systemName,"E10027","Logical", "", null);
		}
		
		return systemData;
	}
	
	
	
}
