package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SetAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-02-19T16:13:03.570+0530")
@StaticMetamodel(TmailingAddress.class)
public class TmailingAddress_ {
	public static volatile SingularAttribute<TmailingAddress, Integer> addressId;
	public static volatile SingularAttribute<TmailingAddress, String> address1Tx;
	public static volatile SingularAttribute<TmailingAddress, String> address2Tx;
	public static volatile SingularAttribute<TmailingAddress, String> address3Tx;
	public static volatile SingularAttribute<TmailingAddress, String> cityNm;
	public static volatile SingularAttribute<TmailingAddress, Timestamp> createTs;
	public static volatile SingularAttribute<TmailingAddress, String> createUserId;
	public static volatile SingularAttribute<TmailingAddress, String> postalCd;
	public static volatile SingularAttribute<TmailingAddress, String> stateCd;
	public static volatile SingularAttribute<TmailingAddress, Timestamp> updateTs;
	public static volatile SingularAttribute<TmailingAddress, String> updateUserId;
	public static volatile SingularAttribute<TmailingAddress, Tlocation> tlocation;
	public static volatile SetAttribute<TmailingAddress, Ttransaction> ttransactions;
}
