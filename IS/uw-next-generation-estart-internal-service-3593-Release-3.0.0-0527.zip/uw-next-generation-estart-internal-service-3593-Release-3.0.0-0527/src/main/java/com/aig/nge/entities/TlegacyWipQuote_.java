package com.aig.nge.entities;

import java.sql.Timestamp;
import java.util.Date;
import javax.annotation.Generated;
import javax.persistence.metamodel.SetAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-04-15T15:31:47.306+0530")
@StaticMetamodel(TlegacyWipQuote.class)
public class TlegacyWipQuote_ {
	public static volatile SingularAttribute<TlegacyWipQuote, TlegacyWipQuotePK> id;
	public static volatile SingularAttribute<TlegacyWipQuote, String> accountLegalNm;
	public static volatile SingularAttribute<TlegacyWipQuote, Integer> accountingPolNo;
	public static volatile SingularAttribute<TlegacyWipQuote, String> acctngPolPrfxCd;
	public static volatile SingularAttribute<TlegacyWipQuote, Timestamp> createTs;
	public static volatile SingularAttribute<TlegacyWipQuote, String> createUserId;
	public static volatile SingularAttribute<TlegacyWipQuote, String> lossrsnAdlcmtsTx;
	public static volatile SingularAttribute<TlegacyWipQuote, String> masterContractNo;
	public static volatile SingularAttribute<TlegacyWipQuote, String> nonRenewalIn;
	public static volatile SingularAttribute<TlegacyWipQuote, String> nonRenewalReasonCd;
	public static volatile SingularAttribute<TlegacyWipQuote, Short> polEventNo;
	public static volatile SingularAttribute<TlegacyWipQuote, Integer> policyId;
	public static volatile SingularAttribute<TlegacyWipQuote, Date> policyMailedDt;
	public static volatile SingularAttribute<TlegacyWipQuote, Integer> priorPolicyId;
	public static volatile SingularAttribute<TlegacyWipQuote, Short> profitUnitCd;
	public static volatile SingularAttribute<TlegacyWipQuote, String> quoteAcceptedIn;
	public static volatile SingularAttribute<TlegacyWipQuote, Date> quoteEfctvDt;
	public static volatile SingularAttribute<TlegacyWipQuote, Date> quoteXprtnDt;
	public static volatile SingularAttribute<TlegacyWipQuote, String> reasonCd;
	public static volatile SingularAttribute<TlegacyWipQuote, Short> sectionCd;
	public static volatile SingularAttribute<TlegacyWipQuote, Date> statusEnteredDt;
	public static volatile SingularAttribute<TlegacyWipQuote, Timestamp> updateTs;
	public static volatile SingularAttribute<TlegacyWipQuote, String> updateUserId;
	public static volatile SingularAttribute<TlegacyWipQuote, String> winningCarrierNm;
	public static volatile SingularAttribute<TlegacyWipQuote, String> wipStatusCd;
	public static volatile SingularAttribute<TlegacyWipQuote, TtransactionComponent> ttransactionComponent;
	public static volatile SetAttribute<TlegacyWipQuote, TlegacyWipQuoteCurrency> tlegacyWipQuoteCurrencies;
	public static volatile SingularAttribute<TlegacyWipQuote, String> businessTypeCd;
	public static volatile SingularAttribute<TlegacyWipQuote, Date> policyXprtnDt;
	//public static volatile SingularAttribute<TlegacyWipQuote, Tsystem> tsystem;
	public static volatile SingularAttribute<TlegacyWipQuote, Short> uwSystemID;
}
