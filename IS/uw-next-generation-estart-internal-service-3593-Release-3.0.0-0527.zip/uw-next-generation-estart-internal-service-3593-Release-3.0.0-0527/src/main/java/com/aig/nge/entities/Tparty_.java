package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SetAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-02-19T16:13:03.650+0530")
@StaticMetamodel(Tparty.class)
public class Tparty_ {
	public static volatile SingularAttribute<Tparty, Integer> partyId;
	public static volatile SingularAttribute<Tparty, Timestamp> createTs;
	public static volatile SingularAttribute<Tparty, String> createUserId;
	public static volatile SingularAttribute<Tparty, String> partyNo;
	public static volatile SingularAttribute<Tparty, Timestamp> updateTs;
	public static volatile SingularAttribute<Tparty, String> updateUserId;
	public static volatile SingularAttribute<Tparty, Taccount> taccount;
	public static volatile SingularAttribute<Tparty, Tagent> tagent;
	public static volatile SetAttribute<Tparty, Tblock> tblocks;
	public static volatile SetAttribute<Tparty, TofacAlertNotification> tofacAlertNotifications;
	public static volatile SingularAttribute<Tparty, TpartyType> tpartyType;
	public static volatile SetAttribute<Tparty, TpartyAction> tpartyActions;
	public static volatile SingularAttribute<Tparty, TpartyDetail> tpartyDetail;
	public static volatile SingularAttribute<Tparty, Tproducer> tproducer;
	public static volatile SetAttribute<Tparty, TproductTowerParty> tproductTowerParties;
	public static volatile SetAttribute<Tparty, TrelatedParty> trelatedParties1;
	public static volatile SetAttribute<Tparty, TrelatedParty> trelatedParties2;
	public static volatile SingularAttribute<Tparty, TshellAccount> tshellAccount;
	public static volatile SetAttribute<Tparty, Tsubmission> tsubmissions1;
	public static volatile SetAttribute<Tparty, Tsubmission> tsubmissions2;
	public static volatile SetAttribute<Tparty, Ttransaction> ttransactions1;
	public static volatile SetAttribute<Tparty, Ttransaction> ttransactions2;
	public static volatile SetAttribute<Tparty, Ttransaction> ttransactions3;
	public static volatile SetAttribute<Tparty, TtransactionComponent> ttransactionComponents;
	public static volatile SetAttribute<Tparty, TtransactionComponentParty> ttransactionComponentParties;
	public static volatile SetAttribute<Tparty, TtransactionParty> ttransactionParties;
	public static volatile SingularAttribute<Tparty, Tuser> tuser;
	public static volatile SetAttribute<Tparty, TuserPreferedProducer> tuserPreferedProducers;
	public static volatile SetAttribute<Tparty, TuserPreferredUnderwriter> tuserPreferredUnderwriter;
	public static volatile SingularAttribute<Tparty, TuserPrefernce> tuserPrefernce;
}
