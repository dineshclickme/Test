package com.aig.nge.entities;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-02-25T15:44:17.717+0530")
@StaticMetamodel(TproductTowerAttributeUsagePK.class)
public class TproductTowerAttributeUsagePK_ {
	public static volatile SingularAttribute<TproductTowerAttributeUsagePK, Short> productTowerId;
	public static volatile SingularAttribute<TproductTowerAttributeUsagePK, Short> tableId;
	public static volatile SingularAttribute<TproductTowerAttributeUsagePK, Short> attributeId;
	public static volatile SingularAttribute<TproductTowerAttributeUsagePK, Short> usageTypeId;
}
