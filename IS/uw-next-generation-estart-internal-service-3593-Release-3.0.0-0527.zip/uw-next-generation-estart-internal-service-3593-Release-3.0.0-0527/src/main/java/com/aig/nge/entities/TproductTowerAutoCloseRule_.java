package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-02-19T16:13:04.009+0530")
@StaticMetamodel(TproductTowerAutoCloseRule.class)
public class TproductTowerAutoCloseRule_ {
	public static volatile SingularAttribute<TproductTowerAutoCloseRule, Integer> autoCloseRuleId;
	public static volatile SingularAttribute<TproductTowerAutoCloseRule, Short> allowableExtensionsNo;
	public static volatile SingularAttribute<TproductTowerAutoCloseRule, Short> autoCloseDaysNo;
	public static volatile SingularAttribute<TproductTowerAutoCloseRule, Timestamp> createTs;
	public static volatile SingularAttribute<TproductTowerAutoCloseRule, String> createUserId;
	public static volatile SingularAttribute<TproductTowerAutoCloseRule, Short> daysPerExtensionNo;
	public static volatile SingularAttribute<TproductTowerAutoCloseRule, Timestamp> updateTs;
	public static volatile SingularAttribute<TproductTowerAutoCloseRule, String> updateUserId;
	public static volatile SingularAttribute<TproductTowerAutoCloseRule, TproductTower> tproductTower;
	public static volatile SingularAttribute<TproductTowerAutoCloseRule, Tstatus> tstatus1;
	public static volatile SingularAttribute<TproductTowerAutoCloseRule, Tstatus> tstatus2;
	public static volatile SingularAttribute<TproductTowerAutoCloseRule, Tstatus> tstatus3;
	public static volatile SingularAttribute<TproductTowerAutoCloseRule, Tstatus> tstatus4;
}
