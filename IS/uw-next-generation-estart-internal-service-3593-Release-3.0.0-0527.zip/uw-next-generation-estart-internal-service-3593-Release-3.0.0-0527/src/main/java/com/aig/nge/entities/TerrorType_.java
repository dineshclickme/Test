package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SetAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-06-19T14:59:45.658+0530")
@StaticMetamodel(TerrorType.class)
public class TerrorType_ {
	public static volatile SingularAttribute<TerrorType, String> errorTypeCd;
	public static volatile SingularAttribute<TerrorType, Timestamp> createTs;
	public static volatile SingularAttribute<TerrorType, String> createUserId;
	public static volatile SingularAttribute<TerrorType, String> errorTypeDs;
	public static volatile SingularAttribute<TerrorType, Timestamp> updateTs;
	public static volatile SingularAttribute<TerrorType, String> updateUserId;
	public static volatile SetAttribute<TerrorType, Terror> terrors;
	public static volatile SetAttribute<TerrorType, TlegacyError> tlegacyErrors;
}
