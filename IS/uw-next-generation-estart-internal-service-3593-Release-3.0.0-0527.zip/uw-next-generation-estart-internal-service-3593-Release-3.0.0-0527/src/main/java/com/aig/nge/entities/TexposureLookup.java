package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the TEXPOSURE_LOOKUP database table.
 * 
 */
@Entity
@Table(name="TEXPOSURE_LOOKUP")
public class TexposureLookup implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="EXPOSURE_LOOKUP_ID")
	private int exposureLookupId;

	@Column(name="COUNTRY_CD")
	private String countryCd;

	@Column(name="COUNTRY_LOCATION_ID")
	private int countryLocationId;

	@Column(name="CREATE_TS")
	private Timestamp createTs;

	@Column(name="CREATE_USER_ID")
	private String createUserId;

	@Column(name="GEO_CLUSTER_CD")
	private String geoClusterCd;

	@Column(name="GEO_CLUSTER_LOCATION_ID")
	private int geoClusterLocationId;

	@Column(name="REGION_CD")
	private String regionCd;

	@Column(name="REGION_LOCATION_ID")
	private int regionLocationId;

	@Column(name="SUB_REGION_CD")
	private String subRegionCd;

	@Column(name="SUB_REGION_LOCATION_ID")
	private int subRegionLocationId;

	@Column(name="UPDATE_TS")
	private Timestamp updateTs;

	@Column(name="UPDATE_USER_ID")
	private String updateUserId;

    public TexposureLookup() {
    }

	public int getExposureLookupId() {
		return this.exposureLookupId;
	}

	public void setExposureLookupId(int exposureLookupId) {
		this.exposureLookupId = exposureLookupId;
	}

	public String getCountryCd() {
		return this.countryCd;
	}

	public void setCountryCd(String countryCd) {
		this.countryCd = countryCd;
	}

	public int getCountryLocationId() {
		return this.countryLocationId;
	}

	public void setCountryLocationId(int countryLocationId) {
		this.countryLocationId = countryLocationId;
	}

	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public String getGeoClusterCd() {
		return this.geoClusterCd;
	}

	public void setGeoClusterCd(String geoClusterCd) {
		this.geoClusterCd = geoClusterCd;
	}

	public int getGeoClusterLocationId() {
		return this.geoClusterLocationId;
	}

	public void setGeoClusterLocationId(int geoClusterLocationId) {
		this.geoClusterLocationId = geoClusterLocationId;
	}

	public String getRegionCd() {
		return this.regionCd;
	}

	public void setRegionCd(String regionCd) {
		this.regionCd = regionCd;
	}

	public int getRegionLocationId() {
		return this.regionLocationId;
	}

	public void setRegionLocationId(int regionLocationId) {
		this.regionLocationId = regionLocationId;
	}

	public String getSubRegionCd() {
		return this.subRegionCd;
	}

	public void setSubRegionCd(String subRegionCd) {
		this.subRegionCd = subRegionCd;
	}

	public int getSubRegionLocationId() {
		return this.subRegionLocationId;
	}

	public void setSubRegionLocationId(int subRegionLocationId) {
		this.subRegionLocationId = subRegionLocationId;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

}