package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SetAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-02-19T16:13:03.947+0530")
@StaticMetamodel(TproductTower.class)
public class TproductTower_ {
	public static volatile SingularAttribute<TproductTower, Short> productTowerId;
	public static volatile SingularAttribute<TproductTower, Timestamp> createTs;
	public static volatile SingularAttribute<TproductTower, String> createUserId;
	public static volatile SingularAttribute<TproductTower, String> deletedIn;
	public static volatile SingularAttribute<TproductTower, String> productTowerNm;
	public static volatile SingularAttribute<TproductTower, Timestamp> updateTs;
	public static volatile SingularAttribute<TproductTower, String> updateUserId;
	public static volatile SetAttribute<TproductTower, TlegacyProductMapping> tlegacyProductMappings;
	public static volatile SetAttribute<TproductTower, TmarketableProduct> tmarketableProducts;
	public static volatile SetAttribute<TproductTower, TpartyAction> tpartyActions;
	public static volatile SingularAttribute<TproductTower, Tsegment> tsegment1;
	public static volatile SingularAttribute<TproductTower, Tsegment> tsegment2;
	public static volatile SetAttribute<TproductTower, TproductTowerAttribute> tproductTowerAttributes;
	public static volatile SetAttribute<TproductTower, TproductTowerAutoCloseRule> tproductTowerAutoCloseRules;
	public static volatile SetAttribute<TproductTower, TproductTowerDivision> tproductTowerDivisions;
	public static volatile SetAttribute<TproductTower, TproductTowerParty> tproductTowerParties;
	public static volatile SetAttribute<TproductTower, TproductTowerReason> tproductTowerReasons;
	public static volatile SetAttribute<TproductTower, TproductTowerTuwSubProduct> tproductTowerTuwSubProdcts;
	public static volatile SetAttribute<TproductTower, TtowerEvent> ttowerEvents;
	public static volatile SetAttribute<TproductTower, TproductTowerConfiguration> tproductTowerConfigurations;
}
