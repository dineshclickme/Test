package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-08-04T13:12:21.091+0530")
@StaticMetamodel(TbrickMetadata.class)
public class TbrickMetadata_ {
	public static volatile SingularAttribute<TbrickMetadata, Integer> brickMetadataId;
	public static volatile SingularAttribute<TbrickMetadata, String> brickMetadataKeyCd;
	public static volatile SingularAttribute<TbrickMetadata, String> brickMetadataOb;
	public static volatile SingularAttribute<TbrickMetadata, Timestamp> createTs;
	public static volatile SingularAttribute<TbrickMetadata, String> createUserId;
	public static volatile SingularAttribute<TbrickMetadata, Timestamp> updateTs;
	public static volatile SingularAttribute<TbrickMetadata, String> updateUserId;
}
