package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SetAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-02-19T16:13:03.705+0530")
@StaticMetamodel(TexcludeBlockType.class)
public class TexcludeBlockType_ {
	public static volatile SingularAttribute<TexcludeBlockType, String> excludeBlockTypeId;
	public static volatile SingularAttribute<TexcludeBlockType, String> blockTypeNm;
	public static volatile SingularAttribute<TexcludeBlockType, String> blockTypeDs;
	public static volatile SingularAttribute<TexcludeBlockType, Timestamp> createTs;
	public static volatile SingularAttribute<TexcludeBlockType, String> createUserId;
	public static volatile SingularAttribute<TexcludeBlockType, Timestamp> updateTs;
	public static volatile SingularAttribute<TexcludeBlockType, String> updateUserId;
}
