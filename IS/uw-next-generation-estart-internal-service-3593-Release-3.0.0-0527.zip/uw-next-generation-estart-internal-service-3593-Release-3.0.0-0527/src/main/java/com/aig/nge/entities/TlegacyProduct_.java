package com.aig.nge.entities;

import java.sql.Timestamp;
import java.util.Date;
import javax.annotation.Generated;
import javax.persistence.metamodel.SetAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-04-15T15:31:47.025+0530")
@StaticMetamodel(TlegacyProduct.class)
public class TlegacyProduct_ {
	public static volatile SingularAttribute<TlegacyProduct, String> productCd;
	public static volatile SingularAttribute<TlegacyProduct, String> blkMjprdGrpIn;
	public static volatile SingularAttribute<TlegacyProduct, String> bundleTypeCd;
	public static volatile SingularAttribute<TlegacyProduct, String> bypassBlockingIn;
	public static volatile SingularAttribute<TlegacyProduct, String> createdById;
	public static volatile SingularAttribute<TlegacyProduct, Date> enteredDt;
	public static volatile SingularAttribute<TlegacyProduct, Timestamp> lastUpdtTs;
	public static volatile SingularAttribute<TlegacyProduct, String> lastUpdtUserId;
	public static volatile SingularAttribute<TlegacyProduct, String> leadUmbrellaIn;
	public static volatile SingularAttribute<TlegacyProduct, String> lossControlIn;
	public static volatile SingularAttribute<TlegacyProduct, String> lst1OptnlReqdIn;
	public static volatile SingularAttribute<TlegacyProduct, String> only1OptlAlwdIn;
	public static volatile SingularAttribute<TlegacyProduct, String> prmryCovgAlwdIn;
	public static volatile SingularAttribute<TlegacyProduct, String> productDs;
	public static volatile SingularAttribute<TlegacyProduct, Date> productEfctvDt;
	public static volatile SingularAttribute<TlegacyProduct, String> productNm;
	public static volatile SingularAttribute<TlegacyProduct, String> productShortNm;
	public static volatile SingularAttribute<TlegacyProduct, Date> productXprtnDt;
	public static volatile SingularAttribute<TlegacyProduct, String> productionIn;
	public static volatile SingularAttribute<TlegacyProduct, String> rrProtectiveIn;
	public static volatile SingularAttribute<TlegacyProduct, String> specialEventIn;
	public static volatile SingularAttribute<TlegacyProduct, String> statutoryLimitIn;
	public static volatile SingularAttribute<TlegacyProduct, String> worldwideXpsrIn;
	public static volatile SingularAttribute<TlegacyProduct, String> xcesCovgAlwdIn;
	public static volatile SetAttribute<TlegacyProduct, TlegacyMinorProductBlock> tlegacyMinorProductBlocks;
	public static volatile SingularAttribute<TlegacyProduct, TlegacyMinorProductGroup> tlegacyMinorProductGroup;
	public static volatile SetAttribute<TlegacyProduct, TlegacyProductBundling> tlegacyProductBundlings1;
	public static volatile SetAttribute<TlegacyProduct, TlegacyProductBundling> tlegacyProductBundlings2;
	public static volatile SetAttribute<TlegacyProduct, TlegacyProductMapping> tlegacyProductMappings;
	public static volatile SetAttribute<TlegacyProduct, TlegacyProfitCenterProduct> tlegacyProfitCenterProducts;
	public static volatile SetAttribute<TlegacyProduct, TlegacyTransactionExtension> tlegacyTransactionExtensions;
	public static volatile SetAttribute<TlegacyProduct, TlegacyTrnsctnCmpntXtensn> tlegacyTrnsctnCmpntXtensns;
}
