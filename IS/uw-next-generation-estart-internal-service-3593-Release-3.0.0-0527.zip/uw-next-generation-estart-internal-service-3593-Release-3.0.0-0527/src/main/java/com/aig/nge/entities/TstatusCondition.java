package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Set;


/**
 * The persistent class for the TSTATUS_CONDITION database table.
 * 
 */
@Entity
@Table(name="TSTATUS_CONDITION")
public class TstatusCondition implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="STATUS_CONDITION_ID")
	private short statusConditionId;

	@Column(name="CREATE_TS")
	private Timestamp createTs;

	@Column(name="CREATE_USER_ID")
	private String createUserId;

	@Column(name="UPDATE_TS")
	private Timestamp updateTs;

	@Column(name="UPDATE_USER_ID")
	private String updateUserId;

	//bi-directional many-to-one association to Tstatus
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="LIFE_CYCLE_STATUS_ID")
	private Tstatus tstatus1;

	//bi-directional many-to-one association to Tstatus
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="RESERVATION_STATUS_ID")
	private Tstatus tstatus2;

	//bi-directional many-to-one association to TstatusTransition
	@OneToMany(mappedBy="tstatusCondition", cascade={CascadeType.ALL})
	private Set<TstatusTransition> tstatusTransitions;

    public TstatusCondition() {
    }

	public short getStatusConditionId() {
		return this.statusConditionId;
	}

	public void setStatusConditionId(short statusConditionId) {
		this.statusConditionId = statusConditionId;
	}

	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public Tstatus getTstatus1() {
		return this.tstatus1;
	}

	public void setTstatus1(Tstatus tstatus1) {
		this.tstatus1 = tstatus1;
	}
	
	public Tstatus getTstatus2() {
		return this.tstatus2;
	}

	public void setTstatus2(Tstatus tstatus2) {
		this.tstatus2 = tstatus2;
	}
	
	public Set<TstatusTransition> getTstatusTransitions() {
		return this.tstatusTransitions;
	}

	public void setTstatusTransitions(Set<TstatusTransition> tstatusTransitions) {
		this.tstatusTransitions = tstatusTransitions;
	}
	
}