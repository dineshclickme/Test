package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SetAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-02-19T16:13:04.296+0530")
@StaticMetamodel(Treason.class)
public class Treason_ {
	public static volatile SingularAttribute<Treason, Short> reasonId;
	public static volatile SingularAttribute<Treason, Timestamp> createTs;
	public static volatile SingularAttribute<Treason, String> createUserId;
	public static volatile SingularAttribute<Treason, String> deletedIn;
	public static volatile SingularAttribute<Treason, String> reasonDs;
	public static volatile SingularAttribute<Treason, String> reasonNm;
	public static volatile SingularAttribute<Treason, Timestamp> updateTs;
	public static volatile SingularAttribute<Treason, String> updateUserId;
	public static volatile SetAttribute<Treason, Tblock> tblocks;
	public static volatile SetAttribute<Treason, TproductTowerReason> tproductTowerReasons;
	public static volatile SingularAttribute<Treason, TreasonType> treasonType;
	public static volatile SetAttribute<Treason, TtransactionComponentStatus> ttransactionComponentStatuses;
}
