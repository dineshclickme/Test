package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the TLEGACY_INTERFACE_ERROR database table.
 * 
 */
@Entity
@Table(name="TLEGACY_INTERFACE_ERROR")
public class TlegacyInterfaceError implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="RECORD_ID")
	private int recordId;

	@Column(name="ASSUMED_BUS_IN")
	private String assumedBusIn;

	@Column(name="ATCHMT_POINT_AM")
	private BigDecimal atchmtPointAm;

	@Column(name="BUNDLE_TYPE_CD")
	private String bundleTypeCd;

	@Column(name="BUSINESS_TYPE_CD")
	private String businessTypeCd;

	@Column(name="CANCEL_REASON_CD")
	private String cancelReasonCd;

	@Column(name="CREATE_TS")
	private Timestamp createTs;

	@Column(name="CREATE_USER_ID")
	private String createUserId;

	@Column(name="CREDITED_BRANCH_CD")
	private String creditedBranchCd;

	@Column(name="DISPLAY_CRNCY_CD")
	private String displayCrncyCd;

	@Column(name="DUN_BRAD_NO")
	private int dunBradNo;

	@Column(name="INPUT_ERROR_MSG_TX")
	private String inputErrorMsgTx;

	@Column(name="ISSUING_COMPANY_NO")
	private int issuingCompanyNo;

	@Column(name="LIMIT_AM")
	private BigDecimal limitAm;

	@Column(name="NON_RENEWAL_IN")
	private String nonRenewalIn;

	@Column(name="NON_RENEWAL_REASON_CD")
	private String nonRenewalReasonCd;

	@Column(name="PART_OF_AM")
	private BigDecimal partOfAm;

    @Temporal( TemporalType.DATE)
	@Column(name="POLICY_EFFECTIVE_DT")
	private Date policyEffectiveDt;

	@Column(name="POLICY_EVENT_NO")
	private short policyEventNo;

    @Temporal( TemporalType.DATE)
	@Column(name="POLICY_EXPIRATION_DT")
	private Date policyExpirationDt;

    @Temporal( TemporalType.DATE)
	@Column(name="POLICY_MAILED_DT")
	private Date policyMailedDt;

	@Column(name="POLICY_NO")
	private String policyNo;

	@Column(name="POLICY_STATUS_CD")
	private String policyStatusCd;

	@Column(name="PREMIUM_AM")
	private BigDecimal premiumAm;

	@Column(name="PRIOR_CARRIER_CD")
	private String priorCarrierCd;

	@Column(name="PRIOR_ISSUING_COMPANY_NO")
	private int priorIssuingCompanyNo;

    @Temporal( TemporalType.DATE)
	@Column(name="PRIOR_POLICY_EFFECTIVE_DT")
	private Date priorPolicyEffectiveDt;

	@Column(name="PRIOR_POLICY_EVENT_NO")
	private short priorPolicyEventNo;

	@Column(name="PRIOR_POLICY_NO")
	private String priorPolicyNo;

	@Column(name="PROCESS_STATUS_CD")
	private String processStatusCd;

	@Column(name="PROCESSED_CT")
	private short processedCt;

	@Column(name="PRODCT_COVG_TYPE_CD")
	private String prodctCovgTypeCd;

	@Column(name="PRODUCER_NO")
	private String producerNo;

	@Column(name="PRODUCT_CD")
	private String productCd;

	@Column(name="PROFIT_CENTER_CD")
	private String profitCenterCd;

	@Column(name="PROFIT_UNIT_CD")
	private short profitUnitCd;

	@Column(name="PROFORMA_CREDIT_CD")
	private String proformaCreditCd;

    @Temporal( TemporalType.DATE)
	@Column(name="SBMN_RECEIVED_DT")
	private Date sbmnReceivedDt;

	@Column(name="SECTION_CD")
	private short sectionCd;

	@Column(name="SOURCE_CD")
	private String sourceCd;

	@Column(name="SUBMISSION_NO")
	private int submissionNo;

	@Column(name="TRANSACTION_TS")
	private Timestamp transactionTs;

	@Column(name="TRANSACTION_TYPE_TX")
	private String transactionTypeTx;

	@Column(name="TRAP_ERROR_MSG_TX")
	private String trapErrorMsgTx;

	@Column(name="UNDERWRITER_ID")
	private String underwriterId;

	@Column(name="UPDATE_TS")
	private Timestamp updateTs;

	@Column(name="UPDATE_USER_ID")
	private String updateUserId;

	@Column(name="UW_SYSTEM_ID")
	private String uwSystemId;

	@Column(name="WIP_ID")
	private String wipId;

	@Column(name="WORKING_BRANCH_CD")
	private String workingBranchCd;

    public TlegacyInterfaceError() {
    }

	public int getRecordId() {
		return this.recordId;
	}

	public void setRecordId(int recordId) {
		this.recordId = recordId;
	}

	public String getAssumedBusIn() {
		return this.assumedBusIn;
	}

	public void setAssumedBusIn(String assumedBusIn) {
		this.assumedBusIn = assumedBusIn;
	}

	public BigDecimal getAtchmtPointAm() {
		return this.atchmtPointAm;
	}

	public void setAtchmtPointAm(BigDecimal atchmtPointAm) {
		this.atchmtPointAm = atchmtPointAm;
	}

	public String getBundleTypeCd() {
		return this.bundleTypeCd;
	}

	public void setBundleTypeCd(String bundleTypeCd) {
		this.bundleTypeCd = bundleTypeCd;
	}

	public String getBusinessTypeCd() {
		return this.businessTypeCd;
	}

	public void setBusinessTypeCd(String businessTypeCd) {
		this.businessTypeCd = businessTypeCd;
	}

	public String getCancelReasonCd() {
		return this.cancelReasonCd;
	}

	public void setCancelReasonCd(String cancelReasonCd) {
		this.cancelReasonCd = cancelReasonCd;
	}

	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public String getCreditedBranchCd() {
		return this.creditedBranchCd;
	}

	public void setCreditedBranchCd(String creditedBranchCd) {
		this.creditedBranchCd = creditedBranchCd;
	}

	public String getDisplayCrncyCd() {
		return this.displayCrncyCd;
	}

	public void setDisplayCrncyCd(String displayCrncyCd) {
		this.displayCrncyCd = displayCrncyCd;
	}

	public int getDunBradNo() {
		return this.dunBradNo;
	}

	public void setDunBradNo(int dunBradNo) {
		this.dunBradNo = dunBradNo;
	}

	public String getInputErrorMsgTx() {
		return this.inputErrorMsgTx;
	}

	public void setInputErrorMsgTx(String inputErrorMsgTx) {
		this.inputErrorMsgTx = inputErrorMsgTx;
	}

	public int getIssuingCompanyNo() {
		return this.issuingCompanyNo;
	}

	public void setIssuingCompanyNo(int issuingCompanyNo) {
		this.issuingCompanyNo = issuingCompanyNo;
	}

	public BigDecimal getLimitAm() {
		return this.limitAm;
	}

	public void setLimitAm(BigDecimal limitAm) {
		this.limitAm = limitAm;
	}

	public String getNonRenewalIn() {
		return this.nonRenewalIn;
	}

	public void setNonRenewalIn(String nonRenewalIn) {
		this.nonRenewalIn = nonRenewalIn;
	}

	public String getNonRenewalReasonCd() {
		return this.nonRenewalReasonCd;
	}

	public void setNonRenewalReasonCd(String nonRenewalReasonCd) {
		this.nonRenewalReasonCd = nonRenewalReasonCd;
	}

	public BigDecimal getPartOfAm() {
		return this.partOfAm;
	}

	public void setPartOfAm(BigDecimal partOfAm) {
		this.partOfAm = partOfAm;
	}

	public Date getPolicyEffectiveDt() {
		return this.policyEffectiveDt;
	}

	public void setPolicyEffectiveDt(Date policyEffectiveDt) {
		this.policyEffectiveDt = policyEffectiveDt;
	}

	public short getPolicyEventNo() {
		return this.policyEventNo;
	}

	public void setPolicyEventNo(short policyEventNo) {
		this.policyEventNo = policyEventNo;
	}

	public Date getPolicyExpirationDt() {
		return this.policyExpirationDt;
	}

	public void setPolicyExpirationDt(Date policyExpirationDt) {
		this.policyExpirationDt = policyExpirationDt;
	}

	public Date getPolicyMailedDt() {
		return this.policyMailedDt;
	}

	public void setPolicyMailedDt(Date policyMailedDt) {
		this.policyMailedDt = policyMailedDt;
	}

	public String getPolicyNo() {
		return this.policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public String getPolicyStatusCd() {
		return this.policyStatusCd;
	}

	public void setPolicyStatusCd(String policyStatusCd) {
		this.policyStatusCd = policyStatusCd;
	}

	public BigDecimal getPremiumAm() {
		return this.premiumAm;
	}

	public void setPremiumAm(BigDecimal premiumAm) {
		this.premiumAm = premiumAm;
	}

	public String getPriorCarrierCd() {
		return this.priorCarrierCd;
	}

	public void setPriorCarrierCd(String priorCarrierCd) {
		this.priorCarrierCd = priorCarrierCd;
	}

	public int getPriorIssuingCompanyNo() {
		return this.priorIssuingCompanyNo;
	}

	public void setPriorIssuingCompanyNo(int priorIssuingCompanyNo) {
		this.priorIssuingCompanyNo = priorIssuingCompanyNo;
	}

	public Date getPriorPolicyEffectiveDt() {
		return this.priorPolicyEffectiveDt;
	}

	public void setPriorPolicyEffectiveDt(Date priorPolicyEffectiveDt) {
		this.priorPolicyEffectiveDt = priorPolicyEffectiveDt;
	}

	public short getPriorPolicyEventNo() {
		return this.priorPolicyEventNo;
	}

	public void setPriorPolicyEventNo(short priorPolicyEventNo) {
		this.priorPolicyEventNo = priorPolicyEventNo;
	}

	public String getPriorPolicyNo() {
		return this.priorPolicyNo;
	}

	public void setPriorPolicyNo(String priorPolicyNo) {
		this.priorPolicyNo = priorPolicyNo;
	}

	public String getProcessStatusCd() {
		return this.processStatusCd;
	}

	public void setProcessStatusCd(String processStatusCd) {
		this.processStatusCd = processStatusCd;
	}

	public short getProcessedCt() {
		return this.processedCt;
	}

	public void setProcessedCt(short processedCt) {
		this.processedCt = processedCt;
	}

	public String getProdctCovgTypeCd() {
		return this.prodctCovgTypeCd;
	}

	public void setProdctCovgTypeCd(String prodctCovgTypeCd) {
		this.prodctCovgTypeCd = prodctCovgTypeCd;
	}

	public String getProducerNo() {
		return this.producerNo;
	}

	public void setProducerNo(String producerNo) {
		this.producerNo = producerNo;
	}

	public String getProductCd() {
		return this.productCd;
	}

	public void setProductCd(String productCd) {
		this.productCd = productCd;
	}

	public String getProfitCenterCd() {
		return this.profitCenterCd;
	}

	public void setProfitCenterCd(String profitCenterCd) {
		this.profitCenterCd = profitCenterCd;
	}

	public short getProfitUnitCd() {
		return this.profitUnitCd;
	}

	public void setProfitUnitCd(short profitUnitCd) {
		this.profitUnitCd = profitUnitCd;
	}

	public String getProformaCreditCd() {
		return this.proformaCreditCd;
	}

	public void setProformaCreditCd(String proformaCreditCd) {
		this.proformaCreditCd = proformaCreditCd;
	}

	public Date getSbmnReceivedDt() {
		return this.sbmnReceivedDt;
	}

	public void setSbmnReceivedDt(Date sbmnReceivedDt) {
		this.sbmnReceivedDt = sbmnReceivedDt;
	}

	public short getSectionCd() {
		return this.sectionCd;
	}

	public void setSectionCd(short sectionCd) {
		this.sectionCd = sectionCd;
	}

	public String getSourceCd() {
		return this.sourceCd;
	}

	public void setSourceCd(String sourceCd) {
		this.sourceCd = sourceCd;
	}

	public int getSubmissionNo() {
		return this.submissionNo;
	}

	public void setSubmissionNo(int submissionNo) {
		this.submissionNo = submissionNo;
	}

	public Timestamp getTransactionTs() {
		return this.transactionTs;
	}

	public void setTransactionTs(Timestamp transactionTs) {
		this.transactionTs = transactionTs;
	}

	public String getTransactionTypeTx() {
		return this.transactionTypeTx;
	}

	public void setTransactionTypeTx(String transactionTypeTx) {
		this.transactionTypeTx = transactionTypeTx;
	}

	public String getTrapErrorMsgTx() {
		return this.trapErrorMsgTx;
	}

	public void setTrapErrorMsgTx(String trapErrorMsgTx) {
		this.trapErrorMsgTx = trapErrorMsgTx;
	}

	public String getUnderwriterId() {
		return this.underwriterId;
	}

	public void setUnderwriterId(String underwriterId) {
		this.underwriterId = underwriterId;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public String getUwSystemId() {
		return this.uwSystemId;
	}

	public void setUwSystemId(String uwSystemId) {
		this.uwSystemId = uwSystemId;
	}

	public String getWipId() {
		return this.wipId;
	}

	public void setWipId(String wipId) {
		this.wipId = wipId;
	}

	public String getWorkingBranchCd() {
		return this.workingBranchCd;
	}

	public void setWorkingBranchCd(String workingBranchCd) {
		this.workingBranchCd = workingBranchCd;
	}

}