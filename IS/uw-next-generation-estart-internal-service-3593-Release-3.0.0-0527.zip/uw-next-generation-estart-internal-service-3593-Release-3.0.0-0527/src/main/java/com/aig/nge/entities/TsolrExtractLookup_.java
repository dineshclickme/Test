package com.aig.nge.entities;

import java.sql.Timestamp;
import java.util.Date;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-09-11T14:03:54.072+0530")
@StaticMetamodel(TsolrExtractLookup.class)
public class TsolrExtractLookup_ {
	public static volatile SingularAttribute<TsolrExtractLookup, Short> solrExtractId;
	public static volatile SingularAttribute<TsolrExtractLookup, String> accountCd;
	public static volatile SingularAttribute<TsolrExtractLookup, String> accountNm;
	public static volatile SingularAttribute<TsolrExtractLookup, String> componentProductCd;
	public static volatile SingularAttribute<TsolrExtractLookup, String> componentProductDeletedIn;
	public static volatile SingularAttribute<TsolrExtractLookup, String> componentProductNm;
	public static volatile SingularAttribute<TsolrExtractLookup, Timestamp> createTs;
	public static volatile SingularAttribute<TsolrExtractLookup, String> createUserId;
	public static volatile SingularAttribute<TsolrExtractLookup, String> creditedBranchCntryNm;
	public static volatile SingularAttribute<TsolrExtractLookup, String> creditedBranchNm;
	public static volatile SingularAttribute<TsolrExtractLookup, String> divisionNm;
	public static volatile SingularAttribute<TsolrExtractLookup, Short> divisionNo;
	public static volatile SingularAttribute<TsolrExtractLookup, String> marketableProductCd;
	public static volatile SingularAttribute<TsolrExtractLookup, String> marketableProductNm;
	public static volatile SingularAttribute<TsolrExtractLookup, String> productStatusDs;
	public static volatile SingularAttribute<TsolrExtractLookup, Date> productStatusDt;
	public static volatile SingularAttribute<TsolrExtractLookup, Short> productTowerDivisionId;
	public static volatile SingularAttribute<TsolrExtractLookup, String> reservationStatusDs;
	public static volatile SingularAttribute<TsolrExtractLookup, String> segmentNm;
	public static volatile SingularAttribute<TsolrExtractLookup, String> subSegmentNm;
	public static volatile SingularAttribute<TsolrExtractLookup, Date> submissionCreatedDt;
	public static volatile SingularAttribute<TsolrExtractLookup, Integer> underwriterId;
	public static volatile SingularAttribute<TsolrExtractLookup, String> underwriterNm;
	public static volatile SingularAttribute<TsolrExtractLookup, Timestamp> updateTs;
	public static volatile SingularAttribute<TsolrExtractLookup, String> updateUserId;
	public static volatile SingularAttribute<TsolrExtractLookup, Short> versionSqn;
}
