package com.aig.nge.entities;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.apache.openjpa.persistence.DataCache;


/**
 * The persistent class for the TMLOB_EXCLUDE_BLOCK_BY_TYPE database table.
 * 
 */
@Entity
@DataCache
@Table(name="TMLOB_EXCLUDE_BLOCK_BY_TYPE")
public class TmlobExcludeBlockByType implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="MLOB_EXCLUDE_BLOCK_BY_TYPE_ID")
	private int mlobExcludeBlockByTypeId;
	
	@Column(name="PRODUCT_TOWER_ID")
	private String productTowerId;
	
	@Column(name="GEOGRAPHIC_LOCATION_ID")
	private String locationId;
	
	@Column(name="DIVISION_NO")
	private String divisionNo;
	
	@Column(name="MASTER_LOB_CD")
	private String masterLobCd;
	
	@Column(name="COVERAGE_LINE_CD")
	private String coverageLineCd; 
	
	
	@Column(name="CREATE_TS")
	private Timestamp createTs;

	@Column(name="CREATE_USER_ID")
	private String createUserId;

	@Column(name="UPDATE_TS")
	private Timestamp updateTs;

	@Column(name="UPDATE_USER_ID")
	private String updateUserId;

	//bi-directional one-to-one association to Taccount
	
	//bi-directional many-to-one association to TpartyType
    @ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="EXCLUDE_BLOCK_TYPE_ID")
	private TexcludeBlockType excludeBlockType;


	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}


	public String getProductTowerId() {
		return productTowerId;
	}

	public void setProductTowerId(String productTowerId) {
		this.productTowerId = productTowerId;
	}

	public String getLocationId() {
		return locationId;
	}

	public void setLocationId(String locationId) {
		this.locationId = locationId;
	}

	public String getMasterLobCd() {
		return masterLobCd;
	}

	public void setMasterLobCd(String masterLobCd) {
		this.masterLobCd = masterLobCd;
	}

	public String getCoverageLineCd() {
		return coverageLineCd;
	}

	public void setCoverageLineCd(String coverageLineCd) {
		this.coverageLineCd = coverageLineCd;
	}

	public int getMlobExcludeBlockByTypeId() {
		return mlobExcludeBlockByTypeId;
	}

	public void setMlobExcludeBlockByTypeId(int mlobExcludeBlockByTypeId) {
		this.mlobExcludeBlockByTypeId = mlobExcludeBlockByTypeId;
	}

	public String getDivisionNo() {
		return divisionNo;
	}

	public void setDivisionNo(String divisionNo) {
		this.divisionNo = divisionNo;
	}

	public TexcludeBlockType getExcludeBlockType() {
		return excludeBlockType;
	}

	public void setExcludeBlockType(TexcludeBlockType excludeBlockType) {
		this.excludeBlockType = excludeBlockType;
	}

}