package com.aig.nge.entities;

import javax.persistence.Entity;
import javax.persistence.EntityResult;
import javax.persistence.FieldResult;
import javax.persistence.Id;
import javax.persistence.NamedNativeQuery;
import javax.persistence.SqlResultSetMapping;

/**
 * @author AIGAdmin
 * 2020 SCUP Release - MLOB change - US159484
 */
@Entity
@SqlResultSetMapping(name = "TransactionDetailsByProductMapping", 
	entities = {
			@EntityResult(entityClass = TransactionDetailsByProductBO.class, fields = {
				@FieldResult(name = "transactionComponentId", column = "TRANSACTION_COMPONENT_ID"),
				@FieldResult(name = "divisionNo", column = "DIVISION_NO"),
				@FieldResult(name = "geoLocationId", column = "GEOGRAPHIC_LOCATION_ID"),
				@FieldResult(name = "productTowerId", column = "PRODUCT_TOWER_ID"),
				@FieldResult(name = "masterLOBCd", column = "MASTER_LOB_CD"),
				@FieldResult(name = "coverageLineCd", column = "COVERAGE_LINE_CD")
				})})

@NamedNativeQuery(name="TransactionDetailsByProductBO.fetchTransactionDetailsByProduct",
		query="SELECT  TC.TRANSACTION_COMPONENT_ID,PTD.DIVISION_NO , L.GEOGRAPHIC_LOCATION_ID, PT.PRODUCT_TOWER_ID , TC.MASTER_LOB_CD,TC.COVERAGE_LINE_CD FROM TTRANSACTION_COMPONENT TC "+
				"INNER JOIN TTRANSACTION T ON T.TRANSACTION_ID =TC.TRANSACTION_ID AND TC.DELETED_IN = ?1 AND TC.TRANSACTION_COMPONENT_ID = ?2"+
				"INNER JOIN TBRANCH B ON B.BRANCH_ID =T.CREDITED_BRANCH_ID "+
				"INNER JOIN TLOCATION L ON L.GEOGRAPHIC_LOCATION_ID =B.GEOGRAPHIC_LOCATION_ID "+
				"INNER JOIN TCOMPONENT_PRODUCT_LOOKUP TCL ON TCL.COMPONENT_PRODUCT_ID = TC.COMPONENT_PRODUCT_ID AND TCL.PRODUCT_DETAIL_ID = TC.PRODUCT_DETAIL_ID "+
				"INNER JOIN TPRODUCT_TOWER PT ON PT.SEGMENT_CD =TCL.COMPONENT_SEGMENT_CD AND PT.SUB_SEGMENT_CD =TCL.COMPONENT_SUB_SEGMENT_CD "+
				"LEFT JOIN TPRODUCT_TOWER_DIVISION PTD ON PTD.PRODUCT_TOWER_DIVISION_ID =TC.PRODUCT_TOWER_DIVISION_ID ",
				
				resultSetMapping="TransactionDetailsByProductMapping")

public class TransactionDetailsByProductBO {
	
	@Id
	private Long transactionComponentId;
	
	private Integer divisionNo;
	
	private int geoLocationId;
	
	private int productTowerId;
	
	private String masterLOBCd;
	
	private String coverageLineCd;

	public Long getTransactionComponentId() {
		return transactionComponentId;
	}

	public void setTransactionComponentId(Long transactionComponentId) {
		this.transactionComponentId = transactionComponentId;
	}

	public Integer getDivisionNo() {
		return divisionNo;
	}

	public void setDivisionNo(Integer divisionNo) {
		this.divisionNo = divisionNo;
	}

	public int getGeoLocationId() {
		return geoLocationId;
	}

	public void setGeoLocationId(int geoLocationId) {
		this.geoLocationId = geoLocationId;
	}

	public int getProductTowerId() {
		return productTowerId;
	}

	public void setProductTowerId(int productTowerId) {
		this.productTowerId = productTowerId;
	}

	public String getMasterLOBCd() {
		return masterLOBCd;
	}

	public void setMasterLOBCd(String masterLOBCd) {
		this.masterLOBCd = masterLOBCd;
	}

	public String getCoverageLineCd() {
		return coverageLineCd;
	}

	public void setCoverageLineCd(String coverageLineCd) {
		this.coverageLineCd = coverageLineCd;
	}
	
	

}