package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SetAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-02-19T16:13:04.304+0530")
@StaticMetamodel(TreasonType.class)
public class TreasonType_ {
	public static volatile SingularAttribute<TreasonType, Short> reasonTypeId;
	public static volatile SingularAttribute<TreasonType, Timestamp> createTs;
	public static volatile SingularAttribute<TreasonType, String> createUserId;
	public static volatile SingularAttribute<TreasonType, String> reasonTypeNm;
	public static volatile SingularAttribute<TreasonType, Timestamp> updateTs;
	public static volatile SingularAttribute<TreasonType, String> updateUserId;
	public static volatile SetAttribute<TreasonType, Treason> treasons;
	public static volatile SetAttribute<TreasonType, TstatusReasonType> tstatusReasonTypes;
	public static volatile SetAttribute<TreasonType, TstatusTransition> tstatusTransitions;
}
