package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Set;


/**
 * The persistent class for the TACTION database table.
 * 
 */
@Entity
public class Taction implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="ACTION_ID")
	private short actionId;

	@Column(name="ACTION_DS")
	private String actionDs;

	@Column(name="CREATE_TS")
	private Timestamp createTs;

	@Column(name="CREATE_USER_ID")
	private String createUserId;

	@Column(name="UPDATE_TS")
	private Timestamp updateTs;

	@Column(name="UPDATE_USER_ID")
	private String updateUserId;

	//bi-directional many-to-one association to TpartyAction
	@OneToMany(mappedBy="taction", cascade={CascadeType.ALL})
	private Set<TpartyAction> tpartyActions;

    public Taction() {
    }

	public short getActionId() {
		return this.actionId;
	}

	public void setActionId(short actionId) {
		this.actionId = actionId;
	}

	public String getActionDs() {
		return this.actionDs;
	}

	public void setActionDs(String actionDs) {
		this.actionDs = actionDs;
	}

	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public Set<TpartyAction> getTpartyActions() {
		return this.tpartyActions;
	}

	public void setTpartyActions(Set<TpartyAction> tpartyActions) {
		this.tpartyActions = tpartyActions;
	}
	
}