package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Set;


/**
 * The persistent class for the TPROFORMA database table.
 * 
 */
@Entity
public class Tproforma implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="PROFORMA_CREDIT_CD")
	private String proformaCreditCd;

	@Column(name="CREATE_TS")
	private Timestamp createTs;

	@Column(name="CREATE_USER_ID")
	private String createUserId;

	@Column(name="PROFORMA_CREDIT_DS")
	private String proformaCreditDs;

	@Column(name="UPDATE_TS")
	private Timestamp updateTs;

	@Column(name="UPDATE_USER_ID")
	private String updateUserId;

	//bi-directional many-to-one association to TlegacySubmissionExtension
	@OneToMany(mappedBy="tproforma")
	private Set<TlegacySubmissionExtension> tlegacySubmissionExtensions;

    public Tproforma() {
    }

	public String getProformaCreditCd() {
		if(this.proformaCreditCd != null)
			return this.proformaCreditCd.trim();
		else
			return this.proformaCreditCd;
	}

	public void setProformaCreditCd(String proformaCreditCd) {
		this.proformaCreditCd = proformaCreditCd;
	}

	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public String getProformaCreditDs() {
		if(this.proformaCreditDs != null )
			return this.proformaCreditDs.trim();
		else
			return this.proformaCreditDs;
	}

	public void setProformaCreditDs(String proformaCreditDs) {
		this.proformaCreditDs = proformaCreditDs;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public Set<TlegacySubmissionExtension> getTlegacySubmissionExtensions() {
		return this.tlegacySubmissionExtensions;
	}

	public void setTlegacySubmissionExtensions(Set<TlegacySubmissionExtension> tlegacySubmissionExtensions) {
		this.tlegacySubmissionExtensions = tlegacySubmissionExtensions;
	}
	
}