package com.aig.nge.entities;

import java.sql.Timestamp;
import java.util.Date;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-04-15T15:31:46.947+0530")
@StaticMetamodel(TlegacyMinorProductBlock.class)
public class TlegacyMinorProductBlock_ {
	public static volatile SingularAttribute<TlegacyMinorProductBlock, TlegacyMinorProductBlockPK> id;
	public static volatile SingularAttribute<TlegacyMinorProductBlock, String> createdById;
	public static volatile SingularAttribute<TlegacyMinorProductBlock, Date> enteredDt;
	public static volatile SingularAttribute<TlegacyMinorProductBlock, Timestamp> lastUpdtTs;
	public static volatile SingularAttribute<TlegacyMinorProductBlock, String> lastUpdtUserId;
	public static volatile SingularAttribute<TlegacyMinorProductBlock, Date> mnprdBlkEfctvDt;
	public static volatile SingularAttribute<TlegacyMinorProductBlock, Date> mnprdBlkXprtnDt;
	public static volatile SingularAttribute<TlegacyMinorProductBlock, TlegacyProduct> tlegacyProduct;
}
