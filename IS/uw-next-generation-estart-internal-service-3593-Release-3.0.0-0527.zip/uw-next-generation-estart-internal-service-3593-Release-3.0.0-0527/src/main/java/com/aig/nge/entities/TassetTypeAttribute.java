package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;

import java.sql.Timestamp;


/**
 * The persistent class for the TASSET_TYPE_ATTRIBUTE database table.
 * 
 */
@Entity
@Table(name="TASSET_TYPE_ATTRIBUTE")
public class TassetTypeAttribute implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private TassetTypeAttributePK id;

	@Column(name="ATTRIBUTE_VAL")
	private String attributeVal;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="CREATE_TS")
	private Timestamp createTs;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="CREATE_USER_ID")
	private String createUserId;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="UPDATE_TS")
	private Timestamp updateTs;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="UPDATE_USER_ID")
	private String updateUserId;

	//bi-directional many-to-one association to TassetType
	@ManyToOne
	@JoinColumn(name="ASSET_TYPE_ID")
	private TassetType tassetType;

	//bi-directional many-to-one association to Tattribute
	@ManyToOne
	@JoinColumn(name="ATTRIBUTE_ID")
	private Tattribute tattribute;

    public TassetTypeAttribute() {
    }

	public TassetTypeAttributePK getId() {
		return this.id;
	}

	public void setId(TassetTypeAttributePK id) {
		this.id = id;
	}
	
	public String getAttributeVal() {
		return this.attributeVal;
	}

	public void setAttributeVal(String attributeVal) {
		this.attributeVal = attributeVal;
	}

	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public TassetType getTassetType() {
		return this.tassetType;
	}

	public void setTassetType(TassetType tassetType) {
		this.tassetType = tassetType;
	}
	
	public Tattribute getTattribute() {
		return this.tattribute;
	}

	public void setTattribute(Tattribute tattribute) {
		this.tattribute = tattribute;
	}
	
}