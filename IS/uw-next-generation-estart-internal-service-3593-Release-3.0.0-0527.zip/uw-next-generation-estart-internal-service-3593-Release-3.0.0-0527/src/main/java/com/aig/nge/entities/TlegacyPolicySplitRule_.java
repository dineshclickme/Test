package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-08-04T13:12:21.271+0530")
@StaticMetamodel(TlegacyPolicySplitRule.class)
public class TlegacyPolicySplitRule_ {
	public static volatile SingularAttribute<TlegacyPolicySplitRule, TlegacyPolicySplitRulePK> id;
	public static volatile SingularAttribute<TlegacyPolicySplitRule, Timestamp> createTs;
	public static volatile SingularAttribute<TlegacyPolicySplitRule, String> createUserId;
	public static volatile SingularAttribute<TlegacyPolicySplitRule, String> policyDigitsIn;
	public static volatile SingularAttribute<TlegacyPolicySplitRule, Timestamp> updateTs;
	public static volatile SingularAttribute<TlegacyPolicySplitRule, String> updateUserId;
	public static volatile SingularAttribute<TlegacyPolicySplitRule, Tsystem> tsystem;
	public static volatile SingularAttribute<TlegacyPolicySplitRule, Tdivision> tdivision;
}
