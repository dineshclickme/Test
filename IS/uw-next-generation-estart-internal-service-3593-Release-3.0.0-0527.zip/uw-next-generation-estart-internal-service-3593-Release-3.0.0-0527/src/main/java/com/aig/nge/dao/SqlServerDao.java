package com.aig.nge.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Repository;

import com.aig.nge.helper.CommonServiceHelper;
import com.aig.nge.utilities.NGEConstants;import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@Repository
public class SqlServerDao {

	/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
	@Autowired
	private CommonServiceHelper commonServiceHelper;
	/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
	//Connection con=null;
	private static final Logger logger = LogManager.getLogger(SqlServerDao.class);
	public SqlServerDao()
	{
		
	}
	@Cacheable("SqlServerDao.getCountryAndBranchDesc")
	public HashMap<String, String> getCountryAndBranchDesc(String srcCd,String branchcd)
	{
		HashMap<String, String> map=new HashMap<String, String>();
		PreparedStatement ps=null;
		ResultSet rs=null;
		Connection con =null;
		try {
		con= getSqlServerConnection();
			 ps= con.prepareCall("SELECT BRCH_LOCL_CTRY_CD,BRCH_LOCL_BRCH_CD FROM TBRANCH where BRCH_SOURCE_CD=? and BRCH_BRCH_NO=?");
			ps.setString(1,srcCd);
			ps.setString(2,branchcd);
			 rs=ps.executeQuery();
			if(rs.next())
			{
				map.put("BRCH_LOCL_CTRY_CD", rs.getString("BRCH_LOCL_CTRY_CD"));
				map.put("BRCH_LOCL_BRCH_CD", rs.getString("BRCH_LOCL_BRCH_CD"));
				logger.debug("BRCH_LOCL_CTRY_CD" + map.get("BRCH_LOCL_CTRY_CD"));
			}
			
			
		} catch (Exception e) {
			/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
			if(commonServiceHelper.checkForRetryExceptions(e, 108, NGEConstants.CatchExceptionTypes.NO_THROW))
			{
				logger.error("checkForRetryExceptions returned true");
			}
			/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
			// TODO Auto-generated catch block
			///logger.debug("Exception : " +e.getMessage());
			logger.info("Exception while getting country and branch data from SQL table");
		}finally{
			try{
		if(rs!=null)
			rs.close();
		if(ps!=null)
			ps.close();
		if(con!=null){
			if(!con.isClosed()){
				con.close();
			}
		}
			}catch(Exception ex){
				/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
				if(commonServiceHelper.checkForRetryExceptions(ex, 109, NGEConstants.CatchExceptionTypes.NO_THROW))
				{
					logger.error("checkForRetryExceptions returned true");
				}
				/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
			}
		}
		return map;
	}
	@Cacheable("SqlServerDao.getPriorCarrierDiscr")
	public String getPriorCarrierDiscr(String carrierCd)
	{
		String map="";
	logger.debug("carrierCd loaded -" +carrierCd);
			PreparedStatement ps=null;
			ResultSet rs=null;
			Connection con =null;
			try {
			con= getSqlServerConnection();
			
			ps=con.prepareCall("SELECT * FROM TCOMP_CARRIER  WHERE CPCA_CC_CD=?");
			ps.setString(1,carrierCd);
			
			rs=ps.executeQuery();
			if(rs.next())
			{
				map=rs.getString("CPCA_CARR_NAME");
				
				logger.debug("CPCA_CARR_NAME" + map);
			}
				
		} catch (Exception e) {
			// TODO Auto-generated catch block
			//logger.debug("Exception : " +e.getMessage());
			/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
			if(commonServiceHelper.checkForRetryExceptions(e, 110, NGEConstants.CatchExceptionTypes.NO_THROW))
			{
				logger.error("checkForRetryExceptions returned true");
			}
			/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
			logger.info("Exception while getting prior carrier description from SQL table");
		}
			finally{
				try{
			if(rs!=null)
				rs.close();
			if(ps!=null)
				ps.close();
			if(con!=null){
				if(!con.isClosed()){
					con.close();
				}
			}
				}catch(Exception ex){
					/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
					if(commonServiceHelper.checkForRetryExceptions(ex, 111, NGEConstants.CatchExceptionTypes.NO_THROW))
					{
						logger.error("checkForRetryExceptions returned true");
					}
					/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
				}
			}
		return map;
	}
	@Cacheable("SqlServerDao.getCurrencyCd")
	public String getCurrencyCd(String currencyCd)
	{
String map="";
PreparedStatement ps=null;
ResultSet rs=null;
Connection con =null;
try {
con= getSqlServerConnection();
			 ps= con.prepareCall("select CURR_OGIS_CD from TCURRENCY where CURR_CURR_CD=?");
			ps.setString(1,currencyCd);
			
			 rs=ps.executeQuery();
			if(rs.next())
			{
				map=rs.getString("CURR_OGIS_CD");
				
				//logger.debug("CURR_OGIS_CD" + map);
			}
			
				
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			//logger.debug("Exception : " +e.getMessage());
			/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
			if(commonServiceHelper.checkForRetryExceptions(e, 112, NGEConstants.CatchExceptionTypes.NO_THROW))
			{
				logger.error("checkForRetryExceptions returned true");
			}
			/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
			logger.info("Exception while getting the country code from SQL table");
		}finally{
			try{
		if(rs!=null)
			rs.close();
		if(ps!=null)
			ps.close();
		if(con!=null){
			if(!con.isClosed()){
				con.close();
			}
		}
			}catch(Exception ex){
				/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
				if(commonServiceHelper.checkForRetryExceptions(ex, 113, NGEConstants.CatchExceptionTypes.NO_THROW))
				{
					logger.error("checkForRetryExceptions returned true");
				}
				/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */
			}
		}
		return map;
	}
	private Connection getSqlServerConnection() throws NamingException,
	SQLException {
Context ctx = new InitialContext();
DataSource datasource = (DataSource) ctx.lookup("jdbc/estart_mssql");
Connection con = datasource.getConnection();
return con;
}
}
