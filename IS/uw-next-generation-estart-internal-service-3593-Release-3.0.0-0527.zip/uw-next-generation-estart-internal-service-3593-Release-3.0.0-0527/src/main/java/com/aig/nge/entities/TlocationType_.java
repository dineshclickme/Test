package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SetAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-02-19T16:13:03.559+0530")
@StaticMetamodel(TlocationType.class)
public class TlocationType_ {
	public static volatile SingularAttribute<TlocationType, Short> locationTypeId;
	public static volatile SingularAttribute<TlocationType, Timestamp> createTs;
	public static volatile SingularAttribute<TlocationType, String> createUserId;
	public static volatile SingularAttribute<TlocationType, String> locationTypeNm;
	public static volatile SingularAttribute<TlocationType, Timestamp> updateTs;
	public static volatile SingularAttribute<TlocationType, String> updateUserId;
	public static volatile SetAttribute<TlocationType, Tlocation> tlocations;
}
