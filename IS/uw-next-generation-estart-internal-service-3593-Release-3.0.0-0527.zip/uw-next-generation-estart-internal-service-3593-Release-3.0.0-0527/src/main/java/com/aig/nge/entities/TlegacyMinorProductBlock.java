package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Date;


/**
 * The persistent class for the TLEGACY_MINOR_PRODUCT_BLOCK database table.
 * 
 */
@Entity
@Table(name="TLEGACY_MINOR_PRODUCT_BLOCK")
public class TlegacyMinorProductBlock implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private TlegacyMinorProductBlockPK id;

	@Column(name="CREATED_BY_ID")
	private String createdById;

    @Temporal( TemporalType.DATE)
	@Column(name="ENTERED_DT")
	private Date enteredDt;

	@Column(name="LAST_UPDT_TS")
	private Timestamp lastUpdtTs;

	@Column(name="LAST_UPDT_USER_ID")
	private String lastUpdtUserId;

    @Temporal( TemporalType.DATE)
	@Column(name="MNPRD_BLK_EFCTV_DT")
	private Date mnprdBlkEfctvDt;

    @Temporal( TemporalType.DATE)
	@Column(name="MNPRD_BLK_XPRTN_DT")
	private Date mnprdBlkXprtnDt;

	//bi-directional many-to-one association to TlegacyProduct
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="PRODUCT_CD")
	private TlegacyProduct tlegacyProduct;

    public TlegacyMinorProductBlock() {
    }

	public TlegacyMinorProductBlockPK getId() {
		return this.id;
	}

	public void setId(TlegacyMinorProductBlockPK id) {
		this.id = id;
	}
	
	public String getCreatedById() {
		return this.createdById;
	}

	public void setCreatedById(String createdById) {
		this.createdById = createdById;
	}

	public Date getEnteredDt() {
		return this.enteredDt;
	}

	public void setEnteredDt(Date enteredDt) {
		this.enteredDt = enteredDt;
	}

	public Timestamp getLastUpdtTs() {
		return this.lastUpdtTs;
	}

	public void setLastUpdtTs(Timestamp lastUpdtTs) {
		this.lastUpdtTs = lastUpdtTs;
	}

	public String getLastUpdtUserId() {
		return this.lastUpdtUserId;
	}

	public void setLastUpdtUserId(String lastUpdtUserId) {
		this.lastUpdtUserId = lastUpdtUserId;
	}

	public Date getMnprdBlkEfctvDt() {
		return this.mnprdBlkEfctvDt;
	}

	public void setMnprdBlkEfctvDt(Date mnprdBlkEfctvDt) {
		this.mnprdBlkEfctvDt = mnprdBlkEfctvDt;
	}

	public Date getMnprdBlkXprtnDt() {
		return this.mnprdBlkXprtnDt;
	}

	public void setMnprdBlkXprtnDt(Date mnprdBlkXprtnDt) {
		this.mnprdBlkXprtnDt = mnprdBlkXprtnDt;
	}

	public TlegacyProduct getTlegacyProduct() {
		return this.tlegacyProduct;
	}

	public void setTlegacyProduct(TlegacyProduct tlegacyProduct) {
		this.tlegacyProduct = tlegacyProduct;
	}
	
}