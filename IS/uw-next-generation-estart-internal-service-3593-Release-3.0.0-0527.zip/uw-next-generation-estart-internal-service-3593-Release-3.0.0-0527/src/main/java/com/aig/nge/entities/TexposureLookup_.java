package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2016-03-21T17:08:49.024+0530")
@StaticMetamodel(TexposureLookup.class)
public class TexposureLookup_ {
	public static volatile SingularAttribute<TexposureLookup, Integer> exposureLookupId;
	public static volatile SingularAttribute<TexposureLookup, String> countryCd;
	public static volatile SingularAttribute<TexposureLookup, Integer> countryLocationId;
	public static volatile SingularAttribute<TexposureLookup, Timestamp> createTs;
	public static volatile SingularAttribute<TexposureLookup, String> createUserId;
	public static volatile SingularAttribute<TexposureLookup, String> geoClusterCd;
	public static volatile SingularAttribute<TexposureLookup, Integer> geoClusterLocationId;
	public static volatile SingularAttribute<TexposureLookup, String> regionCd;
	public static volatile SingularAttribute<TexposureLookup, Integer> regionLocationId;
	public static volatile SingularAttribute<TexposureLookup, String> subRegionCd;
	public static volatile SingularAttribute<TexposureLookup, Integer> subRegionLocationId;
	public static volatile SingularAttribute<TexposureLookup, Timestamp> updateTs;
	public static volatile SingularAttribute<TexposureLookup, String> updateUserId;
}
