package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the TLEGACY_PROFIT_CENTER_PRODUCT database table.
 * 
 */
@Embeddable
public class TlegacyProfitCenterProductPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="PROFIT_CENTER_CD")
	private String profitCenterCd;

	@Column(name="SOURCE_CD")
	private String sourceCd;

	@Column(name="PRODUCT_CD")
	private String productCd;

    public TlegacyProfitCenterProductPK() {
    }
	public String getProfitCenterCd() {
		return this.profitCenterCd;
	}
	public void setProfitCenterCd(String profitCenterCd) {
		this.profitCenterCd = profitCenterCd;
	}
	public String getSourceCd() {
		return this.sourceCd;
	}
	public void setSourceCd(String sourceCd) {
		this.sourceCd = sourceCd;
	}
	public String getProductCd() {
		return this.productCd;
	}
	public void setProductCd(String productCd) {
		this.productCd = productCd;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof TlegacyProfitCenterProductPK)) {
			return false;
		}
		TlegacyProfitCenterProductPK castOther = (TlegacyProfitCenterProductPK)other;
		return 
			this.profitCenterCd.equals(castOther.profitCenterCd)
			&& this.sourceCd.equals(castOther.sourceCd)
			&& this.productCd.equals(castOther.productCd);

    }
    
	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.profitCenterCd.hashCode();
		hash = hash * prime + this.sourceCd.hashCode();
		hash = hash * prime + this.productCd.hashCode();
		
		return hash;
    }
}