package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-05-27T15:19:12.991+0530")
@StaticMetamodel(TlegacyProductMapping.class)
public class TlegacyProductMapping_ {
	public static volatile SingularAttribute<TlegacyProductMapping, Short> legacyProductMapId;
	public static volatile SingularAttribute<TlegacyProductMapping, Timestamp> createTs;
	public static volatile SingularAttribute<TlegacyProductMapping, String> createUserId;
	public static volatile SingularAttribute<TlegacyProductMapping, String> defaultProductIn;
	public static volatile SingularAttribute<TlegacyProductMapping, Short> legactSectionCd;
	public static volatile SingularAttribute<TlegacyProductMapping, Short> legacyProfitUnitCd;
	public static volatile SingularAttribute<TlegacyProductMapping, Timestamp> updateTs;
	public static volatile SingularAttribute<TlegacyProductMapping, String> updateUserId;
	public static volatile SingularAttribute<TlegacyProductMapping, TlegacyProduct> tlegacyProduct;
	public static volatile SingularAttribute<TlegacyProductMapping, TlegacyProfitCenterProduct> tlegacyProfitCenterProduct;
	public static volatile SingularAttribute<TlegacyProductMapping, Tproduct> tproduct1;
	public static volatile SingularAttribute<TlegacyProductMapping, Tproduct> tproduct2;
	public static volatile SingularAttribute<TlegacyProductMapping, Tproduct> tproduct3;
	public static volatile SingularAttribute<TlegacyProductMapping, Tproduct> tproduct4;
	public static volatile SingularAttribute<TlegacyProductMapping, Tproduct> tproduct5;
	public static volatile SingularAttribute<TlegacyProductMapping, TproductTower> tproductTower;
	public static volatile SingularAttribute<TlegacyProductMapping, String> legacyProdctCovgTypCd;
}
