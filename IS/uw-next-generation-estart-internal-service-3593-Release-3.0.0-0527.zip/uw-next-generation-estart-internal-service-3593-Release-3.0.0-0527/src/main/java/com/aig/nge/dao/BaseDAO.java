package com.aig.nge.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.aig.nge.utilities.NGEException;
/**
 * @author Sudha
 * This DAO class is used as base class for all DAOs.
 * 
 */
@Repository
public class BaseDAO {
	@Autowired
	protected NGEException ngeException;
}
