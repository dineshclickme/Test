package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;

import org.apache.openjpa.persistence.DataCache;
import java.sql.Timestamp;
import java.util.Set;


/**
 * The persistent class for the TPRODUCT_STATE database table.
 * 
 */
@Entity
@DataCache
@Table(name="TPRODUCT_STATE")
public class TproductState implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="PRODUCT_STATE_ID")
	private short productStateId;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="CREATE_TS")
	private Timestamp createTs;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="CREATE_USER_ID")
	private String createUserId;

	@Column(name="PRODUCT_STATE_DS")
	private String productStateDs;

	@Column(name="PRODUCT_STATE_NM")
	private String productStateNm;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="UPDATE_TS")
	private Timestamp updateTs;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="UPDATE_USER_ID")
	private String updateUserId;

	//bi-directional many-to-one association to TtransactionComponent
	@OneToMany(mappedBy="tproductState", cascade={CascadeType.ALL})
	private Set<TtransactionComponent> ttransactionComponents;

    public TproductState() {
    }

	public short getProductStateId() {
		return this.productStateId;
	}

	public void setProductStateId(short productStateId) {
		this.productStateId = productStateId;
	}

	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public String getProductStateDs() {
		return this.productStateDs;
	}

	public void setProductStateDs(String productStateDs) {
		this.productStateDs = productStateDs;
	}

	public String getProductStateNm() {
		return this.productStateNm;
	}

	public void setProductStateNm(String productStateNm) {
		this.productStateNm = productStateNm;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public Set<TtransactionComponent> getTtransactionComponents() {
		return this.ttransactionComponents;
	}

	public void setTtransactionComponents(Set<TtransactionComponent> ttransactionComponents) {
		this.ttransactionComponents = ttransactionComponents;
	}
	
}