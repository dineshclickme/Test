package com.aig.nge.entities;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-08-04T13:12:21.591+0530")
@StaticMetamodel(TtowerTuwSubProdctConfigPK.class)
public class TtowerTuwSubProdctConfigPK_ {
	public static volatile SingularAttribute<TtowerTuwSubProdctConfigPK, Integer> configurationId;
	public static volatile SingularAttribute<TtowerTuwSubProdctConfigPK, Integer> tuwSubProductId;
}
