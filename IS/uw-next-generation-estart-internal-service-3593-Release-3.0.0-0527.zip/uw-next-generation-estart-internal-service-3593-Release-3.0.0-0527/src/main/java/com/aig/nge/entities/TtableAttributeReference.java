package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;

import org.apache.openjpa.persistence.DataCache;
import java.sql.Timestamp;


/**
 * The persistent class for the TTABLE_ATTRIBUTE_REFERENCE database table.
 * 
 */
@Entity
@DataCache
@Table(name="TTABLE_ATTRIBUTE_REFERENCE")
public class TtableAttributeReference implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private TtableAttributeReferencePK id;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="CREATE_TS")
	private Timestamp createTs;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="CREATE_USER_ID")
	private String createUserId;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="UPDATE_TS")
	private Timestamp updateTs;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="UPDATE_USER_ID")
	private String updateUserId;

	//bi-directional many-to-one association to TattributeReference
	@ManyToOne
	@JoinColumn(name="REFERENCE_ID")
	private TattributeReference tattributeReference;

	//bi-directional many-to-one association to TtableAttribute
	@ManyToOne
	@JoinColumns({
		@JoinColumn(name="ATTRIBUTE_ID", referencedColumnName="ATTRIBUTE_ID"),
		@JoinColumn(name="TABLE_ID", referencedColumnName="TABLE_ID")
		})
	private TtableAttribute ttableAttribute;

    public TtableAttributeReference() {
    }

	public TtableAttributeReferencePK getId() {
		return this.id;
	}

	public void setId(TtableAttributeReferencePK id) {
		this.id = id;
	}
	
	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public TattributeReference getTattributeReference() {
		return this.tattributeReference;
	}

	public void setTattributeReference(TattributeReference tattributeReference) {
		this.tattributeReference = tattributeReference;
	}
	
	public TtableAttribute getTtableAttribute() {
		return this.ttableAttribute;
	}

	public void setTtableAttribute(TtableAttribute ttableAttribute) {
		this.ttableAttribute = ttableAttribute;
	}
	
}