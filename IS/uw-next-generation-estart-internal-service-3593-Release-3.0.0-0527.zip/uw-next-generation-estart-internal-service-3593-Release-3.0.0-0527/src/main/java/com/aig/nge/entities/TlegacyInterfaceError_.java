package com.aig.nge.entities;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-09-11T14:03:53.625+0530")
@StaticMetamodel(TlegacyInterfaceError.class)
public class TlegacyInterfaceError_ {
	public static volatile SingularAttribute<TlegacyInterfaceError, Integer> recordId;
	public static volatile SingularAttribute<TlegacyInterfaceError, String> assumedBusIn;
	public static volatile SingularAttribute<TlegacyInterfaceError, BigDecimal> atchmtPointAm;
	public static volatile SingularAttribute<TlegacyInterfaceError, String> bundleTypeCd;
	public static volatile SingularAttribute<TlegacyInterfaceError, String> businessTypeCd;
	public static volatile SingularAttribute<TlegacyInterfaceError, String> cancelReasonCd;
	public static volatile SingularAttribute<TlegacyInterfaceError, Timestamp> createTs;
	public static volatile SingularAttribute<TlegacyInterfaceError, String> createUserId;
	public static volatile SingularAttribute<TlegacyInterfaceError, String> creditedBranchCd;
	public static volatile SingularAttribute<TlegacyInterfaceError, String> displayCrncyCd;
	public static volatile SingularAttribute<TlegacyInterfaceError, Integer> dunBradNo;
	public static volatile SingularAttribute<TlegacyInterfaceError, String> inputErrorMsgTx;
	public static volatile SingularAttribute<TlegacyInterfaceError, Integer> issuingCompanyNo;
	public static volatile SingularAttribute<TlegacyInterfaceError, BigDecimal> limitAm;
	public static volatile SingularAttribute<TlegacyInterfaceError, String> nonRenewalIn;
	public static volatile SingularAttribute<TlegacyInterfaceError, String> nonRenewalReasonCd;
	public static volatile SingularAttribute<TlegacyInterfaceError, BigDecimal> partOfAm;
	public static volatile SingularAttribute<TlegacyInterfaceError, Date> policyEffectiveDt;
	public static volatile SingularAttribute<TlegacyInterfaceError, Short> policyEventNo;
	public static volatile SingularAttribute<TlegacyInterfaceError, Date> policyExpirationDt;
	public static volatile SingularAttribute<TlegacyInterfaceError, Date> policyMailedDt;
	public static volatile SingularAttribute<TlegacyInterfaceError, String> policyNo;
	public static volatile SingularAttribute<TlegacyInterfaceError, String> policyStatusCd;
	public static volatile SingularAttribute<TlegacyInterfaceError, BigDecimal> premiumAm;
	public static volatile SingularAttribute<TlegacyInterfaceError, String> priorCarrierCd;
	public static volatile SingularAttribute<TlegacyInterfaceError, Integer> priorIssuingCompanyNo;
	public static volatile SingularAttribute<TlegacyInterfaceError, Date> priorPolicyEffectiveDt;
	public static volatile SingularAttribute<TlegacyInterfaceError, Short> priorPolicyEventNo;
	public static volatile SingularAttribute<TlegacyInterfaceError, String> priorPolicyNo;
	public static volatile SingularAttribute<TlegacyInterfaceError, String> processStatusCd;
	public static volatile SingularAttribute<TlegacyInterfaceError, Short> processedCt;
	public static volatile SingularAttribute<TlegacyInterfaceError, String> prodctCovgTypeCd;
	public static volatile SingularAttribute<TlegacyInterfaceError, String> producerNo;
	public static volatile SingularAttribute<TlegacyInterfaceError, String> productCd;
	public static volatile SingularAttribute<TlegacyInterfaceError, String> profitCenterCd;
	public static volatile SingularAttribute<TlegacyInterfaceError, Short> profitUnitCd;
	public static volatile SingularAttribute<TlegacyInterfaceError, String> proformaCreditCd;
	public static volatile SingularAttribute<TlegacyInterfaceError, Date> sbmnReceivedDt;
	public static volatile SingularAttribute<TlegacyInterfaceError, Short> sectionCd;
	public static volatile SingularAttribute<TlegacyInterfaceError, String> sourceCd;
	public static volatile SingularAttribute<TlegacyInterfaceError, Integer> submissionNo;
	public static volatile SingularAttribute<TlegacyInterfaceError, Timestamp> transactionTs;
	public static volatile SingularAttribute<TlegacyInterfaceError, String> transactionTypeTx;
	public static volatile SingularAttribute<TlegacyInterfaceError, String> trapErrorMsgTx;
	public static volatile SingularAttribute<TlegacyInterfaceError, String> underwriterId;
	public static volatile SingularAttribute<TlegacyInterfaceError, Timestamp> updateTs;
	public static volatile SingularAttribute<TlegacyInterfaceError, String> updateUserId;
	public static volatile SingularAttribute<TlegacyInterfaceError, String> uwSystemId;
	public static volatile SingularAttribute<TlegacyInterfaceError, String> wipId;
	public static volatile SingularAttribute<TlegacyInterfaceError, String> workingBranchCd;
}
