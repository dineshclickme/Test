package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-06-19T14:59:45.945+0530")
@StaticMetamodel(Tproperty.class)
public class Tproperty_ {
	public static volatile SingularAttribute<Tproperty, TpropertyPK> id;
	public static volatile SingularAttribute<Tproperty, Timestamp> createTs;
	public static volatile SingularAttribute<Tproperty, String> createUserId;
	public static volatile SingularAttribute<Tproperty, String> propertyVal;
	public static volatile SingularAttribute<Tproperty, Timestamp> updateTs;
	public static volatile SingularAttribute<Tproperty, String> updateUserId;
	public static volatile SingularAttribute<Tproperty, Tsystem> tsystem;
}
