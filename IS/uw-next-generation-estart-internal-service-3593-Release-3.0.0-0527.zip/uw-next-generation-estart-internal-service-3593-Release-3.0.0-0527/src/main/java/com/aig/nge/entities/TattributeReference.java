package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;
import org.apache.openjpa.persistence.DataCache;
import java.sql.Timestamp;
import java.util.Set;


/**
 * The persistent class for the TATTRIBUTE_REFERENCE database table.
 * 
 */
@Entity
@DataCache
@Table(name="TATTRIBUTE_REFERENCE")
public class TattributeReference implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="REFERENCE_ID")
	private short referenceId;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="CREATE_TS")
	private Timestamp createTs;

	@Basic(fetch=FetchType.LAZY)
	@Column(name="CREATE_USER_ID")
	private String createUserId;

	@Column(name="DELETED_IN")
	private String deletedIn;

	@Column(name="REFERENCE_NM")
	private String referenceNm;

	@Column(name="REFERENCE_VAL")
	private String referenceVal;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="UPDATE_TS")
	private Timestamp updateTs;

	@Basic(fetch=FetchType.LAZY)
	@Column(name="UPDATE_USER_ID")
	private String updateUserId;
	
	@Column(name="RELATED_REFERENCE_NM")
	private String relatedReferenceNm;//Aug 2018  Q3 Maintenance Release 2.12 -	To modify Asset screen to populate the relation between Make and Model attributes

	//bi-directional many-to-one association to TreferenceGroup
	@ManyToOne
	@JoinColumn(name="REFERENCE_GROUP_ID")
	private TreferenceGroup treferenceGroup;

	//bi-directional many-to-one association to TtableAttributeReference
	@OneToMany(mappedBy="tattributeReference", cascade={CascadeType.ALL})
	private Set<TtableAttributeReference> ttableAttributeReferences;

    public TattributeReference() {
    }

	public short getReferenceId() {
		return this.referenceId;
	}

	public void setReferenceId(short referenceId) {
		this.referenceId = referenceId;
	}

	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public String getDeletedIn() {
		return this.deletedIn;
	}

	public void setDeletedIn(String deletedIn) {
		this.deletedIn = deletedIn;
	}

	public String getReferenceNm() {
		return this.referenceNm;
	}

	public void setReferenceNm(String referenceNm) {
		this.referenceNm = referenceNm;
	}

	public String getReferenceVal() {
		return this.referenceVal;
	}

	public void setReferenceVal(String referenceVal) {
		this.referenceVal = referenceVal;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public TreferenceGroup getTreferenceGroup() {
		return this.treferenceGroup;
	}

	public void setTreferenceGroup(TreferenceGroup treferenceGroup) {
		this.treferenceGroup = treferenceGroup;
	}
	
	public Set<TtableAttributeReference> getTtableAttributeReferences() {
		return this.ttableAttributeReferences;
	}

	public void setTtableAttributeReferences(Set<TtableAttributeReference> ttableAttributeReferences) {
		this.ttableAttributeReferences = ttableAttributeReferences;
	}

	public String getRelatedReferenceNm() {
		return relatedReferenceNm;
	}

	public void setRelatedReferenceNm(String relatedReferenceNm) {
		this.relatedReferenceNm = relatedReferenceNm;
	}
	
	
}