package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-02-24T11:59:50.112+0530")
@StaticMetamodel(TproductTowerParty.class)
public class TproductTowerParty_ {
	public static volatile SingularAttribute<TproductTowerParty, TproductTowerPartyPK> id;
	public static volatile SingularAttribute<TproductTowerParty, Timestamp> createTs;
	public static volatile SingularAttribute<TproductTowerParty, String> createUserId;
	public static volatile SingularAttribute<TproductTowerParty, Timestamp> updateTs;
	public static volatile SingularAttribute<TproductTowerParty, String> updateUserId;
	public static volatile SingularAttribute<TproductTowerParty, Tparty> tparty;
	public static volatile SingularAttribute<TproductTowerParty, TproductTower> tproductTower;
	public static volatile SingularAttribute<TproductTowerParty, Trole> trole;
}
