package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the TLEGACY_SOURCE_MAPPING database table.
 * 
 */
@Embeddable
public class TlegacySourceMappingPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="SOURCE_CD")
	private String sourceCd;

	@Column(name="LEGACY_BRANCH_NO")
	private String legacyBranchNo;

    public TlegacySourceMappingPK() {
    }
	public String getSourceCd() {
		return this.sourceCd;
	}
	public void setSourceCd(String sourceCd) {
		this.sourceCd = sourceCd;
	}
	public String getLegacyBranchNo() {
		return this.legacyBranchNo;
	}
	public void setLegacyBranchNo(String legacyBranchNo) {
		this.legacyBranchNo = legacyBranchNo;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof TlegacySourceMappingPK)) {
			return false;
		}
		TlegacySourceMappingPK castOther = (TlegacySourceMappingPK)other;
		return 
			this.sourceCd.equals(castOther.sourceCd)
			&& this.legacyBranchNo.equals(castOther.legacyBranchNo);

    }
    
	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.sourceCd.hashCode();
		hash = hash * prime + this.legacyBranchNo.hashCode();
		
		return hash;
    }
}