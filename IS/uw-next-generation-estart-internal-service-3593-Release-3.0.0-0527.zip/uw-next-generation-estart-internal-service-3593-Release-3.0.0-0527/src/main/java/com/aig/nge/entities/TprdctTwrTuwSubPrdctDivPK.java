package com.aig.nge.entities;


import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the TPRDCT_TWR_TUW_SUB_PRDCT_DIV database table.
 * 
 */
@Embeddable
public class TprdctTwrTuwSubPrdctDivPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="PRODUCT_TOWER_TUW_SUBPRODCT_ID")
	private int productTowerTuwSubprodctId;

	@Column(name="DIVISION_NO")
	private short divisionNo;

    public TprdctTwrTuwSubPrdctDivPK() {
    }
	public int getProductTowerTuwSubprodctId() {
		return this.productTowerTuwSubprodctId;
	}
	public void setProductTowerTuwSubprodctId(int productTowerTuwSubprodctId) {
		this.productTowerTuwSubprodctId = productTowerTuwSubprodctId;
	}
	public short getDivisionNo() {
		return this.divisionNo;
	}
	public void setDivisionNo(short divisionNo) {
		this.divisionNo = divisionNo;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof TprdctTwrTuwSubPrdctDivPK)) {
			return false;
		}
		TprdctTwrTuwSubPrdctDivPK castOther = (TprdctTwrTuwSubPrdctDivPK)other;
		return 
			(this.productTowerTuwSubprodctId == castOther.productTowerTuwSubprodctId)
			&& (this.divisionNo == castOther.divisionNo);

    }
    
	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.productTowerTuwSubprodctId;
		hash = hash * prime + ((int) this.divisionNo);
		
		return hash;
    }
}