package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Set;


/**
 * The persistent class for the TSUBMISSION_EVALUATION_ALERT database table.
 * 
 */
@Entity
@Table(name="TSUBMISSION_EVALUATION_ALERT")
public class TsubmissionEvaluationAlert implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="SUBMISSION_EVALUATION_CD")
	private int submissionEvaluationCd;

	@Column(name="ALERT_TYPE_NM")
	private String alertTypeNm;

	@Column(name="CREATE_TS")
	private Timestamp createTs;

	@Column(name="CREATE_USER_ID")
	private String createUserId;

	@Column(name="UPDATE_TS")
	private Timestamp updateTs;

	@Column(name="UPDATE_USER_ID")
	private String updateUserId;

	//bi-directional many-to-one association to TofacAlertNotification
	@OneToMany(mappedBy="tsubmissionEvaluationAlert")
	private Set<TofacAlertNotification> tofacAlertNotifications;

	//bi-directional many-to-one association to TseAlertSource
	@OneToMany(mappedBy="tsubmissionEvaluationAlert")
	private Set<TseAlertSource> tseAlertSources;

    public TsubmissionEvaluationAlert() {
    }

	public int getSubmissionEvaluationCd() {
		return this.submissionEvaluationCd;
	}

	public void setSubmissionEvaluationCd(int submissionEvaluationCd) {
		this.submissionEvaluationCd = submissionEvaluationCd;
	}

	public String getAlertTypeNm() {
		return this.alertTypeNm;
	}

	public void setAlertTypeNm(String alertTypeNm) {
		this.alertTypeNm = alertTypeNm;
	}

	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public Set<TofacAlertNotification> getTofacAlertNotifications() {
		return this.tofacAlertNotifications;
	}

	public void setTofacAlertNotifications(Set<TofacAlertNotification> tofacAlertNotifications) {
		this.tofacAlertNotifications = tofacAlertNotifications;
	}
	
	public Set<TseAlertSource> getTseAlertSources() {
		return this.tseAlertSources;
	}

	public void setTseAlertSources(Set<TseAlertSource> tseAlertSources) {
		this.tseAlertSources = tseAlertSources;
	}
	
}