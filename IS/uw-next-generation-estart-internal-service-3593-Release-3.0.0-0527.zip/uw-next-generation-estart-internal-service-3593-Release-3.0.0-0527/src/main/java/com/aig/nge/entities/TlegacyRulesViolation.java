package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the TLEGACY_RULES_VIOLATION database table.
 * 
 */
@Entity
@Table(name="TLEGACY_RULES_VIOLATION")
public class TlegacyRulesViolation implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="TRANSACTION_COMPONENT_ID")
	private String transactionComponentId;

	@Column(name="CREATE_TS")
	private Timestamp createTs;

	@Column(name="CREATE_USER_ID")
	private String createUserId;

	@Column(name="METHOD_NM")
	private String methodNm;

	@Column(name="UPDATE_TS")
	private Timestamp updateTs;

	@Column(name="UPDATE_USER_ID")
	private String updateUserId;

	//bi-directional many-to-one association to TlegacyError
    @ManyToOne
	@JoinColumn(name="LEGACY_ERROR_ID")
	private TlegacyError tlegacyError;

	//bi-directional many-to-one association to Tsystem
    @ManyToOne
	@JoinColumn(name="SYSTEM_ID")
	private Tsystem tsystem;

	//bi-directional one-to-one association to TtransactionComponent
	@OneToOne
	@JoinColumn(name="TRANSACTION_COMPONENT_ID")
	private TtransactionComponent ttransactionComponent;

    public TlegacyRulesViolation() {
    }

	public String getTransactionComponentId() {
		return this.transactionComponentId;
	}

	public void setTransactionComponentId(String transactionComponentId) {
		this.transactionComponentId = transactionComponentId;
	}

	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public String getMethodNm() {
		return this.methodNm;
	}

	public void setMethodNm(String methodNm) {
		this.methodNm = methodNm;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public TlegacyError getTlegacyError() {
		return this.tlegacyError;
	}

	public void setTlegacyError(TlegacyError tlegacyError) {
		this.tlegacyError = tlegacyError;
	}
	
	public Tsystem getTsystem() {
		return this.tsystem;
	}

	public void setTsystem(Tsystem tsystem) {
		this.tsystem = tsystem;
	}
	
	public TtransactionComponent getTtransactionComponent() {
		return this.ttransactionComponent;
	}

	public void setTtransactionComponent(TtransactionComponent ttransactionComponent) {
		this.ttransactionComponent = ttransactionComponent;
	}
	
}