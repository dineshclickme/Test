package com.aig.nge.dao;


import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.aig.nge.entities.Tattribute;
import com.aig.nge.entities.Tbranch;
import com.aig.nge.entities.TmailingAddress;
import com.aig.nge.entities.Tparty;
import com.aig.nge.entities.TproducerContact;
import com.aig.nge.entities.TproductTower;
import com.aig.nge.entities.TproductTowerAttribute;
import com.aig.nge.entities.TrelationType;
import com.aig.nge.entities.Trole;
import com.aig.nge.entities.Tstatus;
import com.aig.nge.entities.Tsubmission;
import com.aig.nge.entities.Ttable;
import com.aig.nge.entities.TtableAttributeReference;
import com.aig.nge.entities.Ttransaction;
import com.aig.nge.entities.TtransactionAttribute;
import com.aig.nge.entities.TtransactionAttributePK;
import com.aig.nge.entities.TtransactionParty;
import com.aig.nge.entities.TtransactionPartyPK;
import com.aig.nge.entities.TtransactionProductAttribute;
import com.aig.nge.entities.TtransactionRelation;
import com.aig.nge.entities.TtransactionVersion;
import com.aig.nge.entities.TtransactionVersionPK;
import com.aig.nge.entities.VcomponentProduct;
import com.aig.nge.handler.external.AccountServiceHandler;
import com.aig.nge.handler.external.ProducerResolver;
import com.aig.nge.helper.CommonServiceHelper;
import com.aig.nge.helper.HistoryHelper;
import com.aig.nge.helper.external.AccountServiceHelper;
import com.aig.nge.model.ProducerModel;
import com.aig.nge.repository.TAttributeRepository;
import com.aig.nge.repository.TProducerContactRepository;
import com.aig.nge.repository.TRelationTypeRepository;
import com.aig.nge.repository.TStatusRepository;
import com.aig.nge.repository.TTransactionAttributeHRepository;
import com.aig.nge.repository.TTransactionAttributeRepository;
import com.aig.nge.repository.TTransactionHistoryRepository;
import com.aig.nge.repository.TTransactionPartyRepository;
import com.aig.nge.repository.TTransactionProductAttributeRepository;
import com.aig.nge.repository.TTransactionRelationRepository;
import com.aig.nge.repository.TTransactionRepository;
import com.aig.nge.repository.TTransactionVersionRepository;
import com.aig.nge.repository.VComponentProductRepository;
import com.aig.nge.utilities.AIGCIExceptionMsg;
import com.aig.nge.utilities.NGECommonUtil;
import com.aig.nge.utilities.NGEConstants;
import com.aig.nge.utilities.NGEDateUtil;
import com.aig.nge.utilities.NGEErrorCodes;
import com.aig.nge.utilities.NGESession;
import com.aig.nge.wsdl.external.accountservice.GetAccountResponse;
import com.aig.nge.wsdl.skeleton.AdditionalInsuredRq;
import com.aig.nge.wsdl.skeleton.AdditionalInsuredsVersionRq;
import com.aig.nge.wsdl.skeleton.AdditionalProducerDetail;
import com.aig.nge.wsdl.skeleton.AdditionalProducersDetails;
import com.aig.nge.wsdl.skeleton.Attribute;
import com.aig.nge.wsdl.skeleton.Attributes;
import com.aig.nge.wsdl.skeleton.Broker;
import com.aig.nge.wsdl.skeleton.CreditedBranch;import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
/*import com.aig.nge.entities.TproductTowerDivision;*/

/**
 * 
 * @author Manasaj This DAO class is used for accessing all the transaction
 *         related repositories
 * 
 */
@Repository
public class TransactionDAO extends BaseDAO {

	private static final Logger logger = LogManager.getLogger(TransactionDAO.class);
	@Autowired
	private TTransactionRepository transactionRepository;

	@Autowired
	private TTransactionVersionRepository versionRepository;

	@Autowired
	private TProducerContactRepository producerContactRepository;

	@Autowired
	private TTransactionAttributeRepository transactionAttributeRepository;

	@Autowired
	private TTransactionPartyRepository transactionPartyRepository;

	@Autowired
	private TTransactionVersionRepository transactionVersionRepository;

	@Autowired
	private TAttributeRepository attributeRepository;

	@Autowired
	private PartyDAO partyDAO;
	
	@Autowired
	private NGECommonUtil ngeCommonUtil;

	@Autowired
	private CommonDAO commonDAO;

	@Autowired
	TTransactionAttributeHRepository transactionAttributeHRepository;

	@Autowired
	TTransactionHistoryRepository transactionHistoryRepository;

	@Autowired
	TStatusRepository statusRepository;

	@Autowired
	private TTransactionRelationRepository transactionRelationRepository;
	
	@Autowired
	private TRelationTypeRepository transactionRelationTypeRepository;
	@Autowired
	private TTransactionProductAttributeRepository tTransactionProductAttributeRepository;

	/*@Autowired
	private SequenceNumberGeneration sequenceNumberGeneration;*/
	
	@Autowired
	private VComponentProductRepository vComponentProductRepository;
	
	@Autowired
	private AccountServiceHelper accountServiceHelper;
	
	@Autowired
	private ProducerResolver producerResolver;
	
	@Autowired
	private AttributeDAO attributeDAO;
	
	@Autowired
	private TableDAO tableDAO;
	
	@Autowired
	private CommonServiceHelper commonServiceHelper;
	
	@Autowired
	private ProductDAO productDAO;
	
	@Autowired
	private HistoryHelper historyHelper;
	
	@Autowired
	private SubmissionDAO submissionDAO;
	

	/* 2021 MDM Changes - Starts */	
	@Autowired
	private AccountServiceHandler accountServiceHandler;
	/* 2021 MDM Changes - Ends */	

	
	/**
	 * @author Manasaj
	 * @param transactionId
	 * @throws AIGCIExceptionMsg
	 */
	public Ttransaction findByTransactionID(long transactionId)
			throws AIGCIExceptionMsg {
		Ttransaction transaction = transactionRepository.findOne(String
				.valueOf(transactionId));
		if (transaction == null) {
			ngeException.throwException(NGEErrorCodes.INVALID_TXN_ID_VALUE,
					NGEErrorCodes.ERROR_TYPE, null, null);
		}
		return transaction;

	}
	
	public Ttransaction getByTransactionId(long transactionId)
			throws AIGCIExceptionMsg {
		Ttransaction transaction = transactionRepository.getByTransactionId((String
				.valueOf(transactionId)));
		if (transaction == null) {
			ngeException.throwException(NGEErrorCodes.INVALID_TXN_ID_VALUE,
					NGEErrorCodes.ERROR_TYPE, null, null);
		}
		return transaction;
	}
	
	public List<Ttransaction> getListOfTransactions(List<String> transactionIdList)	throws AIGCIExceptionMsg {
		List<Ttransaction> transactionList = null;
		transactionList = transactionRepository.getListOfTransactions(transactionIdList);
		if (transactionList == null || transactionList.isEmpty()) {
			ngeException.throwException(NGEErrorCodes.INVALID_TXN_ID_VALUE,
					NGEErrorCodes.ERROR_TYPE, null, null);
		}
		return transactionList;
	}

	public List<TtransactionAttribute> getTransactionId(String attributeVal,
			String attributeNm) throws AIGCIExceptionMsg {
		List<TtransactionAttribute> transactionAttribute = null;
		transactionAttribute = transactionAttributeRepository
				.findByAttributeValAndTattribute(attributeVal, attributeNm);
		if (transactionAttribute.isEmpty()) {
			ngeException.throwException(NGEErrorCodes.INVALID_CONTRACT_NUM,
					NGEErrorCodes.ERROR_TYPE, "Invalid Contract Number. Given Contract Number is either blank or does not exists in NGE", null);
		}
		return transactionAttribute;
	}

	/**
	 * @author Manasaj
	 * @param versionPK
	 * @throws AIGCIExceptionMsg
	 */
	public TtransactionVersion findByTransactionVersion(
			TtransactionVersionPK versionPK) throws AIGCIExceptionMsg {
		TtransactionVersion transactionVersion = versionRepository
				.findOne(versionPK);
		
		if (transactionVersion == null) {
			List<Object> errorReason = new ArrayList<Object>();
			errorReason.add(versionPK.getVersionSqn());
			errorReason.add(versionPK.getTransactionId());
			ngeException.throwException(
					NGEErrorCodes.INVALID_TRANSACTION_VERSION,
					NGEErrorCodes.ERROR_TYPE, ""+versionPK.getVersionSqn()+" is not a valid  VersionId  for the TransactionId"+versionPK.getTransactionId()+" ", errorReason);
		}
		return transactionVersion;

	}

	public TtransactionVersion findByTransactionVersionForAddProduct(
			TtransactionVersionPK versionPK, boolean checkBoundInd, boolean checkLockInd) throws AIGCIExceptionMsg {
		List<TtransactionVersion> transactionVersionList = versionRepository
				.findByTransactionIdForAddProduct(versionPK.getTransactionId());
		TtransactionVersion transactionVersionMatched = null;
		
		if (transactionVersionList == null || transactionVersionList.isEmpty()) {
			ngeException.throwException(NGEErrorCodes.INVALID_TXN_ID_VALUE, NGEErrorCodes.ERROR_TYPE, null, null);
		}
		else 
		{
			boolean isVersionAvailable = false;
			
			for(TtransactionVersion transactionVersion : transactionVersionList)
			{
				if(transactionVersion.getId().getVersionSqn() == versionPK.getVersionSqn())
				{
					isVersionAvailable = true;
					transactionVersionMatched = transactionVersion;
				}
				else if(NGEConstants.YES.equalsIgnoreCase(transactionVersion.getBoundIn()) && checkBoundInd)
				{
					ngeException.throwException(NGEErrorCodes.BOUND_IND,
							NGEErrorCodes.ERROR_TYPE, null, null);
				}
			}
			if(!isVersionAvailable)
			{
				List<Object> errorReason = new ArrayList<Object>();
				errorReason.add(versionPK.getVersionSqn());
				errorReason.add(versionPK.getTransactionId());
				ngeException.throwException(
						NGEErrorCodes.INVALID_TRANSACTION_VERSION,
						NGEErrorCodes.ERROR_TYPE, ""+versionPK.getVersionSqn()+" is not a valid  VersionId  for the TransactionId"+versionPK.getTransactionId()+" ", errorReason);
			}
			else if(transactionVersionMatched.getLockIn().equalsIgnoreCase(NGEConstants.YES) && checkLockInd){
				 ngeException.throwException(NGEErrorCodes.LOCK_IN,NGEErrorCodes.ERROR_TYPE, null, null);
			}
		}
		return transactionVersionMatched;

	}
	
	public TtransactionVersionPK setVersionPK(long transactionId,
			short versionNo) {
		TtransactionVersionPK versionPK = new TtransactionVersionPK();
		versionPK.setTransactionId(String.valueOf(transactionId));
		versionPK.setVersionSqn(versionNo);
		return versionPK;
	}

	public void deleteProducerContact(List<TproducerContact> tProducerContactList) {
		producerContactRepository.delete(tProducerContactList);
	}
	
	public List<TproducerContact> getProducerContact(String transactionId) {

		List<TproducerContact> tProducerContactList = null;
		tProducerContactList = producerContactRepository
				.getProducerContact(transactionId);
		return tProducerContactList;
	}
	

	public List<Ttransaction> findBySubmissionAndTransactionId(
			String submissionNo, String transactionId) {

		List<Ttransaction> tTransactionList = null;
		if(transactionId.equalsIgnoreCase("0"))
		{
			transactionId = null;
		}
		tTransactionList = transactionRepository
				.findBySubmissionAndTransactionId(submissionNo, transactionId);
		return tTransactionList;
	}

	public List<TtransactionAttribute> getTransactionAttribute(
			String transactionId, short versionNo) {

		List<TtransactionAttribute> tTransactionAttributeList = null;
		tTransactionAttributeList = transactionAttributeRepository
				.getTransactionAttribute(transactionId, versionNo);
		return tTransactionAttributeList;
	}

	public List<TtransactionAttribute> getAttributeValues(short attributeId,
			String transactionId, short versionNo) {

		List<TtransactionAttribute> attributeValuesList = null;
		attributeValuesList = transactionAttributeRepository.findById(
				transactionId, versionNo, attributeId);
		return attributeValuesList;
	}

	public List<Short> getUniqueAttributeId(String transactionId,
			short versionNo) {

		List<Short> uniqueAttributeId = null;
		uniqueAttributeId = transactionAttributeRepository
				.getUniqueAttributeId(transactionId, versionNo);
		return uniqueAttributeId;
	}
	
	public Set<Short> getUniqueAttributeId(Set<TtransactionAttribute> transactionAttributeList) {
		
		Set<Short> uniqueAttributeId = new HashSet<Short>(); 

			for (TtransactionAttribute transactionProductAttribute : transactionAttributeList)
			{
				uniqueAttributeId.add(transactionProductAttribute.getTattribute().getAttributeId());
			}
		return uniqueAttributeId;	
	}

	public String getAttributeNm(short attributeId) {

		Tattribute attribute = null; 
		attribute=attributeRepository.getAttributeNm(attributeId);
		return attribute.getAttributeNm();
	}

	public List<TtransactionParty> getTransactionParty(TtransactionVersion transactionVersion, String roleNm) {

		List<TtransactionParty> tTransactionPartyList = new ArrayList<TtransactionParty>();
		transactionVersion.getTtransactionParties();
		for(TtransactionParty transactionParty : transactionVersion.getTtransactionParties())
		{
			if(roleNm.equalsIgnoreCase(transactionParty.getTrole().getRoleNm()) && NGEConstants.NO.equalsIgnoreCase(transactionParty.getDeletedIn()))
			{
				tTransactionPartyList.add(transactionParty);
			}
		}
		//tTransactionPartyList = transactionPartyRepository.getTransactionParty(
			//	transactionId, versionNo, roleNm.toUpperCase(), NGEConstants.NO);
		return tTransactionPartyList;

	}

	public List<Ttransaction> findBySubmissionNo(String submissionNo) {

		List<Ttransaction> tTransactionList = null;
		tTransactionList = transactionRepository
				.findBySubmissionNo(submissionNo);
		return tTransactionList;
	}

	public List<TtransactionVersion> findBySubmissionNoAndTransactionIdAndVersionNo(
			String submissionNo, String transactionId, short versionNo) {

		List<TtransactionVersion> tTransactionVersionList = null;
			
		if(versionNo != 0){
			tTransactionVersionList=transactionVersionRepository.findByVersionNo(submissionNo, transactionId, versionNo);																												
		}else{
			tTransactionVersionList=findBySubmissionNoAndTransactionId(submissionNo, transactionId);
		}
		return tTransactionVersionList;

	}

	public List<TtransactionVersion> findBySubmissionNoAndTransactionId(
			String submissionNo, String transactionId) {

		List<TtransactionVersion> tTransactionVersionList = null;
		tTransactionVersionList = transactionVersionRepository
				.findBySubmissionNoAndTransactionId(submissionNo, transactionId);
		return tTransactionVersionList;

	}

	public TtransactionVersion findByTransactionIdAndBoundIn(
			String transactionId, short versionSqn, String boundInd)
			throws AIGCIExceptionMsg {

		TtransactionVersion tTransactionVersionData = null;
		tTransactionVersionData = transactionVersionRepository
				.findByTransactionIdAndBoundIn(transactionId, boundInd);
		if (tTransactionVersionData != null
				&& tTransactionVersionData.getId().getVersionSqn() != versionSqn) {
			ngeException.throwException(NGEErrorCodes.BOUND_IND,
					NGEErrorCodes.ERROR_TYPE, null, null);
		}
		return tTransactionVersionData;

	}

	public TtransactionVersion populateTransactionVersion(Ttransaction transactionData,
			AdditionalInsuredsVersionRq additionalInsureds,
			AdditionalProducersDetails additionalProducers,
			Attributes transactionAttributes,CreditedBranch creditedBranch)
			throws AIGCIExceptionMsg {
		TtransactionVersion transactionVersionData = new TtransactionVersion();
		
		// Transaction version table
		TtransactionVersionPK transVerPk = new TtransactionVersionPK();
		transVerPk.setTransactionId(transactionData.getTransactionId());
		transVerPk.setVersionSqn((short) 1);
		transactionVersionData.setId(transVerPk);
		transactionVersionData.setBoundIn(NGEConstants.NO);
		transactionVersionData.setLockIn(NGEConstants.NO);
		transactionVersionData.setCreateTs(NGEDateUtil.getTodayDate());
		transactionVersionData.setCreateUserId(NGESession.getSessionData().getUserId());
		String actionValue="";
		HashMap<Long, String> additionalInsuredMap = new HashMap<Long, String>();
		HashMap<String, String> additionalProducerMap = new HashMap<String, String>();

		// transaction party table
		Set<TtransactionParty> transactionParties = new HashSet<TtransactionParty>();
		int partySqn = 1;
		Tparty accountParty = null;
		if (additionalInsureds != null
				&& additionalInsureds.getAdditionalInsuredRq() != null
				&& additionalInsureds.getAdditionalInsuredRq().size() > 0) {
			List<AdditionalInsuredRq> aList = additionalInsureds
					.getAdditionalInsuredRq();
			
				
			List<Long> accountNoList = new ArrayList<Long>();
			for (AdditionalInsuredRq insured : aList) {
				
				/* 2021 MDM Changes - Starts */
				if (insured.getMDMPartyId() != null) {
					GetAccountResponse accountResponseType = accountServiceHandler.getAccount(insured.getAccountNo(), insured.getMDMPartyId());
					String accountNo = accountResponseType.getGetAccountRsp().getResponse().getGetAccountResults().getAccount().getAccountInfo().getAccountShortInfo().getAccountNumber();
					accountNoList.add(Long.valueOf(accountNo));
					
					additionalInsuredMap.put(Long.valueOf(accountNo), NGEConstants.ROLE.ADDITIONAL_NAMED_INSURED);
				}
				else if(insured.getAccountNo() != null){
					accountNoList.add(insured.getAccountNo());
					
					additionalInsuredMap.put(insured.getAccountNo(), NGEConstants.ROLE.ADDITIONAL_NAMED_INSURED);
				}							
				/* 2021 MDM Changes - Ends */
			}
			
			/* 2021 MDM Changes - Starts */
			if(accountNoList != null && !accountNoList.isEmpty()){
				
				java.util.Collections.sort(accountNoList);
				boolean validateDuplicateAdditionalInsureds=ngeCommonUtil.checkDuplicates((ArrayList)accountNoList);

				if(!validateDuplicateAdditionalInsureds){
					ngeException.throwException(
							NGEErrorCodes.DUPLICATE_ADDITIONAL_INSURED,
							NGEErrorCodes.ERROR_TYPE, "Duplicate Additional Insured found", null);
				}
			}
			/* 2021 MDM Changes - Ends */
			
			// Check whether the primary insured is provided as additional insured
			Tsubmission submissionData = submissionDAO.findSubmissionNo(Long.parseLong(transactionData.getTsubmission().getSubmissionNo()));
			
			/* 2021 MDM Changes - Starts */
			if(additionalInsuredMap != null && !additionalInsuredMap.isEmpty()){
				
				if(additionalInsuredMap.get(Long.parseLong(submissionData.getTparty2().getPartyNo())) != null){
					List<Object> errorFieldList=new ArrayList<Object>();		           
					errorFieldList.add(NGEConstants.AttributeLevel.TRANSACTION);
					ngeException.throwException(NGEErrorCodes.PRIMARY_ACC_ADDNL_SAME,NGEErrorCodes.ERROR_TYPE, null, errorFieldList);
				}
			}
			/* 2021 MDM Changes - Ends */
			
			for (AdditionalInsuredRq aItem : aList) {
				actionValue=aItem.getAction().value();
				if(actionValue.equalsIgnoreCase(NGEConstants.ACTION_CREATE)){
				
					/* 2021 MDM Changes - Starts */
					accountParty = accountServiceHelper.getAccount(aItem.getAccountNo(), aItem.getMDMPartyId());
					/* 2021 MDM Changes - Ends */
				if (accountParty == null) {
					ngeException.throwException(
							NGEErrorCodes.INVALID_ADDITIONALINSUREDS,
							NGEErrorCodes.ERROR_TYPE, "Unable to store party id for additional insured", null);
				} else {
					
					TtransactionPartyPK transPartyPK = new TtransactionPartyPK();
					transPartyPK.setTransactionId(transactionVersionData
							.getId().getTransactionId());
					transPartyPK.setVersionSqn(transactionVersionData.getId()
							.getVersionSqn());
					transPartyPK.setPartySqn((short) partySqn);
					transPartyPK.setPartyId(accountParty.getPartyId());

					Trole role = new Trole();
					role.setRoleId((short) 1);

					TtransactionParty transParty = new TtransactionParty();
					transParty.setId(transPartyPK);
					transParty.setTrole(role);
					transParty.setSystemId(NGESession.getSessionData().getSystem().getSystemId());
					transParty.setDeletedIn(NGEConstants.NO); // setting to
																// default value
					transParty.setCreateTs(NGEDateUtil.getTodayDate());
					transParty.setCreateUserId(NGESession.getSessionData().getUserId());

					transactionParties.add(transParty);
					partySqn++;

					}
				} else{
					ngeException.throwException(NGEErrorCodes.INVALID_ADDITIONAL_INSURED_ACTION, NGEErrorCodes.ERROR_TYPE, "Unsupported operation for adding an additional insured", null);
				}
			}
		}

		if (additionalProducers != null && additionalProducers.getAdditionalProducer() != null && additionalProducers.getAdditionalProducer().size() > 0) {
			List<AdditionalProducerDetail> aList = additionalProducers.getAdditionalProducer();
			List<String> producerList = new ArrayList<String>();
			ProducerModel producerDetail = new ProducerModel();;
			for (AdditionalProducerDetail additionalProducer : aList) {
				producerList.add(additionalProducer.getProducerCd());
				
				additionalProducerMap.put(additionalProducer.getProducerCd(), NGEConstants.ROLE.ADDITIONAL_PRODUCER_ENTITY);
			}
			java.util.Collections.sort(producerList);
			boolean validateDuplicateProducer=ngeCommonUtil.checkDuplicates((ArrayList)producerList);  
			if(!validateDuplicateProducer){				
					ngeException.throwException(NGEErrorCodes.DUPLICATE_ADDITIONAL_PRODUCER,NGEErrorCodes.ERROR_TYPE, "Duplicate Additional Producer found", null);
			}
			
				// Check whether the transaction level producer is provided as additional producer
				if(additionalProducerMap.get(transactionData.getTparty1().getPartyNo()) != null){					
					ngeException.throwException(NGEErrorCodes.TXN_PRD_ADDNL_SAME,NGEErrorCodes.ERROR_TYPE, null, null);
				}
			
			for (AdditionalProducerDetail aItem:aList) {
				actionValue=aItem.getAction().value();
				if(actionValue.equalsIgnoreCase(NGEConstants.ACTION_CREATE)){
					
					producerDetail = producerResolver.getProducer(aItem.getProducerCd());					
					
					Tparty party = partyDAO.getProducerOrAgentParty(aItem.getProducerCd(),NGEConstants.PartyType.PRODUCER); 
	                    
					if (party == null) {
						
						party = partyDAO.createParty(aItem.getProducerCd(), NGEConstants.PartyType.PRODUCER);
						partyDAO.createProducer(party.getPartyId(), producerDetail.getProducerName());
						}
					
						/* 2021 MDM Changes - Starts */
						TtransactionParty transactionParty=transactionPartyRepository.findById(transactionVersionData.getId().getTransactionId(), transactionVersionData.getId().getVersionSqn(), party.getPartyId(), NGEConstants.NO);
						/* 2021 MDM Changes - Ends */
						if(transactionParty!=null){
							ngeException.throwException(NGEErrorCodes.DUPLICATE_ADDITIONAL_PRODUCER,NGEErrorCodes.ERROR_TYPE, "Duplicate Additional Producer found", null);
						}else{
						TtransactionPartyPK transPartyPK = new TtransactionPartyPK();
						transPartyPK.setTransactionId(transactionVersionData.getId().getTransactionId());
						transPartyPK.setVersionSqn(transactionVersionData.getId().getVersionSqn());
						transPartyPK.setPartySqn((short)partySqn);
						transPartyPK.setPartyId(party.getPartyId());

						Trole role = new Trole();
						role.setRoleId((short)2); 

						TtransactionParty transParty = new TtransactionParty();
						transParty.setId(transPartyPK);
						transParty.setTrole(role);
						transParty.setSystemId(NGESession.getSessionData().getSystem().getSystemId());
						transParty.setDeletedIn("N"); 
						transParty.setCreateTs(NGEDateUtil.getTodayDate());
						transParty.setCreateUserId(NGESession.getSessionData().getUserId());

						transactionParties.add(transParty);
						partySqn++;
					
					}
				} else{
					ngeException.throwException(NGEErrorCodes.INVALID_ADDITIONAL_PRODUCER_ACTION, NGEErrorCodes.ERROR_TYPE, "Unsupported operation for adding an additional producer", null);
				}
				
			}
		}
		if (transactionParties.size() > 0) {
			transactionVersionData.setTtransactionParties(transactionParties);
		}

		// Transaction party table
		TproductTower tProductTowerData = new TproductTower();
		List<TproductTowerAttribute> tProductTowerAttributeDataForTransactionAttributes = new ArrayList<TproductTowerAttribute>();
		tProductTowerData = productDAO.getProductTowerBySegmentandSubSegmentCd(NGEConstants.SEGMENT_ALL_CD, NGEConstants.SUB_SEGMENT_ALL_CD);
		
		tProductTowerAttributeDataForTransactionAttributes = commonServiceHelper.getMandatoryAttribute(tProductTowerData.getProductTowerId(), NGEConstants.TRANSACTION_ATTRIBUTE, null);
		
		
		Set<TtransactionAttribute> transactionAttributesData = new HashSet<TtransactionAttribute>();
		if (transactionAttributes != null
				&& transactionAttributes.getAttribute() != null
				&& transactionAttributes.getAttribute().size() > 0) {
			List<Attribute> aList = transactionAttributes.getAttribute();
			Map<String, Short> attributeSqnMap = new HashMap<String, Short>();
			List<TtableAttributeReference> tTableAttributeReferenceList = null;
			List<TtableAttributeReference> tTableAttributeReferenceValuesList = null;
			Ttable tableData =  new Ttable();
			boolean isMandatoryCheckNeeded = true;
			TproductTower productTowerData = new TproductTower();
			
			//Validation of Transaction level attributes
			productTowerData = productDAO.getProductTowerBySegmentandSubSegmentCd(NGEConstants.SEGMENT_ALL_CD, NGEConstants.SUB_SEGMENT_ALL_CD);
			commonServiceHelper.validateAttributeName(productTowerData.getProductTowerId(),NGEConstants.TRANSACTION_ATTRIBUTE,aList, NGEConstants.AttributeLevel.TRANSACTION, NGEConstants.ACTION_CREATE, null, isMandatoryCheckNeeded);
			
			for (Attribute aItem : aList) {
				String attributeName = aItem.getName();
				commonDAO.validateAttribute(
						NGEConstants.AttributeTable.TRANSACTION,
						aItem.getName());	
				
				Tattribute attributeData = attributeRepository
						.findByAttributeName(attributeName.toUpperCase());
				if (attributeData == null
						|| attributeData.getAttributeId() <= 0) {
					List<Object> errorFieldList=new ArrayList<Object>();		           
					errorFieldList.add(attributeName);
					ngeException.throwException(
							NGEErrorCodes.INVALID_ATTRIBUTEID,
							NGEErrorCodes.ERROR_TYPE, "Unable to find attribute id for attribute name", errorFieldList);
				} else {
					
					tableData = tableDAO.getTableData(NGEConstants.TRANSACTION_ATTRIBUTE);
					short tableId = tableData.getTableId();
					
					tTableAttributeReferenceList=attributeDAO.getReferenceDataByTabeIdAndAttributeName(tableId,attributeName);
					if(tTableAttributeReferenceList!=null && tTableAttributeReferenceList.size()>0){
						
							List<Object> errorReason=new ArrayList<Object>();
							errorReason.add(aItem.getAttributeValue());
							errorReason.add(aItem.getName());
							tTableAttributeReferenceValuesList=attributeDAO.getReferenceDataByReferenceValue(tableId, attributeName, aItem.getAttributeValue());
							if(tTableAttributeReferenceValuesList==null || tTableAttributeReferenceValuesList.size()==0){
								ngeException.throwException(
										NGEErrorCodes.ATTRIBUTE_VALUE_NOT_ALLOWED,
										NGEErrorCodes.ERROR_TYPE, "Attribute value "+aItem.getAttributeValue()+"is not allowed", errorReason);
							}						
					}
					
						if (!attributeSqnMap.containsKey(attributeName))
							attributeSqnMap.put(attributeName, new Short(
									(short) 1));
						short attributeSqn = attributeSqnMap.get(attributeName);
						attributeSqnMap.put(attributeName, new Short(
								(short) (attributeSqn + 1)));

						TtransactionAttributePK transAttributePK = new TtransactionAttributePK();
						transAttributePK
								.setTransactionId(transactionVersionData
										.getId().getTransactionId());
						transAttributePK.setVersionSqn(transactionVersionData
								.getId().getVersionSqn());
						transAttributePK.setAttributeId(attributeData
								.getAttributeId());
						transAttributePK.setAttributeSqn(attributeSqn);

						TtransactionAttribute thisAttributeData = new TtransactionAttribute();
						thisAttributeData.setId(transAttributePK);
						thisAttributeData.setAttributeVal(aItem.getAttributeValue());
						thisAttributeData.setTattribute(attributeData);
						thisAttributeData.setSystemId(NGESession.getSessionData().getSystem().getSystemId());
						thisAttributeData.setCreateTs(NGEDateUtil
								.getTodayDate());
						thisAttributeData.setCreateUserId(NGESession.getSessionData().getUserId());

						transactionAttributesData.add(thisAttributeData);					
				}
			}
		}
		else if(null == transactionAttributes && null != tProductTowerAttributeDataForTransactionAttributes && !tProductTowerAttributeDataForTransactionAttributes.isEmpty()){
			String mandatoryAttributes = null;
			for(TproductTowerAttribute productTowerAttribute : tProductTowerAttributeDataForTransactionAttributes)
			{
				if(mandatoryAttributes == null)
				{
					mandatoryAttributes = productTowerAttribute.getTattribute().getAttributeNm();
				}
				else
				{
					mandatoryAttributes = mandatoryAttributes +" , " + productTowerAttribute.getTattribute().getAttributeNm();
				}
			}
			
			List<Object> errorReason=new ArrayList<Object>();
			errorReason.add(mandatoryAttributes);
			errorReason.add(NGEConstants.AttributeLevel.TRANSACTION);
			ngeException.throwException(NGEErrorCodes.MANDATORY_ATTRIBUTES_NOT_PRESENT,NGEErrorCodes.ERROR_TYPE, null, errorReason);
		}
		
		
		if (transactionAttributesData.size() > 0) {
			transactionVersionData
					.setTtransactionAttributes(transactionAttributesData);
		}
		
		logger.info("Transaction Id :" + transactionVersionData.getId().getTransactionId() + "Version Number :"	+ transactionVersionData.getId().getVersionSqn());

		return transactionVersionData;

	}

	public Ttransaction populateTransaction(Tsubmission submissionData,
			Tparty underwriterData, Tparty producerData, Tparty agentData,
			Tbranch branchData, 
			TmailingAddress addressData, Broker producerContact) throws AIGCIExceptionMsg {
		Ttransaction transactionData = new Ttransaction();

		try {

			//transactionData
				//	.setTransactionId(String.valueOf(getTransactionId()));
			transactionData.setTsubmission(submissionData);
			transactionData.setTparty3(underwriterData);
			transactionData.setTparty1(producerData);
			transactionData.setTparty2(agentData);
			
			transactionData.setTbranch(branchData);
			transactionData.setSystemId(NGESession.getSessionData().getSystem().getSystemId());
			transactionData.setCreateTs(NGEDateUtil.getTodayDate());
			transactionData.setCreateUserId(NGESession.getSessionData().getUserId());
			
			if (addressData != null) {
				transactionData.setTmailingAddress(addressData);
			}

			transactionData = transactionRepository.save(transactionData);
			
			TproducerContact producerContactData = partyDAO
					.populateProducerContact(producerContact, 
							transactionData);
			if (producerContactData != null) {
				Set<TproducerContact> producerContactSet = new HashSet<TproducerContact>();
				producerContactSet.add(producerContactData);
				transactionData.setTproducerContacts(producerContactSet);
			}
			
		} catch (Exception e) {
			/* 2021 PI1 F38409 JPA Cache Retry Issue Fix starts */
			if(commonServiceHelper.checkForRetryExceptions(e, 119, NGEConstants.CatchExceptionTypes.THROW_HANDLED_EXCEPTION))
			{
				logger.error("checkForRetryExceptions returned true");
			}
			/* 2021 PI1 F38409 JPA Cache Retry Issue Fix ends */

			logger.error("Exception Message :" +e.getMessage());
			ngeException.throwException(NGEErrorCodes.INSERTION_FAILED,
					NGEErrorCodes.ERROR_TYPE, "Unable to insert Transaction Details", null);
		}

		logger.info("Transaction Id :" + transactionData.getTransactionId());

		return transactionData;

	}

	public void saveTransaction(Ttransaction transactionData,
			TtransactionVersion transactionVersionData) {
		Set<TtransactionVersion> transactionVersionSets = new HashSet<TtransactionVersion>();
		transactionVersionSets.add(transactionVersionData);
		transactionData.setTtransactionVersions(transactionVersionSets);

		transactionData = transactionRepository.save(transactionData);
	}

/*	public Long getTransactionId() throws AIGCIExceptionMsg {
		HashMap<String, String> sequenceNames = new HashMap<>();
		sequenceNames.put(NGEConstants.Sequence.TRANSACTION_ID, "LONG");
		HashMap<String, Object> outputSequenceMap = sequenceNumberGeneration.getNextSequenceNumber(sequenceNames);
		Long transactionId = Long.parseLong(outputSequenceMap.get(NGEConstants.Sequence.TRANSACTION_ID).toString());
		
		return transactionId;
	}*/

	public Ttransaction saveTransaction(Ttransaction transactionData) {
		transactionData = transactionRepository.save(transactionData);
		return transactionData;
	}

	public void deleteTransactionAttribute(
			TtransactionAttribute transactionAttribute) {
		transactionAttributeRepository.delete(transactionAttribute);

	}
	
	public void deleteTransactionAttributeList(
			List<TtransactionAttribute> transactionAttribute) {
		transactionAttributeRepository.delete(transactionAttribute);

	}
	
	public void moveTransactionAttributesListToHistory(
			List<TtransactionAttribute> transactionAttributes) throws AIGCIExceptionMsg {
		if(transactionAttributes != null && transactionAttributes.size() > 0){
			for(TtransactionAttribute transactionAttribute : transactionAttributes){
				historyHelper.createTransactionAttributeHistory(transactionAttribute);
			}
		}

	}
	

	public Short getMaxTransactionAttributeSqn(String transactionId, short versionNo, short attributeId) {

		Short attributeSqn = transactionAttributeRepository
				.getMaxAttributeSqn(transactionId, versionNo, attributeId);
		if(attributeSqn == null)
		{
			attributeSqn = 0;
		}
		return attributeSqn;
	}

	public List<TtransactionAttribute> getByAttributeId(String transactionId,
			short versionNo, short attributeId) {

		List<TtransactionAttribute> transactionAttributeData = transactionAttributeRepository
				.findById(transactionId, versionNo, attributeId);
		return transactionAttributeData;
	}

	public Tstatus getStatusDs(String transactionStatus) {
		Tstatus statusData = null;
		/*
		* EXADATA Migration Changes
		* 		Adding space for status name 
		*/

		if(transactionStatus.equals(NGEConstants.EMPTY_STRING))
			transactionStatus = NGEConstants.EMPTY_SPACE;
		
		statusData = statusRepository.findByStatusNm(transactionStatus.toUpperCase());
		return statusData;
	}

    
	/**
	 * 
	 * @param ttransactions
	 */
	public void saveTransactions(Set<Ttransaction> ttransactions) {
		transactionRepository.save(ttransactions);
	}
	
	public TtransactionVersion saveTransactionVersions(TtransactionVersion transactionVersionData ) {
		transactionVersionData=versionRepository.save(transactionVersionData);
		return transactionVersionData;
	}
	
	public String getSubmisionNo(String transactionId){
		String subNo=	transactionRepository.findBytransactionNo(transactionId);
		return subNo;
		
	}
	public Short findMaxVersionNo(String transactionId){
		Short versionNo=versionRepository.findMaxVersionNO(transactionId);
		if(versionNo == null)
		{
			versionNo=0;
		}
		return versionNo;
	}
	public List<TtransactionVersion> findVersionByTransactionId(
			String transactionId) throws AIGCIExceptionMsg {
		
		List<TtransactionVersion> transactionVersions = new ArrayList<TtransactionVersion>();

		transactionVersions = transactionVersionRepository.findByTransactionId(transactionId);
		return transactionVersions;
	
	}
	public TtransactionRelation getRelationByRelatedTransactionId(long transactionId,String relationType){
		TtransactionRelation transactionRelatedData=null;
		List<TtransactionRelation> transactionRelatedRecord=transactionRelationRepository.getRelationByRelatedTransactionId(String.valueOf(transactionId),relationType.toUpperCase());
		
		if (transactionRelatedRecord.size() > 0) {
			transactionRelatedData=transactionRelatedRecord.get(0);
		}
		return transactionRelatedData;
		
		
	}
	public TtransactionRelation getRelationByTransactionId(long transactionId,String relationType){
		TtransactionRelation transactionRelatedData=null;
		List<TtransactionRelation> transactionRelatedRecord=transactionRelationRepository.getRelationByTransactionId(String.valueOf(transactionId),relationType.toUpperCase());
		
		if (transactionRelatedRecord.size() > 0) {
			transactionRelatedData=transactionRelatedRecord.get(0);
		}
		return transactionRelatedData;
		
		
	}
	
	public TrelationType getTransactionRelationByType(String relationType) throws AIGCIExceptionMsg
	{
		TrelationType relationTypeData=null;
		List<Object> errorFieldList=new ArrayList<Object>();
		List<TrelationType> realtionTypeList=transactionRelationTypeRepository.findByRelationTypeNm(relationType.toUpperCase());
		
		if (realtionTypeList.size() == 1) {
			relationTypeData = realtionTypeList.get(0);
		}else if (realtionTypeList.size() == 0){
			errorFieldList.add(relationType);
			ngeException.throwException(NGEErrorCodes.NO_TRANSACTION_RELATION_TYPE, NGEErrorCodes.ERROR_TYPE, null,errorFieldList);
		}else{
			errorFieldList.add(relationType);
			ngeException.throwException(NGEErrorCodes.DUPLICATE_TRANSACTION_RELATION_TYPE, NGEErrorCodes.ERROR_TYPE, null,errorFieldList);
		}
		
		return relationTypeData;
	}
/*	
	*//**
	 * Author Nandhakumar
	 * @param transactionId
	 * @return
	 * @throws AIGCIExceptionMsg
	 */
		public TtransactionVersion getBoundTransaction(String transactionId)throws AIGCIExceptionMsg{
			TtransactionVersion transationVersion = null;
			transationVersion = transactionVersionRepository.findByTransactionIdAndBoundIn(transactionId,NGEConstants.YES);
			return transationVersion;
		}
		
		public List<TtransactionVersion> getBoundedTransactions(String transactionId)throws AIGCIExceptionMsg{
			List<TtransactionVersion> transationVersion = null;
			transationVersion = transactionVersionRepository.findByTransactionIdAndBoundInd(transactionId,NGEConstants.YES);
			return transationVersion;
		}
		
		
		
		/**
		 * 
		 * @param attrName
		 * @param attrVal
		 * @return TtransactionProductAttribute list
		 */
		/*public List<TtransactionProductAttribute> getMarketableProductUnderwriter(String attrName, String attrVal, String segmentCd, String subSegmentCd, TproductTowerDivision productTowerDivision) {
			return tTransactionProductAttributeRepository.getMarketableProductUnderwriter(attrName, attrVal, segmentCd, subSegmentCd, productTowerDivision);
		}*/
		public List<TtransactionProductAttribute> getMarketableProductUnderwriter(String attrName, String attrVal,Set<Integer> productList){
			List<TtransactionProductAttribute> marketableProUnderWriters=null; 
		 marketableProUnderWriters=tTransactionProductAttributeRepository.getMarketableProductUnderwriter(attrName, attrVal,productList);
		 return marketableProUnderWriters;
	     }
		
		
		/**
		 * 
		 * @param attrName
		 * @param attrVal
		 * @return productId list
		 */
		public List<Integer> getProductIdByAttrNameAndValue(String attrName, String attrVal,String deletedIn) {
			return tTransactionProductAttributeRepository.getProductIdByAttrNameAndValue(attrName, attrVal, deletedIn);
		}

		public List<TtransactionVersion> getVersionList(Ttransaction transactionData, List<TtransactionVersion>transactionVersionsList) throws AIGCIExceptionMsg {
			transactionVersionsList=getBoundedTransactions(transactionData.getTransactionId());
			
			if(transactionVersionsList.size()==0){
				
				transactionVersionsList=findVersionByTransactionId(transactionData.getTransactionId());
			}	
			return transactionVersionsList;
		}

		public void transferTtransactionUnderwriter(String fromUwEmpId, String toUwEmpId)
		{
			List<Ttransaction> transaction=new ArrayList<Ttransaction>();
			transaction = transactionRepository.getByUnderWriterId(Integer.valueOf(fromUwEmpId));
			for(Ttransaction transObj: transaction)
			{
				logger.debug("Transaction Id:"+transObj.getTransactionId());
				logger.debug("Underwriter Id:"+transObj.getTparty3().getPartyId());
			}
		}
		
		public int updateNewUnderwriter(int fromUwId, int toUwId, String userId, Timestamp currentTs)
		{
			int count = transactionRepository.changeUnderwriter(fromUwId, toUwId, userId, currentTs);
			return count;
		}
		
		public Set<Integer> getMarketableProductDetail(
				String segmentCd, String subSegmentCd) {
			Set<Integer> marketableProducts = new HashSet<Integer>(); 
			List<VcomponentProduct> vComponentProductsList = null;
			
			vComponentProductsList = vComponentProductRepository.getProductIdBySegmentCdandSubsegmenCd(segmentCd,subSegmentCd);
			
			if(vComponentProductsList != null && !vComponentProductsList.isEmpty()){
				
				for(VcomponentProduct vComponentProductData : vComponentProductsList){
					
					if(vComponentProductData.getComponentProductDeletedIn().equalsIgnoreCase(NGEConstants.YES) || 
							vComponentProductData.getProductDetailDeletedIn().equalsIgnoreCase(NGEConstants.YES)){
						
						if(NGESession.getSessionData().getClientId() != null){
							
							if(NGESession.getSessionData().getClientId().equalsIgnoreCase(NGEConstants.LEGACY_CONSUMERS)){
								
								marketableProducts.add(vComponentProductData.getId().getProductDetailId());
							}
						}
					}
					else{
						
						marketableProducts.add(vComponentProductData.getId().getProductDetailId());
					}
				}
			}
			return marketableProducts;
		}		
}
