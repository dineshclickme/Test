package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SetAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-02-19T16:13:03.579+0530")
@StaticMetamodel(TmarketableProduct.class)
public class TmarketableProduct_ {
	public static volatile SingularAttribute<TmarketableProduct, Integer> marketableProductId;
	public static volatile SingularAttribute<TmarketableProduct, Timestamp> createTs;
	public static volatile SingularAttribute<TmarketableProduct, String> createUserId;
	public static volatile SingularAttribute<TmarketableProduct, String> deletedIn;
	public static volatile SingularAttribute<TmarketableProduct, String> marketableProductCd;
	public static volatile SingularAttribute<TmarketableProduct, String> marketableProductNm;
	public static volatile SingularAttribute<TmarketableProduct, Timestamp> updateTs;
	public static volatile SingularAttribute<TmarketableProduct, String> updateUserId;
	public static volatile SingularAttribute<TmarketableProduct, Tproduct> tproduct;
	public static volatile SingularAttribute<TmarketableProduct, TproductTower> tproductTower;
	public static volatile SetAttribute<TmarketableProduct, TmarketableProductComponent> tmarketableProductComponents;
}
