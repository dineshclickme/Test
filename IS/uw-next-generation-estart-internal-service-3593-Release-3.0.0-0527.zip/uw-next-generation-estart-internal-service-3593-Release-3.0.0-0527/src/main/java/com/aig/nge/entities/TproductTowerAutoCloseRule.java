package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;

import org.apache.openjpa.persistence.DataCache;
import java.sql.Timestamp;


/**
 * The persistent class for the TPRODUCT_TOWER_AUTO_CLOSE_RULE database table.
 * 
 */
@Entity
@DataCache
@Table(name="TPRODUCT_TOWER_AUTO_CLOSE_RULE")
public class TproductTowerAutoCloseRule implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="AUTO_CLOSE_RULE_ID")
	private int autoCloseRuleId;

	@Column(name="ALLOWABLE_EXTENSIONS_NO")
	private short allowableExtensionsNo;

	@Column(name="AUTO_CLOSE_DAYS_NO")
	private short autoCloseDaysNo;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="CREATE_TS")
	private Timestamp createTs;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="CREATE_USER_ID")
	private String createUserId;

	@Column(name="DAYS_PER_EXTENSION_NO")
	private short daysPerExtensionNo;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="UPDATE_TS")
	private Timestamp updateTs;
	
	@Basic(fetch=FetchType.LAZY)
	@Column(name="UPDATE_USER_ID")
	private String updateUserId;

	//bi-directional many-to-one association to TproductTower
	@ManyToOne
	@JoinColumn(name="PRODUCT_TOWER_ID")
	private TproductTower tproductTower;

	//bi-directional many-to-one association to Tstatus
	@ManyToOne
	@JoinColumn(name="RESERVATION_STATUS_ID")
	private Tstatus tstatus1;

	//bi-directional many-to-one association to Tstatus
	@ManyToOne
	@JoinColumn(name="STATUS_ID")
	private Tstatus tstatus2;

	//bi-directional many-to-one association to Tstatus
	@ManyToOne
	@JoinColumn(name="STATUS_AFTER_AUTO_CLOSE_ID")
	private Tstatus tstatus3;

	//bi-directional many-to-one association to Tstatus
	@ManyToOne
	@JoinColumn(name="RESRVN_STAT_AFTER_AUTO_CLOS_ID")
	private Tstatus tstatus4;

    public TproductTowerAutoCloseRule() {
    }

	public int getAutoCloseRuleId() {
		return this.autoCloseRuleId;
	}

	public void setAutoCloseRuleId(int autoCloseRuleId) {
		this.autoCloseRuleId = autoCloseRuleId;
	}

	public short getAllowableExtensionsNo() {
		return this.allowableExtensionsNo;
	}

	public void setAllowableExtensionsNo(short allowableExtensionsNo) {
		this.allowableExtensionsNo = allowableExtensionsNo;
	}

	public short getAutoCloseDaysNo() {
		return this.autoCloseDaysNo;
	}

	public void setAutoCloseDaysNo(short autoCloseDaysNo) {
		this.autoCloseDaysNo = autoCloseDaysNo;
	}

	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public short getDaysPerExtensionNo() {
		return this.daysPerExtensionNo;
	}

	public void setDaysPerExtensionNo(short daysPerExtensionNo) {
		this.daysPerExtensionNo = daysPerExtensionNo;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public TproductTower getTproductTower() {
		return this.tproductTower;
	}

	public void setTproductTower(TproductTower tproductTower) {
		this.tproductTower = tproductTower;
	}
	
	public Tstatus getTstatus1() {
		return this.tstatus1;
	}

	public void setTstatus1(Tstatus tstatus1) {
		this.tstatus1 = tstatus1;
	}
	
	public Tstatus getTstatus2() {
		return this.tstatus2;
	}

	public void setTstatus2(Tstatus tstatus2) {
		this.tstatus2 = tstatus2;
	}
	
	public Tstatus getTstatus3() {
		return this.tstatus3;
	}

	public void setTstatus3(Tstatus tstatus3) {
		this.tstatus3 = tstatus3;
	}
	
	public Tstatus getTstatus4() {
		return this.tstatus4;
	}

	public void setTstatus4(Tstatus tstatus4) {
		this.tstatus4 = tstatus4;
	}
	
}