package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SetAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-02-25T15:44:17.623+0530")
@StaticMetamodel(TproductTowerAttribute.class)
public class TproductTowerAttribute_ {
	public static volatile SingularAttribute<TproductTowerAttribute, TproductTowerAttributePK> id;
	public static volatile SingularAttribute<TproductTowerAttribute, String> allowMultipleIn;
	public static volatile SingularAttribute<TproductTowerAttribute, Timestamp> createTs;
	public static volatile SingularAttribute<TproductTowerAttribute, String> createUserId;
	public static volatile SingularAttribute<TproductTowerAttribute, String> deletedIn;
	public static volatile SingularAttribute<TproductTowerAttribute, String> labelNm;
	public static volatile SingularAttribute<TproductTowerAttribute, String> mandatoryIn;
	public static volatile SingularAttribute<TproductTowerAttribute, Short> orderSqn;
	public static volatile SingularAttribute<TproductTowerAttribute, Timestamp> updateTs;
	public static volatile SingularAttribute<TproductTowerAttribute, String> updateUserId;
	public static volatile SingularAttribute<TproductTowerAttribute, Tattribute> tattribute;
	public static volatile SingularAttribute<TproductTowerAttribute, TproductTower> tproductTower;
	public static volatile SingularAttribute<TproductTowerAttribute, TtableAttribute> ttableAttribute;
	public static volatile SetAttribute<TproductTowerAttribute, TproductTowerAttributeUsage> tproductTowerAttributeUsages;
}
