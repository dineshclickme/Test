package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the TTRANSACTION_CMPNT_BRANCH_HS database table.
 * 
 */
@Embeddable
public class TtransactionCmpntBranchHPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="TRANSACTION_COMPONENT_ID")
	private String transactionComponentId;

	@Column(name="BRANCH_TYPE_ID")
	private short branchTypeId;

    @Temporal( TemporalType.TIMESTAMP)
	@Column(name="CREATE_HISTORY_TS")
	private java.util.Date createHistoryTs;

    public TtransactionCmpntBranchHPK() {
    }
	public String getTransactionComponentId() {
		return this.transactionComponentId;
	}
	public void setTransactionComponentId(String transactionComponentId) {
		this.transactionComponentId = transactionComponentId;
	}
	public short getBranchTypeId() {
		return this.branchTypeId;
	}
	public void setBranchTypeId(short branchTypeId) {
		this.branchTypeId = branchTypeId;
	}
	public java.util.Date getCreateHistoryTs() {
		return this.createHistoryTs;
	}
	public void setCreateHistoryTs(java.util.Date createHistoryTs) {
		this.createHistoryTs = createHistoryTs;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof TtransactionCmpntBranchHPK)) {
			return false;
		}
		TtransactionCmpntBranchHPK castOther = (TtransactionCmpntBranchHPK)other;
		return 
			this.transactionComponentId.equals(castOther.transactionComponentId)
			&& (this.branchTypeId == castOther.branchTypeId)
			&& this.createHistoryTs.equals(castOther.createHistoryTs);

    }
    
	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.transactionComponentId.hashCode();
		hash = hash * prime + ((int) this.branchTypeId);
		hash = hash * prime + this.createHistoryTs.hashCode();
		
		return hash;
    }
}