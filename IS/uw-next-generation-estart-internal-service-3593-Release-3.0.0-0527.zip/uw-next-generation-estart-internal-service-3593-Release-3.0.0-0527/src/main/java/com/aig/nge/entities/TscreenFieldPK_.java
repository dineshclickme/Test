package com.aig.nge.entities;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-02-19T16:13:04.396+0530")
@StaticMetamodel(TscreenFieldPK.class)
public class TscreenFieldPK_ {
	public static volatile SingularAttribute<TscreenFieldPK, Short> screenId;
	public static volatile SingularAttribute<TscreenFieldPK, Short> fieldId;
}
