package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the THELP_LANGUAGE database table.
 * 
 */
@Entity
@Table(name="THELP_LANGUAGE")
public class ThelpLanguage implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private ThelpLanguagePK id;

	@Column(name="CREATE_TS")
	private Timestamp createTs;

	@Column(name="CREATE_USER_ID")
	private String createUserId;

	@Column(name="HELP_TX")
	private String helpTx;

	@Column(name="UPDATE_TS")
	private Timestamp updateTs;

	@Column(name="UPDATE_USER_ID")
	private String updateUserId;

	//bi-directional many-to-one association to Thelp
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="HELP_ID")
	private Thelp thelp;

	//bi-directional many-to-one association to Tlanguage
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="LANGUAGE_ID")
	private Tlanguage tlanguage;

    public ThelpLanguage() {
    }

	public ThelpLanguagePK getId() {
		return this.id;
	}

	public void setId(ThelpLanguagePK id) {
		this.id = id;
	}
	
	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public String getHelpTx() {
		return this.helpTx;
	}

	public void setHelpTx(String helpTx) {
		this.helpTx = helpTx;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public Thelp getThelp() {
		return this.thelp;
	}

	public void setThelp(Thelp thelp) {
		this.thelp = thelp;
	}
	
	public Tlanguage getTlanguage() {
		return this.tlanguage;
	}

	public void setTlanguage(Tlanguage tlanguage) {
		this.tlanguage = tlanguage;
	}
	
}