package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the TLEGACY_LEAD_SUBTYPE database table.
 * 
 */
@Embeddable
public class TlegacyLeadSubtypePK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="SOURCE_CD")
	private String sourceCd;

	@Column(name="LEAD_TYPE_CD")
	private String leadTypeCd;

	@Column(name="LEAD_SUBTYPE_CD")
	private String leadSubtypeCd;

    public TlegacyLeadSubtypePK() {
    }
	public String getSourceCd() {
		return this.sourceCd;
	}
	public void setSourceCd(String sourceCd) {
		this.sourceCd = sourceCd;
	}
	public String getLeadTypeCd() {
		return this.leadTypeCd;
	}
	public void setLeadTypeCd(String leadTypeCd) {
		this.leadTypeCd = leadTypeCd;
	}
	public String getLeadSubtypeCd() {
		return this.leadSubtypeCd;
	}
	public void setLeadSubtypeCd(String leadSubtypeCd) {
		this.leadSubtypeCd = leadSubtypeCd;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof TlegacyLeadSubtypePK)) {
			return false;
		}
		TlegacyLeadSubtypePK castOther = (TlegacyLeadSubtypePK)other;
		return 
			this.sourceCd.equals(castOther.sourceCd)
			&& this.leadTypeCd.equals(castOther.leadTypeCd)
			&& this.leadSubtypeCd.equals(castOther.leadSubtypeCd);

    }
    
	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.sourceCd.hashCode();
		hash = hash * prime + this.leadTypeCd.hashCode();
		hash = hash * prime + this.leadSubtypeCd.hashCode();
		
		return hash;
    }
}