package com.aig.nge.entities;

import java.util.Date;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-03-02T12:10:25.027+0530")
@StaticMetamodel(TtransactionAttributeHPK.class)
public class TtransactionAttributeHPK_ {
	public static volatile SingularAttribute<TtransactionAttributeHPK, String> transactionId;
	public static volatile SingularAttribute<TtransactionAttributeHPK, Short> versionSqn;
	public static volatile SingularAttribute<TtransactionAttributeHPK, Short> attributeId;
	public static volatile SingularAttribute<TtransactionAttributeHPK, Short> attributeSqn;
	public static volatile SingularAttribute<TtransactionAttributeHPK, Date> createHistoryTs;
}
