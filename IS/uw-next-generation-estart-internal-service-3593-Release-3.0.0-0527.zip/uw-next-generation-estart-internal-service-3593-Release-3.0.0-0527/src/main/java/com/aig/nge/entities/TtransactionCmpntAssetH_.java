package com.aig.nge.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-03-02T12:10:25.043+0530")
@StaticMetamodel(TtransactionCmpntAssetH.class)
public class TtransactionCmpntAssetH_ {
	public static volatile SingularAttribute<TtransactionCmpntAssetH, TtransactionCmpntAssetHPK> id;
	public static volatile SingularAttribute<TtransactionCmpntAssetH, Timestamp> createTs;
	public static volatile SingularAttribute<TtransactionCmpntAssetH, String> createUserId;
	public static volatile SingularAttribute<TtransactionCmpntAssetH, String> deletedIn;
	public static volatile SingularAttribute<TtransactionCmpntAssetH, Short> systemId;
	public static volatile SingularAttribute<TtransactionCmpntAssetH, String> updateUserId;
	public static volatile SingularAttribute<TtransactionCmpntAssetH, Timestamp> updateTs;
}
