package com.aig.nge.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Set;


/**
 * The persistent class for the TFORMAT database table.
 * 
 */
@Entity
public class Tformat implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="FORMAT_ID")
	private short formatId;

	@Column(name="CREATE_TS")
	private Timestamp createTs;

	@Column(name="CREATE_USER_ID")
	private String createUserId;

	@Column(name="FORMAT_DS")
	private String formatDs;

	@Column(name="FORMAT_VAL")
	private String formatVal;

	@Column(name="UPDATE_TS")
	private Timestamp updateTs;

	@Column(name="UPDATE_USER_ID")
	private String updateUserId;

	//bi-directional many-to-one association to TuserPrefernce
	@OneToMany(mappedBy="tformat1", cascade={CascadeType.ALL})
	private Set<TuserPrefernce> tuserPrefernces1;

	//bi-directional many-to-one association to TuserPrefernce
	@OneToMany(mappedBy="tformat2", cascade={CascadeType.ALL})
	private Set<TuserPrefernce> tuserPrefernces2;

    public Tformat() {
    }

	public short getFormatId() {
		return this.formatId;
	}

	public void setFormatId(short formatId) {
		this.formatId = formatId;
	}

	public Timestamp getCreateTs() {
		return this.createTs;
	}

	public void setCreateTs(Timestamp createTs) {
		this.createTs = createTs;
	}

	public String getCreateUserId() {
		return this.createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public String getFormatDs() {
		return this.formatDs;
	}

	public void setFormatDs(String formatDs) {
		this.formatDs = formatDs;
	}

	public String getFormatVal() {
		return this.formatVal;
	}

	public void setFormatVal(String formatVal) {
		this.formatVal = formatVal;
	}

	public Timestamp getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Timestamp updateTs) {
		this.updateTs = updateTs;
	}

	public String getUpdateUserId() {
		return this.updateUserId;
	}

	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	public Set<TuserPrefernce> getTuserPrefernces1() {
		return this.tuserPrefernces1;
	}

	public void setTuserPrefernces1(Set<TuserPrefernce> tuserPrefernces1) {
		this.tuserPrefernces1 = tuserPrefernces1;
	}
	
	public Set<TuserPrefernce> getTuserPrefernces2() {
		return this.tuserPrefernces2;
	}

	public void setTuserPrefernces2(Set<TuserPrefernce> tuserPrefernces2) {
		this.tuserPrefernces2 = tuserPrefernces2;
	}
	
}