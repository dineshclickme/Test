package com.util;

import java.io.File;
import java.io.FileInputStream;
import java.util.Properties;

public class ConfigManager {
	public static final String INPUT_DIR;
	public static final String OUTPUT_DIR;
	public static final String CES_URL;
	public static final String PROXY_HOST;
	public static final int PROXY_PORT;
	public static final int THREAD_POOL_SIZE;
	private static final Properties properties = new Properties();

	static {
		try {
//			System.out.println("Loading Configuration from file "					+ System.getProperty("conf"));
			properties.load(new FileInputStream(new File("conf.properties")));
		} catch (Exception e) {
			e.printStackTrace();
		}

		INPUT_DIR = properties.getProperty("INPUT_DIR");
		OUTPUT_DIR = properties.getProperty("OUTPUT_DIR");
		CES_URL = properties.getProperty("CES_URL");
		PROXY_HOST = properties.getProperty("PROXY_HOST");
		int temp = 5;
		try {
			temp = Integer.parseInt(properties.getProperty("THREAD_POOL_SIZE"));

			if (temp > 3000) {
				temp = 50;
			}
		} catch (Exception e) {
			temp = 5;
		}

		THREAD_POOL_SIZE = temp;

		int tempPort = -1;
		try {
			tempPort = Integer.parseInt(properties.getProperty("PROXY_PORT"));
		} catch (Exception e) {
			System.out.println("No Proxy");
		}

		PROXY_PORT = tempPort;

		System.out.println("Loaded Configuration");
		
		System.out.println("Thread Pool Size " + THREAD_POOL_SIZE);
		System.out.println();
	}

	public static String getPropertyString(String propName, String defaultValue) {
		return properties.getProperty(propName, defaultValue);
	}
}