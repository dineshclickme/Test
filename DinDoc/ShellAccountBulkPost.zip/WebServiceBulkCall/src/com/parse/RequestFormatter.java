package com.parse;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.StringTokenizer;

import com.util.ConfigManager;

public class RequestFormatter {
	private static final String pattern;
	public static final boolean ONLY_XML;

	static {
		String variables = ConfigManager.getPropertyString("REQUEST.VARS", "");
		StringTokenizer varTokens = new StringTokenizer(variables, ",");
		String tempPattern = ConfigManager.getPropertyString("REQUEST_PATTERN",
				"[INPUT_FILE]");

		while (varTokens.hasMoreTokens()) {
			String variable = varTokens.nextToken();
			try {
				tempPattern = replace(
						tempPattern,
						"[" + variable + "]",
						URLEncoder.encode(
								ConfigManager.getPropertyString("REQUEST."
										+ variable, ""), "UTF-8"), -1);
			} catch (UnsupportedEncodingException e) {
				e.printStackTrace();
			}
		}

		pattern = tempPattern;

		if (pattern.equals("[INPUT_FILE]")) {
			ONLY_XML = true;
			System.out.println("Only XML");
		} else {
			ONLY_XML = false;
			System.out.println("XML with param");
		}
	}

	public static String format(String request) {
		try {
			return replace(pattern, "[INPUT_FILE]",
					URLEncoder.encode(request, "UTF-8"), -1);
		} catch (UnsupportedEncodingException e) {
		}
		return replace(pattern, "[INPUT_FILE]", request, -1);
	}

	public static String replace(String text, String repl, String with, int max) {
		if ((text == null) || (isEmpty(repl)) || (with == null) || (max == 0)) {
			return text;
		}

		StringBuffer buf = new StringBuffer(text.length());
		int start = 0;
		int end = 0;
		while ((end = text.indexOf(repl, start)) != -1) {
			buf.append(text.substring(start, end)).append(with);
			start = end + repl.length();

			if (--max == 0) {
				break;
			}
		}
		buf.append(text.substring(start));
		return buf.toString();
	}

	public static boolean isEmpty(String str) {
		return (str == null) || (str.length() == 0);
	}
}