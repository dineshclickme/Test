package com.parse;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringWriter;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

public class Parser {
	static boolean verbose = true;

	public static void writeOutput(Document toBeWritten, File outputXMLFile) {
		try {
			TransformerFactory tFactory = TransformerFactory.newInstance();
			Transformer transformer = tFactory.newTransformer();
			transformer.setOutputProperty("indent", "yes");

			DOMSource source = new DOMSource(toBeWritten);
			StreamResult result = new StreamResult(outputXMLFile);
			if (verbose) {
				System.out.println("Writing signed XML to "
						+ outputXMLFile.toString() + " ...");
			}
			transformer.transform(source, result);
		} catch (Exception e) {
			usage(e);
		}
	}

	public static String getXMLString(Document doc) {
		try {
			DOMSource domSource = new DOMSource(doc);
			StringWriter writer = new StringWriter();
			StreamResult result = new StreamResult(writer);
			TransformerFactory tf = TransformerFactory.newInstance();
			Transformer transformer = tf.newTransformer();
			transformer.transform(domSource, result);
			return writer.toString();
		} catch (TransformerException ex) {
			ex.printStackTrace();
		}
		return null;
	}

	public static void usage(Exception e) {
		if (e != null) {
			System.err.println("Error!: ");
			e.printStackTrace();
			System.err.println();
		}
	}

	public static Document loadXMLFrom(String xml) throws SAXException,
			IOException {
		return loadXMLFrom(new ByteArrayInputStream(xml.getBytes()));
	}

	public static Document loadXMLFrom(InputStream is) throws SAXException,
			IOException {
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		factory.setNamespaceAware(true);
		DocumentBuilder builder = null;
		try {
			builder = factory.newDocumentBuilder();
		} catch (ParserConfigurationException localParserConfigurationException) {
		}
		Document doc = builder.parse(is);
		is.close();
		return doc;
	}

	public static Document parseInputXML(File input) {
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();

		factory.setNamespaceAware(true);
		Document parsedXML = null;
		try {
			System.out.println("Parsing input XML file ...");
			System.out.println("Input XML :" + input.toString());
			DocumentBuilder builder = factory.newDocumentBuilder();
			parsedXML = builder.parse(input);
		} catch (Exception e) {
			usage(e);
		}
		return parsedXML;
	}

	public static Document parseInputXML(InputStream input) {
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();

		factory.setNamespaceAware(true);
		Document parsedXML = null;
		try {
			System.out.println("Parsing input XML file ...");
			System.out.println("Input XML :" + input.toString());
			DocumentBuilder builder = factory.newDocumentBuilder();
			parsedXML = builder.parse(input);
		} catch (Exception e) {
			usage(e);
		}
		return parsedXML;
	}

	public static Document parseInputXML(InputSource input) {
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();

		factory.setNamespaceAware(true);
		Document parsedXML = null;
		try {
			System.out.println("Parsing input XML file ...");
			System.out.println("Input XML :" + input.toString());
			DocumentBuilder builder = factory.newDocumentBuilder();
			parsedXML = builder.parse(input);
		} catch (Exception e) {
			usage(e);
		}
		return parsedXML;
	}
}