package com.parse;

public class Bean {
	private String outputXML = "";
	private StringBuffer timedifference = null;

	public String getoutputXML() {
		return this.outputXML;
	}

	public void setoutputXML(String outputXML) {
		this.outputXML = outputXML;
	}

	public StringBuffer gettimedifference() {
		return this.timedifference;
	}

	public void settimedifference(StringBuffer timedifference) {
		this.timedifference = timedifference;
	}
}