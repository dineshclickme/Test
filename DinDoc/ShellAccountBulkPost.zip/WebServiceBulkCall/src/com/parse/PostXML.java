package com.parse;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;

import com.design.Main;

public class PostXML
{
  public static String postXMLString(String xmlStr, String fileName, boolean isInputXMLFile, String urlString, String proxyHostStr, int proxyPort,String rep,int count)
  {
    String soapresponse = null;
    try
    {
      if (isInputXMLFile)
      {
        File file = new File(fileName);
        BufferedReader br = new BufferedReader(new FileReader(file));
        StringBuffer xmlStrTemp = new StringBuffer();
        String line = null;
        while ((line = br.readLine()) != null) {
          xmlStrTemp.append(line);
        }
        xmlStr = xmlStrTemp.toString();
        xmlStr=xmlStr.replace(rep, rep+String.valueOf(count));
      }
      URL serviceURL = new URL(urlString);
      URLConnection con;
      if ((proxyHostStr != null) && (!proxyHostStr.trim().equals("")) && 
        (proxyPort > 0))
      {
        Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(
          proxyHostStr, proxyPort));
        con = serviceURL.openConnection(proxy);
      }
      else
      {
        con = serviceURL.openConnection();
      }
      HttpURLConnection httpserviceConnection = null;
      String result = null;
      
      httpserviceConnection = (HttpURLConnection)con;
      httpserviceConnection.setDoInput(true);
      httpserviceConnection.setDoOutput(true);
      httpserviceConnection.setUseCaches(false);
      httpserviceConnection.setRequestMethod("POST");
      if (RequestFormatter.ONLY_XML)
      {
        httpserviceConnection.setRequestProperty("Content-Type", 
          "text/xml; charset=utf-8");
        httpserviceConnection.setRequestProperty("SOAPAction", "");
      }
      else
      {
        httpserviceConnection.setRequestProperty("Content-Type", 
          "application/x-www-form-urlencoded");
      }
      httpserviceConnection.setRequestProperty("Accept-Charset", "UTF-8");
      httpserviceConnection.setRequestProperty("Content-Type", 
        "application/x-www-form-urlencoded;charset=UTF-8");
      



      httpserviceConnection.getOutputStream().write(
        getQuery("GATEWAY_XML", xmlStr).getBytes("UTF-8"));
      System.out.println(httpserviceConnection.getResponseCode());
      
      int rescode = httpserviceConnection.getResponseCode();
      



      InputStreamReader isr = null;
      if (httpserviceConnection.getErrorStream() != null) {
        isr = new InputStreamReader(
          httpserviceConnection.getErrorStream());
      } else {
        isr = new InputStreamReader(
          httpserviceConnection.getInputStream());
      }
      result = readData(isr);
      httpserviceConnection.disconnect();
      
      soapresponse = result;
    }
    catch (Exception e)
    {
      e.printStackTrace();
      Main.jtaStatus.append("Error:\n");
      Main.jtaStatus.append("------------\n");
      Main.jtaStatus.append(e.getMessage() + "\n");
      Main.flag = false;
      return "failed" + e.getMessage();
    }
    return soapresponse;
  }
  
  private static String readData(Reader in)
    throws IOException, Exception
  {
    int num = 0;
    char[] readBuf = new char[2048];
    StringBuffer buf = new StringBuffer();
    while ((num = in.read(readBuf, 0, readBuf.length)) != -1) {
      buf.append(readBuf, 0, num);
    }
    return buf.toString();
  }
  
  private static String getQuery(String name, String value)
    throws UnsupportedEncodingException
  {
    StringBuilder result = new StringBuilder();
    boolean first = true;
    
    result.append(URLEncoder.encode(name, "UTF-8"));
    result.append("=");
    result.append(URLEncoder.encode(value, "UTF-8"));
    
    return result.toString();
  }
}
