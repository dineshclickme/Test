package com.xml.convert;

//import GetSubmissionRequestBean;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

public class XMLWriter {
		 public static void writeXMLFile(List<GetSubmissionRequestBean> writeSubmissionRequest){

			for(GetSubmissionRequestBean writeRequest: writeSubmissionRequest){
		  try {

			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();

			// root element
			Document doc = docBuilder.newDocument();
			Element rootElement = doc.createElement("EStartGatewayXML");
			doc.appendChild(rootElement);

			Element ServiceName = doc.createElement("ServiceName");
			ServiceName.appendChild(doc.createTextNode("SubmissionService"));
			rootElement.appendChild(ServiceName);

			Element MethodName = doc.createElement("MethodName");
			MethodName.appendChild(doc.createTextNode("getSubmission"));
			rootElement.appendChild(MethodName);

			Element GatewayData = doc.createElement("GatewayData");
			rootElement.appendChild(GatewayData);

			Element SubmissionServiceXML = doc.createElement("SubmissionServiceXML");
			GatewayData.appendChild(SubmissionServiceXML);

			Element Identity = doc.createElement("Identity");
			SubmissionServiceXML.appendChild(Identity);

			Element applicationId = doc.createElement("application_id");
			applicationId.appendChild(doc.createTextNode("EST"));
			Identity.appendChild(applicationId);

			Element userId = doc.createElement("user_id");
			userId.appendChild(doc.createTextNode("EST"));
			Identity.appendChild(userId);

			Element password  = doc.createElement("password");
			Identity.appendChild(password );

			Element secureId  = doc.createElement("secured_id");
			Identity.appendChild(secureId );

			Element Request = doc.createElement("Request");
			SubmissionServiceXML.appendChild(Request);

			Element Arguments = doc.createElement("Arguments");
			Request.appendChild(Arguments);

			Element getSubmission = doc.createElement("getSubmission");
			Arguments.appendChild(getSubmission);

			Element SearchNumber = doc.createElement("SearchNumber");
			SearchNumber.appendChild(doc.createTextNode(writeRequest.getSearchNumber()));
			getSubmission.appendChild(SearchNumber);

			/*Element ProductCd = doc.createElement("ProductCd");
			ProductCd.appendChild(doc.createTextNode(writeRequest.getProductCd()));
			getSubmission.appendChild(ProductCd);

			Element ProductCoverageType  = doc.createElement("ProductCoverageType");
			getSubmission.appendChild(ProductCoverageType);

			Attr attr = doc.createAttribute("Options");
			attr.setValue(writeRequest.getProductCoverageTypeAttr());
			ProductCoverageType.setAttributeNode(attr);*/

			Element CurrentYearWipsOnly  = doc.createElement("CurrentYearWipsOnly");
			CurrentYearWipsOnly.appendChild(doc.createTextNode("N"));
			getSubmission.appendChild(CurrentYearWipsOnly);

			/*Element ExcludeSubmHeaderInfo  = doc.createElement("ExcludeSubmHeaderInfo");
			ExcludeSubmHeaderInfo.appendChild(doc.createTextNode("Y"));
			getSubmission.appendChild(ExcludeSubmHeaderInfo);*/

			Element ExcludeSubmAccountInfo  = doc.createElement("ExcludeSubmAccountInfo");
			ExcludeSubmAccountInfo.appendChild(doc.createTextNode("Y"));
			getSubmission.appendChild(ExcludeSubmAccountInfo);

			Element ExcludeSubmProducerInfo  = doc.createElement("ExcludeSubmProducerInfo");
			ExcludeSubmProducerInfo.appendChild(doc.createTextNode("Y"));
			getSubmission.appendChild(ExcludeSubmProducerInfo);

			/*Element CarrDiscrpRequired   = doc.createElement("CarrDiscrpRequired");
			getSubmission.appendChild(CarrDiscrpRequired );*/

			Element SICCodeRequired = doc.createElement("SICCodeRequired");
			SICCodeRequired.appendChild(doc.createTextNode("Y"));
			getSubmission.appendChild(SICCodeRequired);

			Element SubRecvDtRequired   = doc.createElement("SubRecvDtRequired");
			SubRecvDtRequired.appendChild(doc.createTextNode("Y"));
			getSubmission.appendChild(SubRecvDtRequired);

			Element PolmailDtRequired   = doc.createElement("PolmailDtRequired");
			PolmailDtRequired.appendChild(doc.createTextNode("Y"));
			getSubmission.appendChild(PolmailDtRequired);

			/*Element BrokerId    = doc.createElement("BrokerId");
			getSubmission.appendChild(BrokerId);

			Element EffectiveDt     = doc.createElement("EffectiveDt");
			getSubmission.appendChild(EffectiveDt);*/

			Element AIUBranchRequired     = doc.createElement("AIUBranchRequired");
			AIUBranchRequired.appendChild(doc.createTextNode("N"));
			getSubmission.appendChild(AIUBranchRequired);

			Element Response  = doc.createElement("Response");
			SubmissionServiceXML.appendChild(Response );

			// write the content into xml file
			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer = transformerFactory.newTransformer();
			//to remove the xml declarations
			transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
			DOMSource source = new DOMSource(doc);
			File streamFile = new File(ReadProperties.readParams("writePath")+writeRequest.getSerialNum()+"_"+writeRequest.getSearchNumber()+"_"+writeRequest.getProductCd()+"_"+writeRequest.getProductCoverageTypeAttr()+".xml");
			System.out.println("streamFile:"+streamFile.getAbsolutePath());
			StreamResult result = new StreamResult(new FileOutputStream(streamFile));

			// Output to console for testing
			//StreamResult result = new StreamResult(System.out);

			transformer.transform(source, result);

			System.out.println(writeRequest.getSerialNum()+"_"+writeRequest.getSearchNumber()+"_"+writeRequest.getProductCd()+"_"+writeRequest.getProductCoverageTypeAttr()+".xml File saved!");

		  } catch (ParserConfigurationException pce) {
			pce.printStackTrace();
		  } catch (TransformerException tfe) {
			tfe.printStackTrace();
		  } catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
		 }
	}