package com.xml.convert;

public class GetSubmissionRequestBean {
	private String serialNum;
	public String getSerialNum() {
		return serialNum;
	}

	public void setSerialNum(String serialNum) {
		this.serialNum = serialNum;
	}

	private String SearchNumber;
	private String ProductCd;
	private String ProductCoverageTypeAttr;

	public GetSubmissionRequestBean(){}

	public GetSubmissionRequestBean(String SearchNumber, String ProductCd, String ProductCoverageTypeAttr)
	{
		this.SearchNumber=SearchNumber;
		this.ProductCd=ProductCd;
		this.ProductCoverageTypeAttr=ProductCoverageTypeAttr;
	}

	public String getSearchNumber() {
		return SearchNumber;
	}
	public void setSearchNumber(String searchNumber) {
		SearchNumber = searchNumber;
	}
	public String getProductCd() {
		return ProductCd;
	}
	public void setProductCd(String productCd) {
		ProductCd = productCd;
	}
	public String getProductCoverageTypeAttr() {
		return ProductCoverageTypeAttr;
	}
	public void setProductCoverageTypeAttr(String productCoverageTypeAttr) {
		ProductCoverageTypeAttr = productCoverageTypeAttr;
	}

	@Override
	public String toString()
	{
		return "SearchNumber:" +SearchNumber+" ProductCd: "+ProductCd+" Product CovergaeType: "+ProductCoverageTypeAttr;
	}


}
