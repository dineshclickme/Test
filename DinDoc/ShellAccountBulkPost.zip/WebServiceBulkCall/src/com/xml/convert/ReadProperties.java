package com.xml.convert;


import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class ReadProperties {

	public static String readParams(String param)
	{
		Properties prop = new Properties();
		InputStream input = null;
		String writePath="";
		String readPath="";
	try {

		input = new FileInputStream("conf.properties");

		// load a properties file
		prop.load(input);

		// get the property value and print it out
		//System.out.println(prop.getProperty("counter"));
		//System.out.println(prop.getProperty("writePath"));
		writePath=prop.getProperty("writePath");
		readPath=prop.getProperty("readPath");


	} catch (IOException ex) {
		ex.printStackTrace();
	} finally {
		if (input != null) {
			try {
				input.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	if(param=="writePath")
	{
		return writePath;
	}
	else if(param=="readPath"){
		return readPath;
	}
	return "";

  }

}