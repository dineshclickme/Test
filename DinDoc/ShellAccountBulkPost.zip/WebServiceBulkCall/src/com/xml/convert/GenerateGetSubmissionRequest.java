package com.xml.convert;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

/*import com.getsubmission.GetSubmissionRequestBean;
import com.getsubmission.ReadProperties;
import com.getsubmission.XMLWriter;*/

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
//import java.util.Iterator;
import java.util.List;

public class GenerateGetSubmissionRequest {
	private static final String FILE_PATH = ReadProperties.readParams("readPath");

	 public static void main(String args[]) {

	       boolean flag =  getReadSubmissionRequest();
if(flag){
	System.out.println("XML generated successfully.");
}else{
	System.out.println("Something went wrong! please validate the input template excel.");
}

	    }

	 public static boolean getReadSubmissionRequest() {
		 boolean flag = false;
		 List<GetSubmissionRequestBean> getSubmissionList = new ArrayList<GetSubmissionRequestBean>();
	        FileInputStream fis = null;
	        try {
	        	 fis = new FileInputStream(FILE_PATH);

	             // Using XSSF for xlsx format, for xls use HSSF
	             Workbook workbook = new XSSFWorkbook(fis);

	             int numberOfSheets = 2; //workbook.getNumberOfSheets(); Give the Excel sheet number.
	             Sheet sheet = workbook.getSheetAt(numberOfSheets-1);
	             int lastRow=sheet.getLastRowNum();
	             System.out.println("LastRow:" +lastRow);



	             GetSubmissionRequestBean newSubmission= null;

	            for(int row=1;row<=lastRow;row++){
	            	 Row rowTest=sheet.getRow(row);
	            	 int cellCounter=rowTest.getPhysicalNumberOfCells();
	            	 String[] b=new String[cellCounter];
	            	 for(int col=0;col<cellCounter;col++){
	            		 Cell a=rowTest.getCell(col);
	            		 b[col]=a.toString();
	            		 //System.out.println(a);
	            	 }
	            	 newSubmission= new GetSubmissionRequestBean();
	            	 newSubmission.setSerialNum(b[0]);
	            	 newSubmission.setSearchNumber(b[1]);
	            	 newSubmission.setProductCd(b[2]);
	            	 newSubmission.setProductCoverageTypeAttr(b[3]);

	            	 if(b[4].equalsIgnoreCase("1")){
	            	 getSubmissionList.add(newSubmission);
	            	 }
	             }

	             fis.close();
	             XMLWriter.writeXMLFile(getSubmissionList);
	             flag = true;

	        }catch (FileNotFoundException e) {
	            e.printStackTrace();
	            flag = false;
	        } catch (IOException e) {
	            e.printStackTrace();
	            flag = false;
	        }
	        return flag;
	 }
}


