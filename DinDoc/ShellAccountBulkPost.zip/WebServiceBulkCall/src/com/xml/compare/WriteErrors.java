package com.xml.compare;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Name;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFColor;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;


public class WriteErrors {

public static void main(String argv[]) {
		
	}

private static final String FILE_PATH = "OUTPUT/test_results.xlsx";

//We are making use of a single instance to prevent multiple write access to same file.
/*private static final WriteErrors INSTANCE = new WriteErrors();
public static WriteErrors getInstance() {
    return INSTANCE;
}*/

private WriteErrors() {
}

	
public static void writeLog(List<DifferenceBean> errorLog, List<SummaryBean>  summaryList, DashboardBean dashBoard) throws IOException, InvalidFormatException{
	
	  
	  
	  //Load sample excel file
	  XSSFWorkbook wb = new XSSFWorkbook(OPCPackage.open(new FileInputStream("OUTPUT/Reference/ChartSample.xlsx")));
	  CreationHelper createHelper = wb.getCreationHelper();
	 // Sheet sh=wb.getSheetAt(2);
	  //String sheetName=sh.getSheetName();
	
		//XSSFWorkbook wb = new XSSFWorkbook();
		XSSFSheet dashBoardSheet = wb.getSheetAt(0); //wb.createSheet("Dashboard");
		XSSFSheet summarySheet = wb.createSheet("Summary");
    	XSSFSheet logSheet = wb.createSheet("Difference Log");
    	
    	String sheetName=dashBoardSheet.getSheetName();
    	int summaryNo=0;
    	
    	Font f=wb.createFont();
    	f.setBoldweight(Font.BOLDWEIGHT_BOLD);
        
    	
    	XSSFCellStyle headerStyle = wb.createCellStyle();
    	XSSFCellStyle rowStyle = wb.createCellStyle();
    	XSSFCellStyle pass = wb.createCellStyle();
    	XSSFCellStyle fail = wb.createCellStyle();
    	XSSFCellStyle error= wb.createCellStyle();
    	
    	//headerStyle.setFillForegroundColor(new XSSFColor(new java.awt.Color(253, 233, 217)));
    	headerStyle.setFillForegroundColor(new XSSFColor(new java.awt.Color(0,206,209)));
    	headerStyle.setFillPattern(CellStyle.SOLID_FOREGROUND);
    	headerStyle.setFont(f);
    	headerStyle.setBorderBottom(HSSFCellStyle.BORDER_THIN);
    	headerStyle.setBorderTop(HSSFCellStyle.BORDER_THIN);
    	headerStyle.setBorderRight(HSSFCellStyle.BORDER_THIN);
    	headerStyle.setBorderLeft(HSSFCellStyle.BORDER_THIN);
    	
    	rowStyle.setBorderBottom(HSSFCellStyle.BORDER_THIN);
    	rowStyle.setBorderTop(HSSFCellStyle.BORDER_THIN);
    	rowStyle.setBorderRight(HSSFCellStyle.BORDER_THIN);
    	rowStyle.setBorderLeft(HSSFCellStyle.BORDER_THIN);
    	
    	pass.setBorderBottom(HSSFCellStyle.BORDER_THIN);
    	pass.setBorderTop(HSSFCellStyle.BORDER_THIN);
    	pass.setBorderRight(HSSFCellStyle.BORDER_THIN);
    	pass.setBorderLeft(HSSFCellStyle.BORDER_THIN);
    //	pass.setFillForegroundColor(new XSSFColor(new java.awt.Color(146, 208, 80)));
    	pass.setFillForegroundColor(new XSSFColor(new java.awt.Color(50,205,50)));
    	pass.setFillPattern(CellStyle.SOLID_FOREGROUND);
    	
    	fail.setBorderBottom(HSSFCellStyle.BORDER_THIN);
    	fail.setBorderTop(HSSFCellStyle.BORDER_THIN);
    	fail.setBorderRight(HSSFCellStyle.BORDER_THIN);
    	fail.setBorderLeft(HSSFCellStyle.BORDER_THIN);
    	fail.setFillForegroundColor(new XSSFColor(new java.awt.Color(255, 0, 0)));
    	fail.setFillPattern(CellStyle.SOLID_FOREGROUND);
    	
    	error.setBorderBottom(HSSFCellStyle.BORDER_THIN);
    	error.setBorderTop(HSSFCellStyle.BORDER_THIN);
    	error.setBorderRight(HSSFCellStyle.BORDER_THIN);
    	error.setBorderLeft(HSSFCellStyle.BORDER_THIN);
    	error.setFillForegroundColor(new XSSFColor(new java.awt.Color(255, 194, 0)));
    	error.setFillPattern(CellStyle.SOLID_FOREGROUND);
    	
    	
        XSSFRow logHeading=logSheet.createRow(0);
        logHeading.createCell(0).setCellValue("File Name");
        logHeading.getCell(0).setCellStyle(headerStyle);
        logHeading.createCell(1).setCellValue("Legacy Tag Name");
        logHeading.getCell(1).setCellStyle(headerStyle);
        logHeading.createCell(2).setCellValue("Target Tag Name");
        logHeading.getCell(2).setCellStyle(headerStyle);
        logHeading.createCell(3).setCellValue("Legacy (Pre-Migration) Response");
        logHeading.getCell(3).setCellStyle(headerStyle);
        logHeading.createCell(4).setCellValue("NextGen (Post-Migration) Response");
        logHeading.getCell(4).setCellStyle(headerStyle);
        logHeading.createCell(5).setCellValue("Difference Remarks");
        logHeading.getCell(5).setCellStyle(headerStyle);
        logHeading.createCell(6).setCellValue("Status");
        logHeading.getCell(6).setCellStyle(headerStyle);
        int rowIndex = 1;
        
        XSSFRow summaryHeading=summarySheet.createRow(0);
        summaryHeading.createCell(0).setCellValue("S.No.");
        summaryHeading.getCell(0).setCellStyle(headerStyle);
        summaryHeading.createCell(1).setCellValue("Legacy (Pre-Migration) File Name");
        summaryHeading.getCell(1).setCellStyle(headerStyle);
        /*heading.createCell(1).setCellValue("NextGen (Post-Migration) File Name");
        heading.getCell(1).setCellStyle(headerStyle);*/
        summaryHeading.createCell(2).setCellValue("NextGen (Post-Migration) File Name");
        summaryHeading.getCell(2).setCellStyle(headerStyle);
        summaryHeading.createCell(3).setCellValue("Status");
        summaryHeading.getCell(3).setCellStyle(headerStyle);
        
        XSSFRow dashBoardHeading=dashBoardSheet.createRow(0);
        dashBoardHeading.createCell(0).setCellValue("Total no. of Legacy Responses");
        dashBoardHeading.getCell(0).setCellStyle(headerStyle);
        dashBoardHeading.createCell(1).setCellValue("Total no. of Target Responses");
        dashBoardHeading.getCell(1).setCellStyle(headerStyle);
        dashBoardHeading.createCell(2).setCellValue("Legacy Only Responses");
        dashBoardHeading.getCell(2).setCellStyle(headerStyle);
        dashBoardHeading.createCell(3).setCellValue("Target Only Responses");
        dashBoardHeading.getCell(3).setCellStyle(headerStyle);
        dashBoardHeading.createCell(4).setCellValue("Total no. of XMLs compared");
        dashBoardHeading.getCell(4).setCellStyle(headerStyle);
        dashBoardHeading.createCell(5).setCellValue("Pass Count");
        dashBoardHeading.getCell(5).setCellStyle(headerStyle);
        dashBoardHeading.createCell(6).setCellValue("Fail Count");
        dashBoardHeading.getCell(6).setCellStyle(headerStyle);
        dashBoardHeading.createCell(7).setCellValue("Error Count");
        dashBoardHeading.getCell(7).setCellStyle(headerStyle);
               
		
	for(DifferenceBean iterateError: errorLog){
		Row row = logSheet.createRow(rowIndex++);
        int cellIndex = 0;
        //
       
        row.createCell(cellIndex++).setCellValue(iterateError.getLegacyFileName());
        row.getCell(cellIndex-1).setCellStyle(rowStyle);
        //
        
        row.createCell(cellIndex++).setCellValue(iterateError.getLegacyTagName());
        row.getCell(cellIndex-1).setCellStyle(rowStyle);
        //
        
        row.createCell(cellIndex++).setCellValue(iterateError.getTargetTagName());
        row.getCell(cellIndex-1).setCellStyle(rowStyle);
        //
        row.createCell(cellIndex++).setCellValue(iterateError.getLegacyResponse());
        row.getCell(cellIndex-1).setCellStyle(rowStyle);
        //
        row.createCell(cellIndex++).setCellValue(iterateError.getNextGenResponse());
        row.getCell(cellIndex-1).setCellStyle(rowStyle);

        row.createCell(cellIndex++).setCellValue(iterateError.getRemarks());
        row.getCell(cellIndex-1).setCellStyle(rowStyle);
        row.createCell(cellIndex++).setCellValue(iterateError.getStatus());
        if(iterateError.getStatus().equalsIgnoreCase("pass"))
        {
        	row.getCell(cellIndex-1).setCellStyle(pass);
        }
        else if(iterateError.getStatus().equalsIgnoreCase("fail"))
        {
        	row.getCell(cellIndex-1).setCellStyle(fail);
        }else if(iterateError.getStatus().equalsIgnoreCase("error"))
        {
        	row.getCell(cellIndex-1).setCellStyle(error);
        }
		
	}
	
	logSheet.autoSizeColumn(0);
    logSheet.autoSizeColumn(1);
    logSheet.autoSizeColumn(2);
    logSheet.autoSizeColumn(3);
    logSheet.autoSizeColumn(4);
    logSheet.autoSizeColumn(5);
    logSheet.autoSizeColumn(6);
    
    
    rowIndex = 1;
    for(SummaryBean iterateSummary: summaryList){
		Row row = summarySheet.createRow(rowIndex++);
        int cellIndex = 0;
        //
        summaryNo++;
        row.createCell(cellIndex++).setCellValue(summaryNo);
        row.getCell(cellIndex-1).setCellStyle(rowStyle);
        
        row.createCell(cellIndex++).setCellValue(iterateSummary.getLegacyFileName());
        row.getCell(cellIndex-1).setCellStyle(rowStyle);
        //
        
       /* row.createCell(cellIndex++).setCellValue(iterateError.getTargetFileName());
        row.getCell(cellIndex-1).setCellStyle(rowStyle);*/
        //
        row.createCell(cellIndex++).setCellValue(iterateSummary.getTargetFileName());
        row.getCell(cellIndex-1).setCellStyle(rowStyle);
        //
        row.createCell(cellIndex++).setCellValue(iterateSummary.getStatus());
        if(iterateSummary.getStatus().equalsIgnoreCase("pass"))
        {
        	row.getCell(cellIndex-1).setCellStyle(pass);
        }
        else if(iterateSummary.getStatus().equalsIgnoreCase("fail"))
        {
        	row.getCell(cellIndex-1).setCellStyle(fail);
        }else if(iterateSummary.getStatus().equalsIgnoreCase("error"))
        {
        	row.getCell(cellIndex-1).setCellStyle(error);
        }
		
	}
    
    summarySheet.autoSizeColumn(0);
    summarySheet.autoSizeColumn(1);
    summarySheet.autoSizeColumn(2);
    summarySheet.autoSizeColumn(3);
    
    rowIndex = 1;
    
	Row row = dashBoardSheet.createRow(rowIndex++);
    int cellIndex = 0;
    //
   
    row.createCell(cellIndex++).setCellValue(dashBoard.getLegacyCount());
    row.getCell(cellIndex-1).setCellStyle(rowStyle);
    //
    
   /* row.createCell(cellIndex++).setCellValue(iterateError.getTargetFileName());
    row.getCell(cellIndex-1).setCellStyle(rowStyle);*/
    //
    row.createCell(cellIndex++).setCellValue(dashBoard.getTargetCount());
    row.getCell(cellIndex-1).setCellStyle(rowStyle);
    
    row.createCell(cellIndex++).setCellValue(dashBoard.getLegacyOnlyCount());
    row.getCell(cellIndex-1).setCellStyle(rowStyle);
    
    row.createCell(cellIndex++).setCellValue(dashBoard.getTargetOnlyCount());
    row.getCell(cellIndex-1).setCellStyle(rowStyle);
    
    row.createCell(cellIndex++).setCellValue(dashBoard.getComparisonCount());
    row.getCell(cellIndex-1).setCellStyle(rowStyle);
    //
    row.createCell(cellIndex++).setCellValue(dashBoard.getPassCount());
    row.getCell(cellIndex-1).setCellStyle(pass);
    row.createCell(cellIndex++).setCellValue(dashBoard.getFailCount());
    row.getCell(cellIndex-1).setCellStyle(fail);
    row.createCell(cellIndex++).setCellValue(dashBoard.getErrorCount());
    row.getCell(cellIndex-1).setCellStyle(error);
    
        
    dashBoardSheet.autoSizeColumn(0);
    dashBoardSheet.autoSizeColumn(1);
    dashBoardSheet.autoSizeColumn(2);
    dashBoardSheet.autoSizeColumn(3);
    dashBoardSheet.autoSizeColumn(4);
    dashBoardSheet.autoSizeColumn(5);
    dashBoardSheet.autoSizeColumn(6);
    dashBoardSheet.autoSizeColumn(7);
    //write this workbook in excel file.
    try {
    	
    	 //Search for named range
        Name rangeCell = wb.getName("Overall_Rows");         
        //Set new range for named range 
        String reference = sheetName + "!$C$1:$E$1" ;          
        //Assigns range value to named range
        rangeCell.setRefersToFormula(reference);

        rangeCell = wb.getName("Overall_Values");            
        reference = sheetName +"!$C$2:$E$2" ;
        rangeCell.setRefersToFormula(reference); 
        
     
      //Search for named range
        Name rangeCell1 = wb.getName("Summary_Rows");         
        //Set new range for named range 
        String reference1 =sheetName +"!$F$1:$H$1";          
        //Assigns range value to named range
        rangeCell1.setRefersToFormula(reference1);

        rangeCell1 = wb.getName("Summary_Values");            
        reference1 = sheetName +"!$F$2:$H$2";
        rangeCell1.setRefersToFormula(reference1); 
        
        FileOutputStream fos = new FileOutputStream(FILE_PATH);
        //workbook.write(fos);
        wb.write(fos);
        fos.close();
	System.out.println(FILE_PATH + " is successfully written");
    } catch (FileNotFoundException e) {
        e.printStackTrace();
    } catch (IOException e) {
        e.printStackTrace();
    }
}

}
