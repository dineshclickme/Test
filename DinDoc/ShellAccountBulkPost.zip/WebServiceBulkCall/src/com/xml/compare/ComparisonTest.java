package com.xml.compare;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.custommonkey.xmlunit.DetailedDiff;
import org.custommonkey.xmlunit.Diff;
import org.custommonkey.xmlunit.Difference;
import org.custommonkey.xmlunit.DifferenceConstants;
import org.custommonkey.xmlunit.NodeDetail;
import org.custommonkey.xmlunit.XMLUnit;
import org.custommonkey.xmlunit.examples.RecursiveElementNameAndTextQualifier;
import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class ComparisonTest {


public static void compareXMLs(List<ReadFileNamesBean>  files, List<SummaryBean>  summaryList, DashboardBean dashBoard){

	XMLUnit.setIgnoreAttributeOrder(true);

	XMLUnit.setNormalizeWhitespace(true);

	  XMLUnit.setIgnoreDiffBetweenTextAndCDATA(true);
	DocumentBuilder dBuilder;
	dBuilder=null;
	try {
		dBuilder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
	} catch (ParserConfigurationException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
	Document docLegacy=null;
	Document docTarget=null;
FileReader fr1 = null;
FileReader fr2 = null;
int errorCount=0;
int passCount=0;
int failCount=0;

List<DifferenceBean> differenceLog=new ArrayList<DifferenceBean>();

//Iteration Loop may start here
for(ReadFileNamesBean file:files){

	String masterConditionCodeLegacy="";
	String masterConditionCodeTarget="";
	String badLegacy="";
	String badTarget="";
	String targetRootElement="";
	String legacyRootElement="";

try {
    fr1 = new FileReader(file.getLegacyFile());
    fr2 = new FileReader(file.getTargetFile());
} catch (FileNotFoundException e) {
    e.printStackTrace();
}


try {

	docLegacy = dBuilder.parse(file.getLegacyFile());
	legacyRootElement=docLegacy.getDocumentElement().getNodeName();
	if (docLegacy.getDocumentElement().hasAttributes()) {

		NamedNodeMap nodeMap = docLegacy.getDocumentElement().getAttributes();

		for (int i = 0; i < nodeMap.getLength(); i++) {

			Node node = nodeMap.item(i);
			masterConditionCodeLegacy=node.getNodeName();
			badLegacy=node.getNodeValue();

		}

	}

   } catch (Exception e) {
	System.out.println(e.getMessage());
   }

try {

	docTarget = dBuilder.parse(file.getTargetFile());
	targetRootElement=docTarget.getDocumentElement().getNodeName();

	if (docTarget.getDocumentElement().hasAttributes()) {
		NamedNodeMap nodeMap = docTarget.getDocumentElement().getAttributes();

		for (int i = 0; i < nodeMap.getLength(); i++) {

			Node node = nodeMap.item(i);
			masterConditionCodeTarget=node.getNodeName();
			badTarget=node.getNodeValue();


		}

	}

   } catch (Exception e) {
	System.out.println(e.getMessage());
   }



if(masterConditionCodeLegacy.equalsIgnoreCase("MasterConditionCode") && badLegacy.equalsIgnoreCase("Bad") && masterConditionCodeTarget.equalsIgnoreCase("MasterConditionCode") && badTarget.equalsIgnoreCase("Bad")){
	errorCount++;
	SummaryBean sb=new SummaryBean();
	sb.setTargetFileName(file.getTargetFileName());
	sb.setLegacyFileName(file.getLegacyFileName());
	sb.setStatus("Error");
	summaryList.add(sb);
	DifferenceBean errorDiff = new DifferenceBean();
	errorDiff.setRemarks("Legacy and NextGen Reponses are Error Responses");
	errorDiff.setLegacyResponse("Legacy and NextGen Reponses are Error Responses");
	errorDiff.setNextGenResponse("Legacy and NextGen Reponses are Error Responses");
	errorDiff.setLegacyFileName(file.getLegacyFileName());
	errorDiff.setTargetFileName(file.getTargetFileName());
	errorDiff.setLegacyTagName(legacyRootElement);
	errorDiff.setTargetTagName(targetRootElement);
	errorDiff.setStatus("Error");
	differenceLog.add(errorDiff);
}
else if(masterConditionCodeLegacy.equalsIgnoreCase("MasterConditionCode") && badLegacy.equalsIgnoreCase("Bad")){
	errorCount++;
	SummaryBean sb=new SummaryBean();
	sb.setTargetFileName(file.getTargetFileName());
	sb.setLegacyFileName(file.getLegacyFileName());
	sb.setStatus("Error");
	summaryList.add(sb);
	DifferenceBean errorDiff = new DifferenceBean();
	errorDiff.setRemarks("Legacy Reponse is an Error Response");
	errorDiff.setLegacyResponse("Legacy Reponse is an Error Response");
	errorDiff.setNextGenResponse("");
	errorDiff.setLegacyFileName(file.getLegacyFileName());
	errorDiff.setTargetFileName(file.getTargetFileName());
	errorDiff.setLegacyTagName(legacyRootElement);
	errorDiff.setTargetTagName("");
	errorDiff.setStatus("Error");
	differenceLog.add(errorDiff);
}
else if(masterConditionCodeTarget.equalsIgnoreCase("MasterConditionCode") && badTarget.equalsIgnoreCase("Bad")){
	errorCount++;
	SummaryBean sb=new SummaryBean();
	sb.setTargetFileName(file.getTargetFileName());
	sb.setLegacyFileName(file.getLegacyFileName());
	sb.setStatus("Error");
	summaryList.add(sb);
	DifferenceBean errorDiff = new DifferenceBean();
	errorDiff.setRemarks("NextGen Reponse is an Error Response");
	errorDiff.setLegacyResponse("");
	errorDiff.setNextGenResponse("NextGen Reponse is an Error Response");
	errorDiff.setLegacyFileName(file.getLegacyFileName());
	errorDiff.setTargetFileName(file.getTargetFileName());
	errorDiff.setLegacyTagName("");
	errorDiff.setTargetTagName(targetRootElement);
	errorDiff.setStatus("Error");
	differenceLog.add(errorDiff);
}
else
{
try {
	XMLUnit.setIgnoreAttributeOrder(true);


    Diff diff = new Diff(fr1, fr2);

    if(diff.identical()){
    	passCount++;
    	SummaryBean sb=new SummaryBean();
    	sb.setTargetFileName(file.getTargetFileName());
    	sb.setLegacyFileName(file.getLegacyFileName());
    	sb.setStatus("Pass");
    	summaryList.add(sb);

    }else{
    	failCount++;
    	SummaryBean sb=new SummaryBean();
    	sb.setTargetFileName(file.getTargetFileName());
    	sb.setLegacyFileName(file.getLegacyFileName());
    	sb.setStatus("Fail");
    	summaryList.add(sb);

    }

    DetailedDiff detDiff = new DetailedDiff(diff);
    List differences = detDiff.getAllDifferences();

    DifferenceBean newLog=null;

    for (Object object : differences) {
        Difference difference = (Difference)object;
        newLog=new DifferenceBean();
        NodeDetail testNode = difference.getTestNodeDetail();
        NodeDetail controlNode = difference.getControlNodeDetail();
        int controlChilds =0;
        int testChilds =0;

        if(difference.getDescription().equalsIgnoreCase("number of child nodes")){

        	// ***** change the || to && for better results *****
        	if(!difference.getControlNodeDetail().getValue().equalsIgnoreCase("0") && !difference.getTestNodeDetail().getValue().equalsIgnoreCase("0") ){

        	controlChilds =Integer.parseInt(difference.getControlNodeDetail().getValue());
        	testChilds = Integer.parseInt(difference.getTestNodeDetail().getValue());

        	newLog.setLegacyFileName(file.getLegacyFileName());
        	newLog.setTargetFileName(file.getTargetFileName());
        	newLog.setLegacyTagName(difference.getControlNodeDetail().getNode().getLocalName());
        	newLog.setTargetTagName(difference.getTestNodeDetail().getNode().getLocalName());
        	newLog.setLegacyResponse(difference.getControlNodeDetail().getValue());
        	newLog.setNextGenResponse(difference.getTestNodeDetail().getValue());
    		newLog.setStatus("Fail");
    		if(controlChilds > testChilds){
        		newLog.setRemarks("NextGen Response XML has less number of child nodes(tags) than Legacy Response XML ");
        	}else if(controlChilds < testChilds){
        		newLog.setRemarks("NextGen Response XML has more number of child nodes(tags) than Legacy Response XML ");
        	}
        	 differenceLog.add(newLog);

       }
        }

        else if(difference.getDescription().equalsIgnoreCase("presence of child node")){

    		newLog.setStatus("Fail");

    		if(difference.getTestNodeDetail().getValue().equalsIgnoreCase("null")){

						if(difference.getControlNodeDetail().getNode().hasChildNodes()){

							NodeList children = difference.getControlNodeDetail().getNode().getChildNodes();

							for(int i=0;i<children.getLength();i++ ){
								String n= children.item(i).getNodeValue();
								if(n!=null){
									if(!n.trim().isEmpty()){

										if(difference.toString().contains("#text") && !difference.getControlNodeDetail().getNode().hasChildNodes()){
											newLog.setLegacyTagName(difference.getControlNodeDetail().getNode().getParentNode().getLocalName());
											newLog.setTargetTagName("");
											newLog.setLegacyResponse(n);
											newLog.setRemarks("This tag has no value in NextGen response.");
											differenceLog.add(newLog);
										}
										else{
											newLog.setLegacyFileName(file.getLegacyFileName());
								        	newLog.setTargetFileName(file.getTargetFileName());
								        	newLog.setLegacyTagName(difference.getControlNodeDetail().getNode().getLocalName());
								        	newLog.setTargetTagName("");
											newLog.setLegacyResponse(n);
											newLog.setRemarks("This tag is not available in NextGen response." );
											newLog.setNextGenResponse("");
											String testString=difference.getControlNodeDetail().getNode().getLocalName();
											differenceLog.add(newLog);
										}
									}
								}
							}
					}
	    			else{


	    				if(difference.toString().contains("#text") && !difference.getControlNodeDetail().getNode().hasChildNodes() ){
	    					newLog.setLegacyFileName(file.getLegacyFileName());
		                	newLog.setTargetFileName(file.getTargetFileName());
	        				newLog.setLegacyTagName(difference.getControlNodeDetail().getNode().getParentNode().getLocalName());
            				newLog.setTargetTagName("");
            				newLog.setLegacyResponse(difference.getControlNodeDetail().getNode().getNodeValue());
            				newLog.setRemarks("This tag has no value in NextGen response.");

            				if(difference.getId()==22 && (!difference.getControlNodeDetail().getNode().getNodeValue().trim().isEmpty() || !difference.getControlNodeDetail().getNode().getNodeValue().trim().equalsIgnoreCase("") )){

            					differenceLog.add(newLog);
            				}
	        			}
	        			else{
	        				newLog.setLegacyFileName(file.getLegacyFileName());
		                	newLog.setTargetFileName(file.getTargetFileName());
		                	newLog.setLegacyTagName(difference.getControlNodeDetail().getNode().getLocalName());
		                	newLog.setTargetTagName("");
		        			newLog.setLegacyResponse("unable to fetch value");
		                	newLog.setRemarks("This tag is not available in NextGen response.");
		        			newLog.setNextGenResponse("");
		        			String testString=difference.getControlNodeDetail().getNode().getLocalName();
		        			differenceLog.add(newLog);
	        			}
	    			}
    		}

    		if(difference.getControlNodeDetail().getValue().equalsIgnoreCase("null")){


				if(difference.getTestNodeDetail().getNode().hasChildNodes()){

					NodeList children = difference.getTestNodeDetail().getNode().getChildNodes();

					for(int i=0;i<children.getLength();i++ ){
						String n= children.item(i).getNodeValue();
						if(n!=null){
						}
						if(n!=null){
							if(!n.trim().isEmpty()){

								if(difference.toString().contains("#text") && !difference.getTestNodeDetail().getNode().hasChildNodes()){
									newLog.setTargetTagName(difference.getTestNodeDetail().getNode().getParentNode().getLocalName());
									newLog.setLegacyTagName("");
									newLog.setNextGenResponse(n);
									newLog.setRemarks("This tag has no value in NextGen response.");
									differenceLog.add(newLog);
								}
								else{
									newLog.setLegacyFileName(file.getLegacyFileName());
						        	newLog.setTargetFileName(file.getTargetFileName());
						        	newLog.setTargetTagName(difference.getTestNodeDetail().getNode().getLocalName());
						        	newLog.setLegacyTagName("");
									newLog.setNextGenResponse(n);
									newLog.setRemarks("This tag is not available in Legacy response." );
									newLog.setLegacyResponse("");
									differenceLog.add(newLog);
								}
							}
						}
					}
			}
			else{
				if(difference.toString().contains("#text") && !difference.getTestNodeDetail().getNode().hasChildNodes() ){
					newLog.setLegacyFileName(file.getLegacyFileName());
                	newLog.setTargetFileName(file.getTargetFileName());
    				newLog.setTargetTagName(difference.getTestNodeDetail().getNode().getParentNode().getLocalName());
    				newLog.setLegacyTagName("");
    				newLog.setNextGenResponse(difference.getTestNodeDetail().getNode().getNodeValue());
    				newLog.setRemarks("This tag has no value in Legacy response.");
    				if(difference.getId()==22 && (!difference.getTestNodeDetail().getNode().getNodeValue().trim().isEmpty() || !difference.getTestNodeDetail().getNode().getNodeValue().trim().equalsIgnoreCase(""))){
    					differenceLog.add(newLog);
    				}
    			}
    			else{

    				newLog.setLegacyFileName(file.getLegacyFileName());
                	newLog.setTargetFileName(file.getTargetFileName());
                	newLog.setTargetTagName(difference.getTestNodeDetail().getNode().getLocalName());
                	newLog.setLegacyTagName("");
        			newLog.setNextGenResponse("unable to fetch value");
                	newLog.setRemarks("This tag is not available in NextGen response.");
        			newLog.setLegacyResponse("");
        			String testString=difference.getTestNodeDetail().getNode().getLocalName();
        			differenceLog.add(newLog);
    			}
			}


    		}

        }

        else{
        	if(!difference.getDescription().equalsIgnoreCase("namespace prefix") && !difference.getDescription().equalsIgnoreCase("namespace URI") && !difference.getDescription().equalsIgnoreCase("node type") && !difference.getDescription().equalsIgnoreCase("sequence of child nodes") && !difference.getDescription().equalsIgnoreCase("presence of child nodes to be")){

       	newLog.setRemarks(difference.getDescription());
        newLog.setLegacyResponse(difference.getControlNodeDetail().getValue());
        newLog.setNextGenResponse(difference.getTestNodeDetail().getValue());
        newLog.setLegacyTagName(difference.getControlNodeDetail().getNode().getLocalName());
    	newLog.setTargetTagName(difference.getTestNodeDetail().getNode().getLocalName());
        String stringOne,stringTwo,stringThree,desc;
        int oneLength;
        String tagName;
        int start,end;
        desc=difference.getTestNodeDetail().getXpathLocation().toString();
        start=desc.lastIndexOf("/");
        end=desc.length();
        tagName=desc.substring(start+1, end).replaceAll("\\[.*?\\]", "");
        newLog.setLegacyFileName(file.getLegacyFileName());
    	newLog.setTargetFileName(file.getTargetFileName());
    	newLog.setLegacyTagName(difference.getControlNodeDetail().getNode().getLocalName());
    	newLog.setTargetTagName(difference.getTestNodeDetail().getNode().getLocalName());



        if(difference.getDescription().equalsIgnoreCase("text value")){
     	   stringOne=desc.replaceAll("/text\\(\\)", "").replaceAll("\\[.*?\\]", "");
     	   oneLength=stringOne.length();
     	   stringTwo=stringOne.substring(stringOne.lastIndexOf("/")+1,oneLength);
     	   newLog.setLegacyFileName(file.getLegacyFileName());
     	   newLog.setTargetFileName(file.getTargetFileName());
     	   newLog.setLegacyTagName(stringTwo);
     	   newLog.setTargetTagName(stringTwo);
     	   newLog.setRemarks("Change in Tag Value");

        	}
        else if(difference.getDescription().equalsIgnoreCase("attribute value")){
     	   stringOne=desc.replaceAll("/text\\(\\)", "").replaceAll("\\[.*?\\]", "");
     	   oneLength=stringOne.length();
     	   stringTwo=stringOne.substring(stringOne.lastIndexOf("/")+2,oneLength);
     	   stringThree=stringOne.replaceAll("/@", "!"); //.replaceAll(stringTwo, "");
     	   String stringFour=stringThree.substring(stringThree.lastIndexOf("/")+1,stringThree.indexOf("!"));
     	   newLog.setLegacyFileName(file.getLegacyFileName());
      	   newLog.setTargetFileName(file.getTargetFileName());
      	   newLog.setLegacyTagName(stringTwo);
      	   newLog.setTargetTagName(stringTwo);
     	   newLog.setRemarks("Change of value in attribute for \'"+stringTwo+"\' in tag \'"+stringFour+"\'");
        	}

       if(newLog.getLegacyResponse().equalsIgnoreCase(newLog.getNextGenResponse()))
        	newLog.setStatus("Pass");
        else{
        	newLog.setStatus("Fail");
		differenceLog.add(newLog);
	}
        //differenceLog.add(newLog);
        }
        }

    }



} catch (SAXException e) {
    e.printStackTrace();
} catch (IOException e) {
    e.printStackTrace();
}
}

}//Loop might END

dashBoard.setErrorCount(errorCount);
dashBoard.setPassCount(passCount);
dashBoard.setFailCount(failCount);
try {
	WriteErrors.writeLog(differenceLog,summaryList,dashBoard);
} catch (InvalidFormatException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
} catch (IOException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}
}


}