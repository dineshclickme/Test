package com.xml.compare;

public class DifferenceBean {
	
	private String legacyFileName;
	private String targetFileName;
	private String legacyTagName;
	private String targetTagName;
	private String legacyResponse;
	private String nextGenResponse;
	private String remarks;
	private String status;
	
	public DifferenceBean(){}
	
	

	public String getLegacyResponse() {
		return legacyResponse;
	}

	public void setLegacyResponse(String legacyResponse) {
		this.legacyResponse = legacyResponse;
	}

	public String getNextGenResponse() {
		return nextGenResponse;
	}

	public void setNextGenResponse(String nextGenResponse) {
		this.nextGenResponse = nextGenResponse;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	

	public String getLegacyTagName() {
		return legacyTagName;
	}



	public void setLegacyTagName(String legacyTagName) {
		this.legacyTagName = legacyTagName;
	}



	public String getTargetTagName() {
		return targetTagName;
	}



	public void setTargetTagName(String targetTagName) {
		this.targetTagName = targetTagName;
	}



	public String getLegacyFileName() {
		return legacyFileName;
	}

	public void setLegacyFileName(String legacyFileName) {
		this.legacyFileName = legacyFileName;
	}
	
	public String getTargetFileName() {
		return targetFileName;
	}

	public void setTargetFileName(String targetFileName) {
		this.targetFileName = targetFileName;
	}



	public DifferenceBean(String legacyFileName, String targetFileName,
			String legacyTagName, String targetTagName, String legacyResponse,
			String nextGenResponse, String remarks, String status) {
		super();
		this.legacyFileName = legacyFileName;
		this.targetFileName = targetFileName;
		this.legacyTagName = legacyTagName;
		this.targetTagName = targetTagName;
		this.legacyResponse = legacyResponse;
		this.nextGenResponse = nextGenResponse;
		this.remarks = remarks;
		this.status = status;
	}
	

}
