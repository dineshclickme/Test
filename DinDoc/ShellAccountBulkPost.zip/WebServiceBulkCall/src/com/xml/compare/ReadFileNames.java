package com.xml.compare;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import com.util.ConfigManager;

public class ReadFileNames {
	
	//private static final String LEGACY_FILE_PATH="INPUT/Legacy";
	//private static final String TARGET_FILE_PATH="INPUT/Target";
	
	private static final String LEGACY_FILE_PATH=ConfigManager.getPropertyString("LEGACY_OUTPUT_DIR", "");
	private static final String TARGET_FILE_PATH=ConfigManager.getPropertyString("OUTPUT_DIR", "");
	
	public static void compare(){
		
		int legacyCount=0;
		int targetCount=0;
		int comparisonCount=0;
		int legacyOnlyCount=0;
		int targetOnlyCount=0;
		List<String> results = new ArrayList<String>();
		/*List<String> legacyOnly = new ArrayList<String>();
		List<String> targetOnly = new ArrayList<String>();*/
		//System.out.println("path name:"+LEGACY_FILE_PATH);
		File[] legacyFolder = new File(LEGACY_FILE_PATH).listFiles();
		File[] targetFolder = new File(TARGET_FILE_PATH).listFiles();
		
		List<ReadFileNamesBean> fileNamesList=new ArrayList<ReadFileNamesBean>();
		List<SummaryBean> summaryList=new ArrayList<SummaryBean>();
		DashboardBean dashBoard=new DashboardBean();
		
		//System.out.println("Legacy Count:"+legacyFolder.length);
		legacyCount=legacyFolder.length;
		
		//System.out.println("Target Count:"+targetFolder.length);
		targetCount=targetFolder.length;
		String legacyFileName="";
		String targetFileName="";
		
		for(File legacy:legacyFolder){ //To Check Legacy Only responses
			int flag=0;
			String flag2="";
			legacyFileName=legacy.toString().substring(legacy.toString().lastIndexOf("\\")+1);
			//System.out.println("Legacy:"+legacyName);
			String targetName;
			for(File target:targetFolder){
				//flag=0;
				targetName=target.toString().substring(target.toString().lastIndexOf("\\")+1);
				if(legacyFileName.equalsIgnoreCase(targetName)){
					flag=1;
					//System.out.println("Conatins!"+flag);
					break;
				}else{
					flag=2;
					flag2=legacyFileName;
					//System.out.println("Doesn't"+flag);
					
				}
			}
			
			if(flag==2){
				//System.out.println("Legacy Only File:"+flag2);
				SummaryBean sb=new SummaryBean();
				sb.setTargetFileName("No Target Response");
				sb.setLegacyFileName(flag2);
				sb.setStatus("Fail");
				summaryList.add(sb);
				
			}
			
		}
		
		for(File target:targetFolder){  //To Check Target Only responses
			int flag=0;
			String flag2="";
			targetFileName=target.toString().substring(target.toString().lastIndexOf("\\")+1);
			//System.out.println("Legacy:"+legacyName);
			for(File legacy:legacyFolder){
				//flag=0;
				legacyFileName=legacy.toString().substring(legacy.toString().lastIndexOf("\\")+1);
				if(targetFileName.equalsIgnoreCase(legacyFileName)){
					flag=1;
					//System.out.println("Conatins!"+flag);
					break;
				}else{
					flag=2;
					flag2=targetFileName;
					//System.out.println("Doesn't"+flag);
					
				}
			}
			
			if(flag==2){
				
				//System.out.println("Target Only File:"+flag2);
				SummaryBean sb=new SummaryBean();
				sb.setTargetFileName(flag2);
				sb.setLegacyFileName("No Legacy Response");
				sb.setStatus("Fail");
				summaryList.add(sb);
				
				//ComparisonTest.compareXMLs(empty,target);
			}
			
		}
		
		
		
		for (File legacyFile : legacyFolder) {
			legacyFileName=legacyFile.toString().substring(legacyFile.toString().lastIndexOf("\\")+1);
			for(File targetFile: targetFolder){
			targetFileName=targetFile.toString().substring(targetFile.toString().lastIndexOf("\\")+1);
		    if (legacyFile.toString().contains(".xml")) {  	
		    	if(legacyFileName.equalsIgnoreCase(targetFileName)){
		    		ReadFileNamesBean fileName=new ReadFileNamesBean();
		    		results.add(legacyFile.getName());
		    		//System.out.println(file.toString());
		    		//System.out.println(legacyFile.toString().substring(legacyFile.toString().lastIndexOf("\\")+1));
		    		fileName.setLegacyFile(legacyFile);
		    		fileName.setTargetFile(targetFile);
		    		fileName.setLegacyFileName(legacyFileName);
		    		fileName.setTargetFileName(targetFileName);
		    		fileNamesList.add(fileName);
		    		//ComparisonTest.compareXMLs(legacyFile,targetFile,legacyFileName,targetFileName);
		        
		    	}
		    }
		}
			
		}
		
		//ComparisonTest.compareXMLs(fileNamesList,summaryList);
		//System.out.println("Common Files Count:"+results.size());
		comparisonCount=results.size();
		if(legacyCount>comparisonCount){
			legacyOnlyCount=(legacyCount-comparisonCount);
		}
		if(targetCount>comparisonCount){
			targetOnlyCount=targetCount-comparisonCount;
		}
		
		dashBoard.setLegacyCount(legacyCount);
		//System.out.println("Legacy Count:"+legacyCount);
		dashBoard.setTargetCount(targetCount);
		//System.out.println("Target Count:"+targetCount);
		dashBoard.setComparisonCount(comparisonCount);
		//System.out.println("Comparison Count:"+comparisonCount);
		dashBoard.setLegacyOnlyCount(legacyOnlyCount);
		//System.out.println("Legacy Only Count:"+legacyOnlyCount);
		dashBoard.setTargetOnlyCount(targetOnlyCount);
		//System.out.println("Target Only Count:"+targetOnlyCount);
		
		ComparisonTest.compareXMLs(fileNamesList,summaryList,dashBoard);
	}

}
