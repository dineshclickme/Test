package com.xml.compare;

import java.io.File;

public class ReadFileNamesBean {
	private File legacyFile;
	private File targetFile;
	private String legacyFileName;
	private String targetFileName;
	
	public File getLegacyFile() {
		return legacyFile;
	}
	public void setLegacyFile(File legacyFile) {
		this.legacyFile = legacyFile;
	}
	public File getTargetFile() {
		return targetFile;
	}
	public void setTargetFile(File targetFile) {
		this.targetFile = targetFile;
	}
	public String getLegacyFileName() {
		return legacyFileName;
	}
	public void setLegacyFileName(String legacyFileName) {
		this.legacyFileName = legacyFileName;
	}
	public String getTargetFileName() {
		return targetFileName;
	}
	public void setTargetFileName(String targetFileName) {
		this.targetFileName = targetFileName;
	}
	public ReadFileNamesBean(File legacyFile, File targetFile,
			String legacyFileName, String targetFileName) {
		super();
		this.legacyFile = legacyFile;
		this.targetFile = targetFile;
		this.legacyFileName = legacyFileName;
		this.targetFileName = targetFileName;
	}
	public ReadFileNamesBean() {
		// TODO Auto-generated constructor stub
	}
	
}
