package com.xml.compare;

public class SummaryBean {
	
	private String legacyFileName;
	private String targetFileName;
	private String status;
	public String getLegacyFileName() {
		return legacyFileName;
	}
	public void setLegacyFileName(String legacyFileName) {
		this.legacyFileName = legacyFileName;
	}
	public String getTargetFileName() {
		return targetFileName;
	}
	public void setTargetFileName(String targetFileName) {
		this.targetFileName = targetFileName;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public SummaryBean(String legacyFileName, String targetFileName,
			String status) {
		super();
		this.legacyFileName = legacyFileName;
		this.targetFileName = targetFileName;
		this.status = status;
	}
	public SummaryBean() {
		
	}
	
	

}
