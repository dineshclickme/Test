package com.xml.compare;

public class DashboardBean {
	
	private int legacyCount;
	private int targetCount;
	private int legacyOnlyCount;
	private int targetOnlyCount;
	private int comparisonCount;
	private int passCount;
	private int failCount;
	private int errorCount;
	public int getLegacyCount() {
		return legacyCount;
	}
	public void setLegacyCount(int legacyCount) {
		this.legacyCount = legacyCount;
	}
	public int getTargetCount() {
		return targetCount;
	}
	public void setTargetCount(int targetCount) {
		this.targetCount = targetCount;
	}
	public int getLegacyOnlyCount() {
		return legacyOnlyCount;
	}
	public void setLegacyOnlyCount(int legacyOnlyCount) {
		this.legacyOnlyCount = legacyOnlyCount;
	}
	public int getTargetOnlyCount() {
		return targetOnlyCount;
	}
	public void setTargetOnlyCount(int targetOnlyCount) {
		this.targetOnlyCount = targetOnlyCount;
	}
	public int getComparisonCount() {
		return comparisonCount;
	}
	public void setComparisonCount(int comparisonCount) {
		this.comparisonCount = comparisonCount;
	}
	public int getPassCount() {
		return passCount;
	}
	public void setPassCount(int passCount) {
		this.passCount = passCount;
	}
	public int getFailCount() {
		return failCount;
	}
	public void setFailCount(int failCount) {
		this.failCount = failCount;
	}
	public int getErrorCount() {
		return errorCount;
	}
	public void setErrorCount(int errorCount) {
		this.errorCount = errorCount;
	}
	public DashboardBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	public DashboardBean(int legacyCount, int targetCount, int legacyOnlyCount,
			int targetOnlyCount, int comparisonCount, int passCount,
			int failCount, int errorCount) {
		super();
		this.legacyCount = legacyCount;
		this.targetCount = targetCount;
		this.legacyOnlyCount = legacyOnlyCount;
		this.targetOnlyCount = targetOnlyCount;
		this.comparisonCount = comparisonCount;
		this.passCount = passCount;
		this.failCount = failCount;
		this.errorCount = errorCount;
	}
	
}
