package com.design;


public class Tst {
public static void main(String[] args) {
	
	
	
	String url = "https://ftwdsdbg2g31.r1-core.r1.aig.net:10001/estart/servlet/gateway/EStartGateway";
	
	url = url.substring(url.indexOf("https://")+8, url.lastIndexOf(":"));
	
	System.out.println(url);
	
}
}
