package com.design;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.util.ConfigManager;
import com.xml.compare.ReadFileNames;
import com.xml.convert.GenerateGetSubmissionRequest;

public class Main extends JFrame{

	/**
	 * 
	 */
	private static final long serialVersionUID = -6818786701613534587L;
	public static JTextArea jtaStatus;
	JButton btnColse;
	public static boolean flag;
	public static String unKey="1B";
	
	static{
//		try{
//			File file = new File("");
//			BufferedReader br = new BufferedReader(new FileReader(file));
//			StringBuffer xmlStrTemp = new StringBuffer();
//			String line = null;
//			while ((line = br.readLine()) != null) {
//				xmlStrTemp.append(line);
//			}
//		}catch(Exception e){
//			e.printStackTrace();
//		}
		
	}
	
	public Main() {
		
		setLayout(null);
		jtaStatus=new JTextArea();
		jtaStatus.setLineWrap(true);
		JScrollPane jta=new JScrollPane(jtaStatus);
		jta.setBounds(20, 30, 450, 400);
		add(jta);
		
		btnColse=new JButton("Close");
		btnColse.setBounds(390, 440, 80, 25);
		add(btnColse);
		
		btnColse.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				System.exit(0);
			}
		});
		
		setSize(500, 500);
		setResizable(false);
		setTitle("Bulk XML Posting Tool::");
		setVisible(true);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	
	}
	
	public void setSSLConfig() {
		javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(new javax.net.ssl.HostnameVerifier() {

					public boolean verify(String hostname,
							javax.net.ssl.SSLSession sslSession) {
						String url = ConfigManager.getPropertyString("CES_URL", "http://ftwdsdbg2g31.r1-core.r1.aig.net:10001");
						url = url.substring(url.indexOf("https://")+8, url.lastIndexOf(":"));
						System.out.println("Certificate Path: "+ url);
						if (hostname.equals(url)) {
							jtaStatus.append("SSL configured successfully."+"\n");
							return true;
						}
						return false;
					}
					
				});
		
	}
	
	public void setSSLConfigForLegacy() {
		javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(new javax.net.ssl.HostnameVerifier() {

					public boolean verify(String hostname,
							javax.net.ssl.SSLSession sslSession) {
						String url = ConfigManager.getPropertyString("LEGACY_URL", "https://estart.aig.net/estart/servlet/gateway/EStartGateway");
						url = url.substring(url.indexOf("https://")+8, url.lastIndexOf(":"));
						System.out.println("Certificate Path: "+ url);
						if (hostname.equals(url)) {
							jtaStatus.append("SSL configured successfully."+"\n");
							return true;
						}
						return false;
					}
					
				});
		
	}

	public static void main(String[] args) {
		Main main = new Main();
		String url=null;
		
		boolean xmlConvertionIn =  true;
	
		flag = true;
		String inputFolder=null;
		String outputFolder=null;
		String inputFile=null;
		String finalResult=null;
		String count=null;
		String thread_pool_size=null;
		 inputFolder = ConfigManager.getPropertyString("INPUT_DIR", "");
		 outputFolder = ConfigManager.getPropertyString("OUTPUT_DIR", "");
		 inputFile = ConfigManager.getPropertyString("INPUT_FILE", "");
		 finalResult = ConfigManager.getPropertyString("FINAL_RESULT", "");
		 count = ConfigManager.getPropertyString("COUNT", "");
		 thread_pool_size = ConfigManager.getPropertyString("THREAD_POOL_SIZE", "");
		url = ConfigManager.getPropertyString("URL", "");
		String toReplace=ConfigManager.getPropertyString("TO_REPLACE", "");
//		inputFolder=args[0];
//		outputFolder=args[1];
//		inputFile=args[2];
//		thread_pool_size=args[3];
//		url=args[4];
		
		main.jtaStatus.append("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"+"\n");
		main.jtaStatus.append("Bulk posting started for below Gateway..."+"\n");
		main.jtaStatus.append("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"+"\n");
		main.jtaStatus.append("Server Details"+"\n");
		main.jtaStatus.append("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"+"\n");
		main.jtaStatus.append("-----------------------"+"\n");
		main.jtaStatus.append("Input File(s) Location : "+inputFolder+"\n");
		main.jtaStatus.append("-----------------------"+"\n");
		main.jtaStatus.append("Output File(s) Location : "+outputFolder+"\n");
		main.jtaStatus.append("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"+"\n\n");
		
		/*if(sslFlag.equalsIgnoreCase("YES")){
			main.setSSLConfig();
		}*/
		boolean goNxtIn = false;
		
		Utility utility = new Utility();
		//goNxtIn = utility.start(url, inputFolder, outputFolder, "_out_");
		goNxtIn = true;
		if(goNxtIn){
			
			main.jtaStatus.append("Service URL : "+url+"\n");

			main.jtaStatus.append("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"+"\n\n");
			BufferedReader br = null;
	        String line = "";
	        String cvsSplitBy = ",";
	        //String[] header=null;
	        String xmlStr="";
//		        try {
//		        	Integer i = 0;
//		        	
//		        	FileInputStream inputStream = new FileInputStream(new File(inputFile));
//		            
//		            Workbook workbook = new XSSFWorkbook(inputStream);
//		            Sheet firstSheet = workbook.getSheetAt(0);
//		            Iterator<Row> iterator = firstSheet.iterator();
//		            List<String> recordSet=new ArrayList<String>(); 
//		            List<String> headerSet=new ArrayList<String>(); 
//		            while (iterator.hasNext()) {
//		                Row nextRow = iterator.next();
//		                Iterator<Cell> cellIterator = nextRow.cellIterator();
//		                     
//		                recordSet=new ArrayList<String>(); 
//		                            //String[] record = line.split(cvsSplitBy);
//		                            while (cellIterator.hasNext()) {
//					                    Cell cell = cellIterator.next();
//					                    cell.setCellType(Cell.CELL_TYPE_STRING);
//					                    recordSet.add( cell.getStringCellValue());
//				                    	if(i==0){
//					                    	headerSet.add(cell.getStringCellValue());
//					                    }
//					                   /* switch (cell.getCellType()) {
//					                    case Cell.CELL_TYPE_STRING:
//					                    	recordSet.add( cell.getStringCellValue());
//					                    	if(i==0){
//						                    	headerSet.add(cell.getStringCellValue());
//						                    }
//					                    	break;
//					                    case Cell.CELL_TYPE_BOOLEAN:
//					                    	recordSet.add( String.valueOf(cell.getBooleanCellValue()));
//					                    	if(i==0){
//						                    	headerSet.add(String.valueOf(cell.getBooleanCellValue()));
//						                    }
//					                    	break;
//					                    case Cell.CELL_TYPE_NUMERIC:
//					                    	recordSet.add( String.valueOf(cell.getNumericCellValue()));
//					                    	if(i==0){
//						                    	headerSet.add(String.valueOf(cell.getNumericCellValue()));
//						                    }
//					                    	break;
//					                    }*/
//					                    
//		                            }
//					                if(i==0){
//					                	 i++;
//					                	continue;
//					                }
//					          
//					                xmlStr="{";
//					                for(int j=1;j<=recordSet.size()-1;j++){
//					                	if(recordSet.get(j)!=null && recordSet.get(j).trim().length()>0 ){
//					                		if( recordSet.get(j).equals("null")){
//					                			recordSet.set(j, "");
//					                		}
//					                		
//					                		if(recordSet.get(j).equals("{")){
//					                			
//					                			xmlStr+="\""+headerSet.get(j)+"\":";
//					                			xmlStr+="{";
//					                			continue;
//					                		}
//					                		if(recordSet.get(j).equals("}")){
//					                			xmlStr=xmlStr.substring(0, xmlStr.length()-1);
//					                			xmlStr+="},";
//					                			continue;
//					                		}
//						                	xmlStr+="\""+headerSet.get(j)+"\":\""+recordSet.get(j)+"\"";
//						                	if(recordSet.size()-1!=j){
//						                		xmlStr+=",";
//						                	}
//						                	
//						                	if(recordSet.size()-1==j){
//						                		xmlStr+="}";
//						                	}
//					                	}
//					                	
//					                }
//					                
//					                BufferedWriter writer = null;
//					        		try {
//					        			File file = new File(inputFolder+i+".txt");
//					        			i++;
//					        			file.createNewFile();
//					        			writer = new BufferedWriter(new FileWriter(file));
//					        			writer.write(xmlStr);
//					        		} catch (IOException e) {
//					        			e.printStackTrace();
//					        		} finally {
//					        			try {
//					        				writer.flush();
//					        				writer.close();
//					        			} catch (Exception localException1) {
//					        			}
//					        		}
//		                
//		            }
//		             
//		            inputStream.close();
//		           // br = new BufferedReader(new FileReader(inputFile));
//		 
//		            //while ((line = br.readLine()) != null) {
//		                
//		            //}
//			          
//
//		        } catch (FileNotFoundException e) {
//		            e.printStackTrace();
//		        } catch (IOException e) {
//		            e.printStackTrace();
//		        } 
//		        catch (Exception e) {
//					e.printStackTrace();
//				}finally {
//		            if (br != null) {
//		                try {
//		                    br.close();
//		                    
//		                } catch (IOException e) {
//		                    e.printStackTrace();
//		                }
//		            }
//		            
//		        }
				
			goNxtIn = utility.start(url, inputFolder, outputFolder, "_out_",thread_pool_size,finalResult,count, toReplace);
			
		}else{
			main.jtaStatus.append("Bulk posting failed in the ["+ url +"]server.\n");
		}
		
		
		/*************  Bulk posting ends here  ***************************/
	}
}
