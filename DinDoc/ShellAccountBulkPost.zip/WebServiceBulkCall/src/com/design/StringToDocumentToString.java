package com.design;
import java.io.File;
import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

public class StringToDocumentToString {

    public static void main(String[] args) throws ParserConfigurationException, SAXException, IOException {
        /*final String xmlStr = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n"+
                                "<Emp id=\"1\"><name>Pankaj</name><age>25</age>\n"+
                                "<role>Developer</role><gen>Male</gen></Emp>";*/
       
        String xml = "<add job=\"351\">\n" +
                "    <tag>foobar</tag>\n" +
                "    <tag>foobar2</tag>\n" +
                "</add>";
       //Document doc = convertStringToDocument(xml);
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = factory.newDocumentBuilder();
       Document doc = builder.parse(new File("sample.xml"));
        
  /* DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
  DocumentBuilder db = dbf.newDocumentBuilder();
  ByteArrayInputStream bis = new ByteArrayInputStream(xml.getBytes());
 Document doc = db.parse(bis);*/
   Node n = doc.getFirstChild();
//   NodeList nl = n.getChildNodes();
   NodeList nl = doc.getElementsByTagName("Wip");
   Node an,an2;

   for (int i=0; i < nl.getLength(); i++) {
       an = nl.item(i);
       if(an.getNodeType()==Node.ELEMENT_NODE) {
           NodeList nl2 = an.getChildNodes();

           for(int i2=0; i2<nl2.getLength(); i2++) {
               an2 = nl2.item(i2);
               
               //Element information = (Element) an2;
	           //System.out.println(information.getNodeValue());
	          
               // DEBUG PRINTS
              // System.out.print(an2.getNodeName() + ": type (" + an2.getNodeType() + "):");
               if(!an2.getNodeName().equalsIgnoreCase("#text")) {
            	   System.out.println("node name:"+an2.getNodeName() );
               }
               
               //if(an2.hasChildNodes()) System.out.println(an2.getFirstChild().getTextContent());
               if(an2.getNodeType()==Node.ELEMENT_NODE && an2.getNodeName().equalsIgnoreCase("WipId")) {
            	 ///  System.out.println(an2.getTextContent());
            	   Node ch = an2.getFirstChild();
            	   NodeList chLst = an2.getChildNodes();
            	   
            	  /* for (int j = 0; j < chLst.getLength(); j++) {
					Node chh = chLst.item(i);
					
					//Element information2 = (Element) chh;
			           //String lastName = information.getElementsByTagName("name").item(0).getTextContent();
			           
			           
			           //System.out.println(information2.getNodeValue());
					System.out.println(chh.getNodeName()+" : "+chh.getNodeValue());
	            	   if(chh.getNodeType()==Node.ELEMENT_NODE)
	            		   System.out.print(chh.getFirstChild().getNodeValue());
	            	   }
					
				}*/
               } 
            	   
              // System.out.println(an2.getTextContent());
               //System.out.println(", "+an2.getNodeValue());
               System.out.println("----------");
           }
       }
   }
        
        
        
      /*  doc.getDocumentElement().normalize();
        NodeList nEmployeesList = doc.getElementsByTagName("Emp");
        int totalEmployees = nEmployeesList.getLength();

     for (int a = 0; a < totalEmployees; a++)
     {
        Node list = nEmployeesList.item(a);  
        
        if (list.getNodeType() == Node.ELEMENT_NODE)
        {
        	 NodeList nl2 = list.getChildNodes();

             for(int i2=0; i2<nl2.getLength(); i2++) {
                 Node an2 = nl2.item(i2);
                 // DEBUG PRINTS
                 System.out.println(an2.getNodeName() + ": type (" + an2.getNodeType() + "):");
                 if(an2.hasChildNodes()) System.out.println(an2.getFirstChild().getTextContent());
                 if(an2.hasChildNodes()) System.out.println(an2.getFirstChild().getNodeValue());
                 System.out.println(an2.getTextContent());
                 System.out.println(an2.getNodeValue());
             }
             */
             
             
           /*Element information = (Element) list;
           String lastName = information.getElementsByTagName("name").item(0).getTextContent();
           String firstName = information.getElementsByTagName("age").item(0).getTextContent();
           System.out.println("Last name: " + lastName );
           System.out.println("First name: " + firstName);
           System.out.println();
           }
        }*/
        
       /* NodeList errNodes = doc.getElementsByTagName("Emp");
        if (errNodes.getLength() > 0) {
            Element err = (Element)errNodes.item(0);
            err.getNodeName();
            System.out.println(err.getNodeName());
            NodeList cNodes = err.getChildNodes();
            System.out.println(cNodes.getLength());
           for (int i = 0; i < cNodes.getLength(); i++) {
        	   Element n = (Element)errNodes.item(i);
              System.out.println(n.getNodeName());
		}
            //System.out.println(err.getElementsByTagName("name").item(0).getTextContent());
        } else { 
            // success
        }*/
        
   System.out.println("------------------  XML --------------------------");
        //String str = convertDocumentToString(doc);
       // System.out.println(str);
    }

    private static String convertDocumentToString(Document doc) {
        TransformerFactory tf = TransformerFactory.newInstance();
        Transformer transformer;
        try {
            transformer = tf.newTransformer();
            // below code to remove XML declaration
            // transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
            StringWriter writer = new StringWriter();
            transformer.transform(new DOMSource(doc), new StreamResult(writer));
            String output = writer.getBuffer().toString();
            return output;
        } catch (TransformerException e) {
            e.printStackTrace();
        }
        
        return null;
    }

    private static Document convertStringToDocument(String xmlStr) {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();  
        DocumentBuilder builder;  
        try  
        {  
            builder = factory.newDocumentBuilder();  
            Document doc = builder.parse( new InputSource( new StringReader( xmlStr ) ) ); 
            return doc;
        } catch (Exception e) {  
            e.printStackTrace();  
        } 
        return null;
    }

}