package com.design;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import org.dom4j.DocumentHelper;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.XMLWriter;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.bootstrap.DOMImplementationRegistry;
import org.w3c.dom.ls.DOMImplementationLS;
import org.w3c.dom.ls.LSSerializer;
import org.xml.sax.InputSource;

import com.parse.PostXML;

public class WriteToFile implements Runnable {
	private String inputXML;
	private String outputXML;
	private String url;
	private String proxyHost;
	private int proxyPort;
	private int count;
	private String toReplace;
	public static StringBuffer shellAcounts=new StringBuffer();

	public WriteToFile(String inputXML, String outputXML, String url,
			String proxyHost, int proxyPort,int count ,String toReplace ) {
		this.inputXML = inputXML;
		this.outputXML = outputXML;
		this.url = url;
		this.proxyHost = proxyHost;
		this.proxyPort = proxyPort;
		this.count = count;
		this.toReplace = toReplace;
	}

	public void run() {
		System.out.println("Thread Name "+Thread.currentThread().getName());
		long st = System.currentTimeMillis();
		String result = PostXML.postXMLString(null, this.inputXML, true, this.url, this.proxyHost, this.proxyPort,this.toReplace,this.count );
		long et = System.currentTimeMillis();
		//result = prettyPrint(DOM4JParserDemo.sortWips(result));
		if(result != null){
			int start=0;
			start=result.indexOf("Type='Info'>Shell Account ")+"Type='Info'>Shell Account ".length();
			int end=result.indexOf(" created successfully</Message>");
			try {
			if(start !=0 && end !=0){
				shellAcounts.append(result.substring(start,end)).append("\n");
			}
			}catch(Exception e) {
				
			}
		}
		//writeToFile(this.outputXML, result);
		//System.out.println("Time taken to process " + this.inputXML + " is : "	+ (et - st));
		Main.jtaStatus.append("Time taken to process " + new File(this.inputXML).getName() + " is : "	+ (et - st)+"ms.\n");
	}

	public String prettyPrint(final String xml){  
	    final StringWriter sw;

	    try {
	        final OutputFormat format = OutputFormat.createPrettyPrint();
	        final org.dom4j.Document document = DocumentHelper.parseText(xml);
	        sw = new StringWriter();
	        final XMLWriter writer = new XMLWriter(sw, format);
	        writer.write(document);
	    }
	    catch (Exception e) {
	    	Main.jtaStatus.append("Response stored as string due to error in pretty printing xml" + "\n");
	        //throw new RuntimeException("Response stored as string due to error in pretty printing xml:\n" + xml, e);
	    	return xml;
	    }
	    return sw.toString();
	}
	
	private static Document convertStringToDocument(String xmlStr) {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();  
        DocumentBuilder builder;  
        try  
        {  
            builder = factory.newDocumentBuilder();  
            Document doc = builder.parse( new InputSource( new StringReader( xmlStr ) ) ); 
            return doc;
        } catch (Exception e) {  
            e.printStackTrace();  
        } 
        return null;
    }
	
	private void writeToFile(String fileName, String fileContent) {
		BufferedWriter writer = null;
		try {
			File file = new File(fileName);
			file.createNewFile();
			writer = new BufferedWriter(new FileWriter(file));
			writer.write(fileContent);
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				writer.flush();
				writer.close();
			} catch (Exception localException1) {
			}
		}
	}
}