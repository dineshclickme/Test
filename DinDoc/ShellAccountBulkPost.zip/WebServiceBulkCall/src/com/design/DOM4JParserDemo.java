package com.design;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.Node;
import org.dom4j.io.SAXReader;
import org.dom4j.io.XMLWriter;

public class DOM4JParserDemo {
	
	public static String sortWips(String inputXML)   {
	    String returnXML = "";  
		try {
	         File inputFile = new File("sample.xml");
//	         SAXReader reader = new SAXReader();
//	         Document document = reader.read( inputFile );
	         Document document = DocumentHelper.parseText(inputXML);
	         document.normalize();
	        // System.out.println("Root element :" + document.getRootElement().getName());
	         Element classElement = document.getRootElement();
	         Node checkWipNodes = document.selectSingleNode("//EStartGatewayXML/GatewayData/SubmissionServiceXML/Response/Results/Submission/SubmissionInfo/SubmProductInfo/Wips" );
	         if(checkWipNodes != null){
	         List<Node> nodes = document.selectNodes("//EStartGatewayXML/GatewayData/SubmissionServiceXML/Response/Results/Submission/SubmissionInfo/SubmProductInfo" );
	         // copy wip nodes
	         Map<String, Map<String, Element>> sortedMap = new HashMap<String, Map<String,Element>>();
	         
	         Map<String, Element> tMap = null;
	         for (Node node : nodes) {
	            String prodCd = node.selectSingleNode("ProductCd").getText();
//	            System.out.println("\nCurrent Element :" + node.getName()+" - "+ prodCd);
	        	 List<Node> wipNodes = node.selectNodes(node.getUniquePath()+"/Wips/Wip");
	        	 tMap = new TreeMap<String, Element>();
	        	 for (Node wipNode : wipNodes) {
	        		 String wipId = wipNode.selectSingleNode("WipId").getText();
	                 tMap.put(wipId,((Element)wipNode).createCopy());
	        	 }
	        	 sortedMap.put(prodCd, tMap);
	        	
	        	 System.out.println("\n----------------------------");
	         }
	         
	         nodes = document.selectNodes("//EStartGatewayXML/GatewayData/SubmissionServiceXML/Response/Results/Submission/SubmissionInfo/SubmProductInfo" );
	         
	         //delete wip nodes
	         for (Node node : nodes) {
	             String prodCd = node.selectSingleNode("ProductCd").getText();
	             //System.out.println("\nDelete Element :" + node.getName()+" - "+ prodCd);
	         	 List<Node> wipNodes = node.selectNodes("//Wips/Wip");
	         	 for (Node wipNode : wipNodes) {
	                  wipNode.detach();
	         	 }
	         	// System.out.println("\n----------------------------");
	          }
	         nodes = document.selectNodes("//EStartGatewayXML/GatewayData/SubmissionServiceXML/Response/Results/Submission/SubmissionInfo/SubmProductInfo" );
	         //insert sorted element
	         int index =0;
	         for (Node node : nodes) {
	             String prodCd = node.selectSingleNode("ProductCd").getText();
	             System.out.println("\nCurrent Insert Element :" + node.getName()+" - "+ prodCd);
	         	 // sort wip id's
	             System.out.println("Node getUniquePath:"+node.getUniquePath());
	         	 Node sNode = node.selectSingleNode(node.getUniquePath()+"/Wips");
	              Element element = (Element) sNode;
	              Map<String, Element> tempMap =  sortedMap.get(prodCd);
	              Iterator<String> iter =    tempMap.keySet().iterator();
	              while (iter.hasNext()) {
	     			String key = (String) iter.next();
	     			Element wipElmt = tempMap.get(key);
//	     			System.out.println(wipElmt.selectSingleNode("WipId").getText());
	     			element.add(wipElmt);
	              }
	              
	              index++;
	         	 System.out.println("\n----------------------------");
	          }
	         }else{
	        	 System.out.println("Wips not available!");
	         }

	returnXML = document.asXML();
	      } catch (DocumentException e) {
	         e.printStackTrace();
	      }
		
		return returnXML;
	   }
	
	
	
   public static void main(String[] args) throws IOException {
      try {
         File inputFile = new File("sample.xml");
         SAXReader reader = new SAXReader();
         
//         new StringReader("");
         Document document = reader.read( inputFile );
         document = DocumentHelper.parseText("");
         //document.normalize();
         System.out.println("Root element :" + document.getRootElement().getName());
         Element classElement = document.getRootElement();
         Node checkWipNodes = document.selectSingleNode("//EStartGatewayXML/GatewayData/SubmissionServiceXML/Response/Results/Submission/SubmissionInfo/SubmProductInfo/Wips" );
         if(checkWipNodes != null){
         List<Node> nodes = document.selectNodes("//EStartGatewayXML/GatewayData/SubmissionServiceXML/Response/Results/Submission/SubmissionInfo/SubmProductInfo" );
         // copy wip nodes
         Map<String, Map<String, Element>> sortedMap = new HashMap<String, Map<String,Element>>();
         
         Map<String, Element> tMap = null;
         for (Node node : nodes) {
            String prodCd = node.selectSingleNode("ProductCd").getText();
            System.out.println("\nCurrent Element :" + node.getName()+" - "+ prodCd);
//            System.out.println("Student roll no : "  + node.valueOf("@rollno") );
        	 List<Node> wipNodes = node.selectNodes(node.getUniquePath()+"/Wips/Wip");
        	 tMap = new TreeMap<String, Element>();
        	 for (Node wipNode : wipNodes) {
        		 //System.out.println("wipNode :" + wipNode.getName());
        		 String wipId = wipNode.selectSingleNode("WipId").getText();
                 //System.out.print(wipId+",");
                 tMap.put(wipId,((Element)wipNode).createCopy());
        		 //tMap.put(wipId, wipNode.detach());
        	 }
        	 
        	              
        	 System.out.println("tMap.size():"+tMap.size());
        	 sortedMap.put(prodCd, tMap);
        	
        	 System.out.println("\n----------------------------");
         }
         
         nodes = document.selectNodes("//EStartGatewayXML/GatewayData/SubmissionServiceXML/Response/Results/Submission/SubmissionInfo/SubmProductInfo" );
         
         //delete wip nodes
         for (Node node : nodes) {
             String prodCd = node.selectSingleNode("ProductCd").getText();
             System.out.println("\nDelete Element :" + node.getName()+" - "+ prodCd);
         	 List<Node> wipNodes = node.selectNodes("//Wips/Wip");
         	 for (Node wipNode : wipNodes) {
                  wipNode.detach();
         	 }
         	 System.out.println("\n----------------------------");
          }
         nodes = document.selectNodes("//EStartGatewayXML/GatewayData/SubmissionServiceXML/Response/Results/Submission/SubmissionInfo/SubmProductInfo" );
         //insert sorted element
         int index =0;
         for (Node node : nodes) {
             String prodCd = node.selectSingleNode("ProductCd").getText();
             System.out.println("\nCurrent Insert Element :" + node.getName()+" - "+ prodCd);
         	 // sort wip id's
             
             System.out.println("Node path:"+node.getPath());
             System.out.println("Node getUniquePath:"+node.getUniquePath());
//             System.out.println("Node getUniquePath:"+node.get);
         	 Node sNode = node.selectSingleNode(node.getUniquePath()+"/Wips");
              Element element = (Element) sNode;
              Map<String, Element> tempMap =  sortedMap.get(prodCd);
              System.out.println("tempMap.size():"+tempMap.size());
              Iterator<String> iter =    tempMap.keySet().iterator();
              while (iter.hasNext()) {
     			String key = (String) iter.next();
     			//System.out.println(key);
     			Element wipElmt = tempMap.get(key);
     			//Element wipElmt = (Element) wipNode;
     			System.out.println(wipElmt.selectSingleNode("WipId").getText());
     			element.add(wipElmt);
              }
              
              index++;
         	 System.out.println("\n----------------------------");
          }
         }else{
        	 System.out.println("Wips not available!");
         }
         
       /*  for (int i = 0; i < sortedList.size(); i++) {
			
		}*/
         
         
        /* Node sNode = document.selectSingleNode("//EStartGatewayXML/GatewayData/SubmissionServiceXML/Response/Results/Submission/SubmissionInfo/SubmProductInfo/Wips");
         Element element = (Element) sNode;
         Iterator<String> iter =    tMap.keySet().iterator();
         while (iter.hasNext()) {
			String key = (String) iter.next();
			System.out.println(key);
			Node wipNode = tMap.get(key);
			Element wipElmt = (Element) wipNode;
			   // create a deep clone for the target document:
			   element.add(wipElmt);
			  // element.
			
//			element.add(wipNode);
			Element added = element.addElement(wipElmt.getName());
				added.addElement("WipId").addText(key);
				
				Iterator iterator=element.elementIterator("BusinessType");
			     while(iterator.hasNext()){
			      Element tmpElement=(Element)iterator.next();
			      tmpElement.setText("Ayesha");
			      added.addElement(tmpElement.getName()).addAttribute(, arg1)("").addText(tmpElement.getText());
			  
			     }
		}*/
         
System.out.println(document.asXML());
         XMLWriter output = new XMLWriter(new FileWriter( new File("sample-modified.xml") ));
        	     output.write( document );
        	     output.close();
         
         
         
      } catch (DocumentException e) {
         e.printStackTrace();
      }
   }
}