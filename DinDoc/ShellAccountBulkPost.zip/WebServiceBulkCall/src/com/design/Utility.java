package com.design;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.util.ConfigManager;

public class Utility {
	
	String url;
	String inputFolder;
	String outputFolder;
	String finalResult;
	String outFileTag;
	String toReplace;
	int cnt=1;
	public static int in=1;
	public static int count=0;
	
	public boolean start( String url, String inputFolder, String outputFolder, String outFileTag,String thread_pool_size , String finalResult, String count,String toReplace) {
		boolean okIn = false;
		this.url = url;
		this.inputFolder = inputFolder;
		this.outputFolder = outputFolder;
		this.finalResult = finalResult;
		this.outFileTag = outFileTag;
		this.toReplace = toReplace;
		
		this.cnt=Integer.parseInt(count);
		createOutputDirectory();
		String[] inputFiles = getInputFiles();
		if(processInputs(inputFiles,thread_pool_size))
			okIn = true;
		else
			okIn = false;
		
		return okIn;
	}

	private String[] getInputFiles() {
		String[] retVal = (String[]) null;

		File sourceDirectory = new File(this.inputFolder);

		if (!sourceDirectory.exists()) {
			System.err.println("Input Directory " + this.inputFolder	+ "does not exist.");
			Main.jtaStatus.append("Input Directory " + this.inputFolder	+ "does not exist."+"\n");
			//System.exit(1001);
		}

		if (sourceDirectory.isDirectory()) {
			retVal = sourceDirectory.list();
		} else {
			System.err.println("Input directory " + this.inputFolder	+ " is not a directory.");
			Main.jtaStatus.append("Input directory " + this.inputFolder	+ " is not a directory."+"\n");
			//System.exit(1002);
		}

		if ((retVal == null) || (retVal.length == 0)) {
			System.err.println("Input directory " + this.inputFolder	+ " does not contain any files.");
			Main.jtaStatus.append("Input directory " + this.inputFolder	+ " does not contain any files."+"\n");
			//System.exit(1003);
		}

		return retVal;
	}

	private void createOutputDirectory() {
		File targetDirectory = new File(this.outputFolder);

		if ((targetDirectory.exists()) && (targetDirectory.isDirectory())) {
		} else if (targetDirectory.isFile()) {
			System.err.println("A file with same name as output directory is identified. Please remove the file and try again. ");
			Main.jtaStatus.append("A file with same name as output directory is identified. Please remove the file and try again. "+"\n");
			//System.exit(1004);
		} else {
			//targetDirectory.mkdir();
			System.out.println("Created output directory "	+ this.outputFolder);
			Main.jtaStatus.append("Created output directory "	+ this.outputFolder+"\n");
		}
		
		File targetDirectory2 = new File(this.finalResult);
		if ((targetDirectory2.exists()) && (targetDirectory2.isDirectory())) {
		} else if (targetDirectory2.isFile()) {
			System.err.println("A file with same name as output directory is identified. Please remove the file and try again. ");
			Main.jtaStatus.append("A file with same name as output directory is identified. Please remove the file and try again. "+"\n");
			//System.exit(1004);
		} else {
			targetDirectory2.mkdir();
			System.out.println("Created output directory "	+ this.finalResult);
			Main.jtaStatus.append("Created output directory "	+ this.finalResult+"\n");
		}
		
		
		
	}

	private boolean processInputs(String[] inputFiles,String thread_pool_size) {
		boolean processIn = false;
		
		ThreadPool threadPool = new ThreadPool(Integer.parseInt(thread_pool_size));

		for (String inputFile : inputFiles) {
			for (this.count=0;this.count < this.cnt; this.count++) {
			String inputFileName = getAbsoluteInputFileName(inputFile);
			String outputFileName = getAbsoluteOutputFileName(inputFile);
			WriteToFile test = new WriteToFile(inputFileName, outputFileName, this.url, ConfigManager.PROXY_HOST, ConfigManager.PROXY_PORT,this.count,this.toReplace);

			threadPool.runTask(test);
			}
		}

		threadPool.join();
		System.out.println("2nd Thread Name "+Thread.currentThread().getName());
		processIn = true;
		System.out.println("Shell Accounts \n"+WriteToFile.shellAcounts);
		writeToFile(this.finalResult+"result.txt", WriteToFile.shellAcounts.toString());
		return processIn;
	}
	
	private void writeToFile(String fileName, String fileContent) {
		BufferedWriter writer = null;
		try {
			File file = new File(fileName);
			file.createNewFile();
			writer = new BufferedWriter(new FileWriter(file));
			writer.write(fileContent);
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				writer.flush();
				writer.close();
			} catch (Exception localException1) {
			}
		}
	}

	private String getAbsoluteInputFileName(String inputFileName) {
		return this.inputFolder + inputFileName;
	}

	private String getAbsoluteOutputFileName(String inputFileName) {
		SimpleDateFormat format = new SimpleDateFormat("dd_MMM_yyyy");
		return this.outputFolder + inputFileName.toLowerCase().replaceFirst(".xml", this.outFileTag + format.format(new Date()) + ".xml");
	}
}