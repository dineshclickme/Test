package com.aig.commercial.hip.aas.util;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class ServiceUtil {
	private ServiceUtil() {
		
	}
	public static String currentTimeStamp() {
		Calendar cal = Calendar.getInstance();
		Date currentTime = cal.getTime();
		SimpleDateFormat simpleFormatter = new SimpleDateFormat("yyyy-MM-dd'T'hh:mm:ss.SSS");
		return simpleFormatter.format(currentTime);
	}
}
