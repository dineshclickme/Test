package com.aig.commercial.hip.test;

import static org.junit.Assert.assertFalse;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import org.mule.api.MuleEvent;
import org.mule.munit.assertion.MunitAssertion;
import org.mule.util.IOUtils;
import org.xmlunit.builder.DiffBuilder;
import org.xmlunit.diff.Diff;


public class XMLUnitAssertEquals implements MunitAssertion {

	private String expectedXML = null;

	private List<String> attrIgnoreList = new ArrayList<String>();

	private List<String> nodeIgnoreList = new ArrayList<String>();

	private static final String PROPERTY_KEY_XML_TRANSFORMER_FACTORY = "javax.xml.transform.TransformerFactory";
	
	@Override
	public MuleEvent execute(MuleEvent event) throws AssertionError {

		try {
			System.setProperty(PROPERTY_KEY_XML_TRANSFORMER_FACTORY,
	                "com.sun.org.apache.xalan.internal.xsltc.trax.TransformerFactoryImpl");
			
			String payload = null;
			
			if(event.getMessage().getPayload()  instanceof InputStream){
				payload = IOUtils.toString((InputStream) event.getMessage().getPayload());
			} else {
				payload = event.getMessage().getPayloadAsString();
			}
			
			
			String expectedOutput = IOUtils.getResourceAsString(expectedXML, this.getClass());
					 
			
			Diff myDiff = DiffBuilder.compare(expectedOutput).withTest(payload).ignoreComments().ignoreWhitespace()
					.withNodeFilter(node -> !nodeIgnoreList.contains(node.getNodeName()))
					.withAttributeFilter(attr -> !attrIgnoreList.contains(attr.getName()))
					/*.withDifferenceEvaluator(
							(DifferenceEvaluator) new IgnoreAttributeDifferenceEvaluator(attrIgnoreList))*/
					.checkForSimilar().build();

			assertFalse(myDiff.toString(), myDiff.hasDifferences());

		} catch (Exception e) {
			throw new AssertionError("XML match failed", e);
		} finally {
			System.clearProperty(PROPERTY_KEY_XML_TRANSFORMER_FACTORY);
		}

		return event;

	}

	public List<String> getAttrIgnoreList() {
		return attrIgnoreList;
	}

	public void setAttrIgnoreList(List<String> attrIgnoreList) {
		this.attrIgnoreList = attrIgnoreList;
	}

	public List<String> getNodeIgnoreList() {
		return nodeIgnoreList;
	}

	public void setNodeIgnoreList(List<String> nodeIgnoreList) {
		this.nodeIgnoreList = nodeIgnoreList;
	}

	public String getExpectedXML() {
		return expectedXML;
	}

	public void setExpectedXML(String expectedXML) {
		this.expectedXML = expectedXML;
	}

}
