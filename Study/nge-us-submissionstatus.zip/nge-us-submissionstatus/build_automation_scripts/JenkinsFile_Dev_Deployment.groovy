node('windows || linux'){
   try{
   		def node_os = isUnix() ? 'LINUX' : 'WIN'
        def gitpipelinerepo = 'github.aig.net/commercial-it-config/devops-mule-apps-devcicd.git';
        clonerepo(node_os,gitpipelinerepo,"master");

		def pipelnscrpt = "devops-mule-apps-devcicd/apps/jenkinsjob/Mule-App-Deployment-Mgmt-DEV.groovy";	
		echo "Executing the pipeline script from config repo"
		load pipelnscrpt
    }finally{
      	deleteDir();
   }
}

def clonerepo(nodeOs, gitRepo, branchName){
	try{
		withCredentials([string(credentialsId: 'comm_git_clone_token', variable: 'comm_git_clone_token')]){
			if(nodeOs == 'WIN') {
				bat "git clone -b ${branchName} https://${comm_git_clone_token}@${gitRepo}";
				println "Cloned the repo";
			}else{
				sh "scl enable rh-git29 -- git clone -b ${branchName} https://${comm_git_clone_token}@${gitRepo}";
			}
		}
		println "Cloned repo - ${gitRepo}, branch - ${branchName}";
	}catch(Exception e){
		println "Failed to clone repo - ${gitRepo}";
		throw e;
	}
}
