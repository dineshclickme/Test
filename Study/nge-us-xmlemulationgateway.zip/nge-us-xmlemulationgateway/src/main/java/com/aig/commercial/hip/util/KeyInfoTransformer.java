package com.aig.commercial.hip.util;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.Node;
import org.dom4j.XPath;
import org.dom4j.io.SAXReader;
import org.mule.api.MuleMessage;
import org.mule.api.transformer.TransformerException;
import org.mule.transformer.AbstractMessageTransformer;

public class KeyInfoTransformer extends AbstractMessageTransformer {

	private static final String METHODNAME = "methodname";
	private static final String SERVICENAME = "servicename";
	private static final String IS_EMPTY_OR_INVALID_VALID_FORMAT = " is empty or invalid. Valid format : aig.logger.<ServiceName>.<MethodName>.req.keyInfo=keyInfo1=xpath,keyInfo2=xpath. Check. ";
	private static final String REQUEST_FLOW_DIRECTION = "req";
	private static final String KEY_INFO = "keyInfo";
	private static final int TOKEN_COUNT = 2;
	private static final Logger LOGGER = Logger.getLogger(KeyInfoTransformer.class);
	private static Properties prop = new Properties();
	private static List<String> piiList;
	private String flowDirection;
	
	static {
		try {
			prop.load(Thread.currentThread().getContextClassLoader().getResourceAsStream("config/application.properties"));
			piiList = new ArrayList<String>(Arrays.asList(prop.getProperty("aig.logger.pii").split(",")));
		} catch (IOException e) {
			LOGGER.error("Error loading config/application.properties.", e);
		}		
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public Object transformMessage(MuleMessage message, String outputEncoding) throws TransformerException {
		Document document = null;
		try {
			document = createDocument(message.getPayloadAsBytes());
		} catch (Exception e) {
			LOGGER.error("Error getting payload as bytes.", e);
		}
		if(REQUEST_FLOW_DIRECTION.equals(flowDirection)){
			message.setInvocationProperty(KEY_INFO, getRequestKeyInfo(document));			
		} else {
			setResponseKeyInfo(document, (LinkedHashMap<String, String>)message.getInvocationProperty(KEY_INFO));
		}
		return message;
	}
	
	/**
	 * sets keyInfo from request
	 * @param document
	 * @return
	 */
	private LinkedHashMap<String, String> getRequestKeyInfo(Document document) {
		LinkedHashMap<String, String> keyInfo = new LinkedHashMap<String, String>();
		String serviceName = getServiceName(document);
		String methodName = getMethodName(document);
		populateServiceKeyInfo(keyInfo, serviceName, methodName);
		Document request = convertXMLStringToDocument(document, "//Request");
		populateIdentityKeyInfo(keyInfo, request);
		populateOperationKeyInfo(keyInfo, getKey(serviceName, methodName), request);
		return keyInfo;
	}

	/**
	 * updates keyInfo from response
	 * @param document
	 * @param keyInfo
	 */
	private void setResponseKeyInfo(Document document, LinkedHashMap<String, String> keyInfo){
		Document response = convertXMLStringToDocument(document, "//XMLEmulationRs");
		populateOperationKeyInfo(keyInfo, getKey(keyInfo.get(SERVICENAME), keyInfo.get(METHODNAME)), response);		
	}
	
	/**
	 * name of the property that identifies keyInfo fields with xpaths
	 * @param serviceName
	 * @param methodName
	 * @return
	 */
	private String getKey(String serviceName, String methodName) {
		return "aig.logger." + serviceName + "." + methodName + "." + flowDirection + ".keyInfo";
	}

	/**
	 * Create a Document from payload xml (sent in CDATA or escaped format) embedded in Request element.
	 * @param document
	 * @return
	 */
	private Document convertXMLStringToDocument(Document document, String xpath) {
		String requestString = getSingleNodeValueFromDocument(document, xpath);
		return	createDocument(requestString.getBytes());
	}
	
	
	/**
	 * Populate operation-level
	 * @param keyInfo
	 * @param xpathPropertyName
	 * @param document
	 */
	private void populateOperationKeyInfo(LinkedHashMap<String, String> keyInfo, String xpathPropertyName,
			Document document) {
		try{
			if(isKeyInfoList(xpathPropertyName)){
				String xpathList = 	prop.getProperty(xpathPropertyName + "List"); 
				String[] key = xpathList.trim().split("=");
				if(key != null && key.length == TOKEN_COUNT)
				{
					List<Node> nodes = getMultipleNodeValues(document, key[1]);
					int i=0;
					for(Node node:nodes){
						populateOperationSingleKeyInfo(keyInfo, key[0], i, xpathPropertyName, node);
						i++;
					}
				}
			} else {
				populateOperationSingleKeyInfo(keyInfo, xpathPropertyName, document);
			}
		}catch(Exception e){
			LOGGER.error("populateOperationKeyInfo unexpected error - " + xpathPropertyName, e);
		}
	}

	@SuppressWarnings("unchecked")
	private List<Node> getMultipleNodeValues(Document document, String xpathList) {
		XPath xpathVar = document.getRootElement().createXPath(xpathList);
		return (List<Node>)xpathVar.selectNodes(document.getRootElement());
	}

	private void populateOperationSingleKeyInfo(LinkedHashMap<String, String> keyInfo, String listKey, int listIndex, String xpathPropertyName, Node node){
		if(prop.getProperty(xpathPropertyName) != null){
			//split the keyinfo fields separated by comma; ex: aig.logger.<ServiceName>.<MethodName>.req.keyInfo=keyInfo1=xpath,keyInfo2=xpath
			String[] keyInfoXpaths = prop.getProperty(xpathPropertyName).trim().split(",");
			if(keyInfoXpaths != null){
				for(String keys: keyInfoXpaths){
					//separate the key and xpath for keyInfo field
					String[] key = keys.trim().split("=");
					if(key != null && key.length == TOKEN_COUNT){
						//extract xpath value and add it to keyInfo map
						keyInfo.put(listKey + "_" + listIndex + "_" + key[0] , getSingleNodeValueFromNode(node, key[1]));
					} else {
						logger.warn(xpathPropertyName + IS_EMPTY_OR_INVALID_VALID_FORMAT + keys +".");
					}
				}
			} else {
				logger.warn(xpathPropertyName + IS_EMPTY_OR_INVALID_VALID_FORMAT);
			}
		}		
	}
	
	private void populateOperationSingleKeyInfo(LinkedHashMap<String, String> keyInfo, String xpathPropertyName, Document document) {
		if(prop.getProperty(xpathPropertyName) != null){
			//split the keyinfo fields separated by comma; ex: aig.logger.<ServiceName>.<MethodName>.req.keyInfo=keyInfo1=xpath,keyInfo2=xpath
			String[] keyInfoXpaths = prop.getProperty(xpathPropertyName).trim().split(",");
			if(keyInfoXpaths != null){
				for(String keys: keyInfoXpaths){
					//separate the key and xpath for keyInfo field
					String[] key = keys.trim().split("=");
					if(key != null && key.length == TOKEN_COUNT){
						//extract xpath value and add it to keyInfo map
						keyInfo.put(key[0], getSingleNodeValueFromDocument(document, key[1]));
					} else {
						logger.warn(xpathPropertyName + IS_EMPTY_OR_INVALID_VALID_FORMAT + keys +".");
					}
				}
			} else {
				logger.warn(xpathPropertyName + IS_EMPTY_OR_INVALID_VALID_FORMAT);
			}
		}
	}

	private boolean isKeyInfoList(String xpathPropertyName) {
		return prop.getProperty(xpathPropertyName + "List") != null;
	}

	/**
	 * Populate ServiceName and MethodName in keyInfo.
	 * @param keyInfo
	 * @param serviceName
	 * @param methodName
	 */
	private void populateServiceKeyInfo(LinkedHashMap<String, String> keyInfo, String serviceName, String methodName) {
		keyInfo.put(SERVICENAME, serviceName);
		keyInfo.put(METHODNAME, methodName);
	}

	/**
	 * Populate application_id and user_id (from request XML) in keyInfo.
	 * @param keyInfo
	 * @param document
	 */
	private void populateIdentityKeyInfo(LinkedHashMap<String, String> keyInfo, Document request){
		keyInfo.put("application_id", getSingleNodeValueFromDocument(request, "//Identity/application_id"));
		keyInfo.put("user_id", getSingleNodeValueFromDocument(request, "//Identity/user_id"));
	}

	/**
	 * Retrieve service name.
	 * @param document
	 * @return
	 */
	private String getServiceName(Document document) {
		return getSingleNodeValueFromDocument(document, "//ServiceName");
	}
	
	/**
	 * Retrieve operation name.
	 * @param document
	 * @return
	 */
	private String getMethodName(Document document) {
		return getSingleNodeValueFromDocument(document, "//MethodName");
	}
	
	/**
	 * Create dom4j Document from request/payload xml.
	 * @param message
	 * @return
	 */
	private Document createDocument(byte[] bytes) {
		Document document = null;
		try {
			SAXReader reader = new SAXReader();
			document = reader.read(new ByteArrayInputStream(bytes));
		} catch (Exception e) {
			LOGGER.error("Error creating dom4j document from request payload.", e);
		}
		return document;
	}

	/**
	 * From the given node, retrieve the first element value that matches xpath.
	 * @param document
	 * @param xpath
	 * @return
	 */
	private String getSingleNodeValueFromNode(Node searchNode, String xpath){
		String result = null;
		XPath xpathVar = searchNode.createXPath(xpath);
		Node node = xpathVar.selectSingleNode(searchNode);
		if (node != null ) {
			Element element = (Element) node;
			result = element.getStringValue();
		} else {
			result = "";
			logger.warn(xpath + IS_EMPTY_OR_INVALID_VALID_FORMAT);
		}
		return checkNApplyPIIMask(xpath, result);
	}

	/**
	 * From the given document, retrieve the first element value that matches xpath.
	 * @param document
	 * @param xpath
	 * @return
	 */
	private String getSingleNodeValueFromDocument(Document document, String xpath){
		String result = null;
		XPath xpathVar = document.getRootElement().createXPath(xpath);
		Node node = xpathVar.selectSingleNode(document.getRootElement());
		if (node != null ) {
			Element element = (Element) node;
			result = element.getStringValue();
		} else {
			result = "";
			logger.warn(xpath + IS_EMPTY_OR_INVALID_VALID_FORMAT);
		}
		return checkNApplyPIIMask(xpath, result);
	}

	private String checkNApplyPIIMask(String xpath, String result) {
		if(piiList.contains(xpath)){
			return result.replaceAll("(?<=.).", "*");
		}
		return result;
	}

	public String getFlowDirection() {
		return flowDirection;
	}

	public void setFlowDirection(String flowDirection) {
		this.flowDirection = flowDirection;
	}
	
}
