package com.aig.commercial.hip;

import org.dom4j.*;
import org.dom4j.io.SAXReader;

import java.io.ByteArrayInputStream;
import java.util.*;

public class WSDLUtil {

	private static final String LOCATION = "location";
	private static final String HTTP_PROTOCOL = "http:";
	private static final String HTTPS_PROTOCOL = "https:";
	private static final String UNCHECKED = "unchecked";

	private WSDLUtil(){
		//private constructor to hide the implicit public one.
	}
	
	public static String convertURLsToHttps(String originalWsdl) throws DocumentException{
		SAXReader reader = new SAXReader();
		Document originalWsdlDoc = reader.read(new ByteArrayInputStream(originalWsdl.getBytes()));
		convertWsdlUrlsToHttps(originalWsdlDoc);
		convertXsdUrlsToHttps(originalWsdlDoc);
		convertSOAPAddressUrlsToHttps(originalWsdlDoc);
		return originalWsdlDoc.asXML();
	}

	private static void convertSOAPAddressUrlsToHttps(Document originalWsdlDoc) {
		Map<String, String> nameSpaceURIs = new HashMap<String, String>();
		nameSpaceURIs.put("soap", "http://schemas.xmlsoap.org/wsdl/soap/");
		XPath xpathVar = originalWsdlDoc.getRootElement().createXPath("//soap:address");
		xpathVar.setNamespaceURIs(nameSpaceURIs);
		@SuppressWarnings(UNCHECKED)
		List<Node> nodes = xpathVar.selectNodes(originalWsdlDoc.getRootElement());
		if (nodes != null && !nodes.isEmpty()) {
			for (Node node : nodes) {
				Element element = (Element) node;
				Attribute attribute = element.attribute(LOCATION);
				attribute.setText(attribute.getText().replaceAll(HTTP_PROTOCOL, HTTPS_PROTOCOL));
			}
			originalWsdlDoc.normalize();
		}
	}

	private static void convertXsdUrlsToHttps(Document originalWsdlDoc) {
		Map<String, String> nameSpaceURIs = new HashMap<String, String>();
		nameSpaceURIs.put("xsd", "http://www.w3.org/2001/XMLSchema");
		XPath xpathVar = originalWsdlDoc.getRootElement().createXPath("//xsd:import");
		xpathVar.setNamespaceURIs(nameSpaceURIs);
		@SuppressWarnings(UNCHECKED)
		List<Node> nodes = xpathVar.selectNodes(originalWsdlDoc.getRootElement());
		if (nodes != null && !nodes.isEmpty()) {
			for (Node node : nodes) {
				Element element = (Element) node;
				Attribute attribute = element.attribute("schemaLocation");
				attribute.setText(attribute.getText().replaceAll(HTTP_PROTOCOL, HTTPS_PROTOCOL));
			}
			originalWsdlDoc.normalize();
		}
	}

	private static void convertWsdlUrlsToHttps(Document originalWsdlDoc) {
		Map<String, String> nameSpaceURIs = new HashMap<String, String>();
		nameSpaceURIs.put("wsdl", "http://schemas.xmlsoap.org/wsdl/");
		XPath xpathVar = originalWsdlDoc.getRootElement().createXPath("//wsdl:import");
		xpathVar.setNamespaceURIs(nameSpaceURIs);
		@SuppressWarnings(UNCHECKED)
		List<Node> nodes = xpathVar.selectNodes(originalWsdlDoc.getRootElement());
		if (nodes != null && !nodes.isEmpty()) {
			for (Node node : nodes) {
				Element element = (Element) node;
				Attribute attribute = element.attribute(LOCATION);
				attribute.setText(attribute.getText().replaceAll(HTTP_PROTOCOL, HTTPS_PROTOCOL));
			}
			originalWsdlDoc.normalize();
		}
	}
}
