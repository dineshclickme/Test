package com.aig.commercial.hip;

public class XMLConversionUtil {

	private static final String START_XML_TAG = "<_xml:";

	private static final String GATEWAY_DATA2 = "<GatewayData>";

	private static final String DIARY_SERVICE_XML = "<DiaryServiceXML";

	private static final String CLOSE_XML_TAG = "</_xml:";

	private static final String GATEWAY_DATA = "</GatewayData>";

	private XMLConversionUtil(){
		//private constructor to hide the implicit public one.
	}
	
	public static String formatXMLtoLegacy(String inputXML) {
		String result = inputXML.replace("<p:", "<").replace("</p:", "</");
		result = result.replace(START_XML_TAG, "<").replace(CLOSE_XML_TAG, "</");

		int legacyXMLStarts = result.indexOf("XML\">") + 6;
		int legacyXMLEnds = result.lastIndexOf("</EStartGatewayXML>") - 1;
		if (legacyXMLStarts > 0 && legacyXMLEnds > 0) {
			result = result.substring(legacyXMLStarts, legacyXMLEnds);

		}
		
		if(-1 != result.indexOf(GATEWAY_DATA2)) {
			result = result.substring(result.indexOf(GATEWAY_DATA2)
				+ GATEWAY_DATA.length(), result.indexOf(GATEWAY_DATA));
		} else {
			String splitEnd=result.substring(result.indexOf(DIARY_SERVICE_XML)+DIARY_SERVICE_XML.length());
			result = DIARY_SERVICE_XML+splitEnd.substring(splitEnd.indexOf(">"));
		}
			
		return result;
	}
	
	public static String removeNamespaces(String inputXML) {
		String result = inputXML.replace("<p:", "<").replace("</p:", "</");
		result = result.replace(START_XML_TAG, "<").replace(CLOSE_XML_TAG, "</");
		return result.replaceAll("(<\\?[^<]*\\?>)?", ""). /* remove preamble */
				  replaceAll(" xmlns.*?(\"|\').*?(\"|\')", "") /* remove xmlns declaration */
				  .replaceAll(" xsi:.*?(\"|\').*?(\"|\')", "") /* remove xsi declaration */
				  .replaceAll("(<)(\\w+:)(.*?>)", "$1$3") /* remove opening tag prefix */
				  .replaceAll("(</)(\\w+:)(.*?>)", "$1$3")
				  .replaceAll("<(\\w+)/>", "<$1></$1>")/* convert self closing tag to start and end tag */;
	}
	
	
	public static String removeRequestMessageID(String inputXML) {
		String result = inputXML.replaceAll("<request_message_id>[\\s\\S]*?</request_message_id>","");
		return result;
		
	}
	
}
