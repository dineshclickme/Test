# nge-us-xmlemulationgateway

## Local Setup Instructions:
* Follow the basic instructions here http://confluence.aig.net:8090/display/CI/Mule+Code+-+Local+Env+setup+and+Deploy+Instructions.
* Get the code.  
    * git clone https://github.aig.net/commercial-it-integration/nge-us-xmlemulationgateway.git
* Import the code to Anypoint Studio using 'Maven-based Mule Project using pom.xml' option.
* Create keyfile.properties file under C:/Temp/Props (or any other folder) and enter below values in the file:  
   vault.key=Synergy123456789
* Update the tls-default.conf under C:\AnypointStudio\plugins\org.mule.tooling.server.3.9.0.ee_6.4.1.201710111930\mule\conf.  
   enabledProtocols=TLSv1,TLSv1.1,TLSv1.2
* Open command prompt as Administrator and configure the certificates using keytool commands as defined at below URL: 
http://confluence.aig.net:8090/display/CI/Certs+for+Developers
* Run the app with the following vm Settings in VM arguments.  
  -XX:PermSize=128M -XX:MaxPermSize=256M -DskipTests -Dmule.env=dev -Dmule.propertiesFolder=C:/Temp/Props
* Test the app using soapui ui project xml (if) available under /src/test/resources/soapUiProject/