# nge-us-submissionstatus-bpel
BPEL flow for RPC and DPQLSP 
