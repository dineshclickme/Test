package com.aig.nge.emu.service;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import com.aig.nge.emu.api.legacysubmissionutil.HandleTransferProductReq;
import com.aig.nge.emu.api.legacysubmissionutil.HandleTransferProductReqResponse;
import com.aig.nge.emu.api.legacysubmissionutil.HandleTransferProductResp;
import com.aig.nge.emu.test.BaseTest;
import com.aig.nge.emu.util.common.SubmissionException;
import com.aig.nge.emu.xsd.service.legacy.submissionService.Arguments;
import com.aig.nge.emu.xsd.service.legacy.submissionService.Identity;
import com.aig.nge.emu.xsd.service.legacy.submissionService.ProductCoverageType;
import com.aig.nge.emu.xsd.service.legacy.submissionService.Request;
import com.aig.nge.emu.xsd.service.legacy.submissionService.SubmissionServiceXML;
import com.aig.nge.emu.xsd.service.legacy.submissionService.TransferFrom;
import com.aig.nge.emu.xsd.service.legacy.submissionService.TransferProduct;
import com.aig.nge.emu.xsd.service.legacy.submissionService.TransferTo;

public class TransferProductImplTest extends BaseTest {
	TransferProductImpl tp; 
	com.aig.nge.emu.api.legacysubmissionutil.ObjectFactory of;

	@Before
	public void setUp() throws Exception {
		super.setUp();
		tp=new TransferProductImpl();
		of = new com.aig.nge.emu.api.legacysubmissionutil.ObjectFactory();
	}

	//@Test
	public void testProcessRequest() throws SubmissionException {
		SubmissionServiceXML submissionServiceXML = getTestSubmissionServiceXMLData();
		HandleTransferProductReq handleTransferProductReq = of.createHandleTransferProductReq();
		handleTransferProductReq.setSubmissionServiceXML(submissionServiceXML);
		HandleTransferProductReqResponse handleTransferProductReqResponse = tp.processRequest(handleTransferProductReq);
		assertTrue(handleTransferProductReqResponse.getSubmissionServiceXML().getResponse() == null || handleTransferProductReqResponse.getSubmissionServiceXML().getResponse().getErrors().getCount() == null);
	}
	
	//@Test
	public void testProcessRes() throws SubmissionException {
		SubmissionServiceXML submissionServiceXML = getTestSubmissionServiceXMLData();
		HandleTransferProductResp handleTransferProductResp = of.createHandleTransferProductResp();
		handleTransferProductResp.setSubmissionServiceXML(submissionServiceXML);
		assertNull(tp.processRes(handleTransferProductResp).getSubmissionServiceXML().getResponse().getErrors().getCount());
	}

	private SubmissionServiceXML getTestSubmissionServiceXMLData() {
		com.aig.nge.emu.xsd.service.legacy.submissionService.ObjectFactory of = new com.aig.nge.emu.xsd.service.legacy.submissionService.ObjectFactory();
		SubmissionServiceXML submissionServiceXML = of.createSubmissionServiceXML();
		Identity identity = of.createIdentity();
		identity.setApplicationId("NGE");
		identity.setUserId("rkamiset");
		submissionServiceXML.setIdentity(identity);
		Request request = of.createRequest();
		TransferTo transferTo = of.createTransferTo();
		transferTo.setProfitCenterCd("00");
		transferTo.setProfitUnitCd("0000");
		transferTo.setSectionCd("000");
		transferTo.setUnderwriterId("ANMAMBR");
		transferTo.setWorkingBranchCd("03");
		TransferFrom transferFrom = of.createTransferFrom();
		transferFrom.setProductCd("HULL");
		ProductCoverageType pct = of.createProductCoverageType();
		pct.setOptions("P");
		transferFrom.setProductCoverageType(pct);
		transferFrom.setSubmissionNo("280996713");
		Arguments args = of.createArguments();
		TransferProduct transferProduct = of.createTransferProduct();
		transferProduct.setTransferFrom(transferFrom);
		transferProduct.setTransferTo(transferTo);
		args.setTransferProduct(transferProduct);
		request.setArguments(args);
		submissionServiceXML.setRequest(request);
		return submissionServiceXML;
	}

}
