package com.aig.nge.emu.test;

import org.junit.After;
import org.junit.Before;
import org.junit.runner.RunWith;
import org.mule.api.MuleContext;
import org.mule.config.spring.SpringXmlConfigurationBuilder;
import org.mule.context.DefaultMuleContextFactory;

import com.aig.nge.emu.util.common.NGESession;
import com.aig.nge.emu.util.common.PropertiesHandler;
import com.aig.nge.emu.util.common.SessionModel;
//import org.springframework.test.context.ContextConfiguration;
//import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
// 
//@RunWith(SpringJUnit4ClassRunner.class)
//@ContextConfiguration(locations = { "classpath*:spring-config-test.xml" })
public class BaseTest {	
	
	@Before
	public void setUp() throws Exception {
		System.setProperty("mule.env", "dev");
		PropertiesHandler.loadAllPropertyFiles();
		SessionModel sessionModel = new SessionModel();
		sessionModel.setServiceName("SUBMISSION_SERVICE");
		NGESession.setSessionData(sessionModel);

		MuleContext muleContext = new DefaultMuleContextFactory().createMuleContext(new SpringXmlConfigurationBuilder("spring-beans-test.xml"));
		muleContext.start();
	}

	@After
	public void tearDown() throws Exception {
	}

}
