package com.aig.nge.emu.dao;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.aig.nge.emu.test.BaseTest;

public class CommonDAOTest extends BaseTest {
	CommonDAO commonDAO;
	
	@Before
	public void setUp() throws Exception {
		super.setUp();
		commonDAO = new CommonDAO();
		Logger.getRootLogger().setLevel(Level.DEBUG);
	}

	@After
	public void tearDown() throws Exception {
	}

	//@Test
	public void testUpdateBundleProfitCenterCd() throws Exception{
		commonDAO.updateBundleProfitCenterCd("00", 112693900, (short) 1, "rkamiset", "000", "0000");
	}

	//@Test
	public void testCacheProfitCenterCd() throws Exception{
		commonDAO.cacheProfitCenterCd();
	}
}
