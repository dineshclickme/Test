package com.aig.nge.emu.util.common;

import static org.junit.Assert.*;

import java.net.URL;
import java.net.URLClassLoader;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.aig.nge.emu.test.BaseTest;

public class PropertiesHandlerTest extends BaseTest {
	
	@Before
	public void setUp() throws Exception {	
		super.setUp();
	}

	private void printClassPaths() {
		URL[] urls = ((URLClassLoader) (Thread.currentThread().getContextClassLoader())).getURLs();
		for (URL url: urls) {
		    System.out.println(url.getFile());
		}
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testGetPropertyDirectory() throws Exception{
		System.setProperty("mule.env", "dev");
		assertEquals("properties/dev/", PropertiesHandler.getPropertyDirectory());
		System.clearProperty("nge.region");
	}

	@Test
	public void testGetApplicationRootDirectory() {
		assertEquals("properties/", PropertiesHandler.getApplicationRootDirectory());
	}

	//@Test
	public void testLoadAllPropertyFiles() throws Exception{
		printClassPaths();
		//System.out.println(Thread.currentThread().getContextClassLoader().getResource("properties/dev/queries.properties"));
		PropertiesHandler.loadAllPropertyFiles();
		assertNotNull(PropertiesHandler.allProperties.get("queries.properties"));
	}

	
}
