
> Create a sequence diagram to flush out the details of backend calls.

> For every operation, Submission calls LegacySubmissionUtil two times during request and during response it call one of the three operations ending with Resp, Error, Fault. For each of these four operations, establish input and output. 

> Once the input and output schemas are established, update LegacySubmissionUtil wsdl/xsd. Rajesh created wsdl for transferProduct and Poonam has updated the wsdl for handleUpdateSubmissionDetails. Creation of WSDL

> After updating WSDL (src\main\wsdl), update binding.xjb to pick proper java package name for any new xsds. The package names should be same as what you find in use by LegacySubmissionUtil java code (src\main\java).

Note: If package names used to reference input/output schemas in handle* methods are different from what we find in the java code, then we will run into issues while converting de/serialization.

> Once WSDL is ready, verify the changes by loading the new WSDL to soapui and creating sample requests and responses. If you don't find the expected operation, double check WSDL and if the operation is empty, check WSDL and XSDs.

> After WSDL work is done, the next task is to compile LegacySubmissionUtil.xsd to generate JAXB classes for the new handle* methods. To perform that, go to src\main\wsdl directory and run the following command. 

                mvn -X clean org.jvnet.jaxb2.maven2:maven-jaxb2-plugin:0.13.3:generate > output.txt

Inspect output.txt, if there are any errors, address them. If no errors, then copy the newly generated JAXB classes (including ObjectFactory.java and package-info.java) for handle method from the following folder

                src\main\wsdl\target\generated-sources\xjc\com\aig\nge\emu\api\legacysubmissionutil

and copy them to 

                src\main\java\com\aig\nge\emu\api\legacysubmissionutil

At this point, you can share the updated WSDL and XSDs with Submission service team.

Refer: the commit with the message "update schema and generate handleUpdateSubmissionDetailsResp, Error and Fault classes" in nge-us-legacy-submissionutil for an example of this work.