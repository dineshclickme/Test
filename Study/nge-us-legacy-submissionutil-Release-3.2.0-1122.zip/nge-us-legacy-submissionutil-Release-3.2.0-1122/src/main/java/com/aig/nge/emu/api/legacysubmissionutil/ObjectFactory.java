
package com.aig.nge.emu.api.legacysubmissionutil;

import javax.xml.bind.annotation.XmlRegistry;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.aig.nge.emu.api.legacysubmissionutil package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {


    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.aig.nge.emu.api.legacysubmissionutil
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link HandleReleaseSubmissionReq }
     * 
     */
    public HandleReleaseSubmissionReq createHandleReleaseSubmissionReq() {
        return new HandleReleaseSubmissionReq();
    }

    /**
     * Create an instance of {@link HandleReleaseSubmissionReqResponse }
     * 
     */
    public HandleReleaseSubmissionReqResponse createHandleReleaseSubmissionReqResponse() {
        return new HandleReleaseSubmissionReqResponse();
    }

    /**
     * Create an instance of {@link HandleReleaseSubmissionResp }
     * 
     */
    public HandleReleaseSubmissionResp createHandleReleaseSubmissionResp() {
        return new HandleReleaseSubmissionResp();
    }

    /**
     * Create an instance of {@link HandleReleaseSubmissionRespResponse }
     * 
     */
    public HandleReleaseSubmissionRespResponse createHandleReleaseSubmissionRespResponse() {
        return new HandleReleaseSubmissionRespResponse();
    }

    /**
     * Create an instance of {@link HandleReleaseSubmissionError }
     * 
     */
    public HandleReleaseSubmissionError createHandleReleaseSubmissionError() {
        return new HandleReleaseSubmissionError();
    }

    /**
     * Create an instance of {@link HandleReleaseSubmissionErrorResponse }
     * 
     */
    public HandleReleaseSubmissionErrorResponse createHandleReleaseSubmissionErrorResponse() {
        return new HandleReleaseSubmissionErrorResponse();
    }

    /**
     * Create an instance of {@link HandleReleaseSubmissionFault }
     * 
     */
    public HandleReleaseSubmissionFault createHandleReleaseSubmissionFault() {
        return new HandleReleaseSubmissionFault();
    }

    /**
     * Create an instance of {@link HandleReleaseSubmissionFaultResponse }
     * 
     */
    public HandleReleaseSubmissionFaultResponse createHandleReleaseSubmissionFaultResponse() {
        return new HandleReleaseSubmissionFaultResponse();
    }

    /**
     * Create an instance of {@link HandleReleaseAlertBlockError }
     * 
     */
    public HandleReleaseAlertBlockError createHandleReleaseAlertBlockError() {
        return new HandleReleaseAlertBlockError();
    }

    /**
     * Create an instance of {@link HandleReleaseAlertBlockErrorResponse }
     * 
     */
    public HandleReleaseAlertBlockErrorResponse createHandleReleaseAlertBlockErrorResponse() {
        return new HandleReleaseAlertBlockErrorResponse();
    }

    /**
     * Create an instance of {@link HandleReleaseAlertBlockFault }
     * 
     */
    public HandleReleaseAlertBlockFault createHandleReleaseAlertBlockFault() {
        return new HandleReleaseAlertBlockFault();
    }

    /**
     * Create an instance of {@link HandleReleaseAlertBlockFaultResponse }
     * 
     */
    public HandleReleaseAlertBlockFaultResponse createHandleReleaseAlertBlockFaultResponse() {
        return new HandleReleaseAlertBlockFaultResponse();
    }

    /**
     * Create an instance of {@link HandleReleaseAlertBlockResp }
     * 
     */
    public HandleReleaseAlertBlockResp createHandleReleaseAlertBlockResp() {
        return new HandleReleaseAlertBlockResp();
    }

    /**
     * Create an instance of {@link HandleReleaseAlertBlockRespResponse }
     * 
     */
    public HandleReleaseAlertBlockRespResponse createHandleReleaseAlertBlockRespResponse() {
        return new HandleReleaseAlertBlockRespResponse();
    }

    /**
     * Create an instance of {@link HandleReleaseAlertBlockReq }
     * 
     */
    public HandleReleaseAlertBlockReq createHandleReleaseAlertBlockReq() {
        return new HandleReleaseAlertBlockReq();
    }

    /**
     * Create an instance of {@link HandleReleaseAlertBlockReqResponse }
     * 
     */
    public HandleReleaseAlertBlockReqResponse createHandleReleaseAlertBlockReqResponse() {
        return new HandleReleaseAlertBlockReqResponse();
    }

    /**
     * Create an instance of {@link HandleUpdateStatusToWorkingError }
     * 
     */
    public HandleUpdateStatusToWorkingError createHandleUpdateStatusToWorkingError() {
        return new HandleUpdateStatusToWorkingError();
    }

    /**
     * Create an instance of {@link HandleUpdateStatusToWorkingErrorResponse }
     * 
     */
    public HandleUpdateStatusToWorkingErrorResponse createHandleUpdateStatusToWorkingErrorResponse() {
        return new HandleUpdateStatusToWorkingErrorResponse();
    }

    /**
     * Create an instance of {@link HandleUpdateStatusToWorkingFault }
     * 
     */
    public HandleUpdateStatusToWorkingFault createHandleUpdateStatusToWorkingFault() {
        return new HandleUpdateStatusToWorkingFault();
    }

    /**
     * Create an instance of {@link HandleUpdateStatusToWorkingFaultResponse }
     * 
     */
    public HandleUpdateStatusToWorkingFaultResponse createHandleUpdateStatusToWorkingFaultResponse() {
        return new HandleUpdateStatusToWorkingFaultResponse();
    }

    /**
     * Create an instance of {@link HandleUpdateStatusWorkingResp }
     * 
     */
    public HandleUpdateStatusWorkingResp createHandleUpdateStatusWorkingResp() {
        return new HandleUpdateStatusWorkingResp();
    }

    /**
     * Create an instance of {@link HandleUpdateStatusWorkingRespResponse }
     * 
     */
    public HandleUpdateStatusWorkingRespResponse createHandleUpdateStatusWorkingRespResponse() {
        return new HandleUpdateStatusWorkingRespResponse();
    }

    /**
     * Create an instance of {@link HandleUpdateStatusToWorkingReq }
     * 
     */
    public HandleUpdateStatusToWorkingReq createHandleUpdateStatusToWorkingReq() {
        return new HandleUpdateStatusToWorkingReq();
    }

    /**
     * Create an instance of {@link HandleUpdateStatusToWorkingReqResponse }
     * 
     */
    public HandleUpdateStatusToWorkingReqResponse createHandleUpdateStatusToWorkingReqResponse() {
        return new HandleUpdateStatusToWorkingReqResponse();
    }

    /**
     * Create an instance of {@link HandleExtensionFault }
     * 
     */
    public HandleExtensionFault createHandleExtensionFault() {
        return new HandleExtensionFault();
    }

    /**
     * Create an instance of {@link HandleExtensionFaultResponse }
     * 
     */
    public HandleExtensionFaultResponse createHandleExtensionFaultResponse() {
        return new HandleExtensionFaultResponse();
    }

    /**
     * Create an instance of {@link HandleExtensionResp }
     * 
     */
    public HandleExtensionResp createHandleExtensionResp() {
        return new HandleExtensionResp();
    }

    /**
     * Create an instance of {@link HandleExtensionRespResponse }
     * 
     */
    public HandleExtensionRespResponse createHandleExtensionRespResponse() {
        return new HandleExtensionRespResponse();
    }

    /**
     * Create an instance of {@link HandleExtensionReq }
     * 
     */
    public HandleExtensionReq createHandleExtensionReq() {
        return new HandleExtensionReq();
    }

    /**
     * Create an instance of {@link HandleExtensionReqResponse }
     * 
     */
    public HandleExtensionReqResponse createHandleExtensionReqResponse() {
        return new HandleExtensionReqResponse();
    }

    /**
     * Create an instance of {@link HandleAddSubmissionFault }
     * 
     */
    public HandleAddSubmissionFault createHandleAddSubmissionFault() {
        return new HandleAddSubmissionFault();
    }

    /**
     * Create an instance of {@link HandleAddSubmissionFaultResponse }
     * 
     */
    public HandleAddSubmissionFaultResponse createHandleAddSubmissionFaultResponse() {
        return new HandleAddSubmissionFaultResponse();
    }

    /**
     * Create an instance of {@link HandleAddSubmissionResp }
     * 
     */
    public HandleAddSubmissionResp createHandleAddSubmissionResp() {
        return new HandleAddSubmissionResp();
    }

    /**
     * Create an instance of {@link HandleAddSubmissionRespResponse }
     * 
     */
    public HandleAddSubmissionRespResponse createHandleAddSubmissionRespResponse() {
        return new HandleAddSubmissionRespResponse();
    }

    /**
     * Create an instance of {@link HandleAddSubmissionReq }
     * 
     */
    public HandleAddSubmissionReq createHandleAddSubmissionReq() {
        return new HandleAddSubmissionReq();
    }

    /**
     * Create an instance of {@link HandleAddSubmissionReqResponse }
     * 
     */
    public HandleAddSubmissionReqResponse createHandleAddSubmissionReqResponse() {
        return new HandleAddSubmissionReqResponse();
    }

    /**
     * Create an instance of {@link HandleUpdateSubmissionDetailsFault }
     * 
     */
    public HandleUpdateSubmissionDetailsFault createHandleUpdateSubmissionDetailsFault() {
        return new HandleUpdateSubmissionDetailsFault();
    }

    /**
     * Create an instance of {@link HandleUpdateSubmissionDetailsFaultResponse }
     * 
     */
    public HandleUpdateSubmissionDetailsFaultResponse createHandleUpdateSubmissionDetailsFaultResponse() {
        return new HandleUpdateSubmissionDetailsFaultResponse();
    }

    /**
     * Create an instance of {@link HandleUpdateSubmissionDetailsResp }
     * 
     */
    public HandleUpdateSubmissionDetailsResp createHandleUpdateSubmissionDetailsResp() {
        return new HandleUpdateSubmissionDetailsResp();
    }

    /**
     * Create an instance of {@link HandleUpdateSubmissionDetailsRespResponse }
     * 
     */
    public HandleUpdateSubmissionDetailsRespResponse createHandleUpdateSubmissionDetailsRespResponse() {
        return new HandleUpdateSubmissionDetailsRespResponse();
    }

    /**
     * Create an instance of {@link HandleUpdateSubmissionDetailsReq }
     * 
     */
    public HandleUpdateSubmissionDetailsReq createHandleUpdateSubmissionDetailsReq() {
        return new HandleUpdateSubmissionDetailsReq();
    }

    /**
     * Create an instance of {@link HandleUpdateSubmissionDetailsReqResponse }
     * 
     */
    public HandleUpdateSubmissionDetailsReqResponse createHandleUpdateSubmissionDetailsReqResponse() {
        return new HandleUpdateSubmissionDetailsReqResponse();
    }

    /**
     * Create an instance of {@link HandleTransferProductReq }
     * 
     */
    public HandleTransferProductReq createHandleTransferProductReq() {
        return new HandleTransferProductReq();
    }

    /**
     * Create an instance of {@link HandleTransferProductReqResponse }
     * 
     */
    public HandleTransferProductReqResponse createHandleTransferProductReqResponse() {
        return new HandleTransferProductReqResponse();
    }

    /**
     * Create an instance of {@link HandleTransferProductResp }
     * 
     */
    public HandleTransferProductResp createHandleTransferProductResp() {
        return new HandleTransferProductResp();
    }

    /**
     * Create an instance of {@link HandleTransferProductRespResponse }
     * 
     */
    public HandleTransferProductRespResponse createHandleTransferProductRespResponse() {
        return new HandleTransferProductRespResponse();
    }

    /**
     * Create an instance of {@link HandleTransferProductError }
     * 
     */
    public HandleTransferProductError createHandleTransferProductError() {
        return new HandleTransferProductError();
    }

    /**
     * Create an instance of {@link HandleTransferProductErrorResponse }
     * 
     */
    public HandleTransferProductErrorResponse createHandleTransferProductErrorResponse() {
        return new HandleTransferProductErrorResponse();
    }

    /**
     * Create an instance of {@link HandleTransferProductFault }
     * 
     */
    public HandleTransferProductFault createHandleTransferProductFault() {
        return new HandleTransferProductFault();
    }

    /**
     * Create an instance of {@link HandleTransferProductFaultResponse }
     * 
     */
    public HandleTransferProductFaultResponse createHandleTransferProductFaultResponse() {
        return new HandleTransferProductFaultResponse();
    }

}
