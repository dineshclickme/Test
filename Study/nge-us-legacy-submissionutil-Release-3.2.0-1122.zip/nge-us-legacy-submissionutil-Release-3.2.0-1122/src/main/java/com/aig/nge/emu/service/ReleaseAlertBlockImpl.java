package com.aig.nge.emu.service;

import com.aig.logging.NGELogger;
import com.aig.nge.emu.api.legacysubmissionutil.HandleReleaseAlertBlockError;
import com.aig.nge.emu.api.legacysubmissionutil.HandleReleaseAlertBlockErrorResponse;
import com.aig.nge.emu.api.legacysubmissionutil.HandleReleaseAlertBlockFault;
import com.aig.nge.emu.api.legacysubmissionutil.HandleReleaseAlertBlockFaultResponse;
import com.aig.nge.emu.api.legacysubmissionutil.HandleReleaseAlertBlockReq;
import com.aig.nge.emu.api.legacysubmissionutil.HandleReleaseAlertBlockReqResponse;
import com.aig.nge.emu.api.legacysubmissionutil.HandleReleaseAlertBlockResp;
import com.aig.nge.emu.api.legacysubmissionutil.HandleReleaseAlertBlockRespResponse;
import com.aig.nge.emu.constants.LegacyConstants;
import com.aig.nge.emu.constants.NGEConstants;
import com.aig.nge.emu.helper.CommonHelper;
import com.aig.nge.emu.logic.java.ReleaseAlertBlockJava;
import com.aig.nge.emu.util.common.NGEException;
import com.aig.nge.emu.util.common.ServiceException;
import com.aig.nge.emu.util.common.SubmissionException;
import com.aig.nge.emu.xsd.service.internal.esb.ReleaseAlertBlockRequest;
import com.aig.nge.emu.xsd.service.internal.esb.ReleaseAlertBlockResponse;
import com.aig.nge.emu.xsd.service.legacy.submissionService.ReleaseAlertBlock;
import com.aig.nge.emu.xsd.service.legacy.submissionService.Response;
import com.aig.nge.emu.xsd.service.legacy.submissionService.SubmissionServiceXML;

public class ReleaseAlertBlockImpl extends AbstractCommand {
	private ReleaseAlertBlockJava releaseAlertBlockJava;
	private NGEException ngeException;

	public ReleaseAlertBlockImpl() {
		releaseAlertBlockJava = new ReleaseAlertBlockJava();
		ngeException = new NGEException();
	}

	com.aig.nge.emu.api.legacysubmissionutil.ObjectFactory of = new com.aig.nge.emu.api.legacysubmissionutil.ObjectFactory();
	com.aig.nge.emu.xsd.service.legacy.submissionService.ObjectFactory of2 = new com.aig.nge.emu.xsd.service.legacy.submissionService.ObjectFactory();

	public HandleReleaseAlertBlockReqResponse processRequest(HandleReleaseAlertBlockReq handleReleaseAlertBlockReq)
			throws SubmissionException {
		Response result = null;
		ReleaseAlertBlock releaseAlertBlockLegacy = null;
		HandleReleaseAlertBlockReqResponse handleReleaseAlertBlockReqResponse = null;
		SubmissionServiceXML submissionServiceXML = handleReleaseAlertBlockReq.getSubmissionServiceXML();
		ReleaseAlertBlockRequest releasealertblockrequest = new ReleaseAlertBlockRequest();
		try {
			/*
			 * DataObject legacyRequestObj =
			 * handleReleaseAlertBlockReq.getDataObject(XpathConstants.
			 * LEGACY_REQUEST_ROOT_RELEASE_ALERT_BLOCK); DataObject
			 * ngeRequestObj =
			 * handleReleaseAlertBlockReq.getDataObject(XpathConstants.
			 * NGE_RELEASE_ALERT_BLOCK_REQUEST_ROOT);
			 */

			/*
			 * if(null == legacyRequestObj ) throw new ServiceException(
			 * "Legacy request mapping not found in DataObject");
			 * 
			 * //Converting legacy request Data Object to XML String
			 * legacyRequestXML=XMLBOConversion.parseBOtoXML(legacyRequestObj);
			 * //Converting Legacy requestXML to POJO
			 * submissionServiceXML=(SubmissionServiceXML)
			 * NGEUnmarshaller.unMarshaller(legacyRequestXML,
			 * SubmissionServiceXML.class);
			 */

			/*
			 * if(null != ngeRequestObj) { //Converting NGE request Data Object
			 * to XML String
			 * ngeRequestXML=XMLBOConversion.parseBOtoXMLNGE(ngeRequestObj);
			 * releasealertblockrequest=(ReleaseAlertBlockRequest)
			 * NGEUnmarshaller.unMarshaller(ngeRequestXML,
			 * ReleaseAlertBlockRequest.class); }
			 * 
			 * else { releasealertblockrequest=new ReleaseAlertBlockRequest(); }
			 */

			handleReleaseAlertBlockReqResponse = of.createHandleReleaseAlertBlockReqResponse();
			releaseAlertBlockLegacy = of2.createReleaseAlertBlock();
			if (null == submissionServiceXML.getRequest().getArguments().getReleaseAlertBlock()) {
				throw new ServiceException("Request missing releaseAlertBlock  details");
			}

			releaseAlertBlockLegacy = submissionServiceXML.getRequest().getArguments().getReleaseAlertBlock();
			result = releaseAlertBlockJava.requestValidation(releaseAlertBlockLegacy, releasealertblockrequest);

			if (result == null) {
				// Converting NGE requestXML to POJO
				/*
				 * String alertACD=
				 * NGEMarshaller.marshaller(releasealertblockrequest,
				 * ReleaseAlertBlockRequest.class); DataObject
				 * releaseAlertBlock=XMLBOConversion.parseXMLtoBONGE(alertACD);
				 * 
				 * handleReleaseAlertBlockReq.setDataObject(XpathConstants.
				 * NGE_RELEASE_ALERT_BLOCK_REQUEST_ROOT,releaseAlertBlock);
				 */
				handleReleaseAlertBlockReqResponse.setSubmissionServiceXML(submissionServiceXML);
				handleReleaseAlertBlockReqResponse.setReleaseAlertBlockRequest(releasealertblockrequest);
			} else {
				submissionServiceXML.setResponse(result);
				/*
				 * String submission=
				 * NGEMarshaller.marshaller(submissionServiceXML,
				 * SubmissionServiceXML.class);
				 * 
				 * DataObject
				 * submissionData=XMLBOConversion.parseXMLtoBOSubmissionService(
				 * submission);
				 */
				// handleReleaseAlertBlockReq.setDataObject(XpathConstants.LEGACY_REQUEST_ROOT_RELEASE_ALERT_BLOCK,submissionData);

			}
		} catch (SubmissionException ex) {
			NGELogger.methodDebugLog("SubmissionException ", ex.getMessage());
			if (ex.getErrNumber().equalsIgnoreCase(NGEConstants.STALE)) {
				throw ex;
			}
			result = ngeException.getErrorResponse(LegacyConstants.SERVICE_ERROR, ex.getMessage(),
					LegacyConstants.MessageType.SYSTEM);
		} catch (Exception exception) {
			result = ngeException.getErrorResponse(LegacyConstants.SERVICE_ERROR, exception.getMessage(),
					LegacyConstants.MessageType.SYSTEM);
		}

		handleReleaseAlertBlockReqResponse.setSubmissionServiceXML(submissionServiceXML);
		return handleReleaseAlertBlockReqResponse;
	}

	public HandleReleaseAlertBlockRespResponse processSuccessResponse(
			HandleReleaseAlertBlockResp handleReleaseAlertBlockResp) throws SubmissionException {
		Response response = null;
		SubmissionServiceXML submissionServiceXML = handleReleaseAlertBlockResp.getSubmissionServiceXML();
		ReleaseAlertBlockResponse releasealertblockresponse = null;
		HandleReleaseAlertBlockRespResponse handleReleaseAlertBlockRespResponse = null;
		try {

			/*
			 * DataObject legacyResponseObj =
			 * releaseAlertBlockResponse.getDataObject(XpathConstants.
			 * LEGACY_RESPONSE_ROOT_RELEASE_ALERT_BLOCK); DataObject
			 * ngeResponseObj =
			 * releaseAlertBlockResponse.getDataObject(XpathConstants.
			 * NGE_RELEASE_ALERT_BLOCK_RESPONSE_ROOT);
			 * 
			 * if(null == ngeResponseObj ) throw new ServiceException(
			 * "nge response mapping not found in DataObject");
			 * 
			 * //Converting legacy request Data Object to XML String
			 * legacyResponseXML=XMLBOConversion.parseBOtoXML(legacyResponseObj)
			 * ;
			 */
			// Converting Legacy requestXML to POJO
			/*
			 * submissionServiceXML=(SubmissionServiceXML)
			 * NGEUnmarshaller.unMarshaller(legacyResponseXML,
			 * SubmissionServiceXML.class);
			 * 
			 * //Converting NGE request Data Object to XML String
			 * ngeResponsetXML=XMLBOConversion.parseBOtoXMLNGE(ngeResponseObj);
			 * 
			 * //Converting NGE requestXML to POJO
			 * releasealertblockresponse=(ReleaseAlertBlockResponse)
			 * NGEUnmarshaller.unMarshaller(ngeResponsetXML,
			 * ReleaseAlertBlockResponse.class);
			 */
			handleReleaseAlertBlockRespResponse = of.createHandleReleaseAlertBlockRespResponse();
			if (null == submissionServiceXML) {
				throw new ServiceException("Response missing submission details");
			}
			response = CommonHelper.getSuccessResponse(LegacyConstants.RELEASE_ALERT_BLOCK_SUCCESS_NO,
					LegacyConstants.RELEASE_ALERT_BLOCK_SUCCESS_MESSAGE, LegacyConstants.MessageType.INFO, null);

			submissionServiceXML.setResponse(response);

			/*
			 * String submission= NGEMarshaller.marshaller(submissionServiceXML,
			 * SubmissionServiceXML.class);
			 * 
			 * DataObject
			 * submissionData=XMLBOConversion.parseXMLtoBOSubmissionService(
			 * submission);
			 * 
			 * releaseAlertBlockResponse.setDataObject(XpathConstants.
			 * LEGACY_RESPONSE_ROOT_RELEASE_ALERT_BLOCK,submissionData);
			 */
			handleReleaseAlertBlockRespResponse.setSubmissionServiceXML(submissionServiceXML);

		}
		/*
		 * catch(SubmissionException ex){ NGELogger.methodDebugLog(
		 * "SubmissionException ", ex.getMessage());
		 * if(ex.getErrNumber().equalsIgnoreCase(NGEConstants.STALE)) { throw
		 * ex; } }
		 */
		catch (Exception exception) {
			NGEException.ngePrintStackTrace(exception);
		}
		return handleReleaseAlertBlockRespResponse;
	}

	public HandleReleaseAlertBlockFaultResponse processCallOutErrorResponse(
			HandleReleaseAlertBlockFault handleReleaseAlertBlockFault) throws SubmissionException {
		Response response = null;
		SubmissionServiceXML submissionServiceXML = handleReleaseAlertBlockFault.getSubmissionServiceXML();
		HandleReleaseAlertBlockFaultResponse handleReleaseAlertBlockFaultResponse = null;
		try {
			handleReleaseAlertBlockFaultResponse = of.createHandleReleaseAlertBlockFaultResponse();
			/*
			 * DataObject legacyResponseObj = obj.getDataObject(XpathConstants.
			 * LEGACY_RESPONSE_ROOT_RELEASE_ALERT_BLOCK);
			 * 
			 * //Converting legacy request Data Object to XML String
			 * legacyResponseXML=XMLBOConversion.parseBOtoXML(legacyResponseObj)
			 * ; //Converting Legacy requestXML to POJO
			 * submissionServiceXML=(SubmissionServiceXML)
			 * NGEUnmarshaller.unMarshaller(legacyResponseXML,
			 * SubmissionServiceXML.class);
			 */

			if (null == submissionServiceXML) {
				throw new ServiceException("Response missing Submission details");
			}
			response = ngeException.getErrorResponse(LegacyConstants.NO_ALERT_NO, LegacyConstants.NO_ALERT_MSG,
					LegacyConstants.MessageType.LOGICAL);

			submissionServiceXML.setResponse(response);

			// Converting NGE requestXML to POJO
			/*
			 * String submission= NGEMarshaller.marshaller(submissionServiceXML,
			 * SubmissionServiceXML.class);
			 * 
			 * DataObject
			 * submissionData=XMLBOConversion.parseXMLtoBOSubmissionService(
			 * submission);
			 * 
			 * obj.setDataObject(XpathConstants.
			 * LEGACY_RESPONSE_ROOT_RELEASE_ALERT_BLOCK,submissionData);
			 */
			handleReleaseAlertBlockFaultResponse.setSubmissionServiceXML(submissionServiceXML);

		} catch (Exception exception) {
			NGEException.ngePrintStackTrace(exception);
		}
		return handleReleaseAlertBlockFaultResponse;
	}

	public HandleReleaseAlertBlockErrorResponse processSysErrorResponse(
			HandleReleaseAlertBlockError handleReleaseAlertBlockError) throws SubmissionException {
		Response response = null;
		SubmissionServiceXML submissionServiceXML = handleReleaseAlertBlockError.getSubmissionServiceXML();
		HandleReleaseAlertBlockErrorResponse handleReleaseAlertBlockErrorResponse = null;
		try {
			handleReleaseAlertBlockErrorResponse = of.createHandleReleaseAlertBlockErrorResponse();
			// DataObject legacyResponseObj =
			// obj.getDataObject(XpathConstants.LEGACY_RESPONSE_ROOT_RELEASE_ALERT_BLOCK);

			// Converting legacy request Data Object to XML
			// String
			// legacyResponseXML=XMLBOConversion.parseBOtoXML(legacyResponseObj);

			// Converting Legacy requestXML to POJO
			/// submissionServiceXML=(SubmissionServiceXML)
			/// NGEUnmarshaller.unMarshaller(legacyResponseXML,
			/// SubmissionServiceXML.class);

			response = ngeException.getErrorResponse(LegacyConstants.SERVICE_ERROR,
					submissionServiceXML.getResponse().getErrors().getCount(), LegacyConstants.MessageType.LOGICAL);

			submissionServiceXML.setResponse(response);

			// Converting NGE requestXML to POJO
			/*
			 * String submission= NGEMarshaller.marshaller(submissionServiceXML,
			 * SubmissionServiceXML.class);
			 * 
			 * DataObject
			 * submissionData=XMLBOConversion.parseXMLtoBOSubmissionService(
			 * submission);
			 * 
			 * obj.setDataObject(XpathConstants.
			 * LEGACY_RESPONSE_ROOT_RELEASE_ALERT_BLOCK,submissionData);
			 */
			handleReleaseAlertBlockErrorResponse.setSubmissionServiceXML(submissionServiceXML);

		} catch (Exception exception) {
			NGEException.ngePrintStackTrace(exception);
		}
		return handleReleaseAlertBlockErrorResponse;
	}

	@Override
	public Object handleRequest(Object obj) throws SubmissionException {
		return processRequest((HandleReleaseAlertBlockReq) obj);

	}

	@Override
	public Object handleResponse(Object obj) throws SubmissionException {
		return processSuccessResponse((HandleReleaseAlertBlockResp) obj);
	}

	@Override
	public Object handleError(Object obj) throws SubmissionException {
		return processSysErrorResponse((HandleReleaseAlertBlockError) obj);
	}

	@Override
	public Object handleFault(Object obj) throws SubmissionException {
		return processCallOutErrorResponse((HandleReleaseAlertBlockFault) obj);

	}
}