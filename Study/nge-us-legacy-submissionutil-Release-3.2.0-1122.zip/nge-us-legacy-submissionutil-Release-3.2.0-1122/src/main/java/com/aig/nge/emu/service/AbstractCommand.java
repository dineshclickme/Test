package com.aig.nge.emu.service;

import com.aig.nge.emu.util.common.SubmissionException;

public abstract class AbstractCommand implements Command {

	public Object execute(Object obj, String token) throws SubmissionException {
		Object result = null;
		if(token.endsWith("Req\"")){
			result = handleRequest(obj);
		} else if(token.endsWith("Resp\"")){
			result = handleResponse(obj);
		} else if(token.endsWith("Error\"")){
			result = handleError(obj);
		} else if(token.endsWith("Fault\"")){
			result = handleFault(obj);
		} else {
			throw new SubmissionException("Unexpected SOAPFault ending. Should end with Req, Resp, Error or Fault. Received SOAP fault : " + token);
		}
		return result;
	}
}
