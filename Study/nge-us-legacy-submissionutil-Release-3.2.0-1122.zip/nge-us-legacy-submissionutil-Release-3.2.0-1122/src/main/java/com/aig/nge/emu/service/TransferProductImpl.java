package com.aig.nge.emu.service;



import java.util.List;

import com.aig.logging.NGELogger;
import com.aig.nge.emu.api.legacysubmissionutil.HandleTransferProductError;
import com.aig.nge.emu.api.legacysubmissionutil.HandleTransferProductErrorResponse;
import com.aig.nge.emu.api.legacysubmissionutil.HandleTransferProductFault;
import com.aig.nge.emu.api.legacysubmissionutil.HandleTransferProductFaultResponse;
import com.aig.nge.emu.api.legacysubmissionutil.HandleTransferProductReq;
import com.aig.nge.emu.api.legacysubmissionutil.HandleTransferProductReqResponse;
import com.aig.nge.emu.api.legacysubmissionutil.HandleTransferProductResp;
import com.aig.nge.emu.api.legacysubmissionutil.HandleTransferProductRespResponse;
import com.aig.nge.emu.constants.LegacyConstants;
import com.aig.nge.emu.constants.NGEConstants;
import com.aig.nge.emu.dao.ProductDAO;
import com.aig.nge.emu.helper.CommonHelper;
import com.aig.nge.emu.helper.SubmissionServiceCommomHelper;
import com.aig.nge.emu.logic.java.TransferProductJava;
import com.aig.nge.emu.model.TlegacyErrorModel;
import com.aig.nge.emu.util.common.NGEException;
import com.aig.nge.emu.util.common.ServiceException;
import com.aig.nge.emu.util.common.SubmissionException;
import com.aig.nge.emu.xsd.service.internal.esb.UpdateComponentProductRes;
import com.aig.nge.emu.xsd.service.internal.esb.UpdateProductRequest;
import com.aig.nge.emu.xsd.service.internal.esb.UpdateProductResponse;
import com.aig.nge.emu.xsd.service.legacy.submissionService.Error;
import com.aig.nge.emu.xsd.service.legacy.submissionService.Response;
import com.aig.nge.emu.xsd.service.legacy.submissionService.SubmissionServiceXML;
import com.aig.nge.emu.xsd.service.legacy.submissionService.TransferProduct;

public class TransferProductImpl extends AbstractCommand{
	
	private TransferProductJava transferProductJava;
	private NGEException ngeException;
	public TransferProductImpl(){
		transferProductJava = new TransferProductJava();
		ngeException=new NGEException();
	}
	com.aig.nge.emu.api.legacysubmissionutil.ObjectFactory of = new com.aig.nge.emu.api.legacysubmissionutil.ObjectFactory();

	public HandleTransferProductReqResponse processRequest(HandleTransferProductReq handleTransferProductReq) throws SubmissionException {
		NGELogger.methodEnteringLog();
		Response result=null;
		TransferProduct transferProduct = null;
		UpdateProductRequest updateProductRequest =null;
		SubmissionServiceXML submissionServiceXML = handleTransferProductReq.getSubmissionServiceXML();
		HandleTransferProductReqResponse handleTransferProductReqResponse = of.createHandleTransferProductReqResponse();

		try{		
			if(null == submissionServiceXML ){
				throw new ServiceException("Legacy request mapping not found in DataObject");
			}
			
			updateProductRequest = new UpdateProductRequest();
			
			if(null == submissionServiceXML.getRequest().getArguments().getTransferProduct())
			{
				throw new ServiceException("Request missing Transfer Product  details");
			}
			
			transferProduct = submissionServiceXML.getRequest().getArguments().getTransferProduct();
			result = transferProductJava.requestValidation(submissionServiceXML,transferProduct,updateProductRequest);
			
			NGELogger.logMessage("TransferProductImpl","Entering processRequest() Method result Object..."+result,LegacyConstants.MessageType.INFO);
			if(result == null ){
				submissionServiceXML.getRequest().getArguments().setTransferProduct(transferProduct);
				handleTransferProductReqResponse.setUpdateProductRequest(updateProductRequest);				
			}else{
				submissionServiceXML.setResponse(result);				
			}
			handleTransferProductReqResponse.setSubmissionServiceXML(submissionServiceXML);			
		}catch(SubmissionException ex){				
			NGELogger.methodDebugLog("SubmissionException ", ex.getMessage());
			if(ex.getErrNumber().equalsIgnoreCase(NGEConstants.STALE))
				{
					//throw ex;
				}
		}catch(Exception exp){
			NGEException.ngePrintStackTrace(exp);

			result=ngeException.getErrorResponse(LegacyConstants.SERVICE_ERROR,exp.getMessage(),LegacyConstants.MessageType.SYSTEM);
		}
		
		NGELogger.methodExitingLog();
		return handleTransferProductReqResponse;
	}

	
	public HandleTransferProductRespResponse processRes(HandleTransferProductResp handleTransferProductResp) throws SubmissionException {		
		NGELogger.methodEnteringLog();
		Response response = new Response();
		SubmissionServiceXML submissionServiceXML = handleTransferProductResp.getSubmissionServiceXML();
		HandleTransferProductRespResponse handleTransferProductRespResponse = of.createHandleTransferProductRespResponse();

		try
		{			
			if(null == submissionServiceXML){
				throw new ServiceException("Response missing submission details");
			}
			
			String successMsg = LegacyConstants.TRAN_SUCC_CD_MSG;
			transferProductJava.updatePUCAndSection(submissionServiceXML);
			response = CommonHelper.getTranProSuccessRes(LegacyConstants.TRAN_SUCC_CD,successMsg,LegacyConstants.MessageType.INFO, response);
			submissionServiceXML.setResponse(response);
			handleTransferProductRespResponse.setSubmissionServiceXML(submissionServiceXML);
		}catch(SubmissionException ex){				
			NGELogger.methodDebugLog("SubmissionException ", ex.getMessage());
			if(ex.getErrNumber().equalsIgnoreCase(NGEConstants.STALE))
				{
					throw ex;
				}
		}catch(Exception e){
			NGEException.ngePrintStackTrace(e);
		}
		NGELogger.methodExitingLog();
		return handleTransferProductRespResponse;
	}
	

	public HandleTransferProductErrorResponse processSuccessResponseErr(HandleTransferProductError handleTransferProductError) throws SubmissionException {
		NGELogger.methodEnteringLog();
		Response response = new Response();
		ProductDAO productDAO = new ProductDAO();
		TlegacyErrorModel tlegacyErrorModel = null;
		HandleTransferProductErrorResponse handleTransferProductErrorResponse = of.createHandleTransferProductErrorResponse();
		try
		{
			SubmissionServiceXML submissionServiceXML = handleTransferProductError.getSubmissionServiceXML();
			UpdateProductResponse resHdr = handleTransferProductError.getUpdateProductResponse();
			String systemId = submissionServiceXML.getIdentity().getApplicationId();
			if (resHdr != null) {
				List<UpdateComponentProductRes> componentList = resHdr.getProductsRs().getComponentProduct();
				for (UpdateComponentProductRes component : componentList) {
					String messageType = component.getMessage().getMessageCategory().toString();
					if (messageType.equalsIgnoreCase(LegacyConstants.MessageType.ERROR)
							|| messageType.equalsIgnoreCase(LegacyConstants.MessageType.LOGICAL)) {
						String errorCd = component.getMessage().getMessageCode();
						String errorMsg = component.getMessage().getStatusMessage();
						tlegacyErrorModel = productDAO.getLegacyErrorCdAndMsg(errorCd, systemId, errorMsg);
						if (tlegacyErrorModel != null) {
							response = ngeException.getErrorResponse(tlegacyErrorModel.getLegacyErrorCd().trim(),
									tlegacyErrorModel.getLegacyErrorMesageTx(), LegacyConstants.MessageType.LOGICAL);
							submissionServiceXML.setResponse(response);
						} else {
							response = ngeException.getErrorResponse(component.getMessage().getMessageCode().trim(),
									component.getMessage().getStatusMessage(), LegacyConstants.MessageType.LOGICAL);
							submissionServiceXML.setResponse(response);
						}
						break;
					}
				}
			}			
			handleTransferProductErrorResponse.setSubmissionServiceXML(submissionServiceXML);
		}catch(SubmissionException ex){				
			NGELogger.methodDebugLog("SubmissionException ", ex.getMessage());
			if(ex.getErrNumber().equalsIgnoreCase(NGEConstants.STALE))
				{
					throw ex;
				}
		}catch(Exception e){
			NGEException.ngePrintStackTrace(e);
		}
		NGELogger.methodExitingLog();
		return handleTransferProductErrorResponse;
	}

	public HandleTransferProductFaultResponse processCallOutErrorResponse(HandleTransferProductFault handleTransferProductFault) throws SubmissionException {
		NGELogger.methodEnteringLog();
		SubmissionServiceCommomHelper submissionServiceCommomHelper;
		HandleTransferProductFaultResponse handleTransferProductFaultResponse = of.createHandleTransferProductFaultResponse();

		try{
			SubmissionServiceXML submissionServiceXML = handleTransferProductFault.getSubmissionServiceXML();

			if(null == submissionServiceXML){
				throw new ServiceException("Response missing Submission details");
			}
			
			for(Error error:submissionServiceXML.getResponse().getErrors().getError()){
				submissionServiceCommomHelper=new SubmissionServiceCommomHelper();
				submissionServiceCommomHelper.generateLegacyErrorByNGE(error, submissionServiceXML);
			}

			handleTransferProductFaultResponse.setSubmissionServiceXML(submissionServiceXML);
		}catch(SubmissionException ex){				
			NGELogger.methodDebugLog("SubmissionException ", ex.getMessage());
			if(ex.getErrNumber().equalsIgnoreCase(NGEConstants.STALE))
				{
					throw ex;
				}
		}catch(Exception e){
			NGEException.ngePrintStackTrace(e);
		}
		NGELogger.methodExitingLog();
		return handleTransferProductFaultResponse;
	}

	@Override
	public Object handleRequest(Object obj) throws SubmissionException {
		return processRequest((HandleTransferProductReq)obj);
	}
	
	@Override
	public Object handleResponse(Object obj) throws SubmissionException{
		return processRes((HandleTransferProductResp)obj);
	}

	@Override
	public Object handleError(Object obj) throws SubmissionException{
		return processSuccessResponseErr((HandleTransferProductError)obj);
	}
	
	@Override
	public Object handleFault(Object obj) throws SubmissionException{
		return processCallOutErrorResponse((HandleTransferProductFault)obj);
	}
}
