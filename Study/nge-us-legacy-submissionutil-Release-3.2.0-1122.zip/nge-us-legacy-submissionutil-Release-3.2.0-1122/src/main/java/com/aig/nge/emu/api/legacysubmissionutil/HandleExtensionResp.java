
package com.aig.nge.emu.api.legacysubmissionutil;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import com.aig.nge.emu.xsd.service.internal.esb.ExtendAutoCloseDaysResponse;
import com.aig.nge.emu.xsd.service.legacy.submissionService.SubmissionServiceXML;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element ref="{http://www.aig.com/SubmissionProductManagementServiceV1}ExtendAutoCloseDaysResponse"/&gt;
 *         &lt;element ref="{http://www.aig.com/SubmissionServiceXML}SubmissionServiceXML"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "extendAutoCloseDaysResponse",
    "submissionServiceXML"
})
@XmlRootElement(name = "handleExtensionResp")
public class HandleExtensionResp {

    @XmlElement(name = "ExtendAutoCloseDaysResponse", namespace = "http://www.aig.com/SubmissionProductManagementServiceV1", required = true)
    protected ExtendAutoCloseDaysResponse extendAutoCloseDaysResponse;
    @XmlElement(name = "SubmissionServiceXML", namespace = "http://www.aig.com/SubmissionServiceXML", required = true)
    protected SubmissionServiceXML submissionServiceXML;

    /**
     * Gets the value of the extendAutoCloseDaysResponse property.
     * 
     * @return
     *     possible object is
     *     {@link ExtendAutoCloseDaysResponse }
     *     
     */
    public ExtendAutoCloseDaysResponse getExtendAutoCloseDaysResponse() {
        return extendAutoCloseDaysResponse;
    }

    /**
     * Sets the value of the extendAutoCloseDaysResponse property.
     * 
     * @param value
     *     allowed object is
     *     {@link ExtendAutoCloseDaysResponse }
     *     
     */
    public void setExtendAutoCloseDaysResponse(ExtendAutoCloseDaysResponse value) {
        this.extendAutoCloseDaysResponse = value;
    }

    /**
     * Gets the value of the submissionServiceXML property.
     * 
     * @return
     *     possible object is
     *     {@link SubmissionServiceXML }
     *     
     */
    public SubmissionServiceXML getSubmissionServiceXML() {
        return submissionServiceXML;
    }

    /**
     * Sets the value of the submissionServiceXML property.
     * 
     * @param value
     *     allowed object is
     *     {@link SubmissionServiceXML }
     *     
     */
    public void setSubmissionServiceXML(SubmissionServiceXML value) {
        this.submissionServiceXML = value;
    }

}
