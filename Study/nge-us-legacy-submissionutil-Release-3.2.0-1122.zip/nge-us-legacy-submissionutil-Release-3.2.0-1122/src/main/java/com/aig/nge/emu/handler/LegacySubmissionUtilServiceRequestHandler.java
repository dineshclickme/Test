package com.aig.nge.emu.handler;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import org.apache.logging.log4j.ThreadContext;
import org.mule.api.MuleMessage;

import com.aig.logging.NGELogger;
import com.aig.nge.emu.constants.NGEConstants;
import com.aig.nge.emu.service.AddSubmissionImpl;
import com.aig.nge.emu.service.Command;
import com.aig.nge.emu.service.ExtensionImpl;
import com.aig.nge.emu.service.ReleaseAlertBlockImpl;
import com.aig.nge.emu.service.ReleaseSubmissionImpl;
import com.aig.nge.emu.service.TransferProductImpl;
import com.aig.nge.emu.service.UpdStatusImpl;
import com.aig.nge.emu.service.UpdateSubmissionImpl;
import com.aig.nge.emu.util.common.LoadCache;
import com.aig.nge.emu.util.common.NGEException;
import com.aig.nge.emu.util.common.NGESession;
import com.aig.nge.emu.util.common.SessionModel;
import com.aig.nge.emu.util.common.SubmissionException;

public class LegacySubmissionUtilServiceRequestHandler {

	private static final String KEY_INFO = "keyInfo";
	public static Map<String, Command> commands = setupCommands();
		
	private static HashMap<String, Command> setupCommands(){
		HashMap<String, Command> result = new HashMap<String, Command>();
		
		result.put("\"http://www.aig.com/LegacySubmissionUtil/handleTransferProductReq\"", new TransferProductImpl());
		result.put("\"http://www.aig.com/LegacySubmissionUtil/handleTransferProductResp\"", new TransferProductImpl());
		result.put("\"http://www.aig.com/LegacySubmissionUtil/handleTransferProductError\"", new TransferProductImpl());
		result.put("\"http://www.aig.com/LegacySubmissionUtil/handleTransferProductFault\"", new TransferProductImpl());
		
		result.put("\"http://www.aig.com/LegacySubmissionUtil/handleUpdateSubmissionDetailsReq\"", new UpdateSubmissionImpl());
		result.put("\"http://www.aig.com/LegacySubmissionUtil/handleUpdateSubmissionDetailsResp\"", new UpdateSubmissionImpl());
		result.put("\"http://www.aig.com/LegacySubmissionUtil/handleUpdateSubmissionDetailsFault\"", new UpdateSubmissionImpl());
		
		result.put("\"http://www.aig.com/LegacySubmissionUtil/handleAddSubmissionReq\"", new AddSubmissionImpl());
		result.put("\"http://www.aig.com/LegacySubmissionUtil/handleAddSubmissionResp\"", new AddSubmissionImpl());
		result.put("\"http://www.aig.com/LegacySubmissionUtil/handleAddSubmissionFault\"", new AddSubmissionImpl());
		
		result.put("\"http://www.aig.com/LegacySubmissionUtil/handleExtensionReq\"", new ExtensionImpl());
		result.put("\"http://www.aig.com/LegacySubmissionUtil/handleExtensionResp\"", new ExtensionImpl());
		result.put("\"http://www.aig.com/LegacySubmissionUtil/handleExtensionFault\"", new ExtensionImpl());

		result.put("\"http://www.aig.com/LegacySubmissionStatusUtil/handleReleaseSubmissionReq\"", new ReleaseSubmissionImpl());
		result.put("\"http://www.aig.com/LegacySubmissionStatusUtil/handleReleaseSubmissionResp\"", new ReleaseSubmissionImpl());
		result.put("\"http://www.aig.com/LegacySubmissionStatusUtil/handleReleaseSubmissionError\"", new ReleaseSubmissionImpl());
		result.put("\"http://www.aig.com/LegacySubmissionStatusUtil/handleReleaseSubmissionFault\"", new ReleaseSubmissionImpl());
		
		result.put("\"http://www.aig.com/LegacySubmissionStatusUtil/handleUpdateStatusToWorkingReq\"", new UpdStatusImpl());
		result.put("\"http://www.aig.com/LegacySubmissionStatusUtil/handleUpdateStatusToWorkingResp\"", new UpdStatusImpl());
		result.put("\"http://www.aig.com/LegacySubmissionStatusUtil/handleUpdateStatusToWorkingError\"", new UpdStatusImpl());
		result.put("\"http://www.aig.com/LegacySubmissionStatusUtil/handleUpdateStatusToWorkingFault\"", new UpdStatusImpl());
		
		result.put("\"http://www.aig.com/LegacySubmissionStatusUtil/handleReleaseAlertBlockReq\"", new ReleaseAlertBlockImpl());
		result.put("\"http://www.aig.com/LegacySubmissionStatusUtil/handleReleaseAlertBlockResp\"", new ReleaseAlertBlockImpl());
		result.put("\"http://www.aig.com/LegacySubmissionStatusUtil/handleReleaseAlertBlockError\"", new ReleaseAlertBlockImpl());
		result.put("\"http://www.aig.com/LegacySubmissionStatusUtil/handleReleaseAlertBlockFault\"", new ReleaseAlertBlockImpl());
		
		
		return result;
	}

	public static Object handle(Object xml, String token, String serviceName, LinkedHashMap<String, String> keyInfo, String transactionId) throws SubmissionException {
		Object result = null;
		int MAX_RETRY_COUNT=3;
		boolean conditionalRetry = false;
		int numOfRetries = 0;
		do{
			try{
				populateThreadContextWithKeyInfo(keyInfo, transactionId);
				NGELogger.methodDebugLog("conditionalRetry set to " + conditionalRetry + ", No of retries:", String.valueOf(numOfRetries));
				createSession(serviceName);				
				result = commands.get(token).execute(xml, token);
			} catch(SubmissionException sc){
				NGELogger.methodDebugLog("SubmissionException ErrNumber : ", sc.getErrNumber());
				conditionalRetry = checkStaleCondition(sc);
			} finally {
				numOfRetries++;
			}
		}while(conditionalRetry && numOfRetries<MAX_RETRY_COUNT);
		destroySession();
		if (numOfRetries == MAX_RETRY_COUNT){
			NGEException ngee = new NGEException();
			ngee.throwSubmissionException("Reached maximum retry counts upon STALE connection error.", NGEConstants.SERVICE_ERROR_NO, NGEConstants.MessageType.SYSTEM);
		}
		return result;
	}

	private static void populateThreadContextWithKeyInfo(LinkedHashMap<String, String> keyInfo, String transactionId) {
		ThreadContext.putAll(keyInfo);
		ThreadContext.put("transactionId", transactionId);
		ThreadContext.put("application", "nge-us-legacy-submissionutil");
	}
		
	private static void destroySession() {
		ThreadContext.clearMap();
		NGESession.unSetSessionData();
	}

	private static boolean checkStaleCondition(SubmissionException sc) {
		boolean conditionalRetry = false;
		if(sc.getErrNumber().equalsIgnoreCase(NGEConstants.STALE)) {
			conditionalRetry = true;
		}
		return conditionalRetry;
	}

	public static void createSession(String serviceName) throws SubmissionException
	{	
		SessionModel sessionModel = new SessionModel();
		sessionModel.setServiceName(serviceName);
		NGESession.setSessionData(sessionModel);
		loadCache();
	}
	
	private static void loadCache() throws SubmissionException{
		LoadCache ld = new LoadCache();
		try {
			ld.cache();
		} catch (SubmissionException e) {
			if(e.getErrNumber().equalsIgnoreCase(NGEConstants.STALE))
			{
				throw e;
			}
			NGEException.ngePrintStackTrace(e);
		}
	}
}
