package com.aig.nge.emu.service;

import java.util.List;

import com.aig.logging.NGELogger;
import com.aig.nge.emu.api.legacysubmissionutil.HandleUpdateStatusToWorkingError;
import com.aig.nge.emu.api.legacysubmissionutil.HandleUpdateStatusToWorkingErrorResponse;
import com.aig.nge.emu.api.legacysubmissionutil.HandleUpdateStatusToWorkingFault;
import com.aig.nge.emu.api.legacysubmissionutil.HandleUpdateStatusToWorkingFaultResponse;
import com.aig.nge.emu.api.legacysubmissionutil.HandleUpdateStatusToWorkingReq;
import com.aig.nge.emu.api.legacysubmissionutil.HandleUpdateStatusToWorkingReqResponse;
import com.aig.nge.emu.api.legacysubmissionutil.HandleUpdateStatusWorkingResp;
import com.aig.nge.emu.api.legacysubmissionutil.HandleUpdateStatusWorkingRespResponse;
import com.aig.nge.emu.constants.LegacyConstants;
import com.aig.nge.emu.constants.NGEConstants;
import com.aig.nge.emu.dao.ProductDAO;
import com.aig.nge.emu.helper.CommonHelper;
import com.aig.nge.emu.helper.SubmissionServiceCommomHelper;
import com.aig.nge.emu.logic.java.UpdStatusJava;
import com.aig.nge.emu.model.TlegacyErrorModel;
import com.aig.nge.emu.util.common.NGEException;
import com.aig.nge.emu.util.common.ServiceException;
import com.aig.nge.emu.util.common.SubmissionException;
import com.aig.nge.emu.xsd.service.internal.esb.ReopenProductsRequest;
import com.aig.nge.emu.xsd.service.internal.esb.ReopenProductsResponse;
import com.aig.nge.emu.xsd.service.internal.esb.ReopenResponse;
import com.aig.nge.emu.xsd.service.legacy.submissionService.Error;
import com.aig.nge.emu.xsd.service.legacy.submissionService.Response;
import com.aig.nge.emu.xsd.service.legacy.submissionService.SubmissionServiceXML;
import com.aig.nge.emu.xsd.service.legacy.submissionService.UpdateStatusToWorking;

public class UpdStatusImpl extends AbstractCommand {

	private UpdStatusJava updStatusJava;
	private NGEException ngeException;
	private CommonHelper commonHelper;

	public UpdStatusImpl() {
		updStatusJava = new UpdStatusJava();
		ngeException = new NGEException();
		commonHelper = new CommonHelper();
	}

	com.aig.nge.emu.api.legacysubmissionutil.ObjectFactory of = new com.aig.nge.emu.api.legacysubmissionutil.ObjectFactory();
	com.aig.nge.emu.xsd.service.internal.esb.ObjectFactory of2 = new com.aig.nge.emu.xsd.service.internal.esb.ObjectFactory();

	public HandleUpdateStatusToWorkingReqResponse processRequest(
			HandleUpdateStatusToWorkingReq handleUpdateStatusToWorkingReq) throws SubmissionException {

		NGELogger.methodEnteringLog();
		Response result = null;
		UpdateStatusToWorking updateStatusToWorking = null;
		HandleUpdateStatusToWorkingReqResponse handleUpdateStatusToWorkingReqResponse = null;
		SubmissionServiceXML submissionServiceXML = null;
		ReopenProductsRequest reopenProductsRequest = null;

		try {

			submissionServiceXML = handleUpdateStatusToWorkingReq.getSubmissionServiceXML();
			handleUpdateStatusToWorkingReqResponse = of.createHandleUpdateStatusToWorkingReqResponse();
			reopenProductsRequest = of2.createReopenProductsRequest();
			/*
			 * DataObject legacyRequestObj =
			 * handleUpdateStatusToWorkingReq.getDataObject(XpathConstants.
			 * LEGACY_REQUEST_ROOT); DataObject ngeRequestObj =
			 * handleUpdateStatusToWorkingReq.getDataObject(XpathConstants.
			 * NGE_UPDATE_STATUS_TO_WORKING_REQUEST_ROOT);
			 * 
			 * 
			 * 
			 * if(null == legacyRequestObj ){
			 * 
			 * throw new ServiceException(
			 * "Legacy request mapping not found in DataObject");
			 * 
			 * }
			 * 
			 * String
			 * legacyRequestXML=XMLBOConversion.parseBOtoXML(legacyRequestObj);
			 * 
			 * 
			 * submissionServiceXML=(SubmissionServiceXML)
			 * NGEUnmarshaller.unMarshaller(legacyRequestXML,
			 * SubmissionServiceXML.class);
			 * 
			 * if(null != ngeRequestObj){
			 * 
			 * String
			 * ngeRequestXML=XMLBOConversion.parseBOtoXMLNGE(ngeRequestObj);
			 * 
			 * 
			 * 
			 * 
			 * reopenProductsRequest = (ReopenProductsRequest)
			 * NGEUnmarshaller.unMarshaller(ngeRequestXML,
			 * ReopenProductsRequest.class);
			 * 
			 * 
			 * }
			 * 
			 * else{
			 * 
			 * reopenProductsRequest = new ReopenProductsRequest(); }
			 */

			if (null == submissionServiceXML) {
				throw new ServiceException("Legacy request mapping not found in DataObject");
			}

			if (null == submissionServiceXML.getRequest().getArguments().getUpdateStatusToWorking()) {
				throw new ServiceException("Request missing updateStatusToWorking details");
			}

			updateStatusToWorking = submissionServiceXML.getRequest().getArguments().getUpdateStatusToWorking();
			result = updStatusJava.requestValidation(submissionServiceXML, reopenProductsRequest);

			if (result == null) {
				submissionServiceXML.getRequest().getArguments().setUpdateStatusToWorking(updateStatusToWorking);
				;
				handleUpdateStatusToWorkingReqResponse.setReopenProductsRequest(reopenProductsRequest);
				/*
				 * String reopenACD =
				 * NGEMarshaller.marshaller(reopenProductsRequest,
				 * ReopenProductsRequest.class);
				 * 
				 * DataObject reopenRes =
				 * XMLBOConversion.parseXMLtoBONGE(reopenACD);
				 * 
				 * handleUpdateStatusToWorkingReq.setDataObject(XpathConstants.
				 * NGE_UPDATE_STATUS_TO_WORKING_REQUEST_ROOT, reopenRes);
				 * 
				 * String submission =
				 * NGEMarshaller.marshaller(submissionServiceXML,
				 * SubmissionServiceXML.class);
				 * 
				 * DataObject submissionData =
				 * XMLBOConversion.parseXMLtoBOSubmissionService(submission);
				 * 
				 * handleUpdateStatusToWorkingReq.setDataObject(XpathConstants.
				 * LEGACY_REQUEST_ROOT, submissionData);
				 */
			} else {
				submissionServiceXML.setResponse(result);

				/*
				 * submissionServiceXML.setResponse(result); String submission =
				 * NGEMarshaller.marshaller(submissionServiceXML,
				 * SubmissionServiceXML.class);
				 * 
				 * DataObject submissionData =
				 * XMLBOConversion.parseXMLtoBOSubmissionService(submission);
				 * 
				 * handleUpdateStatusToWorkingReq.setDataObject(XpathConstants.
				 * LEGACY_REQUEST_ROOT, submissionData);
				 */
			}
			handleUpdateStatusToWorkingReqResponse.setSubmissionServiceXML(submissionServiceXML);

		} catch (SubmissionException ex) {
			NGELogger.methodDebugLog("SubmissionException ", ex.getMessage());
			if (ex.getErrNumber().equalsIgnoreCase(NGEConstants.STALE)) {
				throw ex;
			}
		} catch (Exception e) {
			result = ngeException.getErrorResponse(LegacyConstants.SERVICE_ERROR, e.getMessage(),
					LegacyConstants.MessageType.SYSTEM);
		}
		NGELogger.methodExitingLog();
		return handleUpdateStatusToWorkingReqResponse;
	}

	public HandleUpdateStatusWorkingRespResponse processSuccessResponse(
			HandleUpdateStatusWorkingResp handleUpdateStatusWorkingResp) throws SubmissionException {
		NGELogger.methodEnteringLog();
		Response response = new Response();
		SubmissionServiceXML submissionServiceXML = null;
		HandleUpdateStatusWorkingRespResponse handleUpdateStatusWorkingRespResponse = null;

		try {
			submissionServiceXML = handleUpdateStatusWorkingResp.getSubmissionServiceXML();
			handleUpdateStatusWorkingRespResponse = of.createHandleUpdateStatusWorkingRespResponse();
			/*
			 * DataObject legacyResponseObj =
			 * upStatusRes.getDataObject(XpathConstants.
			 * LEGACY_UPDATE_STATUS_RESPONSE_ROOT);
			 * 
			 * String legacyResponseXML =
			 * XMLBOConversion.parseBOtoXML(legacyResponseObj);
			 * 
			 * submissionServiceXML = (SubmissionServiceXML)
			 * NGEUnmarshaller.unMarshaller(legacyResponseXML,
			 * SubmissionServiceXML.class);
			 */

			if (null == submissionServiceXML) {
				throw new ServiceException("Response missing submission details");
			}

			response = commonHelper.getUWSSuccessResponse(response, submissionServiceXML);
			submissionServiceXML.setResponse(response);
			handleUpdateStatusWorkingRespResponse.setSubmissionServiceXML(submissionServiceXML);

			/*
			 * String submission =
			 * NGEMarshaller.marshaller(submissionServiceXML,
			 * SubmissionServiceXML.class);
			 * 
			 * DataObject submissionData =
			 * XMLBOConversion.parseXMLtoBOSubmissionService(submission);
			 * 
			 * upStatusRes.setDataObject(XpathConstants.
			 * LEGACY_UPDATE_STATUS_RESPONSE_ROOT, submissionData);
			 */

		} catch (SubmissionException ex) {
			NGELogger.methodDebugLog("SubmissionException ", ex.getMessage());
			if (ex.getErrNumber().equalsIgnoreCase(NGEConstants.STALE)) {
				throw ex;
			}
		} catch (Exception e) {
			NGEException.ngePrintStackTrace(e);
		}
		NGELogger.methodExitingLog();
		return handleUpdateStatusWorkingRespResponse;
	}

	public HandleUpdateStatusToWorkingErrorResponse processSuccessResponseErr(HandleUpdateStatusToWorkingError handleUpdateStatusToWorkingError) throws SubmissionException {
		NGELogger.methodEnteringLog();
		ProductDAO productDAO = new ProductDAO();
		Response response = new Response();
		TlegacyErrorModel tlegacyErrorModel = null;
		SubmissionServiceXML submissionServiceXML = null;
		ReopenProductsResponse reopenProductsRes = null;
		HandleUpdateStatusToWorkingErrorResponse handleUpdateStatusToWorkingErrorResponse=null;
		try {

			handleUpdateStatusToWorkingErrorResponse=of.createHandleUpdateStatusToWorkingErrorResponse();
			submissionServiceXML=handleUpdateStatusToWorkingError.getSubmissionServiceXML();
/*			DataObject legacyResponseObj = upStatusRes.getDataObject(XpathConstants.LEGACY_UPDATE_STATUS_RESPONSE_ROOT);
			DataObject ngeResponseObj = upStatusRes.getDataObject(XpathConstants.NGE_UPDATE_STATUS_RESPONSE_ROOT);

			if (null == ngeResponseObj)
				throw new ServiceException("nge request mapping not found in DataObject");

			String legacyResponseXML = XMLBOConversion.parseBOtoXML(legacyResponseObj);

			submissionServiceXML = (SubmissionServiceXML) NGEUnmarshaller.unMarshaller(legacyResponseXML,
					SubmissionServiceXML.class);

			String ngeResponsetXML = XMLBOConversion.parseBOtoXMLNGE(ngeResponseObj);

			reopenProductsRes = (ReopenProductsResponse) NGEUnmarshaller.unMarshaller(ngeResponsetXML,
					ReopenProductsResponse.class);*/

			if (null == submissionServiceXML) {
				throw new ServiceException("Response Errmissing submission details");
			}
			reopenProductsRes=handleUpdateStatusToWorkingError.getReopenProductsResponse();
			String systemId = submissionServiceXML.getIdentity().getApplicationId();
			
			if (reopenProductsRes != null) {

				List<ReopenResponse> reopenResponseType = reopenProductsRes.getProducts().getReOpenProduct();

				for (ReopenResponse reopen : reopenResponseType) {

					String messageType = reopen.getMessage().getMessageCategory().toString();

					if ((messageType.equalsIgnoreCase(LegacyConstants.MessageType.ERROR)
							|| messageType.equalsIgnoreCase(LegacyConstants.MessageType.LOGICAL))) {

						String errorCd = reopen.getMessage().getMessageCode();
						String errorMsg = reopen.getMessage().getStatusMessage();
						tlegacyErrorModel = productDAO.getLegacyErrorCdAndMsg(errorCd, systemId, errorMsg);
						if (tlegacyErrorModel != null) {
							response = ngeException.getErrorResponse(tlegacyErrorModel.getLegacyErrorCd().trim(),
									tlegacyErrorModel.getLegacyErrorMesageTx(), LegacyConstants.MessageType.LOGICAL);
							submissionServiceXML.setResponse(response);
						} else {
							response = ngeException.getErrorResponse(reopen.getMessage().getMessageCode().trim(),
									reopen.getMessage().getStatusMessage(), LegacyConstants.MessageType.LOGICAL);
							submissionServiceXML.setResponse(response);

						}
						break;
					}
				}
			}

		/*	String submission = NGEMarshaller.marshaller(submissionServiceXML, SubmissionServiceXML.class);

			DataObject submissionData = XMLBOConversion.parseXMLtoBOSubmissionService(submission);

			upStatusRes.setDataObject(XpathConstants.LEGACY_UPDATE_STATUS_RESPONSE_ROOT, submissionData);*/
			handleUpdateStatusToWorkingErrorResponse.setSubmissionServiceXML(submissionServiceXML);
		} catch (SubmissionException ex) {
			NGELogger.methodDebugLog("SubmissionException ", ex.getMessage());
			if (ex.getErrNumber().equalsIgnoreCase(NGEConstants.STALE)) {
				throw ex;
			}
		} catch (Exception e) {
			NGEException.ngePrintStackTrace(e);
		}
		NGELogger.methodExitingLog();
		return handleUpdateStatusToWorkingErrorResponse;
	}

	public HandleUpdateStatusToWorkingFaultResponse processCallOutErrorResponse(
			HandleUpdateStatusToWorkingFault handleUpdateStatusToWorkingFault) throws SubmissionException {
		NGELogger.methodEnteringLog();
		Response response = null;
		SubmissionServiceXML submissionServiceXML = null;
		HandleUpdateStatusToWorkingFaultResponse handleUpdateStatusToWorkingFaultResponse = null;
		SubmissionServiceCommomHelper submissionServiceCommomHelper;
		try {
			submissionServiceXML=handleUpdateStatusToWorkingFault.getSubmissionServiceXML();
			handleUpdateStatusToWorkingFaultResponse=of.createHandleUpdateStatusToWorkingFaultResponse();
/*			DataObject legacyResponseObj = upStatusRes.getDataObject(XpathConstants.LEGACY_UPDATE_STATUS_RESPONSE_ROOT);

			String legacyResponseXML = XMLBOConversion.parseBOtoXML(legacyResponseObj);

			submissionServiceXML = (SubmissionServiceXML) NGEUnmarshaller.unMarshaller(legacyResponseXML,
					SubmissionServiceXML.class);*/

			if (null == submissionServiceXML) {
				throw new ServiceException("Response missing Submission details");
			}

			for (Error error : submissionServiceXML.getResponse().getErrors().getError()) {
				submissionServiceCommomHelper = new SubmissionServiceCommomHelper();
				submissionServiceCommomHelper.generateLegacyErrorByNGE(error, submissionServiceXML);
			}

			handleUpdateStatusToWorkingFaultResponse.setSubmissionServiceXML(submissionServiceXML);
			
/*			String submission = NGEMarshaller.marshaller(submissionServiceXML, SubmissionServiceXML.class);

			DataObject submissionData = XMLBOConversion.parseXMLtoBOSubmissionService(submission);

			upStatusRes.setDataObject(XpathConstants.LEGACY_UPDATE_STATUS_RESPONSE_ROOT, submissionData);
*/
		} catch (SubmissionException ex) {
			NGELogger.methodDebugLog("SubmissionException ", ex.getMessage());
			if (ex.getErrNumber().equalsIgnoreCase(NGEConstants.STALE)) {
				throw ex;
			}
		} catch (Exception e) {
			NGEException.ngePrintStackTrace(e);
		}
		NGELogger.methodExitingLog();
		return handleUpdateStatusToWorkingFaultResponse;
	}

	@Override
	public Object handleRequest(Object obj) throws SubmissionException {
		return processRequest((HandleUpdateStatusToWorkingReq) obj);
	}

	@Override
	public Object handleResponse(Object obj) throws SubmissionException {
		return processSuccessResponse((HandleUpdateStatusWorkingResp) obj);
	}

	@Override
	public Object handleError(Object obj) throws SubmissionException {
		return processSuccessResponseErr((HandleUpdateStatusToWorkingError)obj);
	}

	@Override
	public Object handleFault(Object obj) throws SubmissionException {
		return processCallOutErrorResponse((HandleUpdateStatusToWorkingFault) obj);
	}

}
