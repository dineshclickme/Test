package com.aig.nge.emu.service;

import com.aig.nge.emu.api.legacysubmissionutil.HandleReleaseSubmissionError;
import com.aig.nge.emu.api.legacysubmissionutil.HandleReleaseSubmissionErrorResponse;
import com.aig.nge.emu.api.legacysubmissionutil.HandleReleaseSubmissionFault;
import com.aig.nge.emu.api.legacysubmissionutil.HandleReleaseSubmissionFaultResponse;
import com.aig.nge.emu.api.legacysubmissionutil.HandleReleaseSubmissionReq;
import com.aig.nge.emu.api.legacysubmissionutil.HandleReleaseSubmissionReqResponse;
import com.aig.nge.emu.api.legacysubmissionutil.HandleReleaseSubmissionResp;
import com.aig.nge.emu.api.legacysubmissionutil.HandleReleaseSubmissionRespResponse;
import com.aig.nge.emu.constants.LegacyConstants;
import com.aig.nge.emu.helper.CommonHelper;
import com.aig.nge.emu.logic.java.ReleaseSubmissionJava;
import com.aig.nge.emu.util.common.NGEException;
import com.aig.nge.emu.util.common.ServiceException;
import com.aig.nge.emu.util.common.SubmissionException;
import com.aig.nge.emu.xsd.service.internal.esb.ReleaseBlockedProductRequest;
import com.aig.nge.emu.xsd.service.legacy.submissionService.ReleaseSubmission;
import com.aig.nge.emu.xsd.service.legacy.submissionService.Response;
import com.aig.nge.emu.xsd.service.legacy.submissionService.SubmissionServiceXML;

public class ReleaseSubmissionImpl extends AbstractCommand {

	private ReleaseSubmissionJava releaseSubmissionJava;
	private NGEException ngeException;

	public ReleaseSubmissionImpl() {
		releaseSubmissionJava = new ReleaseSubmissionJava();
		ngeException = new NGEException();
	}

	com.aig.nge.emu.api.legacysubmissionutil.ObjectFactory of = new com.aig.nge.emu.api.legacysubmissionutil.ObjectFactory();
	com.aig.nge.emu.xsd.service.internal.esb.ObjectFactory of2 = new com.aig.nge.emu.xsd.service.internal.esb.ObjectFactory();

	public HandleReleaseSubmissionReqResponse processRequest(HandleReleaseSubmissionReq handleReleaseSubmissionReq) {
		Response result = null;
		ReleaseSubmission releaseSubmission = null;
		HandleReleaseSubmissionReqResponse handleReleaseSubmissionReqResponse = null;
		ReleaseBlockedProductRequest releaseBlockedProductRequest = null;
		SubmissionServiceXML submissionServiceXML = null;

		try {
			//
			// DataObject legacyRequestObj =
			// releaseSubmissionRequest.getDataObject(XpathConstants.LEGACY_REQUEST_ROOT_RELEASE_SUBMISSION);
			// DataObject ngeRequestObj =
			// releaseSubmissionRequest.getDataObject(XpathConstants.NGE_RELEASE_SUBMISSION_REQUEST_ROOT);
			//
			// SubmissionServiceXML submissionServiceXML=null;
			submissionServiceXML = handleReleaseSubmissionReq.getSubmissionServiceXML();
			handleReleaseSubmissionReqResponse = of.createHandleReleaseSubmissionReqResponse();
			releaseBlockedProductRequest = of2.createReleaseBlockedProductRequest();
			if (null == submissionServiceXML) {
				throw new ServiceException("Legacy request mapping not found in DataObject");
			}

			// Converting legacy request Data Object to XML
			// String
			// legacyRequestXML=XMLBOConversion.parseBOtoXML(legacyRequestObj);
			// Converting Legacy requestXML to POJO
			// submissionServiceXML=(SubmissionServiceXML)
			// NGEUnmarshaller.unMarshaller(legacyRequestXML,
			// SubmissionServiceXML.class);

			/*
			 * if(null != ngeRequestObj) { //Converting NGE request Data Object
			 * to XML String
			 * ngeRequestXML=XMLBOConversion.parseBOtoXMLNGE(ngeRequestObj);
			 * 
			 * //Converting NGE requestXML to POJO
			 * releaseBlockedProductRequest=(ReleaseBlockedProductRequest)
			 * NGEUnmarshaller.unMarshaller(ngeRequestXML,
			 * ReleaseBlockedProductRequest.class); } else {
			 * releaseBlockedProductRequest=new ReleaseBlockedProductRequest();
			 * }
			 */
			if (null == submissionServiceXML.getRequest().getArguments().getReleaseSubmission()) {
				throw new ServiceException("Request missing release submission details");
			}
			releaseSubmission = submissionServiceXML.getRequest().getArguments().getReleaseSubmission();
			result = releaseSubmissionJava.requestValidation(releaseSubmission, releaseBlockedProductRequest);

			if (result == null) {

				submissionServiceXML.getRequest().getArguments().setReleaseSubmission(releaseSubmission);
				handleReleaseSubmissionReqResponse.setReleaseBlockedProductRequest(releaseBlockedProductRequest);

				/*
				 * // Converting NGE requestXML to POJO String releaseACD =
				 * NGEMarshaller.marshaller(releaseBlockedProductRequest,
				 * ReleaseBlockedProductRequest.class);
				 * 
				 * DataObject releasesubmission =
				 * XMLBOConversion.parseXMLtoBONGE(releaseACD);
				 * 
				 * releaseSubmissionRequest.setDataObject(XpathConstants.
				 * NGE_RELEASE_SUBMISSION_REQUEST_ROOT, releasesubmission);
				 */
			} else {
				submissionServiceXML.setResponse(result);
				/*
				 * // Converting NGE requestXML to POJO
				 * submissionServiceXML.setResponse(result); String submission =
				 * NGEMarshaller.marshaller(submissionServiceXML,
				 * SubmissionServiceXML.class);
				 * 
				 * DataObject submissionData =
				 * XMLBOConversion.parseXMLtoBOSubmissionService(submission);
				 * 
				 * releaseSubmissionRequest.setDataObject(XpathConstants.
				 * LEGACY_REQUEST_ROOT_RELEASE_SUBMISSION, submissionData);
				 */
			}
			handleReleaseSubmissionReqResponse.setSubmissionServiceXML(submissionServiceXML);
		} catch (Exception exception) {
			result = ngeException.getErrorResponse(LegacyConstants.SERVICE_ERROR, exception.getMessage(),
					LegacyConstants.MessageType.SYSTEM);
		}
		return handleReleaseSubmissionReqResponse;
	}

	public HandleReleaseSubmissionRespResponse processSuccessResponse(
			HandleReleaseSubmissionResp handleReleaseSubmissionResp) throws SubmissionException {
		Response response = null;
		SubmissionServiceXML submissionServiceXML = null;
		HandleReleaseSubmissionRespResponse handleReleaseSubmissionRespResponse = null;
		try {
			handleReleaseSubmissionRespResponse = of.createHandleReleaseSubmissionRespResponse();
			submissionServiceXML = handleReleaseSubmissionResp.getSubmissionServiceXML();
			/*
			 * DataObject legacyResponseObj = releaseSubmissionResponse
			 * .getDataObject(XpathConstants.
			 * LEGACY_RESPONSE_ROOT_RELEASE_SUBMISSION); DataObject
			 * ngeResponseObj = releaseSubmissionResponse
			 * .getDataObject(XpathConstants.
			 * NGE_RELEASE_SUBMISSION_RESPONSE_ROOT);
			 * 
			 * if (null == ngeResponseObj) throw new ServiceException(
			 * "nge response mapping not found in DataObject");
			 * 
			 * // Converting legacy request Data Object to XML String
			 * legacyResponseXML =
			 * XMLBOConversion.parseBOtoXML(legacyResponseObj); // Converting
			 * Legacy requestXML to POJO submissionServiceXML =
			 * (SubmissionServiceXML)
			 * NGEUnmarshaller.unMarshaller(legacyResponseXML,
			 * SubmissionServiceXML.class);
			 * 
			 * // Converting NGE request Data Object to XML String
			 * ngeResponsetXML =
			 * XMLBOConversion.parseBOtoXMLNGE(ngeResponseObj); //
			 * System.out.println(ngeResponsetXML);
			 * 
			 * // Converting NGE requestXML to POJO
			 * releaseBlockedProductResponse = (ReleaseBlockedProductResponse)
			 * NGEUnmarshaller .unMarshaller(ngeResponsetXML,
			 * ReleaseBlockedProductResponse.class);
			 */
			if (null == submissionServiceXML) {
				throw new ServiceException("Response missing submission details");
			}
			response = CommonHelper.getSuccessResponse(LegacyConstants.RELEASE_SUBMISSION_SUCCESS_NO,
					LegacyConstants.RELEASE_SUBMISSION_SUCCESS_MSG, LegacyConstants.MessageType.INFO, null);
			submissionServiceXML.setResponse(response);
			handleReleaseSubmissionRespResponse.setSubmissionServiceXML(submissionServiceXML);

			/*
			 * // Converting NGE requestXML to POJO String submission =
			 * NGEMarshaller.marshaller(submissionServiceXML,
			 * SubmissionServiceXML.class);
			 * 
			 * DataObject submissionData =
			 * XMLBOConversion.parseXMLtoBOSubmissionService(submission);
			 * 
			 * releaseSubmissionResponse.setDataObject(XpathConstants.
			 * LEGACY_RESPONSE_ROOT_RELEASE_SUBMISSION, submissionData);
			 */

		} catch (Exception exception) {
			NGEException.ngePrintStackTrace(exception);
		}
		return handleReleaseSubmissionRespResponse;
	}

	public HandleReleaseSubmissionFaultResponse processCallOutErrorResponse(
			HandleReleaseSubmissionFault handleReleaseSubmissionFault) throws SubmissionException {
		Response response = null;
		SubmissionServiceXML submissionServiceXML = null;
		HandleReleaseSubmissionFaultResponse handleReleaseSubmissionFaultResponse = null;
		try {
			handleReleaseSubmissionFaultResponse = of.createHandleReleaseSubmissionFaultResponse();
			submissionServiceXML = handleReleaseSubmissionFault.getSubmissionServiceXML();
			/*
			 * DataObject legacyResponseObj = releaseSubmissionResponse
			 * .getDataObject(XpathConstants.
			 * LEGACY_RESPONSE_ROOT_RELEASE_SUBMISSION);
			 * 
			 * // Converting legacy request Data Object to XML String
			 * legacyResponseXML =
			 * XMLBOConversion.parseBOtoXML(legacyResponseObj); // Converting
			 * Legacy requestXML to POJO submissionServiceXML =
			 * (SubmissionServiceXML)
			 * NGEUnmarshaller.unMarshaller(legacyResponseXML,
			 * SubmissionServiceXML.class);
			 */

			if (null == submissionServiceXML) {
				throw new ServiceException("Response missing Submission details");
			}

			response = ngeException.getErrorResponse(LegacyConstants.NO_BLOCKS_NO, LegacyConstants.NO_BLOCK_MSG,
					LegacyConstants.MessageType.LOGICAL);

			submissionServiceXML.setResponse(response);
			handleReleaseSubmissionFaultResponse.setSubmissionServiceXML(submissionServiceXML);

			/*
			 * // Converting NGE requestXML to POJO String submission =
			 * NGEMarshaller.marshaller(submissionServiceXML,
			 * SubmissionServiceXML.class);
			 * 
			 * DataObject submissionData =
			 * XMLBOConversion.parseXMLtoBOSubmissionService(submission);
			 * 
			 * releaseSubmissionResponse.setDataObject(XpathConstants.
			 * LEGACY_RESPONSE_ROOT_RELEASE_SUBMISSION, submissionData);
			 */
		} catch (Exception exception) {
			NGEException.ngePrintStackTrace(exception);
		}
		return handleReleaseSubmissionFaultResponse;
	}

	public HandleReleaseSubmissionErrorResponse processSysErrorResponse(
			HandleReleaseSubmissionError handleReleaseSubmissionError) throws SubmissionException {
		Response response = null;
		SubmissionServiceXML submissionServiceXML = null;
		HandleReleaseSubmissionErrorResponse handleReleaseSubmissionErrorResponse = null;
		try {
			handleReleaseSubmissionErrorResponse = of.createHandleReleaseSubmissionErrorResponse();
			submissionServiceXML = handleReleaseSubmissionError.getSubmissionServiceXML();
			/*
			 * DataObject legacyResponseObj = releaseSubmissionResponse
			 * .getDataObject(XpathConstants.
			 * LEGACY_RESPONSE_ROOT_RELEASE_SUBMISSION);
			 * 
			 * // Converting legacy request Data Object to XML String
			 * legacyResponseXML =
			 * XMLBOConversion.parseBOtoXML(legacyResponseObj); // Converting
			 * Legacy requestXML to POJO submissionServiceXML =
			 * (SubmissionServiceXML)
			 * NGEUnmarshaller.unMarshaller(legacyResponseXML,
			 * SubmissionServiceXML.class);
			 */

			response = ngeException.getErrorResponse(LegacyConstants.SERVICE_ERROR,
					submissionServiceXML.getResponse().getErrors().getCount(), LegacyConstants.MessageType.LOGICAL);

			submissionServiceXML.setResponse(response);
			handleReleaseSubmissionErrorResponse.setSubmissionServiceXML(submissionServiceXML);

			/*
			 * // Converting NGE requestXML to POJO String submission =
			 * NGEMarshaller.marshaller(submissionServiceXML,
			 * SubmissionServiceXML.class);
			 * 
			 * DataObject submissionData =
			 * XMLBOConversion.parseXMLtoBOSubmissionService(submission);
			 * 
			 * releaseSubmissionResponse.setDataObject(XpathConstants.
			 * LEGACY_RESPONSE_ROOT_RELEASE_SUBMISSION, submissionData);
			 */

		} catch (Exception exception) {
			NGEException.ngePrintStackTrace(exception);
		}
		return handleReleaseSubmissionErrorResponse;
	}

	@Override
	public Object handleRequest(Object obj) throws SubmissionException {
		return processRequest((HandleReleaseSubmissionReq) obj);
	}

	@Override
	public Object handleResponse(Object obj) throws SubmissionException {
		return processSuccessResponse((HandleReleaseSubmissionResp) obj);
	}

	@Override
	public Object handleError(Object obj) throws SubmissionException {
		return processSysErrorResponse((HandleReleaseSubmissionError) obj);
	}

	@Override
	public Object handleFault(Object obj) throws SubmissionException {
		return processCallOutErrorResponse((HandleReleaseSubmissionFault) obj);
	}

}
