package com.aig.commercial.hip.util;

import java.util.LinkedHashMap;
import java.util.Set;

import org.mule.api.MuleMessage;
import org.mule.api.transformer.TransformerException;
import org.mule.transformer.AbstractMessageTransformer;

public class KeyInfoTransformer extends AbstractMessageTransformer {

	private static final String KEY_INFO = "keyInfo";

	@Override
	public Object transformMessage(MuleMessage message, String outputEncoding) throws TransformerException {
		message.setInvocationProperty(KEY_INFO, getKeyInfo(message));
		return message;
	}

	private LinkedHashMap<String, String> getKeyInfo(MuleMessage message){
		LinkedHashMap<String, String> keyInfo = new LinkedHashMap<String, String>();
		Set<String> props = message.getInboundPropertyNames();
		for (String prop : props) {
			if(prop.toLowerCase().startsWith(KEY_INFO.toLowerCase())){
				keyInfo.put(prop.substring(KEY_INFO.length()+1), (String)message.getInboundProperty(prop));
			}
		}
		return keyInfo;
	}
}
