package com.aig.nge.emu.service;

import com.aig.logging.NGELogger;
import com.aig.nge.emu.api.legacysubmissionutil.HandleAddSubmissionFault;
import com.aig.nge.emu.api.legacysubmissionutil.HandleAddSubmissionFaultResponse;
import com.aig.nge.emu.api.legacysubmissionutil.HandleAddSubmissionReq;
import com.aig.nge.emu.api.legacysubmissionutil.HandleAddSubmissionReqResponse;
import com.aig.nge.emu.api.legacysubmissionutil.HandleAddSubmissionResp;
import com.aig.nge.emu.api.legacysubmissionutil.HandleAddSubmissionRespResponse;
import com.aig.nge.emu.constants.LegacyConstants;
import com.aig.nge.emu.constants.NGEConstants;
import com.aig.nge.emu.helper.SubmissionServiceCommomHelper;
import com.aig.nge.emu.logic.java.AddSubmissionJava;
import com.aig.nge.emu.logic.mainframe.AddSubmissionMF;
import com.aig.nge.emu.util.common.NGEException;
import com.aig.nge.emu.util.common.PropertiesHandler;
import com.aig.nge.emu.util.common.ServiceException;
import com.aig.nge.emu.util.common.SubmissionException;
import com.aig.nge.emu.xsd.service.internal.esb.ServiceRequestContext;
import com.aig.nge.emu.xsd.service.internal.submissionService.AddSubmissionRequest;
import com.aig.nge.emu.xsd.service.internal.submissionService.AddSubmissionResponse;
import com.aig.nge.emu.xsd.service.legacy.submissionService.Error;
import com.aig.nge.emu.xsd.service.legacy.submissionService.SubmissionServiceXML;

public class AddSubmissionImpl extends AbstractCommand {
	
	private AddSubmissionJava addSubmissionJava;
	
    
	
	private SubmissionServiceCommomHelper submissionServiceCommomHelper;
	
	private AddSubmissionMF addSubmissionMF;
	
	com.aig.nge.emu.api.legacysubmissionutil.ObjectFactory of = new com.aig.nge.emu.api.legacysubmissionutil.ObjectFactory();
	com.aig.nge.emu.xsd.service.internal.submissionService.ObjectFactory of2 = new com.aig.nge.emu.xsd.service.internal.submissionService.ObjectFactory();
	
	
	public AddSubmissionImpl(){
		addSubmissionJava=new AddSubmissionJava();
		addSubmissionMF = new AddSubmissionMF();
		submissionServiceCommomHelper=new SubmissionServiceCommomHelper();
	}
	
	public HandleAddSubmissionReqResponse processRequest(HandleAddSubmissionReq handleAddSubmissionReq) throws SubmissionException {
		NGELogger.methodEnteringLog();
		
		SubmissionServiceXML submissionServiceXML=handleAddSubmissionReq.getSubmissionServiceXML();
		HandleAddSubmissionReqResponse handleAddSubmissionReqResponse = null;
		AddSubmissionRequest addSubmissionRq=null;
		boolean conditionalRetry = false;
		boolean adbCheck=true;
        int numOfRetries = 0;
        String creditedBranchCd = LegacyConstants.EMPTY_STRING;
        String clientId = LegacyConstants.EMPTY_STRING;
        com.aig.nge.emu.xsd.service.internal.esb.RequestHeader  requestHeader = handleAddSubmissionReq.getAddSubmissionRequestHeader();
        ServiceRequestContext serviceRequestContext = handleAddSubmissionReq.getAddSubmissionRequestHeader().getServiceRequestContext();
		
       try{
		/*	DataObject legacyRequestObj = addSubmissionRequest.getDataObject(XpathConstants.LEGACY_REQUEST_ROOT);
			DataObject ngeRequestObj = addSubmissionRequest.getDataObject(XpathConstants.NGE_ADD_SUBMISSION_REQUEST_ROOT);
			
			//Converting legacy request Data Object to XML 
			String legacyRequestXML=XMLBOConversion.parseBOtoXML(legacyRequestObj);
			NGELogger.methodDebugLog("AddSubmission  Legacy request", legacyRequestXML);
			
			//Converting Legacy requestXML to POJO
			submissionServiceXML=(SubmissionServiceXML) NGEUnmarshaller.unMarshallerSS(legacyRequestXML, SubmissionServiceXML.class);*/
			handleAddSubmissionReqResponse = of.createHandleAddSubmissionReqResponse();
			addSubmissionRq= handleAddSubmissionReq.getAddSubmissionRq();
			/*ServiceRequestContext serviceRequestContext = new ServiceRequestContext();*/
			//To check whether property files are exist or not
			PropertiesHandler.checkPropertyFileForSubmissionService(submissionServiceXML);
			
			//Converting NGE request Data Object to XML 
			/*if(null != ngeRequestObj){
				String ngeRequestXML=XMLBOConversion.parseBOtoXMLNGE(ngeRequestObj);
				//Converting NGE requestXML to POJO
				addSubmissionRq=(AddSubmissionRequest) NGEUnmarshaller.unMarshallerSS(ngeRequestXML, AddSubmissionRequest.class);
			}else{
				addSubmissionRq=new AddSubmissionRequest();
			}*/
			
			/* April 2017 Maintenance Release 2.4 - Bypass Alert Block Evaluation for Source 02 Submissions - Starts */
			if(submissionServiceXML.getRequest().getArguments().getAddSubmission().getCreditedBranchCd() != null){
				creditedBranchCd = submissionServiceXML.getRequest().getArguments().getAddSubmission().getCreditedBranchCd();
				clientId = LegacyConstants.CLIENT_ID + "-" + creditedBranchCd;
			}else{
				clientId = LegacyConstants.CLIENT_ID;
			}
			//addSubmissionRequest.setString(XpathConstants.NGE_ADD_SUBMISSION_CLIENT,clientId);
			/* April 2017 Maintenance Release 2.4 - Bypass Alert Block Evaluation for Source 02 Submissions - Ends */
			serviceRequestContext.setClientId(clientId);
			
			
			String securedId=submissionServiceXML.getIdentity().getSecuredId();
			String ngeAgent = submissionServiceXML.getRequest().getArguments().getAddSubmission().getAgentId();
			String sourceCd = submissionServiceXML.getRequest().getArguments().getAddSubmission().getSourceCd();
			submissionServiceCommomHelper=new SubmissionServiceCommomHelper();
			
			String accountNo=submissionServiceXML.getRequest().getArguments().getAddSubmission().getAccountNo();
			submissionServiceXML.getRequest().getArguments().getAddSubmission().setAccountNo(accountNo != null ? accountNo.trim() : null);
			
			
			submissionServiceCommomHelper.formatSystemIdAndUser(submissionServiceXML);
			
			if(sourceCd!=null && sourceCd.length() > 2)
				sourceCd=sourceCd.substring(0,2);
			do{
				try{
			if(null == securedId || 0 == securedId.length() ){
				addSubmissionJava=new AddSubmissionJava();
		        	conditionalRetry = false;
		            NGELogger.methodDebugLog("Procedure attempt " , String.valueOf((numOfRetries+1)));
		            
				addSubmissionJava.requestValidation(submissionServiceXML,adbCheck);
				NGELogger.methodDebugLog("Procedure attempt result Sucess" , String.valueOf((numOfRetries+1)));

				serviceRequestContext.setClientId(clientId);
				
				if(ngeAgent != null && ngeAgent.startsWith("GUI")){
					//addSubmissionRequest.setString(XpathConstants.NGE_ADD_SUBMISSION_AGENT,"GUI");
					serviceRequestContext.setServiceInvocationOriginator("GUI");
				}else{
					if(sourceCd!=null && !sourceCd.equals("01") || (ngeAgent == null || ngeAgent.trim().length() ==0))
						//addSubmissionRequest.setString(XpathConstants.NGE_ADD_SUBMISSION_AGENT,"GUI");
						serviceRequestContext.setServiceInvocationOriginator("GUI");
				}
			}else{
				//addSubmissionRequest.setString(XpathConstants.NGE_ADD_SUBMISSION_AGENT,"GUI");
				serviceRequestContext.setServiceInvocationOriginator("GUI");
			}
			
			if(submissionServiceXML.getResponse() == null || 0 == submissionServiceXML.getResponse().getErrors().getError().size()){
				addSubmissionMF=new AddSubmissionMF();
				addSubmissionMF.requestValidation(submissionServiceXML,addSubmissionRq,adbCheck);
			}
			
				}catch(SubmissionException sc)
				{
					if(sc.getErrNumber().equalsIgnoreCase(NGEConstants.STALE))
					{
						//System.out.println("Throwing SubmissionException after addSubmissionMF");
						throw sc;
					}
					else
					{
						NGEException.ngePrintStackTrace(sc);
						NGELogger.methodErrorLog(sc.getMessage());
					}
				}
				catch(Exception ex){
					NGELogger.methodErrorLog("Checking for retry : ");
					NGEException.ngePrintStackTrace(ex);
					   if (numOfRetries < 5) {
                           conditionalRetry = true;
                           numOfRetries++;
					   } else 
						   conditionalRetry = false;
					NGELogger.methodErrorLog("conditionalRetry : "+conditionalRetry);
				}
			}while(conditionalRetry);
			
			if(submissionServiceXML.getResponse() != null && 0 == submissionServiceXML.getResponse().getErrors().getError().size())
				 submissionServiceXML.getResponse().setErrors(null);
			
			//Converting NGE requestXML to POJO
			//String createSub= NGEMarshaller.marshaller(addSubmissionRq,AddSubmissionRequest.class);
		//	NGELogger.methodDebugLog("AddSubmission NGE request",createSub);
			
				//addSubmissionRequest.getString(XpathConstants.NGE_ADD_SUBMISSION_REQUEST_ROOT);
			/*DataObject createSubmission=XMLBOConversion.parseXMLtoBONGE(createSub);
			addSubmissionRequest.setDataObject(XpathConstants.NGE_ADD_SUBMISSION_REQUEST_ROOT,createSubmission);
			//Converting NGE requestXML to POJO
			String submission= NGEMarshaller.marshaller(submissionServiceXML,SubmissionServiceXML.class);
			DataObject submissionData=XMLBOConversion.parseXMLtoBOSubmissionService(submission);
			addSubmissionRequest.setDataObject(XpathConstants.LEGACY_REQUEST_ROOT,submissionData);*/
			
			//serviceRequestContext.setInteractionProtocol(InteractionProtocolType.SYNCHRONOUS_REQUEST_AND_RESPONSE);
			 requestHeader.setServiceRequestContext(serviceRequestContext);
			 handleAddSubmissionReqResponse.setAddSubmissionRequestHeader(requestHeader);
			 handleAddSubmissionReqResponse.setAddSubmissionRq(addSubmissionRq);
			 handleAddSubmissionReqResponse.setSubmissionServiceXML(submissionServiceXML);
		}
		catch(SubmissionException sc)
		{
			if(sc.getErrNumber().equalsIgnoreCase(NGEConstants.STALE))
			{
				throw sc;
			}
			else
			{
				NGEException.ngePrintStackTrace(sc);
				NGELogger.methodErrorLog(sc.getMessage());
			}
		}
		catch(Exception e){
			NGEException.ngePrintStackTrace(e);
			NGELogger.methodErrorLog(e.getMessage());
		}
		
		NGELogger.methodExitingLog();
		return handleAddSubmissionReqResponse;
	}

	public HandleAddSubmissionRespResponse processSuccessResponse(HandleAddSubmissionResp handleAddSubmissionResp) throws SubmissionException{
		NGELogger.methodEnteringLog();
		
		SubmissionServiceXML submissionServiceRequestXML=null;
		AddSubmissionResponse createSubmission=null;
		AddSubmissionMF addSubmissionMF;
		HandleAddSubmissionRespResponse handleAddSubmissionRespResponse =null;
		
		try{
			handleAddSubmissionRespResponse = of.createHandleAddSubmissionRespResponse();
			createSubmission= handleAddSubmissionResp.getAddSubmissionRs();
			
			
			submissionServiceRequestXML=handleAddSubmissionResp.getSubmissionServiceXML();
			
			if(null == submissionServiceRequestXML){
				throw new ServiceException("Response missing submission response details");
			}
			
			addSubmissionMF=new AddSubmissionMF();
			addSubmissionMF.extensionTableInsertion(submissionServiceRequestXML,createSubmission);
			handleAddSubmissionRespResponse.setSubmissionServiceXML(submissionServiceRequestXML);
			
		}catch(SubmissionException sc)
		{
			if(sc.getErrNumber().equalsIgnoreCase(NGEConstants.STALE))
			{
				throw sc;
			}
			else
			{
				NGEException.ngePrintStackTrace(sc);
				NGELogger.methodErrorLog(sc.getMessage());
			}
		}catch(Exception e){
			NGEException.ngePrintStackTrace(e);
			NGELogger.methodErrorLog(e.getMessage());
		}
		
		NGELogger.methodExitingLog();
		return handleAddSubmissionRespResponse;
	}
	
	public HandleAddSubmissionFaultResponse processFaultLogic(HandleAddSubmissionFault handleAddSubmissionFault)throws SubmissionException {
		NGELogger.methodEnteringLog(); 
		SubmissionServiceCommomHelper submissionServiceCommomHelper;
		SubmissionServiceXML submissionServiceXML=null;
		HandleAddSubmissionFaultResponse handleAddSubmissionFaultResponse = null;
		try{
			handleAddSubmissionFaultResponse = of.createHandleAddSubmissionFaultResponse();
			submissionServiceXML = handleAddSubmissionFault.getSubmissionServiceXML();
			if(null == submissionServiceXML){
				throw new ServiceException("Response missing Submission details");
			}
			
			for(Error error:submissionServiceXML.getResponse().getErrors().getError()){
				submissionServiceCommomHelper=new SubmissionServiceCommomHelper();
				submissionServiceCommomHelper.generateLegacyErrorByNGE(error, submissionServiceXML);
			}
	
		
			handleAddSubmissionFaultResponse.setSubmissionServiceXML(submissionServiceXML);
		}catch(SubmissionException sc)
		{
			if(sc.getErrNumber().equalsIgnoreCase(NGEConstants.STALE))
			{
				throw sc;
			}
			else
			{
				NGEException.ngePrintStackTrace(sc);
				NGELogger.methodErrorLog(sc.getMessage());
			}
		}catch(Exception e){
			NGEException.ngePrintStackTrace(e);
			NGELogger.methodErrorLog(e.getMessage());
		}
		
		NGELogger.methodExitingLog();
		return handleAddSubmissionFaultResponse;
	}	

	@Override
	public Object handleRequest(Object obj) throws SubmissionException {
		return processRequest((HandleAddSubmissionReq)obj);
	}

	@Override
	public Object handleResponse(Object obj) throws SubmissionException {
		 return processSuccessResponse((HandleAddSubmissionResp)obj);
	}

	@Override
	public Object handleError(Object obj) throws SubmissionException {
		throw new SubmissionException("Unsupported operation for AddSubmissionImpl");
	}

	@Override
	public Object handleFault(Object obj) throws SubmissionException {
		return processFaultLogic((HandleAddSubmissionFault)obj);
	}
}
