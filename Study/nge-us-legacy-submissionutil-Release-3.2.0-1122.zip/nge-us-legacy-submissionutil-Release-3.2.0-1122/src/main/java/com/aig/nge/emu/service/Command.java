package com.aig.nge.emu.service;

import com.aig.nge.emu.util.common.SubmissionException;

public interface Command {
	public Object execute(Object obj, String token) throws SubmissionException;
	public Object handleRequest(Object obj) throws SubmissionException;
	public Object handleResponse(Object obj) throws SubmissionException;
	public Object handleError(Object obj) throws SubmissionException;
	public Object handleFault(Object obj) throws SubmissionException;
}
