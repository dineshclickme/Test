package com.aig.nge.emu.handler;

import org.mule.api.context.notification.MuleContextNotificationListener;
import org.mule.context.notification.MuleContextNotification;

import com.aig.nge.emu.constants.NGEConstants;
import com.aig.nge.emu.util.common.LoadCache;
import com.aig.nge.emu.util.common.NGEException;
import com.aig.nge.emu.util.common.NGESession;
import com.aig.nge.emu.util.common.PropertiesHandler;
import com.aig.nge.emu.util.common.SessionModel;
import com.aig.nge.emu.util.common.SubmissionException;

public class StartUpWork implements MuleContextNotificationListener<MuleContextNotification> {
	

	
	//TODO duplicate code from LegacySubmissionUtilServiceRequestHandler
	private static void loadCache() throws SubmissionException{
		LoadCache ld = new LoadCache();
		try {
			SessionModel sessionModel = new SessionModel();
			sessionModel.setServiceName(NGEConstants.SUBMISSION_SERVICE);
			NGESession.setSessionData(sessionModel);			
			ld.cache();
			//TODO - explore if we need to initialize a seperate cache for SUBMISSION STATUS as well.
			sessionModel.setServiceName(NGEConstants.SUBMISSION_STATUS_SERVICE);
			NGESession.setSessionData(sessionModel);			
			ld.cache();
		} catch (SubmissionException e) {
			if(e.getErrNumber().equalsIgnoreCase(NGEConstants.STALE))
			{
				throw e;
			}
			NGEException.ngePrintStackTrace(e);
		}
	}

	@Override
	public void onNotification(MuleContextNotification notification) {
		try {
			if(notification.getAction() == MuleContextNotification.CONTEXT_STARTED){
				PropertiesHandler.loadAllPropertyFiles();
				loadCache();
			}
		}catch(Exception e){
			e.printStackTrace();
			System.out.println("**** STARTUP EXCEPTION" + e.getMessage());
			System.err.println("**** STARTUP EXCEPTION" + e);
		}	
	}
}
