package com.aig.nge.emu.service;

import com.aig.logging.NGELogger;
import com.aig.nge.emu.api.legacysubmissionutil.HandleExtensionFault;
import com.aig.nge.emu.api.legacysubmissionutil.HandleExtensionFaultResponse;
import com.aig.nge.emu.api.legacysubmissionutil.HandleExtensionReq;
import com.aig.nge.emu.api.legacysubmissionutil.HandleExtensionReqResponse;
import com.aig.nge.emu.api.legacysubmissionutil.HandleExtensionResp;
import com.aig.nge.emu.api.legacysubmissionutil.HandleExtensionRespResponse;
import com.aig.nge.emu.constants.LegacyConstants;
import com.aig.nge.emu.constants.NGEConstants;
import com.aig.nge.emu.helper.CommonHelper;
import com.aig.nge.emu.helper.SubmissionServiceCommomHelper;
import com.aig.nge.emu.logic.java.ExtensionJava;
import com.aig.nge.emu.util.common.NGEException;
import com.aig.nge.emu.util.common.PropertiesHandler;
import com.aig.nge.emu.util.common.ServiceException;
import com.aig.nge.emu.util.common.SubmissionException;
import com.aig.nge.emu.xsd.service.internal.esb.ExtendAutoCloseDaysRequest;
import com.aig.nge.emu.xsd.service.legacy.submissionService.Extension;
import com.aig.nge.emu.xsd.service.legacy.submissionService.Response;
import com.aig.nge.emu.xsd.service.legacy.submissionService.SubmissionServiceXML;

/**
 * @author Dineshkumar V
 *
 */
public class ExtensionImpl extends AbstractCommand {
	
	private ExtensionJava extensionJava;
	private NGEException ngeException;
	private SubmissionServiceCommomHelper submissionServiceCommomHelper;
	
	com.aig.nge.emu.api.legacysubmissionutil.ObjectFactory of = new com.aig.nge.emu.api.legacysubmissionutil.ObjectFactory();
	com.aig.nge.emu.xsd.service.internal.esb.ObjectFactory of2 = new com.aig.nge.emu.xsd.service.internal.esb.ObjectFactory();
	
	public ExtensionImpl(){
		extensionJava=new ExtensionJava();
		ngeException=new NGEException();
		submissionServiceCommomHelper=new SubmissionServiceCommomHelper();
	}

	public HandleExtensionReqResponse processRequest(HandleExtensionReq handleExtensionReq) throws SubmissionException {
		NGELogger.methodEnteringLog();
		Response result=null;
		Extension extensionLegacy=null;
		SubmissionServiceXML submissionServiceXML=handleExtensionReq.getSubmissionServiceXML();
		ExtendAutoCloseDaysRequest extendAutoCloseDaysRequest=null;
		HandleExtensionReqResponse handleExtensionReqResponse = null;
		try{
		/*DataObject legacyRequestObj = handleExtensionReq.getDataObject(XpathConstants.LEGACY_REQUEST_ROOT);
		DataObject ngeRequestObj = handleExtensionReq.getDataObject(XpathConstants.NGE_EXTEND_AUTO_CLOSE_REQUEST_ROOT);*/
		
			/*if(null == legacyRequestObj )
				throw new ServiceException("Legacy request mapping not found in DataObject");
			
			//Converting legacy request Data Object to XML 
			String legacyRequestXML=XMLBOConversion.parseBOtoXML(legacyRequestObj);
			NGELogger.methodDebugLog("Legacy Extension request", legacyRequestXML);
			//Converting Legacy requestXML to POJO
			submissionServiceXML=(SubmissionServiceXML) NGEUnmarshaller.unMarshallerSS(legacyRequestXML, SubmissionServiceXML.class);*/
			
			handleExtensionReqResponse = of.createHandleExtensionReqResponse();
			extendAutoCloseDaysRequest = of2.createExtendAutoCloseDaysRequest();
			//To check whether property files are exist or not
			PropertiesHandler.checkPropertyFileForSubmissionService(submissionServiceXML);
			
		/*	if(null != ngeRequestObj){
			//Converting NGE request Data Object to XML 
			String ngeRequestXML=XMLBOConversion.parseBOtoXMLNGE(ngeRequestObj);*/
			
			//Converting NGE requestXML to POJO
		/*	extendAutoCloseDaysRequest=(ExtendAutoCloseDaysRequest) NGEUnmarshaller.unMarshallerSS(ngeRequestXML, ExtendAutoCloseDaysRequest.class);
			}else{
				extendAutoCloseDaysRequest=new ExtendAutoCloseDaysRequest();
			}*/

			if(null == submissionServiceXML.getRequest().getArguments().getExtension()){
				throw new ServiceException("Request missing extension details");
			}
			
			submissionServiceCommomHelper.formatSystemIdAndUser(submissionServiceXML);
			
			extensionLegacy=submissionServiceXML.getRequest().getArguments().getExtension();
			
			result=extensionJava.requestValidation(extensionLegacy,extendAutoCloseDaysRequest);
			
	        handleExtensionReqResponse.setExtendAutoCloseDaysRequest(extendAutoCloseDaysRequest);
			handleExtensionReqResponse.setSubmissionServiceXML(submissionServiceXML);
		/*	if(result == null ){
			
				submissionServiceXML.getRequest().getArguments().setExtension(extensionLegacy);
				String submission= NGEMarshaller.marshaller(submissionServiceXML,SubmissionServiceXML.class);
				
				DataObject submissionData=XMLBOConversion.parseXMLtoBOSubmissionService(submission);
						
				handleExtensionReq.setDataObject(XpathConstants.LEGACY_REQUEST_ROOT,submissionData);
			//Converting NGE requestXML to POJO
			String extenACD= NGEMarshaller.marshaller(extendAutoCloseDaysRequest,ExtendAutoCloseDaysRequest.class);
			NGELogger.methodDebugLog("Extend Auto Close Internal Service request", extenACD);

			DataObject extendAutoClose=XMLBOConversion.parseXMLtoBONGE(extenACD);
					
			handleExtensionReq.setDataObject(XpathConstants.NGE_EXTEND_AUTO_CLOSE_REQUEST_ROOT,extendAutoClose);
			}else{
				//Converting NGE requestXML to POJO
				submissionServiceXML.setResponse(result);
				String submission= NGEMarshaller.marshaller(submissionServiceXML,SubmissionServiceXML.class);
				
				DataObject submissionData=XMLBOConversion.parseXMLtoBOSubmissionService(submission);
						
				handleExtensionReq.setDataObject(XpathConstants.LEGACY_REQUEST_ROOT,submissionData);
				
			}
			 */
		}catch(SubmissionException ex){				
			NGELogger.methodDebugLog("SubmissionException ", ex.getMessage());
			if(ex.getErrNumber().equalsIgnoreCase(NGEConstants.STALE))
				{
					throw ex;
				}
			ngeException.getErrorResponse(LegacyConstants.SERVICE_ERROR,ex.getMessage(),LegacyConstants.MessageType.SYSTEM);
		}catch(Exception e){
			NGEException.ngePrintStackTrace(e);
			NGELogger.methodErrorLog(e.getMessage());
			ngeException.getErrorResponse(LegacyConstants.SERVICE_ERROR,e.getMessage(),LegacyConstants.MessageType.SYSTEM);
		}
		NGELogger.methodExitingLog();
		return handleExtensionReqResponse;
	}

	public HandleExtensionRespResponse processSuccessResponse(HandleExtensionResp handleExtensionResp) throws SubmissionException {
		NGELogger.methodEnteringLog();
		Response response=null;
		SubmissionServiceXML submissionServiceXML=handleExtensionResp.getSubmissionServiceXML();
		HandleExtensionRespResponse handleExtensionRespResponse = null;
		try{
		
			handleExtensionRespResponse = of.createHandleExtensionRespResponse();
		/*DataObject legacyResponseObj = handleExtensionResp.getDataObject(XpathConstants.LEGACY_EXTENSION_RESPONSE_ROOT);
		DataObject ngeResponseObj = handleExtensionResp.getDataObject(XpathConstants.NGE_EXTEND_AUTO_CLOSE_RESPONSE_ROOT);
		
		if(null == ngeResponseObj )
			throw new ServiceException("nge request mapping not found in DataObject");
		
		//Converting legacy request Data Object to XML 
		String legacyResponseXML=XMLBOConversion.parseBOtoXML(legacyResponseObj);
		
		//Converting Legacy requestXML to POJO
		submissionServiceXML=(SubmissionServiceXML) NGEUnmarshaller.unMarshallerSS(legacyResponseXML, SubmissionServiceXML.class);
		
*/
		if(null == submissionServiceXML){
			throw new ServiceException("Response missing submission details");
		}
		
		extensionJava.updateBundleComponentProduct(submissionServiceXML);
		response=CommonHelper.getSuccessResponse(LegacyConstants.EXTENSION_SUCCESS_NO, LegacyConstants.EXTENSION_SUCCESS_MSG, LegacyConstants.MessageType.INFO, null);
		
		submissionServiceXML.setResponse(response);
		handleExtensionRespResponse.setSubmissionServiceXML(submissionServiceXML);
	/*	//Converting NGE requestXML to POJO
		String submission= NGEMarshaller.marshaller(submissionServiceXML,SubmissionServiceXML.class);
		
		DataObject submissionData=XMLBOConversion.parseXMLtoBOSubmissionService(submission);
				
		handleExtensionResp.setDataObject(XpathConstants.LEGACY_EXTENSION_RESPONSE_ROOT,submissionData);*/
		
		}catch(SubmissionException ex){				
			NGELogger.methodDebugLog("SubmissionException ", ex.getMessage());
			if(ex.getErrNumber().equalsIgnoreCase(NGEConstants.STALE))
				{
					throw ex;
				}
		}catch(Exception e){
			NGEException.ngePrintStackTrace(e);
			NGELogger.methodErrorLog(e.getMessage());
		}
		NGELogger.methodExitingLog();
		
		return handleExtensionRespResponse;
	}
	
	public HandleExtensionFaultResponse processFaultLogicResponse(HandleExtensionFault handleExtensionFault) throws SubmissionException {
	NGELogger.methodEnteringLog();
		Response response=null;
		SubmissionServiceXML submissionServiceXML=handleExtensionFault.getSubmissionServiceXML();
		HandleExtensionFaultResponse handleExtensionFaultResponse = null;
		try{
		
			handleExtensionFaultResponse =of.createHandleExtensionFaultResponse();
	//	DataObject legacyResponseObj = handleExtensionFault.getDataObject(XpathConstants.LEGACY_RESPONSE_ROOT);
		
		//Converting legacy request Data Object to XML 
	/*	String legacyResponseXML=XMLBOConversion.parseBOtoXML(legacyResponseObj);
		NGELogger.methodDebugLog("NGE Extend fault errro", legacyResponseXML);
		//Converting Legacy requestXML to POJO
		submissionServiceXML=(SubmissionServiceXML) NGEUnmarshaller.unMarshallerSS(legacyResponseXML, SubmissionServiceXML.class);
		*/

		if(null == submissionServiceXML){
			throw new ServiceException("Response missing Submission details");
		}
		response=ngeException.getErrorResponse(LegacyConstants.NO_EXTENSION_NO,LegacyConstants.NO_EXTENSION_MSG,LegacyConstants.MessageType.LOGICAL);
		
		submissionServiceXML.setResponse(response);
		handleExtensionFaultResponse.setSubmissionServiceXML(submissionServiceXML);
		
		//Converting NGE requestXML to POJO
		//String submission= NGEMarshaller.marshaller(submissionServiceXML,SubmissionServiceXML.class);
		
		//DataObject submissionData=XMLBOConversion.parseXMLtoBOSubmissionService(submission);
				
		//handleExtensionFault.setDataObject(XpathConstants.LEGACY_RESPONSE_ROOT,submissionData);
		
		}catch(Exception ex){				
			NGELogger.methodDebugLog("SubmissionException ", ex.getMessage());
			
			NGEException.ngePrintStackTrace(ex);
			NGELogger.methodErrorLog(ex.getMessage());
		}
		NGELogger.methodExitingLog();
		return handleExtensionFaultResponse;
	}
	
	
	

	@Override
	public Object handleRequest(Object obj) throws SubmissionException {
		return processRequest((HandleExtensionReq)obj);
	}

	@Override
	public Object handleResponse(Object obj) throws SubmissionException {
		 return processSuccessResponse((HandleExtensionResp)obj);
	}


	@Override
	public Object handleError(Object obj) throws SubmissionException {
		throw new SubmissionException("Unsupported operation for AddSubmissionImpl");
	}

	@Override
	public Object handleFault(Object obj) throws SubmissionException {
		return processFaultLogicResponse((HandleExtensionFault)obj);
	}

}
