package com.aig.nge.emu.service;

import com.aig.logging.NGELogger;
import com.aig.nge.emu.api.legacysubmissionutil.HandleUpdateSubmissionDetailsFault;
import com.aig.nge.emu.api.legacysubmissionutil.HandleUpdateSubmissionDetailsFaultResponse;
import com.aig.nge.emu.api.legacysubmissionutil.HandleUpdateSubmissionDetailsReq;
import com.aig.nge.emu.api.legacysubmissionutil.HandleUpdateSubmissionDetailsReqResponse;
import com.aig.nge.emu.api.legacysubmissionutil.HandleUpdateSubmissionDetailsResp;
import com.aig.nge.emu.api.legacysubmissionutil.HandleUpdateSubmissionDetailsRespResponse;
import com.aig.nge.emu.constants.NGEConstants;
import com.aig.nge.emu.helper.SubmissionServiceCommomHelper;
import com.aig.nge.emu.logic.java.UpdateSubmissionJava;
import com.aig.nge.emu.logic.mainframe.UpdateSubmissionMF;
import com.aig.nge.emu.util.common.NGEException;
import com.aig.nge.emu.util.common.PropertiesHandler;
import com.aig.nge.emu.util.common.ServiceException;
import com.aig.nge.emu.util.common.SubmissionException;
import com.aig.nge.emu.xsd.service.internal.submissionService.UpdateSubmissionDetailsRq;
import com.aig.nge.emu.xsd.service.internal.submissionService.UpdateSubmissionDetailsRs;
import com.aig.nge.emu.xsd.service.legacy.submissionService.Error;
import com.aig.nge.emu.xsd.service.legacy.submissionService.SubmissionServiceXML;

public class UpdateSubmissionImpl extends AbstractCommand{
	//extended commnad class
	private  UpdateSubmissionJava updateSubmissionJava;
	private  UpdateSubmissionMF updateSubmissionMF;
	private  SubmissionServiceCommomHelper submissionServiceCommomHelper;
	//created legacysubmissionutil object factory
	com.aig.nge.emu.api.legacysubmissionutil.ObjectFactory of = new com.aig.nge.emu.api.legacysubmissionutil.ObjectFactory();
	com.aig.nge.emu.xsd.service.internal.submissionService.ObjectFactory of2 = new com.aig.nge.emu.xsd.service.internal.submissionService.ObjectFactory();
	
	public UpdateSubmissionImpl(){
		updateSubmissionJava=new UpdateSubmissionJava();
		updateSubmissionMF=new UpdateSubmissionMF();
		submissionServiceCommomHelper=new SubmissionServiceCommomHelper();
	}


	public HandleUpdateSubmissionDetailsReqResponse processRequest(HandleUpdateSubmissionDetailsReq handleUpdateSubmissionDetailsReq) throws SubmissionException {
		NGELogger.methodEnteringLog();
		SubmissionServiceXML submissionServiceXML = handleUpdateSubmissionDetailsReq.getSubmissionServiceXML();
		UpdateSubmissionDetailsRq updateSubmissionRq=null;
		HandleUpdateSubmissionDetailsReqResponse handleUpdateSubmissionDetailsReqResponse=null;
		try{	
			handleUpdateSubmissionDetailsReqResponse = of.createHandleUpdateSubmissionDetailsReqResponse();
			updateSubmissionRq= of2.createUpdateSubmissionDetailsRq();	

			//To check whether property files are exist or not
			PropertiesHandler.checkPropertyFileForSubmissionService(submissionServiceXML);
			
			submissionServiceCommomHelper.formatSystemIdAndUser(submissionServiceXML);
			//SecuredId is used for separating the mainframe layer and XML emulation layer
			//If securedId is not null then consider incoming is Mainframe request 
			String securedId=submissionServiceXML.getIdentity().getSecuredId();
			
			if(null == securedId || 0 == securedId.length()){
				updateSubmissionJava.requestValidation(submissionServiceXML);
			}else if(securedId.equalsIgnoreCase(NGEConstants.MAINFRAME_USER)){
				updateSubmissionMF.requestMFProcess(submissionServiceXML);
			}
			
			if(submissionServiceXML.getResponse() == null || 0 == submissionServiceXML.getResponse().getErrors().getError().size())
				updateSubmissionMF.requestValidation(submissionServiceXML,updateSubmissionRq);
			
			if(submissionServiceXML.getResponse() != null && 0 == submissionServiceXML.getResponse().getErrors().getError().size())
				 submissionServiceXML.getResponse().setErrors(null);
			
			submissionServiceCommomHelper.reomoveDuplicateEntry(submissionServiceXML, updateSubmissionRq);
			
			handleUpdateSubmissionDetailsReqResponse.setUpdateSubmissionDetailsRq(updateSubmissionRq);				
			handleUpdateSubmissionDetailsReqResponse.setSubmissionServiceXML(submissionServiceXML);		
		}catch(SubmissionException ex){				
			NGELogger.methodDebugLog("SubmissionException ", ex.getMessage());
			if(ex.getErrNumber().equalsIgnoreCase(NGEConstants.STALE))
				{
					throw ex;
				}
		}catch(Exception e){
			NGELogger.methodErrorLog(e.getMessage());
			NGEException.ngePrintStackTrace(e);
			//result=NGEException.getErrorResponse(LegacyConstants.SERVICE_ERROR,e.getMessage(),LegacyConstants.MessageType.SYSTEM);
		}
		NGELogger.methodExitingLog();
		return handleUpdateSubmissionDetailsReqResponse;
	}

	public HandleUpdateSubmissionDetailsRespResponse processSuccessResponse(HandleUpdateSubmissionDetailsResp handleUpdateSubmissionDetailsResp) throws SubmissionException {
		NGELogger.methodEnteringLog();
        SubmissionServiceXML submissionServiceResponseXML=handleUpdateSubmissionDetailsResp.getSubmissionServiceXML();
        HandleUpdateSubmissionDetailsRespResponse handleUpdateSubmissionDetailsRespResponse =null;
		
		try{
			handleUpdateSubmissionDetailsRespResponse = of.createHandleUpdateSubmissionDetailsRespResponse();
			UpdateSubmissionDetailsRs updateSubmission= handleUpdateSubmissionDetailsResp.getUpdateSubmissionDetailsRs();
			
			updateSubmissionMF.extensionTableInsertion(submissionServiceResponseXML, updateSubmission);
			
			handleUpdateSubmissionDetailsRespResponse.setSubmissionServiceXML(submissionServiceResponseXML);
			}catch(SubmissionException ex){				
				NGELogger.methodDebugLog("SubmissionException ", ex.getMessage());
				if(ex.getErrNumber().equalsIgnoreCase(NGEConstants.STALE))
					{
						throw ex;
					}
			}
			catch(Exception e){
				NGEException.ngePrintStackTrace(e);
				NGELogger.methodErrorLog(e.getMessage());
			}
			NGELogger.methodExitingLog();
			return handleUpdateSubmissionDetailsRespResponse;
	}
	
	public HandleUpdateSubmissionDetailsFaultResponse processFaultLogic(HandleUpdateSubmissionDetailsFault handleUpdateSubmissionDetailsFault) throws SubmissionException {
		NGELogger.methodEnteringLog();
		SubmissionServiceXML submissionServiceXML=null;
		HandleUpdateSubmissionDetailsFaultResponse  handleUpdateSubmissionDetailsFaultResponse = null;
		try{
			handleUpdateSubmissionDetailsFaultResponse = of.createHandleUpdateSubmissionDetailsFaultResponse();
	
			submissionServiceXML = handleUpdateSubmissionDetailsFault.getSubmissionServiceXML();
			
			if(null == submissionServiceXML){
				throw new ServiceException("Response missing Submission details");
			}
			
			for(Error error:submissionServiceXML.getResponse().getErrors().getError()){
				submissionServiceCommomHelper.generateLegacyErrorByNGE(error, submissionServiceXML);
			}
			
		   handleUpdateSubmissionDetailsFaultResponse.setSubmissionServiceXML(submissionServiceXML);
		}
		catch(SubmissionException ex){				
			NGELogger.methodDebugLog("SubmissionException ", ex.getMessage());
			if(ex.getErrNumber().equalsIgnoreCase(NGEConstants.STALE))
				{
					throw ex;
				}
		}catch(Exception e){
			NGELogger.methodErrorLog(e.getMessage());
			NGEException.ngePrintStackTrace(e);
		}
		NGELogger.methodExitingLog();
		return handleUpdateSubmissionDetailsFaultResponse;
	}

	@Override
	public Object handleRequest(Object obj) throws SubmissionException {
		return processRequest((HandleUpdateSubmissionDetailsReq)obj);
		
	}

	@Override
	public Object handleResponse(Object obj) throws SubmissionException {
	     return processSuccessResponse((HandleUpdateSubmissionDetailsResp)obj);
	}

	@Override
	public Object handleError(Object obj) throws SubmissionException {
		throw new SubmissionException("Unsupported operation for UpdateSubmissionImpl");
	}

	@Override
	public Object handleFault(Object obj) throws SubmissionException {
		return processFaultLogic((HandleUpdateSubmissionDetailsFault)obj);
	}
}
