# nge-us-legacy-submissionutil

## Local Setup Instructions:
* Follow the basic instructions here http://confluence.aig.net:8090/display/CI/Mule+Code+-+Local+Env+setup+and+Deploy+Instructions.
* Get the code.  
    * git clone https://github.aig.net/commercial-it-integration/nge-us-legacy-submissionutil.git
* Create keyfile.properties file under C:/Temp/Props (or any other folder) and enter below values in the file:  
   vault.key=Synergy123456789
* Run maven to pull required dependencies and generate eclipse classpath files.
```
 mvn clean install -Dmule.propertiesFolder=C:/Temp/Props -Dmule.env=local
 mvn eclipse:eclipse
``` 
* Import the code to Anypoint Studio using 'Maven-based Mule Project from pom.xml' option.
* Update the tls-default.conf under C:\AnypointStudio\plugins\org.mule.tooling.server.3.9.0.ee_6.4.1.201710111930\mule\conf.  
   enabledProtocols=TLSv1,TLSv1.1,TLSv1.2
* Optional. If testing against WPS DEV which uses MD5WithRSA algorithm, update jdk1.x.x_xxx\jre\lib\security\java.security file to 
	* remove MD2 and MD5 from jdk.certpath.disabledAlgorithms: 
```
		jdk.certpath.disabledAlgorithms=SHA1 jdkCA & usage TLSServer, \
		    RSA keySize < 1024, DSA keySize < 1024, EC keySize < 224'
```    	
	* remove MD5WithRSA from jdk.tls.disabledAlgorithms:
		
```
		jdk.tls.disabledAlgorithms=SSLv3, RC4, DH keySize < 768, \
		    EC keySize < 224
```
* Open command prompt as Administrator and configure the certificates (for all backend https URLs) using keytool commands as defined at below URL: 
http://confluence.aig.net:8090/display/CI/Certs+for+Developers

* Run the app with the following vm Settings in VM arguments.  
  -XX:PermSize=128M -XX:MaxPermSize=256M -DskipTests -Dmule.env=dev -Dmule.propertiesFolder=C:/Temp/Props
  	
* Test the app using soapui ui project xml (if) available under /src/test/soapui/ or /src/test/resources/soapui
		